/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageInfo
 */
package android.support.v4.content.pm;

import android.content.pm.PackageInfo;
import android.support.v4.os.BuildCompat;

public final class PackageInfoCompat {
    private PackageInfoCompat() {
    }

    public static long getLongVersionCode(PackageInfo packageInfo) {
        if (BuildCompat.isAtLeastP()) {
            return packageInfo.getLongVersionCode();
        }
        return packageInfo.versionCode;
    }
}

