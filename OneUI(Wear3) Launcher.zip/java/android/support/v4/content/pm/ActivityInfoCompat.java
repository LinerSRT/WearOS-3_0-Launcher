/*
 * Decompiled with CFR 0.151.
 */
package android.support.v4.content.pm;

@Deprecated
public final class ActivityInfoCompat {
    @Deprecated
    public static final int CONFIG_UI_MODE = 512;

    private ActivityInfoCompat() {
    }
}

