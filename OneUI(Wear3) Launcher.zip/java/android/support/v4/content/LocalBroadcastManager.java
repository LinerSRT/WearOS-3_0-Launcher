/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Handler
 *  android.os.Message
 *  android.util.Log
 */
package android.support.v4.content;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;

public final class LocalBroadcastManager {
    private static final boolean DEBUG = false;
    static final int MSG_EXEC_PENDING_BROADCASTS = 1;
    private static final String TAG = "LocalBroadcastManager";
    private static LocalBroadcastManager mInstance;
    private static final Object mLock;
    private final HashMap<String, ArrayList<ReceiverRecord>> mActions;
    private final Context mAppContext;
    private final Handler mHandler;
    private final ArrayList<BroadcastRecord> mPendingBroadcasts;
    private final HashMap<BroadcastReceiver, ArrayList<ReceiverRecord>> mReceivers = new HashMap();

    static {
        mLock = new Object();
    }

    private LocalBroadcastManager(Context context) {
        this.mActions = new HashMap();
        this.mPendingBroadcasts = new ArrayList();
        this.mAppContext = context;
        this.mHandler = new Handler(context.getMainLooper()){

            public void handleMessage(Message message) {
                if (message.what != 1) {
                    super.handleMessage(message);
                } else {
                    LocalBroadcastManager.this.executePendingBroadcasts();
                }
            }
        };
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void executePendingBroadcasts() {
        Throwable throwable2;
        block5: while (true) {
            BroadcastRecord[] broadcastRecordArray;
            int n;
            Object object = this.mReceivers;
            synchronized (object) {
                n = this.mPendingBroadcasts.size();
                if (n <= 0) {
                    return;
                }
                broadcastRecordArray = new BroadcastRecord[n];
                try {
                    this.mPendingBroadcasts.toArray(broadcastRecordArray);
                    this.mPendingBroadcasts.clear();
                    // MONITOREXIT @DISABLED, blocks:[1, 3, 5] lbl13 : MonitorExitStatement: MONITOREXIT : var1_1
                    n = 0;
                }
                catch (Throwable throwable2) {
                    break;
                }
            }
            while (true) {
                if (n >= broadcastRecordArray.length) continue block5;
                BroadcastRecord broadcastRecord = broadcastRecordArray[n];
                int n2 = broadcastRecord.receivers.size();
                for (int i = 0; i < n2; ++i) {
                    object = broadcastRecord.receivers.get(i);
                    if (((ReceiverRecord)object).dead) continue;
                    ((ReceiverRecord)object).receiver.onReceive(this.mAppContext, broadcastRecord.intent);
                }
                ++n;
            }
            break;
        }
        {
            throw throwable2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static LocalBroadcastManager getInstance(Context object) {
        Object object2 = mLock;
        synchronized (object2) {
            LocalBroadcastManager localBroadcastManager;
            if (mInstance != null) return mInstance;
            mInstance = localBroadcastManager = new LocalBroadcastManager(object.getApplicationContext());
            return mInstance;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void registerReceiver(BroadcastReceiver object, IntentFilter intentFilter) {
        HashMap<BroadcastReceiver, ArrayList<ReceiverRecord>> hashMap = this.mReceivers;
        synchronized (hashMap) {
            ReceiverRecord receiverRecord = new ReceiverRecord(intentFilter, (BroadcastReceiver)object);
            Object object2 = this.mReceivers.get(object);
            ArrayList<ReceiverRecord> arrayList = object2;
            if (object2 == null) {
                arrayList = new ArrayList<ReceiverRecord>(1);
                this.mReceivers.put((BroadcastReceiver)object, arrayList);
            }
            arrayList.add(receiverRecord);
            int n = 0;
            while (n < intentFilter.countActions()) {
                object2 = intentFilter.getAction(n);
                arrayList = this.mActions.get(object2);
                object = arrayList;
                if (arrayList == null) {
                    object = new ArrayList(1);
                    this.mActions.put((String)object2, (ArrayList<ReceiverRecord>)object);
                }
                object.add(receiverRecord);
                ++n;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean sendBroadcast(Intent var1_1) {
        var2_2 = this.mReceivers;
        synchronized (var2_2) {
            block17: {
                var3_3 = var1_1.getAction();
                var4_4 = var1_1.resolveTypeIfNeeded(this.mAppContext.getContentResolver());
                var5_5 = var1_1.getData();
                var6_6 = var1_1.getScheme();
                var7_7 = var1_1.getCategories();
                var8_8 = (var1_1.getFlags() & 8) != 0 ? 1 : 0;
                if (var8_8 != 0) {
                    var9_9 = new StringBuilder();
                    var9_9.append("Resolving type ");
                    var9_9.append((String)var4_4);
                    var9_9.append(" scheme ");
                    var9_9.append(var6_6);
                    var9_9.append(" of intent ");
                    var9_9.append(var1_1);
                    Log.v((String)"LocalBroadcastManager", (String)var9_9.toString());
                }
                if ((var10_10 = this.mActions.get(var1_1.getAction())) == null) break block17;
                if (var8_8 != 0) {
                    var9_9 = new StringBuilder();
                    var9_9.append("Action list: ");
                    var9_9.append(var10_10);
                    Log.v((String)"LocalBroadcastManager", (String)var9_9.toString());
                }
                var11_11 = null;
                for (var12_12 = 0; var12_12 < var10_10.size(); ++var12_12) {
                    block18: {
                        var13_13 = var10_10.get(var12_12);
                        if (var8_8 != 0) {
                            var9_9 = new StringBuilder();
                            var9_9.append("Matching against filter ");
                            var9_9.append(var13_13.filter);
                            Log.v((String)"LocalBroadcastManager", (String)var9_9.toString());
                        }
                        if (!var13_13.broadcasting) break block18;
                        if (var8_8 != 0) {
                            Log.v((String)"LocalBroadcastManager", (String)"  Filter's target already added");
                        }
                        ** GOTO lbl78
                    }
                    var14_14 = var13_13.filter;
                    var9_9 = var11_11;
                    var15_15 = var14_14.match(var3_3, (String)var4_4, var6_6, var5_5, var7_7, "LocalBroadcastManager");
                    if (var15_15 >= 0) {
                        if (var8_8 != 0) {
                            var11_11 = new StringBuilder();
                            var11_11.append("  Filter matched!  match=0x");
                            var11_11.append(Integer.toHexString(var15_15));
                            Log.v((String)"LocalBroadcastManager", (String)var11_11.toString());
                        }
                        if (var9_9 == null) {
                            var9_9 = new ArrayList();
                        }
                        var9_9.add(var13_13);
                        var13_13.broadcasting = true;
                    } else {
                        if (var8_8 != 0) {
                            var9_9 = var15_15 != -4 ? (var15_15 != -3 ? (var15_15 != -2 ? (var15_15 != -1 ? "unknown reason" : "type") : "data") : "action") : "category";
                            var13_13 = new StringBuilder();
                            var13_13.append("  Filter did not match: ");
                            var13_13.append((String)var9_9);
                            Log.v((String)"LocalBroadcastManager", (String)var13_13.toString());
                        }
lbl78:
                        // 4 sources

                        var9_9 = var11_11;
                    }
                    var11_11 = var9_9;
                }
                if (var11_11 != null) {
                    for (var8_8 = 0; var8_8 < var11_11.size(); ++var8_8) {
                        ((ReceiverRecord)var11_11.get((int)var8_8)).broadcasting = false;
                    }
                    var9_9 = this.mPendingBroadcasts;
                    var4_4 = new BroadcastRecord(var1_1, (ArrayList<ReceiverRecord>)var11_11);
                    var9_9.add(var4_4);
                    if (!this.mHandler.hasMessages(1)) {
                        this.mHandler.sendEmptyMessage(1);
                    }
                    return true;
                }
            }
            return false;
        }
    }

    public void sendBroadcastSync(Intent intent) {
        if (this.sendBroadcast(intent)) {
            this.executePendingBroadcasts();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void unregisterReceiver(BroadcastReceiver broadcastReceiver) {
        HashMap<BroadcastReceiver, ArrayList<ReceiverRecord>> hashMap = this.mReceivers;
        synchronized (hashMap) {
            ArrayList<ReceiverRecord> arrayList = this.mReceivers.remove(broadcastReceiver);
            if (arrayList == null) {
                return;
            }
            int n = arrayList.size() - 1;
            while (n >= 0) {
                ReceiverRecord receiverRecord = arrayList.get(n);
                receiverRecord.dead = true;
                for (int i = 0; i < receiverRecord.filter.countActions(); ++i) {
                    String string2 = receiverRecord.filter.getAction(i);
                    ArrayList<ReceiverRecord> arrayList2 = this.mActions.get(string2);
                    if (arrayList2 == null) continue;
                    for (int j = arrayList2.size() - 1; j >= 0; --j) {
                        ReceiverRecord receiverRecord2 = arrayList2.get(j);
                        if (receiverRecord2.receiver != broadcastReceiver) continue;
                        receiverRecord2.dead = true;
                        arrayList2.remove(j);
                    }
                    if (arrayList2.size() > 0) continue;
                    this.mActions.remove(string2);
                }
                --n;
            }
            return;
        }
    }

    private static final class BroadcastRecord {
        final Intent intent;
        final ArrayList<ReceiverRecord> receivers;

        BroadcastRecord(Intent intent, ArrayList<ReceiverRecord> arrayList) {
            this.intent = intent;
            this.receivers = arrayList;
        }
    }

    private static final class ReceiverRecord {
        boolean broadcasting;
        boolean dead;
        final IntentFilter filter;
        final BroadcastReceiver receiver;

        ReceiverRecord(IntentFilter intentFilter, BroadcastReceiver broadcastReceiver) {
            this.filter = intentFilter;
            this.receiver = broadcastReceiver;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder(128);
            stringBuilder.append("Receiver{");
            stringBuilder.append(this.receiver);
            stringBuilder.append(" filter=");
            stringBuilder.append(this.filter);
            if (this.dead) {
                stringBuilder.append(" DEAD");
            }
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }
}

