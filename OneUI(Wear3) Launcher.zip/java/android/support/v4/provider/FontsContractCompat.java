/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ContentUris
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ProviderInfo
 *  android.content.pm.Signature
 *  android.content.res.Resources
 *  android.graphics.Typeface
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  android.os.Build$VERSION
 *  android.os.CancellationSignal
 *  android.os.Handler
 *  android.provider.BaseColumns
 */
package android.support.v4.provider;

import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.provider.BaseColumns;
import android.support.v4.content.res.FontResourcesParserCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.TypefaceCompat;
import android.support.v4.graphics.TypefaceCompatUtil;
import android.support.v4.provider.FontRequest;
import android.support.v4.provider.SelfDestructiveThread;
import android.support.v4.util.LruCache;
import android.support.v4.util.Preconditions;
import android.support.v4.util.SimpleArrayMap;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

public class FontsContractCompat {
    private static final int BACKGROUND_THREAD_KEEP_ALIVE_DURATION_MS = 10000;
    public static final String PARCEL_FONT_RESULTS = "font_results";
    static final int RESULT_CODE_PROVIDER_NOT_FOUND = -1;
    static final int RESULT_CODE_WRONG_CERTIFICATES = -2;
    private static final String TAG = "FontsContractCompat";
    private static final SelfDestructiveThread sBackgroundThread;
    private static final Comparator<byte[]> sByteArrayComparator;
    static final Object sLock;
    static final SimpleArrayMap<String, ArrayList<SelfDestructiveThread.ReplyCallback<TypefaceResult>>> sPendingReplies;
    static final LruCache<String, Typeface> sTypefaceCache;

    static {
        sTypefaceCache = new LruCache(16);
        sBackgroundThread = new SelfDestructiveThread("fonts", 10, 10000);
        sLock = new Object();
        sPendingReplies = new SimpleArrayMap();
        sByteArrayComparator = new Comparator<byte[]>(){

            @Override
            public int compare(byte[] byArray, byte[] byArray2) {
                if (byArray.length != byArray2.length) {
                    return byArray.length - byArray2.length;
                }
                for (int i = 0; i < byArray.length; ++i) {
                    if (byArray[i] == byArray2[i]) continue;
                    return byArray[i] - byArray2[i];
                }
                return 0;
            }
        };
    }

    private FontsContractCompat() {
    }

    public static Typeface buildTypeface(Context context, CancellationSignal cancellationSignal, FontInfo[] fontInfoArray) {
        return TypefaceCompat.createFromFontInfo(context, cancellationSignal, fontInfoArray, 0);
    }

    private static List<byte[]> convertToByteArrayList(Signature[] signatureArray) {
        ArrayList<byte[]> arrayList = new ArrayList<byte[]>();
        for (int i = 0; i < signatureArray.length; ++i) {
            arrayList.add(signatureArray[i].toByteArray());
        }
        return arrayList;
    }

    private static boolean equalsByteArrayList(List<byte[]> list, List<byte[]> list2) {
        if (list.size() != list2.size()) {
            return false;
        }
        for (int i = 0; i < list.size(); ++i) {
            if (Arrays.equals(list.get(i), list2.get(i))) continue;
            return false;
        }
        return true;
    }

    public static FontFamilyResult fetchFonts(Context context, CancellationSignal cancellationSignal, FontRequest fontRequest) throws PackageManager.NameNotFoundException {
        ProviderInfo providerInfo = FontsContractCompat.getProvider(context.getPackageManager(), fontRequest, context.getResources());
        if (providerInfo == null) {
            return new FontFamilyResult(1, null);
        }
        return new FontFamilyResult(0, FontsContractCompat.getFontFromProvider(context, fontRequest, providerInfo.authority, cancellationSignal));
    }

    private static List<List<byte[]>> getCertificates(FontRequest fontRequest, Resources resources) {
        if (fontRequest.getCertificates() != null) {
            return fontRequest.getCertificates();
        }
        return FontResourcesParserCompat.readCerts(resources, fontRequest.getCertificatesArrayResId());
    }

    static FontInfo[] getFontFromProvider(Context context, FontRequest arrayList, String string2, CancellationSignal object) {
        block40: {
            Uri uri;
            Uri uri2;
            Object object2;
            block39: {
                Object var7_8;
                block38: {
                    object2 = new ArrayList();
                    uri2 = new Uri.Builder().scheme("content").authority(string2).build();
                    uri = new Uri.Builder().scheme("content").authority(string2).appendPath("file").build();
                    var7_8 = null;
                    string2 = var7_8;
                    if (Build.VERSION.SDK_INT <= 16) break block38;
                    string2 = var7_8;
                    context = context.getContentResolver();
                    string2 = var7_8;
                    arrayList = ((FontRequest)((Object)arrayList)).getQuery();
                    string2 = var7_8;
                    context = context.query(uri2, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{arrayList}, null, (CancellationSignal)object);
                    break block39;
                }
                string2 = var7_8;
                context = context.getContentResolver();
                string2 = var7_8;
                arrayList = ((FontRequest)((Object)arrayList)).getQuery();
                string2 = var7_8;
                try {
                    context = context.query(uri2, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{arrayList}, null);
                }
                catch (Throwable throwable) {
                    if (string2 != null) {
                        string2.close();
                    }
                    throw throwable;
                }
            }
            object = object2;
            if (context != null) {
                object = object2;
                string2 = context;
                if (context.getCount() <= 0) break block40;
                string2 = context;
                int n = context.getColumnIndex("result_code");
                string2 = context;
                string2 = context;
                arrayList = new ArrayList<Object>();
                string2 = context;
                int n2 = context.getColumnIndex("_id");
                string2 = context;
                int n3 = context.getColumnIndex("file_id");
                string2 = context;
                int n4 = context.getColumnIndex("font_ttc_index");
                string2 = context;
                int n5 = context.getColumnIndex("font_weight");
                string2 = context;
                int n6 = context.getColumnIndex("font_italic");
                while (true) {
                    boolean bl;
                    int n7;
                    int n8;
                    int n9;
                    block44: {
                        block43: {
                            block42: {
                                block41: {
                                    object = arrayList;
                                    string2 = context;
                                    if (!context.moveToNext()) break;
                                    if (n == -1) break block41;
                                    string2 = context;
                                    n9 = context.getInt(n);
                                    break block42;
                                }
                                n9 = 0;
                            }
                            if (n4 != -1) {
                                string2 = context;
                                n8 = context.getInt(n4);
                            } else {
                                n8 = 0;
                            }
                            if (n3 == -1) {
                                string2 = context;
                                object = ContentUris.withAppendedId((Uri)uri2, (long)context.getLong(n2));
                            } else {
                                string2 = context;
                                object = ContentUris.withAppendedId((Uri)uri, (long)context.getLong(n3));
                            }
                            if (n5 != -1) {
                                string2 = context;
                                n7 = context.getInt(n5);
                            } else {
                                n7 = 400;
                            }
                            if (n6 != -1) {
                                string2 = context;
                                if (context.getInt(n6) != 1) break block43;
                                bl = true;
                                break block44;
                            }
                        }
                        bl = false;
                    }
                    string2 = context;
                    string2 = context;
                    object2 = new FontInfo((Uri)object, n8, n7, bl, n9);
                    string2 = context;
                    arrayList.add(object2);
                    continue;
                    break;
                }
            }
        }
        if (context != null) {
            context.close();
        }
        return ((ArrayList)object).toArray(new FontInfo[0]);
    }

    static TypefaceResult getFontInternal(Context context, FontRequest object, int n) {
        int n2;
        block4: {
            try {
                object = FontsContractCompat.fetchFonts(context, null, (FontRequest)object);
                int n3 = ((FontFamilyResult)object).getStatusCode();
                n2 = -3;
                if (n3 != 0) break block4;
            }
            catch (PackageManager.NameNotFoundException nameNotFoundException) {
                return new TypefaceResult(null, -1);
            }
            if ((context = TypefaceCompat.createFromFontInfo(context, null, ((FontFamilyResult)object).getFonts(), n)) != null) {
                n2 = 0;
            }
            return new TypefaceResult((Typeface)context, n2);
        }
        if (((FontFamilyResult)object).getStatusCode() == 1) {
            n2 = -2;
        }
        return new TypefaceResult(null, n2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Typeface getFontSync(final Context object, FontRequest object2, ResourcesCompat.FontCallback object3, Handler object4, boolean bl, int n, int n2) {
        CharSequence charSequence = new StringBuilder();
        charSequence.append(((FontRequest)object2).getIdentifier());
        charSequence.append("-");
        charSequence.append(n2);
        charSequence = charSequence.toString();
        Typeface typeface = sTypefaceCache.get((String)charSequence);
        if (typeface != null) {
            if (object3 == null) return typeface;
            ((ResourcesCompat.FontCallback)object3).onFontRetrieved(typeface);
            return typeface;
        }
        if (bl && n == -1) {
            object = FontsContractCompat.getFontInternal(object, (FontRequest)object2, n2);
            if (object3 == null) return object.mTypeface;
            if (object.mResult == 0) {
                ((ResourcesCompat.FontCallback)object3).callbackSuccessAsync(object.mTypeface, (Handler)object4);
                return object.mTypeface;
            }
            ((ResourcesCompat.FontCallback)object3).callbackFailAsync(object.mResult, (Handler)object4);
            return object.mTypeface;
        }
        object2 = new Callable<TypefaceResult>((FontRequest)object2, n2, (String)charSequence){
            final /* synthetic */ String val$id;
            final /* synthetic */ FontRequest val$request;
            final /* synthetic */ int val$style;
            {
                this.val$request = fontRequest;
                this.val$style = n;
                this.val$id = string2;
            }

            @Override
            public TypefaceResult call() throws Exception {
                TypefaceResult typefaceResult = FontsContractCompat.getFontInternal(object, this.val$request, this.val$style);
                if (typefaceResult.mTypeface != null) {
                    sTypefaceCache.put(this.val$id, typefaceResult.mTypeface);
                }
                return typefaceResult;
            }
        };
        if (bl) {
            try {
                return ((TypefaceResult)FontsContractCompat.sBackgroundThread.postAndWait(object2, (int)n)).mTypeface;
            }
            catch (InterruptedException interruptedException) {
                return null;
            }
        }
        object = object3 == null ? null : new SelfDestructiveThread.ReplyCallback<TypefaceResult>((ResourcesCompat.FontCallback)object3, (Handler)object4){
            final /* synthetic */ ResourcesCompat.FontCallback val$fontCallback;
            final /* synthetic */ Handler val$handler;
            {
                this.val$fontCallback = fontCallback;
                this.val$handler = handler;
            }

            @Override
            public void onReply(TypefaceResult typefaceResult) {
                if (typefaceResult == null) {
                    this.val$fontCallback.callbackFailAsync(1, this.val$handler);
                } else if (typefaceResult.mResult == 0) {
                    this.val$fontCallback.callbackSuccessAsync(typefaceResult.mTypeface, this.val$handler);
                } else {
                    this.val$fontCallback.callbackFailAsync(typefaceResult.mResult, this.val$handler);
                }
            }
        };
        object3 = sLock;
        synchronized (object3) {
            if (sPendingReplies.containsKey(charSequence)) {
                if (object == null) return null;
                sPendingReplies.get(charSequence).add((SelfDestructiveThread.ReplyCallback<TypefaceResult>)object);
                return null;
            }
            if (object != null) {
                object4 = new ArrayList();
                ((ArrayList)object4).add(object);
                sPendingReplies.put((String)charSequence, (ArrayList<SelfDestructiveThread.ReplyCallback<TypefaceResult>>)object4);
            }
        }
        sBackgroundThread.postAndReply(object2, new SelfDestructiveThread.ReplyCallback<TypefaceResult>((String)charSequence){
            final /* synthetic */ String val$id;
            {
                this.val$id = string2;
            }

            /*
             * Unable to fully structure code
             */
            @Override
            public void onReply(TypefaceResult var1_1) {
                var2_4 = FontsContractCompat.sLock;
                synchronized (var2_4) {
                    var3_5 = FontsContractCompat.sPendingReplies.get(this.val$id);
                    if (var3_5 != null) ** GOTO lbl8
                    return;
lbl8:
                    // 1 sources

                    FontsContractCompat.sPendingReplies.remove(this.val$id);
                }
                for (var4_6 = 0; var4_6 < var3_5.size(); ++var4_6) {
                    var3_5.get(var4_6).onReply(var1_1);
                }
                return;
                {
                    catch (Throwable var1_2) {
                        while (true) {
                            try {}
                            catch (Throwable var1_3) {
                                continue;
                            }
                            throw var1_1;
                        }
                    }
                }
            }
        });
        return null;
    }

    public static ProviderInfo getProvider(PackageManager object, FontRequest object2, Resources object3) throws PackageManager.NameNotFoundException {
        String string2 = ((FontRequest)object2).getProviderAuthority();
        ProviderInfo providerInfo = object.resolveContentProvider(string2, 0);
        if (providerInfo != null) {
            if (providerInfo.packageName.equals(((FontRequest)object2).getProviderPackage())) {
                object = FontsContractCompat.convertToByteArrayList(object.getPackageInfo((String)providerInfo.packageName, (int)64).signatures);
                Collections.sort(object, sByteArrayComparator);
                object2 = FontsContractCompat.getCertificates((FontRequest)object2, object3);
                for (int i = 0; i < object2.size(); ++i) {
                    object3 = new ArrayList((Collection)object2.get(i));
                    Collections.sort(object3, sByteArrayComparator);
                    if (!FontsContractCompat.equalsByteArrayList((List<byte[]>)object, (List<byte[]>)object3)) continue;
                    return providerInfo;
                }
                return null;
            }
            object = new StringBuilder();
            ((StringBuilder)object).append("Found content provider ");
            ((StringBuilder)object).append(string2);
            ((StringBuilder)object).append(", but package was not ");
            ((StringBuilder)object).append(((FontRequest)object2).getProviderPackage());
            throw new PackageManager.NameNotFoundException(((StringBuilder)object).toString());
        }
        object = new StringBuilder();
        ((StringBuilder)object).append("No package found for authority: ");
        ((StringBuilder)object).append(string2);
        throw new PackageManager.NameNotFoundException(((StringBuilder)object).toString());
    }

    public static Map<Uri, ByteBuffer> prepareFontData(Context context, FontInfo[] fontInfoArray, CancellationSignal cancellationSignal) {
        HashMap<FontInfo, ByteBuffer> hashMap = new HashMap<FontInfo, ByteBuffer>();
        for (FontInfo fontInfo : fontInfoArray) {
            if (fontInfo.getResultCode() != 0 || hashMap.containsKey(fontInfo = fontInfo.getUri())) continue;
            hashMap.put(fontInfo, TypefaceCompatUtil.mmap(context, cancellationSignal, (Uri)fontInfo));
        }
        return Collections.unmodifiableMap(hashMap);
    }

    public static void requestFont(final Context context, final FontRequest fontRequest, FontRequestCallback fontRequestCallback, Handler handler) {
        handler.post(new Runnable(new Handler(), fontRequestCallback){
            final /* synthetic */ FontRequestCallback val$callback;
            final /* synthetic */ Handler val$callerThreadHandler;
            {
                this.val$callerThreadHandler = handler;
                this.val$callback = fontRequestCallback;
            }

            @Override
            public void run() {
                Object object;
                block7: {
                    block8: {
                        block9: {
                            try {
                                object = FontsContractCompat.fetchFonts(context, null, fontRequest);
                                if (((FontFamilyResult)object).getStatusCode() == 0) break block7;
                                int n = ((FontFamilyResult)object).getStatusCode();
                                if (n == 1) break block8;
                                if (n == 2) break block9;
                            }
                            catch (PackageManager.NameNotFoundException nameNotFoundException) {
                                this.val$callerThreadHandler.post(new Runnable(){

                                    @Override
                                    public void run() {
                                        val$callback.onTypefaceRequestFailed(-1);
                                    }
                                });
                                return;
                            }
                            this.val$callerThreadHandler.post(new Runnable(){

                                @Override
                                public void run() {
                                    val$callback.onTypefaceRequestFailed(-3);
                                }
                            });
                            return;
                        }
                        this.val$callerThreadHandler.post(new Runnable(){

                            @Override
                            public void run() {
                                val$callback.onTypefaceRequestFailed(-3);
                            }
                        });
                        return;
                    }
                    this.val$callerThreadHandler.post(new Runnable(){

                        @Override
                        public void run() {
                            val$callback.onTypefaceRequestFailed(-2);
                        }
                    });
                    return;
                }
                FontInfo[] fontInfoArray = ((FontFamilyResult)object).getFonts();
                if (fontInfoArray != null && fontInfoArray.length != 0) {
                    int n = fontInfoArray.length;
                    for (int i = 0; i < n; ++i) {
                        object = fontInfoArray[i];
                        if (((FontInfo)object).getResultCode() == 0) continue;
                        i = ((FontInfo)object).getResultCode();
                        if (i < 0) {
                            this.val$callerThreadHandler.post(new Runnable(){

                                @Override
                                public void run() {
                                    val$callback.onTypefaceRequestFailed(-3);
                                }
                            });
                        } else {
                            this.val$callerThreadHandler.post(new Runnable(){

                                @Override
                                public void run() {
                                    val$callback.onTypefaceRequestFailed(i);
                                }
                            });
                        }
                        return;
                    }
                    object = FontsContractCompat.buildTypeface(context, null, fontInfoArray);
                    if (object == null) {
                        this.val$callerThreadHandler.post(new Runnable(){

                            @Override
                            public void run() {
                                val$callback.onTypefaceRequestFailed(-3);
                            }
                        });
                        return;
                    }
                    this.val$callerThreadHandler.post(new Runnable((Typeface)object){
                        final /* synthetic */ Typeface val$typeface;
                        {
                            this.val$typeface = typeface;
                        }

                        @Override
                        public void run() {
                            val$callback.onTypefaceRetrieved(this.val$typeface);
                        }
                    });
                    return;
                }
                this.val$callerThreadHandler.post(new Runnable(){

                    @Override
                    public void run() {
                        val$callback.onTypefaceRequestFailed(1);
                    }
                });
                return;
            }
        });
    }

    public static void resetCache() {
        sTypefaceCache.evictAll();
    }

    public static final class Columns
    implements BaseColumns {
        public static final String FILE_ID = "file_id";
        public static final String ITALIC = "font_italic";
        public static final String RESULT_CODE = "result_code";
        public static final int RESULT_CODE_FONT_NOT_FOUND = 1;
        public static final int RESULT_CODE_FONT_UNAVAILABLE = 2;
        public static final int RESULT_CODE_MALFORMED_QUERY = 3;
        public static final int RESULT_CODE_OK = 0;
        public static final String TTC_INDEX = "font_ttc_index";
        public static final String VARIATION_SETTINGS = "font_variation_settings";
        public static final String WEIGHT = "font_weight";
    }

    public static class FontFamilyResult {
        public static final int STATUS_OK = 0;
        public static final int STATUS_UNEXPECTED_DATA_PROVIDED = 2;
        public static final int STATUS_WRONG_CERTIFICATES = 1;
        private final FontInfo[] mFonts;
        private final int mStatusCode;

        public FontFamilyResult(int n, FontInfo[] fontInfoArray) {
            this.mStatusCode = n;
            this.mFonts = fontInfoArray;
        }

        public FontInfo[] getFonts() {
            return this.mFonts;
        }

        public int getStatusCode() {
            return this.mStatusCode;
        }
    }

    public static class FontInfo {
        private final boolean mItalic;
        private final int mResultCode;
        private final int mTtcIndex;
        private final Uri mUri;
        private final int mWeight;

        public FontInfo(Uri uri, int n, int n2, boolean bl, int n3) {
            this.mUri = Preconditions.checkNotNull(uri);
            this.mTtcIndex = n;
            this.mWeight = n2;
            this.mItalic = bl;
            this.mResultCode = n3;
        }

        public int getResultCode() {
            return this.mResultCode;
        }

        public int getTtcIndex() {
            return this.mTtcIndex;
        }

        public Uri getUri() {
            return this.mUri;
        }

        public int getWeight() {
            return this.mWeight;
        }

        public boolean isItalic() {
            return this.mItalic;
        }
    }

    public static class FontRequestCallback {
        public static final int FAIL_REASON_FONT_LOAD_ERROR = -3;
        public static final int FAIL_REASON_FONT_NOT_FOUND = 1;
        public static final int FAIL_REASON_FONT_UNAVAILABLE = 2;
        public static final int FAIL_REASON_MALFORMED_QUERY = 3;
        public static final int FAIL_REASON_PROVIDER_NOT_FOUND = -1;
        public static final int FAIL_REASON_SECURITY_VIOLATION = -4;
        public static final int FAIL_REASON_WRONG_CERTIFICATES = -2;
        public static final int RESULT_OK = 0;

        public void onTypefaceRequestFailed(int n) {
        }

        public void onTypefaceRetrieved(Typeface typeface) {
        }

        @Retention(value=RetentionPolicy.SOURCE)
        public static @interface FontRequestFailReason {
        }
    }

    private static final class TypefaceResult {
        final int mResult;
        final Typeface mTypeface;

        TypefaceResult(Typeface typeface, int n) {
            this.mTypeface = typeface;
            this.mResult = n;
        }
    }
}

