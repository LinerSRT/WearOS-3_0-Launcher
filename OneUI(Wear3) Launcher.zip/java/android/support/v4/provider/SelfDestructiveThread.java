/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.HandlerThread
 *  android.os.Message
 */
package android.support.v4.provider;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class SelfDestructiveThread {
    private static final int MSG_DESTRUCTION = 0;
    private static final int MSG_INVOKE_RUNNABLE = 1;
    private Handler.Callback mCallback;
    private final int mDestructAfterMillisec;
    private int mGeneration;
    private Handler mHandler;
    private final Object mLock = new Object();
    private final int mPriority;
    private HandlerThread mThread;
    private final String mThreadName;

    public SelfDestructiveThread(String string2, int n, int n2) {
        this.mCallback = new Handler.Callback(){

            public boolean handleMessage(Message message) {
                int n = message.what;
                if (n != 0) {
                    if (n != 1) {
                        return true;
                    }
                    SelfDestructiveThread.this.onInvokeRunnable((Runnable)message.obj);
                    return true;
                }
                SelfDestructiveThread.this.onDestruction();
                return true;
            }
        };
        this.mThreadName = string2;
        this.mPriority = n;
        this.mDestructAfterMillisec = n2;
        this.mGeneration = 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void post(Runnable runnable) {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mThread == null) {
                HandlerThread handlerThread;
                this.mThread = handlerThread = new HandlerThread(this.mThreadName, this.mPriority);
                handlerThread.start();
                handlerThread = new Handler(this.mThread.getLooper(), this.mCallback);
                this.mHandler = handlerThread;
                ++this.mGeneration;
            }
            this.mHandler.removeMessages(0);
            this.mHandler.sendMessage(this.mHandler.obtainMessage(1, (Object)runnable));
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int getGeneration() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mGeneration;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean isRunning() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mThread == null) return false;
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void onDestruction() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mHandler.hasMessages(1)) {
                return;
            }
            this.mThread.quit();
            this.mThread = null;
            this.mHandler = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void onInvokeRunnable(Runnable runnable) {
        runnable.run();
        Object object = this.mLock;
        synchronized (object) {
            this.mHandler.removeMessages(0);
            this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(0), (long)this.mDestructAfterMillisec);
            return;
        }
    }

    public <T> void postAndReply(final Callable<T> callable, ReplyCallback<T> replyCallback) {
        this.post(new Runnable(new Handler(), replyCallback){
            final /* synthetic */ Handler val$callingHandler;
            final /* synthetic */ ReplyCallback val$reply;
            {
                this.val$callingHandler = handler;
                this.val$reply = replyCallback;
            }

            @Override
            public void run() {
                Object v;
                try {
                    v = callable.call();
                }
                catch (Exception exception) {
                    v = null;
                }
                this.val$callingHandler.post(new Runnable(){

                    @Override
                    public void run() {
                        val$reply.onReply(v);
                    }
                });
            }
        });
    }

    /*
     * Unable to fully structure code
     */
    public <T> T postAndWait(Callable<T> var1_1, int var2_4) throws InterruptedException {
        block8: {
            var3_5 = new ReentrantLock();
            var4_6 = var3_5.newCondition();
            var5_7 = new AtomicReference<V>();
            var6_8 = new AtomicBoolean(true);
            this.post(new Runnable((Callable)var1_1, var3_5, var6_8, var4_6){
                final /* synthetic */ Callable val$callable;
                final /* synthetic */ Condition val$cond;
                final /* synthetic */ ReentrantLock val$lock;
                final /* synthetic */ AtomicBoolean val$running;
                {
                    this.val$callable = callable;
                    this.val$lock = reentrantLock;
                    this.val$running = atomicBoolean;
                    this.val$cond = condition;
                }

                @Override
                public void run() {
                    try {
                        var5_7.set(this.val$callable.call());
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    this.val$lock.lock();
                    try {
                        this.val$running.set(false);
                        this.val$cond.signal();
                        return;
                    }
                    finally {
                        this.val$lock.unlock();
                    }
                }
            });
            var3_5.lock();
            if (var6_8.get()) break block8;
            var1_1 = var5_7.get();
            var3_5.unlock();
            return (T)var1_1;
        }
        try {
            var7_9 = TimeUnit.MILLISECONDS.toNanos(var2_4);
            while (true) lbl-1000:
            // 2 sources

            {
                try {
                    var7_9 = var9_10 = var4_6.awaitNanos(var7_9);
                }
                catch (InterruptedException var1_2) {
                    // empty catch block
                }
                break;
            }
        }
        catch (Throwable var1_3) {
            var3_5.unlock();
            throw var1_3;
        }
        {
            if (var6_8.get()) continue;
            var1_1 = var5_7.get();
            var3_5.unlock();
            return (T)var1_1;
            ** while (var7_9 > 0L)
        }
lbl31:
        // 2 sources

        var1_1 = new InterruptedException("timeout");
        throw var1_1;
    }

    public static interface ReplyCallback<T> {
        public void onReply(T var1);
    }
}

