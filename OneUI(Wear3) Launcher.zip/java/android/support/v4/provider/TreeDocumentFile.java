/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.net.Uri
 *  android.provider.DocumentsContract
 *  android.util.Log
 */
package android.support.v4.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.support.v4.provider.DocumentFile;
import android.support.v4.provider.DocumentsContractApi19;
import android.util.Log;
import java.util.ArrayList;

class TreeDocumentFile
extends DocumentFile {
    private Context mContext;
    private Uri mUri;

    TreeDocumentFile(DocumentFile documentFile, Context context, Uri uri) {
        super(documentFile);
        this.mContext = context;
        this.mUri = uri;
    }

    private static void closeQuietly(AutoCloseable autoCloseable) {
        if (autoCloseable != null) {
            try {
                autoCloseable.close();
            }
            catch (Exception exception) {
            }
            catch (RuntimeException runtimeException) {
                throw runtimeException;
            }
        }
    }

    private static Uri createFile(Context context, Uri uri, String string2, String string3) {
        try {
            context = DocumentsContract.createDocument((ContentResolver)context.getContentResolver(), (Uri)uri, (String)string2, (String)string3);
            return context;
        }
        catch (Exception exception) {
            return null;
        }
    }

    @Override
    public boolean canRead() {
        return DocumentsContractApi19.canRead(this.mContext, this.mUri);
    }

    @Override
    public boolean canWrite() {
        return DocumentsContractApi19.canWrite(this.mContext, this.mUri);
    }

    @Override
    public DocumentFile createDirectory(String object) {
        object = (object = TreeDocumentFile.createFile(this.mContext, this.mUri, "vnd.android.document/directory", (String)object)) != null ? new TreeDocumentFile(this, this.mContext, (Uri)object) : null;
        return object;
    }

    @Override
    public DocumentFile createFile(String object, String string2) {
        object = (object = TreeDocumentFile.createFile(this.mContext, this.mUri, (String)object, string2)) != null ? new TreeDocumentFile(this, this.mContext, (Uri)object) : null;
        return object;
    }

    @Override
    public boolean delete() {
        try {
            boolean bl = DocumentsContract.deleteDocument((ContentResolver)this.mContext.getContentResolver(), (Uri)this.mUri);
            return bl;
        }
        catch (Exception exception) {
            return false;
        }
    }

    @Override
    public boolean exists() {
        return DocumentsContractApi19.exists(this.mContext, this.mUri);
    }

    @Override
    public String getName() {
        return DocumentsContractApi19.getName(this.mContext, this.mUri);
    }

    @Override
    public String getType() {
        return DocumentsContractApi19.getType(this.mContext, this.mUri);
    }

    @Override
    public Uri getUri() {
        return this.mUri;
    }

    @Override
    public boolean isDirectory() {
        return DocumentsContractApi19.isDirectory(this.mContext, this.mUri);
    }

    @Override
    public boolean isFile() {
        return DocumentsContractApi19.isFile(this.mContext, this.mUri);
    }

    @Override
    public boolean isVirtual() {
        return DocumentsContractApi19.isVirtual(this.mContext, this.mUri);
    }

    @Override
    public long lastModified() {
        return DocumentsContractApi19.lastModified(this.mContext, this.mUri);
    }

    @Override
    public long length() {
        return DocumentsContractApi19.length(this.mContext, this.mUri);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public DocumentFile[] listFiles() {
        Throwable throwable2;
        Uri[] uriArray;
        block7: {
            Object object = this.mContext.getContentResolver();
            DocumentFile[] documentFileArray = this.mUri;
            Object object2 = DocumentsContract.buildChildDocumentsUriUsingTree((Uri)documentFileArray, (String)DocumentsContract.getDocumentId((Uri)documentFileArray));
            ArrayList<Uri> arrayList = new ArrayList<Uri>();
            documentFileArray = null;
            uriArray = null;
            object = object.query(object2, new String[]{"document_id"}, null, null, null);
            while (true) {
                uriArray = object;
                documentFileArray = object;
                if (!object.moveToNext()) break;
                uriArray = object;
                documentFileArray = object;
                object2 = object.getString(0);
                uriArray = object;
                documentFileArray = object;
                arrayList.add(DocumentsContract.buildDocumentUriUsingTree((Uri)this.mUri, (String)object2));
            }
            documentFileArray = object;
            {
                catch (Throwable throwable2) {
                    break block7;
                }
                catch (Exception exception) {}
                uriArray = documentFileArray;
                {
                    uriArray = documentFileArray;
                    object = new StringBuilder();
                    uriArray = documentFileArray;
                    ((StringBuilder)object).append("Failed query: ");
                    uriArray = documentFileArray;
                    ((StringBuilder)object).append(exception);
                    uriArray = documentFileArray;
                    Log.w((String)"DocumentFile", (String)((StringBuilder)object).toString());
                }
            }
            TreeDocumentFile.closeQuietly((AutoCloseable)documentFileArray);
            uriArray = arrayList.toArray(new Uri[arrayList.size()]);
            documentFileArray = new DocumentFile[uriArray.length];
            int n = 0;
            while (true) {
                if (n >= uriArray.length) {
                    return documentFileArray;
                }
                documentFileArray[n] = new TreeDocumentFile(this, this.mContext, uriArray[n]);
                ++n;
            }
        }
        TreeDocumentFile.closeQuietly((AutoCloseable)uriArray);
        throw throwable2;
    }

    @Override
    public boolean renameTo(String string2) {
        block3: {
            try {
                string2 = DocumentsContract.renameDocument((ContentResolver)this.mContext.getContentResolver(), (Uri)this.mUri, (String)string2);
                if (string2 == null) break block3;
            }
            catch (Exception exception) {
                return false;
            }
            this.mUri = string2;
            return true;
        }
        return false;
    }
}

