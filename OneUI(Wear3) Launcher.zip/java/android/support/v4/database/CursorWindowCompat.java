/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.database.CursorWindow
 *  android.os.Build$VERSION
 */
package android.support.v4.database;

import android.database.CursorWindow;
import android.os.Build;
import android.support.v4.os.BuildCompat;

public final class CursorWindowCompat {
    private CursorWindowCompat() {
    }

    public CursorWindow create(String string2, long l) {
        if (BuildCompat.isAtLeastP()) {
            return new CursorWindow(string2, l);
        }
        if (Build.VERSION.SDK_INT >= 15) {
            return new CursorWindow(string2);
        }
        return new CursorWindow(false);
    }
}

