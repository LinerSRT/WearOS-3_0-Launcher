/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.database.sqlite.SQLiteCursor
 */
package android.support.v4.database.sqlite;

import android.database.sqlite.SQLiteCursor;
import android.support.v4.os.BuildCompat;

public final class SQLiteCursorCompat {
    private SQLiteCursorCompat() {
    }

    public void setFillWindowForwardOnly(SQLiteCursor sQLiteCursor, boolean bl) {
        if (BuildCompat.isAtLeastP()) {
            sQLiteCursor.setFillWindowForwardOnly(bl);
        }
    }
}

