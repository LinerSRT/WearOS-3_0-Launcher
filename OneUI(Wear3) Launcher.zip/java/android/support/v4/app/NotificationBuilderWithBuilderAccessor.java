/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Notification$Builder
 */
package android.support.v4.app;

import android.app.Notification;

public interface NotificationBuilderWithBuilderAccessor {
    public Notification.Builder getBuilder();
}

