/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$Builder
 *  android.app.PendingIntent
 *  android.app.RemoteInput
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.text.TextUtils
 *  android.util.SparseArray
 *  android.widget.RemoteViews
 */
package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationBuilderWithBuilderAccessor;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationCompatJellybean;
import android.support.v4.app.RemoteInput;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.List;

class NotificationCompatBuilder
implements NotificationBuilderWithBuilderAccessor {
    private final List<Bundle> mActionExtrasList = new ArrayList<Bundle>();
    private RemoteViews mBigContentView;
    private final Notification.Builder mBuilder;
    private final NotificationCompat.Builder mBuilderCompat;
    private RemoteViews mContentView;
    private final Bundle mExtras = new Bundle();
    private int mGroupAlertBehavior;
    private RemoteViews mHeadsUpContentView;

    /*
     * WARNING - void declaration
     */
    NotificationCompatBuilder(NotificationCompat.Builder builder) {
        this.mBuilderCompat = builder;
        this.mBuilder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(builder.mContext, builder.mChannelId) : new Notification.Builder(builder.mContext);
        Notification object3 = builder.mNotification;
        Object object = this.mBuilder.setWhen(object3.when).setSmallIcon(object3.icon, object3.iconLevel).setContent(object3.contentView).setTicker(object3.tickerText, builder.mTickerView).setVibrate(object3.vibrate).setLights(object3.ledARGB, object3.ledOnMS, object3.ledOffMS);
        boolean bl = (object3.flags & 2) != 0;
        object = object.setOngoing(bl);
        bl = (object3.flags & 8) != 0;
        object = object.setOnlyAlertOnce(bl);
        bl = (object3.flags & 0x10) != 0;
        Notification.Builder builder2 = object.setAutoCancel(bl).setDefaults(object3.defaults).setContentTitle(builder.mContentTitle).setContentText(builder.mContentText).setContentInfo(builder.mContentInfo).setContentIntent(builder.mContentIntent).setDeleteIntent(object3.deleteIntent);
        object = builder.mFullScreenIntent;
        bl = (object3.flags & 0x80) != 0;
        builder2.setFullScreenIntent((PendingIntent)object, bl).setLargeIcon(builder.mLargeIcon).setNumber(builder.mNumber).setProgress(builder.mProgressMax, builder.mProgress, builder.mProgressIndeterminate);
        if (Build.VERSION.SDK_INT < 21) {
            this.mBuilder.setSound(object3.sound, object3.audioStreamType);
        }
        if (Build.VERSION.SDK_INT >= 16) {
            this.mBuilder.setSubText(builder.mSubText).setUsesChronometer(builder.mUseChronometer).setPriority(builder.mPriority);
            object = builder.mActions.iterator();
            while (object.hasNext()) {
                this.addAction((NotificationCompat.Action)object.next());
            }
            if (builder.mExtras != null) {
                this.mExtras.putAll(builder.mExtras);
            }
            if (Build.VERSION.SDK_INT < 20) {
                if (builder.mLocalOnly) {
                    this.mExtras.putBoolean("android.support.localOnly", true);
                }
                if (builder.mGroupKey != null) {
                    this.mExtras.putString("android.support.groupKey", builder.mGroupKey);
                    if (builder.mGroupSummary) {
                        this.mExtras.putBoolean("android.support.isGroupSummary", true);
                    } else {
                        this.mExtras.putBoolean("android.support.useSideChannel", true);
                    }
                }
                if (builder.mSortKey != null) {
                    this.mExtras.putString("android.support.sortKey", builder.mSortKey);
                }
            }
            this.mContentView = builder.mContentView;
            this.mBigContentView = builder.mBigContentView;
        }
        if (Build.VERSION.SDK_INT >= 19) {
            this.mBuilder.setShowWhen(builder.mShowWhen);
            if (Build.VERSION.SDK_INT < 21 && builder.mPeople != null && !builder.mPeople.isEmpty()) {
                this.mExtras.putStringArray("android.people", builder.mPeople.toArray(new String[builder.mPeople.size()]));
            }
        }
        if (Build.VERSION.SDK_INT >= 20) {
            this.mBuilder.setLocalOnly(builder.mLocalOnly).setGroup(builder.mGroupKey).setGroupSummary(builder.mGroupSummary).setSortKey(builder.mSortKey);
            this.mGroupAlertBehavior = builder.mGroupAlertBehavior;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            this.mBuilder.setCategory(builder.mCategory).setColor(builder.mColor).setVisibility(builder.mVisibility).setPublicVersion(builder.mPublicVersion).setSound(object3.sound, object3.audioAttributes);
            object = builder.mPeople.iterator();
            while (object.hasNext()) {
                String string2 = (String)object.next();
                this.mBuilder.addPerson(string2);
            }
            this.mHeadsUpContentView = builder.mHeadsUpContentView;
            if (builder.mInvisibleActions.size() > 0) {
                void var2_7;
                Object object2 = object = builder.getExtras().getBundle("android.car.EXTENSIONS");
                if (object == null) {
                    Bundle bundle = new Bundle();
                }
                object = new Bundle();
                for (int i = 0; i < builder.mInvisibleActions.size(); ++i) {
                    object.putBundle(Integer.toString(i), NotificationCompatJellybean.getBundleForAction(builder.mInvisibleActions.get(i)));
                }
                var2_7.putBundle("invisible_actions", (Bundle)object);
                builder.getExtras().putBundle("android.car.EXTENSIONS", (Bundle)var2_7);
                this.mExtras.putBundle("android.car.EXTENSIONS", (Bundle)var2_7);
            }
        }
        if (Build.VERSION.SDK_INT >= 24) {
            this.mBuilder.setExtras(builder.mExtras).setRemoteInputHistory(builder.mRemoteInputHistory);
            if (builder.mContentView != null) {
                this.mBuilder.setCustomContentView(builder.mContentView);
            }
            if (builder.mBigContentView != null) {
                this.mBuilder.setCustomBigContentView(builder.mBigContentView);
            }
            if (builder.mHeadsUpContentView != null) {
                this.mBuilder.setCustomHeadsUpContentView(builder.mHeadsUpContentView);
            }
        }
        if (Build.VERSION.SDK_INT >= 26) {
            this.mBuilder.setBadgeIconType(builder.mBadgeIcon).setShortcutId(builder.mShortcutId).setTimeoutAfter(builder.mTimeout).setGroupAlertBehavior(builder.mGroupAlertBehavior);
            if (builder.mColorizedSet) {
                this.mBuilder.setColorized(builder.mColorized);
            }
            if (!TextUtils.isEmpty((CharSequence)builder.mChannelId)) {
                this.mBuilder.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null);
            }
        }
    }

    private void addAction(NotificationCompat.Action action) {
        block5: {
            block4: {
                Bundle bundle;
                if (Build.VERSION.SDK_INT < 20) break block4;
                Notification.Action.Builder builder = new Notification.Action.Builder(action.getIcon(), action.getTitle(), action.getActionIntent());
                if (action.getRemoteInputs() != null) {
                    bundle = RemoteInput.fromCompat(action.getRemoteInputs());
                    int n = ((android.app.RemoteInput[])bundle).length;
                    for (int i = 0; i < n; ++i) {
                        builder.addRemoteInput((android.app.RemoteInput)bundle[i]);
                    }
                }
                bundle = action.getExtras() != null ? new Bundle(action.getExtras()) : new Bundle();
                bundle.putBoolean("android.support.allowGeneratedReplies", action.getAllowGeneratedReplies());
                if (Build.VERSION.SDK_INT >= 24) {
                    builder.setAllowGeneratedReplies(action.getAllowGeneratedReplies());
                }
                bundle.putInt("android.support.action.semanticAction", action.getSemanticAction());
                if (Build.VERSION.SDK_INT >= 28) {
                    builder.setSemanticAction(action.getSemanticAction());
                }
                bundle.putBoolean("android.support.action.showsUserInterface", action.getShowsUserInterface());
                builder.addExtras(bundle);
                this.mBuilder.addAction(builder.build());
                break block5;
            }
            if (Build.VERSION.SDK_INT < 16) break block5;
            this.mActionExtrasList.add(NotificationCompatJellybean.writeActionAndGetExtras(this.mBuilder, action));
        }
    }

    private void removeSoundAndVibration(Notification notification) {
        notification.sound = null;
        notification.vibrate = null;
        notification.defaults &= 0xFFFFFFFE;
        notification.defaults &= 0xFFFFFFFD;
    }

    public Notification build() {
        NotificationCompat.Style style2 = this.mBuilderCompat.mStyle;
        if (style2 != null) {
            style2.apply(this);
        }
        RemoteViews remoteViews = style2 != null ? style2.makeContentView(this) : null;
        Notification notification = this.buildInternal();
        if (remoteViews != null) {
            notification.contentView = remoteViews;
        } else if (this.mBuilderCompat.mContentView != null) {
            notification.contentView = this.mBuilderCompat.mContentView;
        }
        if (Build.VERSION.SDK_INT >= 16 && style2 != null && (remoteViews = style2.makeBigContentView(this)) != null) {
            notification.bigContentView = remoteViews;
        }
        if (Build.VERSION.SDK_INT >= 21 && style2 != null && (remoteViews = this.mBuilderCompat.mStyle.makeHeadsUpContentView(this)) != null) {
            notification.headsUpContentView = remoteViews;
        }
        if (Build.VERSION.SDK_INT >= 16 && style2 != null && (remoteViews = NotificationCompat.getExtras(notification)) != null) {
            style2.addCompatExtras((Bundle)remoteViews);
        }
        return notification;
    }

    protected Notification buildInternal() {
        if (Build.VERSION.SDK_INT >= 26) {
            return this.mBuilder.build();
        }
        if (Build.VERSION.SDK_INT >= 24) {
            Notification notification = this.mBuilder.build();
            if (this.mGroupAlertBehavior != 0) {
                if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.mGroupAlertBehavior == 2) {
                    this.removeSoundAndVibration(notification);
                }
                if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.mGroupAlertBehavior == 1) {
                    this.removeSoundAndVibration(notification);
                }
            }
            return notification;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            this.mBuilder.setExtras(this.mExtras);
            Notification notification = this.mBuilder.build();
            RemoteViews remoteViews = this.mContentView;
            if (remoteViews != null) {
                notification.contentView = remoteViews;
            }
            if ((remoteViews = this.mBigContentView) != null) {
                notification.bigContentView = remoteViews;
            }
            if ((remoteViews = this.mHeadsUpContentView) != null) {
                notification.headsUpContentView = remoteViews;
            }
            if (this.mGroupAlertBehavior != 0) {
                if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.mGroupAlertBehavior == 2) {
                    this.removeSoundAndVibration(notification);
                }
                if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.mGroupAlertBehavior == 1) {
                    this.removeSoundAndVibration(notification);
                }
            }
            return notification;
        }
        if (Build.VERSION.SDK_INT >= 20) {
            this.mBuilder.setExtras(this.mExtras);
            Notification notification = this.mBuilder.build();
            RemoteViews remoteViews = this.mContentView;
            if (remoteViews != null) {
                notification.contentView = remoteViews;
            }
            if ((remoteViews = this.mBigContentView) != null) {
                notification.bigContentView = remoteViews;
            }
            if (this.mGroupAlertBehavior != 0) {
                if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.mGroupAlertBehavior == 2) {
                    this.removeSoundAndVibration(notification);
                }
                if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.mGroupAlertBehavior == 1) {
                    this.removeSoundAndVibration(notification);
                }
            }
            return notification;
        }
        if (Build.VERSION.SDK_INT >= 19) {
            Notification notification = NotificationCompatJellybean.buildActionExtrasMap(this.mActionExtrasList);
            if (notification != null) {
                this.mExtras.putSparseParcelableArray("android.support.actionExtras", notification);
            }
            this.mBuilder.setExtras(this.mExtras);
            notification = this.mBuilder.build();
            RemoteViews remoteViews = this.mContentView;
            if (remoteViews != null) {
                notification.contentView = remoteViews;
            }
            if ((remoteViews = this.mBigContentView) != null) {
                notification.bigContentView = remoteViews;
            }
            return notification;
        }
        if (Build.VERSION.SDK_INT >= 16) {
            RemoteViews remoteViews2;
            Notification notification = this.mBuilder.build();
            Bundle bundle = NotificationCompat.getExtras(notification);
            Bundle bundle2 = new Bundle(this.mExtras);
            for (RemoteViews remoteViews2 : this.mExtras.keySet()) {
                if (!bundle.containsKey((String)remoteViews2)) continue;
                bundle2.remove(remoteViews2);
            }
            bundle.putAll(bundle2);
            remoteViews2 = NotificationCompatJellybean.buildActionExtrasMap(this.mActionExtrasList);
            if (remoteViews2 != null) {
                NotificationCompat.getExtras(notification).putSparseParcelableArray("android.support.actionExtras", (SparseArray)remoteViews2);
            }
            if ((remoteViews2 = this.mContentView) != null) {
                notification.contentView = remoteViews2;
            }
            if ((remoteViews2 = this.mBigContentView) != null) {
                notification.bigContentView = remoteViews2;
            }
            return notification;
        }
        return this.mBuilder.getNotification();
    }

    @Override
    public Notification.Builder getBuilder() {
        return this.mBuilder;
    }
}

