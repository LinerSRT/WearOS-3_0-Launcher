/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.graphics.Rect
 *  android.os.Build$VERSION
 *  android.util.SparseArray
 *  android.view.View
 *  android.view.ViewGroup
 */
package android.support.v4.app;

import android.graphics.Rect;
import android.os.Build;
import android.support.v4.app.BackStackRecord;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManagerImpl;
import android.support.v4.app.FragmentTransitionCompat21;
import android.support.v4.app.FragmentTransitionImpl;
import android.support.v4.app.OneShotPreDrawListener;
import android.support.v4.app.SharedElementCallback;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.SimpleArrayMap;
import android.support.v4.view.ViewCompat;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class FragmentTransition {
    private static final int[] INVERSE_OPS = new int[]{0, 3, 0, 1, 5, 4, 7, 6, 9, 8};
    private static final FragmentTransitionImpl PLATFORM_IMPL;
    private static final FragmentTransitionImpl SUPPORT_IMPL;

    static {
        FragmentTransitionCompat21 fragmentTransitionCompat21 = Build.VERSION.SDK_INT >= 21 ? new FragmentTransitionCompat21() : null;
        PLATFORM_IMPL = fragmentTransitionCompat21;
        SUPPORT_IMPL = FragmentTransition.resolveSupportImpl();
    }

    private FragmentTransition() {
    }

    private static void addSharedElementsWithMatchingNames(ArrayList<View> arrayList, ArrayMap<String, View> arrayMap, Collection<String> collection) {
        for (int i = arrayMap.size() - 1; i >= 0; --i) {
            View view = (View)arrayMap.valueAt(i);
            if (!collection.contains(ViewCompat.getTransitionName(view))) continue;
            arrayList.add(view);
        }
    }

    private static void addToFirstInLastOut(BackStackRecord backStackRecord, BackStackRecord.Op object, SparseArray<FragmentContainerTransition> sparseArray, boolean bl, boolean bl2) {
        Object object2;
        boolean bl3;
        int n;
        int n2;
        int n3;
        int n4;
        Fragment fragment;
        block32: {
            boolean bl4;
            block28: {
                int n5;
                int n6;
                block29: {
                    block30: {
                        boolean bl5;
                        block31: {
                            fragment = ((BackStackRecord.Op)object).fragment;
                            if (fragment == null) {
                                return;
                            }
                            n4 = fragment.mContainerId;
                            if (n4 == 0) {
                                return;
                            }
                            n3 = bl ? INVERSE_OPS[((BackStackRecord.Op)object).cmd] : ((BackStackRecord.Op)object).cmd;
                            n2 = 0;
                            n = 0;
                            n6 = 0;
                            n5 = 0;
                            bl4 = false;
                            bl5 = false;
                            if (n3 == 1) break block28;
                            if (n3 == 3) break block29;
                            if (n3 == 4) break block30;
                            if (n3 == 5) break block31;
                            if (n3 == 6) break block29;
                            if (n3 == 7) break block28;
                            bl3 = false;
                            n3 = 0;
                            n2 = 0;
                            n = 0;
                            break block32;
                        }
                        if (bl2) {
                            bl3 = bl5;
                            if (fragment.mHiddenChanged) {
                                bl3 = bl5;
                                if (!fragment.mHidden) {
                                    bl3 = bl5;
                                    if (fragment.mAdded) {
                                        bl3 = true;
                                    }
                                }
                            }
                        } else {
                            bl3 = fragment.mHidden;
                        }
                        n3 = 0;
                        n2 = 0;
                        n = 1;
                        break block32;
                    }
                    if (bl2) {
                        n3 = n2;
                        if (fragment.mHiddenChanged) {
                            n3 = n2;
                            if (fragment.mAdded) {
                                n3 = n2;
                                if (fragment.mHidden) {
                                    n3 = 1;
                                }
                            }
                        }
                    } else {
                        n3 = n;
                        if (fragment.mAdded) {
                            n3 = n;
                            if (!fragment.mHidden) {
                                n3 = 1;
                            }
                        }
                    }
                    bl3 = false;
                    n5 = 1;
                    n2 = n3;
                    n = 0;
                    n3 = n5;
                    break block32;
                }
                if (bl2) {
                    n3 = !fragment.mAdded && fragment.mView != null && fragment.mView.getVisibility() == 0 && fragment.mPostponedAlpha >= 0.0f ? 1 : n6;
                } else {
                    n3 = n5;
                    if (fragment.mAdded) {
                        n3 = n5;
                        if (!fragment.mHidden) {
                            n3 = 1;
                        }
                    }
                }
                bl3 = false;
                n5 = 1;
                n2 = n3;
                n = 0;
                n3 = n5;
                break block32;
            }
            if (bl2) {
                bl3 = fragment.mIsNewlyAdded;
            } else {
                bl3 = bl4;
                if (!fragment.mAdded) {
                    bl3 = bl4;
                    if (!fragment.mHidden) {
                        bl3 = true;
                    }
                }
            }
            n3 = 0;
            n2 = 0;
            n = 1;
        }
        object = (FragmentContainerTransition)sparseArray.get(n4);
        if (bl3) {
            object = FragmentTransition.ensureContainer((FragmentContainerTransition)object, sparseArray, n4);
            ((FragmentContainerTransition)object).lastIn = fragment;
            ((FragmentContainerTransition)object).lastInIsPop = bl;
            ((FragmentContainerTransition)object).lastInTransaction = backStackRecord;
        }
        if (!bl2 && n != 0) {
            if (object != null && ((FragmentContainerTransition)object).firstOut == fragment) {
                ((FragmentContainerTransition)object).firstOut = null;
            }
            object2 = backStackRecord.mManager;
            if (fragment.mState < 1 && ((FragmentManagerImpl)object2).mCurState >= 1 && !backStackRecord.mReorderingAllowed) {
                ((FragmentManagerImpl)object2).makeActive(fragment);
                ((FragmentManagerImpl)object2).moveToState(fragment, 1, 0, 0, false);
            }
        }
        if (n2 != 0 && ((object2 = object) == null || ((FragmentContainerTransition)object2).firstOut == null)) {
            object = FragmentTransition.ensureContainer((FragmentContainerTransition)object2, sparseArray, n4);
            ((FragmentContainerTransition)object).firstOut = fragment;
            ((FragmentContainerTransition)object).firstOutIsPop = bl;
            ((FragmentContainerTransition)object).firstOutTransaction = backStackRecord;
        }
        if (!bl2 && n3 != 0 && object != null && ((FragmentContainerTransition)object).lastIn == fragment) {
            ((FragmentContainerTransition)object).lastIn = null;
        }
    }

    public static void calculateFragments(BackStackRecord backStackRecord, SparseArray<FragmentContainerTransition> sparseArray, boolean bl) {
        int n = backStackRecord.mOps.size();
        for (int i = 0; i < n; ++i) {
            FragmentTransition.addToFirstInLastOut(backStackRecord, backStackRecord.mOps.get(i), sparseArray, false, bl);
        }
    }

    private static ArrayMap<String, String> calculateNameOverrides(int n, ArrayList<BackStackRecord> arrayList, ArrayList<Boolean> arrayList2, int n2, int n3) {
        ArrayMap<String, String> arrayMap = new ArrayMap<String, String>();
        --n3;
        while (n3 >= n2) {
            Object object = arrayList.get(n3);
            if (((BackStackRecord)object).interactsWith(n)) {
                boolean bl = arrayList2.get(n3);
                if (((BackStackRecord)object).mSharedElementSourceNames != null) {
                    ArrayList<String> arrayList3;
                    ArrayList<String> arrayList4;
                    int n4 = ((BackStackRecord)object).mSharedElementSourceNames.size();
                    if (bl) {
                        arrayList4 = ((BackStackRecord)object).mSharedElementSourceNames;
                        arrayList3 = ((BackStackRecord)object).mSharedElementTargetNames;
                    } else {
                        arrayList3 = ((BackStackRecord)object).mSharedElementSourceNames;
                        arrayList4 = ((BackStackRecord)object).mSharedElementTargetNames;
                    }
                    for (int i = 0; i < n4; ++i) {
                        object = arrayList3.get(i);
                        String string2 = arrayList4.get(i);
                        String string3 = (String)arrayMap.remove(string2);
                        if (string3 != null) {
                            arrayMap.put((String)object, string3);
                            continue;
                        }
                        arrayMap.put((String)object, string2);
                    }
                }
            }
            --n3;
        }
        return arrayMap;
    }

    public static void calculatePopFragments(BackStackRecord backStackRecord, SparseArray<FragmentContainerTransition> sparseArray, boolean bl) {
        if (!backStackRecord.mManager.mContainer.onHasView()) {
            return;
        }
        for (int i = backStackRecord.mOps.size() - 1; i >= 0; --i) {
            FragmentTransition.addToFirstInLastOut(backStackRecord, backStackRecord.mOps.get(i), sparseArray, true, bl);
        }
    }

    private static void callSharedElementStartEnd(Fragment object, Fragment object2, boolean bl, ArrayMap<String, View> arrayMap, boolean bl2) {
        object = bl ? ((Fragment)object2).getEnterTransitionCallback() : ((Fragment)object).getEnterTransitionCallback();
        if (object != null) {
            ArrayList<View> arrayList = new ArrayList<View>();
            object2 = new ArrayList();
            int n = arrayMap == null ? 0 : arrayMap.size();
            for (int i = 0; i < n; ++i) {
                ((ArrayList)object2).add(arrayMap.keyAt(i));
                arrayList.add((View)arrayMap.valueAt(i));
            }
            if (bl2) {
                ((SharedElementCallback)object).onSharedElementStart((List<String>)object2, arrayList, null);
            } else {
                ((SharedElementCallback)object).onSharedElementEnd((List<String>)object2, arrayList, null);
            }
        }
    }

    private static boolean canHandleAll(FragmentTransitionImpl fragmentTransitionImpl, List<Object> list) {
        int n = list.size();
        for (int i = 0; i < n; ++i) {
            if (fragmentTransitionImpl.canHandle(list.get(i))) continue;
            return false;
        }
        return true;
    }

    private static ArrayMap<String, View> captureInSharedElements(FragmentTransitionImpl arrayList, ArrayMap<String, String> arrayMap, Object object, FragmentContainerTransition object2) {
        Fragment fragment = ((FragmentContainerTransition)object2).lastIn;
        View view = fragment.getView();
        if (!arrayMap.isEmpty() && object != null && view != null) {
            ArrayMap<String, View> arrayMap2 = new ArrayMap<String, View>();
            ((FragmentTransitionImpl)((Object)arrayList)).findNamedViews(arrayMap2, view);
            arrayList = ((FragmentContainerTransition)object2).lastInTransaction;
            if (((FragmentContainerTransition)object2).lastInIsPop) {
                object = fragment.getExitTransitionCallback();
                arrayList = ((BackStackRecord)arrayList).mSharedElementSourceNames;
            } else {
                object = fragment.getEnterTransitionCallback();
                arrayList = ((BackStackRecord)arrayList).mSharedElementTargetNames;
            }
            if (arrayList != null) {
                arrayMap2.retainAll(arrayList);
                arrayMap2.retainAll(arrayMap.values());
            }
            if (object != null) {
                ((SharedElementCallback)object).onMapSharedElements(arrayList, arrayMap2);
                for (int i = arrayList.size() - 1; i >= 0; --i) {
                    object2 = arrayList.get(i);
                    object = (View)arrayMap2.get(object2);
                    if (object == null) {
                        object = FragmentTransition.findKeyForValue(arrayMap, (String)object2);
                        if (object == null) continue;
                        arrayMap.remove(object);
                        continue;
                    }
                    if (((String)object2).equals(ViewCompat.getTransitionName((View)object)) || (object2 = FragmentTransition.findKeyForValue(arrayMap, (String)object2)) == null) continue;
                    arrayMap.put((String)object2, ViewCompat.getTransitionName((View)object));
                }
            } else {
                FragmentTransition.retainValues(arrayMap, arrayMap2);
            }
            return arrayMap2;
        }
        arrayMap.clear();
        return null;
    }

    private static ArrayMap<String, View> captureOutSharedElements(FragmentTransitionImpl arrayList, ArrayMap<String, String> arrayMap, Object object, FragmentContainerTransition object2) {
        if (!arrayMap.isEmpty() && object != null) {
            object = ((FragmentContainerTransition)object2).firstOut;
            ArrayMap<String, View> arrayMap2 = new ArrayMap<String, View>();
            ((FragmentTransitionImpl)((Object)arrayList)).findNamedViews(arrayMap2, ((Fragment)object).getView());
            arrayList = ((FragmentContainerTransition)object2).firstOutTransaction;
            if (((FragmentContainerTransition)object2).firstOutIsPop) {
                object = ((Fragment)object).getEnterTransitionCallback();
                arrayList = ((BackStackRecord)arrayList).mSharedElementTargetNames;
            } else {
                object = ((Fragment)object).getExitTransitionCallback();
                arrayList = ((BackStackRecord)arrayList).mSharedElementSourceNames;
            }
            arrayMap2.retainAll(arrayList);
            if (object != null) {
                ((SharedElementCallback)object).onMapSharedElements(arrayList, arrayMap2);
                for (int i = arrayList.size() - 1; i >= 0; --i) {
                    object2 = arrayList.get(i);
                    object = (View)arrayMap2.get(object2);
                    if (object == null) {
                        arrayMap.remove(object2);
                        continue;
                    }
                    if (((String)object2).equals(ViewCompat.getTransitionName((View)object))) continue;
                    object2 = (String)arrayMap.remove(object2);
                    arrayMap.put(ViewCompat.getTransitionName((View)object), (String)object2);
                }
            } else {
                arrayMap.retainAll(arrayMap2.keySet());
            }
            return arrayMap2;
        }
        arrayMap.clear();
        return null;
    }

    private static FragmentTransitionImpl chooseImpl(Fragment object, Fragment fragment) {
        ArrayList<Object> arrayList = new ArrayList<Object>();
        if (object != null) {
            Object object2 = ((Fragment)object).getExitTransition();
            if (object2 != null) {
                arrayList.add(object2);
            }
            if ((object2 = ((Fragment)object).getReturnTransition()) != null) {
                arrayList.add(object2);
            }
            if ((object = ((Fragment)object).getSharedElementReturnTransition()) != null) {
                arrayList.add(object);
            }
        }
        if (fragment != null) {
            object = fragment.getEnterTransition();
            if (object != null) {
                arrayList.add(object);
            }
            if ((object = fragment.getReenterTransition()) != null) {
                arrayList.add(object);
            }
            if ((object = fragment.getSharedElementEnterTransition()) != null) {
                arrayList.add(object);
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        object = PLATFORM_IMPL;
        if (object != null && FragmentTransition.canHandleAll((FragmentTransitionImpl)object, arrayList)) {
            return PLATFORM_IMPL;
        }
        object = SUPPORT_IMPL;
        if (object != null && FragmentTransition.canHandleAll((FragmentTransitionImpl)object, arrayList)) {
            return SUPPORT_IMPL;
        }
        if (PLATFORM_IMPL == null && SUPPORT_IMPL == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    private static ArrayList<View> configureEnteringExitingViews(FragmentTransitionImpl fragmentTransitionImpl, Object object, Fragment fragment, ArrayList<View> arrayList, View view) {
        ArrayList<View> arrayList2 = null;
        if (object != null) {
            ArrayList<View> arrayList3 = new ArrayList<View>();
            if ((fragment = fragment.getView()) != null) {
                fragmentTransitionImpl.captureTransitioningViews(arrayList3, (View)fragment);
            }
            if (arrayList != null) {
                arrayList3.removeAll(arrayList);
            }
            arrayList2 = arrayList3;
            if (!arrayList3.isEmpty()) {
                arrayList3.add(view);
                fragmentTransitionImpl.addTargets(object, arrayList3);
                arrayList2 = arrayList3;
            }
        }
        return arrayList2;
    }

    private static Object configureSharedElementsOrdered(final FragmentTransitionImpl fragmentTransitionImpl, ViewGroup viewGroup, final View view, final ArrayMap<String, String> arrayMap, final FragmentContainerTransition fragmentContainerTransition, final ArrayList<View> arrayList, final ArrayList<View> arrayList2, final Object object, Object object2) {
        final Fragment fragment = fragmentContainerTransition.lastIn;
        final Fragment fragment2 = fragmentContainerTransition.firstOut;
        if (fragment != null && fragment2 != null) {
            final boolean bl = fragmentContainerTransition.lastInIsPop;
            final Object object3 = arrayMap.isEmpty() ? null : FragmentTransition.getSharedElementTransition(fragmentTransitionImpl, fragment, fragment2, bl);
            ArrayMap<String, View> arrayMap2 = FragmentTransition.captureOutSharedElements(fragmentTransitionImpl, arrayMap, object3, fragmentContainerTransition);
            if (arrayMap.isEmpty()) {
                object3 = null;
            } else {
                arrayList.addAll(arrayMap2.values());
            }
            if (object == null && object2 == null && object3 == null) {
                return null;
            }
            FragmentTransition.callSharedElementStartEnd(fragment, fragment2, bl, arrayMap2, true);
            if (object3 != null) {
                Rect rect = new Rect();
                fragmentTransitionImpl.setSharedElementTargets(object3, view, arrayList);
                FragmentTransition.setOutEpicenter(fragmentTransitionImpl, object3, object2, arrayMap2, fragmentContainerTransition.firstOutIsPop, fragmentContainerTransition.firstOutTransaction);
                if (object != null) {
                    fragmentTransitionImpl.setEpicenter(object, rect);
                }
                object2 = rect;
            } else {
                object2 = null;
            }
            OneShotPreDrawListener.add((View)viewGroup, new Runnable((Rect)object2){
                final /* synthetic */ Rect val$inEpicenter;
                {
                    this.val$inEpicenter = rect;
                }

                @Override
                public void run() {
                    ArrayMap arrayMap2 = FragmentTransition.captureInSharedElements(fragmentTransitionImpl, arrayMap, object3, fragmentContainerTransition);
                    if (arrayMap2 != null) {
                        arrayList2.addAll(arrayMap2.values());
                        arrayList2.add(view);
                    }
                    FragmentTransition.callSharedElementStartEnd(fragment, fragment2, bl, arrayMap2, false);
                    Object object2 = object3;
                    if (object2 != null) {
                        fragmentTransitionImpl.swapSharedElementTargets(object2, arrayList, arrayList2);
                        object2 = FragmentTransition.getInEpicenterView(arrayMap2, fragmentContainerTransition, object, bl);
                        if (object2 != null) {
                            fragmentTransitionImpl.getBoundsOnScreen((View)object2, this.val$inEpicenter);
                        }
                    }
                }
            });
            return object3;
        }
        return null;
    }

    private static Object configureSharedElementsReordered(FragmentTransitionImpl fragmentTransitionImpl, ViewGroup viewGroup, View view, ArrayMap<String, String> object, FragmentContainerTransition fragmentContainerTransition, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object object2, Object object3) {
        final Fragment fragment = fragmentContainerTransition.lastIn;
        final Fragment fragment2 = fragmentContainerTransition.firstOut;
        if (fragment != null) {
            fragment.getView().setVisibility(0);
        }
        if (fragment != null && fragment2 != null) {
            final boolean bl = fragmentContainerTransition.lastInIsPop;
            Object object4 = ((SimpleArrayMap)object).isEmpty() ? null : FragmentTransition.getSharedElementTransition(fragmentTransitionImpl, fragment, fragment2, bl);
            ArrayMap<String, View> arrayMap = FragmentTransition.captureOutSharedElements(fragmentTransitionImpl, object, object4, fragmentContainerTransition);
            final ArrayMap<String, View> arrayMap2 = FragmentTransition.captureInSharedElements(fragmentTransitionImpl, object, object4, fragmentContainerTransition);
            if (((SimpleArrayMap)object).isEmpty()) {
                if (arrayMap != null) {
                    arrayMap.clear();
                }
                if (arrayMap2 != null) {
                    arrayMap2.clear();
                }
                object = null;
            } else {
                FragmentTransition.addSharedElementsWithMatchingNames(arrayList, arrayMap, ((ArrayMap)object).keySet());
                FragmentTransition.addSharedElementsWithMatchingNames(arrayList2, arrayMap2, ((ArrayMap)object).values());
                object = object4;
            }
            if (object2 == null && object3 == null && object == null) {
                return null;
            }
            FragmentTransition.callSharedElementStartEnd(fragment, fragment2, bl, arrayMap, true);
            if (object != null) {
                arrayList2.add(view);
                fragmentTransitionImpl.setSharedElementTargets(object, view, arrayList);
                FragmentTransition.setOutEpicenter(fragmentTransitionImpl, object, object3, arrayMap, fragmentContainerTransition.firstOutIsPop, fragmentContainerTransition.firstOutTransaction);
                view = new Rect();
                fragmentContainerTransition = FragmentTransition.getInEpicenterView(arrayMap2, fragmentContainerTransition, object2, bl);
                if (fragmentContainerTransition != null) {
                    fragmentTransitionImpl.setEpicenter(object2, (Rect)view);
                }
            } else {
                view = null;
                fragmentContainerTransition = null;
            }
            OneShotPreDrawListener.add((View)viewGroup, new Runnable((View)fragmentContainerTransition, fragmentTransitionImpl, (Rect)view){
                final /* synthetic */ Rect val$epicenter;
                final /* synthetic */ View val$epicenterView;
                final /* synthetic */ FragmentTransitionImpl val$impl;
                {
                    this.val$epicenterView = view;
                    this.val$impl = fragmentTransitionImpl;
                    this.val$epicenter = rect;
                }

                @Override
                public void run() {
                    FragmentTransition.callSharedElementStartEnd(fragment, fragment2, bl, arrayMap2, false);
                    View view = this.val$epicenterView;
                    if (view != null) {
                        this.val$impl.getBoundsOnScreen(view, this.val$epicenter);
                    }
                }
            });
            return object;
        }
        return null;
    }

    private static void configureTransitionsOrdered(FragmentManagerImpl fragmentManagerImpl, int n, FragmentContainerTransition object, View view, ArrayMap<String, String> arrayMap) {
        block4: {
            fragmentManagerImpl = fragmentManagerImpl.mContainer.onHasView() ? (ViewGroup)fragmentManagerImpl.mContainer.onFindViewById(n) : null;
            if (fragmentManagerImpl == null) {
                return;
            }
            Object object2 = ((FragmentContainerTransition)object).firstOut;
            Fragment fragment = ((FragmentContainerTransition)object).lastIn;
            FragmentTransitionImpl fragmentTransitionImpl = FragmentTransition.chooseImpl((Fragment)object2, fragment);
            if (fragmentTransitionImpl == null) {
                return;
            }
            boolean bl = ((FragmentContainerTransition)object).lastInIsPop;
            boolean bl2 = ((FragmentContainerTransition)object).firstOutIsPop;
            Object object3 = FragmentTransition.getEnterTransition(fragmentTransitionImpl, fragment, bl);
            Object object4 = FragmentTransition.getExitTransition(fragmentTransitionImpl, (Fragment)object2, bl2);
            ArrayList<View> arrayList = new ArrayList<View>();
            ArrayList<View> arrayList2 = new ArrayList<View>();
            Object object5 = FragmentTransition.configureSharedElementsOrdered(fragmentTransitionImpl, (ViewGroup)fragmentManagerImpl, view, arrayMap, (FragmentContainerTransition)object, arrayList, arrayList2, object3, object4);
            if (object3 == null && object5 == null && object4 == null) {
                return;
            }
            if ((arrayList = FragmentTransition.configureEnteringExitingViews(fragmentTransitionImpl, object4, (Fragment)object2, arrayList, view)) == null || arrayList.isEmpty()) {
                object4 = null;
            }
            fragmentTransitionImpl.addTarget(object3, view);
            object2 = FragmentTransition.mergeTransitions(fragmentTransitionImpl, object3, object4, object5, fragment, ((FragmentContainerTransition)object).lastInIsPop);
            if (object2 == null) break block4;
            object = new ArrayList();
            fragmentTransitionImpl.scheduleRemoveTargets(object2, object3, (ArrayList<View>)object, object4, arrayList, object5, arrayList2);
            FragmentTransition.scheduleTargetChange(fragmentTransitionImpl, (ViewGroup)fragmentManagerImpl, fragment, view, arrayList2, object3, (ArrayList<View>)object, object4, arrayList);
            fragmentTransitionImpl.setNameOverridesOrdered((View)fragmentManagerImpl, arrayList2, arrayMap);
            fragmentTransitionImpl.beginDelayedTransition((ViewGroup)fragmentManagerImpl, object2);
            fragmentTransitionImpl.scheduleNameReset((ViewGroup)fragmentManagerImpl, arrayList2, arrayMap);
        }
    }

    private static void configureTransitionsReordered(FragmentManagerImpl fragmentManagerImpl, int n, FragmentContainerTransition object, View object2, ArrayMap<String, String> arrayMap) {
        block3: {
            fragmentManagerImpl = fragmentManagerImpl.mContainer.onHasView() ? (ViewGroup)fragmentManagerImpl.mContainer.onFindViewById(n) : null;
            if (fragmentManagerImpl == null) {
                return;
            }
            Object object3 = ((FragmentContainerTransition)object).firstOut;
            Object object4 = ((FragmentContainerTransition)object).lastIn;
            FragmentTransitionImpl fragmentTransitionImpl = FragmentTransition.chooseImpl((Fragment)object3, (Fragment)object4);
            if (fragmentTransitionImpl == null) {
                return;
            }
            boolean bl = ((FragmentContainerTransition)object).lastInIsPop;
            boolean bl2 = ((FragmentContainerTransition)object).firstOutIsPop;
            ArrayList<View> arrayList = new ArrayList<View>();
            ArrayList<View> arrayList2 = new ArrayList<View>();
            Object object5 = FragmentTransition.getEnterTransition(fragmentTransitionImpl, (Fragment)object4, bl);
            ArrayList<View> arrayList3 = FragmentTransition.getExitTransition(fragmentTransitionImpl, (Fragment)object3, bl2);
            Object object6 = FragmentTransition.configureSharedElementsReordered(fragmentTransitionImpl, (ViewGroup)fragmentManagerImpl, object2, arrayMap, (FragmentContainerTransition)object, arrayList2, arrayList, object5, arrayList3);
            if (object5 == null && object6 == null && arrayList3 == null) {
                return;
            }
            object = arrayList3;
            arrayList3 = FragmentTransition.configureEnteringExitingViews(fragmentTransitionImpl, object, (Fragment)object3, arrayList2, object2);
            object2 = FragmentTransition.configureEnteringExitingViews(fragmentTransitionImpl, object5, (Fragment)object4, arrayList, object2);
            FragmentTransition.setViewVisibility((ArrayList<View>)object2, 4);
            object4 = FragmentTransition.mergeTransitions(fragmentTransitionImpl, object5, object, object6, (Fragment)object4, bl);
            if (object4 == null) break block3;
            FragmentTransition.replaceHide(fragmentTransitionImpl, object, (Fragment)object3, arrayList3);
            object3 = fragmentTransitionImpl.prepareSetNameOverridesReordered(arrayList);
            fragmentTransitionImpl.scheduleRemoveTargets(object4, object5, (ArrayList<View>)object2, object, arrayList3, object6, arrayList);
            fragmentTransitionImpl.beginDelayedTransition((ViewGroup)fragmentManagerImpl, object4);
            fragmentTransitionImpl.setNameOverridesReordered((View)fragmentManagerImpl, arrayList2, arrayList, (ArrayList<String>)object3, arrayMap);
            FragmentTransition.setViewVisibility((ArrayList<View>)object2, 0);
            fragmentTransitionImpl.swapSharedElementTargets(object6, arrayList2, arrayList);
        }
    }

    private static FragmentContainerTransition ensureContainer(FragmentContainerTransition fragmentContainerTransition, SparseArray<FragmentContainerTransition> sparseArray, int n) {
        FragmentContainerTransition fragmentContainerTransition2 = fragmentContainerTransition;
        if (fragmentContainerTransition == null) {
            fragmentContainerTransition2 = new FragmentContainerTransition();
            sparseArray.put(n, (Object)fragmentContainerTransition2);
        }
        return fragmentContainerTransition2;
    }

    private static String findKeyForValue(ArrayMap<String, String> arrayMap, String string2) {
        int n = arrayMap.size();
        for (int i = 0; i < n; ++i) {
            if (!string2.equals(arrayMap.valueAt(i))) continue;
            return (String)arrayMap.keyAt(i);
        }
        return null;
    }

    private static Object getEnterTransition(FragmentTransitionImpl fragmentTransitionImpl, Fragment object, boolean bl) {
        if (object == null) {
            return null;
        }
        object = bl ? ((Fragment)object).getReenterTransition() : ((Fragment)object).getEnterTransition();
        return fragmentTransitionImpl.cloneTransition(object);
    }

    private static Object getExitTransition(FragmentTransitionImpl fragmentTransitionImpl, Fragment object, boolean bl) {
        if (object == null) {
            return null;
        }
        object = bl ? ((Fragment)object).getReturnTransition() : ((Fragment)object).getExitTransition();
        return fragmentTransitionImpl.cloneTransition(object);
    }

    private static View getInEpicenterView(ArrayMap<String, View> arrayMap, FragmentContainerTransition object, Object object2, boolean bl) {
        object = ((FragmentContainerTransition)object).lastInTransaction;
        if (object2 != null && arrayMap != null && ((BackStackRecord)object).mSharedElementSourceNames != null && !((BackStackRecord)object).mSharedElementSourceNames.isEmpty()) {
            object = bl ? ((BackStackRecord)object).mSharedElementSourceNames.get(0) : ((BackStackRecord)object).mSharedElementTargetNames.get(0);
            return (View)arrayMap.get(object);
        }
        return null;
    }

    private static Object getSharedElementTransition(FragmentTransitionImpl fragmentTransitionImpl, Fragment object, Fragment fragment, boolean bl) {
        if (object != null && fragment != null) {
            object = bl ? fragment.getSharedElementReturnTransition() : ((Fragment)object).getSharedElementEnterTransition();
            return fragmentTransitionImpl.wrapTransitionInSet(fragmentTransitionImpl.cloneTransition(object));
        }
        return null;
    }

    private static Object mergeTransitions(FragmentTransitionImpl object, Object object2, Object object3, Object object4, Fragment fragment, boolean bl) {
        boolean bl2;
        boolean bl3 = bl2 = true;
        if (object2 != null) {
            bl3 = bl2;
            if (object3 != null) {
                bl3 = bl2;
                if (fragment != null) {
                    bl = bl ? fragment.getAllowReturnTransitionOverlap() : fragment.getAllowEnterTransitionOverlap();
                    bl3 = bl;
                }
            }
        }
        object = bl3 ? ((FragmentTransitionImpl)object).mergeTransitionsTogether(object3, object2, object4) : ((FragmentTransitionImpl)object).mergeTransitionsInSequence(object3, object2, object4);
        return object;
    }

    private static void replaceHide(FragmentTransitionImpl fragmentTransitionImpl, Object object, Fragment fragment, final ArrayList<View> arrayList) {
        if (fragment != null && object != null && fragment.mAdded && fragment.mHidden && fragment.mHiddenChanged) {
            fragment.setHideReplaced(true);
            fragmentTransitionImpl.scheduleHideFragmentView(object, fragment.getView(), arrayList);
            OneShotPreDrawListener.add((View)fragment.mContainer, new Runnable(){

                @Override
                public void run() {
                    FragmentTransition.setViewVisibility(arrayList, 4);
                }
            });
        }
    }

    private static FragmentTransitionImpl resolveSupportImpl() {
        try {
            FragmentTransitionImpl fragmentTransitionImpl = (FragmentTransitionImpl)Class.forName("android.support.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
            return fragmentTransitionImpl;
        }
        catch (Exception exception) {
            return null;
        }
    }

    private static void retainValues(ArrayMap<String, String> arrayMap, ArrayMap<String, View> arrayMap2) {
        for (int i = arrayMap.size() - 1; i >= 0; --i) {
            if (arrayMap2.containsKey((String)arrayMap.valueAt(i))) continue;
            arrayMap.removeAt(i);
        }
    }

    private static void scheduleTargetChange(final FragmentTransitionImpl fragmentTransitionImpl, ViewGroup viewGroup, final Fragment fragment, final View view, final ArrayList<View> arrayList, final Object object, final ArrayList<View> arrayList2, final Object object2, final ArrayList<View> arrayList3) {
        OneShotPreDrawListener.add((View)viewGroup, new Runnable(){

            @Override
            public void run() {
                ArrayList arrayList4 = object;
                if (arrayList4 != null) {
                    fragmentTransitionImpl.removeTarget(arrayList4, view);
                    arrayList4 = FragmentTransition.configureEnteringExitingViews(fragmentTransitionImpl, object, fragment, arrayList, view);
                    arrayList2.addAll(arrayList4);
                }
                if (arrayList3 != null) {
                    if (object2 != null) {
                        arrayList4 = new ArrayList();
                        arrayList4.add(view);
                        fragmentTransitionImpl.replaceTargets(object2, arrayList3, arrayList4);
                    }
                    arrayList3.clear();
                    arrayList3.add(view);
                }
            }
        });
    }

    private static void setOutEpicenter(FragmentTransitionImpl fragmentTransitionImpl, Object object, Object object2, ArrayMap<String, View> view, boolean bl, BackStackRecord object3) {
        if (((BackStackRecord)object3).mSharedElementSourceNames != null && !((BackStackRecord)object3).mSharedElementSourceNames.isEmpty()) {
            object3 = bl ? ((BackStackRecord)object3).mSharedElementTargetNames.get(0) : ((BackStackRecord)object3).mSharedElementSourceNames.get(0);
            view = (View)view.get(object3);
            fragmentTransitionImpl.setEpicenter(object, view);
            if (object2 != null) {
                fragmentTransitionImpl.setEpicenter(object2, view);
            }
        }
    }

    private static void setViewVisibility(ArrayList<View> arrayList, int n) {
        if (arrayList == null) {
            return;
        }
        for (int i = arrayList.size() - 1; i >= 0; --i) {
            arrayList.get(i).setVisibility(n);
        }
    }

    static void startTransitions(FragmentManagerImpl fragmentManagerImpl, ArrayList<BackStackRecord> arrayList, ArrayList<Boolean> arrayList2, int n, int n2, boolean bl) {
        Object object;
        int n3;
        if (fragmentManagerImpl.mCurState < 1) {
            return;
        }
        SparseArray sparseArray = new SparseArray();
        for (n3 = n; n3 < n2; ++n3) {
            object = arrayList.get(n3);
            if (arrayList2.get(n3).booleanValue()) {
                FragmentTransition.calculatePopFragments((BackStackRecord)object, (SparseArray<FragmentContainerTransition>)sparseArray, bl);
                continue;
            }
            FragmentTransition.calculateFragments((BackStackRecord)object, (SparseArray<FragmentContainerTransition>)sparseArray, bl);
        }
        if (sparseArray.size() != 0) {
            View view = new View(fragmentManagerImpl.mHost.getContext());
            int n4 = sparseArray.size();
            for (n3 = 0; n3 < n4; ++n3) {
                int n5 = sparseArray.keyAt(n3);
                object = FragmentTransition.calculateNameOverrides(n5, arrayList, arrayList2, n, n2);
                FragmentContainerTransition fragmentContainerTransition = (FragmentContainerTransition)sparseArray.valueAt(n3);
                if (bl) {
                    FragmentTransition.configureTransitionsReordered(fragmentManagerImpl, n5, fragmentContainerTransition, view, (ArrayMap<String, String>)object);
                    continue;
                }
                FragmentTransition.configureTransitionsOrdered(fragmentManagerImpl, n5, fragmentContainerTransition, view, (ArrayMap<String, String>)object);
            }
        }
    }

    static boolean supportsTransition() {
        boolean bl = PLATFORM_IMPL != null || SUPPORT_IMPL != null;
        return bl;
    }

    static class FragmentContainerTransition {
        public Fragment firstOut;
        public boolean firstOutIsPop;
        public BackStackRecord firstOutTransaction;
        public Fragment lastIn;
        public boolean lastInIsPop;
        public BackStackRecord lastInTransaction;

        FragmentContainerTransition() {
        }
    }
}

