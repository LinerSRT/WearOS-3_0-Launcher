/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewGroup
 */
package android.support.v4.app;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class FragmentStatePagerAdapter
extends PagerAdapter {
    private static final boolean DEBUG = false;
    private static final String TAG = "FragmentStatePagerAdapt";
    private FragmentTransaction mCurTransaction = null;
    private Fragment mCurrentPrimaryItem = null;
    private final FragmentManager mFragmentManager;
    private ArrayList<Fragment> mFragments;
    private ArrayList<Fragment.SavedState> mSavedState = new ArrayList();

    public FragmentStatePagerAdapter(FragmentManager fragmentManager) {
        this.mFragments = new ArrayList();
        this.mFragmentManager = fragmentManager;
    }

    @Override
    public void destroyItem(ViewGroup object, int n, Object arrayList) {
        Fragment fragment = (Fragment)((Object)arrayList);
        if (this.mCurTransaction == null) {
            this.mCurTransaction = this.mFragmentManager.beginTransaction();
        }
        while (this.mSavedState.size() <= n) {
            this.mSavedState.add(null);
        }
        arrayList = this.mSavedState;
        object = fragment.isAdded() ? this.mFragmentManager.saveFragmentInstanceState(fragment) : null;
        arrayList.set(n, (Fragment.SavedState)object);
        this.mFragments.set(n, null);
        this.mCurTransaction.remove(fragment);
    }

    @Override
    public void finishUpdate(ViewGroup object) {
        object = this.mCurTransaction;
        if (object != null) {
            ((FragmentTransaction)object).commitNowAllowingStateLoss();
            this.mCurTransaction = null;
        }
    }

    public abstract Fragment getItem(int var1);

    @Override
    public Object instantiateItem(ViewGroup viewGroup, int n) {
        Object object;
        if (this.mFragments.size() > n && (object = this.mFragments.get(n)) != null) {
            return object;
        }
        if (this.mCurTransaction == null) {
            this.mCurTransaction = this.mFragmentManager.beginTransaction();
        }
        Fragment fragment = this.getItem(n);
        if (this.mSavedState.size() > n && (object = this.mSavedState.get(n)) != null) {
            fragment.setInitialSavedState((Fragment.SavedState)object);
        }
        while (this.mFragments.size() <= n) {
            this.mFragments.add(null);
        }
        fragment.setMenuVisibility(false);
        fragment.setUserVisibleHint(false);
        this.mFragments.set(n, fragment);
        this.mCurTransaction.add(viewGroup.getId(), fragment);
        return fragment;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        boolean bl = ((Fragment)object).getView() == view;
        return bl;
    }

    @Override
    public void restoreState(Parcelable parcelable, ClassLoader object2) {
        if (parcelable != null) {
            int n;
            parcelable = (Bundle)parcelable;
            parcelable.setClassLoader((ClassLoader)object2);
            object2 = parcelable.getParcelableArray("states");
            this.mSavedState.clear();
            this.mFragments.clear();
            if (object2 != null) {
                for (n = 0; n < ((Parcelable[])object2).length; ++n) {
                    this.mSavedState.add((Fragment.SavedState)object2[n]);
                }
            }
            for (Object object2 : parcelable.keySet()) {
                if (!((String)object2).startsWith("f")) continue;
                n = Integer.parseInt(((String)object2).substring(1));
                Object object3 = this.mFragmentManager.getFragment((Bundle)parcelable, (String)object2);
                if (object3 != null) {
                    while (this.mFragments.size() <= n) {
                        this.mFragments.add(null);
                    }
                    ((Fragment)object3).setMenuVisibility(false);
                    this.mFragments.set(n, (Fragment)object3);
                    continue;
                }
                object3 = new StringBuilder();
                ((StringBuilder)object3).append("Bad fragment at key ");
                ((StringBuilder)object3).append((String)object2);
                Log.w((String)"FragmentStatePagerAdapt", (String)((StringBuilder)object3).toString());
            }
        }
    }

    @Override
    public Parcelable saveState() {
        Bundle bundle;
        Object object = null;
        if (this.mSavedState.size() > 0) {
            object = new Bundle();
            bundle = new Fragment.SavedState[this.mSavedState.size()];
            this.mSavedState.toArray((T[])bundle);
            object.putParcelableArray("states", (Parcelable[])bundle);
        }
        for (int i = 0; i < this.mFragments.size(); ++i) {
            Fragment fragment = this.mFragments.get(i);
            bundle = object;
            if (fragment != null) {
                bundle = object;
                if (fragment.isAdded()) {
                    bundle = object;
                    if (object == null) {
                        bundle = new Bundle();
                    }
                    object = new StringBuilder();
                    ((StringBuilder)object).append("f");
                    ((StringBuilder)object).append(i);
                    object = ((StringBuilder)object).toString();
                    this.mFragmentManager.putFragment(bundle, (String)object, fragment);
                }
            }
            object = bundle;
        }
        return object;
    }

    @Override
    public void setPrimaryItem(ViewGroup object, int n, Object object2) {
        object = this.mCurrentPrimaryItem;
        if ((object2 = (Fragment)object2) != object) {
            if (object != null) {
                ((Fragment)object).setMenuVisibility(false);
                this.mCurrentPrimaryItem.setUserVisibleHint(false);
            }
            if (object2 != null) {
                ((Fragment)object2).setMenuVisibility(true);
                ((Fragment)object2).setUserVisibleHint(true);
            }
            this.mCurrentPrimaryItem = object2;
        }
    }

    @Override
    public void startUpdate(ViewGroup object) {
        if (object.getId() != -1) {
            return;
        }
        object = new StringBuilder();
        ((StringBuilder)object).append("ViewPager with adapter ");
        ((StringBuilder)object).append(this);
        ((StringBuilder)object).append(" requires a view id");
        throw new IllegalStateException(((StringBuilder)object).toString());
    }
}

