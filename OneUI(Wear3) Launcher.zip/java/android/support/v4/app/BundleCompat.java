/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.util.Log
 */
package android.support.v4.app;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class BundleCompat {
    private BundleCompat() {
    }

    public static IBinder getBinder(Bundle bundle, String string2) {
        if (Build.VERSION.SDK_INT >= 18) {
            return bundle.getBinder(string2);
        }
        return BundleCompatBaseImpl.getBinder(bundle, string2);
    }

    public static void putBinder(Bundle bundle, String string2, IBinder iBinder) {
        if (Build.VERSION.SDK_INT >= 18) {
            bundle.putBinder(string2, iBinder);
        } else {
            BundleCompatBaseImpl.putBinder(bundle, string2, iBinder);
        }
    }

    static class BundleCompatBaseImpl {
        private static final String TAG = "BundleCompatBaseImpl";
        private static Method sGetIBinderMethod;
        private static boolean sGetIBinderMethodFetched;
        private static Method sPutIBinderMethod;
        private static boolean sPutIBinderMethodFetched;

        private BundleCompatBaseImpl() {
        }

        public static IBinder getBinder(Bundle bundle, String string2) {
            Method method;
            if (!sGetIBinderMethodFetched) {
                try {
                    sGetIBinderMethod = method = Bundle.class.getMethod("getIBinder", String.class);
                    method.setAccessible(true);
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    Log.i((String)TAG, (String)"Failed to retrieve getIBinder method", (Throwable)noSuchMethodException);
                }
                sGetIBinderMethodFetched = true;
            }
            if ((method = sGetIBinderMethod) != null) {
                try {
                    bundle = (IBinder)method.invoke(bundle, string2);
                    return bundle;
                }
                catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException exception) {
                    Log.i((String)TAG, (String)"Failed to invoke getIBinder via reflection", (Throwable)exception);
                    sGetIBinderMethod = null;
                }
            }
            return null;
        }

        public static void putBinder(Bundle bundle, String string2, IBinder iBinder) {
            Method method;
            if (!sPutIBinderMethodFetched) {
                try {
                    sPutIBinderMethod = method = Bundle.class.getMethod("putIBinder", String.class, IBinder.class);
                    method.setAccessible(true);
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    Log.i((String)TAG, (String)"Failed to retrieve putIBinder method", (Throwable)noSuchMethodException);
                }
                sPutIBinderMethodFetched = true;
            }
            if ((method = sPutIBinderMethod) != null) {
                try {
                    method.invoke(bundle, string2, iBinder);
                }
                catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException exception) {
                    Log.i((String)TAG, (String)"Failed to invoke putIBinder via reflection", (Throwable)exception);
                    sPutIBinderMethod = null;
                }
            }
        }
    }
}

