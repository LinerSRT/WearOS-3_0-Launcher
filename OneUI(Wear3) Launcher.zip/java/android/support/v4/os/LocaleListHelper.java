/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 */
package android.support.v4.os;

import android.os.Build;
import android.support.v4.os.LocaleHelper;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;

final class LocaleListHelper {
    private static final Locale EN_LATN;
    private static final Locale LOCALE_AR_XB;
    private static final Locale LOCALE_EN_XA;
    private static final int NUM_PSEUDO_LOCALES = 2;
    private static final String STRING_AR_XB = "ar-XB";
    private static final String STRING_EN_XA = "en-XA";
    private static LocaleListHelper sDefaultAdjustedLocaleList;
    private static LocaleListHelper sDefaultLocaleList;
    private static final Locale[] sEmptyList;
    private static final LocaleListHelper sEmptyLocaleList;
    private static Locale sLastDefaultLocale;
    private static LocaleListHelper sLastExplicitlySetLocaleList;
    private static final Object sLock;
    private final Locale[] mList;
    private final String mStringRepresentation;

    static {
        sEmptyList = new Locale[0];
        sEmptyLocaleList = new LocaleListHelper(new Locale[0]);
        LOCALE_EN_XA = new Locale("en", "XA");
        LOCALE_AR_XB = new Locale("ar", "XB");
        EN_LATN = LocaleHelper.forLanguageTag("en-Latn");
        sLock = new Object();
        sLastExplicitlySetLocaleList = null;
        sDefaultLocaleList = null;
        sDefaultAdjustedLocaleList = null;
        sLastDefaultLocale = null;
    }

    LocaleListHelper(Locale serializable, LocaleListHelper localeListHelper) {
        if (serializable != null) {
            int n;
            int n2 = localeListHelper == null ? 0 : localeListHelper.mList.length;
            int n3 = -1;
            int n4 = 0;
            while (true) {
                n = n3;
                if (n4 >= n2) break;
                if (((Locale)serializable).equals(localeListHelper.mList[n4])) {
                    n = n4;
                    break;
                }
                ++n4;
            }
            n4 = n == -1 ? 1 : 0;
            n3 = n4 + n2;
            Locale[] localeArray = new Locale[n3];
            localeArray[0] = (Locale)((Locale)serializable).clone();
            if (n == -1) {
                for (n4 = 0; n4 < n2; ++n4) {
                    localeArray[n4 + 1] = (Locale)localeListHelper.mList[n4].clone();
                }
            } else {
                for (n4 = 0; n4 < n; ++n4) {
                    localeArray[n4 + 1] = (Locale)localeListHelper.mList[n4].clone();
                }
                for (n4 = n + 1; n4 < n2; ++n4) {
                    localeArray[n4] = (Locale)localeListHelper.mList[n4].clone();
                }
            }
            serializable = new StringBuilder();
            for (n4 = 0; n4 < n3; ++n4) {
                ((StringBuilder)serializable).append(LocaleHelper.toLanguageTag(localeArray[n4]));
                if (n4 >= n3 - 1) continue;
                ((StringBuilder)serializable).append(',');
            }
            this.mList = localeArray;
            this.mStringRepresentation = ((StringBuilder)serializable).toString();
            return;
        }
        throw new NullPointerException("topLocale is null");
    }

    LocaleListHelper(Locale ... object) {
        if (((Locale[])object).length == 0) {
            this.mList = sEmptyList;
            this.mStringRepresentation = "";
        } else {
            Locale[] localeArray = new Locale[((Locale[])object).length];
            HashSet<Locale> hashSet = new HashSet<Locale>();
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < ((Locale[])object).length; ++i) {
                Locale locale = object[i];
                if (locale != null) {
                    if (!hashSet.contains(locale)) {
                        localeArray[i] = locale = (Locale)locale.clone();
                        stringBuilder.append(LocaleHelper.toLanguageTag(locale));
                        if (i < ((Object)object).length - 1) {
                            stringBuilder.append(',');
                        }
                        hashSet.add(locale);
                        continue;
                    }
                    object = new StringBuilder();
                    ((StringBuilder)object).append("list[");
                    ((StringBuilder)object).append(i);
                    ((StringBuilder)object).append("] is a repetition");
                    throw new IllegalArgumentException(((StringBuilder)object).toString());
                }
                object = new StringBuilder();
                ((StringBuilder)object).append("list[");
                ((StringBuilder)object).append(i);
                ((StringBuilder)object).append("] is null");
                throw new NullPointerException(((StringBuilder)object).toString());
            }
            this.mList = localeArray;
            this.mStringRepresentation = stringBuilder.toString();
        }
    }

    private Locale computeFirstMatch(Collection<String> object, boolean bl) {
        int n = this.computeFirstMatchIndex((Collection<String>)object, bl);
        object = n == -1 ? null : this.mList[n];
        return object;
    }

    private int computeFirstMatchIndex(Collection<String> object, boolean bl) {
        int n;
        int n2;
        Locale[] localeArray = this.mList;
        if (localeArray.length == 1) {
            return 0;
        }
        if (localeArray.length == 0) {
            return -1;
        }
        int n3 = n2 = Integer.MAX_VALUE;
        if (bl) {
            n = this.findFirstMatchIndex(EN_LATN);
            if (n == 0) {
                return 0;
            }
            n3 = n2;
            if (n < Integer.MAX_VALUE) {
                n3 = n;
            }
        }
        object = object.iterator();
        n = n3;
        while (object.hasNext()) {
            n2 = this.findFirstMatchIndex(LocaleHelper.forLanguageTag((String)object.next()));
            if (n2 == 0) {
                return 0;
            }
            n3 = n;
            if (n2 < n) {
                n3 = n2;
            }
            n = n3;
        }
        if (n == Integer.MAX_VALUE) {
            return 0;
        }
        return n;
    }

    private int findFirstMatchIndex(Locale locale) {
        Locale[] localeArray;
        for (int i = 0; i < (localeArray = this.mList).length; ++i) {
            if (LocaleListHelper.matchScore(locale, localeArray[i]) <= 0) continue;
            return i;
        }
        return Integer.MAX_VALUE;
    }

    static LocaleListHelper forLanguageTags(String localeArray) {
        if (localeArray != null && !localeArray.isEmpty()) {
            String[] stringArray = localeArray.split(",", -1);
            localeArray = new Locale[stringArray.length];
            for (int i = 0; i < localeArray.length; ++i) {
                localeArray[i] = LocaleHelper.forLanguageTag(stringArray[i]);
            }
            return new LocaleListHelper(localeArray);
        }
        return LocaleListHelper.getEmptyLocaleList();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static LocaleListHelper getAdjustedDefault() {
        LocaleListHelper.getDefault();
        Object object = sLock;
        synchronized (object) {
            return sDefaultAdjustedLocaleList;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static LocaleListHelper getDefault() {
        Locale locale = Locale.getDefault();
        Object object = sLock;
        synchronized (object) {
            LocaleListHelper localeListHelper;
            if (locale.equals(sLastDefaultLocale)) return sDefaultLocaleList;
            sLastDefaultLocale = locale;
            if (sDefaultLocaleList != null && locale.equals(sDefaultLocaleList.get(0))) {
                return sDefaultLocaleList;
            }
            sDefaultLocaleList = localeListHelper = new LocaleListHelper(locale, sLastExplicitlySetLocaleList);
            sDefaultAdjustedLocaleList = localeListHelper;
            return sDefaultLocaleList;
        }
    }

    static LocaleListHelper getEmptyLocaleList() {
        return sEmptyLocaleList;
    }

    private static String getLikelyScript(Locale object) {
        if (Build.VERSION.SDK_INT >= 21) {
            if (!((String)(object = ((Locale)object).getScript())).isEmpty()) {
                return object;
            }
            return "";
        }
        return "";
    }

    private static boolean isPseudoLocale(String string2) {
        boolean bl = STRING_EN_XA.equals(string2) || STRING_AR_XB.equals(string2);
        return bl;
    }

    private static boolean isPseudoLocale(Locale locale) {
        boolean bl = LOCALE_EN_XA.equals(locale) || LOCALE_AR_XB.equals(locale);
        return bl;
    }

    static boolean isPseudoLocalesOnly(String[] stringArray) {
        if (stringArray == null) {
            return true;
        }
        if (stringArray.length > 3) {
            return false;
        }
        for (String string2 : stringArray) {
            if (string2.isEmpty() || LocaleListHelper.isPseudoLocale(string2)) continue;
            return false;
        }
        return true;
    }

    private static int matchScore(Locale object, Locale locale) {
        boolean bl = ((Locale)object).equals(locale);
        int n = 1;
        if (bl) {
            return 1;
        }
        if (!((Locale)object).getLanguage().equals(locale.getLanguage())) {
            return 0;
        }
        if (!LocaleListHelper.isPseudoLocale((Locale)object) && !LocaleListHelper.isPseudoLocale(locale)) {
            String string2 = LocaleListHelper.getLikelyScript((Locale)object);
            if (string2.isEmpty()) {
                object = ((Locale)object).getCountry();
                int n2 = n;
                if (!((String)object).isEmpty()) {
                    n2 = ((String)object).equals(locale.getCountry()) ? n : 0;
                }
                return n2;
            }
            return string2.equals(LocaleListHelper.getLikelyScript(locale)) ? 1 : 0;
        }
        return 0;
    }

    static void setDefault(LocaleListHelper localeListHelper) {
        LocaleListHelper.setDefault(localeListHelper, 0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void setDefault(LocaleListHelper localeListHelper, int n) {
        if (localeListHelper == null) {
            throw new NullPointerException("locales is null");
        }
        if (localeListHelper.isEmpty()) {
            throw new IllegalArgumentException("locales is empty");
        }
        Object object = sLock;
        synchronized (object) {
            Locale locale;
            sLastDefaultLocale = locale = localeListHelper.get(n);
            Locale.setDefault(locale);
            sLastExplicitlySetLocaleList = localeListHelper;
            sDefaultLocaleList = localeListHelper;
            sDefaultAdjustedLocaleList = n == 0 ? localeListHelper : (localeListHelper = new LocaleListHelper(sLastDefaultLocale, sDefaultLocaleList));
            return;
        }
    }

    public boolean equals(Object localeArray) {
        Locale[] localeArray2;
        if (localeArray == this) {
            return true;
        }
        if (!(localeArray instanceof LocaleListHelper)) {
            return false;
        }
        localeArray = ((LocaleListHelper)localeArray).mList;
        if (this.mList.length != localeArray.length) {
            return false;
        }
        for (int i = 0; i < (localeArray2 = this.mList).length; ++i) {
            if (localeArray2[i].equals(localeArray[i])) continue;
            return false;
        }
        return true;
    }

    Locale get(int n) {
        Object object;
        object = n >= 0 && n < ((Locale[])(object = this.mList)).length ? object[n] : null;
        return object;
    }

    Locale getFirstMatch(String[] stringArray) {
        return this.computeFirstMatch(Arrays.asList(stringArray), false);
    }

    int getFirstMatchIndex(String[] stringArray) {
        return this.computeFirstMatchIndex(Arrays.asList(stringArray), false);
    }

    int getFirstMatchIndexWithEnglishSupported(Collection<String> collection) {
        return this.computeFirstMatchIndex(collection, true);
    }

    int getFirstMatchIndexWithEnglishSupported(String[] stringArray) {
        return this.getFirstMatchIndexWithEnglishSupported(Arrays.asList(stringArray));
    }

    Locale getFirstMatchWithEnglishSupported(String[] stringArray) {
        return this.computeFirstMatch(Arrays.asList(stringArray), true);
    }

    public int hashCode() {
        Locale[] localeArray;
        int n = 1;
        for (int i = 0; i < (localeArray = this.mList).length; ++i) {
            n = n * 31 + localeArray[i].hashCode();
        }
        return n;
    }

    int indexOf(Locale locale) {
        Locale[] localeArray;
        for (int i = 0; i < (localeArray = this.mList).length; ++i) {
            if (!localeArray[i].equals(locale)) continue;
            return i;
        }
        return -1;
    }

    boolean isEmpty() {
        boolean bl = this.mList.length == 0;
        return bl;
    }

    int size() {
        return this.mList.length;
    }

    String toLanguageTags() {
        return this.mStringRepresentation;
    }

    public String toString() {
        Locale[] localeArray;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        for (int i = 0; i < (localeArray = this.mList).length; ++i) {
            stringBuilder.append(localeArray[i]);
            if (i >= this.mList.length - 1) continue;
            stringBuilder.append(',');
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

