/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 *  android.os.LocaleList
 */
package android.support.v4.os;

import android.os.Build;
import android.os.LocaleList;
import android.support.v4.os.LocaleHelper;
import android.support.v4.os.LocaleListHelper;
import android.support.v4.os.LocaleListInterface;
import java.util.Locale;

public final class LocaleListCompat {
    static final LocaleListInterface IMPL;
    private static final LocaleListCompat sEmptyLocaleList;

    static {
        sEmptyLocaleList = new LocaleListCompat();
        IMPL = Build.VERSION.SDK_INT >= 24 ? new LocaleListCompatApi24Impl() : new LocaleListCompatBaseImpl();
    }

    private LocaleListCompat() {
    }

    public static LocaleListCompat create(Locale ... localeArray) {
        LocaleListCompat localeListCompat = new LocaleListCompat();
        localeListCompat.setLocaleListArray(localeArray);
        return localeListCompat;
    }

    public static LocaleListCompat forLanguageTags(String object) {
        if (object != null && !((String)object).isEmpty()) {
            String[] stringArray = ((String)object).split(",", -1);
            Locale[] localeArray = new Locale[stringArray.length];
            for (int i = 0; i < localeArray.length; ++i) {
                object = Build.VERSION.SDK_INT >= 21 ? Locale.forLanguageTag(stringArray[i]) : LocaleHelper.forLanguageTag(stringArray[i]);
                localeArray[i] = object;
            }
            object = new LocaleListCompat();
            super.setLocaleListArray(localeArray);
            return object;
        }
        return LocaleListCompat.getEmptyLocaleList();
    }

    public static LocaleListCompat getAdjustedDefault() {
        if (Build.VERSION.SDK_INT >= 24) {
            return LocaleListCompat.wrap(LocaleList.getAdjustedDefault());
        }
        return LocaleListCompat.create(Locale.getDefault());
    }

    public static LocaleListCompat getDefault() {
        if (Build.VERSION.SDK_INT >= 24) {
            return LocaleListCompat.wrap(LocaleList.getDefault());
        }
        return LocaleListCompat.create(Locale.getDefault());
    }

    public static LocaleListCompat getEmptyLocaleList() {
        return sEmptyLocaleList;
    }

    private void setLocaleList(LocaleList localeList) {
        int n = localeList.size();
        if (n > 0) {
            Locale[] localeArray = new Locale[n];
            for (int i = 0; i < n; ++i) {
                localeArray[i] = localeList.get(i);
            }
            IMPL.setLocaleList(localeArray);
        }
    }

    private void setLocaleListArray(Locale ... localeArray) {
        IMPL.setLocaleList(localeArray);
    }

    public static LocaleListCompat wrap(Object object) {
        LocaleListCompat localeListCompat = new LocaleListCompat();
        if (object instanceof LocaleList) {
            localeListCompat.setLocaleList((LocaleList)object);
        }
        return localeListCompat;
    }

    public boolean equals(Object object) {
        return IMPL.equals(object);
    }

    public Locale get(int n) {
        return IMPL.get(n);
    }

    public Locale getFirstMatch(String[] stringArray) {
        return IMPL.getFirstMatch(stringArray);
    }

    public int hashCode() {
        return IMPL.hashCode();
    }

    public int indexOf(Locale locale) {
        return IMPL.indexOf(locale);
    }

    public boolean isEmpty() {
        return IMPL.isEmpty();
    }

    public int size() {
        return IMPL.size();
    }

    public String toLanguageTags() {
        return IMPL.toLanguageTags();
    }

    public String toString() {
        return IMPL.toString();
    }

    public Object unwrap() {
        return IMPL.getLocaleList();
    }

    static class LocaleListCompatApi24Impl
    implements LocaleListInterface {
        private LocaleList mLocaleList = new LocaleList(new Locale[0]);

        LocaleListCompatApi24Impl() {
        }

        @Override
        public boolean equals(Object object) {
            return this.mLocaleList.equals(((LocaleListCompat)object).unwrap());
        }

        @Override
        public Locale get(int n) {
            return this.mLocaleList.get(n);
        }

        @Override
        public Locale getFirstMatch(String[] stringArray) {
            LocaleList localeList = this.mLocaleList;
            if (localeList != null) {
                return localeList.getFirstMatch(stringArray);
            }
            return null;
        }

        @Override
        public Object getLocaleList() {
            return this.mLocaleList;
        }

        @Override
        public int hashCode() {
            return this.mLocaleList.hashCode();
        }

        @Override
        public int indexOf(Locale locale) {
            return this.mLocaleList.indexOf(locale);
        }

        @Override
        public boolean isEmpty() {
            return this.mLocaleList.isEmpty();
        }

        @Override
        public void setLocaleList(Locale ... localeArray) {
            this.mLocaleList = new LocaleList(localeArray);
        }

        @Override
        public int size() {
            return this.mLocaleList.size();
        }

        @Override
        public String toLanguageTags() {
            return this.mLocaleList.toLanguageTags();
        }

        @Override
        public String toString() {
            return this.mLocaleList.toString();
        }
    }

    static class LocaleListCompatBaseImpl
    implements LocaleListInterface {
        private LocaleListHelper mLocaleList = new LocaleListHelper(new Locale[0]);

        LocaleListCompatBaseImpl() {
        }

        @Override
        public boolean equals(Object object) {
            return this.mLocaleList.equals(((LocaleListCompat)object).unwrap());
        }

        @Override
        public Locale get(int n) {
            return this.mLocaleList.get(n);
        }

        @Override
        public Locale getFirstMatch(String[] stringArray) {
            LocaleListHelper localeListHelper = this.mLocaleList;
            if (localeListHelper != null) {
                return localeListHelper.getFirstMatch(stringArray);
            }
            return null;
        }

        @Override
        public Object getLocaleList() {
            return this.mLocaleList;
        }

        @Override
        public int hashCode() {
            return this.mLocaleList.hashCode();
        }

        @Override
        public int indexOf(Locale locale) {
            return this.mLocaleList.indexOf(locale);
        }

        @Override
        public boolean isEmpty() {
            return this.mLocaleList.isEmpty();
        }

        @Override
        public void setLocaleList(Locale ... localeArray) {
            this.mLocaleList = new LocaleListHelper(localeArray);
        }

        @Override
        public int size() {
            return this.mLocaleList.size();
        }

        @Override
        public String toLanguageTags() {
            return this.mLocaleList.toLanguageTags();
        }

        @Override
        public String toString() {
            return this.mLocaleList.toString();
        }
    }
}

