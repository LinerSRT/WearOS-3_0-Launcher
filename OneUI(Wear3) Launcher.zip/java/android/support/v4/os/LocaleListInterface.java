/*
 * Decompiled with CFR 0.151.
 */
package android.support.v4.os;

import java.util.Locale;

interface LocaleListInterface {
    public boolean equals(Object var1);

    public Locale get(int var1);

    public Locale getFirstMatch(String[] var1);

    public Object getLocaleList();

    public int hashCode();

    public int indexOf(Locale var1);

    public boolean isEmpty();

    public void setLocaleList(Locale ... var1);

    public int size();

    public String toLanguageTags();

    public String toString();
}

