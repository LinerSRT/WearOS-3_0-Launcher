/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Message
 */
package android.support.v4.os;

import android.os.Handler;
import android.os.Message;
import android.support.v4.os.BuildCompat;

public final class HandlerCompat {
    private HandlerCompat() {
    }

    public static boolean postDelayed(Handler handler, Runnable runnable, Object object, long l) {
        if (BuildCompat.isAtLeastP()) {
            return handler.postDelayed(runnable, object, l);
        }
        runnable = Message.obtain((Handler)handler, (Runnable)runnable);
        ((Message)runnable).obj = object;
        return handler.sendMessageDelayed((Message)runnable, l);
    }
}

