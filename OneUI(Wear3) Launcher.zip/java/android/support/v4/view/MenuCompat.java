/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.Menu
 *  android.view.MenuItem
 */
package android.support.v4.view;

import android.support.v4.internal.view.SupportMenu;
import android.support.v4.os.BuildCompat;
import android.view.Menu;
import android.view.MenuItem;

public final class MenuCompat {
    private MenuCompat() {
    }

    public static void setGroupDividerEnabled(Menu menu2, boolean bl) {
        if (menu2 instanceof SupportMenu) {
            ((SupportMenu)menu2).setGroupDividerEnabled(bl);
        } else if (BuildCompat.isAtLeastP()) {
            menu2.setGroupDividerEnabled(bl);
        }
    }

    @Deprecated
    public static void setShowAsAction(MenuItem menuItem, int n) {
        menuItem.setShowAsAction(n);
    }
}

