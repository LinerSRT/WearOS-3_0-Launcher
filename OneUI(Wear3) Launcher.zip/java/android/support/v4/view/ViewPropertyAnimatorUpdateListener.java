/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package android.support.v4.view;

import android.view.View;

public interface ViewPropertyAnimatorUpdateListener {
    public void onAnimationUpdate(View var1);
}

