/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewParent
 *  android.view.accessibility.AccessibilityEvent
 */
package android.support.v4.view;

import android.os.Build;
import android.support.v4.view.NestedScrollingParent;
import android.support.v4.view.NestedScrollingParent2;
import android.util.Log;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;

public final class ViewParentCompat {
    private static final String TAG = "ViewParentCompat";

    private ViewParentCompat() {
    }

    public static void notifySubtreeAccessibilityStateChanged(ViewParent viewParent, View view, View view2, int n) {
        if (Build.VERSION.SDK_INT >= 19) {
            viewParent.notifySubtreeAccessibilityStateChanged(view, view2, n);
        }
    }

    public static boolean onNestedFling(ViewParent viewParent, View object, float f, float f2, boolean bl) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                bl = viewParent.onNestedFling((View)object, f, f2, bl);
                return bl;
            }
            catch (AbstractMethodError abstractMethodError) {
                object = new StringBuilder();
                ((StringBuilder)object).append("ViewParent ");
                ((StringBuilder)object).append(viewParent);
                ((StringBuilder)object).append(" does not implement interface ");
                ((StringBuilder)object).append("method onNestedFling");
                Log.e((String)TAG, (String)((StringBuilder)object).toString(), (Throwable)abstractMethodError);
            }
        } else if (viewParent instanceof NestedScrollingParent) {
            return ((NestedScrollingParent)viewParent).onNestedFling((View)object, f, f2, bl);
        }
        return false;
    }

    public static boolean onNestedPreFling(ViewParent viewParent, View object, float f, float f2) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                boolean bl = viewParent.onNestedPreFling((View)object, f, f2);
                return bl;
            }
            catch (AbstractMethodError abstractMethodError) {
                object = new StringBuilder();
                ((StringBuilder)object).append("ViewParent ");
                ((StringBuilder)object).append(viewParent);
                ((StringBuilder)object).append(" does not implement interface ");
                ((StringBuilder)object).append("method onNestedPreFling");
                Log.e((String)TAG, (String)((StringBuilder)object).toString(), (Throwable)abstractMethodError);
            }
        } else if (viewParent instanceof NestedScrollingParent) {
            return ((NestedScrollingParent)viewParent).onNestedPreFling((View)object, f, f2);
        }
        return false;
    }

    public static void onNestedPreScroll(ViewParent viewParent, View view, int n, int n2, int[] nArray) {
        ViewParentCompat.onNestedPreScroll(viewParent, view, n, n2, nArray, 0);
    }

    public static void onNestedPreScroll(ViewParent viewParent, View view, int n, int n2, int[] object, int n3) {
        if (viewParent instanceof NestedScrollingParent2) {
            ((NestedScrollingParent2)viewParent).onNestedPreScroll(view, n, n2, (int[])object, n3);
        } else if (n3 == 0) {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    viewParent.onNestedPreScroll(view, n, n2, (int[])object);
                }
                catch (AbstractMethodError abstractMethodError) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("ViewParent ");
                    ((StringBuilder)object).append(viewParent);
                    ((StringBuilder)object).append(" does not implement interface ");
                    ((StringBuilder)object).append("method onNestedPreScroll");
                    Log.e((String)TAG, (String)((StringBuilder)object).toString(), (Throwable)abstractMethodError);
                }
            } else if (viewParent instanceof NestedScrollingParent) {
                ((NestedScrollingParent)viewParent).onNestedPreScroll(view, n, n2, (int[])object);
            }
        }
    }

    public static void onNestedScroll(ViewParent viewParent, View view, int n, int n2, int n3, int n4) {
        ViewParentCompat.onNestedScroll(viewParent, view, n, n2, n3, n4, 0);
    }

    public static void onNestedScroll(ViewParent viewParent, View view, int n, int n2, int n3, int n4, int n5) {
        if (viewParent instanceof NestedScrollingParent2) {
            ((NestedScrollingParent2)viewParent).onNestedScroll(view, n, n2, n3, n4, n5);
        } else if (n5 == 0) {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    viewParent.onNestedScroll(view, n, n2, n3, n4);
                }
                catch (AbstractMethodError abstractMethodError) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("ViewParent ");
                    stringBuilder.append(viewParent);
                    stringBuilder.append(" does not implement interface ");
                    stringBuilder.append("method onNestedScroll");
                    Log.e((String)TAG, (String)stringBuilder.toString(), (Throwable)abstractMethodError);
                }
            } else if (viewParent instanceof NestedScrollingParent) {
                ((NestedScrollingParent)viewParent).onNestedScroll(view, n, n2, n3, n4);
            }
        }
    }

    public static void onNestedScrollAccepted(ViewParent viewParent, View view, View view2, int n) {
        ViewParentCompat.onNestedScrollAccepted(viewParent, view, view2, n, 0);
    }

    public static void onNestedScrollAccepted(ViewParent viewParent, View object, View view, int n, int n2) {
        if (viewParent instanceof NestedScrollingParent2) {
            ((NestedScrollingParent2)viewParent).onNestedScrollAccepted((View)object, view, n, n2);
        } else if (n2 == 0) {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    viewParent.onNestedScrollAccepted((View)object, view, n);
                }
                catch (AbstractMethodError abstractMethodError) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("ViewParent ");
                    ((StringBuilder)object).append(viewParent);
                    ((StringBuilder)object).append(" does not implement interface ");
                    ((StringBuilder)object).append("method onNestedScrollAccepted");
                    Log.e((String)TAG, (String)((StringBuilder)object).toString(), (Throwable)abstractMethodError);
                }
            } else if (viewParent instanceof NestedScrollingParent) {
                ((NestedScrollingParent)viewParent).onNestedScrollAccepted((View)object, view, n);
            }
        }
    }

    public static boolean onStartNestedScroll(ViewParent viewParent, View view, View view2, int n) {
        return ViewParentCompat.onStartNestedScroll(viewParent, view, view2, n, 0);
    }

    public static boolean onStartNestedScroll(ViewParent viewParent, View object, View view, int n, int n2) {
        if (viewParent instanceof NestedScrollingParent2) {
            return ((NestedScrollingParent2)viewParent).onStartNestedScroll((View)object, view, n, n2);
        }
        if (n2 == 0) {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    boolean bl = viewParent.onStartNestedScroll((View)object, view, n);
                    return bl;
                }
                catch (AbstractMethodError abstractMethodError) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("ViewParent ");
                    ((StringBuilder)object).append(viewParent);
                    ((StringBuilder)object).append(" does not implement interface ");
                    ((StringBuilder)object).append("method onStartNestedScroll");
                    Log.e((String)TAG, (String)((StringBuilder)object).toString(), (Throwable)abstractMethodError);
                }
            } else if (viewParent instanceof NestedScrollingParent) {
                return ((NestedScrollingParent)viewParent).onStartNestedScroll((View)object, view, n);
            }
        }
        return false;
    }

    public static void onStopNestedScroll(ViewParent viewParent, View view) {
        ViewParentCompat.onStopNestedScroll(viewParent, view, 0);
    }

    public static void onStopNestedScroll(ViewParent viewParent, View view, int n) {
        if (viewParent instanceof NestedScrollingParent2) {
            ((NestedScrollingParent2)viewParent).onStopNestedScroll(view, n);
        } else if (n == 0) {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    viewParent.onStopNestedScroll(view);
                }
                catch (AbstractMethodError abstractMethodError) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("ViewParent ");
                    stringBuilder.append(viewParent);
                    stringBuilder.append(" does not implement interface ");
                    stringBuilder.append("method onStopNestedScroll");
                    Log.e((String)TAG, (String)stringBuilder.toString(), (Throwable)abstractMethodError);
                }
            } else if (viewParent instanceof NestedScrollingParent) {
                ((NestedScrollingParent)viewParent).onStopNestedScroll(view);
            }
        }
    }

    @Deprecated
    public static boolean requestSendAccessibilityEvent(ViewParent viewParent, View view, AccessibilityEvent accessibilityEvent) {
        return viewParent.requestSendAccessibilityEvent(view, accessibilityEvent);
    }
}

