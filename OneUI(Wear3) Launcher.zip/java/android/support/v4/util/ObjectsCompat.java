/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 */
package android.support.v4.util;

import android.os.Build;
import java.util.Arrays;
import java.util.Objects;

public class ObjectsCompat {
    private ObjectsCompat() {
    }

    public static boolean equals(Object object, Object object2) {
        if (Build.VERSION.SDK_INT >= 19) {
            return Objects.equals(object, object2);
        }
        boolean bl = object == object2 || object != null && object.equals(object2);
        return bl;
    }

    public static int hash(Object ... objectArray) {
        if (Build.VERSION.SDK_INT >= 19) {
            return Objects.hash(objectArray);
        }
        return Arrays.hashCode(objectArray);
    }

    public static int hashCode(Object object) {
        int n = object != null ? object.hashCode() : 0;
        return n;
    }
}

