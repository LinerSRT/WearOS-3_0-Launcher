/*
 * Decompiled with CFR 0.151.
 */
package android.support.v4.util;

public interface Consumer<T> {
    public void accept(T var1);
}

