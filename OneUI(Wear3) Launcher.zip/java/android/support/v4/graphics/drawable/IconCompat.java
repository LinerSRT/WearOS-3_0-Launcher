/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.content.Context
 *  android.content.Intent
 *  android.content.Intent$ShortcutIconResource
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapShader
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Icon
 *  android.net.Uri
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  android.util.Log
 *  androidx.versionedparcelable.CustomVersionedParcelable
 */
package android.support.v4.graphics.drawable;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.os.BuildCompat;
import android.support.v4.util.Preconditions;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat
extends CustomVersionedParcelable {
    private static final float ADAPTIVE_ICON_INSET_FACTOR = 0.25f;
    private static final int AMBIENT_SHADOW_ALPHA = 30;
    private static final float BLUR_FACTOR = 0.010416667f;
    static final PorterDuff.Mode DEFAULT_TINT_MODE = PorterDuff.Mode.SRC_IN;
    private static final float DEFAULT_VIEW_PORT_SCALE = 0.6666667f;
    private static final String EXTRA_INT1 = "int1";
    private static final String EXTRA_INT2 = "int2";
    private static final String EXTRA_OBJ = "obj";
    private static final String EXTRA_TINT_LIST = "tint_list";
    private static final String EXTRA_TINT_MODE = "tint_mode";
    private static final String EXTRA_TYPE = "type";
    private static final float ICON_DIAMETER_FACTOR = 0.9166667f;
    private static final int KEY_SHADOW_ALPHA = 61;
    private static final float KEY_SHADOW_OFFSET_FACTOR = 0.020833334f;
    private static final String TAG = "IconCompat";
    public static final int TYPE_UNKNOWN = -1;
    public byte[] mData;
    public int mInt1;
    public int mInt2;
    Object mObj1;
    public Parcelable mParcelable;
    public ColorStateList mTintList = null;
    PorterDuff.Mode mTintMode = DEFAULT_TINT_MODE;
    public String mTintModeStr;
    public int mType;

    public IconCompat() {
    }

    private IconCompat(int n) {
        this.mType = n;
    }

    public static IconCompat createFromBundle(Bundle object) {
        IconCompat iconCompat;
        block6: {
            block3: {
                block4: {
                    block5: {
                        int n = object.getInt(EXTRA_TYPE);
                        iconCompat = new IconCompat(n);
                        iconCompat.mInt1 = object.getInt(EXTRA_INT1);
                        iconCompat.mInt2 = object.getInt(EXTRA_INT2);
                        if (object.containsKey(EXTRA_TINT_LIST)) {
                            iconCompat.mTintList = (ColorStateList)object.getParcelable(EXTRA_TINT_LIST);
                        }
                        if (object.containsKey(EXTRA_TINT_MODE)) {
                            iconCompat.mTintMode = PorterDuff.Mode.valueOf((String)object.getString(EXTRA_TINT_MODE));
                        }
                        if (n == -1 || n == 1) break block3;
                        if (n == 2) break block4;
                        if (n == 3) break block5;
                        if (n == 4) break block4;
                        if (n != 5) {
                            object = new StringBuilder();
                            ((StringBuilder)object).append("Unknown type ");
                            ((StringBuilder)object).append(n);
                            Log.w((String)TAG, (String)((StringBuilder)object).toString());
                            return null;
                        }
                        break block3;
                    }
                    iconCompat.mObj1 = object.getByteArray(EXTRA_OBJ);
                    break block6;
                }
                iconCompat.mObj1 = object.getString(EXTRA_OBJ);
                break block6;
            }
            iconCompat.mObj1 = object.getParcelable(EXTRA_OBJ);
        }
        return iconCompat;
    }

    public static IconCompat createFromIcon(Icon icon) {
        Preconditions.checkNotNull(icon);
        int n = IconCompat.getType(icon);
        if (n != 2) {
            if (n != 4) {
                IconCompat iconCompat = new IconCompat(-1);
                iconCompat.mObj1 = icon;
                return iconCompat;
            }
            return IconCompat.createWithContentUri(IconCompat.getUri(icon));
        }
        return IconCompat.createWithResource(IconCompat.getResPackage(icon), IconCompat.getResId(icon));
    }

    static Bitmap createLegacyIconFromAdaptiveIcon(Bitmap bitmap, boolean bl) {
        int n = (int)((float)Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.6666667f);
        Bitmap bitmap2 = Bitmap.createBitmap((int)n, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap2);
        Paint paint = new Paint(3);
        float f = (float)n * 0.5f;
        float f2 = 0.9166667f * f;
        if (bl) {
            float f3 = (float)n * 0.010416667f;
            paint.setColor(0);
            paint.setShadowLayer(f3, 0.0f, (float)n * 0.020833334f, 0x3D000000);
            canvas.drawCircle(f, f, f2, paint);
            paint.setShadowLayer(f3, 0.0f, 0.0f, 0x1E000000);
            canvas.drawCircle(f, f, f2, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        Matrix matrix = new Matrix();
        matrix.setTranslate((float)(-(bitmap.getWidth() - n) / 2), (float)(-(bitmap.getHeight() - n) / 2));
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader((Shader)bitmapShader);
        canvas.drawCircle(f, f, f2, paint);
        canvas.setBitmap(null);
        return bitmap2;
    }

    public static IconCompat createWithAdaptiveBitmap(Bitmap bitmap) {
        if (bitmap != null) {
            IconCompat iconCompat = new IconCompat(5);
            iconCompat.mObj1 = bitmap;
            return iconCompat;
        }
        throw new IllegalArgumentException("Bitmap must not be null.");
    }

    public static IconCompat createWithBitmap(Bitmap bitmap) {
        if (bitmap != null) {
            IconCompat iconCompat = new IconCompat(1);
            iconCompat.mObj1 = bitmap;
            return iconCompat;
        }
        throw new IllegalArgumentException("Bitmap must not be null.");
    }

    public static IconCompat createWithContentUri(Uri uri) {
        if (uri != null) {
            return IconCompat.createWithContentUri(uri.toString());
        }
        throw new IllegalArgumentException("Uri must not be null.");
    }

    public static IconCompat createWithContentUri(String string2) {
        if (string2 != null) {
            IconCompat iconCompat = new IconCompat(4);
            iconCompat.mObj1 = string2;
            return iconCompat;
        }
        throw new IllegalArgumentException("Uri must not be null.");
    }

    public static IconCompat createWithData(byte[] byArray, int n, int n2) {
        if (byArray != null) {
            IconCompat iconCompat = new IconCompat(3);
            iconCompat.mObj1 = byArray;
            iconCompat.mInt1 = n;
            iconCompat.mInt2 = n2;
            return iconCompat;
        }
        throw new IllegalArgumentException("Data must not be null.");
    }

    public static IconCompat createWithResource(Context context, int n) {
        if (context != null) {
            IconCompat iconCompat = new IconCompat(2);
            iconCompat.mInt1 = n;
            iconCompat.mObj1 = context.getPackageName();
            return iconCompat;
        }
        throw new IllegalArgumentException("Context must not be null.");
    }

    public static IconCompat createWithResource(String string2, int n) {
        if (string2 != null) {
            IconCompat iconCompat = new IconCompat(2);
            iconCompat.mInt1 = n;
            iconCompat.mObj1 = string2;
            return iconCompat;
        }
        throw new IllegalArgumentException("Package must not be null.");
    }

    public static int getResId(Icon icon) {
        if (BuildCompat.isAtLeastP()) {
            return icon.getResId();
        }
        try {
            int n = (Integer)icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0]);
            return n;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            Log.e((String)TAG, (String)"Unable to get icon resource", (Throwable)noSuchMethodException);
            return 0;
        }
        catch (InvocationTargetException invocationTargetException) {
            Log.e((String)TAG, (String)"Unable to get icon resource", (Throwable)invocationTargetException);
            return 0;
        }
        catch (IllegalAccessException illegalAccessException) {
            Log.e((String)TAG, (String)"Unable to get icon resource", (Throwable)illegalAccessException);
            return 0;
        }
    }

    public static String getResPackage(Icon object) {
        if (BuildCompat.isAtLeastP()) {
            return object.getResPackage();
        }
        try {
            object = (String)object.getClass().getMethod("getResPackage", new Class[0]).invoke(object, new Object[0]);
            return object;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            Log.e((String)TAG, (String)"Unable to get icon package", (Throwable)noSuchMethodException);
            return null;
        }
        catch (InvocationTargetException invocationTargetException) {
            Log.e((String)TAG, (String)"Unable to get icon package", (Throwable)invocationTargetException);
            return null;
        }
        catch (IllegalAccessException illegalAccessException) {
            Log.e((String)TAG, (String)"Unable to get icon package", (Throwable)illegalAccessException);
            return null;
        }
    }

    public static int getType(Icon icon) {
        if (BuildCompat.isAtLeastP()) {
            return icon.getType();
        }
        try {
            int n = (Integer)icon.getClass().getMethod("getType", new Class[0]).invoke(icon, new Object[0]);
            return n;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to get icon type ");
            stringBuilder.append(icon);
            Log.e((String)TAG, (String)stringBuilder.toString(), (Throwable)noSuchMethodException);
            return -1;
        }
        catch (InvocationTargetException invocationTargetException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to get icon type ");
            stringBuilder.append(icon);
            Log.e((String)TAG, (String)stringBuilder.toString(), (Throwable)invocationTargetException);
            return -1;
        }
        catch (IllegalAccessException illegalAccessException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to get icon type ");
            stringBuilder.append(icon);
            Log.e((String)TAG, (String)stringBuilder.toString(), (Throwable)illegalAccessException);
            return -1;
        }
    }

    public static Uri getUri(Icon icon) {
        if (BuildCompat.isAtLeastP()) {
            return icon.getUri();
        }
        try {
            icon = (Uri)icon.getClass().getMethod("getUri", new Class[0]).invoke(icon, new Object[0]);
            return icon;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            Log.e((String)TAG, (String)"Unable to get icon uri", (Throwable)noSuchMethodException);
            return null;
        }
        catch (InvocationTargetException invocationTargetException) {
            Log.e((String)TAG, (String)"Unable to get icon uri", (Throwable)invocationTargetException);
            return null;
        }
        catch (IllegalAccessException illegalAccessException) {
            Log.e((String)TAG, (String)"Unable to get icon uri", (Throwable)illegalAccessException);
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Drawable loadDrawableInner(Context context) {
        String string2;
        int n = this.mType;
        if (n == 1) return new BitmapDrawable(context.getResources(), (Bitmap)this.mObj1);
        if (n != 2) {
            if (n == 3) return new BitmapDrawable(context.getResources(), BitmapFactory.decodeByteArray((byte[])((byte[])this.mObj1), (int)this.mInt1, (int)this.mInt2));
            if (n != 4) {
                if (n == 5) return new BitmapDrawable(context.getResources(), IconCompat.createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, false));
                return null;
            }
            Uri uri = Uri.parse((String)((String)this.mObj1));
            Object object = uri.getScheme();
            Object object2 = null;
            Object object3 = null;
            if (!"content".equals(object) && !"file".equals(object)) {
                try {
                    object = new File((String)this.mObj1);
                    object2 = object3 = new FileInputStream((File)object);
                }
                catch (FileNotFoundException fileNotFoundException) {
                    object3 = new StringBuilder();
                    ((StringBuilder)object3).append("Unable to load image from path: ");
                    ((StringBuilder)object3).append(uri);
                    Log.w((String)TAG, (String)((StringBuilder)object3).toString(), (Throwable)fileNotFoundException);
                }
            } else {
                try {
                    object2 = context.getContentResolver().openInputStream(uri);
                }
                catch (Exception exception) {
                    object2 = new StringBuilder();
                    ((StringBuilder)object2).append("Unable to load image from URI: ");
                    ((StringBuilder)object2).append(uri);
                    Log.w((String)TAG, (String)((StringBuilder)object2).toString(), (Throwable)exception);
                    object2 = object3;
                }
            }
            if (object2 == null) return null;
            return new BitmapDrawable(context.getResources(), BitmapFactory.decodeStream((InputStream)object2));
        }
        String string3 = string2 = (String)this.mObj1;
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string3 = context.getPackageName();
        }
        if ("android".equals(string3)) {
            string3 = Resources.getSystem();
        } else {
            PackageManager packageManager = context.getPackageManager();
            try {
                string2 = packageManager.getApplicationInfo(string3, 8192);
                if (string2 == null) return null;
                string3 = string2 = packageManager.getResourcesForApplication((ApplicationInfo)string2);
            }
            catch (PackageManager.NameNotFoundException nameNotFoundException) {
                Log.e((String)TAG, (String)String.format("Unable to find pkg=%s for icon %s", new Object[]{string3, this}), (Throwable)nameNotFoundException);
                return null;
            }
        }
        try {
            return ResourcesCompat.getDrawable((Resources)string3, this.mInt1, context.getTheme());
        }
        catch (RuntimeException runtimeException) {
            Log.e((String)TAG, (String)String.format("Unable to load resource 0x%08x from pkg=%s", this.mInt1, this.mObj1), (Throwable)runtimeException);
            return null;
        }
    }

    private static String typeToString(int n) {
        if (n != 1) {
            if (n != 2) {
                if (n != 3) {
                    if (n != 4) {
                        if (n != 5) {
                            return "UNKNOWN";
                        }
                        return "BITMAP_MASKABLE";
                    }
                    return "URI";
                }
                return "DATA";
            }
            return "RESOURCE";
        }
        return "BITMAP";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void addToShortcutIntent(Intent object, Drawable drawable2, Context context) {
        int n = this.mType;
        if (n != 1) {
            if (n != 2) {
                if (n != 5) {
                    throw new IllegalArgumentException("Icon type not supported for intent shortcuts");
                }
                context = IconCompat.createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, true);
            } else {
                try {
                    context = context.createPackageContext((String)this.mObj1, 0);
                    if (drawable2 == null) {
                        object.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", (Parcelable)Intent.ShortcutIconResource.fromContext((Context)context, (int)this.mInt1));
                        return;
                    }
                    Drawable drawable3 = ContextCompat.getDrawable(context, this.mInt1);
                    if (drawable3.getIntrinsicWidth() > 0 && drawable3.getIntrinsicHeight() > 0) {
                        context = Bitmap.createBitmap((int)drawable3.getIntrinsicWidth(), (int)drawable3.getIntrinsicHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
                    } else {
                        n = ((ActivityManager)context.getSystemService("activity")).getLauncherLargeIconSize();
                        context = Bitmap.createBitmap((int)n, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
                    }
                    drawable3.setBounds(0, 0, context.getWidth(), context.getHeight());
                    Canvas canvas = new Canvas((Bitmap)context);
                    drawable3.draw(canvas);
                }
                catch (PackageManager.NameNotFoundException nameNotFoundException) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("Can't find package ");
                    ((StringBuilder)object).append(this.mObj1);
                    throw new IllegalArgumentException(((StringBuilder)object).toString(), nameNotFoundException);
                }
            }
        } else {
            Bitmap bitmap = (Bitmap)this.mObj1;
            context = bitmap;
            if (drawable2 != null) {
                context = bitmap.copy(bitmap.getConfig(), true);
            }
        }
        if (drawable2 != null) {
            n = context.getWidth();
            int n2 = context.getHeight();
            drawable2.setBounds(n / 2, n2 / 2, n, n2);
            drawable2.draw(new Canvas((Bitmap)context));
        }
        object.putExtra("android.intent.extra.shortcut.ICON", (Parcelable)context);
    }

    public int getResId() {
        if (this.mType == -1 && Build.VERSION.SDK_INT >= 23) {
            return IconCompat.getResId((Icon)this.mObj1);
        }
        if (this.mType == 2) {
            return this.mInt1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("called getResId() on ");
        stringBuilder.append((Object)this);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public String getResPackage() {
        if (this.mType == -1 && Build.VERSION.SDK_INT >= 23) {
            return IconCompat.getResPackage((Icon)this.mObj1);
        }
        if (this.mType == 2) {
            return (String)this.mObj1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("called getResPackage() on ");
        stringBuilder.append((Object)this);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public int getType() {
        if (this.mType == -1 && Build.VERSION.SDK_INT >= 23) {
            return IconCompat.getType((Icon)this.mObj1);
        }
        return this.mType;
    }

    public Uri getUri() {
        if (this.mType == -1 && Build.VERSION.SDK_INT >= 23) {
            return IconCompat.getUri((Icon)this.mObj1);
        }
        return Uri.parse((String)((String)this.mObj1));
    }

    public Drawable loadDrawable(Context context) {
        if (Build.VERSION.SDK_INT >= 23) {
            return this.toIcon().loadDrawable(context);
        }
        if ((context = this.loadDrawableInner(context)) != null && (this.mTintList != null || this.mTintMode != DEFAULT_TINT_MODE)) {
            context.mutate();
            DrawableCompat.setTintList((Drawable)context, this.mTintList);
            DrawableCompat.setTintMode((Drawable)context, this.mTintMode);
        }
        return context;
    }

    public void onPostParceling() {
        block12: {
            block11: {
                block6: {
                    Object object;
                    block7: {
                        block8: {
                            block9: {
                                block10: {
                                    this.mTintMode = PorterDuff.Mode.valueOf((String)this.mTintModeStr);
                                    int n = this.mType;
                                    if (n == -1) break block6;
                                    if (n == 1) break block7;
                                    if (n == 2) break block8;
                                    if (n == 3) break block9;
                                    if (n == 4) break block10;
                                    if (n == 5) break block7;
                                    break block11;
                                }
                                this.mObj1 = Uri.parse((String)new String(this.mData, Charset.forName("UTF-16")));
                                break block11;
                            }
                            this.mObj1 = this.mData;
                            break block11;
                        }
                        this.mObj1 = new String(this.mData, Charset.forName("UTF-16"));
                        break block11;
                    }
                    if ((object = this.mParcelable) != null) {
                        this.mObj1 = object;
                    } else {
                        object = this.mData;
                        this.mObj1 = object;
                        this.mType = 3;
                        this.mInt1 = 0;
                        this.mInt2 = ((Parcelable)object).length;
                    }
                    break block11;
                }
                Parcelable parcelable = this.mParcelable;
                if (parcelable == null) break block12;
                this.mObj1 = parcelable;
            }
            return;
        }
        throw new IllegalArgumentException("Invalid icon");
    }

    public void onPreParceling(boolean bl) {
        block12: {
            block11: {
                block6: {
                    block7: {
                        block8: {
                            block9: {
                                block10: {
                                    this.mTintModeStr = this.mTintMode.name();
                                    int n = this.mType;
                                    if (n == -1) break block6;
                                    if (n == 1) break block7;
                                    if (n == 2) break block8;
                                    if (n == 3) break block9;
                                    if (n == 4) break block10;
                                    if (n == 5) break block7;
                                    break block11;
                                }
                                this.mData = this.mObj1.toString().getBytes(Charset.forName("UTF-16"));
                                break block11;
                            }
                            this.mData = (byte[])this.mObj1;
                            break block11;
                        }
                        this.mData = ((String)this.mObj1).getBytes(Charset.forName("UTF-16"));
                        break block11;
                    }
                    if (bl) {
                        Bitmap bitmap = (Bitmap)this.mObj1;
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 90, (OutputStream)byteArrayOutputStream);
                        this.mData = byteArrayOutputStream.toByteArray();
                    } else {
                        this.mParcelable = (Parcelable)this.mObj1;
                    }
                    break block11;
                }
                if (bl) break block12;
                this.mParcelable = (Parcelable)this.mObj1;
            }
            return;
        }
        throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
    }

    public IconCompat setTint(int n) {
        return this.setTintList(ColorStateList.valueOf((int)n));
    }

    public IconCompat setTintList(ColorStateList colorStateList) {
        this.mTintList = colorStateList;
        return this;
    }

    public IconCompat setTintMode(PorterDuff.Mode mode) {
        this.mTintMode = mode;
        return this;
    }

    public Bundle toBundle() {
        Bundle bundle;
        block7: {
            block3: {
                block4: {
                    block5: {
                        block6: {
                            bundle = new Bundle();
                            int n = this.mType;
                            if (n == -1) break block3;
                            if (n == 1) break block4;
                            if (n == 2) break block5;
                            if (n == 3) break block6;
                            if (n == 4) break block5;
                            if (n != 5) {
                                throw new IllegalArgumentException("Invalid icon");
                            }
                            break block4;
                        }
                        bundle.putByteArray(EXTRA_OBJ, (byte[])this.mObj1);
                        break block7;
                    }
                    bundle.putString(EXTRA_OBJ, (String)this.mObj1);
                    break block7;
                }
                bundle.putParcelable(EXTRA_OBJ, (Parcelable)((Bitmap)this.mObj1));
                break block7;
            }
            bundle.putParcelable(EXTRA_OBJ, (Parcelable)this.mObj1);
        }
        bundle.putInt(EXTRA_TYPE, this.mType);
        bundle.putInt(EXTRA_INT1, this.mInt1);
        bundle.putInt(EXTRA_INT2, this.mInt2);
        ColorStateList colorStateList = this.mTintList;
        if (colorStateList != null) {
            bundle.putParcelable(EXTRA_TINT_LIST, (Parcelable)colorStateList);
        }
        if ((colorStateList = this.mTintMode) != DEFAULT_TINT_MODE) {
            bundle.putString(EXTRA_TINT_MODE, colorStateList.name());
        }
        return bundle;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Icon toIcon() {
        Icon icon;
        int n = this.mType;
        if (n == -1) return (Icon)this.mObj1;
        if (n != 1) {
            if (n != 2) {
                if (n != 3) {
                    if (n != 4) {
                        if (n != 5) throw new IllegalArgumentException("Unknown type");
                        icon = Build.VERSION.SDK_INT >= 26 ? Icon.createWithAdaptiveBitmap((Bitmap)((Bitmap)this.mObj1)) : Icon.createWithBitmap((Bitmap)IconCompat.createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1, false));
                    } else {
                        icon = Icon.createWithContentUri((String)((String)this.mObj1));
                    }
                } else {
                    icon = Icon.createWithData((byte[])((byte[])this.mObj1), (int)this.mInt1, (int)this.mInt2);
                }
            } else {
                icon = Icon.createWithResource((String)((String)this.mObj1), (int)this.mInt1);
            }
        } else {
            icon = Icon.createWithBitmap((Bitmap)((Bitmap)this.mObj1));
        }
        ColorStateList colorStateList = this.mTintList;
        if (colorStateList != null) {
            icon.setTintList(colorStateList);
        }
        if ((colorStateList = this.mTintMode) == DEFAULT_TINT_MODE) return icon;
        icon.setTintMode((PorterDuff.Mode)colorStateList);
        return icon;
    }

    public String toString() {
        StringBuilder stringBuilder;
        block8: {
            block4: {
                block5: {
                    block6: {
                        block7: {
                            if (this.mType == -1) {
                                return String.valueOf(this.mObj1);
                            }
                            stringBuilder = new StringBuilder("Icon(typ=").append(IconCompat.typeToString(this.mType));
                            int n = this.mType;
                            if (n == 1) break block4;
                            if (n == 2) break block5;
                            if (n == 3) break block6;
                            if (n == 4) break block7;
                            if (n == 5) break block4;
                            break block8;
                        }
                        stringBuilder.append(" uri=");
                        stringBuilder.append(this.mObj1);
                        break block8;
                    }
                    stringBuilder.append(" len=");
                    stringBuilder.append(this.mInt1);
                    if (this.mInt2 != 0) {
                        stringBuilder.append(" off=");
                        stringBuilder.append(this.mInt2);
                    }
                    break block8;
                }
                stringBuilder.append(" pkg=");
                stringBuilder.append(this.getResPackage());
                stringBuilder.append(" id=");
                stringBuilder.append(String.format("0x%08x", this.getResId()));
                break block8;
            }
            stringBuilder.append(" size=");
            stringBuilder.append(((Bitmap)this.mObj1).getWidth());
            stringBuilder.append("x");
            stringBuilder.append(((Bitmap)this.mObj1).getHeight());
        }
        if (this.mTintList != null) {
            stringBuilder.append(" tint=");
            stringBuilder.append(this.mTintList);
        }
        if (this.mTintMode != DEFAULT_TINT_MODE) {
            stringBuilder.append(" mode=");
            stringBuilder.append(this.mTintMode);
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface IconType {
    }
}

