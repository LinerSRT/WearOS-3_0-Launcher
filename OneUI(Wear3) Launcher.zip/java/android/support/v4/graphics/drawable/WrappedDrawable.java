/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 */
package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

public interface WrappedDrawable {
    public Drawable getWrappedDrawable();

    public void setWrappedDrawable(Drawable var1);
}

