/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  android.util.Log
 */
package android.support.v4.graphics;

import android.graphics.Path;
import android.util.Log;
import java.util.ArrayList;

public class PathParser {
    private static final String LOGTAG = "PathParser";

    private PathParser() {
    }

    private static void addNode(ArrayList<PathDataNode> arrayList, char c, float[] fArray) {
        arrayList.add(new PathDataNode(c, fArray));
    }

    public static boolean canMorph(PathDataNode[] pathDataNodeArray, PathDataNode[] pathDataNodeArray2) {
        if (pathDataNodeArray != null && pathDataNodeArray2 != null) {
            if (pathDataNodeArray.length != pathDataNodeArray2.length) {
                return false;
            }
            for (int i = 0; i < pathDataNodeArray.length; ++i) {
                if (pathDataNodeArray[i].mType == pathDataNodeArray2[i].mType && pathDataNodeArray[i].mParams.length == pathDataNodeArray2[i].mParams.length) {
                    continue;
                }
                return false;
            }
            return true;
        }
        return false;
    }

    static float[] copyOfRange(float[] fArray, int n, int n2) {
        if (n <= n2) {
            int n3 = fArray.length;
            if (n >= 0 && n <= n3) {
                n3 = Math.min(n2 -= n, n3 - n);
                float[] fArray2 = new float[n2];
                System.arraycopy(fArray, n, fArray2, 0, n3);
                return fArray2;
            }
            throw new ArrayIndexOutOfBoundsException();
        }
        throw new IllegalArgumentException();
    }

    public static PathDataNode[] createNodesFromPathData(String string2) {
        if (string2 == null) {
            return null;
        }
        int n = 0;
        int n2 = 1;
        ArrayList<PathDataNode> arrayList = new ArrayList<PathDataNode>();
        while (n2 < string2.length()) {
            String string3 = string2.substring(n, n2 = PathParser.nextStart(string2, n2)).trim();
            if (string3.length() > 0) {
                float[] fArray = PathParser.getFloats(string3);
                PathParser.addNode(arrayList, string3.charAt(0), fArray);
            }
            n = n2++;
        }
        if (n2 - n == 1 && n < string2.length()) {
            PathParser.addNode(arrayList, string2.charAt(n), new float[0]);
        }
        return arrayList.toArray(new PathDataNode[arrayList.size()]);
    }

    public static Path createPathFromPathData(String string2) {
        Object object = new Path();
        PathDataNode[] pathDataNodeArray = PathParser.createNodesFromPathData(string2);
        if (pathDataNodeArray != null) {
            try {
                PathDataNode.nodesToPath(pathDataNodeArray, (Path)object);
                return object;
            }
            catch (RuntimeException runtimeException) {
                object = new StringBuilder();
                ((StringBuilder)object).append("Error in parsing ");
                ((StringBuilder)object).append(string2);
                throw new RuntimeException(((StringBuilder)object).toString(), runtimeException);
            }
        }
        return null;
    }

    public static PathDataNode[] deepCopyNodes(PathDataNode[] pathDataNodeArray) {
        if (pathDataNodeArray == null) {
            return null;
        }
        PathDataNode[] pathDataNodeArray2 = new PathDataNode[pathDataNodeArray.length];
        for (int i = 0; i < pathDataNodeArray.length; ++i) {
            pathDataNodeArray2[i] = new PathDataNode(pathDataNodeArray[i]);
        }
        return pathDataNodeArray2;
    }

    /*
     * Unable to fully structure code
     */
    private static void extract(String var0, int var1_1, ExtractFloatResult var2_2) {
        var4_4 = '\u0000';
        var2_2.mEndWithNegOrDot = false;
        var5_5 = false;
        var6_6 = false;
        for (var3_3 = var1_1; var3_3 < var0.length(); ++var3_3) {
            var7_7 = false;
            var8_8 = var0.charAt(var3_3);
            if (var8_8 == ' ') ** GOTO lbl-1000
            if (var8_8 == 'E' || var8_8 == 'e') ** GOTO lbl41
            switch (var8_8) {
                default: {
                    var8_8 = var4_4;
                    var9_9 = var5_5;
                    var10_10 = var7_7;
                    break;
                }
                case '.': {
                    if (!var5_5) {
                        var9_9 = true;
                        var8_8 = var4_4;
                        var10_10 = var7_7;
                        break;
                    }
                    var8_8 = '\u0001';
                    var2_2.mEndWithNegOrDot = true;
                    var9_9 = var5_5;
                    var10_10 = var7_7;
                    break;
                }
                case '-': {
                    var8_8 = var4_4;
                    var9_9 = var5_5;
                    var10_10 = var7_7;
                    if (var3_3 == var1_1) break;
                    var8_8 = var4_4;
                    var9_9 = var5_5;
                    var10_10 = var7_7;
                    if (var6_6) break;
                    var8_8 = '\u0001';
                    var2_2.mEndWithNegOrDot = true;
                    var9_9 = var5_5;
                    var10_10 = var7_7;
                    break;
                }
lbl41:
                // 1 sources

                var10_10 = true;
                var8_8 = var4_4;
                var9_9 = var5_5;
                break;
                case ',': lbl-1000:
                // 2 sources

                {
                    var8_8 = '\u0001';
                    var10_10 = var7_7;
                    var9_9 = var5_5;
                }
            }
            if (var8_8 != '\u0000') break;
            var4_4 = var8_8;
            var5_5 = var9_9;
            var6_6 = var10_10;
        }
        var2_2.mEndPosition = var3_3;
    }

    private static float[] getFloats(String string2) {
        if (string2.charAt(0) != 'z' && string2.charAt(0) != 'Z') {
            Object object = new float[string2.length()];
            int n = 0;
            int n2 = 1;
            Object object2 = new ExtractFloatResult();
            int n3 = string2.length();
            while (n2 < n3) {
                int n4;
                int n5;
                block10: {
                    PathParser.extract(string2, n2, (ExtractFloatResult)object2);
                    n5 = ((ExtractFloatResult)object2).mEndPosition;
                    n4 = n;
                    if (n2 >= n5) break block10;
                    object[n] = Float.parseFloat(string2.substring(n2, n5));
                    n4 = n + 1;
                }
                if (((ExtractFloatResult)object2).mEndWithNegOrDot) {
                    n2 = n5;
                    n = n4;
                    continue;
                }
                n2 = n5 + 1;
                n = n4;
            }
            try {
                object2 = PathParser.copyOfRange((float[])object, 0, n);
                return object2;
            }
            catch (NumberFormatException numberFormatException) {
                object = new StringBuilder();
                ((StringBuilder)object).append("error in parsing \"");
                ((StringBuilder)object).append(string2);
                ((StringBuilder)object).append("\"");
                throw new RuntimeException(((StringBuilder)object).toString(), numberFormatException);
            }
        }
        return new float[0];
    }

    private static int nextStart(String string2, int n) {
        while (n < string2.length()) {
            char c = string2.charAt(n);
            if (((c - 65) * (c - 90) <= 0 || (c - 97) * (c - 122) <= 0) && c != 'e' && c != 'E') {
                return n;
            }
            ++n;
        }
        return n;
    }

    public static void updateNodes(PathDataNode[] pathDataNodeArray, PathDataNode[] pathDataNodeArray2) {
        for (int i = 0; i < pathDataNodeArray2.length; ++i) {
            pathDataNodeArray[i].mType = pathDataNodeArray2[i].mType;
            for (int j = 0; j < pathDataNodeArray2[i].mParams.length; ++j) {
                pathDataNodeArray[i].mParams[j] = pathDataNodeArray2[i].mParams[j];
            }
        }
    }

    private static class ExtractFloatResult {
        int mEndPosition;
        boolean mEndWithNegOrDot;

        ExtractFloatResult() {
        }
    }

    public static class PathDataNode {
        public float[] mParams;
        public char mType;

        PathDataNode(char c, float[] fArray) {
            this.mType = c;
            this.mParams = fArray;
        }

        PathDataNode(PathDataNode object) {
            this.mType = ((PathDataNode)object).mType;
            object = ((PathDataNode)object).mParams;
            this.mParams = PathParser.copyOfRange((float[])object, 0, ((Object)object).length);
        }

        private static void addCommand(Path path, float[] fArray, char c, char c2, float[] fArray2) {
            int n;
            float f = fArray[0];
            float f2 = fArray[1];
            float f3 = fArray[2];
            float f4 = fArray[3];
            float f5 = fArray[4];
            float f6 = fArray[5];
            switch (c2) {
                default: {
                    n = 2;
                    break;
                }
                case 'Z': 
                case 'z': {
                    path.close();
                    f = f5;
                    f2 = f6;
                    f3 = f5;
                    f4 = f6;
                    path.moveTo(f, f2);
                    n = 2;
                    break;
                }
                case 'Q': 
                case 'S': 
                case 'q': 
                case 's': {
                    n = 4;
                    break;
                }
                case 'L': 
                case 'M': 
                case 'T': 
                case 'l': 
                case 'm': 
                case 't': {
                    n = 2;
                    break;
                }
                case 'H': 
                case 'V': 
                case 'h': 
                case 'v': {
                    n = 1;
                    break;
                }
                case 'C': 
                case 'c': {
                    n = 6;
                    break;
                }
                case 'A': 
                case 'a': {
                    n = 7;
                }
            }
            char c3 = '\u0000';
            float f7 = f3;
            float f8 = f4;
            f4 = f6;
            f6 = f2;
            f3 = f5;
            char c4 = c;
            c = c3;
            f5 = f;
            while (true) {
                boolean bl;
                boolean bl2;
                float f9;
                c3 = c2;
                if (c >= fArray2.length) break;
                if (c3 != 'A') {
                    if (c3 != 'C') {
                        if (c3 != 'H') {
                            if (c3 != 'Q') {
                                if (c3 != 'V') {
                                    if (c3 != 'a') {
                                        if (c3 != 'c') {
                                            if (c3 != 'h') {
                                                if (c3 != 'q') {
                                                    if (c3 != 'v') {
                                                        if (c3 != 'L') {
                                                            if (c3 != 'M') {
                                                                if (c3 != 'S') {
                                                                    if (c3 != 'T') {
                                                                        if (c3 != 'l') {
                                                                            if (c3 != 'm') {
                                                                                if (c3 != 's') {
                                                                                    if (c3 != 't') {
                                                                                        f2 = f7;
                                                                                        f = f8;
                                                                                    } else {
                                                                                        f = 0.0f;
                                                                                        f2 = 0.0f;
                                                                                        if (c4 == 'q' || c4 == 't' || c4 == 'Q' || c4 == 'T') {
                                                                                            f = f5 - f7;
                                                                                            f2 = f6 - f8;
                                                                                        }
                                                                                        path.rQuadTo(f, f2, fArray2[c + '\u0000'], fArray2[c + '\u0001']);
                                                                                        f8 = f5 + fArray2[c + '\u0000'];
                                                                                        f7 = f6 + fArray2[c + '\u0001'];
                                                                                        f = f5 + f;
                                                                                        f9 = f6 + f2;
                                                                                        f6 = f7;
                                                                                        f5 = f8;
                                                                                        f2 = f;
                                                                                        f = f9;
                                                                                    }
                                                                                } else {
                                                                                    if (c4 != 'c' && c4 != 's' && c4 != 'C' && c4 != 'S') {
                                                                                        f = 0.0f;
                                                                                        f2 = 0.0f;
                                                                                    } else {
                                                                                        f = f5 - f7;
                                                                                        f2 = f6 - f8;
                                                                                    }
                                                                                    path.rCubicTo(f, f2, fArray2[c + '\u0000'], fArray2[c + '\u0001'], fArray2[c + 2], fArray2[c + 3]);
                                                                                    f8 = fArray2[c + '\u0000'];
                                                                                    f = fArray2[c + '\u0001'];
                                                                                    f2 = f5 + fArray2[c + 2];
                                                                                    f7 = fArray2[c + 3];
                                                                                    f = f6 + f;
                                                                                    f6 = f7 + f6;
                                                                                    f5 = f2;
                                                                                    f2 = f8 += f5;
                                                                                }
                                                                            } else {
                                                                                f5 += fArray2[c + '\u0000'];
                                                                                f6 += fArray2[c + '\u0001'];
                                                                                if (c > '\u0000') {
                                                                                    path.rLineTo(fArray2[c + '\u0000'], fArray2[c + '\u0001']);
                                                                                    f2 = f7;
                                                                                    f = f8;
                                                                                } else {
                                                                                    path.rMoveTo(fArray2[c + '\u0000'], fArray2[c + '\u0001']);
                                                                                    f3 = f5;
                                                                                    f4 = f6;
                                                                                    f2 = f7;
                                                                                    f = f8;
                                                                                }
                                                                            }
                                                                        } else {
                                                                            path.rLineTo(fArray2[c + '\u0000'], fArray2[c + '\u0001']);
                                                                            f5 += fArray2[c + '\u0000'];
                                                                            f6 += fArray2[c + '\u0001'];
                                                                            f2 = f7;
                                                                            f = f8;
                                                                        }
                                                                    } else {
                                                                        f = f5;
                                                                        f2 = f6;
                                                                        if (c4 == 'q' || c4 == 't' || c4 == 'Q' || c4 == 'T') {
                                                                            f = f5 * 2.0f - f7;
                                                                            f2 = f6 * 2.0f - f8;
                                                                        }
                                                                        path.quadTo(f, f2, fArray2[c + '\u0000'], fArray2[c + '\u0001']);
                                                                        f5 = fArray2[c + '\u0000'];
                                                                        f6 = fArray2[c + '\u0001'];
                                                                        f8 = f2;
                                                                        f2 = f;
                                                                        f = f8;
                                                                    }
                                                                } else {
                                                                    if (c4 == 'c' || c4 == 's' || c4 == 'C' || c4 == 'S') {
                                                                        f5 = f5 * 2.0f - f7;
                                                                        f6 = f6 * 2.0f - f8;
                                                                    }
                                                                    path.cubicTo(f5, f6, fArray2[c + '\u0000'], fArray2[c + '\u0001'], fArray2[c + 2], fArray2[c + 3]);
                                                                    f2 = fArray2[c + '\u0000'];
                                                                    f = fArray2[c + '\u0001'];
                                                                    f5 = fArray2[c + 2];
                                                                    f6 = fArray2[c + 3];
                                                                }
                                                            } else {
                                                                f5 = fArray2[c + '\u0000'];
                                                                f6 = fArray2[c + '\u0001'];
                                                                if (c > '\u0000') {
                                                                    path.lineTo(fArray2[c + '\u0000'], fArray2[c + '\u0001']);
                                                                    f2 = f7;
                                                                    f = f8;
                                                                } else {
                                                                    path.moveTo(fArray2[c + '\u0000'], fArray2[c + '\u0001']);
                                                                    f2 = f5;
                                                                    f = f6;
                                                                    f3 = f5;
                                                                    f4 = f6;
                                                                    f6 = f;
                                                                    f5 = f2;
                                                                    f2 = f7;
                                                                    f = f8;
                                                                }
                                                            }
                                                        } else {
                                                            path.lineTo(fArray2[c + '\u0000'], fArray2[c + '\u0001']);
                                                            f5 = fArray2[c + '\u0000'];
                                                            f6 = fArray2[c + '\u0001'];
                                                            f2 = f7;
                                                            f = f8;
                                                        }
                                                    } else {
                                                        path.rLineTo(0.0f, fArray2[c + '\u0000']);
                                                        f6 += fArray2[c + '\u0000'];
                                                        f2 = f7;
                                                        f = f8;
                                                    }
                                                } else {
                                                    path.rQuadTo(fArray2[c + '\u0000'], fArray2[c + '\u0001'], fArray2[c + 2], fArray2[c + 3]);
                                                    f = fArray2[c + '\u0000'];
                                                    f8 = fArray2[c + '\u0001'];
                                                    f2 = f5 + fArray2[c + 2];
                                                    f7 = fArray2[c + 3];
                                                    f8 = f6 + f8;
                                                    f6 = f7 + f6;
                                                    f5 = f2;
                                                    f2 = f += f5;
                                                    f = f8;
                                                }
                                            } else {
                                                path.rLineTo(fArray2[c + '\u0000'], 0.0f);
                                                f5 += fArray2[c + '\u0000'];
                                                f2 = f7;
                                                f = f8;
                                            }
                                        } else {
                                            path.rCubicTo(fArray2[c + '\u0000'], fArray2[c + '\u0001'], fArray2[c + 2], fArray2[c + 3], fArray2[c + 4], fArray2[c + 5]);
                                            f = fArray2[c + 2];
                                            f8 = fArray2[c + 3];
                                            f2 = f5 + fArray2[c + 4];
                                            f7 = fArray2[c + 5];
                                            f8 = f6 + f8;
                                            f6 = f7 + f6;
                                            f5 = f2;
                                            f2 = f += f5;
                                            f = f8;
                                        }
                                    } else {
                                        f8 = fArray2[c + 5];
                                        f9 = fArray2[c + 6];
                                        f7 = fArray2[c + '\u0000'];
                                        f = fArray2[c + '\u0001'];
                                        f2 = fArray2[c + 2];
                                        bl2 = fArray2[c + 3] != 0.0f;
                                        bl = fArray2[c + 4] != 0.0f;
                                        c4 = c;
                                        PathDataNode.drawArc(path, f5, f6, f8 + f5, f9 + f6, f7, f, f2, bl2, bl);
                                        f2 = f5 += fArray2[c4 + 5];
                                        f = f6 += fArray2[c4 + 6];
                                    }
                                } else {
                                    c4 = c;
                                    path.lineTo(f5, fArray2[c4 + '\u0000']);
                                    f6 = fArray2[c4 + '\u0000'];
                                    f2 = f7;
                                    f = f8;
                                }
                            } else {
                                c4 = c;
                                path.quadTo(fArray2[c4 + '\u0000'], fArray2[c4 + '\u0001'], fArray2[c4 + 2], fArray2[c4 + 3]);
                                f2 = fArray2[c4 + '\u0000'];
                                f = fArray2[c4 + '\u0001'];
                                f5 = fArray2[c4 + 2];
                                f6 = fArray2[c4 + 3];
                            }
                        } else {
                            c4 = c;
                            path.lineTo(fArray2[c4 + '\u0000'], f6);
                            f5 = fArray2[c4 + '\u0000'];
                            f2 = f7;
                            f = f8;
                        }
                    } else {
                        c4 = c;
                        path.cubicTo(fArray2[c4 + '\u0000'], fArray2[c4 + '\u0001'], fArray2[c4 + 2], fArray2[c4 + 3], fArray2[c4 + 4], fArray2[c4 + 5]);
                        f5 = fArray2[c4 + 4];
                        f6 = fArray2[c4 + 5];
                        f2 = fArray2[c4 + 2];
                        f = fArray2[c4 + 3];
                    }
                } else {
                    c4 = c;
                    f2 = fArray2[c4 + 5];
                    f7 = fArray2[c4 + 6];
                    f8 = fArray2[c4 + '\u0000'];
                    f = fArray2[c4 + '\u0001'];
                    f9 = fArray2[c4 + 2];
                    bl2 = fArray2[c4 + 3] != 0.0f;
                    bl = fArray2[c4 + 4] != 0.0f;
                    PathDataNode.drawArc(path, f5, f6, f2, f7, f8, f, f9, bl2, bl);
                    f2 = fArray2[c4 + 5];
                    f = fArray2[c4 + 6];
                    f5 = f2;
                    f6 = f;
                }
                c4 = c2;
                c = (char)(c + n);
                f7 = f2;
                f8 = f;
            }
            fArray[0] = f5;
            fArray[1] = f6;
            fArray[2] = f7;
            fArray[3] = f8;
            fArray[4] = f3;
            fArray[5] = f4;
        }

        private static void arcToBezier(Path path, double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8, double d9) {
            double d10 = d3;
            int n = (int)Math.ceil(Math.abs(d9 * 4.0 / Math.PI));
            double d11 = Math.cos(d7);
            double d12 = Math.sin(d7);
            d7 = Math.cos(d8);
            double d13 = Math.sin(d8);
            double d14 = -d10;
            d10 = -d10 * d12 * d13 + d4 * d11 * d7;
            double d15 = d9 / (double)n;
            int n2 = 0;
            double d16 = d5;
            d14 = d14 * d11 * d13 - d4 * d12 * d7;
            double d17 = d8;
            d9 = d10;
            d10 = d6;
            d8 = d13;
            d5 = d12;
            d6 = d11;
            d11 = d15;
            while (true) {
                double d18 = d3;
                if (n2 >= n) break;
                double d19 = d17 + d11;
                double d20 = Math.sin(d19);
                double d21 = Math.cos(d19);
                d15 = d + d18 * d6 * d21 - d4 * d5 * d20;
                d13 = d2 + d18 * d5 * d21 + d4 * d6 * d20;
                d12 = -d18 * d6 * d20 - d4 * d5 * d21;
                d18 = -d18 * d5 * d20 + d4 * d6 * d21;
                d21 = Math.tan((d19 - d17) / 2.0);
                d17 = Math.sin(d19 - d17) * (Math.sqrt(d21 * 3.0 * d21 + 4.0) - 1.0) / 3.0;
                path.rLineTo(0.0f, 0.0f);
                path.cubicTo((float)(d16 + d17 * d14), (float)(d10 + d17 * d9), (float)(d15 - d17 * d12), (float)(d13 - d17 * d18), (float)d15, (float)d13);
                d17 = d19;
                d10 = d13;
                d14 = d12;
                d9 = d18;
                d16 = d15;
                ++n2;
            }
        }

        private static void drawArc(Path path, float f, float f2, float f3, float f4, float f5, float f6, float f7, boolean bl, boolean bl2) {
            double d = Math.toRadians(f7);
            double d2 = Math.cos(d);
            double d3 = Math.sin(d);
            double d4 = ((double)f * d2 + (double)f2 * d3) / (double)f5;
            double d5 = ((double)(-f) * d3 + (double)f2 * d2) / (double)f6;
            double d6 = ((double)f3 * d2 + (double)f4 * d3) / (double)f5;
            double d7 = ((double)(-f3) * d3 + (double)f4 * d2) / (double)f6;
            double d8 = d4 - d6;
            double d9 = d5 - d7;
            double d10 = (d4 + d6) / 2.0;
            double d11 = (d5 + d7) / 2.0;
            double d12 = d8 * d8 + d9 * d9;
            if (d12 == 0.0) {
                Log.w((String)PathParser.LOGTAG, (String)" Points are coincident");
                return;
            }
            double d13 = 1.0 / d12 - 0.25;
            if (d13 < 0.0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Points are too far apart ");
                stringBuilder.append(d12);
                Log.w((String)PathParser.LOGTAG, (String)stringBuilder.toString());
                float f8 = (float)(Math.sqrt(d12) / 1.99999);
                PathDataNode.drawArc(path, f, f2, f3, f4, f5 * f8, f6 * f8, f7, bl, bl2);
                return;
            }
            d12 = Math.sqrt(d13);
            d8 = d12 * d8;
            d9 = d12 * d9;
            if (bl == bl2) {
                d10 -= d9;
                d11 += d8;
            } else {
                d10 += d9;
                d11 -= d8;
            }
            d4 = Math.atan2(d5 - d11, d4 - d10);
            d6 = Math.atan2(d7 - d11, d6 - d10) - d4;
            bl = d6 >= 0.0;
            d7 = d6;
            if (bl2 != bl) {
                d7 = d6 > 0.0 ? d6 - Math.PI * 2 : d6 + Math.PI * 2;
            }
            d11 = (double)f6 * d11;
            PathDataNode.arcToBezier(path, (d10 *= (double)f5) * d2 - d11 * d3, d10 * d3 + d11 * d2, f5, f6, f, f2, d, d4, d7);
        }

        public static void nodesToPath(PathDataNode[] pathDataNodeArray, Path path) {
            float[] fArray = new float[6];
            char c = 'm';
            char c2 = c;
            for (int i = 0; i < pathDataNodeArray.length; ++i) {
                PathDataNode.addCommand(path, fArray, c2, pathDataNodeArray[i].mType, pathDataNodeArray[i].mParams);
                c = pathDataNodeArray[i].mType;
                c2 = c;
            }
        }

        public void interpolatePathDataNode(PathDataNode pathDataNode, PathDataNode pathDataNode2, float f) {
            float[] fArray;
            for (int i = 0; i < (fArray = pathDataNode.mParams).length; ++i) {
                this.mParams[i] = fArray[i] * (1.0f - f) + pathDataNode2.mParams[i] * f;
            }
        }
    }
}

