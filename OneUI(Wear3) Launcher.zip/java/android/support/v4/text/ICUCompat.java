/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 *  android.util.Log
 */
package android.support.v4.text;

import android.os.Build;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

public final class ICUCompat {
    private static final String TAG = "ICUCompat";
    private static Method sAddLikelySubtagsMethod;
    private static Method sGetScriptMethod;

    static {
        block6: {
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    sAddLikelySubtagsMethod = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", Locale.class);
                }
                catch (Exception exception) {
                    throw new IllegalStateException(exception);
                }
            }
            Class<?> clazz = Class.forName("libcore.icu.ICU");
            if (clazz == null) break block6;
            try {
                sGetScriptMethod = clazz.getMethod("getScript", String.class);
                sAddLikelySubtagsMethod = clazz.getMethod("addLikelySubtags", String.class);
            }
            catch (Exception exception) {
                sGetScriptMethod = null;
                sAddLikelySubtagsMethod = null;
                Log.w((String)TAG, (Throwable)exception);
            }
        }
    }

    private ICUCompat() {
    }

    private static String addLikelySubtags(Locale object) {
        object = ((Locale)object).toString();
        try {
            if (sAddLikelySubtagsMethod != null) {
                String string2 = (String)sAddLikelySubtagsMethod.invoke(null, object);
                return string2;
            }
        }
        catch (InvocationTargetException invocationTargetException) {
            Log.w((String)TAG, (Throwable)invocationTargetException);
        }
        catch (IllegalAccessException illegalAccessException) {
            Log.w((String)TAG, (Throwable)illegalAccessException);
        }
        return object;
    }

    private static String getScript(String string2) {
        try {
            if (sGetScriptMethod != null) {
                string2 = (String)sGetScriptMethod.invoke(null, string2);
                return string2;
            }
        }
        catch (InvocationTargetException invocationTargetException) {
            Log.w((String)TAG, (Throwable)invocationTargetException);
        }
        catch (IllegalAccessException illegalAccessException) {
            Log.w((String)TAG, (Throwable)illegalAccessException);
        }
        return null;
    }

    public static String maximizeAndGetScript(Locale object) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                String string2 = ((Locale)sAddLikelySubtagsMethod.invoke(null, object)).getScript();
                return string2;
            }
            catch (IllegalAccessException illegalAccessException) {
                Log.w((String)TAG, (Throwable)illegalAccessException);
            }
            catch (InvocationTargetException invocationTargetException) {
                Log.w((String)TAG, (Throwable)invocationTargetException);
            }
            return ((Locale)object).getScript();
        }
        if ((object = ICUCompat.addLikelySubtags((Locale)object)) != null) {
            return ICUCompat.getScript((String)object);
        }
        return null;
    }
}

