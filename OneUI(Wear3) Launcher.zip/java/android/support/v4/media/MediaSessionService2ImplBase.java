/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.IBinder
 *  android.util.Log
 */
package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaSessionService2;
import android.support.v4.media.SessionToken2;
import android.util.Log;

class MediaSessionService2ImplBase
implements MediaSessionService2.SupportLibraryImpl {
    private static final boolean DEBUG = true;
    private static final String TAG = "MSS2ImplBase";
    private final Object mLock = new Object();
    private MediaSession2 mSession;

    MediaSessionService2ImplBase() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaSession2 getSession() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mSession;
        }
    }

    @Override
    public int getSessionType() {
        return 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public IBinder onBind(Intent object) {
        if (!"android.media.MediaSessionService2".equals(object.getAction())) return null;
        object = this.mLock;
        synchronized (object) {
            if (this.mSession != null) {
                return this.mSession.getSessionBinder();
            }
            Log.d((String)TAG, (String)"Session hasn't created");
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onCreate(MediaSessionService2 object) {
        SessionToken2 sessionToken2 = new SessionToken2((Context)object, new ComponentName((Context)object, object.getClass().getName()));
        if (sessionToken2.getType() != this.getSessionType()) {
            object = new StringBuilder();
            ((StringBuilder)object).append("Expected session type ");
            ((StringBuilder)object).append(this.getSessionType());
            ((StringBuilder)object).append(" but was ");
            ((StringBuilder)object).append(sessionToken2.getType());
            throw new RuntimeException(((StringBuilder)object).toString());
        }
        Object object2 = ((MediaSessionService2)((Object)object)).onCreateSession(sessionToken2.getId());
        object = this.mLock;
        synchronized (object) {
            this.mSession = object2;
            if (object2 != null && sessionToken2.getId().equals(this.mSession.getToken().getId()) && this.mSession.getToken().getType() == this.getSessionType()) {
                return;
            }
            this.mSession = null;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Expected session with id ");
            stringBuilder.append(sessionToken2.getId());
            stringBuilder.append(" and type ");
            stringBuilder.append(sessionToken2.getType());
            stringBuilder.append(", but got ");
            stringBuilder.append(this.mSession);
            object2 = new RuntimeException(stringBuilder.toString());
            throw object2;
        }
    }

    @Override
    public MediaSessionService2.MediaNotification onUpdateNotification() {
        return null;
    }
}

