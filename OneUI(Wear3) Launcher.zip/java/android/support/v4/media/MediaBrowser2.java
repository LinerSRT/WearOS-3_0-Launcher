/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.util.Log
 */
package android.support.v4.media;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.media.MediaBrowser2ImplBase;
import android.support.v4.media.MediaBrowser2ImplLegacy;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.SessionToken2;
import android.util.Log;
import java.util.List;
import java.util.concurrent.Executor;

public class MediaBrowser2
extends MediaController2 {
    static final boolean DEBUG = Log.isLoggable((String)"MediaBrowser2", (int)3);
    static final String TAG = "MediaBrowser2";

    public MediaBrowser2(Context context, SessionToken2 sessionToken2, Executor executor, BrowserCallback browserCallback) {
        super(context, sessionToken2, executor, browserCallback);
    }

    @Override
    SupportLibraryImpl createImpl(Context context, SessionToken2 sessionToken2, Executor executor, MediaController2.ControllerCallback controllerCallback) {
        if (sessionToken2.isLegacySession()) {
            return new MediaBrowser2ImplLegacy(context, this, sessionToken2, executor, (BrowserCallback)controllerCallback);
        }
        return new MediaBrowser2ImplBase(context, (MediaController2)this, sessionToken2, executor, (BrowserCallback)controllerCallback);
    }

    @Override
    BrowserCallback getCallback() {
        return (BrowserCallback)super.getCallback();
    }

    public void getChildren(String string2, int n, int n2, Bundle bundle) {
        this.getImpl().getChildren(string2, n, n2, bundle);
    }

    @Override
    SupportLibraryImpl getImpl() {
        return (SupportLibraryImpl)super.getImpl();
    }

    public void getItem(String string2) {
        this.getImpl().getItem(string2);
    }

    public void getLibraryRoot(Bundle bundle) {
        this.getImpl().getLibraryRoot(bundle);
    }

    public void getSearchResult(String string2, int n, int n2, Bundle bundle) {
        this.getImpl().getSearchResult(string2, n, n2, bundle);
    }

    public void search(String string2, Bundle bundle) {
        this.getImpl().search(string2, bundle);
    }

    public void subscribe(String string2, Bundle bundle) {
        this.getImpl().subscribe(string2, bundle);
    }

    public void unsubscribe(String string2) {
        this.getImpl().unsubscribe(string2);
    }

    public static class BrowserCallback
    extends MediaController2.ControllerCallback {
        public void onChildrenChanged(MediaBrowser2 mediaBrowser2, String string2, int n, Bundle bundle) {
        }

        public void onGetChildrenDone(MediaBrowser2 mediaBrowser2, String string2, int n, int n2, List<MediaItem2> list, Bundle bundle) {
        }

        public void onGetItemDone(MediaBrowser2 mediaBrowser2, String string2, MediaItem2 mediaItem2) {
        }

        public void onGetLibraryRootDone(MediaBrowser2 mediaBrowser2, Bundle bundle, String string2, Bundle bundle2) {
        }

        public void onGetSearchResultDone(MediaBrowser2 mediaBrowser2, String string2, int n, int n2, List<MediaItem2> list, Bundle bundle) {
        }

        public void onSearchResultChanged(MediaBrowser2 mediaBrowser2, String string2, int n, Bundle bundle) {
        }
    }

    static interface SupportLibraryImpl
    extends MediaController2.SupportLibraryImpl {
        public void getChildren(String var1, int var2, int var3, Bundle var4);

        public void getItem(String var1);

        public void getLibraryRoot(Bundle var1);

        public void getSearchResult(String var1, int var2, int var3, Bundle var4);

        public void search(String var1, Bundle var2);

        public void subscribe(String var1, Bundle var2);

        public void unsubscribe(String var1);
    }
}

