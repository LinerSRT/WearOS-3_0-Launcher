/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.media.AudioManager
 *  android.media.AudioManager$OnAudioFocusChangeListener
 *  android.util.Log
 */
package android.support.v4.media;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.support.v4.media.AudioAttributesCompat;
import android.support.v4.media.BaseMediaPlayer;
import android.support.v4.media.MediaSession2;
import android.support.v4.util.ObjectsCompat;
import android.util.Log;

public class AudioFocusHandler {
    private static final boolean DEBUG = false;
    private static final String TAG = "AudioFocusHandler";
    private final AudioFocusHandlerImpl mImpl;

    AudioFocusHandler(Context context, MediaSession2 mediaSession2) {
        this.mImpl = new AudioFocusHandlerImplBase(context, mediaSession2);
    }

    public void close() {
        this.mImpl.close();
    }

    public boolean onPauseRequested() {
        return this.mImpl.onPauseRequested();
    }

    public boolean onPlayRequested() {
        return this.mImpl.onPlayRequested();
    }

    public void onPlayerStateChanged(int n) {
        this.mImpl.onPlayerStateChanged(n);
    }

    public void sendIntent(Intent intent) {
        this.mImpl.sendIntent(intent);
    }

    static interface AudioFocusHandlerImpl {
        public void close();

        public boolean onPauseRequested();

        public boolean onPlayRequested();

        public void onPlayerStateChanged(int var1);

        public void sendIntent(Intent var1);
    }

    private static class AudioFocusHandlerImplBase
    implements AudioFocusHandlerImpl {
        private static final float VOLUME_DUCK_FACTOR = 0.2f;
        private AudioAttributesCompat mAudioAttributes;
        private final AudioManager.OnAudioFocusChangeListener mAudioFocusListener;
        private final AudioManager mAudioManager;
        private final BroadcastReceiver mBecomingNoisyIntentReceiver = new NoisyIntentReceiver();
        private boolean mHasAudioFocus;
        private boolean mHasRegisteredReceiver;
        private final IntentFilter mIntentFilter = new IntentFilter("android.media.AUDIO_BECOMING_NOISY");
        private final Object mLock;
        private boolean mResumeWhenAudioFocusGain;
        private final MediaSession2 mSession;

        AudioFocusHandlerImplBase(Context context, MediaSession2 mediaSession2) {
            this.mAudioFocusListener = new AudioFocusListener();
            this.mLock = new Object();
            this.mSession = mediaSession2;
            this.mAudioManager = (AudioManager)context.getSystemService("audio");
        }

        private void abandonAudioFocusLocked() {
            if (!this.mHasAudioFocus) {
                return;
            }
            this.mAudioManager.abandonAudioFocus(this.mAudioFocusListener);
            this.mHasAudioFocus = false;
            this.mResumeWhenAudioFocusGain = false;
        }

        static /* synthetic */ boolean access$602(AudioFocusHandlerImplBase audioFocusHandlerImplBase, boolean bl) {
            audioFocusHandlerImplBase.mResumeWhenAudioFocusGain = bl;
            return bl;
        }

        private int convertAudioAttributesToFocusGainLocked() {
            AudioAttributesCompat audioAttributesCompat = this.mAudioAttributes;
            if (audioAttributesCompat == null) {
                return 0;
            }
            switch (audioAttributesCompat.getUsage()) {
                default: {
                    return 0;
                }
                case 2: 
                case 3: 
                case 4: {
                    return 2;
                }
                case 1: 
                case 14: {
                    return 1;
                }
                case 0: 
                case 5: 
                case 6: 
                case 7: 
                case 8: 
                case 9: 
                case 10: 
                case 11: 
                case 12: 
                case 13: 
                case 16: 
            }
            return 3;
        }

        private void registerReceiverLocked() {
            if (this.mHasRegisteredReceiver) {
                return;
            }
            this.mSession.getContext().registerReceiver(this.mBecomingNoisyIntentReceiver, this.mIntentFilter);
            this.mHasRegisteredReceiver = true;
        }

        private boolean requestAudioFocusLocked() {
            int n = this.convertAudioAttributesToFocusGainLocked();
            if (n == 0) {
                return true;
            }
            int n2 = this.mAudioManager.requestAudioFocus(this.mAudioFocusListener, this.mAudioAttributes.getVolumeControlStream(), n);
            if (n2 == 1) {
                this.mHasAudioFocus = true;
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("requestAudioFocus(");
                stringBuilder.append(n);
                stringBuilder.append(") failed (return=");
                stringBuilder.append(n2);
                stringBuilder.append(") playback wouldn't start.");
                Log.w((String)AudioFocusHandler.TAG, (String)stringBuilder.toString());
                this.mHasAudioFocus = false;
            }
            this.mResumeWhenAudioFocusGain = false;
            return this.mHasAudioFocus;
        }

        private void unregisterReceiverLocked() {
            if (!this.mHasRegisteredReceiver) {
                return;
            }
            this.mSession.getContext().unregisterReceiver(this.mBecomingNoisyIntentReceiver);
            this.mHasRegisteredReceiver = false;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private void updateAudioAttributesIfNeeded() {
            Object object;
            object = this.mSession.getVolumeProvider() != null ? null : ((object = this.mSession.getPlayer()) == null ? null : ((BaseMediaPlayer)object).getAudioAttributes());
            Object object2 = this.mLock;
            synchronized (object2) {
                if (ObjectsCompat.equals(object, this.mAudioAttributes)) {
                    return;
                }
                this.mAudioAttributes = object;
                if (this.mHasAudioFocus) {
                    boolean bl;
                    this.mHasAudioFocus = bl = this.requestAudioFocusLocked();
                    if (!bl) {
                        Log.w((String)AudioFocusHandler.TAG, (String)"Failed to regain audio focus.");
                    }
                }
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void close() {
            Object object = this.mLock;
            synchronized (object) {
                this.unregisterReceiverLocked();
                this.abandonAudioFocusLocked();
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public boolean onPauseRequested() {
            Object object = this.mLock;
            synchronized (object) {
                this.mResumeWhenAudioFocusGain = false;
                return true;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public boolean onPlayRequested() {
            this.updateAudioAttributesIfNeeded();
            Object object = this.mLock;
            synchronized (object) {
                return this.requestAudioFocusLocked();
                {
                }
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void onPlayerStateChanged(int n) {
            Object object = this.mLock;
            synchronized (object) {
                block7: {
                    block5: {
                        block6: {
                            if (n == 0) break block5;
                            if (n == 1) break block6;
                            if (n != 2) {
                                if (n == 3) {
                                    this.abandonAudioFocusLocked();
                                    this.unregisterReceiverLocked();
                                }
                                break block7;
                            } else {
                                this.updateAudioAttributesIfNeeded();
                                this.registerReceiverLocked();
                            }
                            break block7;
                        }
                        this.updateAudioAttributesIfNeeded();
                        this.unregisterReceiverLocked();
                        break block7;
                    }
                    this.abandonAudioFocusLocked();
                }
                return;
            }
        }

        @Override
        public void sendIntent(Intent intent) {
            this.mBecomingNoisyIntentReceiver.onReceive(this.mSession.getContext(), intent);
        }

        private class AudioFocusListener
        implements AudioManager.OnAudioFocusChangeListener {
            private float mPlayerDuckingVolume;
            private float mPlayerVolumeBeforeDucking;

            private AudioFocusListener() {
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onAudioFocusChange(int n) {
                if (n != -3) {
                    if (n == -2) {
                        AudioFocusHandlerImplBase.this.mSession.pause();
                        Object object = AudioFocusHandlerImplBase.this.mLock;
                        synchronized (object) {
                            AudioFocusHandlerImplBase.access$602(AudioFocusHandlerImplBase.this, true);
                            return;
                        }
                    }
                    if (n == -1) {
                        AudioFocusHandlerImplBase.this.mSession.pause();
                        Object object = AudioFocusHandlerImplBase.this.mLock;
                        synchronized (object) {
                            AudioFocusHandlerImplBase.access$602(AudioFocusHandlerImplBase.this, false);
                            return;
                        }
                    }
                    if (n != 1) {
                        return;
                    }
                    if (AudioFocusHandlerImplBase.this.mSession.getPlayerState() == 1) {
                        Object object = AudioFocusHandlerImplBase.this.mLock;
                        synchronized (object) {
                            if (!AudioFocusHandlerImplBase.this.mResumeWhenAudioFocusGain) {
                                return;
                            }
                        }
                        AudioFocusHandlerImplBase.this.mSession.play();
                        return;
                    }
                    BaseMediaPlayer baseMediaPlayer = AudioFocusHandlerImplBase.this.mSession.getPlayer();
                    if (baseMediaPlayer == null) return;
                    float f = baseMediaPlayer.getPlayerVolume();
                    Object object = AudioFocusHandlerImplBase.this.mLock;
                    synchronized (object) {
                        if (f != this.mPlayerDuckingVolume) {
                            return;
                        }
                        f = this.mPlayerVolumeBeforeDucking;
                    }
                    baseMediaPlayer.setPlayerVolume(f);
                    return;
                }
                Object object = AudioFocusHandlerImplBase.this.mLock;
                synchronized (object) {
                    if (AudioFocusHandlerImplBase.this.mAudioAttributes == null) {
                        return;
                    }
                    if (AudioFocusHandlerImplBase.this.mAudioAttributes.getContentType() == 1) {
                        AudioFocusHandlerImplBase.this.mSession.pause();
                    } else {
                        BaseMediaPlayer baseMediaPlayer = AudioFocusHandlerImplBase.this.mSession.getPlayer();
                        if (baseMediaPlayer == null) return;
                        float f = baseMediaPlayer.getPlayerVolume();
                        float f2 = 0.2f * f;
                        Object object2 = AudioFocusHandlerImplBase.this.mLock;
                        synchronized (object2) {
                            this.mPlayerVolumeBeforeDucking = f;
                            this.mPlayerDuckingVolume = f2;
                        }
                        baseMediaPlayer.setPlayerVolume(f2);
                    }
                    return;
                }
            }
        }

        private class NoisyIntentReceiver
        extends BroadcastReceiver {
            private NoisyIntentReceiver() {
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Converted monitor instructions to comments
             * Lifted jumps to return sites
             */
            public void onReceive(Context object, Intent object2) {
                object = AudioFocusHandlerImplBase.this.mLock;
                // MONITORENTER : object
                if (!AudioFocusHandlerImplBase.this.mHasRegisteredReceiver) {
                    // MONITOREXIT : object
                    return;
                }
                // MONITOREXIT : object
                if (!"android.media.AUDIO_BECOMING_NOISY".equals(object2.getAction())) return;
                object2 = AudioFocusHandlerImplBase.this.mLock;
                // MONITORENTER : object2
                if (AudioFocusHandlerImplBase.this.mAudioAttributes == null) {
                    // MONITOREXIT : object2
                    return;
                }
                int n = AudioFocusHandlerImplBase.this.mAudioAttributes.getUsage();
                // MONITOREXIT : object2
                if (n == 1) {
                    AudioFocusHandlerImplBase.this.mSession.pause();
                    return;
                }
                if (n != 14) {
                    return;
                }
                object = AudioFocusHandlerImplBase.this.mSession.getPlayer();
                if (object == null) return;
                ((BaseMediaPlayer)object).setPlayerVolume(((BaseMediaPlayer)object).getPlayerVolume() * 0.2f);
            }
        }
    }
}

