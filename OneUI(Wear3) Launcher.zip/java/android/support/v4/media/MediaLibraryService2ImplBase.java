/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.IBinder
 */
package android.support.v4.media;

import android.content.Intent;
import android.os.IBinder;
import android.support.v4.media.MediaLibraryService2;
import android.support.v4.media.MediaSessionService2ImplBase;

class MediaLibraryService2ImplBase
extends MediaSessionService2ImplBase {
    MediaLibraryService2ImplBase() {
    }

    @Override
    public MediaLibraryService2.MediaLibrarySession getSession() {
        return (MediaLibraryService2.MediaLibrarySession)super.getSession();
    }

    @Override
    public int getSessionType() {
        return 2;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public IBinder onBind(Intent var1_1) {
        block5: {
            block4: {
                var2_2 = var1_1.getAction();
                var3_3 = var2_2.hashCode();
                if (var3_3 == 901933117) break block4;
                if (var3_3 != 1665850838 || !var2_2.equals("android.media.browse.MediaBrowserService")) ** GOTO lbl-1000
                var3_3 = 1;
                break block5;
            }
            if (var2_2.equals("android.media.MediaLibraryService2")) {
                var3_3 = 0;
            } else lbl-1000:
            // 2 sources

            {
                var3_3 = -1;
            }
        }
        if (var3_3 != 0) {
            if (var3_3 != 1) {
                return super.onBind(var1_1);
            }
            return this.getSession().getImpl().getLegacySessionBinder();
        }
        return this.getSession().getSessionBinder();
    }
}

