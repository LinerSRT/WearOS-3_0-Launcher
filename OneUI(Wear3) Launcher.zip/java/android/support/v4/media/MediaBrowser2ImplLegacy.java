/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.BadParcelableException
 *  android.os.Bundle
 */
package android.support.v4.media;

import android.content.Context;
import android.os.BadParcelableException;
import android.os.Bundle;
import android.support.v4.media.MediaBrowser2;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaController2ImplLegacy;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaUtils2;
import android.support.v4.media.SessionToken2;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;

class MediaBrowser2ImplLegacy
extends MediaController2ImplLegacy
implements MediaBrowser2.SupportLibraryImpl {
    public static final String EXTRA_ITEM_COUNT = "android.media.browse.extra.ITEM_COUNT";
    private final HashMap<Bundle, MediaBrowserCompat> mBrowserCompats = new HashMap();
    private final HashMap<String, List<SubscribeCallback>> mSubscribeCallbacks = new HashMap();

    MediaBrowser2ImplLegacy(Context context, MediaBrowser2 mediaBrowser2, SessionToken2 sessionToken2, Executor executor, MediaBrowser2.BrowserCallback browserCallback) {
        super(context, mediaBrowser2, sessionToken2, executor, browserCallback);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private MediaBrowserCompat getBrowserCompat(Bundle object) {
        Object object2 = this.mLock;
        synchronized (object2) {
            return this.mBrowserCompats.get(object);
        }
    }

    private Bundle getExtrasWithoutPagination(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        bundle.setClassLoader(this.getContext().getClassLoader());
        try {
            bundle.remove("android.media.browse.extra.PAGE");
            bundle.remove("android.media.browse.extra.PAGE_SIZE");
        }
        catch (BadParcelableException badParcelableException) {
            // empty catch block
        }
        return bundle;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void close() {
        Object object = this.mLock;
        synchronized (object) {
            Iterator<MediaBrowserCompat> iterator2 = this.mBrowserCompats.values().iterator();
            while (true) {
                if (!iterator2.hasNext()) {
                    this.mBrowserCompats.clear();
                    super.close();
                    return;
                }
                iterator2.next().disconnect();
            }
        }
    }

    @Override
    public MediaBrowser2.BrowserCallback getCallback() {
        return (MediaBrowser2.BrowserCallback)super.getCallback();
    }

    @Override
    public void getChildren(String string2, int n, int n2, Bundle bundle) {
        if (string2 != null) {
            if (n >= 1 && n2 >= 1) {
                MediaBrowserCompat mediaBrowserCompat = this.getBrowserCompat();
                if (mediaBrowserCompat == null) {
                    return;
                }
                bundle = MediaUtils2.createBundle(bundle);
                bundle.putInt("android.media.browse.extra.PAGE", n);
                bundle.putInt("android.media.browse.extra.PAGE_SIZE", n2);
                mediaBrowserCompat.subscribe(string2, bundle, new GetChildrenCallback(string2, n, n2));
                return;
            }
            throw new IllegalArgumentException("Neither page nor pageSize should be less than 1");
        }
        throw new IllegalArgumentException("parentId shouldn't be null");
    }

    @Override
    public MediaBrowser2 getInstance() {
        return (MediaBrowser2)super.getInstance();
    }

    @Override
    public void getItem(final String string2) {
        MediaBrowserCompat mediaBrowserCompat = this.getBrowserCompat();
        if (mediaBrowserCompat == null) {
            return;
        }
        mediaBrowserCompat.getItem(string2, new MediaBrowserCompat.ItemCallback(){

            @Override
            public void onError(String string22) {
                MediaBrowser2ImplLegacy.this.getCallbackExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        MediaBrowser2ImplLegacy.this.getCallback().onGetItemDone(MediaBrowser2ImplLegacy.this.getInstance(), string2, null);
                    }
                });
            }

            @Override
            public void onItemLoaded(final MediaBrowserCompat.MediaItem mediaItem) {
                MediaBrowser2ImplLegacy.this.getCallbackExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        MediaBrowser2ImplLegacy.this.getCallback().onGetItemDone(MediaBrowser2ImplLegacy.this.getInstance(), string2, MediaUtils2.convertToMediaItem2(mediaItem));
                    }
                });
            }
        });
    }

    @Override
    public void getLibraryRoot(final Bundle bundle) {
        final MediaBrowserCompat mediaBrowserCompat = this.getBrowserCompat(bundle);
        if (mediaBrowserCompat != null) {
            this.getCallbackExecutor().execute(new Runnable(){

                @Override
                public void run() {
                    MediaBrowser2ImplLegacy.this.getCallback().onGetLibraryRootDone(MediaBrowser2ImplLegacy.this.getInstance(), bundle, mediaBrowserCompat.getRoot(), mediaBrowserCompat.getExtras());
                }
            });
        } else {
            this.getCallbackExecutor().execute(new Runnable(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                @Override
                public void run() {
                    MediaBrowserCompat mediaBrowserCompat = new MediaBrowserCompat(MediaBrowser2ImplLegacy.this.getContext(), MediaBrowser2ImplLegacy.this.getSessionToken().getComponentName(), new GetLibraryRootCallback(bundle), bundle);
                    Object object = MediaBrowser2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaBrowser2ImplLegacy.this.mBrowserCompats.put(bundle, mediaBrowserCompat);
                    }
                    mediaBrowserCompat.connect();
                }
            });
        }
    }

    @Override
    public void getSearchResult(String string2, final int n, final int n2, final Bundle bundle) {
        MediaBrowserCompat mediaBrowserCompat = this.getBrowserCompat();
        if (mediaBrowserCompat == null) {
            return;
        }
        Bundle bundle2 = MediaUtils2.createBundle(bundle);
        bundle2.putInt("android.media.browse.extra.PAGE", n);
        bundle2.putInt("android.media.browse.extra.PAGE_SIZE", n2);
        mediaBrowserCompat.search(string2, bundle2, new MediaBrowserCompat.SearchCallback(){

            @Override
            public void onError(final String string2, Bundle bundle2) {
                MediaBrowser2ImplLegacy.this.getCallbackExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        MediaBrowser2ImplLegacy.this.getCallback().onGetSearchResultDone(MediaBrowser2ImplLegacy.this.getInstance(), string2, n, n2, null, bundle);
                    }
                });
            }

            @Override
            public void onSearchResult(final String string2, Bundle bundle2, final List<MediaBrowserCompat.MediaItem> list) {
                MediaBrowser2ImplLegacy.this.getCallbackExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        List<MediaItem2> list2 = MediaUtils2.convertMediaItemListToMediaItem2List(list);
                        MediaBrowser2ImplLegacy.this.getCallback().onGetSearchResultDone(MediaBrowser2ImplLegacy.this.getInstance(), string2, n, n2, list2, bundle);
                    }
                });
            }
        });
    }

    @Override
    public void search(String string2, Bundle bundle) {
        MediaBrowserCompat mediaBrowserCompat = this.getBrowserCompat();
        if (mediaBrowserCompat == null) {
            return;
        }
        mediaBrowserCompat.search(string2, bundle, new MediaBrowserCompat.SearchCallback(){

            @Override
            public void onError(String string2, Bundle bundle) {
            }

            @Override
            public void onSearchResult(final String string2, final Bundle bundle, final List<MediaBrowserCompat.MediaItem> list) {
                MediaBrowser2ImplLegacy.this.getCallbackExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        MediaBrowser2ImplLegacy.this.getCallback().onSearchResultChanged(MediaBrowser2ImplLegacy.this.getInstance(), string2, list.size(), bundle);
                    }
                });
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void subscribe(String string2, Bundle bundle) {
        Bundle bundle2;
        if (string2 == null) {
            throw new IllegalArgumentException("parentId shouldn't be null");
        }
        MediaBrowserCompat mediaBrowserCompat = this.getBrowserCompat();
        if (mediaBrowserCompat == null) {
            return;
        }
        SubscribeCallback subscribeCallback = new SubscribeCallback();
        Object object = this.mLock;
        synchronized (object) {
            Bundle bundle3;
            bundle2 = bundle3 = this.mSubscribeCallbacks.get(string2);
            if (bundle3 == null) {
                bundle2 = new ArrayList();
                this.mSubscribeCallbacks.put(string2, (List<SubscribeCallback>)bundle2);
            }
            bundle2.add(subscribeCallback);
        }
        bundle2 = new Bundle();
        bundle2.putBundle("android.support.v4.media.argument.EXTRAS", bundle);
        mediaBrowserCompat.subscribe(string2, bundle2, subscribeCallback);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void unsubscribe(String string2) {
        if (string2 == null) {
            throw new IllegalArgumentException("parentId shouldn't be null");
        }
        MediaBrowserCompat mediaBrowserCompat = this.getBrowserCompat();
        if (mediaBrowserCompat == null) {
            return;
        }
        Object object = this.mLock;
        synchronized (object) {
            List<SubscribeCallback> list = this.mSubscribeCallbacks.get(string2);
            if (list == null) {
                return;
            }
            int n = 0;
            while (n < list.size()) {
                mediaBrowserCompat.unsubscribe(string2, list.get(n));
                ++n;
            }
            return;
        }
    }

    private class GetChildrenCallback
    extends MediaBrowserCompat.SubscriptionCallback {
        private final int mPage;
        private final int mPageSize;
        private final String mParentId;

        GetChildrenCallback(String string2, int n, int n2) {
            this.mParentId = string2;
            this.mPage = n;
            this.mPageSize = n2;
        }

        @Override
        public void onChildrenLoaded(String string2, List<MediaBrowserCompat.MediaItem> list) {
            this.onChildrenLoaded(string2, list, null);
        }

        @Override
        public void onChildrenLoaded(final String string2, final List<MediaBrowserCompat.MediaItem> bundle, Bundle bundle2) {
            ArrayList<MediaItem2> arrayList;
            if (bundle == null) {
                arrayList = null;
            } else {
                ArrayList<MediaItem2> arrayList2 = new ArrayList<MediaItem2>();
                int n = 0;
                while (true) {
                    arrayList = arrayList2;
                    if (n >= bundle.size()) break;
                    arrayList2.add(MediaUtils2.convertToMediaItem2((MediaBrowserCompat.MediaItem)bundle.get(n)));
                    ++n;
                }
            }
            bundle = MediaBrowser2ImplLegacy.this.getExtrasWithoutPagination(bundle2);
            MediaBrowser2ImplLegacy.this.getCallbackExecutor().execute(new Runnable(){

                @Override
                public void run() {
                    MediaBrowserCompat mediaBrowserCompat = MediaBrowser2ImplLegacy.this.getBrowserCompat();
                    if (mediaBrowserCompat == null) {
                        return;
                    }
                    MediaBrowser2ImplLegacy.this.getCallback().onGetChildrenDone(MediaBrowser2ImplLegacy.this.getInstance(), string2, GetChildrenCallback.this.mPage, GetChildrenCallback.this.mPageSize, arrayList, bundle);
                    mediaBrowserCompat.unsubscribe(GetChildrenCallback.this.mParentId, GetChildrenCallback.this);
                }
            });
        }

        @Override
        public void onError(String string2) {
            this.onChildrenLoaded(string2, null, null);
        }

        @Override
        public void onError(String string2, Bundle bundle) {
            this.onChildrenLoaded(string2, null, bundle);
        }
    }

    private class GetLibraryRootCallback
    extends MediaBrowserCompat.ConnectionCallback {
        private final Bundle mExtras;

        GetLibraryRootCallback(Bundle bundle) {
            this.mExtras = bundle;
        }

        @Override
        public void onConnected() {
            MediaBrowser2ImplLegacy.this.getCallbackExecutor().execute(new Runnable(){

                /*
                 * WARNING - void declaration
                 */
                @Override
                public void run() {
                    Object object = MediaBrowser2ImplLegacy.this.mLock;
                    synchronized (object) {
                        try {
                            MediaBrowserCompat mediaBrowserCompat = (MediaBrowserCompat)MediaBrowser2ImplLegacy.this.mBrowserCompats.get(GetLibraryRootCallback.this.mExtras);
                            // MONITOREXIT @DISABLED, blocks:[0, 2] lbl5 : MonitorExitStatement: MONITOREXIT : var1_1
                            if (mediaBrowserCompat == null) {
                                return;
                            }
                            MediaBrowser2ImplLegacy.this.getCallback().onGetLibraryRootDone(MediaBrowser2ImplLegacy.this.getInstance(), GetLibraryRootCallback.this.mExtras, mediaBrowserCompat.getRoot(), mediaBrowserCompat.getExtras());
                            return;
                        }
                        catch (Throwable throwable) {
                            while (true) {
                                void var2_4;
                                try {}
                                catch (Throwable throwable2) {
                                    continue;
                                }
                                throw var2_4;
                            }
                        }
                    }
                }
            });
        }

        @Override
        public void onConnectionFailed() {
            MediaBrowser2ImplLegacy.this.close();
        }

        @Override
        public void onConnectionSuspended() {
            MediaBrowser2ImplLegacy.this.close();
        }
    }

    private class SubscribeCallback
    extends MediaBrowserCompat.SubscriptionCallback {
        private SubscribeCallback() {
        }

        @Override
        public void onChildrenLoaded(String string2, List<MediaBrowserCompat.MediaItem> list) {
            this.onChildrenLoaded(string2, list, null);
        }

        @Override
        public void onChildrenLoaded(final String string2, final List<MediaBrowserCompat.MediaItem> bundle, Bundle bundle2) {
            block4: {
                int n;
                block3: {
                    block2: {
                        if (bundle2 == null || !bundle2.containsKey(MediaBrowser2ImplLegacy.EXTRA_ITEM_COUNT)) break block2;
                        n = bundle2.getInt(MediaBrowser2ImplLegacy.EXTRA_ITEM_COUNT);
                        break block3;
                    }
                    if (bundle == null) break block4;
                    n = bundle.size();
                }
                bundle = MediaBrowser2ImplLegacy.this.getBrowserCompat().getNotifyChildrenChangedOptions();
                MediaBrowser2ImplLegacy.this.getCallbackExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        MediaBrowser2ImplLegacy.this.getCallback().onChildrenChanged(MediaBrowser2ImplLegacy.this.getInstance(), string2, n, bundle);
                    }
                });
                return;
            }
        }

        @Override
        public void onError(String string2) {
            this.onChildrenLoaded(string2, null, null);
        }

        @Override
        public void onError(String string2, Bundle bundle) {
            this.onChildrenLoaded(string2, null, bundle);
        }
    }
}

