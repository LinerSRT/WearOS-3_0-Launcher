/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  androidx.media.AudioAttributesImplApi21
 *  androidx.media.AudioAttributesImplApi21Parcelizer
 *  androidx.versionedparcelable.VersionedParcel
 */
package android.support.v4.media;

import androidx.media.AudioAttributesImplApi21;
import androidx.versionedparcelable.VersionedParcel;

public final class AudioAttributesImplApi21Parcelizer
extends androidx.media.AudioAttributesImplApi21Parcelizer {
    public static AudioAttributesImplApi21 read(VersionedParcel versionedParcel) {
        return androidx.media.AudioAttributesImplApi21Parcelizer.read((VersionedParcel)versionedParcel);
    }

    public static void write(AudioAttributesImplApi21 audioAttributesImplApi21, VersionedParcel versionedParcel) {
        androidx.media.AudioAttributesImplApi21Parcelizer.write((AudioAttributesImplApi21)audioAttributesImplApi21, (VersionedParcel)versionedParcel);
    }
}

