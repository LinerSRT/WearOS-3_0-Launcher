/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.media.MediaFormat
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Message
 *  android.text.Layout$Alignment
 *  android.text.SpannableStringBuilder
 *  android.text.TextUtils
 *  android.text.style.CharacterStyle
 *  android.text.style.RelativeSizeSpan
 *  android.text.style.StyleSpan
 *  android.text.style.SubscriptSpan
 *  android.text.style.SuperscriptSpan
 *  android.text.style.UnderlineSpan
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.View$OnLayoutChangeListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.accessibility.CaptioningManager
 *  android.view.accessibility.CaptioningManager$CaptionStyle
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 */
package android.support.v4.media.subtitle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.Message;
import android.support.v4.media.subtitle.Cea708CCParser;
import android.support.v4.media.subtitle.ClosedCaptionWidget;
import android.support.v4.media.subtitle.SubtitleController;
import android.support.v4.media.subtitle.SubtitleTrack;
import android.support.v4.media.subtitle.SubtitleView;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.CharacterStyle;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.SubscriptSpan;
import android.text.style.SuperscriptSpan;
import android.text.style.UnderlineSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.CaptioningManager;
import android.widget.RelativeLayout;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Cea708CaptionRenderer
extends SubtitleController.Renderer {
    private Cea708CCWidget mCCWidget;
    private final Context mContext;

    public Cea708CaptionRenderer(Context context) {
        this.mContext = context;
    }

    @Override
    public SubtitleTrack createTrack(MediaFormat mediaFormat) {
        if ("text/cea-708".equals(mediaFormat.getString("mime"))) {
            if (this.mCCWidget == null) {
                this.mCCWidget = new Cea708CCWidget(this.mContext);
            }
            return new Cea708CaptionTrack(this.mCCWidget, mediaFormat);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No matching format: ");
        stringBuilder.append(mediaFormat.toString());
        throw new RuntimeException(stringBuilder.toString());
    }

    @Override
    public boolean supports(MediaFormat mediaFormat) {
        if (mediaFormat.containsKey("mime")) {
            return "text/cea-708".equals(mediaFormat.getString("mime"));
        }
        return false;
    }

    class Cea708CCWidget
    extends ClosedCaptionWidget
    implements Cea708CCParser.DisplayListener {
        private final CCHandler mCCHandler;

        Cea708CCWidget(Context context) {
            this(context, null);
        }

        Cea708CCWidget(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, 0);
        }

        Cea708CCWidget(Context context, AttributeSet attributeSet, int n) {
            this(context, attributeSet, n, 0);
        }

        Cea708CCWidget(Context context, AttributeSet attributeSet, int n, int n2) {
            super(context, attributeSet, n, n2);
            this.mCCHandler = new CCHandler((CCLayout)this.mClosedCaptionLayout);
        }

        @Override
        public ClosedCaptionWidget.ClosedCaptionLayout createCaptionLayout(Context context) {
            return new CCLayout(context);
        }

        @Override
        public void emitEvent(Cea708CCParser.CaptionEvent captionEvent) {
            this.mCCHandler.processCaptionEvent(captionEvent);
            this.setSize(this.getWidth(), this.getHeight());
            if (this.mListener != null) {
                this.mListener.onChanged(this);
            }
        }

        public void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            ((ViewGroup)this.mClosedCaptionLayout).draw(canvas);
        }

        class CCHandler
        implements Handler.Callback {
            private static final int CAPTION_ALL_WINDOWS_BITMAP = 255;
            private static final long CAPTION_CLEAR_INTERVAL_MS = 60000L;
            private static final int CAPTION_WINDOWS_MAX = 8;
            private static final boolean DEBUG = false;
            private static final int MSG_CAPTION_CLEAR = 2;
            private static final int MSG_DELAY_CANCEL = 1;
            private static final String TAG = "CCHandler";
            private static final int TENTHS_OF_SECOND_IN_MILLIS = 100;
            private final CCLayout mCCLayout;
            private final CCWindowLayout[] mCaptionWindowLayouts = new CCWindowLayout[8];
            private CCWindowLayout mCurrentWindowLayout;
            private final Handler mHandler;
            private boolean mIsDelayed = false;
            private final ArrayList<Cea708CCParser.CaptionEvent> mPendingCaptionEvents = new ArrayList();

            CCHandler(CCLayout cCLayout) {
                this.mCCLayout = cCLayout;
                this.mHandler = new Handler((Handler.Callback)this);
            }

            private void clearWindows(int n) {
                if (n == 0) {
                    return;
                }
                Iterator<CCWindowLayout> iterator2 = this.getWindowsFromBitmap(n).iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().clear();
                }
            }

            private void defineWindow(Cea708CCParser.CaptionWindow captionWindow) {
                Object object;
                if (captionWindow == null) {
                    return;
                }
                int n = captionWindow.id;
                if (n >= 0 && n < ((CCWindowLayout[])(object = this.mCaptionWindowLayouts)).length) {
                    CCWindowLayout cCWindowLayout = object[n];
                    object = cCWindowLayout;
                    if (cCWindowLayout == null) {
                        object = new CCWindowLayout(this.mCCLayout.getContext());
                    }
                    object.initWindow(this.mCCLayout, captionWindow);
                    this.mCaptionWindowLayouts[n] = object;
                    this.mCurrentWindowLayout = object;
                    return;
                }
            }

            private void delay(int n) {
                if (n >= 0 && n <= 255) {
                    this.mIsDelayed = true;
                    Handler handler = this.mHandler;
                    handler.sendMessageDelayed(handler.obtainMessage(1), (long)(n * 100));
                    return;
                }
            }

            private void delayCancel() {
                this.mIsDelayed = false;
                this.processPendingBuffer();
            }

            private void deleteWindows(int n) {
                if (n == 0) {
                    return;
                }
                for (CCWindowLayout cCWindowLayout : this.getWindowsFromBitmap(n)) {
                    cCWindowLayout.removeFromCaptionView();
                    this.mCaptionWindowLayouts[cCWindowLayout.getCaptionWindowId()] = null;
                }
            }

            private void displayWindows(int n) {
                if (n == 0) {
                    return;
                }
                Iterator<CCWindowLayout> iterator2 = this.getWindowsFromBitmap(n).iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().show();
                }
            }

            private ArrayList<CCWindowLayout> getWindowsFromBitmap(int n) {
                ArrayList<CCWindowLayout> arrayList = new ArrayList<CCWindowLayout>();
                for (int i = 0; i < 8; ++i) {
                    CCWindowLayout cCWindowLayout;
                    if ((1 << i & n) == 0 || (cCWindowLayout = this.mCaptionWindowLayouts[i]) == null) continue;
                    arrayList.add(cCWindowLayout);
                }
                return arrayList;
            }

            private void hideWindows(int n) {
                if (n == 0) {
                    return;
                }
                Iterator<CCWindowLayout> iterator2 = this.getWindowsFromBitmap(n).iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().hide();
                }
            }

            private void processPendingBuffer() {
                Iterator<Cea708CCParser.CaptionEvent> iterator2 = this.mPendingCaptionEvents.iterator();
                while (iterator2.hasNext()) {
                    this.processCaptionEvent(iterator2.next());
                }
                this.mPendingCaptionEvents.clear();
            }

            private void sendBufferToCurrentWindow(String string2) {
                CCWindowLayout cCWindowLayout = this.mCurrentWindowLayout;
                if (cCWindowLayout != null) {
                    cCWindowLayout.sendBuffer(string2);
                    this.mHandler.removeMessages(2);
                    string2 = this.mHandler;
                    string2.sendMessageDelayed(string2.obtainMessage(2), 60000L);
                }
            }

            private void sendControlToCurrentWindow(char c) {
                CCWindowLayout cCWindowLayout = this.mCurrentWindowLayout;
                if (cCWindowLayout != null) {
                    cCWindowLayout.sendControl(c);
                }
            }

            private void setCurrentWindowLayout(int n) {
                Object object;
                if (n >= 0 && n < ((CCWindowLayout[])(object = this.mCaptionWindowLayouts)).length) {
                    if ((object = object[n]) == null) {
                        return;
                    }
                    this.mCurrentWindowLayout = object;
                    return;
                }
            }

            private void setPenAttr(Cea708CCParser.CaptionPenAttr captionPenAttr) {
                CCWindowLayout cCWindowLayout = this.mCurrentWindowLayout;
                if (cCWindowLayout != null) {
                    cCWindowLayout.setPenAttr(captionPenAttr);
                }
            }

            private void setPenColor(Cea708CCParser.CaptionPenColor captionPenColor) {
                CCWindowLayout cCWindowLayout = this.mCurrentWindowLayout;
                if (cCWindowLayout != null) {
                    cCWindowLayout.setPenColor(captionPenColor);
                }
            }

            private void setPenLocation(Cea708CCParser.CaptionPenLocation captionPenLocation) {
                CCWindowLayout cCWindowLayout = this.mCurrentWindowLayout;
                if (cCWindowLayout != null) {
                    cCWindowLayout.setPenLocation(captionPenLocation.row, captionPenLocation.column);
                }
            }

            private void setWindowAttr(Cea708CCParser.CaptionWindowAttr captionWindowAttr) {
                CCWindowLayout cCWindowLayout = this.mCurrentWindowLayout;
                if (cCWindowLayout != null) {
                    cCWindowLayout.setWindowAttr(captionWindowAttr);
                }
            }

            private void toggleWindows(int n) {
                if (n == 0) {
                    return;
                }
                for (CCWindowLayout cCWindowLayout : this.getWindowsFromBitmap(n)) {
                    if (cCWindowLayout.isShown()) {
                        cCWindowLayout.hide();
                        continue;
                    }
                    cCWindowLayout.show();
                }
            }

            public boolean handleMessage(Message message) {
                int n = message.what;
                if (n != 1) {
                    if (n != 2) {
                        return false;
                    }
                    this.clearWindows(255);
                    return true;
                }
                this.delayCancel();
                return true;
            }

            public void processCaptionEvent(Cea708CCParser.CaptionEvent captionEvent) {
                if (this.mIsDelayed) {
                    this.mPendingCaptionEvents.add(captionEvent);
                    return;
                }
                switch (captionEvent.type) {
                    default: {
                        break;
                    }
                    case 16: {
                        this.defineWindow((Cea708CCParser.CaptionWindow)captionEvent.obj);
                        break;
                    }
                    case 15: {
                        this.setWindowAttr((Cea708CCParser.CaptionWindowAttr)captionEvent.obj);
                        break;
                    }
                    case 14: {
                        this.setPenLocation((Cea708CCParser.CaptionPenLocation)captionEvent.obj);
                        break;
                    }
                    case 13: {
                        this.setPenColor((Cea708CCParser.CaptionPenColor)captionEvent.obj);
                        break;
                    }
                    case 12: {
                        this.setPenAttr((Cea708CCParser.CaptionPenAttr)captionEvent.obj);
                        break;
                    }
                    case 11: {
                        this.reset();
                        break;
                    }
                    case 10: {
                        this.delayCancel();
                        break;
                    }
                    case 9: {
                        this.delay((Integer)captionEvent.obj);
                        break;
                    }
                    case 8: {
                        this.deleteWindows((Integer)captionEvent.obj);
                        break;
                    }
                    case 7: {
                        this.toggleWindows((Integer)captionEvent.obj);
                        break;
                    }
                    case 6: {
                        this.hideWindows((Integer)captionEvent.obj);
                        break;
                    }
                    case 5: {
                        this.displayWindows((Integer)captionEvent.obj);
                        break;
                    }
                    case 4: {
                        this.clearWindows((Integer)captionEvent.obj);
                        break;
                    }
                    case 3: {
                        this.setCurrentWindowLayout((Integer)captionEvent.obj);
                        break;
                    }
                    case 2: {
                        this.sendControlToCurrentWindow(((Character)captionEvent.obj).charValue());
                        break;
                    }
                    case 1: {
                        this.sendBufferToCurrentWindow((String)captionEvent.obj);
                    }
                }
            }

            public void reset() {
                this.mCurrentWindowLayout = null;
                this.mIsDelayed = false;
                this.mPendingCaptionEvents.clear();
                for (int i = 0; i < 8; ++i) {
                    CCWindowLayout[] cCWindowLayoutArray = this.mCaptionWindowLayouts;
                    if (cCWindowLayoutArray[i] != null) {
                        cCWindowLayoutArray[i].removeFromCaptionView();
                    }
                    this.mCaptionWindowLayouts[i] = null;
                }
                this.mCCLayout.setVisibility(4);
                this.mHandler.removeMessages(2);
            }
        }

        class CCLayout
        extends ScaledLayout
        implements ClosedCaptionWidget.ClosedCaptionLayout {
            private static final float SAFE_TITLE_AREA_SCALE_END_X = 0.9f;
            private static final float SAFE_TITLE_AREA_SCALE_END_Y = 0.9f;
            private static final float SAFE_TITLE_AREA_SCALE_START_X = 0.1f;
            private static final float SAFE_TITLE_AREA_SCALE_START_Y = 0.1f;
            private final ScaledLayout mSafeTitleAreaLayout;

            CCLayout(Context context) {
                super(context);
                Cea708CCWidget.this = (Cea708CCWidget)Cea708CCWidget.this.new ScaledLayout(context);
                this.mSafeTitleAreaLayout = Cea708CCWidget.this;
                this.addView((View)Cea708CCWidget.this, new ScaledLayout.ScaledLayoutParams(0.1f, 0.9f, 0.1f, 0.9f));
            }

            public void addOrUpdateViewToSafeTitleArea(CCWindowLayout cCWindowLayout, ScaledLayout.ScaledLayoutParams scaledLayoutParams) {
                if (this.mSafeTitleAreaLayout.indexOfChild((View)cCWindowLayout) < 0) {
                    this.mSafeTitleAreaLayout.addView((View)cCWindowLayout, scaledLayoutParams);
                    return;
                }
                this.mSafeTitleAreaLayout.updateViewLayout((View)cCWindowLayout, scaledLayoutParams);
            }

            public void removeViewFromSafeTitleArea(CCWindowLayout cCWindowLayout) {
                this.mSafeTitleAreaLayout.removeView((View)cCWindowLayout);
            }

            @Override
            public void setCaptionStyle(CaptioningManager.CaptionStyle captionStyle) {
                int n = this.mSafeTitleAreaLayout.getChildCount();
                for (int i = 0; i < n; ++i) {
                    ((CCWindowLayout)this.mSafeTitleAreaLayout.getChildAt(i)).setCaptionStyle(captionStyle);
                }
            }

            @Override
            public void setFontScale(float f) {
                int n = this.mSafeTitleAreaLayout.getChildCount();
                for (int i = 0; i < n; ++i) {
                    ((CCWindowLayout)this.mSafeTitleAreaLayout.getChildAt(i)).setFontScale(f);
                }
            }
        }

        class CCView
        extends SubtitleView {
            CCView(Context context) {
                this(context, null);
            }

            CCView(Context context, AttributeSet attributeSet) {
                this(context, attributeSet, 0);
            }

            CCView(Context context, AttributeSet attributeSet, int n) {
                this(context, attributeSet, n, 0);
            }

            CCView(Context context, AttributeSet attributeSet, int n, int n2) {
                super(context, attributeSet, n, n2);
            }

            void setCaptionStyle(CaptioningManager.CaptionStyle captionStyle) {
                if (captionStyle.hasForegroundColor()) {
                    this.setForegroundColor(captionStyle.foregroundColor);
                }
                if (captionStyle.hasBackgroundColor()) {
                    this.setBackgroundColor(captionStyle.backgroundColor);
                }
                if (captionStyle.hasEdgeType()) {
                    this.setEdgeType(captionStyle.edgeType);
                }
                if (captionStyle.hasEdgeColor()) {
                    this.setEdgeColor(captionStyle.edgeColor);
                }
                this.setTypeface(captionStyle.getTypeface());
            }
        }

        private class CCWindowLayout
        extends RelativeLayout
        implements View.OnLayoutChangeListener {
            private static final int ANCHOR_HORIZONTAL_16_9_MAX = 209;
            private static final int ANCHOR_HORIZONTAL_MODE_CENTER = 1;
            private static final int ANCHOR_HORIZONTAL_MODE_LEFT = 0;
            private static final int ANCHOR_HORIZONTAL_MODE_RIGHT = 2;
            private static final int ANCHOR_MODE_DIVIDER = 3;
            private static final int ANCHOR_RELATIVE_POSITIONING_MAX = 99;
            private static final int ANCHOR_VERTICAL_MAX = 74;
            private static final int ANCHOR_VERTICAL_MODE_BOTTOM = 2;
            private static final int ANCHOR_VERTICAL_MODE_CENTER = 1;
            private static final int ANCHOR_VERTICAL_MODE_TOP = 0;
            private static final int MAX_COLUMN_COUNT_16_9 = 42;
            private static final float PROPORTION_PEN_SIZE_LARGE = 1.25f;
            private static final float PROPORTION_PEN_SIZE_SMALL = 0.75f;
            private static final String TAG = "CCWindowLayout";
            private final SpannableStringBuilder mBuilder;
            private CCLayout mCCLayout;
            private CCView mCCView;
            private CaptioningManager.CaptionStyle mCaptionStyle;
            private int mCaptionWindowId;
            private final List<CharacterStyle> mCharacterStyles;
            private float mFontScale;
            private int mLastCaptionLayoutHeight;
            private int mLastCaptionLayoutWidth;
            private int mRow;
            private int mRowLimit;
            private float mTextSize;
            private String mWidestChar;

            CCWindowLayout(Context context) {
                this(context, null);
            }

            CCWindowLayout(Context context, AttributeSet attributeSet) {
                this(context, attributeSet, 0);
            }

            CCWindowLayout(Context context, AttributeSet attributeSet, int n) {
                this(context, attributeSet, n, 0);
            }

            CCWindowLayout(Context context, AttributeSet attributeSet, int n, int n2) {
                super(context, attributeSet, n, n2);
                this.mRowLimit = 0;
                this.mBuilder = new SpannableStringBuilder();
                this.mCharacterStyles = new ArrayList<CharacterStyle>();
                this.mRow = -1;
                this.mCCView = new CCView(context);
                Cea708CCWidget.this = new RelativeLayout.LayoutParams(-2, -2);
                this.addView(this.mCCView, (ViewGroup.LayoutParams)Cea708CCWidget.this);
                Cea708CCWidget.this = (CaptioningManager)context.getSystemService("captioning");
                this.mFontScale = Cea708CCWidget.this.getFontScale();
                this.setCaptionStyle(Cea708CCWidget.this.getUserStyle());
                this.mCCView.setText("");
                this.updateWidestChar();
            }

            private int getScreenColumnCount() {
                return 42;
            }

            private void updateText(String spannableStringBuilder, boolean bl) {
                int n;
                int n2;
                int n3;
                if (!bl) {
                    this.mBuilder.clear();
                }
                if (spannableStringBuilder != null && spannableStringBuilder.length() > 0) {
                    n3 = this.mBuilder.length();
                    this.mBuilder.append((CharSequence)spannableStringBuilder);
                    for (CharacterStyle string22 : this.mCharacterStyles) {
                        spannableStringBuilder = this.mBuilder;
                        spannableStringBuilder.setSpan((Object)string22, n3, spannableStringBuilder.length(), 33);
                    }
                }
                spannableStringBuilder = TextUtils.split((String)this.mBuilder.toString(), (String)"\n");
                String string2 = TextUtils.join((CharSequence)"\n", (Object[])Arrays.copyOfRange(spannableStringBuilder, Math.max(0, ((String[])spannableStringBuilder).length - (this.mRowLimit + 1)), ((String[])spannableStringBuilder).length));
                spannableStringBuilder = this.mBuilder;
                spannableStringBuilder.delete(0, spannableStringBuilder.length() - string2.length());
                int n4 = 0;
                n3 = n2 = this.mBuilder.length() - 1;
                while (true) {
                    n = n3;
                    if (n4 > n3) break;
                    n = n3;
                    if (this.mBuilder.charAt(n4) > ' ') break;
                    ++n4;
                }
                while (n >= n4 && this.mBuilder.charAt(n) <= ' ') {
                    --n;
                }
                if (n4 == 0 && n == n2) {
                    this.mCCView.setText((CharSequence)this.mBuilder);
                } else {
                    spannableStringBuilder = new SpannableStringBuilder();
                    spannableStringBuilder.append((CharSequence)this.mBuilder);
                    if (n < n2) {
                        spannableStringBuilder.delete(n + 1, n2 + 1);
                    }
                    if (n4 > 0) {
                        spannableStringBuilder.delete(0, n4);
                    }
                    this.mCCView.setText((CharSequence)spannableStringBuilder);
                }
            }

            private void updateTextSize() {
                if (this.mCCLayout == null) {
                    return;
                }
                CharSequence charSequence = new StringBuilder();
                int n = this.getScreenColumnCount();
                for (int i = 0; i < n; ++i) {
                    charSequence.append(this.mWidestChar);
                }
                charSequence = charSequence.toString();
                Paint paint = new Paint();
                paint.setTypeface(this.mCaptionStyle.getTypeface());
                float f = 0.0f;
                float f2 = 255.0f;
                while (f < f2) {
                    float f3 = (f + f2) / 2.0f;
                    paint.setTextSize(f3);
                    float f4 = paint.measureText((String)charSequence);
                    if ((float)this.mCCLayout.getWidth() * 0.8f > f4) {
                        f = 0.01f + f3;
                        continue;
                    }
                    f2 = f3 - 0.01f;
                }
                this.mTextSize = f2 = this.mFontScale * f2;
                this.mCCView.setTextSize(f2);
            }

            private void updateWidestChar() {
                Paint paint = new Paint();
                paint.setTypeface(this.mCaptionStyle.getTypeface());
                Charset charset = Charset.forName("ISO-8859-1");
                float f = 0.0f;
                for (int i = 0; i < 256; ++i) {
                    String string2 = new String(new byte[]{(byte)i}, charset);
                    float f2 = paint.measureText(string2);
                    float f3 = f;
                    if (f < f2) {
                        f3 = f2;
                        this.mWidestChar = string2;
                    }
                    f = f3;
                }
                this.updateTextSize();
            }

            public void appendText(String string2) {
                this.updateText(string2, true);
            }

            public void clear() {
                this.clearText();
                this.hide();
            }

            public void clearText() {
                this.mBuilder.clear();
                this.mCCView.setText("");
            }

            public int getCaptionWindowId() {
                return this.mCaptionWindowId;
            }

            public void hide() {
                this.setVisibility(4);
                this.requestLayout();
            }

            public void initWindow(CCLayout object, Cea708CCParser.CaptionWindow captionWindow) {
                float f;
                float f2;
                int n;
                int n2;
                float f3;
                CCLayout cCLayout;
                block28: {
                    block27: {
                        block26: {
                            block25: {
                                cCLayout = this.mCCLayout;
                                if (cCLayout != object) {
                                    if (cCLayout != null) {
                                        cCLayout.removeOnLayoutChangeListener(this);
                                    }
                                    this.mCCLayout = object;
                                    object.addOnLayoutChangeListener((View.OnLayoutChangeListener)this);
                                    this.updateWidestChar();
                                }
                                f3 = captionWindow.anchorVertical;
                                boolean bl = captionWindow.relativePositioning;
                                n2 = 99;
                                n = bl ? 99 : 74;
                                f2 = f3 / (float)n;
                                f3 = captionWindow.anchorHorizontal;
                                n = captionWindow.relativePositioning ? n2 : 209;
                                f = f3 / (float)n;
                                if (f2 < 0.0f) break block25;
                                f3 = f2;
                                if (!(f2 > 1.0f)) break block26;
                            }
                            object = new StringBuilder();
                            ((StringBuilder)object).append("The vertical position of the anchor point should be at the range of 0 and 1 but ");
                            ((StringBuilder)object).append(f2);
                            Log.i((String)TAG, (String)((StringBuilder)object).toString());
                            f3 = Math.max(0.0f, Math.min(f2, 1.0f));
                        }
                        if (f < 0.0f) break block27;
                        f2 = f;
                        if (!(f > 1.0f)) break block28;
                    }
                    object = new StringBuilder();
                    ((StringBuilder)object).append("The horizontal position of the anchor point should be at the range of 0 and 1 but ");
                    ((StringBuilder)object).append(f);
                    Log.i((String)TAG, (String)((StringBuilder)object).toString());
                    f2 = Math.max(0.0f, Math.min(f, 1.0f));
                }
                n = 17;
                int n3 = captionWindow.anchorId % 3;
                n2 = captionWindow.anchorId / 3;
                float f4 = 0.0f;
                float f5 = 1.0f;
                float f6 = 0.0f;
                f = 1.0f;
                if (n3 != 0) {
                    if (n3 != 1) {
                        if (n3 != 2) {
                            f2 = f6;
                        } else {
                            n = 5;
                            f = f2;
                            f2 = f6;
                        }
                    } else {
                        f6 = Math.min(1.0f - f2, f2);
                        n = captionWindow.columnCount;
                        n3 = Math.min(this.getScreenColumnCount(), n + 1);
                        object = new StringBuilder();
                        for (n = 0; n < n3; ++n) {
                            ((StringBuilder)object).append(this.mWidestChar);
                        }
                        cCLayout = new Paint();
                        cCLayout.setTypeface(this.mCaptionStyle.getTypeface());
                        cCLayout.setTextSize(this.mTextSize);
                        f = cCLayout.measureText(((StringBuilder)object).toString());
                        f = this.mCCLayout.getWidth() > 0 ? f / 2.0f / ((float)this.mCCLayout.getWidth() * 0.8f) : 0.0f;
                        if (f > 0.0f && f < f2) {
                            this.mCCView.setAlignment(Layout.Alignment.ALIGN_NORMAL);
                            f2 -= f;
                            f = 1.0f;
                            n = 3;
                        } else {
                            n = 1;
                            this.mCCView.setAlignment(Layout.Alignment.ALIGN_CENTER);
                            f = f2 - f6;
                            f6 = f2 + f6;
                            f2 = f;
                            f = f6;
                        }
                    }
                } else {
                    n = 3;
                    this.mCCView.setAlignment(Layout.Alignment.ALIGN_NORMAL);
                }
                if (n2 != 0) {
                    if (n2 != 1) {
                        if (n2 != 2) {
                            f3 = f4;
                        } else {
                            n |= 0x50;
                            f5 = f3;
                            f3 = f4;
                        }
                    } else {
                        n |= 0x10;
                        f4 = Math.min(1.0f - f3, f3);
                        f5 = f3 - f4;
                        f4 = f3 + f4;
                        f3 = f5;
                        f5 = f4;
                    }
                } else {
                    n |= 0x30;
                }
                object = this.mCCLayout;
                cCLayout = this.mCCLayout;
                cCLayout.getClass();
                ((CCLayout)object).addOrUpdateViewToSafeTitleArea(this, cCLayout.new ScaledLayout.ScaledLayoutParams(f3, f5, f2, f));
                this.setCaptionWindowId(captionWindow.id);
                this.setRowLimit(captionWindow.rowCount);
                this.setGravity(n);
                if (captionWindow.visible) {
                    this.show();
                } else {
                    this.hide();
                }
            }

            public void onLayoutChange(View view, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
                n = n3 - n;
                n2 = n4 - n2;
                if (n != this.mLastCaptionLayoutWidth || n2 != this.mLastCaptionLayoutHeight) {
                    this.mLastCaptionLayoutWidth = n;
                    this.mLastCaptionLayoutHeight = n2;
                    this.updateTextSize();
                }
            }

            public void removeFromCaptionView() {
                CCLayout cCLayout = this.mCCLayout;
                if (cCLayout != null) {
                    cCLayout.removeViewFromSafeTitleArea(this);
                    this.mCCLayout.removeOnLayoutChangeListener(this);
                    this.mCCLayout = null;
                }
            }

            public void sendBuffer(String string2) {
                this.appendText(string2);
            }

            public void sendControl(char c) {
            }

            public void setCaptionStyle(CaptioningManager.CaptionStyle captionStyle) {
                this.mCaptionStyle = captionStyle;
                this.mCCView.setCaptionStyle(captionStyle);
            }

            public void setCaptionWindowId(int n) {
                this.mCaptionWindowId = n;
            }

            public void setFontScale(float f) {
                this.mFontScale = f;
                this.updateTextSize();
            }

            public void setPenAttr(Cea708CCParser.CaptionPenAttr captionPenAttr) {
                int n;
                this.mCharacterStyles.clear();
                if (captionPenAttr.italic) {
                    this.mCharacterStyles.add((CharacterStyle)new StyleSpan(2));
                }
                if (captionPenAttr.underline) {
                    this.mCharacterStyles.add((CharacterStyle)new UnderlineSpan());
                }
                if ((n = captionPenAttr.penSize) != 0) {
                    if (n == 2) {
                        this.mCharacterStyles.add((CharacterStyle)new RelativeSizeSpan(1.25f));
                    }
                } else {
                    this.mCharacterStyles.add((CharacterStyle)new RelativeSizeSpan(0.75f));
                }
                n = captionPenAttr.penOffset;
                if (n != 0) {
                    if (n == 2) {
                        this.mCharacterStyles.add((CharacterStyle)new SuperscriptSpan());
                    }
                } else {
                    this.mCharacterStyles.add((CharacterStyle)new SubscriptSpan());
                }
            }

            public void setPenColor(Cea708CCParser.CaptionPenColor captionPenColor) {
            }

            public void setPenLocation(int n, int n2) {
                if (this.mRow >= 0) {
                    for (n2 = this.mRow; n2 < n; ++n2) {
                        this.appendText("\n");
                    }
                }
                this.mRow = n;
            }

            public void setRowLimit(int n) {
                if (n >= 0) {
                    this.mRowLimit = n;
                    return;
                }
                throw new IllegalArgumentException("A rowLimit should have a positive number");
            }

            public void setText(String string2) {
                this.updateText(string2, false);
            }

            public void setWindowAttr(Cea708CCParser.CaptionWindowAttr captionWindowAttr) {
            }

            public void show() {
                this.setVisibility(0);
                this.requestLayout();
            }
        }

        class ScaledLayout
        extends ViewGroup {
            private static final boolean DEBUG = false;
            private static final String TAG = "ScaledLayout";
            private Rect[] mRectArray;
            private final Comparator<Rect> mRectTopLeftSorter;

            ScaledLayout(Context context) {
                super(context);
                this.mRectTopLeftSorter = new Comparator<Rect>(){

                    @Override
                    public int compare(Rect rect, Rect rect2) {
                        if (rect.top != rect2.top) {
                            return rect.top - rect2.top;
                        }
                        return rect.left - rect2.left;
                    }
                };
            }

            protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
                return layoutParams instanceof ScaledLayoutParams;
            }

            public void dispatchDraw(Canvas canvas) {
                int n = this.getPaddingLeft();
                int n2 = this.getPaddingTop();
                int n3 = this.getChildCount();
                for (int i = 0; i < n3; ++i) {
                    View view = this.getChildAt(i);
                    if (view.getVisibility() == 8) continue;
                    Rect[] rectArray = this.mRectArray;
                    if (i >= rectArray.length) break;
                    int n4 = rectArray[i].left;
                    int n5 = this.mRectArray[i].top;
                    int n6 = canvas.save();
                    canvas.translate((float)(n4 + n), (float)(n5 + n2));
                    view.draw(canvas);
                    canvas.restoreToCount(n6);
                }
            }

            public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
                return new ScaledLayoutParams(this.getContext(), attributeSet);
            }

            protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
                n3 = this.getPaddingLeft();
                n2 = this.getPaddingTop();
                n4 = this.getChildCount();
                for (n = 0; n < n4; ++n) {
                    View view = this.getChildAt(n);
                    if (view.getVisibility() == 8) continue;
                    int n5 = this.mRectArray[n].left;
                    int n6 = this.mRectArray[n].top;
                    int n7 = this.mRectArray[n].bottom;
                    view.layout(n5 + n3, n6 + n2, this.mRectArray[n].right + n2, n7 + n3);
                }
            }

            protected void onMeasure(int n, int n2) {
                Object object;
                Rect[] rectArray;
                int n3;
                int n4 = View.MeasureSpec.getSize((int)n);
                n = View.MeasureSpec.getSize((int)n2);
                int n5 = n4 - this.getPaddingLeft() - this.getPaddingRight();
                int n6 = n - this.getPaddingTop() - this.getPaddingBottom();
                int n7 = this.getChildCount();
                this.mRectArray = new Rect[n7];
                n2 = n4;
                for (n3 = 0; n3 < n7; ++n3) {
                    rectArray = this.getChildAt(n3);
                    object = rectArray.getLayoutParams();
                    if (object instanceof ScaledLayoutParams) {
                        float f = ((ScaledLayoutParams)object).scaleStartRow;
                        float f2 = ((ScaledLayoutParams)object).scaleEndRow;
                        float f3 = ((ScaledLayoutParams)object).scaleStartCol;
                        float f4 = ((ScaledLayoutParams)object).scaleEndCol;
                        if (!(f < 0.0f) && !(f > 1.0f)) {
                            if (!(f2 < f) && !(f > 1.0f)) {
                                if (!(f4 < 0.0f) && !(f4 > 1.0f)) {
                                    if (!(f4 < f3) && !(f4 > 1.0f)) {
                                        this.mRectArray[n3] = new Rect((int)((float)n5 * f3), (int)((float)n6 * f), (int)((float)n5 * f4), (int)((float)n6 * f2));
                                        int n8 = View.MeasureSpec.makeMeasureSpec((int)((int)((float)n5 * (f4 - f3))), (int)0x40000000);
                                        rectArray.measure(n8, View.MeasureSpec.makeMeasureSpec((int)0, (int)0));
                                        if (rectArray.getMeasuredHeight() > this.mRectArray[n3].height()) {
                                            n4 = (rectArray.getMeasuredHeight() - this.mRectArray[n3].height() + 1) / 2;
                                            object = this.mRectArray[n3];
                                            object.bottom += n4;
                                            object = this.mRectArray[n3];
                                            object.top -= n4;
                                            if (this.mRectArray[n3].top < 0) {
                                                object = this.mRectArray[n3];
                                                object.bottom -= this.mRectArray[n3].top;
                                                this.mRectArray[n3].top = 0;
                                            }
                                            if (this.mRectArray[n3].bottom > n6) {
                                                object = this.mRectArray[n3];
                                                object.top -= this.mRectArray[n3].bottom - n6;
                                                this.mRectArray[n3].bottom = n6;
                                            }
                                        }
                                        rectArray.measure(n8, View.MeasureSpec.makeMeasureSpec((int)((int)((float)n6 * (f2 - f))), (int)0x40000000));
                                        continue;
                                    }
                                    throw new RuntimeException("A child of ScaledLayout should have a range of scaleEndCol between scaleStartCol and 1");
                                }
                                throw new RuntimeException("A child of ScaledLayout should have a range of scaleStartCol between 0 and 1");
                            }
                            throw new RuntimeException("A child of ScaledLayout should have a range of scaleEndRow between scaleStartRow and 1");
                        }
                        throw new RuntimeException("A child of ScaledLayout should have a range of scaleStartRow between 0 and 1");
                    }
                    throw new RuntimeException("A child of ScaledLayout cannot have the UNSPECIFIED scale factors");
                }
                n3 = 0;
                object = new int[n7];
                rectArray = new Rect[n7];
                for (n4 = 0; n4 < n7; ++n4) {
                    n5 = n3;
                    if (this.getChildAt(n4).getVisibility() == 0) {
                        object[n3] = n3;
                        rectArray[n3] = this.mRectArray[n4];
                        n5 = n3 + 1;
                    }
                    n3 = n5;
                }
                Arrays.sort(rectArray, 0, n3, this.mRectTopLeftSorter);
                for (n4 = 0; n4 < n3 - 1; ++n4) {
                    for (n5 = n4 + 1; n5 < n3; ++n5) {
                        if (!Rect.intersects((Rect)rectArray[n4], (Rect)rectArray[n5])) continue;
                        object[n5] = object[n4];
                        rectArray[n5].set(rectArray[n5].left, rectArray[n4].bottom, rectArray[n5].right, rectArray[n4].bottom + rectArray[n5].height());
                    }
                }
                --n3;
                while (n3 >= 0) {
                    if (rectArray[n3].bottom > n6) {
                        n5 = rectArray[n3].bottom - n6;
                        for (n4 = 0; n4 <= n3; ++n4) {
                            if (object[n3] != object[n4]) continue;
                            rectArray[n4].set(rectArray[n4].left, rectArray[n4].top - n5, rectArray[n4].right, rectArray[n4].bottom - n5);
                        }
                    }
                    --n3;
                }
                this.setMeasuredDimension(n2, n);
            }

            class ScaledLayoutParams
            extends ViewGroup.LayoutParams {
                public static final float SCALE_UNSPECIFIED = -1.0f;
                public float scaleEndCol;
                public float scaleEndRow;
                public float scaleStartCol;
                public float scaleStartRow;

                ScaledLayoutParams(float f, float f2, float f3, float f4) {
                    super(-1, -1);
                    this.scaleStartRow = f;
                    this.scaleEndRow = f2;
                    this.scaleStartCol = f3;
                    this.scaleEndCol = f4;
                }

                ScaledLayoutParams(Context context, AttributeSet attributeSet) {
                    super(-1, -1);
                }
            }
        }
    }

    static class Cea708CaptionTrack
    extends SubtitleTrack {
        private final Cea708CCParser mCCParser;
        private final Cea708CCWidget mRenderingWidget;

        Cea708CaptionTrack(Cea708CCWidget cea708CCWidget, MediaFormat mediaFormat) {
            super(mediaFormat);
            this.mRenderingWidget = cea708CCWidget;
            this.mCCParser = new Cea708CCParser(this.mRenderingWidget);
        }

        @Override
        public SubtitleTrack.RenderingWidget getRenderingWidget() {
            return this.mRenderingWidget;
        }

        @Override
        public void onData(byte[] byArray, boolean bl, long l) {
            this.mCCParser.parse(byArray);
        }

        @Override
        public void updateView(ArrayList<SubtitleTrack.Cue> arrayList) {
        }
    }
}

