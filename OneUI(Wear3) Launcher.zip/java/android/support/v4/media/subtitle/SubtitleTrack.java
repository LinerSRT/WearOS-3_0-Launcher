/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.media.MediaFormat
 *  android.os.Handler
 *  android.util.Log
 *  android.util.LongSparseArray
 *  android.util.Pair
 */
package android.support.v4.media.subtitle;

import android.graphics.Canvas;
import android.media.MediaFormat;
import android.os.Handler;
import android.support.v4.media.SubtitleData2;
import android.support.v4.media.subtitle.MediaTimeProvider;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.Pair;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.SortedMap;
import java.util.TreeMap;

public abstract class SubtitleTrack
implements MediaTimeProvider.OnMediaTimeListener {
    private static final String TAG = "SubtitleTrack";
    public boolean DEBUG = false;
    private final ArrayList<Cue> mActiveCues;
    private CueList mCues;
    private MediaFormat mFormat;
    protected Handler mHandler;
    private long mLastTimeMs;
    private long mLastUpdateTimeMs;
    private long mNextScheduledTimeMs = -1L;
    private Runnable mRunnable;
    private final LongSparseArray<Run> mRunsByEndTime = new LongSparseArray();
    private final LongSparseArray<Run> mRunsByID = new LongSparseArray();
    protected MediaTimeProvider mTimeProvider;
    protected boolean mVisible;

    public SubtitleTrack(MediaFormat mediaFormat) {
        this.mActiveCues = new ArrayList();
        this.mHandler = new Handler();
        this.mFormat = mediaFormat;
        this.mCues = new CueList();
        this.clearActiveCues();
        this.mLastTimeMs = -1L;
    }

    static /* synthetic */ Runnable access$102(SubtitleTrack subtitleTrack, Runnable runnable) {
        subtitleTrack.mRunnable = runnable;
        return runnable;
    }

    private void removeRunsByEndTimeIndex(int n) {
        Object object = (Run)this.mRunsByEndTime.valueAt(n);
        while (object != null) {
            Object object2 = ((Run)object).mFirstCue;
            while (object2 != null) {
                this.mCues.remove((Cue)object2);
                Cue cue = ((Cue)object2).mNextInRun;
                ((Cue)object2).mNextInRun = null;
                object2 = cue;
            }
            this.mRunsByID.remove(((Run)object).mRunID);
            object2 = ((Run)object).mNextRunAtEndTimeMs;
            ((Run)object).mPrevRunAtEndTimeMs = null;
            ((Run)object).mNextRunAtEndTimeMs = null;
            object = object2;
        }
        this.mRunsByEndTime.removeAt(n);
    }

    private void takeTime(long l) {
        synchronized (this) {
            this.mLastTimeMs = l;
            return;
        }
    }

    protected boolean addCue(Cue runnable) {
        synchronized (this) {
            block22: {
                long l;
                Object object;
                block21: {
                    block18: {
                        block20: {
                            Run run;
                            block19: {
                                this.mCues.add((Cue)((Object)runnable));
                                if (((Cue)runnable).mRunID == 0L) break block18;
                                run = (Run)this.mRunsByID.get(((Cue)runnable).mRunID);
                                if (run != null) break block19;
                                object = new Run();
                                this.mRunsByID.put(((Cue)runnable).mRunID, object);
                                ((Run)object).mEndTimeMs = ((Cue)runnable).mEndTimeMs;
                                break block20;
                            }
                            object = run;
                            if (run.mEndTimeMs >= ((Cue)runnable).mEndTimeMs) break block20;
                            run.mEndTimeMs = ((Cue)runnable).mEndTimeMs;
                            object = run;
                        }
                        ((Cue)runnable).mNextInRun = ((Run)object).mFirstCue;
                        ((Run)object).mFirstCue = runnable;
                    }
                    long l2 = -1L;
                    object = this.mTimeProvider;
                    l = l2;
                    if (object == null) break block21;
                    try {
                        l = this.mTimeProvider.getCurrentTimeUs(false, true) / 1000L;
                    }
                    catch (IllegalStateException illegalStateException) {
                        l = l2;
                    }
                }
                if (this.DEBUG) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("mVisible=");
                    ((StringBuilder)object).append(this.mVisible);
                    ((StringBuilder)object).append(", ");
                    ((StringBuilder)object).append(((Cue)runnable).mStartTimeMs);
                    ((StringBuilder)object).append(" <= ");
                    ((StringBuilder)object).append(l);
                    ((StringBuilder)object).append(", ");
                    ((StringBuilder)object).append(((Cue)runnable).mEndTimeMs);
                    ((StringBuilder)object).append(" >= ");
                    ((StringBuilder)object).append(this.mLastTimeMs);
                    Log.v((String)TAG, (String)((StringBuilder)object).toString());
                }
                if (!this.mVisible || ((Cue)runnable).mStartTimeMs > l || ((Cue)runnable).mEndTimeMs < this.mLastTimeMs) break block22;
                if (this.mRunnable != null) {
                    this.mHandler.removeCallbacks(this.mRunnable);
                }
                runnable = new Runnable(){

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    @Override
                    public void run() {
                        SubtitleTrack subtitleTrack = this;
                        synchronized (subtitleTrack) {
                            SubtitleTrack.access$102(SubtitleTrack.this, null);
                            SubtitleTrack.this.updateActiveCues(true, l);
                            SubtitleTrack.this.updateView(SubtitleTrack.this.mActiveCues);
                            return;
                        }
                    }
                };
                this.mRunnable = runnable;
                if (this.mHandler.postDelayed(runnable, 10L)) {
                    if (this.DEBUG) {
                        Log.v((String)TAG, (String)"scheduling update");
                    }
                } else if (this.DEBUG) {
                    Log.w((String)TAG, (String)"failed to schedule subtitle view update");
                }
                return true;
            }
            if (this.mVisible && ((Cue)runnable).mEndTimeMs >= this.mLastTimeMs && (((Cue)runnable).mStartTimeMs < this.mNextScheduledTimeMs || this.mNextScheduledTimeMs < 0L)) {
                this.scheduleTimedEvents();
            }
            return false;
        }
    }

    protected void clearActiveCues() {
        synchronized (this) {
            if (this.DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Clearing ");
                stringBuilder.append(this.mActiveCues.size());
                stringBuilder.append(" active cues");
                Log.v((String)TAG, (String)stringBuilder.toString());
            }
            this.mActiveCues.clear();
            this.mLastUpdateTimeMs = -1L;
            return;
        }
    }

    protected void finalize() throws Throwable {
        for (int i = this.mRunsByEndTime.size() - 1; i >= 0; --i) {
            this.removeRunsByEndTimeIndex(i);
        }
        super.finalize();
    }

    protected void finishedRun(long l) {
        Run run;
        if (l != 0L && l != -1L && (run = (Run)this.mRunsByID.get(l)) != null) {
            run.storeByEndTimeMs(this.mRunsByEndTime);
        }
    }

    public final MediaFormat getFormat() {
        return this.mFormat;
    }

    public abstract RenderingWidget getRenderingWidget();

    public int getTrackType() {
        int n = this.getRenderingWidget() == null ? 3 : 4;
        return n;
    }

    public void hide() {
        if (!this.mVisible) {
            return;
        }
        Object object = this.mTimeProvider;
        if (object != null) {
            object.cancelNotifications(this);
        }
        if ((object = this.getRenderingWidget()) != null) {
            object.setVisible(false);
        }
        this.mVisible = false;
    }

    public void onData(SubtitleData2 subtitleData2) {
        long l = subtitleData2.getStartTimeUs() + 1L;
        this.onData(subtitleData2.getData(), true, l);
        this.setRunDiscardTimeMs(l, (subtitleData2.getStartTimeUs() + subtitleData2.getDurationUs()) / 1000L);
    }

    protected abstract void onData(byte[] var1, boolean var2, long var3);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onSeek(long l) {
        if (this.DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onSeek ");
            stringBuilder.append(l);
            Log.d((String)"SubtitleTrack", (String)stringBuilder.toString());
        }
        synchronized (this) {
            this.updateActiveCues(true, l /= 1000L);
            this.takeTime(l);
        }
        this.updateView(this.mActiveCues);
        this.scheduleTimedEvents();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onStop() {
        synchronized (this) {
            if (this.DEBUG) {
                Log.d((String)"SubtitleTrack", (String)"onStop");
            }
            this.clearActiveCues();
            this.mLastTimeMs = -1L;
        }
        this.updateView(this.mActiveCues);
        this.mNextScheduledTimeMs = -1L;
        this.mTimeProvider.notifyAt(-1L, this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onTimedEvent(long l) {
        if (this.DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onTimedEvent ");
            stringBuilder.append(l);
            Log.d((String)"SubtitleTrack", (String)stringBuilder.toString());
        }
        synchronized (this) {
            this.updateActiveCues(false, l /= 1000L);
            this.takeTime(l);
        }
        this.updateView(this.mActiveCues);
        this.scheduleTimedEvents();
    }

    protected void scheduleTimedEvents() {
        if (this.mTimeProvider != null) {
            Object object;
            this.mNextScheduledTimeMs = this.mCues.nextTimeAfter(this.mLastTimeMs);
            if (this.DEBUG) {
                object = new StringBuilder();
                ((StringBuilder)object).append("sched @");
                ((StringBuilder)object).append(this.mNextScheduledTimeMs);
                ((StringBuilder)object).append(" after ");
                ((StringBuilder)object).append(this.mLastTimeMs);
                Log.d((String)"SubtitleTrack", (String)((StringBuilder)object).toString());
            }
            object = this.mTimeProvider;
            long l = this.mNextScheduledTimeMs;
            l = l >= 0L ? (l *= 1000L) : -1L;
            object.notifyAt(l, this);
        }
    }

    public void setRunDiscardTimeMs(long l, long l2) {
        Run run;
        if (l != 0L && l != -1L && (run = (Run)this.mRunsByID.get(l)) != null) {
            run.mEndTimeMs = l2;
            run.storeByEndTimeMs(this.mRunsByEndTime);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setTimeProvider(MediaTimeProvider mediaTimeProvider) {
        synchronized (this) {
            MediaTimeProvider mediaTimeProvider2 = this.mTimeProvider;
            if (mediaTimeProvider2 == mediaTimeProvider) {
                return;
            }
            if (this.mTimeProvider != null) {
                this.mTimeProvider.cancelNotifications(this);
            }
            this.mTimeProvider = mediaTimeProvider;
            if (mediaTimeProvider != null) {
                mediaTimeProvider.scheduleUpdate(this);
            }
            return;
        }
    }

    public void show() {
        if (this.mVisible) {
            return;
        }
        this.mVisible = true;
        Object object = this.getRenderingWidget();
        if (object != null) {
            object.setVisible(true);
        }
        if ((object = this.mTimeProvider) != null) {
            object.scheduleUpdate(this);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void updateActiveCues(boolean bl, long l) {
        synchronized (this) {
            if (bl || this.mLastUpdateTimeMs > l) {
                this.clearActiveCues();
            }
            Iterator<Pair<Long, Cue>> iterator2 = this.mCues.entriesBetween(this.mLastUpdateTimeMs, l).iterator();
            while (iterator2.hasNext()) {
                Object object = iterator2.next();
                Cue cue = (Cue)((Pair)object).second;
                if (cue.mEndTimeMs == (Long)((Pair)object).first) {
                    if (this.DEBUG) {
                        object = new StringBuilder();
                        ((StringBuilder)object).append("Removing ");
                        ((StringBuilder)object).append(cue);
                        Log.v((String)"SubtitleTrack", (String)((StringBuilder)object).toString());
                    }
                    this.mActiveCues.remove(cue);
                    if (cue.mRunID != 0L) continue;
                    iterator2.remove();
                    continue;
                }
                if (cue.mStartTimeMs == (Long)((Pair)object).first) {
                    if (this.DEBUG) {
                        object = new StringBuilder();
                        ((StringBuilder)object).append("Adding ");
                        ((StringBuilder)object).append(cue);
                        Log.v((String)"SubtitleTrack", (String)((StringBuilder)object).toString());
                    }
                    if (cue.mInnerTimesMs != null) {
                        cue.onTime(l);
                    }
                    this.mActiveCues.add(cue);
                    continue;
                }
                if (cue.mInnerTimesMs == null) continue;
                cue.onTime(l);
            }
            while (this.mRunsByEndTime.size() > 0 && this.mRunsByEndTime.keyAt(0) <= l) {
                this.removeRunsByEndTimeIndex(0);
            }
            this.mLastUpdateTimeMs = l;
            return;
        }
    }

    public abstract void updateView(ArrayList<Cue> var1);

    static class Cue {
        public long mEndTimeMs;
        public long[] mInnerTimesMs;
        public Cue mNextInRun;
        public long mRunID;
        public long mStartTimeMs;

        Cue() {
        }

        public void onTime(long l) {
        }
    }

    static class CueList {
        private static final String TAG = "CueList";
        public boolean DEBUG = false;
        private SortedMap<Long, ArrayList<Cue>> mCues = new TreeMap<Long, ArrayList<Cue>>();

        CueList() {
        }

        private boolean addEvent(Cue cue, long l) {
            ArrayList<Cue> arrayList;
            ArrayList<Cue> arrayList2 = (ArrayList<Cue>)this.mCues.get(l);
            if (arrayList2 == null) {
                arrayList = new ArrayList<Cue>(2);
                this.mCues.put(l, arrayList);
            } else {
                arrayList = arrayList2;
                if (arrayList2.contains(cue)) {
                    return false;
                }
            }
            arrayList.add(cue);
            return true;
        }

        private void removeEvent(Cue cue, long l) {
            ArrayList arrayList = (ArrayList)this.mCues.get(l);
            if (arrayList != null) {
                arrayList.remove(cue);
                if (arrayList.size() == 0) {
                    this.mCues.remove(l);
                }
            }
        }

        public void add(Cue cue) {
            if (cue.mStartTimeMs >= cue.mEndTimeMs) {
                return;
            }
            if (!this.addEvent(cue, cue.mStartTimeMs)) {
                return;
            }
            long l = cue.mStartTimeMs;
            if (cue.mInnerTimesMs != null) {
                for (long l2 : cue.mInnerTimesMs) {
                    long l3 = l;
                    if (l2 > l) {
                        l3 = l;
                        if (l2 < cue.mEndTimeMs) {
                            this.addEvent(cue, l2);
                            l3 = l2;
                        }
                    }
                    l = l3;
                }
            }
            this.addEvent(cue, cue.mEndTimeMs);
        }

        public Iterable<Pair<Long, Cue>> entriesBetween(final long l, final long l2) {
            return new Iterable<Pair<Long, Cue>>(){

                @Override
                public Iterator<Pair<Long, Cue>> iterator() {
                    Object object;
                    if (DEBUG) {
                        object = new StringBuilder();
                        ((StringBuilder)object).append("slice (");
                        ((StringBuilder)object).append(l);
                        ((StringBuilder)object).append(", ");
                        ((StringBuilder)object).append(l2);
                        ((StringBuilder)object).append("]=");
                        Log.d((String)CueList.TAG, (String)((StringBuilder)object).toString());
                    }
                    try {
                        object = new EntryIterator(mCues.subMap(l + 1L, l2 + 1L));
                        return object;
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        return new EntryIterator(null);
                    }
                }
            };
        }

        public long nextTimeAfter(long l) {
            block4: {
                SortedMap<Long, ArrayList<Cue>> sortedMap = this.mCues.tailMap(1L + l);
                if (sortedMap == null) break block4;
                try {
                    l = sortedMap.firstKey();
                    return l;
                }
                catch (NoSuchElementException noSuchElementException) {
                    return -1L;
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    return -1L;
                }
            }
            return -1L;
        }

        public void remove(Cue cue) {
            this.removeEvent(cue, cue.mStartTimeMs);
            if (cue.mInnerTimesMs != null) {
                long[] lArray = cue.mInnerTimesMs;
                int n = lArray.length;
                for (int i = 0; i < n; ++i) {
                    this.removeEvent(cue, lArray[i]);
                }
            }
            this.removeEvent(cue, cue.mEndTimeMs);
        }

        class EntryIterator
        implements Iterator<Pair<Long, Cue>> {
            private long mCurrentTimeMs;
            private boolean mDone;
            private Pair<Long, Cue> mLastEntry;
            private Iterator<Cue> mLastListIterator;
            private Iterator<Cue> mListIterator;
            private SortedMap<Long, ArrayList<Cue>> mRemainingCues;

            EntryIterator(SortedMap<Long, ArrayList<Cue>> sortedMap) {
                if (((CueList)CueList.this).DEBUG) {
                    CueList.this = new StringBuilder();
                    ((StringBuilder)CueList.this).append(sortedMap);
                    ((StringBuilder)CueList.this).append("");
                    Log.v((String)CueList.TAG, (String)((StringBuilder)CueList.this).toString());
                }
                this.mRemainingCues = sortedMap;
                this.mLastListIterator = null;
                this.nextKey();
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            private void nextKey() {
                block6: {
                    do {
                        long l;
                        if (this.mRemainingCues == null) break block6;
                        this.mCurrentTimeMs = l = this.mRemainingCues.firstKey().longValue();
                        this.mListIterator = ((ArrayList)this.mRemainingCues.get(l)).iterator();
                        try {
                            this.mRemainingCues = this.mRemainingCues.tailMap(this.mCurrentTimeMs + 1L);
                        }
                        catch (IllegalArgumentException illegalArgumentException) {
                            this.mRemainingCues = null;
                        }
                        this.mDone = false;
                    } while (!this.mListIterator.hasNext());
                    return;
                }
                try {
                    NoSuchElementException noSuchElementException = new NoSuchElementException("");
                    throw noSuchElementException;
                }
                catch (NoSuchElementException noSuchElementException) {
                    this.mDone = true;
                    this.mRemainingCues = null;
                    this.mListIterator = null;
                    return;
                }
            }

            @Override
            public boolean hasNext() {
                return this.mDone ^ true;
            }

            @Override
            public Pair<Long, Cue> next() {
                if (!this.mDone) {
                    this.mLastEntry = new Pair((Object)this.mCurrentTimeMs, (Object)this.mListIterator.next());
                    Iterator<Cue> iterator2 = this.mListIterator;
                    this.mLastListIterator = iterator2;
                    if (!iterator2.hasNext()) {
                        this.nextKey();
                    }
                    return this.mLastEntry;
                }
                throw new NoSuchElementException("");
            }

            @Override
            public void remove() {
                if (this.mLastListIterator != null && ((Cue)this.mLastEntry.second).mEndTimeMs == (Long)this.mLastEntry.first) {
                    this.mLastListIterator.remove();
                    this.mLastListIterator = null;
                    if (((ArrayList)CueList.this.mCues.get(this.mLastEntry.first)).size() == 0) {
                        CueList.this.mCues.remove(this.mLastEntry.first);
                    }
                    Cue cue = (Cue)this.mLastEntry.second;
                    CueList.this.removeEvent(cue, cue.mStartTimeMs);
                    if (cue.mInnerTimesMs != null) {
                        for (long l : cue.mInnerTimesMs) {
                            CueList.this.removeEvent(cue, l);
                        }
                    }
                    return;
                }
                throw new IllegalStateException("");
            }
        }
    }

    public static interface RenderingWidget {
        public void draw(Canvas var1);

        public void onAttachedToWindow();

        public void onDetachedFromWindow();

        public void setOnChangedListener(OnChangedListener var1);

        public void setSize(int var1, int var2);

        public void setVisible(boolean var1);

        public static interface OnChangedListener {
            public void onChanged(RenderingWidget var1);
        }
    }

    private static class Run {
        static final /* synthetic */ boolean $assertionsDisabled = false;
        public long mEndTimeMs = -1L;
        public Cue mFirstCue;
        public Run mNextRunAtEndTimeMs;
        public Run mPrevRunAtEndTimeMs;
        public long mRunID = 0L;
        private long mStoredEndTimeMs = -1L;

        private Run() {
        }

        public void removeAtEndTimeMs() {
            Run run = this.mPrevRunAtEndTimeMs;
            Run run2 = this.mPrevRunAtEndTimeMs;
            if (run2 != null) {
                run2.mNextRunAtEndTimeMs = this.mNextRunAtEndTimeMs;
                this.mPrevRunAtEndTimeMs = null;
            }
            if ((run2 = this.mNextRunAtEndTimeMs) != null) {
                run2.mPrevRunAtEndTimeMs = run;
                this.mNextRunAtEndTimeMs = null;
            }
        }

        public void storeByEndTimeMs(LongSparseArray<Run> longSparseArray) {
            long l;
            Run run;
            int n = longSparseArray.indexOfKey(this.mStoredEndTimeMs);
            if (n >= 0) {
                if (this.mPrevRunAtEndTimeMs == null) {
                    run = this.mNextRunAtEndTimeMs;
                    if (run == null) {
                        longSparseArray.removeAt(n);
                    } else {
                        longSparseArray.setValueAt(n, (Object)run);
                    }
                }
                this.removeAtEndTimeMs();
            }
            if ((l = this.mEndTimeMs) >= 0L) {
                this.mPrevRunAtEndTimeMs = null;
                this.mNextRunAtEndTimeMs = run = (Run)longSparseArray.get(l);
                if (run != null) {
                    run.mPrevRunAtEndTimeMs = this;
                }
                longSparseArray.put(this.mEndTimeMs, (Object)this);
                this.mStoredEndTimeMs = this.mEndTimeMs;
            }
        }
    }
}

