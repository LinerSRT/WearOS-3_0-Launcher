/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Paint$Join
 *  android.graphics.Paint$Style
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  android.support.mediacompat.R$dimen
 *  android.text.Layout$Alignment
 *  android.text.SpannableStringBuilder
 *  android.text.StaticLayout
 *  android.text.StaticLayout$Builder
 *  android.text.TextPaint
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 */
package android.support.v4.media.subtitle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.support.mediacompat.R;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

class SubtitleView
extends View {
    private static final int COLOR_BEVEL_DARK = Integer.MIN_VALUE;
    private static final int COLOR_BEVEL_LIGHT = -2130706433;
    private static final float INNER_PADDING_RATIO = 0.125f;
    private Layout.Alignment mAlignment;
    private int mBackgroundColor;
    private final float mCornerRadius;
    private int mEdgeColor;
    private int mEdgeType;
    private int mForegroundColor;
    private boolean mHasMeasurements;
    private int mInnerPaddingX = 0;
    private int mLastMeasuredWidth;
    private StaticLayout mLayout;
    private final RectF mLineBounds = new RectF();
    private final float mOutlineWidth;
    private Paint mPaint;
    private final float mShadowOffsetX;
    private final float mShadowOffsetY;
    private final float mShadowRadius;
    private float mSpacingAdd = 0.0f;
    private float mSpacingMult = 1.0f;
    private final SpannableStringBuilder mText = new SpannableStringBuilder();
    private TextPaint mTextPaint;

    SubtitleView(Context context) {
        this(context, null);
    }

    SubtitleView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    SubtitleView(Context context, AttributeSet attributeSet, int n) {
        this(context, attributeSet, n, 0);
    }

    SubtitleView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet);
        float f;
        context = this.getContext().getResources();
        this.mCornerRadius = context.getDimensionPixelSize(R.dimen.subtitle_corner_radius);
        this.mOutlineWidth = context.getDimensionPixelSize(R.dimen.subtitle_outline_width);
        this.mShadowRadius = context.getDimensionPixelSize(R.dimen.subtitle_shadow_radius);
        this.mShadowOffsetX = f = (float)context.getDimensionPixelSize(R.dimen.subtitle_shadow_offset);
        this.mShadowOffsetY = f;
        context = new TextPaint();
        this.mTextPaint = context;
        context.setAntiAlias(true);
        this.mTextPaint.setSubpixelText(true);
        context = new Paint();
        this.mPaint = context;
        context.setAntiAlias(true);
    }

    private boolean computeMeasurements(int n) {
        if (this.mHasMeasurements && n == this.mLastMeasuredWidth) {
            return true;
        }
        if ((n -= this.getPaddingLeft() + this.getPaddingRight() + this.mInnerPaddingX * 2) <= 0) {
            return false;
        }
        this.mHasMeasurements = true;
        this.mLastMeasuredWidth = n;
        SpannableStringBuilder spannableStringBuilder = this.mText;
        this.mLayout = StaticLayout.Builder.obtain((CharSequence)spannableStringBuilder, (int)0, (int)spannableStringBuilder.length(), (TextPaint)this.mTextPaint, (int)n).setAlignment(this.mAlignment).setLineSpacing(this.mSpacingAdd, this.mSpacingMult).setUseLineSpacingFromFallbacks(true).build();
        return true;
    }

    protected void onDraw(Canvas canvas) {
        int n;
        float f;
        StaticLayout staticLayout = this.mLayout;
        if (staticLayout == null) {
            return;
        }
        int n2 = canvas.save();
        int n3 = this.mInnerPaddingX;
        canvas.translate((float)(this.getPaddingLeft() + n3), (float)this.getPaddingTop());
        int n4 = staticLayout.getLineCount();
        TextPaint textPaint = this.mTextPaint;
        Paint paint = this.mPaint;
        RectF rectF = this.mLineBounds;
        if (Color.alpha((int)this.mBackgroundColor) > 0) {
            float f2 = this.mCornerRadius;
            f = staticLayout.getLineTop(0);
            paint.setColor(this.mBackgroundColor);
            paint.setStyle(Paint.Style.FILL);
            for (n = 0; n < n4; ++n) {
                rectF.left = staticLayout.getLineLeft(n) - (float)n3;
                rectF.right = staticLayout.getLineRight(n) + (float)n3;
                rectF.top = f;
                f = rectF.bottom = (float)staticLayout.getLineBottom(n);
                canvas.drawRoundRect(rectF, f2, f2, paint);
            }
        }
        n3 = this.mEdgeType;
        n = 1;
        if (n3 == 1) {
            textPaint.setStrokeJoin(Paint.Join.ROUND);
            textPaint.setStrokeWidth(this.mOutlineWidth);
            textPaint.setColor(this.mEdgeColor);
            textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            staticLayout.draw(canvas);
        } else if (n3 == 2) {
            textPaint.setShadowLayer(this.mShadowRadius, this.mShadowOffsetX, this.mShadowOffsetY, this.mEdgeColor);
        } else if (n3 == 3 || n3 == 4) {
            if (n3 != 3) {
                n = 0;
            }
            n4 = -1;
            n3 = n != 0 ? -1 : this.mEdgeColor;
            if (n != 0) {
                n4 = this.mEdgeColor;
            }
            f = this.mShadowRadius / 2.0f;
            textPaint.setColor(this.mForegroundColor);
            textPaint.setStyle(Paint.Style.FILL);
            textPaint.setShadowLayer(this.mShadowRadius, -f, -f, n3);
            staticLayout.draw(canvas);
            textPaint.setShadowLayer(this.mShadowRadius, f, f, n4);
        }
        textPaint.setColor(this.mForegroundColor);
        textPaint.setStyle(Paint.Style.FILL);
        staticLayout.draw(canvas);
        textPaint.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
        canvas.restoreToCount(n2);
    }

    public void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        this.computeMeasurements(n3 - n);
    }

    protected void onMeasure(int n, int n2) {
        if (this.computeMeasurements(View.MeasureSpec.getSize((int)n))) {
            StaticLayout staticLayout = this.mLayout;
            int n3 = this.getPaddingLeft();
            n2 = this.getPaddingRight();
            n = this.mInnerPaddingX;
            this.setMeasuredDimension(staticLayout.getWidth() + (n3 + n2 + n * 2), staticLayout.getHeight() + this.getPaddingTop() + this.getPaddingBottom());
        } else {
            this.setMeasuredDimension(0x1000000, 0x1000000);
        }
    }

    public void setAlignment(Layout.Alignment alignment) {
        if (this.mAlignment != alignment) {
            this.mAlignment = alignment;
            this.mHasMeasurements = false;
            this.requestLayout();
            this.invalidate();
        }
    }

    public void setBackgroundColor(int n) {
        this.mBackgroundColor = n;
        this.invalidate();
    }

    public void setEdgeColor(int n) {
        this.mEdgeColor = n;
        this.invalidate();
    }

    public void setEdgeType(int n) {
        this.mEdgeType = n;
        this.invalidate();
    }

    public void setForegroundColor(int n) {
        this.mForegroundColor = n;
        this.invalidate();
    }

    public void setText(int n) {
        this.setText(this.getContext().getText(n));
    }

    public void setText(CharSequence charSequence) {
        this.mText.clear();
        this.mText.append(charSequence);
        this.mHasMeasurements = false;
        this.requestLayout();
        this.invalidate();
    }

    public void setTextSize(float f) {
        if (this.mTextPaint.getTextSize() != f) {
            this.mTextPaint.setTextSize(f);
            this.mInnerPaddingX = (int)(0.125f * f + 0.5f);
            this.mHasMeasurements = false;
            this.requestLayout();
            this.invalidate();
        }
    }

    public void setTypeface(Typeface typeface) {
        if (typeface != null && !typeface.equals((Object)this.mTextPaint.getTypeface())) {
            this.mTextPaint.setTypeface(typeface);
            this.mHasMeasurements = false;
            this.requestLayout();
            this.invalidate();
        }
    }
}

