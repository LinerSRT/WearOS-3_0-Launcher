/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint$Join
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.graphics.Typeface
 *  android.media.MediaFormat
 *  android.support.mediacompat.R$dimen
 *  android.text.Spannable
 *  android.text.SpannableStringBuilder
 *  android.text.TextPaint
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.accessibility.CaptioningManager$CaptionStyle
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  android.widget.TextView$BufferType
 */
package android.support.v4.media.subtitle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.media.MediaFormat;
import android.support.mediacompat.R;
import android.support.v4.media.subtitle.Cea608CCParser;
import android.support.v4.media.subtitle.ClosedCaptionWidget;
import android.support.v4.media.subtitle.SubtitleController;
import android.support.v4.media.subtitle.SubtitleTrack;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.CaptioningManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class ClosedCaptionRenderer
extends SubtitleController.Renderer {
    private Cea608CCWidget mCCWidget;
    private final Context mContext;

    public ClosedCaptionRenderer(Context context) {
        this.mContext = context;
    }

    @Override
    public SubtitleTrack createTrack(MediaFormat mediaFormat) {
        if ("text/cea-608".equals(mediaFormat.getString("mime"))) {
            if (this.mCCWidget == null) {
                this.mCCWidget = new Cea608CCWidget(this.mContext);
            }
            return new Cea608CaptionTrack(this.mCCWidget, mediaFormat);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No matching format: ");
        stringBuilder.append(mediaFormat.toString());
        throw new RuntimeException(stringBuilder.toString());
    }

    @Override
    public boolean supports(MediaFormat mediaFormat) {
        if (mediaFormat.containsKey("mime")) {
            return "text/cea-608".equals(mediaFormat.getString("mime"));
        }
        return false;
    }

    class Cea608CCWidget
    extends ClosedCaptionWidget
    implements Cea608CCParser.DisplayListener {
        private static final String DUMMY_TEXT = "1234567890123456789012345678901234";
        private final Rect mTextBounds;

        Cea608CCWidget(Context context) {
            this(context, null);
        }

        Cea608CCWidget(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, 0);
        }

        Cea608CCWidget(Context context, AttributeSet attributeSet, int n) {
            this(context, attributeSet, n, 0);
        }

        Cea608CCWidget(Context context, AttributeSet attributeSet, int n, int n2) {
            super(context, attributeSet, n, n2);
            this.mTextBounds = new Rect();
        }

        @Override
        public ClosedCaptionWidget.ClosedCaptionLayout createCaptionLayout(Context context) {
            return new CCLayout(context);
        }

        @Override
        public CaptioningManager.CaptionStyle getCaptionStyle() {
            return this.mCaptionStyle;
        }

        @Override
        public void onDisplayChanged(SpannableStringBuilder[] spannableStringBuilderArray) {
            ((CCLayout)this.mClosedCaptionLayout).update(spannableStringBuilderArray);
            if (this.mListener != null) {
                this.mListener.onChanged(this);
            }
        }

        private class CCLayout
        extends LinearLayout
        implements ClosedCaptionWidget.ClosedCaptionLayout {
            private static final int MAX_ROWS = 15;
            private static final float SAFE_AREA_RATIO = 0.9f;
            private final CCLineBox[] mLineBoxes;

            CCLayout(Context context) {
                super(context);
                this.mLineBoxes = new CCLineBox[15];
                this.setGravity(0x800003);
                this.setOrientation(1);
                for (int i = 0; i < 15; ++i) {
                    this.mLineBoxes[i] = new CCLineBox(this.getContext());
                    this.addView((View)this.mLineBoxes[i], -2, -2);
                }
            }

            protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
                if ((n3 -= n) * 3 >= (n4 -= n2) * 4) {
                    n2 = n4 * 4 / 3;
                    n = n4;
                } else {
                    n2 = n3;
                    n = n3 * 3 / 4;
                }
                n2 = (int)((float)n2 * 0.9f);
                int n5 = (int)((float)n * 0.9f);
                n3 = (n3 - n2) / 2;
                n4 = (n4 - n5) / 2;
                for (n = 0; n < 15; ++n) {
                    this.mLineBoxes[n].layout(n3, n5 * n / 15 + n4, n3 + n2, (n + 1) * n5 / 15 + n4);
                }
            }

            protected void onMeasure(int n, int n2) {
                super.onMeasure(n, n2);
                n2 = this.getMeasuredWidth();
                n = this.getMeasuredHeight();
                if (n2 * 3 >= n * 4) {
                    n2 = n * 4 / 3;
                } else {
                    n = n2 * 3 / 4;
                }
                int n3 = (int)((float)n2 * 0.9f);
                n2 = View.MeasureSpec.makeMeasureSpec((int)((int)((float)n * 0.9f) / 15), (int)0x40000000);
                n3 = View.MeasureSpec.makeMeasureSpec((int)n3, (int)0x40000000);
                for (n = 0; n < 15; ++n) {
                    this.mLineBoxes[n].measure(n3, n2);
                }
            }

            @Override
            public void setCaptionStyle(CaptioningManager.CaptionStyle captionStyle) {
                for (int i = 0; i < 15; ++i) {
                    this.mLineBoxes[i].setCaptionStyle(captionStyle);
                }
            }

            @Override
            public void setFontScale(float f) {
            }

            void update(SpannableStringBuilder[] spannableStringBuilderArray) {
                for (int i = 0; i < 15; ++i) {
                    if (spannableStringBuilderArray[i] != null) {
                        this.mLineBoxes[i].setText((CharSequence)spannableStringBuilderArray[i], TextView.BufferType.SPANNABLE);
                        this.mLineBoxes[i].setVisibility(0);
                        continue;
                    }
                    this.mLineBoxes[i].setVisibility(4);
                }
            }
        }

        private class CCLineBox
        extends TextView {
            private static final float EDGE_OUTLINE_RATIO = 0.1f;
            private static final float EDGE_SHADOW_RATIO = 0.05f;
            private static final float FONT_PADDING_RATIO = 0.75f;
            private int mBgColor;
            private int mEdgeColor;
            private int mEdgeType;
            private float mOutlineWidth;
            private float mShadowOffset;
            private float mShadowRadius;
            private int mTextColor;

            CCLineBox(Context context) {
                super(context);
                this.mTextColor = -1;
                this.mBgColor = -16777216;
                this.mEdgeType = 0;
                this.mEdgeColor = 0;
                this.setGravity(17);
                this.setBackgroundColor(0);
                this.setTextColor(-1);
                this.setTypeface(Typeface.MONOSPACE);
                this.setVisibility(4);
                Cea608CCWidget.this = this.getContext().getResources();
                this.mOutlineWidth = Cea608CCWidget.this.getDimensionPixelSize(R.dimen.subtitle_outline_width);
                this.mShadowRadius = Cea608CCWidget.this.getDimensionPixelSize(R.dimen.subtitle_shadow_radius);
                this.mShadowOffset = Cea608CCWidget.this.getDimensionPixelSize(R.dimen.subtitle_shadow_offset);
            }

            private void drawEdgeOutline(Canvas canvas) {
                TextPaint textPaint = this.getPaint();
                Paint.Style style2 = textPaint.getStyle();
                Paint.Join join = textPaint.getStrokeJoin();
                float f = textPaint.getStrokeWidth();
                this.setTextColor(this.mEdgeColor);
                textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
                textPaint.setStrokeJoin(Paint.Join.ROUND);
                textPaint.setStrokeWidth(this.mOutlineWidth);
                super.onDraw(canvas);
                this.setTextColor(this.mTextColor);
                textPaint.setStyle(style2);
                textPaint.setStrokeJoin(join);
                textPaint.setStrokeWidth(f);
                this.setBackgroundSpans(0);
                super.onDraw(canvas);
                this.setBackgroundSpans(this.mBgColor);
            }

            private void drawEdgeRaisedOrDepressed(Canvas canvas) {
                TextPaint textPaint = this.getPaint();
                Paint.Style style2 = textPaint.getStyle();
                textPaint.setStyle(Paint.Style.FILL);
                boolean bl = this.mEdgeType == 3;
                int n = -1;
                int n2 = bl ? -1 : this.mEdgeColor;
                if (bl) {
                    n = this.mEdgeColor;
                }
                float f = this.mShadowRadius;
                float f2 = f / 2.0f;
                this.setShadowLayer(f, -f2, -f2, n2);
                super.onDraw(canvas);
                this.setBackgroundSpans(0);
                this.setShadowLayer(this.mShadowRadius, f2, f2, n);
                super.onDraw(canvas);
                textPaint.setStyle(style2);
                this.setBackgroundSpans(this.mBgColor);
            }

            private void setBackgroundSpans(int n) {
                Cea608CCParser.MutableBackgroundColorSpan[] mutableBackgroundColorSpanArray = this.getText();
                if (mutableBackgroundColorSpanArray instanceof Spannable) {
                    mutableBackgroundColorSpanArray = (Spannable)mutableBackgroundColorSpanArray;
                    mutableBackgroundColorSpanArray = (Cea608CCParser.MutableBackgroundColorSpan[])mutableBackgroundColorSpanArray.getSpans(0, mutableBackgroundColorSpanArray.length(), Cea608CCParser.MutableBackgroundColorSpan.class);
                    for (int i = 0; i < mutableBackgroundColorSpanArray.length; ++i) {
                        mutableBackgroundColorSpanArray[i].setBackgroundColor(n);
                    }
                }
            }

            protected void onDraw(Canvas canvas) {
                int n = this.mEdgeType;
                if (n != -1 && n != 0 && n != 2) {
                    if (n == 1) {
                        this.drawEdgeOutline(canvas);
                    } else {
                        this.drawEdgeRaisedOrDepressed(canvas);
                    }
                    return;
                }
                super.onDraw(canvas);
            }

            protected void onMeasure(int n, int n2) {
                float f = (float)View.MeasureSpec.getSize((int)n2) * 0.75f;
                this.setTextSize(0, f);
                this.mOutlineWidth = 0.1f * f + 1.0f;
                this.mShadowRadius = f = 0.05f * f + 1.0f;
                this.mShadowOffset = f;
                this.setScaleX(1.0f);
                this.getPaint().getTextBounds(Cea608CCWidget.DUMMY_TEXT, 0, Cea608CCWidget.DUMMY_TEXT.length(), Cea608CCWidget.this.mTextBounds);
                f = Cea608CCWidget.this.mTextBounds.width();
                this.setScaleX((float)View.MeasureSpec.getSize((int)n) / f);
                super.onMeasure(n, n2);
            }

            void setCaptionStyle(CaptioningManager.CaptionStyle captionStyle) {
                this.mTextColor = captionStyle.foregroundColor;
                this.mBgColor = captionStyle.backgroundColor;
                this.mEdgeType = captionStyle.edgeType;
                this.mEdgeColor = captionStyle.edgeColor;
                this.setTextColor(this.mTextColor);
                if (this.mEdgeType == 2) {
                    float f = this.mShadowRadius;
                    float f2 = this.mShadowOffset;
                    this.setShadowLayer(f, f2, f2, this.mEdgeColor);
                } else {
                    this.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
                }
                this.invalidate();
            }
        }
    }

    static class Cea608CaptionTrack
    extends SubtitleTrack {
        private final Cea608CCParser mCCParser;
        private final Cea608CCWidget mRenderingWidget;

        Cea608CaptionTrack(Cea608CCWidget cea608CCWidget, MediaFormat mediaFormat) {
            super(mediaFormat);
            this.mRenderingWidget = cea608CCWidget;
            this.mCCParser = new Cea608CCParser(this.mRenderingWidget);
        }

        @Override
        public SubtitleTrack.RenderingWidget getRenderingWidget() {
            return this.mRenderingWidget;
        }

        @Override
        public void onData(byte[] byArray, boolean bl, long l) {
            this.mCCParser.parse(byArray);
        }

        @Override
        public void updateView(ArrayList<SubtitleTrack.Cue> arrayList) {
        }
    }
}

