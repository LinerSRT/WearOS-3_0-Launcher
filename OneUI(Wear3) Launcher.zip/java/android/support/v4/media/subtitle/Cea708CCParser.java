/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.util.Log
 */
package android.support.v4.media.subtitle;

import android.graphics.Color;
import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

class Cea708CCParser {
    public static final int CAPTION_EMIT_TYPE_BUFFER = 1;
    public static final int CAPTION_EMIT_TYPE_COMMAND_CLW = 4;
    public static final int CAPTION_EMIT_TYPE_COMMAND_CWX = 3;
    public static final int CAPTION_EMIT_TYPE_COMMAND_DFX = 16;
    public static final int CAPTION_EMIT_TYPE_COMMAND_DLC = 10;
    public static final int CAPTION_EMIT_TYPE_COMMAND_DLW = 8;
    public static final int CAPTION_EMIT_TYPE_COMMAND_DLY = 9;
    public static final int CAPTION_EMIT_TYPE_COMMAND_DSW = 5;
    public static final int CAPTION_EMIT_TYPE_COMMAND_HDW = 6;
    public static final int CAPTION_EMIT_TYPE_COMMAND_RST = 11;
    public static final int CAPTION_EMIT_TYPE_COMMAND_SPA = 12;
    public static final int CAPTION_EMIT_TYPE_COMMAND_SPC = 13;
    public static final int CAPTION_EMIT_TYPE_COMMAND_SPL = 14;
    public static final int CAPTION_EMIT_TYPE_COMMAND_SWA = 15;
    public static final int CAPTION_EMIT_TYPE_COMMAND_TGW = 7;
    public static final int CAPTION_EMIT_TYPE_CONTROL = 2;
    private static final boolean DEBUG = false;
    private static final String MUSIC_NOTE_CHAR = new String("\u266b".getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
    private static final String TAG = "Cea708CCParser";
    private final StringBuilder mBuilder = new StringBuilder();
    private int mCommand = 0;
    private DisplayListener mListener = new DisplayListener(){

        @Override
        public void emitEvent(CaptionEvent captionEvent) {
        }
    };

    Cea708CCParser(DisplayListener displayListener) {
        if (displayListener != null) {
            this.mListener = displayListener;
        }
    }

    private void emitCaptionBuffer() {
        if (this.mBuilder.length() > 0) {
            this.mListener.emitEvent(new CaptionEvent(1, this.mBuilder.toString()));
            this.mBuilder.setLength(0);
        }
    }

    private void emitCaptionEvent(CaptionEvent captionEvent) {
        this.emitCaptionBuffer();
        this.mListener.emitEvent(captionEvent);
    }

    /*
     * Unable to fully structure code
     */
    private int parseC0(byte[] var1_1, int var2_3) {
        block15: {
            block14: {
                block13: {
                    var3_4 = this.mCommand;
                    if (var3_4 < 24 || var3_4 > 31) break block14;
                    if (var3_4 != 24) break block13;
                    if (var1_1[var2_3] != 0) ** GOTO lbl9
                    try {
                        this.mBuilder.append((char)var1_1[var2_3 + 1]);
                        break block13;
lbl9:
                        // 1 sources

                        var4_5 = new String(Arrays.copyOfRange(var1_1, var2_3, var2_3 + 2), "EUC-KR");
                        this.mBuilder.append(var4_5);
                    }
                    catch (UnsupportedEncodingException var1_2) {
                        Log.e((String)"Cea708CCParser", (String)"P16 Code - Could not find supported encoding", (Throwable)var1_2);
                    }
                }
                var2_3 += 2;
                break block15;
            }
            var3_4 = this.mCommand;
            if (var3_4 >= 16 && var3_4 <= 23) {
                ++var2_3;
            } else {
                var3_4 = this.mCommand;
                if (var3_4 != 3) {
                    if (var3_4 != 8) {
                        switch (var3_4) {
                            default: {
                                break;
                            }
                            case 14: {
                                this.emitCaptionEvent(new CaptionEvent(2, Character.valueOf((char)var3_4)));
                                break;
                            }
                            case 13: {
                                this.mBuilder.append('\n');
                                break;
                            }
                            case 12: {
                                this.emitCaptionEvent(new CaptionEvent(2, Character.valueOf((char)var3_4)));
                                break;
                            }
                        }
                    } else {
                        this.emitCaptionEvent(new CaptionEvent(2, Character.valueOf((char)var3_4)));
                    }
                } else {
                    this.emitCaptionEvent(new CaptionEvent(2, Character.valueOf((char)var3_4)));
                }
            }
        }
        return var2_3;
    }

    private int parseC1(byte[] byArray, int n) {
        int n2 = this.mCommand;
        switch (n2) {
            default: {
                break;
            }
            case 152: 
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: 
            case 159: {
                boolean bl = (byArray[n] & 0x20) != 0;
                boolean bl2 = (byArray[n] & 0x10) != 0;
                boolean bl3 = (byArray[n] & 8) != 0;
                byte by = byArray[n];
                boolean bl4 = (byArray[n + 1] & 0x80) != 0;
                byte by2 = byArray[n + 1];
                byte by3 = byArray[n + 2];
                byte by4 = byArray[n + 3];
                byte by5 = byArray[n + 3];
                byte by6 = byArray[n + 4];
                byte by7 = byArray[n + 5];
                this.emitCaptionEvent(new CaptionEvent(16, new CaptionWindow(n2 - 152, bl, bl2, bl3, by & 7, bl4, by2 & 0x7F, by3 & 0xFF, (by4 & 0xF0) >> 4, 0xF & by5, by6 & 0x3F, 7 & byArray[n + 5], (by7 & 0x38) >> 3)));
                n += 6;
                break;
            }
            case 151: {
                CaptionColor captionColor = new CaptionColor((byArray[n] & 0xC0) >> 6, (byArray[n] & 0x30) >> 4, (byArray[n] & 0xC) >> 2, byArray[n] & 3);
                byte by = byArray[n + 1];
                byte by8 = byArray[n + 2];
                CaptionColor captionColor2 = new CaptionColor(0, (byArray[n + 1] & 0x30) >> 4, (byArray[n + 1] & 0xC) >> 2, byArray[n + 1] & 3);
                boolean bl = (byArray[n + 2] & 0x40) != 0;
                byte by9 = byArray[n + 2];
                n2 = byArray[n + 2];
                byte by10 = byArray[n + 2];
                byte by11 = byArray[n + 3];
                this.emitCaptionEvent(new CaptionEvent(15, new CaptionWindowAttr(captionColor, captionColor2, (by8 & 0x80) >> 5 | (by & 0xC0) >> 6, bl, (by9 & 0x30) >> 4, (n2 & 0xC) >> 2, by10 & 3, (0xC & byArray[n + 3]) >> 2, (by11 & 0xF0) >> 4, 3 & byArray[n + 3])));
                n += 4;
                break;
            }
            case 146: {
                this.emitCaptionEvent(new CaptionEvent(14, new CaptionPenLocation(byArray[n] & 0xF, byArray[n + 1] & 0x3F)));
                n += 2;
                break;
            }
            case 145: {
                CaptionColor captionColor = new CaptionColor((byArray[n] & 0xC0) >> 6, (byArray[n] & 0x30) >> 4, (byArray[n] & 0xC) >> 2, byArray[n] & 3);
                CaptionColor captionColor3 = new CaptionColor((byArray[++n] & 0xC0) >> 6, (byArray[n] & 0x30) >> 4, (byArray[n] & 0xC) >> 2, byArray[n] & 3);
                this.emitCaptionEvent(new CaptionEvent(13, new CaptionPenColor(captionColor, captionColor3, new CaptionColor(0, (byArray[++n] & 0x30) >> 4, (0xC & byArray[n]) >> 2, byArray[n] & 3))));
                ++n;
                break;
            }
            case 144: {
                byte by = byArray[n];
                byte by12 = byArray[n];
                byte by13 = byArray[n];
                boolean bl = (byArray[n + 1] & 0x80) != 0;
                boolean bl5 = (byArray[n + 1] & 0x40) != 0;
                byte by14 = byArray[n + 1];
                this.emitCaptionEvent(new CaptionEvent(12, new CaptionPenAttr(by12 & 3, (by13 & 0xC) >> 2, (by & 0xF0) >> 4, 7 & byArray[n + 1], (by14 & 0x38) >> 3, bl5, bl)));
                n += 2;
                break;
            }
            case 143: {
                this.emitCaptionEvent(new CaptionEvent(11, null));
                break;
            }
            case 142: {
                this.emitCaptionEvent(new CaptionEvent(10, null));
                break;
            }
            case 141: {
                byte by = byArray[n];
                ++n;
                this.emitCaptionEvent(new CaptionEvent(9, by & 0xFF));
                break;
            }
            case 140: {
                byte by = byArray[n];
                ++n;
                this.emitCaptionEvent(new CaptionEvent(8, by & 0xFF));
                break;
            }
            case 139: {
                byte by = byArray[n];
                ++n;
                this.emitCaptionEvent(new CaptionEvent(7, by & 0xFF));
                break;
            }
            case 138: {
                byte by = byArray[n];
                ++n;
                this.emitCaptionEvent(new CaptionEvent(6, by & 0xFF));
                break;
            }
            case 137: {
                byte by = byArray[n];
                ++n;
                this.emitCaptionEvent(new CaptionEvent(5, by & 0xFF));
                break;
            }
            case 136: {
                byte by = byArray[n];
                ++n;
                this.emitCaptionEvent(new CaptionEvent(4, by & 0xFF));
                break;
            }
            case 128: 
            case 129: 
            case 130: 
            case 131: 
            case 132: 
            case 133: 
            case 134: 
            case 135: {
                this.emitCaptionEvent(new CaptionEvent(3, n2 - 128));
            }
        }
        return n;
    }

    private int parseC2(byte[] byArray, int n) {
        int n2 = this.mCommand;
        if (n2 >= 0 && n2 <= 7) {
            n2 = n;
        } else {
            n2 = this.mCommand;
            if (n2 >= 8 && n2 <= 15) {
                n2 = n + 1;
            } else {
                n2 = this.mCommand;
                if (n2 >= 16 && n2 <= 23) {
                    n2 = n + 2;
                } else {
                    int n3 = this.mCommand;
                    n2 = n;
                    if (n3 >= 24) {
                        n2 = n;
                        if (n3 <= 31) {
                            n2 = n + 3;
                        }
                    }
                }
            }
        }
        return n2;
    }

    private int parseC3(byte[] byArray, int n) {
        int n2 = this.mCommand;
        if (n2 >= 128 && n2 <= 135) {
            n2 = n + 4;
        } else {
            int n3 = this.mCommand;
            n2 = n;
            if (n3 >= 136) {
                n2 = n;
                if (n3 <= 143) {
                    n2 = n + 5;
                }
            }
        }
        return n2;
    }

    private int parseExt1(byte[] byArray, int n) {
        int n2;
        this.mCommand = n2 = byArray[n] & 0xFF;
        int n3 = n + 1;
        if (n2 >= 0 && n2 <= 31) {
            n = this.parseC2(byArray, n3);
        } else {
            n = this.mCommand;
            if (n >= 128 && n <= 159) {
                n = this.parseC3(byArray, n3);
            } else {
                n = this.mCommand;
                if (n >= 32 && n <= 127) {
                    n = this.parseG2(byArray, n3);
                } else {
                    n2 = this.mCommand;
                    n = n3;
                    if (n2 >= 160) {
                        n = n3;
                        if (n2 <= 255) {
                            n = this.parseG3(byArray, n3);
                        }
                    }
                }
            }
        }
        return n;
    }

    private int parseG0(byte[] byArray, int n) {
        int n2 = this.mCommand;
        if (n2 == 127) {
            this.mBuilder.append(MUSIC_NOTE_CHAR);
        } else {
            this.mBuilder.append((char)n2);
        }
        return n;
    }

    private int parseG1(byte[] byArray, int n) {
        this.mBuilder.append((char)this.mCommand);
        return n;
    }

    private int parseG2(byte[] byArray, int n) {
        return n;
    }

    private int parseG3(byte[] byArray, int n) {
        return n;
    }

    private int parseServiceBlockData(byte[] byArray, int n) {
        int n2;
        this.mCommand = n2 = byArray[n] & 0xFF;
        int n3 = n + 1;
        if (n2 == 16) {
            n = this.parseExt1(byArray, n3);
        } else if (n2 >= 0 && n2 <= 31) {
            n = this.parseC0(byArray, n3);
        } else {
            n = this.mCommand;
            if (n >= 128 && n <= 159) {
                n = this.parseC1(byArray, n3);
            } else {
                n = this.mCommand;
                if (n >= 32 && n <= 127) {
                    n = this.parseG0(byArray, n3);
                } else {
                    n2 = this.mCommand;
                    n = n3;
                    if (n2 >= 160) {
                        n = n3;
                        if (n2 <= 255) {
                            n = this.parseG1(byArray, n3);
                        }
                    }
                }
            }
        }
        return n;
    }

    public void parse(byte[] byArray) {
        int n = 0;
        while (n < byArray.length) {
            n = this.parseServiceBlockData(byArray, n);
        }
        this.emitCaptionBuffer();
    }

    public static class CaptionColor {
        private static final int[] COLOR_MAP = new int[]{0, 15, 240, 255};
        public static final int OPACITY_FLASH = 1;
        private static final int[] OPACITY_MAP = new int[]{255, 254, 128, 0};
        public static final int OPACITY_SOLID = 0;
        public static final int OPACITY_TRANSLUCENT = 2;
        public static final int OPACITY_TRANSPARENT = 3;
        public final int blue;
        public final int green;
        public final int opacity;
        public final int red;

        CaptionColor(int n, int n2, int n3, int n4) {
            this.opacity = n;
            this.red = n2;
            this.green = n3;
            this.blue = n4;
        }

        public int getArgbValue() {
            int n = OPACITY_MAP[this.opacity];
            int[] nArray = COLOR_MAP;
            return Color.argb((int)n, (int)nArray[this.red], (int)nArray[this.green], (int)nArray[this.blue]);
        }
    }

    public static class CaptionEvent {
        public final Object obj;
        public final int type;

        CaptionEvent(int n, Object object) {
            this.type = n;
            this.obj = object;
        }
    }

    public static class CaptionPenAttr {
        public static final int OFFSET_NORMAL = 1;
        public static final int OFFSET_SUBSCRIPT = 0;
        public static final int OFFSET_SUPERSCRIPT = 2;
        public static final int PEN_SIZE_LARGE = 2;
        public static final int PEN_SIZE_SMALL = 0;
        public static final int PEN_SIZE_STANDARD = 1;
        public final int edgeType;
        public final int fontTag;
        public final boolean italic;
        public final int penOffset;
        public final int penSize;
        public final int textTag;
        public final boolean underline;

        CaptionPenAttr(int n, int n2, int n3, int n4, int n5, boolean bl, boolean bl2) {
            this.penSize = n;
            this.penOffset = n2;
            this.textTag = n3;
            this.fontTag = n4;
            this.edgeType = n5;
            this.underline = bl;
            this.italic = bl2;
        }
    }

    public static class CaptionPenColor {
        public final CaptionColor backgroundColor;
        public final CaptionColor edgeColor;
        public final CaptionColor foregroundColor;

        CaptionPenColor(CaptionColor captionColor, CaptionColor captionColor2, CaptionColor captionColor3) {
            this.foregroundColor = captionColor;
            this.backgroundColor = captionColor2;
            this.edgeColor = captionColor3;
        }
    }

    public static class CaptionPenLocation {
        public final int column;
        public final int row;

        CaptionPenLocation(int n, int n2) {
            this.row = n;
            this.column = n2;
        }
    }

    public static class CaptionWindow {
        public final int anchorHorizontal;
        public final int anchorId;
        public final int anchorVertical;
        public final int columnCount;
        public final boolean columnLock;
        public final int id;
        public final int penStyle;
        public final int priority;
        public final boolean relativePositioning;
        public final int rowCount;
        public final boolean rowLock;
        public final boolean visible;
        public final int windowStyle;

        CaptionWindow(int n, boolean bl, boolean bl2, boolean bl3, int n2, boolean bl4, int n3, int n4, int n5, int n6, int n7, int n8, int n9) {
            this.id = n;
            this.visible = bl;
            this.rowLock = bl2;
            this.columnLock = bl3;
            this.priority = n2;
            this.relativePositioning = bl4;
            this.anchorVertical = n3;
            this.anchorHorizontal = n4;
            this.anchorId = n5;
            this.rowCount = n6;
            this.columnCount = n7;
            this.penStyle = n8;
            this.windowStyle = n9;
        }
    }

    public static class CaptionWindowAttr {
        public final CaptionColor borderColor;
        public final int borderType;
        public final int displayEffect;
        public final int effectDirection;
        public final int effectSpeed;
        public final CaptionColor fillColor;
        public final int justify;
        public final int printDirection;
        public final int scrollDirection;
        public final boolean wordWrap;

        CaptionWindowAttr(CaptionColor captionColor, CaptionColor captionColor2, int n, boolean bl, int n2, int n3, int n4, int n5, int n6, int n7) {
            this.fillColor = captionColor;
            this.borderColor = captionColor2;
            this.borderType = n;
            this.wordWrap = bl;
            this.printDirection = n2;
            this.scrollDirection = n3;
            this.justify = n4;
            this.effectDirection = n5;
            this.effectSpeed = n6;
            this.displayEffect = n7;
        }
    }

    private static class Const {
        public static final int CODE_C0_BS = 8;
        public static final int CODE_C0_CR = 13;
        public static final int CODE_C0_ETX = 3;
        public static final int CODE_C0_EXT1 = 16;
        public static final int CODE_C0_FF = 12;
        public static final int CODE_C0_HCR = 14;
        public static final int CODE_C0_NUL = 0;
        public static final int CODE_C0_P16 = 24;
        public static final int CODE_C0_RANGE_END = 31;
        public static final int CODE_C0_RANGE_START = 0;
        public static final int CODE_C0_SKIP1_RANGE_END = 23;
        public static final int CODE_C0_SKIP1_RANGE_START = 16;
        public static final int CODE_C0_SKIP2_RANGE_END = 31;
        public static final int CODE_C0_SKIP2_RANGE_START = 24;
        public static final int CODE_C1_CLW = 136;
        public static final int CODE_C1_CW0 = 128;
        public static final int CODE_C1_CW1 = 129;
        public static final int CODE_C1_CW2 = 130;
        public static final int CODE_C1_CW3 = 131;
        public static final int CODE_C1_CW4 = 132;
        public static final int CODE_C1_CW5 = 133;
        public static final int CODE_C1_CW6 = 134;
        public static final int CODE_C1_CW7 = 135;
        public static final int CODE_C1_DF0 = 152;
        public static final int CODE_C1_DF1 = 153;
        public static final int CODE_C1_DF2 = 154;
        public static final int CODE_C1_DF3 = 155;
        public static final int CODE_C1_DF4 = 156;
        public static final int CODE_C1_DF5 = 157;
        public static final int CODE_C1_DF6 = 158;
        public static final int CODE_C1_DF7 = 159;
        public static final int CODE_C1_DLC = 142;
        public static final int CODE_C1_DLW = 140;
        public static final int CODE_C1_DLY = 141;
        public static final int CODE_C1_DSW = 137;
        public static final int CODE_C1_HDW = 138;
        public static final int CODE_C1_RANGE_END = 159;
        public static final int CODE_C1_RANGE_START = 128;
        public static final int CODE_C1_RST = 143;
        public static final int CODE_C1_SPA = 144;
        public static final int CODE_C1_SPC = 145;
        public static final int CODE_C1_SPL = 146;
        public static final int CODE_C1_SWA = 151;
        public static final int CODE_C1_TGW = 139;
        public static final int CODE_C2_RANGE_END = 31;
        public static final int CODE_C2_RANGE_START = 0;
        public static final int CODE_C2_SKIP0_RANGE_END = 7;
        public static final int CODE_C2_SKIP0_RANGE_START = 0;
        public static final int CODE_C2_SKIP1_RANGE_END = 15;
        public static final int CODE_C2_SKIP1_RANGE_START = 8;
        public static final int CODE_C2_SKIP2_RANGE_END = 23;
        public static final int CODE_C2_SKIP2_RANGE_START = 16;
        public static final int CODE_C2_SKIP3_RANGE_END = 31;
        public static final int CODE_C2_SKIP3_RANGE_START = 24;
        public static final int CODE_C3_RANGE_END = 159;
        public static final int CODE_C3_RANGE_START = 128;
        public static final int CODE_C3_SKIP4_RANGE_END = 135;
        public static final int CODE_C3_SKIP4_RANGE_START = 128;
        public static final int CODE_C3_SKIP5_RANGE_END = 143;
        public static final int CODE_C3_SKIP5_RANGE_START = 136;
        public static final int CODE_G0_MUSICNOTE = 127;
        public static final int CODE_G0_RANGE_END = 127;
        public static final int CODE_G0_RANGE_START = 32;
        public static final int CODE_G1_RANGE_END = 255;
        public static final int CODE_G1_RANGE_START = 160;
        public static final int CODE_G2_BLK = 48;
        public static final int CODE_G2_NBTSP = 33;
        public static final int CODE_G2_RANGE_END = 127;
        public static final int CODE_G2_RANGE_START = 32;
        public static final int CODE_G2_TSP = 32;
        public static final int CODE_G3_CC = 160;
        public static final int CODE_G3_RANGE_END = 255;
        public static final int CODE_G3_RANGE_START = 160;

        private Const() {
        }
    }

    static interface DisplayListener {
        public void emitEvent(CaptionEvent var1);
    }
}

