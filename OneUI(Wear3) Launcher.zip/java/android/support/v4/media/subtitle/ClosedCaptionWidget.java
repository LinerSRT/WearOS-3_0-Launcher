/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.accessibility.CaptioningManager
 *  android.view.accessibility.CaptioningManager$CaptionStyle
 *  android.view.accessibility.CaptioningManager$CaptioningChangeListener
 */
package android.support.v4.media.subtitle;

import android.content.Context;
import android.support.v4.media.subtitle.SubtitleTrack;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.CaptioningManager;

abstract class ClosedCaptionWidget
extends ViewGroup
implements SubtitleTrack.RenderingWidget {
    protected CaptioningManager.CaptionStyle mCaptionStyle;
    private final CaptioningManager.CaptioningChangeListener mCaptioningListener = new CaptioningManager.CaptioningChangeListener(){

        public void onFontScaleChanged(float f) {
            ClosedCaptionWidget.this.mClosedCaptionLayout.setFontScale(f);
        }

        public void onUserStyleChanged(CaptioningManager.CaptionStyle captionStyle) {
            ClosedCaptionWidget.this.mCaptionStyle = captionStyle;
            ClosedCaptionWidget.this.mClosedCaptionLayout.setCaptionStyle(ClosedCaptionWidget.this.mCaptionStyle);
        }
    };
    protected ClosedCaptionLayout mClosedCaptionLayout;
    private boolean mHasChangeListener;
    protected SubtitleTrack.RenderingWidget.OnChangedListener mListener;
    private final CaptioningManager mManager;

    ClosedCaptionWidget(Context context) {
        this(context, null);
    }

    ClosedCaptionWidget(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    ClosedCaptionWidget(Context context, AttributeSet attributeSet, int n) {
        this(context, attributeSet, n, 0);
    }

    ClosedCaptionWidget(Context object, AttributeSet attributeSet, int n, int n2) {
        super((Context)object, attributeSet, n, n2);
        this.setLayerType(1, null);
        attributeSet = (CaptioningManager)object.getSystemService("captioning");
        this.mManager = attributeSet;
        this.mCaptionStyle = attributeSet.getUserStyle();
        object = this.createCaptionLayout((Context)object);
        this.mClosedCaptionLayout = object;
        object.setCaptionStyle(this.mCaptionStyle);
        this.mClosedCaptionLayout.setFontScale(this.mManager.getFontScale());
        this.addView((View)((ViewGroup)this.mClosedCaptionLayout), -1, -1);
        this.requestLayout();
    }

    private void manageChangeListener() {
        boolean bl = this.isAttachedToWindow() && this.getVisibility() == 0;
        if (this.mHasChangeListener != bl) {
            this.mHasChangeListener = bl;
            if (bl) {
                this.mManager.addCaptioningChangeListener(this.mCaptioningListener);
            } else {
                this.mManager.removeCaptioningChangeListener(this.mCaptioningListener);
            }
        }
    }

    public abstract ClosedCaptionLayout createCaptionLayout(Context var1);

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.manageChangeListener();
    }

    @Override
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.manageChangeListener();
    }

    protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        ((ViewGroup)this.mClosedCaptionLayout).layout(n, n2, n3, n4);
    }

    protected void onMeasure(int n, int n2) {
        super.onMeasure(n, n2);
        ((ViewGroup)this.mClosedCaptionLayout).measure(n, n2);
    }

    @Override
    public void setOnChangedListener(SubtitleTrack.RenderingWidget.OnChangedListener onChangedListener) {
        this.mListener = onChangedListener;
    }

    @Override
    public void setSize(int n, int n2) {
        this.measure(View.MeasureSpec.makeMeasureSpec((int)n, (int)0x40000000), View.MeasureSpec.makeMeasureSpec((int)n2, (int)0x40000000));
        this.layout(0, 0, n, n2);
    }

    @Override
    public void setVisible(boolean bl) {
        if (bl) {
            this.setVisibility(0);
        } else {
            this.setVisibility(8);
        }
        this.manageChangeListener();
    }

    static interface ClosedCaptionLayout {
        public void setCaptionStyle(CaptioningManager.CaptionStyle var1);

        public void setFontScale(float var1);
    }
}

