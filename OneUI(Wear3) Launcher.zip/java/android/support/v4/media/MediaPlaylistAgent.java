/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package android.support.v4.media;

import android.support.v4.media.DataSourceDesc;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.util.SimpleArrayMap;
import android.util.Log;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import java.util.concurrent.Executor;

public abstract class MediaPlaylistAgent {
    public static final int REPEAT_MODE_ALL = 2;
    public static final int REPEAT_MODE_GROUP = 3;
    public static final int REPEAT_MODE_NONE = 0;
    public static final int REPEAT_MODE_ONE = 1;
    public static final int SHUFFLE_MODE_ALL = 1;
    public static final int SHUFFLE_MODE_GROUP = 2;
    public static final int SHUFFLE_MODE_NONE = 0;
    private static final String TAG = "MediaPlaylistAgent";
    private final SimpleArrayMap<PlaylistEventCallback, Executor> mCallbacks;
    private final Object mLock = new Object();

    public MediaPlaylistAgent() {
        this.mCallbacks = new SimpleArrayMap();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private SimpleArrayMap<PlaylistEventCallback, Executor> getCallbacks() {
        SimpleArrayMap<PlaylistEventCallback, Executor> simpleArrayMap = new SimpleArrayMap<PlaylistEventCallback, Executor>();
        Object object = this.mLock;
        synchronized (object) {
            simpleArrayMap.putAll(this.mCallbacks);
            return simpleArrayMap;
        }
    }

    public abstract void addPlaylistItem(int var1, MediaItem2 var2);

    public abstract MediaItem2 getCurrentMediaItem();

    public MediaItem2 getMediaItem(DataSourceDesc dataSourceDesc) {
        if (dataSourceDesc != null) {
            List<MediaItem2> list = this.getPlaylist();
            if (list == null) {
                return null;
            }
            for (int i = 0; i < list.size(); ++i) {
                MediaItem2 mediaItem2 = list.get(i);
                if (mediaItem2 == null || !mediaItem2.getDataSourceDesc().equals(dataSourceDesc)) continue;
                return mediaItem2;
            }
            return null;
        }
        throw new IllegalArgumentException("dsd shouldn't be null");
    }

    public abstract List<MediaItem2> getPlaylist();

    public abstract MediaMetadata2 getPlaylistMetadata();

    public abstract int getRepeatMode();

    public abstract int getShuffleMode();

    public final void notifyPlaylistChanged() {
        SimpleArrayMap<PlaylistEventCallback, Executor> simpleArrayMap = this.getCallbacks();
        final List<MediaItem2> list = this.getPlaylist();
        final MediaMetadata2 mediaMetadata2 = this.getPlaylistMetadata();
        for (int i = 0; i < simpleArrayMap.size(); ++i) {
            final PlaylistEventCallback playlistEventCallback = simpleArrayMap.keyAt(i);
            simpleArrayMap.valueAt(i).execute(new Runnable(){

                @Override
                public void run() {
                    playlistEventCallback.onPlaylistChanged(MediaPlaylistAgent.this, list, mediaMetadata2);
                }
            });
        }
    }

    public final void notifyPlaylistMetadataChanged() {
        SimpleArrayMap<PlaylistEventCallback, Executor> simpleArrayMap = this.getCallbacks();
        for (int i = 0; i < simpleArrayMap.size(); ++i) {
            final PlaylistEventCallback playlistEventCallback = simpleArrayMap.keyAt(i);
            simpleArrayMap.valueAt(i).execute(new Runnable(){

                @Override
                public void run() {
                    PlaylistEventCallback playlistEventCallback2 = playlistEventCallback;
                    MediaPlaylistAgent mediaPlaylistAgent = MediaPlaylistAgent.this;
                    playlistEventCallback2.onPlaylistMetadataChanged(mediaPlaylistAgent, mediaPlaylistAgent.getPlaylistMetadata());
                }
            });
        }
    }

    public final void notifyRepeatModeChanged() {
        SimpleArrayMap<PlaylistEventCallback, Executor> simpleArrayMap = this.getCallbacks();
        for (int i = 0; i < simpleArrayMap.size(); ++i) {
            final PlaylistEventCallback playlistEventCallback = simpleArrayMap.keyAt(i);
            simpleArrayMap.valueAt(i).execute(new Runnable(){

                @Override
                public void run() {
                    PlaylistEventCallback playlistEventCallback2 = playlistEventCallback;
                    MediaPlaylistAgent mediaPlaylistAgent = MediaPlaylistAgent.this;
                    playlistEventCallback2.onRepeatModeChanged(mediaPlaylistAgent, mediaPlaylistAgent.getRepeatMode());
                }
            });
        }
    }

    public final void notifyShuffleModeChanged() {
        SimpleArrayMap<PlaylistEventCallback, Executor> simpleArrayMap = this.getCallbacks();
        for (int i = 0; i < simpleArrayMap.size(); ++i) {
            final PlaylistEventCallback playlistEventCallback = simpleArrayMap.keyAt(i);
            simpleArrayMap.valueAt(i).execute(new Runnable(){

                @Override
                public void run() {
                    PlaylistEventCallback playlistEventCallback2 = playlistEventCallback;
                    MediaPlaylistAgent mediaPlaylistAgent = MediaPlaylistAgent.this;
                    playlistEventCallback2.onShuffleModeChanged(mediaPlaylistAgent, mediaPlaylistAgent.getShuffleMode());
                }
            });
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void registerPlaylistEventCallback(Executor executor, PlaylistEventCallback playlistEventCallback) {
        if (executor == null) {
            throw new IllegalArgumentException("executor shouldn't be null");
        }
        if (playlistEventCallback == null) {
            throw new IllegalArgumentException("callback shouldn't be null");
        }
        Object object = this.mLock;
        synchronized (object) {
            if (this.mCallbacks.get(playlistEventCallback) != null) {
                Log.w((String)"MediaPlaylistAgent", (String)"callback is already added. Ignoring.");
                return;
            }
            this.mCallbacks.put(playlistEventCallback, executor);
            return;
        }
    }

    public abstract void removePlaylistItem(MediaItem2 var1);

    public abstract void replacePlaylistItem(int var1, MediaItem2 var2);

    public abstract void setPlaylist(List<MediaItem2> var1, MediaMetadata2 var2);

    public abstract void setRepeatMode(int var1);

    public abstract void setShuffleMode(int var1);

    public abstract void skipToNextItem();

    public abstract void skipToPlaylistItem(MediaItem2 var1);

    public abstract void skipToPreviousItem();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void unregisterPlaylistEventCallback(PlaylistEventCallback playlistEventCallback) {
        if (playlistEventCallback != null) {
            Object object = this.mLock;
            synchronized (object) {
                this.mCallbacks.remove(playlistEventCallback);
                return;
            }
        }
        throw new IllegalArgumentException("callback shouldn't be null");
    }

    public abstract void updatePlaylistMetadata(MediaMetadata2 var1);

    public static abstract class PlaylistEventCallback {
        public void onPlaylistChanged(MediaPlaylistAgent mediaPlaylistAgent, List<MediaItem2> list, MediaMetadata2 mediaMetadata2) {
        }

        public void onPlaylistMetadataChanged(MediaPlaylistAgent mediaPlaylistAgent, MediaMetadata2 mediaMetadata2) {
        }

        public void onRepeatModeChanged(MediaPlaylistAgent mediaPlaylistAgent, int n) {
        }

        public void onShuffleModeChanged(MediaPlaylistAgent mediaPlaylistAgent, int n) {
        }
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface RepeatMode {
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface ShuffleMode {
    }
}

