/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.RemoteException
 *  android.os.ResultReceiver
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.IMediaSession2;
import java.util.ArrayList;
import java.util.List;

public interface IMediaController2
extends IInterface {
    public void onAllowedCommandsChanged(Bundle var1) throws RemoteException;

    public void onBufferingStateChanged(Bundle var1, int var2, long var3) throws RemoteException;

    public void onChildrenChanged(String var1, int var2, Bundle var3) throws RemoteException;

    public void onConnected(IMediaSession2 var1, Bundle var2, int var3, Bundle var4, long var5, long var7, float var9, long var10, Bundle var12, int var13, int var14, List<Bundle> var15, PendingIntent var16) throws RemoteException;

    public void onCurrentMediaItemChanged(Bundle var1) throws RemoteException;

    public void onCustomCommand(Bundle var1, Bundle var2, ResultReceiver var3) throws RemoteException;

    public void onCustomLayoutChanged(List<Bundle> var1) throws RemoteException;

    public void onDisconnected() throws RemoteException;

    public void onError(int var1, Bundle var2) throws RemoteException;

    public void onGetChildrenDone(String var1, int var2, int var3, List<Bundle> var4, Bundle var5) throws RemoteException;

    public void onGetItemDone(String var1, Bundle var2) throws RemoteException;

    public void onGetLibraryRootDone(Bundle var1, String var2, Bundle var3) throws RemoteException;

    public void onGetSearchResultDone(String var1, int var2, int var3, List<Bundle> var4, Bundle var5) throws RemoteException;

    public void onPlaybackInfoChanged(Bundle var1) throws RemoteException;

    public void onPlaybackSpeedChanged(long var1, long var3, float var5) throws RemoteException;

    public void onPlayerStateChanged(long var1, long var3, int var5) throws RemoteException;

    public void onPlaylistChanged(List<Bundle> var1, Bundle var2) throws RemoteException;

    public void onPlaylistMetadataChanged(Bundle var1) throws RemoteException;

    public void onRepeatModeChanged(int var1) throws RemoteException;

    public void onRoutesInfoChanged(List<Bundle> var1) throws RemoteException;

    public void onSearchResultChanged(String var1, int var2, Bundle var3) throws RemoteException;

    public void onSeekCompleted(long var1, long var3, long var5) throws RemoteException;

    public void onShuffleModeChanged(int var1) throws RemoteException;

    public static abstract class Stub
    extends Binder
    implements IMediaController2 {
        private static final String DESCRIPTOR = "android.support.v4.media.IMediaController2";
        static final int TRANSACTION_onAllowedCommandsChanged = 16;
        static final int TRANSACTION_onBufferingStateChanged = 4;
        static final int TRANSACTION_onChildrenChanged = 20;
        static final int TRANSACTION_onConnected = 13;
        static final int TRANSACTION_onCurrentMediaItemChanged = 1;
        static final int TRANSACTION_onCustomCommand = 17;
        static final int TRANSACTION_onCustomLayoutChanged = 15;
        static final int TRANSACTION_onDisconnected = 14;
        static final int TRANSACTION_onError = 11;
        static final int TRANSACTION_onGetChildrenDone = 21;
        static final int TRANSACTION_onGetItemDone = 19;
        static final int TRANSACTION_onGetLibraryRootDone = 18;
        static final int TRANSACTION_onGetSearchResultDone = 23;
        static final int TRANSACTION_onPlaybackInfoChanged = 7;
        static final int TRANSACTION_onPlaybackSpeedChanged = 3;
        static final int TRANSACTION_onPlayerStateChanged = 2;
        static final int TRANSACTION_onPlaylistChanged = 5;
        static final int TRANSACTION_onPlaylistMetadataChanged = 6;
        static final int TRANSACTION_onRepeatModeChanged = 8;
        static final int TRANSACTION_onRoutesInfoChanged = 12;
        static final int TRANSACTION_onSearchResultChanged = 22;
        static final int TRANSACTION_onSeekCompleted = 10;
        static final int TRANSACTION_onShuffleModeChanged = 9;

        public Stub() {
            this.attachInterface(this, DESCRIPTOR);
        }

        public static IMediaController2 asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface(DESCRIPTOR);
            if (iInterface != null && iInterface instanceof IMediaController2) {
                return (IMediaController2)iInterface;
            }
            return new Proxy(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int n, Parcel object, Parcel object2, int n2) throws RemoteException {
            if (n != 1598968902) {
                switch (n) {
                    default: {
                        return super.onTransact(n, object, object2, n2);
                    }
                    case 23: {
                        object.enforceInterface(DESCRIPTOR);
                        String string2 = object.readString();
                        n2 = object.readInt();
                        n = object.readInt();
                        object2 = object.createTypedArrayList(Bundle.CREATOR);
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onGetSearchResultDone(string2, n2, n, (List)object2, (Bundle)object);
                        return true;
                    }
                    case 22: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = object.readString();
                        n = object.readInt();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onSearchResultChanged((String)object2, n, (Bundle)object);
                        return true;
                    }
                    case 21: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = object.readString();
                        n2 = object.readInt();
                        n = object.readInt();
                        ArrayList arrayList = object.createTypedArrayList(Bundle.CREATOR);
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onGetChildrenDone((String)object2, n2, n, arrayList, (Bundle)object);
                        return true;
                    }
                    case 20: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = object.readString();
                        n = object.readInt();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onChildrenChanged((String)object2, n, (Bundle)object);
                        return true;
                    }
                    case 19: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onGetItemDone((String)object2, (Bundle)object);
                        return true;
                    }
                    case 18: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        String string3 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onGetLibraryRootDone((Bundle)object2, string3, (Bundle)object);
                        return true;
                    }
                    case 17: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        Bundle bundle = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        object = object.readInt() != 0 ? (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(object) : null;
                        this.onCustomCommand((Bundle)object2, bundle, (ResultReceiver)object);
                        return true;
                    }
                    case 16: {
                        object.enforceInterface(DESCRIPTOR);
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onAllowedCommandsChanged((Bundle)object);
                        return true;
                    }
                    case 15: {
                        object.enforceInterface(DESCRIPTOR);
                        this.onCustomLayoutChanged(object.createTypedArrayList(Bundle.CREATOR));
                        return true;
                    }
                    case 14: {
                        object.enforceInterface(DESCRIPTOR);
                        this.onDisconnected();
                        return true;
                    }
                    case 13: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaSession2 iMediaSession2 = IMediaSession2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        n2 = object.readInt();
                        Bundle bundle = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        long l = object.readLong();
                        long l2 = object.readLong();
                        float f = object.readFloat();
                        long l3 = object.readLong();
                        Bundle bundle2 = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        int n3 = object.readInt();
                        n = object.readInt();
                        ArrayList arrayList = object.createTypedArrayList(Bundle.CREATOR);
                        object = object.readInt() != 0 ? (PendingIntent)PendingIntent.CREATOR.createFromParcel(object) : null;
                        this.onConnected(iMediaSession2, (Bundle)object2, n2, bundle, l, l2, f, l3, bundle2, n3, n, arrayList, (PendingIntent)object);
                        return true;
                    }
                    case 12: {
                        object.enforceInterface(DESCRIPTOR);
                        this.onRoutesInfoChanged(object.createTypedArrayList(Bundle.CREATOR));
                        return true;
                    }
                    case 11: {
                        object.enforceInterface(DESCRIPTOR);
                        n = object.readInt();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onError(n, (Bundle)object);
                        return true;
                    }
                    case 10: {
                        object.enforceInterface(DESCRIPTOR);
                        this.onSeekCompleted(object.readLong(), object.readLong(), object.readLong());
                        return true;
                    }
                    case 9: {
                        object.enforceInterface(DESCRIPTOR);
                        this.onShuffleModeChanged(object.readInt());
                        return true;
                    }
                    case 8: {
                        object.enforceInterface(DESCRIPTOR);
                        this.onRepeatModeChanged(object.readInt());
                        return true;
                    }
                    case 7: {
                        object.enforceInterface(DESCRIPTOR);
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onPlaybackInfoChanged((Bundle)object);
                        return true;
                    }
                    case 6: {
                        object.enforceInterface(DESCRIPTOR);
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onPlaylistMetadataChanged((Bundle)object);
                        return true;
                    }
                    case 5: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = object.createTypedArrayList(Bundle.CREATOR);
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onPlaylistChanged((List)object2, (Bundle)object);
                        return true;
                    }
                    case 4: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.onBufferingStateChanged((Bundle)object2, object.readInt(), object.readLong());
                        return true;
                    }
                    case 3: {
                        object.enforceInterface(DESCRIPTOR);
                        this.onPlaybackSpeedChanged(object.readLong(), object.readLong(), object.readFloat());
                        return true;
                    }
                    case 2: {
                        object.enforceInterface(DESCRIPTOR);
                        this.onPlayerStateChanged(object.readLong(), object.readLong(), object.readInt());
                        return true;
                    }
                    case 1: 
                }
                object.enforceInterface(DESCRIPTOR);
                object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                this.onCurrentMediaItemChanged((Bundle)object);
                return true;
            }
            object2.writeString(DESCRIPTOR);
            return true;
        }

        private static class Proxy
        implements IMediaController2 {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            @Override
            public void onAllowedCommandsChanged(Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(16, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onBufferingStateChanged(Bundle bundle, int n, long l) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    parcel.writeInt(n);
                    parcel.writeLong(l);
                    this.mRemote.transact(4, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onChildrenChanged(String string2, int n, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeString(string2);
                    parcel.writeInt(n);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(20, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * WARNING - void declaration
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void onConnected(IMediaSession2 iMediaSession2, Bundle bundle, int n, Bundle bundle2, long l, long l2, float f, long l3, Bundle bundle3, int n2, int n3, List<Bundle> list, PendingIntent pendingIntent) throws RemoteException {
                void var1_10;
                Parcel parcel;
                block25: {
                    parcel = Parcel.obtain();
                    try {
                        parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                        iMediaSession2 = iMediaSession2 != null ? iMediaSession2.asBinder() : null;
                        parcel.writeStrongBinder((IBinder)iMediaSession2);
                        if (bundle != null) {
                            parcel.writeInt(1);
                            bundle.writeToParcel(parcel, 0);
                        } else {
                            parcel.writeInt(0);
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                        break block25;
                    }
                    try {
                        parcel.writeInt(n);
                        if (bundle2 != null) {
                            parcel.writeInt(1);
                            bundle2.writeToParcel(parcel, 0);
                        } else {
                            parcel.writeInt(0);
                        }
                    }
                    catch (Throwable throwable) {
                        break block25;
                    }
                    try {
                        parcel.writeLong(l);
                    }
                    catch (Throwable throwable) {
                        break block25;
                    }
                    try {
                        parcel.writeLong(l2);
                    }
                    catch (Throwable throwable) {
                        break block25;
                    }
                    try {
                        parcel.writeFloat(f);
                    }
                    catch (Throwable throwable) {
                        break block25;
                    }
                    try {
                        parcel.writeLong(l3);
                        if (bundle3 != null) {
                            parcel.writeInt(1);
                            bundle3.writeToParcel(parcel, 0);
                        } else {
                            parcel.writeInt(0);
                        }
                    }
                    catch (Throwable throwable) {
                        break block25;
                    }
                    try {
                        parcel.writeInt(n2);
                    }
                    catch (Throwable throwable) {
                        break block25;
                    }
                    try {
                        parcel.writeInt(n3);
                        parcel.writeTypedList(list);
                        if (pendingIntent != null) {
                            parcel.writeInt(1);
                            pendingIntent.writeToParcel(parcel, 0);
                        } else {
                            parcel.writeInt(0);
                        }
                        this.mRemote.transact(13, parcel, null, 1);
                    }
                    catch (Throwable throwable) {
                        break block25;
                    }
                    parcel.recycle();
                    return;
                }
                parcel.recycle();
                throw var1_10;
            }

            @Override
            public void onCurrentMediaItemChanged(Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(1, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onCustomCommand(Bundle bundle, Bundle bundle2, ResultReceiver resultReceiver) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    if (bundle2 != null) {
                        parcel.writeInt(1);
                        bundle2.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    if (resultReceiver != null) {
                        parcel.writeInt(1);
                        resultReceiver.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(17, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onCustomLayoutChanged(List<Bundle> list) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeTypedList(list);
                    this.mRemote.transact(15, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onDisconnected() throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    this.mRemote.transact(14, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onError(int n, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeInt(n);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(11, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onGetChildrenDone(String string2, int n, int n2, List<Bundle> list, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeString(string2);
                    parcel.writeInt(n);
                    parcel.writeInt(n2);
                    parcel.writeTypedList(list);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(21, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onGetItemDone(String string2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeString(string2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(19, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onGetLibraryRootDone(Bundle bundle, String string2, Bundle bundle2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    parcel.writeString(string2);
                    if (bundle2 != null) {
                        parcel.writeInt(1);
                        bundle2.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(18, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onGetSearchResultDone(String string2, int n, int n2, List<Bundle> list, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeString(string2);
                    parcel.writeInt(n);
                    parcel.writeInt(n2);
                    parcel.writeTypedList(list);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(23, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onPlaybackInfoChanged(Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(7, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onPlaybackSpeedChanged(long l, long l2, float f) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeLong(l);
                    parcel.writeLong(l2);
                    parcel.writeFloat(f);
                    this.mRemote.transact(3, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onPlayerStateChanged(long l, long l2, int n) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeLong(l);
                    parcel.writeLong(l2);
                    parcel.writeInt(n);
                    this.mRemote.transact(2, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onPlaylistChanged(List<Bundle> list, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeTypedList(list);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(5, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onPlaylistMetadataChanged(Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(6, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onRepeatModeChanged(int n) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeInt(n);
                    this.mRemote.transact(8, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onRoutesInfoChanged(List<Bundle> list) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeTypedList(list);
                    this.mRemote.transact(12, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onSearchResultChanged(String string2, int n, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeString(string2);
                    parcel.writeInt(n);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(22, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onSeekCompleted(long l, long l2, long l3) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeLong(l);
                    parcel.writeLong(l2);
                    parcel.writeLong(l3);
                    this.mRemote.transact(10, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            @Override
            public void onShuffleModeChanged(int n) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    parcel.writeInt(n);
                    this.mRemote.transact(9, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }
        }
    }
}

