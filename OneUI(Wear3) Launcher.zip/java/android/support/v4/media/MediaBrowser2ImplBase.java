/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.RemoteException
 *  android.util.Log
 */
package android.support.v4.media;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.v4.media.IMediaSession2;
import android.support.v4.media.MediaBrowser2;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaController2ImplBase;
import android.support.v4.media.SessionToken2;
import android.util.Log;
import java.util.concurrent.Executor;

class MediaBrowser2ImplBase
extends MediaController2ImplBase
implements MediaBrowser2.SupportLibraryImpl {
    MediaBrowser2ImplBase(Context context, MediaController2 mediaController2, SessionToken2 sessionToken2, Executor executor, MediaBrowser2.BrowserCallback browserCallback) {
        super(context, mediaController2, sessionToken2, executor, browserCallback);
    }

    @Override
    public MediaBrowser2.BrowserCallback getCallback() {
        return (MediaBrowser2.BrowserCallback)super.getCallback();
    }

    @Override
    public void getChildren(String string2, int n, int n2, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(29);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.getChildren(this.mControllerStub, string2, n, n2, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)"MC2ImplBase", (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void getItem(String string2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(30);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.getItem(this.mControllerStub, string2);
            }
            catch (RemoteException remoteException) {
                Log.w((String)"MC2ImplBase", (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void getLibraryRoot(Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(31);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.getLibraryRoot(this.mControllerStub, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)"MC2ImplBase", (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void getSearchResult(String string2, int n, int n2, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(32);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.getSearchResult(this.mControllerStub, string2, n, n2, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)"MC2ImplBase", (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void search(String string2, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(33);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.search(this.mControllerStub, string2, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)"MC2ImplBase", (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void subscribe(String string2, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(34);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.subscribe(this.mControllerStub, string2, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)"MC2ImplBase", (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void unsubscribe(String string2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(35);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.unsubscribe(this.mControllerStub, string2);
            }
            catch (RemoteException remoteException) {
                Log.w((String)"MC2ImplBase", (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }
}

