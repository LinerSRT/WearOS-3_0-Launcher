/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.media.MediaTimestamp
 */
package android.support.v4.media;

import android.media.MediaTimestamp;

public final class MediaTimestamp2 {
    public static final MediaTimestamp2 TIMESTAMP_UNKNOWN = new MediaTimestamp2(-1L, -1L, 0.0f);
    private final float mClockRate;
    private final long mMediaTimeUs;
    private final long mNanoTime;

    MediaTimestamp2() {
        this.mMediaTimeUs = 0L;
        this.mNanoTime = 0L;
        this.mClockRate = 1.0f;
    }

    MediaTimestamp2(long l, long l2, float f) {
        this.mMediaTimeUs = l;
        this.mNanoTime = l2;
        this.mClockRate = f;
    }

    MediaTimestamp2(MediaTimestamp mediaTimestamp) {
        this.mMediaTimeUs = mediaTimestamp.getAnchorMediaTimeUs();
        this.mNanoTime = mediaTimestamp.getAnchorSytemNanoTime();
        this.mClockRate = mediaTimestamp.getMediaClockRate();
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (MediaTimestamp2)object;
            if (this.mMediaTimeUs != ((MediaTimestamp2)object).mMediaTimeUs || this.mNanoTime != ((MediaTimestamp2)object).mNanoTime || this.mClockRate != ((MediaTimestamp2)object).mClockRate) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public long getAnchorMediaTimeUs() {
        return this.mMediaTimeUs;
    }

    public long getAnchorSytemNanoTime() {
        return this.mNanoTime;
    }

    public float getMediaClockRate() {
        return this.mClockRate;
    }

    public int hashCode() {
        return (int)((float)((int)((long)(Long.valueOf(this.mMediaTimeUs).hashCode() * 31) + this.mNanoTime) * 31) + this.mClockRate);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getClass().getName());
        stringBuilder.append("{AnchorMediaTimeUs=");
        stringBuilder.append(this.mMediaTimeUs);
        stringBuilder.append(" AnchorSystemNanoTime=");
        stringBuilder.append(this.mNanoTime);
        stringBuilder.append(" ClockRate=");
        stringBuilder.append(this.mClockRate);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

