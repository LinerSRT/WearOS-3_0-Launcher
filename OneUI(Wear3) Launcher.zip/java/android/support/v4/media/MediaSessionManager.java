/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build$VERSION
 *  android.util.Log
 */
package android.support.v4.media;

import android.content.Context;
import android.os.Build;
import android.support.v4.media.MediaSessionManagerImplApi21;
import android.support.v4.media.MediaSessionManagerImplApi28;
import android.support.v4.media.MediaSessionManagerImplBase;
import android.util.Log;

public final class MediaSessionManager {
    static final boolean DEBUG = Log.isLoggable((String)"MediaSessionManager", (int)3);
    static final String TAG = "MediaSessionManager";
    private static final Object sLock = new Object();
    private static volatile MediaSessionManager sSessionManager;
    MediaSessionManagerImpl mImpl;

    private MediaSessionManager(Context context) {
        this.mImpl = Build.VERSION.SDK_INT >= 28 ? new MediaSessionManagerImplApi28(context) : (Build.VERSION.SDK_INT >= 21 ? new MediaSessionManagerImplApi21(context) : new MediaSessionManagerImplBase(context));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static MediaSessionManager getSessionManager(Context context) {
        MediaSessionManager mediaSessionManager;
        MediaSessionManager mediaSessionManager2 = mediaSessionManager = sSessionManager;
        if (mediaSessionManager != null) return mediaSessionManager2;
        Object object = sLock;
        synchronized (object) {
            mediaSessionManager2 = mediaSessionManager = sSessionManager;
            if (mediaSessionManager != null) return mediaSessionManager2;
            mediaSessionManager2 = new MediaSessionManager(context.getApplicationContext());
            sSessionManager = mediaSessionManager2;
            return sSessionManager;
        }
    }

    Context getContext() {
        return this.mImpl.getContext();
    }

    public boolean isTrustedForMediaControl(RemoteUserInfo remoteUserInfo) {
        if (remoteUserInfo != null) {
            return this.mImpl.isTrustedForMediaControl(remoteUserInfo.mImpl);
        }
        throw new IllegalArgumentException("userInfo should not be null");
    }

    static interface MediaSessionManagerImpl {
        public Context getContext();

        public boolean isTrustedForMediaControl(RemoteUserInfoImpl var1);
    }

    public static final class RemoteUserInfo {
        public static final String LEGACY_CONTROLLER = "android.media.session.MediaController";
        RemoteUserInfoImpl mImpl;

        public RemoteUserInfo(String string2, int n, int n2) {
            this.mImpl = Build.VERSION.SDK_INT >= 28 ? new MediaSessionManagerImplApi28.RemoteUserInfo(string2, n, n2) : new MediaSessionManagerImplBase.RemoteUserInfo(string2, n, n2);
        }

        public boolean equals(Object object) {
            return this.mImpl.equals(object);
        }

        public String getPackageName() {
            return this.mImpl.getPackageName();
        }

        public int getPid() {
            return this.mImpl.getPid();
        }

        public int getUid() {
            return this.mImpl.getUid();
        }

        public int hashCode() {
            return this.mImpl.hashCode();
        }
    }

    static interface RemoteUserInfoImpl {
        public String getPackageName();

        public int getPid();

        public int getUid();
    }
}

