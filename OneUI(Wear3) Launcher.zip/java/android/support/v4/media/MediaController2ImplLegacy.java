/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Parcelable
 *  android.os.Process
 *  android.os.RemoteException
 *  android.os.ResultReceiver
 *  android.os.SystemClock
 *  android.support.mediacompat.Rating2
 *  android.util.Log
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Parcelable;
import android.os.Process;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.mediacompat.Rating2;
import android.support.v4.app.BundleCompat;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaUtils2;
import android.support.v4.media.SessionCommand2;
import android.support.v4.media.SessionCommandGroup2;
import android.support.v4.media.SessionToken2;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Log;
import java.util.List;
import java.util.concurrent.Executor;

class MediaController2ImplLegacy
implements MediaController2.SupportLibraryImpl {
    private static final boolean DEBUG;
    private static final String TAG = "MC2ImplLegacy";
    static final Bundle sDefaultRootExtras;
    private SessionCommandGroup2 mAllowedCommands;
    private MediaBrowserCompat mBrowserCompat;
    private int mBufferingState;
    private final MediaController2.ControllerCallback mCallback;
    private final Executor mCallbackExecutor;
    private volatile boolean mConnected;
    private final Context mContext;
    private MediaControllerCompat mControllerCompat;
    private ControllerCompatCallback mControllerCompatCallback;
    private MediaItem2 mCurrentMediaItem;
    private final Handler mHandler;
    private final HandlerThread mHandlerThread;
    private MediaController2 mInstance;
    private boolean mIsReleased;
    final Object mLock = new Object();
    private MediaMetadataCompat mMediaMetadataCompat;
    private MediaController2.PlaybackInfo mPlaybackInfo;
    private PlaybackStateCompat mPlaybackStateCompat;
    private int mPlayerState;
    private List<MediaItem2> mPlaylist;
    private MediaMetadata2 mPlaylistMetadata;
    private int mRepeatMode;
    private int mShuffleMode;
    private final SessionToken2 mToken;

    static {
        Bundle bundle;
        DEBUG = Log.isLoggable((String)TAG, (int)3);
        sDefaultRootExtras = bundle = new Bundle();
        bundle.putBoolean("android.support.v4.media.root_default_root", true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    MediaController2ImplLegacy(Context object, MediaController2 mediaController2, SessionToken2 sessionToken2, Executor executor, MediaController2.ControllerCallback controllerCallback) {
        this.mContext = object;
        this.mInstance = mediaController2;
        object = new HandlerThread("MediaController2_Thread");
        this.mHandlerThread = object;
        object.start();
        this.mHandler = new Handler(this.mHandlerThread.getLooper());
        this.mToken = sessionToken2;
        this.mCallback = controllerCallback;
        this.mCallbackExecutor = executor;
        if (sessionToken2.getType() == 0) {
            object = this.mLock;
            synchronized (object) {
                this.mBrowserCompat = null;
            }
            this.connectToSession((MediaSessionCompat.Token)this.mToken.getBinder());
            return;
        }
        this.connectToService();
    }

    static /* synthetic */ PlaybackStateCompat access$1302(MediaController2ImplLegacy mediaController2ImplLegacy, PlaybackStateCompat playbackStateCompat) {
        mediaController2ImplLegacy.mPlaybackStateCompat = playbackStateCompat;
        return playbackStateCompat;
    }

    static /* synthetic */ MediaMetadataCompat access$1402(MediaController2ImplLegacy mediaController2ImplLegacy, MediaMetadataCompat mediaMetadataCompat) {
        mediaController2ImplLegacy.mMediaMetadataCompat = mediaMetadataCompat;
        return mediaMetadataCompat;
    }

    static /* synthetic */ SessionCommandGroup2 access$1502(MediaController2ImplLegacy mediaController2ImplLegacy, SessionCommandGroup2 sessionCommandGroup2) {
        mediaController2ImplLegacy.mAllowedCommands = sessionCommandGroup2;
        return sessionCommandGroup2;
    }

    static /* synthetic */ int access$1602(MediaController2ImplLegacy mediaController2ImplLegacy, int n) {
        mediaController2ImplLegacy.mPlayerState = n;
        return n;
    }

    static /* synthetic */ MediaItem2 access$1702(MediaController2ImplLegacy mediaController2ImplLegacy, MediaItem2 mediaItem2) {
        mediaController2ImplLegacy.mCurrentMediaItem = mediaItem2;
        return mediaItem2;
    }

    static /* synthetic */ List access$1802(MediaController2ImplLegacy mediaController2ImplLegacy, List list) {
        mediaController2ImplLegacy.mPlaylist = list;
        return list;
    }

    static /* synthetic */ MediaMetadata2 access$1902(MediaController2ImplLegacy mediaController2ImplLegacy, MediaMetadata2 mediaMetadata2) {
        mediaController2ImplLegacy.mPlaylistMetadata = mediaMetadata2;
        return mediaMetadata2;
    }

    static /* synthetic */ int access$2002(MediaController2ImplLegacy mediaController2ImplLegacy, int n) {
        mediaController2ImplLegacy.mRepeatMode = n;
        return n;
    }

    static /* synthetic */ int access$2102(MediaController2ImplLegacy mediaController2ImplLegacy, int n) {
        mediaController2ImplLegacy.mShuffleMode = n;
        return n;
    }

    static /* synthetic */ MediaController2.PlaybackInfo access$2202(MediaController2ImplLegacy mediaController2ImplLegacy, MediaController2.PlaybackInfo playbackInfo) {
        mediaController2ImplLegacy.mPlaybackInfo = playbackInfo;
        return playbackInfo;
    }

    static /* synthetic */ int access$2302(MediaController2ImplLegacy mediaController2ImplLegacy, int n) {
        mediaController2ImplLegacy.mBufferingState = n;
        return n;
    }

    static /* synthetic */ MediaBrowserCompat access$502(MediaController2ImplLegacy mediaController2ImplLegacy, MediaBrowserCompat mediaBrowserCompat) {
        mediaController2ImplLegacy.mBrowserCompat = mediaBrowserCompat;
        return mediaBrowserCompat;
    }

    private void connectToService() {
        this.mCallbackExecutor.execute(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void run() {
                Object object = MediaController2ImplLegacy.this.mLock;
                synchronized (object) {
                    MediaController2ImplLegacy mediaController2ImplLegacy = MediaController2ImplLegacy.this;
                    Context context = MediaController2ImplLegacy.this.mContext;
                    ComponentName componentName = MediaController2ImplLegacy.this.mToken.getComponentName();
                    ConnectionCallback connectionCallback = new ConnectionCallback();
                    MediaBrowserCompat mediaBrowserCompat = new MediaBrowserCompat(context, componentName, connectionCallback, sDefaultRootExtras);
                    MediaController2ImplLegacy.access$502(mediaController2ImplLegacy, mediaBrowserCompat);
                    MediaController2ImplLegacy.this.mBrowserCompat.connect();
                    return;
                }
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void connectToSession(MediaSessionCompat.Token object) {
        Object object2;
        Object object3 = null;
        try {
            object = object2 = new MediaControllerCompat(this.mContext, (MediaSessionCompat.Token)object);
        }
        catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            object = object3;
        }
        object3 = this.mLock;
        // MONITORENTER : object3
        this.mControllerCompat = object;
        this.mControllerCompatCallback = object2 = new ControllerCompatCallback();
        this.mControllerCompat.registerCallback((MediaControllerCompat.Callback)object2, this.mHandler);
        // MONITOREXIT : object3
        if (!((MediaControllerCompat)object).isSessionReady()) return;
        this.sendCommand("android.support.v4.media.controller.command.CONNECT", new ResultReceiver(this.mHandler){

            protected void onReceiveResult(int n, Bundle bundle) {
                if (!MediaController2ImplLegacy.this.mHandlerThread.isAlive()) {
                    return;
                }
                if (n != -1) {
                    if (n == 0) {
                        MediaController2ImplLegacy.this.onConnectedNotLocked(bundle);
                    }
                } else {
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable(){

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onDisconnected(MediaController2ImplLegacy.this.mInstance);
                        }
                    });
                    MediaController2ImplLegacy.this.close();
                }
            }
        });
    }

    private void sendCommand(int n) {
        this.sendCommand(n, null);
    }

    private void sendCommand(int n, Bundle bundle) {
        Bundle bundle2 = bundle;
        if (bundle == null) {
            bundle2 = new Bundle();
        }
        bundle2.putInt("android.support.v4.media.argument.COMMAND_CODE", n);
        this.sendCommand("android.support.v4.media.controller.command.BY_COMMAND_CODE", bundle2, null);
    }

    private void sendCommand(String string2) {
        this.sendCommand(string2, null, null);
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void sendCommand(String string2, Bundle object, ResultReceiver resultReceiver) {
        void var3_6;
        ControllerCompatCallback controllerCompatCallback;
        Object object2;
        Bundle bundle = object2;
        if (object2 == null) {
            bundle = new Bundle();
        }
        object2 = this.mLock;
        // MONITORENTER : object2
        MediaControllerCompat mediaControllerCompat = this.mControllerCompat;
        try {
            controllerCompatCallback = this.mControllerCompatCallback;
            // MONITOREXIT : object2
        }
        catch (Throwable throwable) {
            throw throwable;
        }
        BundleCompat.putBinder(bundle, "android.support.v4.media.argument.ICONTROLLER_CALLBACK", controllerCompatCallback.getIControllerCallback().asBinder());
        bundle.putString("android.support.v4.media.argument.PACKAGE_NAME", this.mContext.getPackageName());
        bundle.putInt("android.support.v4.media.argument.UID", Process.myUid());
        bundle.putInt("android.support.v4.media.argument.PID", Process.myPid());
        mediaControllerCompat.sendCommand(string2, bundle, (ResultReceiver)var3_6);
    }

    private void sendCommand(String string2, ResultReceiver resultReceiver) {
        this.sendCommand(string2, null, resultReceiver);
    }

    @Override
    public void addPlaylistItem(int n, MediaItem2 mediaItem2) {
        Bundle bundle = new Bundle();
        bundle.putInt("android.support.v4.media.argument.PLAYLIST_INDEX", n);
        bundle.putBundle("android.support.v4.media.argument.MEDIA_ITEM", mediaItem2.toBundle());
        this.sendCommand(15, bundle);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void adjustVolume(int n, int n2) {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            Bundle bundle = new Bundle();
            bundle.putInt("android.support.v4.media.argument.VOLUME_DIRECTION", n);
            bundle.putInt("android.support.v4.media.argument.VOLUME_FLAGS", n2);
            this.sendCommand(11, bundle);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void close() {
        if (DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("release from ");
            stringBuilder.append(this.mToken);
            Log.d((String)TAG, (String)stringBuilder.toString());
        }
        Object object = this.mLock;
        synchronized (object) {
            if (this.mIsReleased) {
                return;
            }
            this.mHandler.removeCallbacksAndMessages(null);
            if (Build.VERSION.SDK_INT >= 18) {
                this.mHandlerThread.quitSafely();
            } else {
                this.mHandlerThread.quit();
            }
            this.mIsReleased = true;
            this.sendCommand("android.support.v4.media.controller.command.DISCONNECT");
            if (this.mControllerCompat != null) {
                this.mControllerCompat.unregisterCallback(this.mControllerCompatCallback);
            }
            if (this.mBrowserCompat != null) {
                this.mBrowserCompat.disconnect();
                this.mBrowserCompat = null;
            }
            if (this.mControllerCompat != null) {
                this.mControllerCompat.unregisterCallback(this.mControllerCompatCallback);
                this.mControllerCompat = null;
            }
            this.mConnected = false;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                MediaController2ImplLegacy.this.mCallback.onDisconnected(MediaController2ImplLegacy.this.mInstance);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void fastForward() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            this.sendCommand(7);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaBrowserCompat getBrowserCompat() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mBrowserCompat;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public long getBufferedPosition() {
        Object object = this.mLock;
        synchronized (object) {
            boolean bl = this.mConnected;
            long l = -1L;
            if (!bl) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return -1L;
            }
            if (this.mPlaybackStateCompat != null) return this.mPlaybackStateCompat.getBufferedPosition();
            return l;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getBufferingState() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mConnected) return this.mBufferingState;
            IllegalStateException illegalStateException = new IllegalStateException();
            Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
            return 0;
        }
    }

    @Override
    public MediaController2.ControllerCallback getCallback() {
        return this.mCallback;
    }

    @Override
    public Executor getCallbackExecutor() {
        return this.mCallbackExecutor;
    }

    @Override
    public Context getContext() {
        return this.mContext;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaItem2 getCurrentMediaItem() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mCurrentMediaItem;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public long getCurrentPosition() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return -1L;
            }
            if (this.mPlaybackStateCompat == null) {
                return -1L;
            }
            long l = this.mInstance.mTimeDiff != null ? this.mInstance.mTimeDiff : SystemClock.elapsedRealtime() - this.mPlaybackStateCompat.getLastPositionUpdateTime();
            return Math.max(0L, this.mPlaybackStateCompat.getPosition() + (long)(this.mPlaybackStateCompat.getPlaybackSpeed() * (float)l));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public long getDuration() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mMediaMetadataCompat == null) return -1L;
            if (!this.mMediaMetadataCompat.containsKey("android.media.metadata.DURATION")) return -1L;
            return this.mMediaMetadataCompat.getLong("android.media.metadata.DURATION");
        }
    }

    @Override
    public MediaController2 getInstance() {
        return this.mInstance;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaController2.PlaybackInfo getPlaybackInfo() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlaybackInfo;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public float getPlaybackSpeed() {
        Object object = this.mLock;
        synchronized (object) {
            boolean bl = this.mConnected;
            float f = 0.0f;
            if (!bl) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return 0.0f;
            }
            if (this.mPlaybackStateCompat != null) return this.mPlaybackStateCompat.getPlaybackSpeed();
            return f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getPlayerState() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlayerState;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public List<MediaItem2> getPlaylist() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlaylist;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaMetadata2 getPlaylistMetadata() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlaylistMetadata;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getRepeatMode() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mRepeatMode;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public PendingIntent getSessionActivity() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mConnected) return this.mControllerCompat.getSessionActivity();
            IllegalStateException illegalStateException = new IllegalStateException();
            Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
            return null;
        }
    }

    @Override
    public SessionToken2 getSessionToken() {
        return this.mToken;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getShuffleMode() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mShuffleMode;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean isConnected() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mConnected;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void onConnectedNotLocked(Bundle object) {
        object.setClassLoader(MediaSession2.class.getClassLoader());
        final SessionCommandGroup2 sessionCommandGroup2 = SessionCommandGroup2.fromBundle(object.getBundle("android.support.v4.media.argument.ALLOWED_COMMANDS"));
        int n = object.getInt("android.support.v4.media.argument.PLAYER_STATE");
        Object object2 = MediaItem2.fromBundle(object.getBundle("android.support.v4.media.argument.MEDIA_ITEM"));
        int n2 = object.getInt("android.support.v4.media.argument.BUFFERING_STATE");
        PlaybackStateCompat playbackStateCompat = (PlaybackStateCompat)object.getParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT");
        int n3 = object.getInt("android.support.v4.media.argument.REPEAT_MODE");
        int n4 = object.getInt("android.support.v4.media.argument.SHUFFLE_MODE");
        List<MediaItem2> list = MediaUtils2.convertToMediaItem2List(object.getParcelableArray("android.support.v4.media.argument.PLAYLIST"));
        MediaController2.PlaybackInfo playbackInfo = MediaController2.PlaybackInfo.fromBundle(object.getBundle("android.support.v4.media.argument.PLAYBACK_INFO"));
        MediaMetadata2 mediaMetadata2 = MediaMetadata2.fromBundle(object.getBundle("android.support.v4.media.argument.PLAYLIST_METADATA"));
        if (DEBUG) {
            object = new StringBuilder();
            ((StringBuilder)object).append("onConnectedNotLocked token=");
            ((StringBuilder)object).append(this.mToken);
            ((StringBuilder)object).append(", allowedCommands=");
            ((StringBuilder)object).append(sessionCommandGroup2);
            Log.d((String)TAG, (String)((StringBuilder)object).toString());
        }
        boolean bl = false;
        boolean bl2 = false;
        boolean bl3 = bl;
        try {
            object = this.mLock;
            bl3 = bl;
            synchronized (object) {
                bl3 = bl2;
                if (!this.mIsReleased) break block12;
                bl3 = bl2;
            }
        }
        catch (Throwable throwable) {
            if (bl3) {
                this.close();
            }
            throw throwable;
        }
        {
            block12: {
                return;
            }
            bl3 = bl2;
            if (this.mConnected) {
                bl3 = bl2;
                Log.e((String)TAG, (String)"Cannot be notified about the connection result many times. Probably a bug or malicious app.");
                bl3 = true;
                // MONITOREXIT @DISABLED, blocks:[7, 9] lbl47 : MonitorExitStatement: MONITOREXIT : var1_1
                this.close();
                return;
            }
            bl3 = bl2;
            this.mAllowedCommands = sessionCommandGroup2;
            bl3 = bl2;
            this.mPlayerState = n;
            bl3 = bl2;
            this.mCurrentMediaItem = object2;
            bl3 = bl2;
            this.mBufferingState = n2;
            bl3 = bl2;
            this.mPlaybackStateCompat = playbackStateCompat;
            bl3 = bl2;
            this.mRepeatMode = n3;
            bl3 = bl2;
            this.mShuffleMode = n4;
            bl3 = bl2;
            this.mPlaylist = list;
            bl3 = bl2;
            this.mPlaylistMetadata = mediaMetadata2;
            bl3 = bl2;
            this.mConnected = true;
            bl3 = bl2;
            this.mPlaybackInfo = playbackInfo;
            bl3 = bl2;
        }
        bl3 = bl;
        {
            object2 = this.mCallbackExecutor;
            bl3 = bl;
            bl3 = bl;
            object = new Runnable(){

                @Override
                public void run() {
                    MediaController2ImplLegacy.this.mCallback.onConnected(MediaController2ImplLegacy.this.mInstance, sessionCommandGroup2);
                }
            };
            bl3 = bl;
            object2.execute((Runnable)object);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void pause() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            this.sendCommand(2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void play() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            this.sendCommand(1);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void playFromMediaId(String object, Bundle bundle) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mConnected) {
                object = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)object);
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("android.support.v4.media.argument.MEDIA_ID", (String)object);
            bundle2.putBundle("android.support.v4.media.argument.EXTRAS", bundle);
            this.sendCommand(22, bundle2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void playFromSearch(String object, Bundle bundle) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mConnected) {
                object = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)object);
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("android.support.v4.media.argument.QUERY", (String)object);
            bundle2.putBundle("android.support.v4.media.argument.EXTRAS", bundle);
            this.sendCommand(24, bundle2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void playFromUri(Uri object, Bundle bundle) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mConnected) {
                object = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)object);
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putParcelable("android.support.v4.media.argument.URI", (Parcelable)object);
            bundle2.putBundle("android.support.v4.media.argument.EXTRAS", bundle);
            this.sendCommand(23, bundle2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void prepare() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            this.sendCommand(6);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void prepareFromMediaId(String object, Bundle bundle) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mConnected) {
                object = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)object);
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("android.support.v4.media.argument.MEDIA_ID", (String)object);
            bundle2.putBundle("android.support.v4.media.argument.EXTRAS", bundle);
            this.sendCommand(25, bundle2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void prepareFromSearch(String object, Bundle bundle) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mConnected) {
                object = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)object);
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("android.support.v4.media.argument.QUERY", (String)object);
            bundle2.putBundle("android.support.v4.media.argument.EXTRAS", bundle);
            this.sendCommand(27, bundle2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void prepareFromUri(Uri object, Bundle bundle) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mConnected) {
                object = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)object);
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putParcelable("android.support.v4.media.argument.URI", (Parcelable)object);
            bundle2.putBundle("android.support.v4.media.argument.EXTRAS", bundle);
            this.sendCommand(26, bundle2);
            return;
        }
    }

    @Override
    public void removePlaylistItem(MediaItem2 mediaItem2) {
        Bundle bundle = new Bundle();
        bundle.putBundle("android.support.v4.media.argument.MEDIA_ITEM", mediaItem2.toBundle());
        this.sendCommand(16, bundle);
    }

    @Override
    public void replacePlaylistItem(int n, MediaItem2 mediaItem2) {
        Bundle bundle = new Bundle();
        bundle.putInt("android.support.v4.media.argument.PLAYLIST_INDEX", n);
        bundle.putBundle("android.support.v4.media.argument.MEDIA_ITEM", mediaItem2.toBundle());
        this.sendCommand(17, bundle);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void reset() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            this.sendCommand(3);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void rewind() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            this.sendCommand(8);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void seekTo(long l) {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            Bundle bundle = new Bundle();
            bundle.putLong("android.support.v4.media.argument.SEEK_POSITION", l);
            this.sendCommand(9, bundle);
            return;
        }
    }

    @Override
    public void selectRoute(Bundle bundle) {
        Bundle bundle2 = new Bundle();
        bundle2.putBundle("android.support.v4.media.argument.ROUTE_BUNDLE", bundle);
        this.sendCommand(38, bundle2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void sendCustomCommand(SessionCommand2 object, Bundle bundle, ResultReceiver resultReceiver) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mConnected) {
                object = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)object);
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putBundle("android.support.v4.media.argument.CUSTOM_COMMAND", ((SessionCommand2)object).toBundle());
            bundle2.putBundle("android.support.v4.media.argument.ARGUMENTS", bundle);
            this.sendCommand("android.support.v4.media.controller.command.BY_CUSTOM_COMMAND", bundle2, resultReceiver);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setPlaybackSpeed(float f) {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            Bundle bundle = new Bundle();
            bundle.putFloat("android.support.v4.media.argument.PLAYBACK_SPEED", f);
            this.sendCommand(39, bundle);
            return;
        }
    }

    @Override
    public void setPlaylist(List<MediaItem2> object, MediaMetadata2 mediaMetadata2) {
        Bundle bundle = new Bundle();
        bundle.putParcelableArray("android.support.v4.media.argument.PLAYLIST", MediaUtils2.convertMediaItem2ListToParcelableArray(object));
        object = mediaMetadata2 == null ? null : mediaMetadata2.toBundle();
        bundle.putBundle("android.support.v4.media.argument.PLAYLIST_METADATA", object);
        this.sendCommand(19, bundle);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setRating(String object, Rating2 rating2) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mConnected) {
                object = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)object);
                return;
            }
            Bundle bundle = new Bundle();
            bundle.putString("android.support.v4.media.argument.MEDIA_ID", (String)object);
            bundle.putBundle("android.support.v4.media.argument.RATING", rating2.toBundle());
            this.sendCommand(28, bundle);
            return;
        }
    }

    @Override
    public void setRepeatMode(int n) {
        Bundle bundle = new Bundle();
        bundle.putInt("android.support.v4.media.argument.REPEAT_MODE", n);
        this.sendCommand(14, bundle);
    }

    @Override
    public void setShuffleMode(int n) {
        Bundle bundle = new Bundle();
        bundle.putInt("android.support.v4.media.argument.SHUFFLE_MODE", n);
        this.sendCommand(13, bundle);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setVolumeTo(int n, int n2) {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mConnected) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return;
            }
            Bundle bundle = new Bundle();
            bundle.putInt("android.support.v4.media.argument.VOLUME", n);
            bundle.putInt("android.support.v4.media.argument.VOLUME_FLAGS", n2);
            this.sendCommand(10, bundle);
            return;
        }
    }

    @Override
    public void skipBackward() {
    }

    @Override
    public void skipForward() {
    }

    @Override
    public void skipToNextItem() {
        this.sendCommand(4);
    }

    @Override
    public void skipToPlaylistItem(MediaItem2 mediaItem2) {
        Bundle bundle = new Bundle();
        bundle.putBundle("android.support.v4.media.argument.MEDIA_ITEM", mediaItem2.toBundle());
        this.sendCommand(12, bundle);
    }

    @Override
    public void skipToPreviousItem() {
        this.sendCommand(5);
    }

    @Override
    public void subscribeRoutesInfo() {
        this.sendCommand(36);
    }

    @Override
    public void unsubscribeRoutesInfo() {
        this.sendCommand(37);
    }

    @Override
    public void updatePlaylistMetadata(MediaMetadata2 mediaMetadata2) {
        Bundle bundle = new Bundle();
        mediaMetadata2 = mediaMetadata2 == null ? null : mediaMetadata2.toBundle();
        bundle.putBundle("android.support.v4.media.argument.PLAYLIST_METADATA", (Bundle)mediaMetadata2);
        this.sendCommand(21, bundle);
    }

    private class ConnectionCallback
    extends MediaBrowserCompat.ConnectionCallback {
        private ConnectionCallback() {
        }

        @Override
        public void onConnected() {
            MediaBrowserCompat mediaBrowserCompat = MediaController2ImplLegacy.this.getBrowserCompat();
            if (mediaBrowserCompat != null) {
                MediaController2ImplLegacy.this.connectToSession(mediaBrowserCompat.getSessionToken());
            } else if (DEBUG) {
                Log.d((String)MediaController2ImplLegacy.TAG, (String)"Controller is closed prematually", (Throwable)new IllegalStateException());
            }
        }

        @Override
        public void onConnectionFailed() {
            MediaController2ImplLegacy.this.close();
        }

        @Override
        public void onConnectionSuspended() {
            MediaController2ImplLegacy.this.close();
        }
    }

    private final class ControllerCompatCallback
    extends MediaControllerCompat.Callback {
        private ControllerCompatCallback() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void onMetadataChanged(MediaMetadataCompat mediaMetadataCompat) {
            Object object = MediaController2ImplLegacy.this.mLock;
            synchronized (object) {
                MediaController2ImplLegacy.access$1402(MediaController2ImplLegacy.this, mediaMetadataCompat);
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void onPlaybackStateChanged(PlaybackStateCompat playbackStateCompat) {
            Object object = MediaController2ImplLegacy.this.mLock;
            synchronized (object) {
                MediaController2ImplLegacy.access$1302(MediaController2ImplLegacy.this, playbackStateCompat);
                return;
            }
        }

        @Override
        public void onSessionDestroyed() {
            MediaController2ImplLegacy.this.close();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void onSessionEvent(String object, Bundle object2) {
            if (object2 != null) {
                object2.setClassLoader(MediaSession2.class.getClassLoader());
            }
            final int n = -1;
            switch (((String)object).hashCode()) {
                case 1871849865: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_SEEK_COMPLETED")) break;
                    n = 14;
                    break;
                }
                case 1696119769: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_ALLOWED_COMMANDS_CHANGED")) break;
                    n = 0;
                    break;
                }
                case 896576579: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_SHUFFLE_MODE_CHANGED")) break;
                    n = 8;
                    break;
                }
                case 806201420: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_PLAYLIST_CHANGED")) break;
                    n = 5;
                    break;
                }
                case 408969344: {
                    if (!((String)object).equals("android.support.v4.media.session.event.SET_CUSTOM_LAYOUT")) break;
                    n = 10;
                    break;
                }
                case 306321100: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_PLAYLIST_METADATA_CHANGED")) break;
                    n = 6;
                    break;
                }
                case 229988025: {
                    if (!((String)object).equals("android.support.v4.media.session.event.SEND_CUSTOM_COMMAND")) break;
                    n = 9;
                    break;
                }
                case -53555497: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_REPEAT_MODE_CHANGED")) break;
                    n = 7;
                    break;
                }
                case -92092013: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_ROUTES_INFO_CHANGED")) break;
                    n = 4;
                    break;
                }
                case -617184370: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_CURRENT_MEDIA_ITEM_CHANGED")) break;
                    n = 2;
                    break;
                }
                case -1021916189: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_ERROR")) break;
                    n = 3;
                    break;
                }
                case -1471144819: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_PLAYER_STATE_CHANGED")) break;
                    n = 1;
                    break;
                }
                case -1588811870: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_PLAYBACK_INFO_CHANGED")) break;
                    n = 11;
                    break;
                }
                case -2060536131: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_PLAYBACK_SPEED_CHANGED")) break;
                    n = 12;
                    break;
                }
                case -2076894204: {
                    if (!((String)object).equals("android.support.v4.media.session.event.ON_BUFFERING_STATE_CHANGED")) break;
                    n = 13;
                }
            }
            switch (n) {
                default: {
                    return;
                }
                case 14: {
                    final long l = object2.getLong("android.support.v4.media.argument.SEEK_POSITION");
                    object2 = (PlaybackStateCompat)object2.getParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT");
                    if (object2 == null) {
                        return;
                    }
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$1302(MediaController2ImplLegacy.this, (PlaybackStateCompat)object2);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable(){

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onSeekCompleted(MediaController2ImplLegacy.this.mInstance, l);
                        }
                    });
                    return;
                }
                case 13: {
                    final MediaItem2 mediaItem2 = MediaItem2.fromBundle(object2.getBundle("android.support.v4.media.argument.MEDIA_ITEM"));
                    n = object2.getInt("android.support.v4.media.argument.BUFFERING_STATE");
                    object2 = (PlaybackStateCompat)object2.getParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT");
                    if (mediaItem2 == null) return;
                    if (object2 == null) {
                        return;
                    }
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$2302(MediaController2ImplLegacy.this, n);
                        MediaController2ImplLegacy.access$1302(MediaController2ImplLegacy.this, (PlaybackStateCompat)object2);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable(){

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onBufferingStateChanged(MediaController2ImplLegacy.this.mInstance, mediaItem2, n);
                        }
                    });
                    return;
                }
                case 12: {
                    object2 = (PlaybackStateCompat)object2.getParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT");
                    if (object2 == null) {
                        return;
                    }
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$1302(MediaController2ImplLegacy.this, (PlaybackStateCompat)object2);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((PlaybackStateCompat)object2){
                        final /* synthetic */ PlaybackStateCompat val$state;
                        {
                            this.val$state = playbackStateCompat;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onPlaybackSpeedChanged(MediaController2ImplLegacy.this.mInstance, this.val$state.getPlaybackSpeed());
                        }
                    });
                    return;
                }
                case 11: {
                    object2 = MediaController2.PlaybackInfo.fromBundle(object2.getBundle("android.support.v4.media.argument.PLAYBACK_INFO"));
                    if (object2 == null) {
                        return;
                    }
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$2202(MediaController2ImplLegacy.this, (MediaController2.PlaybackInfo)object2);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((MediaController2.PlaybackInfo)object2){
                        final /* synthetic */ MediaController2.PlaybackInfo val$info;
                        {
                            this.val$info = playbackInfo;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onPlaybackInfoChanged(MediaController2ImplLegacy.this.mInstance, this.val$info);
                        }
                    });
                    return;
                }
                case 10: {
                    object = MediaUtils2.convertToCommandButtonList(object2.getParcelableArray("android.support.v4.media.argument.COMMAND_BUTTONS"));
                    if (object == null) {
                        return;
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((List)object){
                        final /* synthetic */ List val$layout;
                        {
                            this.val$layout = list;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onCustomLayoutChanged(MediaController2ImplLegacy.this.mInstance, this.val$layout);
                        }
                    });
                    return;
                }
                case 9: {
                    object = object2.getBundle("android.support.v4.media.argument.CUSTOM_COMMAND");
                    if (object == null) {
                        return;
                    }
                    object = SessionCommand2.fromBundle(object);
                    Bundle bundle = object2.getBundle("android.support.v4.media.argument.ARGUMENTS");
                    object2 = (ResultReceiver)object2.getParcelable("android.support.v4.media.argument.RESULT_RECEIVER");
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((SessionCommand2)object, bundle, (ResultReceiver)object2){
                        final /* synthetic */ Bundle val$args;
                        final /* synthetic */ SessionCommand2 val$command;
                        final /* synthetic */ ResultReceiver val$receiver;
                        {
                            this.val$command = sessionCommand2;
                            this.val$args = bundle;
                            this.val$receiver = resultReceiver;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onCustomCommand(MediaController2ImplLegacy.this.mInstance, this.val$command, this.val$args, this.val$receiver);
                        }
                    });
                    return;
                }
                case 8: {
                    n = object2.getInt("android.support.v4.media.argument.SHUFFLE_MODE");
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$2102(MediaController2ImplLegacy.this, n);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable(){

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onShuffleModeChanged(MediaController2ImplLegacy.this.mInstance, n);
                        }
                    });
                    return;
                }
                case 7: {
                    n = object2.getInt("android.support.v4.media.argument.REPEAT_MODE");
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$2002(MediaController2ImplLegacy.this, n);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable(){

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onRepeatModeChanged(MediaController2ImplLegacy.this.mInstance, n);
                        }
                    });
                    return;
                }
                case 6: {
                    object2 = MediaMetadata2.fromBundle(object2.getBundle("android.support.v4.media.argument.PLAYLIST_METADATA"));
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$1902(MediaController2ImplLegacy.this, (MediaMetadata2)object2);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((MediaMetadata2)object2){
                        final /* synthetic */ MediaMetadata2 val$playlistMetadata;
                        {
                            this.val$playlistMetadata = mediaMetadata2;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onPlaylistMetadataChanged(MediaController2ImplLegacy.this.mInstance, this.val$playlistMetadata);
                        }
                    });
                    return;
                }
                case 5: {
                    MediaMetadata2 mediaMetadata2 = MediaMetadata2.fromBundle(object2.getBundle("android.support.v4.media.argument.PLAYLIST_METADATA"));
                    object2 = MediaUtils2.convertToMediaItem2List(object2.getParcelableArray("android.support.v4.media.argument.PLAYLIST"));
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$1802(MediaController2ImplLegacy.this, (List)object2);
                        MediaController2ImplLegacy.access$1902(MediaController2ImplLegacy.this, mediaMetadata2);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((List)object2, mediaMetadata2){
                        final /* synthetic */ List val$playlist;
                        final /* synthetic */ MediaMetadata2 val$playlistMetadata;
                        {
                            this.val$playlist = list;
                            this.val$playlistMetadata = mediaMetadata2;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onPlaylistChanged(MediaController2ImplLegacy.this.mInstance, this.val$playlist, this.val$playlistMetadata);
                        }
                    });
                    return;
                }
                case 4: {
                    object = MediaUtils2.convertToBundleList(object2.getParcelableArray("android.support.v4.media.argument.ROUTE_BUNDLE"));
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((List)object){
                        final /* synthetic */ List val$routes;
                        {
                            this.val$routes = list;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onRoutesInfoChanged(MediaController2ImplLegacy.this.mInstance, this.val$routes);
                        }
                    });
                    return;
                }
                case 3: {
                    n = object2.getInt("android.support.v4.media.argument.ERROR_CODE");
                    object = object2.getBundle("android.support.v4.media.argument.EXTRAS");
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((Bundle)object){
                        final /* synthetic */ Bundle val$errorExtras;
                        {
                            this.val$errorExtras = bundle;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onError(MediaController2ImplLegacy.this.mInstance, n, this.val$errorExtras);
                        }
                    });
                    return;
                }
                case 2: {
                    object2 = MediaItem2.fromBundle(object2.getBundle("android.support.v4.media.argument.MEDIA_ITEM"));
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$1702(MediaController2ImplLegacy.this, (MediaItem2)object2);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((MediaItem2)object2){
                        final /* synthetic */ MediaItem2 val$item;
                        {
                            this.val$item = mediaItem2;
                        }

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onCurrentMediaItemChanged(MediaController2ImplLegacy.this.mInstance, this.val$item);
                        }
                    });
                    return;
                }
                case 1: {
                    n = object2.getInt("android.support.v4.media.argument.PLAYER_STATE");
                    object2 = (PlaybackStateCompat)object2.getParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT");
                    if (object2 == null) {
                        return;
                    }
                    object = MediaController2ImplLegacy.this.mLock;
                    synchronized (object) {
                        MediaController2ImplLegacy.access$1602(MediaController2ImplLegacy.this, n);
                        MediaController2ImplLegacy.access$1302(MediaController2ImplLegacy.this, (PlaybackStateCompat)object2);
                    }
                    MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable(){

                        @Override
                        public void run() {
                            MediaController2ImplLegacy.this.mCallback.onPlayerStateChanged(MediaController2ImplLegacy.this.mInstance, n);
                        }
                    });
                    return;
                }
                case 0: 
            }
            object2 = SessionCommandGroup2.fromBundle(object2.getBundle("android.support.v4.media.argument.ALLOWED_COMMANDS"));
            object = MediaController2ImplLegacy.this.mLock;
            synchronized (object) {
                MediaController2ImplLegacy.access$1502(MediaController2ImplLegacy.this, (SessionCommandGroup2)object2);
            }
            MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable((SessionCommandGroup2)object2){
                final /* synthetic */ SessionCommandGroup2 val$allowedCommands;
                {
                    this.val$allowedCommands = sessionCommandGroup2;
                }

                @Override
                public void run() {
                    MediaController2ImplLegacy.this.mCallback.onAllowedCommandsChanged(MediaController2ImplLegacy.this.mInstance, this.val$allowedCommands);
                }
            });
        }

        @Override
        public void onSessionReady() {
            MediaController2ImplLegacy.this.sendCommand("android.support.v4.media.controller.command.CONNECT", new ResultReceiver(MediaController2ImplLegacy.this.mHandler){

                protected void onReceiveResult(int n, Bundle bundle) {
                    if (!MediaController2ImplLegacy.this.mHandlerThread.isAlive()) {
                        return;
                    }
                    if (n != -1) {
                        if (n == 0) {
                            MediaController2ImplLegacy.this.onConnectedNotLocked(bundle);
                        }
                    } else {
                        MediaController2ImplLegacy.this.mCallbackExecutor.execute(new Runnable(){

                            @Override
                            public void run() {
                                MediaController2ImplLegacy.this.mCallback.onDisconnected(MediaController2ImplLegacy.this.mInstance);
                            }
                        });
                        MediaController2ImplLegacy.this.close();
                    }
                }
            });
        }
    }
}

