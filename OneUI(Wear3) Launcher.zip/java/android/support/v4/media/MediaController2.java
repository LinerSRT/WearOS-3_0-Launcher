/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.ResultReceiver
 *  android.support.mediacompat.Rating2
 *  android.text.TextUtils
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.support.mediacompat.Rating2;
import android.support.v4.media.AudioAttributesCompat;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaController2ImplBase;
import android.support.v4.media.MediaController2ImplLegacy;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.SessionCommand2;
import android.support.v4.media.SessionCommandGroup2;
import android.support.v4.media.SessionToken2;
import android.text.TextUtils;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import java.util.concurrent.Executor;

public class MediaController2
implements AutoCloseable {
    private final SupportLibraryImpl mImpl;
    Long mTimeDiff;

    public MediaController2(Context context, SessionToken2 sessionToken2, Executor executor, ControllerCallback controllerCallback) {
        if (context != null) {
            if (sessionToken2 != null) {
                if (controllerCallback != null) {
                    if (executor != null) {
                        this.mImpl = this.createImpl(context, sessionToken2, executor, controllerCallback);
                        return;
                    }
                    throw new IllegalArgumentException("executor shouldn't be null");
                }
                throw new IllegalArgumentException("callback shouldn't be null");
            }
            throw new IllegalArgumentException("token shouldn't be null");
        }
        throw new IllegalArgumentException("context shouldn't be null");
    }

    public void addPlaylistItem(int n, MediaItem2 mediaItem2) {
        if (n >= 0) {
            if (mediaItem2 != null) {
                this.mImpl.addPlaylistItem(n, mediaItem2);
                return;
            }
            throw new IllegalArgumentException("item shouldn't be null");
        }
        throw new IllegalArgumentException("index shouldn't be negative");
    }

    public void adjustVolume(int n, int n2) {
        this.mImpl.adjustVolume(n, n2);
    }

    @Override
    public void close() {
        try {
            this.mImpl.close();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    SupportLibraryImpl createImpl(Context context, SessionToken2 sessionToken2, Executor executor, ControllerCallback controllerCallback) {
        if (sessionToken2.isLegacySession()) {
            return new MediaController2ImplLegacy(context, this, sessionToken2, executor, controllerCallback);
        }
        return new MediaController2ImplBase(context, this, sessionToken2, executor, controllerCallback);
    }

    public void fastForward() {
        this.mImpl.fastForward();
    }

    MediaBrowserCompat getBrowserCompat() {
        return this.mImpl.getBrowserCompat();
    }

    public long getBufferedPosition() {
        return this.mImpl.getBufferedPosition();
    }

    public int getBufferingState() {
        return this.mImpl.getBufferingState();
    }

    ControllerCallback getCallback() {
        return this.mImpl.getCallback();
    }

    Executor getCallbackExecutor() {
        return this.mImpl.getCallbackExecutor();
    }

    Context getContext() {
        return this.mImpl.getContext();
    }

    public MediaItem2 getCurrentMediaItem() {
        return this.mImpl.getCurrentMediaItem();
    }

    public long getCurrentPosition() {
        return this.mImpl.getCurrentPosition();
    }

    public long getDuration() {
        return this.mImpl.getDuration();
    }

    SupportLibraryImpl getImpl() {
        return this.mImpl;
    }

    public PlaybackInfo getPlaybackInfo() {
        return this.mImpl.getPlaybackInfo();
    }

    public float getPlaybackSpeed() {
        return this.mImpl.getPlaybackSpeed();
    }

    public int getPlayerState() {
        return this.mImpl.getPlayerState();
    }

    public List<MediaItem2> getPlaylist() {
        return this.mImpl.getPlaylist();
    }

    public MediaMetadata2 getPlaylistMetadata() {
        return this.mImpl.getPlaylistMetadata();
    }

    public int getRepeatMode() {
        return this.mImpl.getRepeatMode();
    }

    public PendingIntent getSessionActivity() {
        return this.mImpl.getSessionActivity();
    }

    public SessionToken2 getSessionToken() {
        return this.mImpl.getSessionToken();
    }

    public int getShuffleMode() {
        return this.mImpl.getShuffleMode();
    }

    public boolean isConnected() {
        return this.mImpl.isConnected();
    }

    public void pause() {
        this.mImpl.pause();
    }

    public void play() {
        this.mImpl.play();
    }

    public void playFromMediaId(String string2, Bundle bundle) {
        if (string2 != null) {
            this.mImpl.playFromMediaId(string2, bundle);
            return;
        }
        throw new IllegalArgumentException("mediaId shouldn't be null");
    }

    public void playFromSearch(String string2, Bundle bundle) {
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            this.mImpl.playFromSearch(string2, bundle);
            return;
        }
        throw new IllegalArgumentException("query shouldn't be empty");
    }

    public void playFromUri(Uri uri, Bundle bundle) {
        if (uri != null) {
            this.mImpl.playFromUri(uri, bundle);
            return;
        }
        throw new IllegalArgumentException("uri shouldn't be null");
    }

    public void prepare() {
        this.mImpl.prepare();
    }

    public void prepareFromMediaId(String string2, Bundle bundle) {
        if (string2 != null) {
            this.mImpl.prepareFromMediaId(string2, bundle);
            return;
        }
        throw new IllegalArgumentException("mediaId shouldn't be null");
    }

    public void prepareFromSearch(String string2, Bundle bundle) {
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            this.mImpl.prepareFromSearch(string2, bundle);
            return;
        }
        throw new IllegalArgumentException("query shouldn't be empty");
    }

    public void prepareFromUri(Uri uri, Bundle bundle) {
        if (uri != null) {
            this.mImpl.prepareFromUri(uri, bundle);
            return;
        }
        throw new IllegalArgumentException("uri shouldn't be null");
    }

    public void removePlaylistItem(MediaItem2 mediaItem2) {
        if (mediaItem2 != null) {
            this.mImpl.removePlaylistItem(mediaItem2);
            return;
        }
        throw new IllegalArgumentException("item shouldn't be null");
    }

    public void replacePlaylistItem(int n, MediaItem2 mediaItem2) {
        if (n >= 0) {
            if (mediaItem2 != null) {
                this.mImpl.replacePlaylistItem(n, mediaItem2);
                return;
            }
            throw new IllegalArgumentException("item shouldn't be null");
        }
        throw new IllegalArgumentException("index shouldn't be negative");
    }

    public void reset() {
        this.mImpl.reset();
    }

    public void rewind() {
        this.mImpl.rewind();
    }

    public void seekTo(long l) {
        this.mImpl.seekTo(l);
    }

    public void selectRoute(Bundle bundle) {
        if (bundle != null) {
            this.mImpl.selectRoute(bundle);
            return;
        }
        throw new IllegalArgumentException("route shouldn't be null");
    }

    public void sendCustomCommand(SessionCommand2 sessionCommand2, Bundle bundle, ResultReceiver resultReceiver) {
        if (sessionCommand2 != null) {
            this.mImpl.sendCustomCommand(sessionCommand2, bundle, resultReceiver);
            return;
        }
        throw new IllegalArgumentException("command shouldn't be null");
    }

    public void setPlaybackSpeed(float f) {
        this.mImpl.setPlaybackSpeed(f);
    }

    public void setPlaylist(List<MediaItem2> list, MediaMetadata2 mediaMetadata2) {
        if (list != null) {
            this.mImpl.setPlaylist(list, mediaMetadata2);
            return;
        }
        throw new IllegalArgumentException("list shouldn't be null");
    }

    public void setRating(String string2, Rating2 rating2) {
        if (string2 != null) {
            if (rating2 != null) {
                this.mImpl.setRating(string2, rating2);
                return;
            }
            throw new IllegalArgumentException("rating shouldn't be null");
        }
        throw new IllegalArgumentException("mediaId shouldn't be null");
    }

    public void setRepeatMode(int n) {
        this.mImpl.setRepeatMode(n);
    }

    public void setShuffleMode(int n) {
        this.mImpl.setShuffleMode(n);
    }

    public void setTimeDiff(Long l) {
        this.mTimeDiff = l;
    }

    public void setVolumeTo(int n, int n2) {
        this.mImpl.setVolumeTo(n, n2);
    }

    public void skipBackward() {
        this.mImpl.skipBackward();
    }

    public void skipForward() {
        this.mImpl.skipForward();
    }

    public void skipToNextItem() {
        this.mImpl.skipToNextItem();
    }

    public void skipToPlaylistItem(MediaItem2 mediaItem2) {
        if (mediaItem2 != null) {
            this.mImpl.skipToPlaylistItem(mediaItem2);
            return;
        }
        throw new IllegalArgumentException("item shouldn't be null");
    }

    public void skipToPreviousItem() {
        this.mImpl.skipToPreviousItem();
    }

    public void subscribeRoutesInfo() {
        this.mImpl.subscribeRoutesInfo();
    }

    public void unsubscribeRoutesInfo() {
        this.mImpl.unsubscribeRoutesInfo();
    }

    public void updatePlaylistMetadata(MediaMetadata2 mediaMetadata2) {
        this.mImpl.updatePlaylistMetadata(mediaMetadata2);
    }

    public static abstract class ControllerCallback {
        public void onAllowedCommandsChanged(MediaController2 mediaController2, SessionCommandGroup2 sessionCommandGroup2) {
        }

        public void onBufferingStateChanged(MediaController2 mediaController2, MediaItem2 mediaItem2, int n) {
        }

        public void onConnected(MediaController2 mediaController2, SessionCommandGroup2 sessionCommandGroup2) {
        }

        public void onCurrentMediaItemChanged(MediaController2 mediaController2, MediaItem2 mediaItem2) {
        }

        public void onCustomCommand(MediaController2 mediaController2, SessionCommand2 sessionCommand2, Bundle bundle, ResultReceiver resultReceiver) {
        }

        public void onCustomLayoutChanged(MediaController2 mediaController2, List<MediaSession2.CommandButton> list) {
        }

        public void onDisconnected(MediaController2 mediaController2) {
        }

        public void onError(MediaController2 mediaController2, int n, Bundle bundle) {
        }

        public void onPlaybackInfoChanged(MediaController2 mediaController2, PlaybackInfo playbackInfo) {
        }

        public void onPlaybackSpeedChanged(MediaController2 mediaController2, float f) {
        }

        public void onPlayerStateChanged(MediaController2 mediaController2, int n) {
        }

        public void onPlaylistChanged(MediaController2 mediaController2, List<MediaItem2> list, MediaMetadata2 mediaMetadata2) {
        }

        public void onPlaylistMetadataChanged(MediaController2 mediaController2, MediaMetadata2 mediaMetadata2) {
        }

        public void onRepeatModeChanged(MediaController2 mediaController2, int n) {
        }

        public void onRoutesInfoChanged(MediaController2 mediaController2, List<Bundle> list) {
        }

        public void onSeekCompleted(MediaController2 mediaController2, long l) {
        }

        public void onShuffleModeChanged(MediaController2 mediaController2, int n) {
        }
    }

    public static final class PlaybackInfo {
        private static final String KEY_AUDIO_ATTRIBUTES = "android.media.audio_info.audio_attrs";
        private static final String KEY_CONTROL_TYPE = "android.media.audio_info.control_type";
        private static final String KEY_CURRENT_VOLUME = "android.media.audio_info.current_volume";
        private static final String KEY_MAX_VOLUME = "android.media.audio_info.max_volume";
        private static final String KEY_PLAYBACK_TYPE = "android.media.audio_info.playback_type";
        public static final int PLAYBACK_TYPE_LOCAL = 1;
        public static final int PLAYBACK_TYPE_REMOTE = 2;
        private final AudioAttributesCompat mAudioAttrsCompat;
        private final int mControlType;
        private final int mCurrentVolume;
        private final int mMaxVolume;
        private final int mPlaybackType;

        PlaybackInfo(int n, AudioAttributesCompat audioAttributesCompat, int n2, int n3, int n4) {
            this.mPlaybackType = n;
            this.mAudioAttrsCompat = audioAttributesCompat;
            this.mControlType = n2;
            this.mMaxVolume = n3;
            this.mCurrentVolume = n4;
        }

        static PlaybackInfo createPlaybackInfo(int n, AudioAttributesCompat audioAttributesCompat, int n2, int n3, int n4) {
            return new PlaybackInfo(n, audioAttributesCompat, n2, n3, n4);
        }

        static PlaybackInfo fromBundle(Bundle bundle) {
            if (bundle == null) {
                return null;
            }
            int n = bundle.getInt(KEY_PLAYBACK_TYPE);
            int n2 = bundle.getInt(KEY_CONTROL_TYPE);
            int n3 = bundle.getInt(KEY_MAX_VOLUME);
            int n4 = bundle.getInt(KEY_CURRENT_VOLUME);
            return PlaybackInfo.createPlaybackInfo(n, AudioAttributesCompat.fromBundle(bundle.getBundle(KEY_AUDIO_ATTRIBUTES)), n2, n3, n4);
        }

        public AudioAttributesCompat getAudioAttributes() {
            return this.mAudioAttrsCompat;
        }

        public int getControlType() {
            return this.mControlType;
        }

        public int getCurrentVolume() {
            return this.mCurrentVolume;
        }

        public int getMaxVolume() {
            return this.mMaxVolume;
        }

        public int getPlaybackType() {
            return this.mPlaybackType;
        }

        Bundle toBundle() {
            Bundle bundle = new Bundle();
            bundle.putInt(KEY_PLAYBACK_TYPE, this.mPlaybackType);
            bundle.putInt(KEY_CONTROL_TYPE, this.mControlType);
            bundle.putInt(KEY_MAX_VOLUME, this.mMaxVolume);
            bundle.putInt(KEY_CURRENT_VOLUME, this.mCurrentVolume);
            AudioAttributesCompat audioAttributesCompat = this.mAudioAttrsCompat;
            if (audioAttributesCompat != null) {
                bundle.putBundle(KEY_AUDIO_ATTRIBUTES, audioAttributesCompat.toBundle());
            }
            return bundle;
        }
    }

    static interface SupportLibraryImpl
    extends AutoCloseable {
        public void addPlaylistItem(int var1, MediaItem2 var2);

        public void adjustVolume(int var1, int var2);

        public void fastForward();

        public MediaBrowserCompat getBrowserCompat();

        public long getBufferedPosition();

        public int getBufferingState();

        public ControllerCallback getCallback();

        public Executor getCallbackExecutor();

        public Context getContext();

        public MediaItem2 getCurrentMediaItem();

        public long getCurrentPosition();

        public long getDuration();

        public MediaController2 getInstance();

        public PlaybackInfo getPlaybackInfo();

        public float getPlaybackSpeed();

        public int getPlayerState();

        public List<MediaItem2> getPlaylist();

        public MediaMetadata2 getPlaylistMetadata();

        public int getRepeatMode();

        public PendingIntent getSessionActivity();

        public SessionToken2 getSessionToken();

        public int getShuffleMode();

        public boolean isConnected();

        public void pause();

        public void play();

        public void playFromMediaId(String var1, Bundle var2);

        public void playFromSearch(String var1, Bundle var2);

        public void playFromUri(Uri var1, Bundle var2);

        public void prepare();

        public void prepareFromMediaId(String var1, Bundle var2);

        public void prepareFromSearch(String var1, Bundle var2);

        public void prepareFromUri(Uri var1, Bundle var2);

        public void removePlaylistItem(MediaItem2 var1);

        public void replacePlaylistItem(int var1, MediaItem2 var2);

        public void reset();

        public void rewind();

        public void seekTo(long var1);

        public void selectRoute(Bundle var1);

        public void sendCustomCommand(SessionCommand2 var1, Bundle var2, ResultReceiver var3);

        public void setPlaybackSpeed(float var1);

        public void setPlaylist(List<MediaItem2> var1, MediaMetadata2 var2);

        public void setRating(String var1, Rating2 var2);

        public void setRepeatMode(int var1);

        public void setShuffleMode(int var1);

        public void setVolumeTo(int var1, int var2);

        public void skipBackward();

        public void skipForward();

        public void skipToNextItem();

        public void skipToPlaylistItem(MediaItem2 var1);

        public void skipToPreviousItem();

        public void subscribeRoutesInfo();

        public void unsubscribeRoutesInfo();

        public void updatePlaylistMetadata(MediaMetadata2 var1);
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface VolumeDirection {
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface VolumeFlags {
    }
}

