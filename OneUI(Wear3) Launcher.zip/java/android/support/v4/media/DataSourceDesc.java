/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 */
package android.support.v4.media;

import android.content.Context;
import android.net.Uri;
import android.support.v4.media.Media2DataSource;
import android.support.v4.util.Preconditions;
import java.io.FileDescriptor;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class DataSourceDesc {
    public static final long FD_LENGTH_UNKNOWN = 0x7FFFFFFFFFFFFFFL;
    private static final long LONG_MAX = 0x7FFFFFFFFFFFFFFL;
    public static final long POSITION_UNKNOWN = 0x7FFFFFFFFFFFFFFL;
    public static final int TYPE_CALLBACK = 1;
    public static final int TYPE_FD = 2;
    public static final int TYPE_NONE = 0;
    public static final int TYPE_URI = 3;
    private long mEndPositionMs = 0x7FFFFFFFFFFFFFFL;
    private FileDescriptor mFD;
    private long mFDLength = 0x7FFFFFFFFFFFFFFL;
    private long mFDOffset = 0L;
    private Media2DataSource mMedia2DataSource;
    private String mMediaId;
    private long mStartPositionMs = 0L;
    private int mType = 0;
    private Uri mUri;
    private Context mUriContext;
    private List<HttpCookie> mUriCookies;
    private Map<String, String> mUriHeader;

    private DataSourceDesc() {
    }

    static /* synthetic */ int access$002(DataSourceDesc dataSourceDesc, int n) {
        dataSourceDesc.mType = n;
        return n;
    }

    static /* synthetic */ long access$1002(DataSourceDesc dataSourceDesc, long l) {
        dataSourceDesc.mStartPositionMs = l;
        return l;
    }

    static /* synthetic */ Media2DataSource access$102(DataSourceDesc dataSourceDesc, Media2DataSource media2DataSource) {
        dataSourceDesc.mMedia2DataSource = media2DataSource;
        return media2DataSource;
    }

    static /* synthetic */ long access$1102(DataSourceDesc dataSourceDesc, long l) {
        dataSourceDesc.mEndPositionMs = l;
        return l;
    }

    static /* synthetic */ FileDescriptor access$202(DataSourceDesc dataSourceDesc, FileDescriptor fileDescriptor) {
        dataSourceDesc.mFD = fileDescriptor;
        return fileDescriptor;
    }

    static /* synthetic */ long access$302(DataSourceDesc dataSourceDesc, long l) {
        dataSourceDesc.mFDOffset = l;
        return l;
    }

    static /* synthetic */ long access$402(DataSourceDesc dataSourceDesc, long l) {
        dataSourceDesc.mFDLength = l;
        return l;
    }

    static /* synthetic */ Uri access$502(DataSourceDesc dataSourceDesc, Uri uri) {
        dataSourceDesc.mUri = uri;
        return uri;
    }

    static /* synthetic */ Map access$602(DataSourceDesc dataSourceDesc, Map map) {
        dataSourceDesc.mUriHeader = map;
        return map;
    }

    static /* synthetic */ List access$702(DataSourceDesc dataSourceDesc, List list) {
        dataSourceDesc.mUriCookies = list;
        return list;
    }

    static /* synthetic */ Context access$802(DataSourceDesc dataSourceDesc, Context context) {
        dataSourceDesc.mUriContext = context;
        return context;
    }

    static /* synthetic */ String access$902(DataSourceDesc dataSourceDesc, String string2) {
        dataSourceDesc.mMediaId = string2;
        return string2;
    }

    public long getEndPosition() {
        return this.mEndPositionMs;
    }

    public FileDescriptor getFileDescriptor() {
        return this.mFD;
    }

    public long getFileDescriptorLength() {
        return this.mFDLength;
    }

    public long getFileDescriptorOffset() {
        return this.mFDOffset;
    }

    public Media2DataSource getMedia2DataSource() {
        return this.mMedia2DataSource;
    }

    public String getMediaId() {
        return this.mMediaId;
    }

    public long getStartPosition() {
        return this.mStartPositionMs;
    }

    public int getType() {
        return this.mType;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public Context getUriContext() {
        return this.mUriContext;
    }

    public List<HttpCookie> getUriCookies() {
        if (this.mUriCookies == null) {
            return null;
        }
        return new ArrayList<HttpCookie>(this.mUriCookies);
    }

    public Map<String, String> getUriHeaders() {
        if (this.mUriHeader == null) {
            return null;
        }
        return new HashMap<String, String>(this.mUriHeader);
    }

    public static class Builder {
        private long mEndPositionMs = 0x7FFFFFFFFFFFFFFL;
        private FileDescriptor mFD;
        private long mFDLength = 0x7FFFFFFFFFFFFFFL;
        private long mFDOffset = 0L;
        private Media2DataSource mMedia2DataSource;
        private String mMediaId;
        private long mStartPositionMs = 0L;
        private int mType = 0;
        private Uri mUri;
        private Context mUriContext;
        private List<HttpCookie> mUriCookies;
        private Map<String, String> mUriHeader;

        public Builder() {
        }

        public Builder(DataSourceDesc dataSourceDesc) {
            this.mType = dataSourceDesc.mType;
            this.mMedia2DataSource = dataSourceDesc.mMedia2DataSource;
            this.mFD = dataSourceDesc.mFD;
            this.mFDOffset = dataSourceDesc.mFDOffset;
            this.mFDLength = dataSourceDesc.mFDLength;
            this.mUri = dataSourceDesc.mUri;
            this.mUriHeader = dataSourceDesc.mUriHeader;
            this.mUriCookies = dataSourceDesc.mUriCookies;
            this.mUriContext = dataSourceDesc.mUriContext;
            this.mMediaId = dataSourceDesc.mMediaId;
            this.mStartPositionMs = dataSourceDesc.mStartPositionMs;
            this.mEndPositionMs = dataSourceDesc.mEndPositionMs;
        }

        private void resetDataSource() {
            this.mType = 0;
            this.mMedia2DataSource = null;
            this.mFD = null;
            this.mFDOffset = 0L;
            this.mFDLength = 0x7FFFFFFFFFFFFFFL;
            this.mUri = null;
            this.mUriHeader = null;
            this.mUriCookies = null;
            this.mUriContext = null;
        }

        public DataSourceDesc build() {
            int n = this.mType;
            if (n != 1 && n != 2 && n != 3) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Illegal type: ");
                stringBuilder.append(this.mType);
                throw new IllegalStateException(stringBuilder.toString());
            }
            if (this.mStartPositionMs <= this.mEndPositionMs) {
                DataSourceDesc dataSourceDesc = new DataSourceDesc();
                DataSourceDesc.access$002(dataSourceDesc, this.mType);
                DataSourceDesc.access$102(dataSourceDesc, this.mMedia2DataSource);
                DataSourceDesc.access$202(dataSourceDesc, this.mFD);
                DataSourceDesc.access$302(dataSourceDesc, this.mFDOffset);
                DataSourceDesc.access$402(dataSourceDesc, this.mFDLength);
                DataSourceDesc.access$502(dataSourceDesc, this.mUri);
                DataSourceDesc.access$602(dataSourceDesc, this.mUriHeader);
                DataSourceDesc.access$702(dataSourceDesc, this.mUriCookies);
                DataSourceDesc.access$802(dataSourceDesc, this.mUriContext);
                DataSourceDesc.access$902(dataSourceDesc, this.mMediaId);
                DataSourceDesc.access$1002(dataSourceDesc, this.mStartPositionMs);
                DataSourceDesc.access$1102(dataSourceDesc, this.mEndPositionMs);
                return dataSourceDesc;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Illegal start/end position: ");
            stringBuilder.append(this.mStartPositionMs);
            stringBuilder.append(" : ");
            stringBuilder.append(this.mEndPositionMs);
            throw new IllegalStateException(stringBuilder.toString());
        }

        public Builder setDataSource(Context context, Uri uri) {
            Preconditions.checkNotNull(context, "context cannot be null");
            Preconditions.checkNotNull(uri, "uri cannot be null");
            this.resetDataSource();
            this.mType = 3;
            this.mUri = uri;
            this.mUriContext = context;
            return this;
        }

        public Builder setDataSource(Context context, Uri uri, Map<String, String> map, List<HttpCookie> list) {
            CookieHandler cookieHandler;
            Preconditions.checkNotNull(context, "context cannot be null");
            Preconditions.checkNotNull(uri);
            if (list != null && (cookieHandler = CookieHandler.getDefault()) != null && !(cookieHandler instanceof CookieManager)) {
                throw new IllegalArgumentException("The cookie handler has to be of CookieManager type when cookies are provided.");
            }
            this.resetDataSource();
            this.mType = 3;
            this.mUri = uri;
            if (map != null) {
                this.mUriHeader = new HashMap<String, String>(map);
            }
            if (list != null) {
                this.mUriCookies = new ArrayList<HttpCookie>(list);
            }
            this.mUriContext = context;
            return this;
        }

        public Builder setDataSource(Media2DataSource media2DataSource) {
            Preconditions.checkNotNull(media2DataSource);
            this.resetDataSource();
            this.mType = 1;
            this.mMedia2DataSource = media2DataSource;
            return this;
        }

        public Builder setDataSource(FileDescriptor fileDescriptor) {
            Preconditions.checkNotNull(fileDescriptor);
            this.resetDataSource();
            this.mType = 2;
            this.mFD = fileDescriptor;
            return this;
        }

        public Builder setDataSource(FileDescriptor fileDescriptor, long l, long l2) {
            Preconditions.checkNotNull(fileDescriptor);
            long l3 = l;
            if (l < 0L) {
                l3 = 0L;
            }
            l = l2;
            if (l2 < 0L) {
                l = 0x7FFFFFFFFFFFFFFL;
            }
            this.resetDataSource();
            this.mType = 2;
            this.mFD = fileDescriptor;
            this.mFDOffset = l3;
            this.mFDLength = l;
            return this;
        }

        public Builder setEndPosition(long l) {
            long l2 = l;
            if (l < 0L) {
                l2 = 0x7FFFFFFFFFFFFFFL;
            }
            this.mEndPositionMs = l2;
            return this;
        }

        public Builder setMediaId(String string2) {
            this.mMediaId = string2;
            return this;
        }

        public Builder setStartPosition(long l) {
            long l2 = l;
            if (l < 0L) {
                l2 = 0L;
            }
            this.mStartPositionMs = l2;
            return this;
        }
    }
}

