/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.Log
 */
package android.support.v4.media;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.media.SessionCommand2;
import android.util.Log;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public final class SessionCommandGroup2 {
    private static final String KEY_COMMANDS = "android.media.mediasession2.commandgroup.commands";
    private static final String PREFIX_COMMAND_CODE = "COMMAND_CODE_";
    private static final String PREFIX_COMMAND_CODE_PLAYBACK = "COMMAND_CODE_PLAYBACK_";
    private static final String PREFIX_COMMAND_CODE_PLAYLIST = "COMMAND_CODE_PLAYLIST_";
    private static final String PREFIX_COMMAND_CODE_VOLUME = "COMMAND_CODE_VOLUME_";
    private static final String TAG = "SessionCommandGroup2";
    private Set<SessionCommand2> mCommands;

    public SessionCommandGroup2() {
        this.mCommands = new HashSet<SessionCommand2>();
    }

    public SessionCommandGroup2(SessionCommandGroup2 sessionCommandGroup2) {
        HashSet<SessionCommand2> hashSet = new HashSet<SessionCommand2>();
        this.mCommands = hashSet;
        if (sessionCommandGroup2 != null) {
            hashSet.addAll(sessionCommandGroup2.mCommands);
        }
    }

    private void addCommandsWithPrefix(String string2) {
        Field[] fieldArray = SessionCommand2.class.getFields();
        if (fieldArray != null) {
            for (int i = 0; i < fieldArray.length; ++i) {
                Object object;
                if (!fieldArray[i].getName().startsWith(string2) || fieldArray[i].getName().equals("COMMAND_CODE_CUSTOM")) continue;
                try {
                    object = this.mCommands;
                    SessionCommand2 sessionCommand2 = new SessionCommand2(fieldArray[i].getInt(null));
                    object.add(sessionCommand2);
                    continue;
                }
                catch (IllegalAccessException illegalAccessException) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("Unexpected ");
                    ((StringBuilder)object).append(fieldArray[i]);
                    ((StringBuilder)object).append(" in MediaSession2");
                    Log.w((String)TAG, (String)((StringBuilder)object).toString());
                }
            }
        }
    }

    public static SessionCommandGroup2 fromBundle(Bundle object) {
        if (object == null) {
            return null;
        }
        ArrayList arrayList = object.getParcelableArrayList(KEY_COMMANDS);
        if (arrayList == null) {
            return null;
        }
        object = new SessionCommandGroup2();
        for (int i = 0; i < arrayList.size(); ++i) {
            Object object2 = (Parcelable)arrayList.get(i);
            if (!(object2 instanceof Bundle) || (object2 = SessionCommand2.fromBundle((Bundle)object2)) == null) continue;
            ((SessionCommandGroup2)object).addCommand((SessionCommand2)object2);
        }
        return object;
    }

    void addAllPlaybackCommands() {
        this.addCommandsWithPrefix(PREFIX_COMMAND_CODE_PLAYBACK);
    }

    void addAllPlaylistCommands() {
        this.addCommandsWithPrefix(PREFIX_COMMAND_CODE_PLAYLIST);
    }

    public void addAllPredefinedCommands() {
        this.addCommandsWithPrefix(PREFIX_COMMAND_CODE);
    }

    void addAllVolumeCommands() {
        this.addCommandsWithPrefix(PREFIX_COMMAND_CODE_VOLUME);
    }

    public void addCommand(int n) {
        if (n != 0) {
            this.mCommands.add(new SessionCommand2(n));
            return;
        }
        throw new IllegalArgumentException("command shouldn't be null");
    }

    public void addCommand(SessionCommand2 sessionCommand2) {
        if (sessionCommand2 != null) {
            this.mCommands.add(sessionCommand2);
            return;
        }
        throw new IllegalArgumentException("command shouldn't be null");
    }

    public Set<SessionCommand2> getCommands() {
        return new HashSet<SessionCommand2>(this.mCommands);
    }

    public boolean hasCommand(int n) {
        if (n != 0) {
            Iterator<SessionCommand2> iterator2 = this.mCommands.iterator();
            while (iterator2.hasNext()) {
                if (iterator2.next().getCommandCode() != n) continue;
                return true;
            }
            return false;
        }
        throw new IllegalArgumentException("Use hasCommand(Command) for custom command");
    }

    public boolean hasCommand(SessionCommand2 sessionCommand2) {
        if (sessionCommand2 != null) {
            return this.mCommands.contains(sessionCommand2);
        }
        throw new IllegalArgumentException("command shouldn't be null");
    }

    public void removeCommand(int n) {
        if (n != 0) {
            this.mCommands.remove(new SessionCommand2(n));
            return;
        }
        throw new IllegalArgumentException("commandCode shouldn't be COMMAND_CODE_CUSTOM");
    }

    public void removeCommand(SessionCommand2 sessionCommand2) {
        if (sessionCommand2 != null) {
            this.mCommands.remove(sessionCommand2);
            return;
        }
        throw new IllegalArgumentException("command shouldn't be null");
    }

    public Bundle toBundle() {
        ArrayList<Bundle> arrayList = new ArrayList<Bundle>();
        Bundle bundle = this.mCommands.iterator();
        while (bundle.hasNext()) {
            arrayList.add(bundle.next().toBundle());
        }
        bundle = new Bundle();
        bundle.putParcelableArrayList(KEY_COMMANDS, arrayList);
        return bundle;
    }
}

