/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ResolveInfo
 *  android.media.AudioManager
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.DeadObjectException
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.IBinder
 *  android.os.Process
 *  android.os.RemoteException
 *  android.os.ResultReceiver
 *  android.os.SystemClock
 *  android.text.TextUtils
 *  android.util.Log
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.v4.media.AudioAttributesCompat;
import android.support.v4.media.AudioFocusHandler;
import android.support.v4.media.BaseMediaPlayer;
import android.support.v4.media.DataSourceDesc;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaPlaylistAgent;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaSession2Stub;
import android.support.v4.media.MediaSessionLegacyStub;
import android.support.v4.media.MediaUtils2;
import android.support.v4.media.SessionCommand2;
import android.support.v4.media.SessionCommandGroup2;
import android.support.v4.media.SessionPlaylistAgentImplBase;
import android.support.v4.media.SessionToken2;
import android.support.v4.media.SessionToken2ImplBase;
import android.support.v4.media.VolumeProviderCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.support.v4.util.ObjectsCompat;
import android.text.TextUtils;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.Executor;

class MediaSession2ImplBase
implements MediaSession2.SupportLibraryImpl {
    static final boolean DEBUG = Log.isLoggable((String)"MS2ImplBase", (int)3);
    static final String TAG = "MS2ImplBase";
    private final AudioFocusHandler mAudioFocusHandler;
    private final AudioManager mAudioManager;
    private final MediaSession2.SessionCallback mCallback;
    private final Executor mCallbackExecutor;
    private final Context mContext;
    private MediaSession2.OnDataSourceMissingHelper mDsmHelper;
    private final Handler mHandler;
    private final HandlerThread mHandlerThread;
    private final MediaSession2 mInstance;
    final Object mLock = new Object();
    private MediaController2.PlaybackInfo mPlaybackInfo;
    private BaseMediaPlayer mPlayer;
    private final BaseMediaPlayer.PlayerEventCallback mPlayerEventCallback;
    private MediaPlaylistAgent mPlaylistAgent;
    private final MediaPlaylistAgent.PlaylistEventCallback mPlaylistEventCallback;
    private final MediaSession2Stub mSession2Stub;
    private final PendingIntent mSessionActivity;
    private final MediaSessionCompat mSessionCompat;
    private final MediaSessionLegacyStub mSessionLegacyStub;
    private SessionPlaylistAgentImplBase mSessionPlaylistAgent;
    private final SessionToken2 mSessionToken;
    private VolumeProviderCompat mVolumeProvider;

    MediaSession2ImplBase(MediaSession2 object, Context context, String string2, BaseMediaPlayer baseMediaPlayer, MediaPlaylistAgent mediaPlaylistAgent, VolumeProviderCompat volumeProviderCompat, PendingIntent pendingIntent, Executor object2, MediaSession2.SessionCallback sessionCallback) {
        this.mContext = context;
        this.mInstance = object;
        object = new HandlerThread("MediaController2_Thread");
        this.mHandlerThread = object;
        object.start();
        this.mHandler = new Handler(this.mHandlerThread.getLooper());
        this.mSession2Stub = new MediaSession2Stub(this);
        this.mSessionLegacyStub = new MediaSessionLegacyStub(this);
        this.mSessionActivity = pendingIntent;
        this.mCallback = sessionCallback;
        this.mCallbackExecutor = object2;
        this.mAudioManager = (AudioManager)context.getSystemService("audio");
        this.mPlayerEventCallback = new MyPlayerEventCallback(this);
        this.mPlaylistEventCallback = new MyPlaylistEventCallback(this);
        this.mAudioFocusHandler = new AudioFocusHandler(context, this.getInstance());
        object = MediaSession2ImplBase.getServiceName(context, "android.media.MediaLibraryService2", string2);
        object2 = MediaSession2ImplBase.getServiceName(context, "android.media.MediaSessionService2", string2);
        if (object2 != null && object != null) {
            object = new StringBuilder();
            ((StringBuilder)object).append("Ambiguous session type. Multiple session services define the same id=");
            ((StringBuilder)object).append(string2);
            throw new IllegalArgumentException(((StringBuilder)object).toString());
        }
        this.mSessionToken = object != null ? new SessionToken2(new SessionToken2ImplBase(Process.myUid(), 2, context.getPackageName(), (String)object, string2, this.mSession2Stub)) : (object2 != null ? new SessionToken2(new SessionToken2ImplBase(Process.myUid(), 1, context.getPackageName(), (String)object2, string2, this.mSession2Stub)) : new SessionToken2(new SessionToken2ImplBase(Process.myUid(), 0, context.getPackageName(), null, string2, this.mSession2Stub)));
        this.mSessionCompat = object = new MediaSessionCompat(context, string2, this.mSessionToken);
        ((MediaSessionCompat)object).setCallback(this.mSessionLegacyStub, this.mHandler);
        this.mSessionCompat.setSessionActivity(pendingIntent);
        this.updatePlayer(baseMediaPlayer, mediaPlaylistAgent, volumeProviderCompat);
    }

    private MediaController2.PlaybackInfo createPlaybackInfo(VolumeProviderCompat object, AudioAttributesCompat audioAttributesCompat) {
        if (object == null) {
            int n;
            int n2 = this.getLegacyStreamType(audioAttributesCompat);
            int n3 = n = 2;
            if (Build.VERSION.SDK_INT >= 21) {
                n3 = n;
                if (this.mAudioManager.isVolumeFixed()) {
                    n3 = 0;
                }
            }
            object = MediaController2.PlaybackInfo.createPlaybackInfo(1, audioAttributesCompat, n3, this.mAudioManager.getStreamMaxVolume(n2), this.mAudioManager.getStreamVolume(n2));
        } else {
            object = MediaController2.PlaybackInfo.createPlaybackInfo(2, audioAttributesCompat, ((VolumeProviderCompat)object).getVolumeControl(), ((VolumeProviderCompat)object).getMaxVolume(), ((VolumeProviderCompat)object).getCurrentVolume());
        }
        return object;
    }

    private int getLegacyStreamType(AudioAttributesCompat audioAttributesCompat) {
        int n;
        if (audioAttributesCompat == null) {
            n = 3;
        } else {
            int n2;
            n = n2 = audioAttributesCompat.getLegacyStreamType();
            if (n2 == Integer.MIN_VALUE) {
                n = 3;
            }
        }
        return n;
    }

    private static String getServiceName(Context object, String string2, String string3) {
        Object object2 = object.getPackageManager();
        string2 = new Intent(string2);
        string2.setPackage(object.getPackageName());
        object2 = object2.queryIntentServices((Intent)string2, 128);
        string2 = null;
        object = null;
        if (object2 != null) {
            int n = 0;
            while (true) {
                string2 = object;
                if (n >= object2.size()) break;
                String string4 = SessionToken2.getSessionId((ResolveInfo)object2.get(n));
                string2 = object;
                if (string4 != null) {
                    string2 = object;
                    if (TextUtils.equals((CharSequence)string3, (CharSequence)string4)) {
                        if (((ResolveInfo)object2.get((int)n)).serviceInfo == null) {
                            string2 = object;
                        } else if (object == null) {
                            string2 = ((ResolveInfo)object2.get((int)n)).serviceInfo.name;
                        } else {
                            object = new StringBuilder();
                            ((StringBuilder)object).append("Ambiguous session type. Multiple session services define the same id=");
                            ((StringBuilder)object).append(string3);
                            throw new IllegalArgumentException(((StringBuilder)object).toString());
                        }
                    }
                }
                ++n;
                object = string2;
            }
        }
        return string2;
    }

    private void notifyAgentUpdatedNotLocked(MediaPlaylistAgent mediaPlaylistAgent) {
        Object object;
        Object object2 = mediaPlaylistAgent.getPlaylist();
        if (!ObjectsCompat.equals(object2, object = this.getPlaylist())) {
            this.notifyToAllControllers(new NotifyRunnable((List)object){
                final /* synthetic */ List val$newPlaylist;
                {
                    this.val$newPlaylist = list;
                }

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onPlaylistChanged(this.val$newPlaylist, MediaSession2ImplBase.this.getPlaylistMetadata());
                }
            });
        } else {
            object2 = mediaPlaylistAgent.getPlaylistMetadata();
            if (!ObjectsCompat.equals(object2, object = this.getPlaylistMetadata())) {
                this.notifyToAllControllers(new NotifyRunnable((MediaMetadata2)object){
                    final /* synthetic */ MediaMetadata2 val$newMetadata;
                    {
                        this.val$newMetadata = mediaMetadata2;
                    }

                    @Override
                    public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                        controllerCb.onPlaylistMetadataChanged(this.val$newMetadata);
                    }
                });
            }
        }
        object = mediaPlaylistAgent.getCurrentMediaItem();
        object2 = this.getCurrentMediaItem();
        if (!ObjectsCompat.equals(object, object2)) {
            this.notifyToAllControllers(new NotifyRunnable((MediaItem2)object2){
                final /* synthetic */ MediaItem2 val$newCurrentItem;
                {
                    this.val$newCurrentItem = mediaItem2;
                }

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onCurrentMediaItemChanged(this.val$newCurrentItem);
                }
            });
        }
        final int n = this.getRepeatMode();
        if (mediaPlaylistAgent.getRepeatMode() != n) {
            this.notifyToAllControllers(new NotifyRunnable(){

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onRepeatModeChanged(n);
                }
            });
        }
        n = this.getShuffleMode();
        if (mediaPlaylistAgent.getShuffleMode() != n) {
            this.notifyToAllControllers(new NotifyRunnable(){

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onShuffleModeChanged(n);
                }
            });
        }
    }

    private void notifyPlayerUpdatedNotLocked(BaseMediaPlayer baseMediaPlayer) {
        float f;
        final long l = SystemClock.elapsedRealtime();
        final long l2 = this.getCurrentPosition();
        this.notifyToAllControllers(new NotifyRunnable(this.getPlayerState()){
            final /* synthetic */ int val$playerState;
            {
                this.val$playerState = n;
            }

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onPlayerStateChanged(l, l2, this.val$playerState);
            }
        });
        final MediaItem2 mediaItem2 = this.getCurrentMediaItem();
        if (mediaItem2 != null) {
            this.notifyToAllControllers(new NotifyRunnable(this.getBufferingState(), this.getBufferedPosition()){
                final /* synthetic */ long val$bufferedPositionMs;
                final /* synthetic */ int val$bufferingState;
                {
                    this.val$bufferingState = n;
                    this.val$bufferedPositionMs = l;
                }

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onBufferingStateChanged(mediaItem2, this.val$bufferingState, this.val$bufferedPositionMs);
                }
            });
        }
        if ((f = this.getPlaybackSpeed()) != baseMediaPlayer.getPlaybackSpeed()) {
            this.notifyToAllControllers(new NotifyRunnable(){

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onPlaybackSpeedChanged(l, l2, f);
                }
            });
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void notifyPlaylistChangedOnExecutor(MediaPlaylistAgent mediaPlaylistAgent, final List<MediaItem2> list, final MediaMetadata2 mediaMetadata2) {
        Object object = this.mLock;
        synchronized (object) {
            if (mediaPlaylistAgent != this.mPlaylistAgent) {
                return;
            }
        }
        this.mCallback.onPlaylistChanged(this.mInstance, mediaPlaylistAgent, list, mediaMetadata2);
        this.notifyToAllControllers(new NotifyRunnable(){

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onPlaylistChanged(list, mediaMetadata2);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void notifyPlaylistMetadataChangedOnExecutor(MediaPlaylistAgent mediaPlaylistAgent, final MediaMetadata2 mediaMetadata2) {
        Object object = this.mLock;
        synchronized (object) {
            if (mediaPlaylistAgent != this.mPlaylistAgent) {
                return;
            }
        }
        this.mCallback.onPlaylistMetadataChanged(this.mInstance, mediaPlaylistAgent, mediaMetadata2);
        this.notifyToAllControllers(new NotifyRunnable(){

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onPlaylistMetadataChanged(mediaMetadata2);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void notifyRepeatModeChangedOnExecutor(MediaPlaylistAgent mediaPlaylistAgent, final int n) {
        Object object = this.mLock;
        synchronized (object) {
            if (mediaPlaylistAgent != this.mPlaylistAgent) {
                return;
            }
        }
        this.mCallback.onRepeatModeChanged(this.mInstance, mediaPlaylistAgent, n);
        this.notifyToAllControllers(new NotifyRunnable(){

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onRepeatModeChanged(n);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void notifyShuffleModeChangedOnExecutor(MediaPlaylistAgent mediaPlaylistAgent, final int n) {
        Object object = this.mLock;
        synchronized (object) {
            if (mediaPlaylistAgent != this.mPlaylistAgent) {
                return;
            }
        }
        this.mCallback.onShuffleModeChanged(this.mInstance, mediaPlaylistAgent, n);
        this.notifyToAllControllers(new NotifyRunnable(){

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onShuffleModeChanged(n);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void addPlaylistItem(int n, MediaItem2 mediaItem2) {
        if (n < 0) throw new IllegalArgumentException("index shouldn't be negative");
        if (mediaItem2 == null) throw new IllegalArgumentException("item shouldn't be null");
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.addPlaylistItem(n, mediaItem2);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void clearOnDataSourceMissingHelper() {
        Object object = this.mLock;
        synchronized (object) {
            this.mDsmHelper = null;
            if (this.mSessionPlaylistAgent != null) {
                this.mSessionPlaylistAgent.clearOnDataSourceMissingHelper();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void close() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mPlayer == null) {
                return;
            }
            this.mAudioFocusHandler.close();
            this.mPlayer.unregisterPlayerEventCallback(this.mPlayerEventCallback);
            this.mPlayer = null;
            this.mSessionCompat.release();
            NotifyRunnable notifyRunnable = new NotifyRunnable(){

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onDisconnected();
                }
            };
            this.notifyToAllControllers(notifyRunnable);
            this.mHandler.removeCallbacksAndMessages(null);
            if (this.mHandlerThread.isAlive()) {
                if (Build.VERSION.SDK_INT >= 18) {
                    this.mHandlerThread.quitSafely();
                } else {
                    this.mHandlerThread.quit();
                }
            }
            return;
        }
    }

    @Override
    public AudioFocusHandler getAudioFocusHandler() {
        return this.mAudioFocusHandler;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public long getBufferedPosition() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            return baseMediaPlayer.getBufferedPosition();
        }
        if (!DEBUG) return -1L;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return -1L;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public int getBufferingState() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            return baseMediaPlayer.getBufferingState();
        }
        if (!DEBUG) return 0;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return 0;
    }

    @Override
    public MediaSession2.SessionCallback getCallback() {
        return this.mCallback;
    }

    @Override
    public Executor getCallbackExecutor() {
        return this.mCallbackExecutor;
    }

    @Override
    public List<MediaSession2.ControllerInfo> getConnectedControllers() {
        return this.mSession2Stub.getConnectedControllers();
    }

    @Override
    public Context getContext() {
        return this.mContext;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public MediaItem2 getCurrentMediaItem() {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            return mediaPlaylistAgent.getCurrentMediaItem();
        }
        if (!DEBUG) return null;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public long getCurrentPosition() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            return baseMediaPlayer.getCurrentPosition();
        }
        if (!DEBUG) return -1L;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return -1L;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public long getDuration() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            return baseMediaPlayer.getDuration();
        }
        if (!DEBUG) return -1L;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return -1L;
    }

    @Override
    public MediaSession2 getInstance() {
        return this.mInstance;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaController2.PlaybackInfo getPlaybackInfo() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlaybackInfo;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public float getPlaybackSpeed() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            return baseMediaPlayer.getPlaybackSpeed();
        }
        if (!DEBUG) return 1.0f;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return 1.0f;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public PlaybackStateCompat getPlaybackStateCompat() {
        Object object = this.mLock;
        synchronized (object) {
            int n = MediaUtils2.convertToPlaybackStateCompatState(this.getPlayerState(), this.getBufferingState());
            Object object2 = new PlaybackStateCompat.Builder();
            return ((PlaybackStateCompat.Builder)object2).setState(n, this.getCurrentPosition(), this.getPlaybackSpeed()).setActions(0x37FFFFL).setBufferedPosition(this.getBufferedPosition()).build();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public BaseMediaPlayer getPlayer() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlayer;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public int getPlayerState() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            return baseMediaPlayer.getPlayerState();
        }
        if (!DEBUG) return 3;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return 3;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public List<MediaItem2> getPlaylist() {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            return mediaPlaylistAgent.getPlaylist();
        }
        if (!DEBUG) return null;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaPlaylistAgent getPlaylistAgent() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlaylistAgent;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public MediaMetadata2 getPlaylistMetadata() {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            return mediaPlaylistAgent.getPlaylistMetadata();
        }
        if (!DEBUG) return null;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public int getRepeatMode() {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            return mediaPlaylistAgent.getRepeatMode();
        }
        if (!DEBUG) return 0;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return 0;
    }

    @Override
    public PendingIntent getSessionActivity() {
        return this.mSessionActivity;
    }

    @Override
    public IBinder getSessionBinder() {
        return this.mSession2Stub.asBinder();
    }

    @Override
    public MediaSessionCompat getSessionCompat() {
        return this.mSessionCompat;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public int getShuffleMode() {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            return mediaPlaylistAgent.getShuffleMode();
        }
        if (!DEBUG) return 0;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
        return 0;
    }

    @Override
    public SessionToken2 getToken() {
        return this.mSessionToken;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public VolumeProviderCompat getVolumeProvider() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mVolumeProvider;
        }
    }

    @Override
    public boolean isClosed() {
        return this.mHandlerThread.isAlive() ^ true;
    }

    @Override
    public void notifyError(final int n, final Bundle bundle) {
        this.notifyToAllControllers(new NotifyRunnable(){

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onError(n, bundle);
            }
        });
    }

    @Override
    public void notifyRoutesInfoChanged(MediaSession2.ControllerInfo controllerInfo, final List<Bundle> list) {
        this.notifyToController(controllerInfo, new NotifyRunnable(){

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onRoutesInfoChanged(list);
            }
        });
    }

    void notifyToAllControllers(NotifyRunnable notifyRunnable) {
        List<MediaSession2.ControllerInfo> list = this.getConnectedControllers();
        for (int i = 0; i < list.size(); ++i) {
            this.notifyToController(list.get(i), notifyRunnable);
        }
    }

    void notifyToController(final MediaSession2.ControllerInfo controllerInfo, NotifyRunnable object) {
        if (controllerInfo == null) {
            return;
        }
        try {
            object.run(controllerInfo.getControllerCb());
        }
        catch (RemoteException remoteException) {
            object = new StringBuilder();
            ((StringBuilder)object).append("Exception in ");
            ((StringBuilder)object).append(controllerInfo.toString());
            Log.w((String)TAG, (String)((StringBuilder)object).toString(), (Throwable)remoteException);
        }
        catch (DeadObjectException deadObjectException) {
            if (DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(controllerInfo.toString());
                stringBuilder.append(" is gone");
                Log.d((String)TAG, (String)stringBuilder.toString(), (Throwable)deadObjectException);
            }
            this.mSession2Stub.removeControllerInfo(controllerInfo);
            this.mCallbackExecutor.execute(new Runnable(){

                @Override
                public void run() {
                    MediaSession2ImplBase.this.mCallback.onDisconnected(MediaSession2ImplBase.this.getInstance(), controllerInfo);
                }
            });
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void pause() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer == null) {
            if (!DEBUG) return;
            Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
            return;
        }
        if (this.mAudioFocusHandler.onPauseRequested()) {
            baseMediaPlayer.pause();
            return;
        }
        Log.w((String)TAG, (String)"pause() wouldn't be called of the failure in audio focus");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void play() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer == null) {
            if (!DEBUG) return;
            Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
            return;
        }
        if (this.mAudioFocusHandler.onPlayRequested()) {
            baseMediaPlayer.play();
            return;
        }
        Log.w((String)TAG, (String)"play() wouldn't be called because of the failure in audio focus");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void prepare() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            baseMediaPlayer.prepare();
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void removePlaylistItem(MediaItem2 mediaItem2) {
        if (mediaItem2 == null) throw new IllegalArgumentException("item shouldn't be null");
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.removePlaylistItem(mediaItem2);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void replacePlaylistItem(int n, MediaItem2 mediaItem2) {
        if (n < 0) throw new IllegalArgumentException("index shouldn't be negative");
        if (mediaItem2 == null) throw new IllegalArgumentException("item shouldn't be null");
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.replacePlaylistItem(n, mediaItem2);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void reset() {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            baseMediaPlayer.reset();
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void seekTo(long l) {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            baseMediaPlayer.seekTo(l);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    @Override
    public void sendCustomCommand(MediaSession2.ControllerInfo controllerInfo, final SessionCommand2 sessionCommand2, final Bundle bundle, final ResultReceiver resultReceiver) {
        if (controllerInfo != null) {
            if (sessionCommand2 != null) {
                this.notifyToController(controllerInfo, new NotifyRunnable(){

                    @Override
                    public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                        controllerCb.onCustomCommand(sessionCommand2, bundle, resultReceiver);
                    }
                });
                return;
            }
            throw new IllegalArgumentException("command shouldn't be null");
        }
        throw new IllegalArgumentException("controller shouldn't be null");
    }

    @Override
    public void sendCustomCommand(final SessionCommand2 sessionCommand2, final Bundle bundle) {
        if (sessionCommand2 != null) {
            this.notifyToAllControllers(new NotifyRunnable(){

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onCustomCommand(sessionCommand2, bundle, null);
                }
            });
            return;
        }
        throw new IllegalArgumentException("command shouldn't be null");
    }

    @Override
    public void setAllowedCommands(MediaSession2.ControllerInfo controllerInfo, final SessionCommandGroup2 sessionCommandGroup2) {
        if (controllerInfo != null) {
            if (sessionCommandGroup2 != null) {
                this.mSession2Stub.setAllowedCommands(controllerInfo, sessionCommandGroup2);
                this.notifyToController(controllerInfo, new NotifyRunnable(){

                    @Override
                    public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                        controllerCb.onAllowedCommandsChanged(sessionCommandGroup2);
                    }
                });
                return;
            }
            throw new IllegalArgumentException("commands shouldn't be null");
        }
        throw new IllegalArgumentException("controller shouldn't be null");
    }

    @Override
    public void setCustomLayout(MediaSession2.ControllerInfo controllerInfo, final List<MediaSession2.CommandButton> list) {
        if (controllerInfo != null) {
            if (list != null) {
                this.notifyToController(controllerInfo, new NotifyRunnable(){

                    @Override
                    public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                        controllerCb.onCustomLayoutChanged(list);
                    }
                });
                return;
            }
            throw new IllegalArgumentException("layout shouldn't be null");
        }
        throw new IllegalArgumentException("controller shouldn't be null");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setOnDataSourceMissingHelper(MediaSession2.OnDataSourceMissingHelper onDataSourceMissingHelper) {
        if (onDataSourceMissingHelper == null) {
            throw new IllegalArgumentException("helper shouldn't be null");
        }
        Object object = this.mLock;
        synchronized (object) {
            this.mDsmHelper = onDataSourceMissingHelper;
            if (this.mSessionPlaylistAgent != null) {
                this.mSessionPlaylistAgent.setOnDataSourceMissingHelper(onDataSourceMissingHelper);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void setPlaybackSpeed(float f) {
        Object object = this.mLock;
        // MONITORENTER : object
        BaseMediaPlayer baseMediaPlayer = this.mPlayer;
        // MONITOREXIT : object
        if (baseMediaPlayer != null) {
            baseMediaPlayer.setPlaybackSpeed(f);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void setPlaylist(List<MediaItem2> list, MediaMetadata2 mediaMetadata2) {
        if (list == null) throw new IllegalArgumentException("list shouldn't be null");
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.setPlaylist(list, mediaMetadata2);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void setRepeatMode(int n) {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.setRepeatMode(n);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void setShuffleMode(int n) {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.setShuffleMode(n);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    @Override
    public void skipBackward() {
    }

    @Override
    public void skipForward() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void skipToNextItem() {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.skipToNextItem();
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void skipToPlaylistItem(MediaItem2 mediaItem2) {
        if (mediaItem2 == null) throw new IllegalArgumentException("item shouldn't be null");
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.skipToPlaylistItem(mediaItem2);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void skipToPreviousItem() {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.skipToPreviousItem();
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    /*
     * Loose catch block
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void updatePlayer(BaseMediaPlayer baseMediaPlayer, MediaPlaylistAgent mediaPlaylistAgent, VolumeProviderCompat volumeProviderCompat) {
        MediaPlaylistAgent mediaPlaylistAgent2;
        BaseMediaPlayer baseMediaPlayer2;
        boolean bl;
        SessionPlaylistAgentImplBase sessionPlaylistAgentImplBase;
        boolean bl2;
        Object object;
        boolean bl3;
        MediaController2.PlaybackInfo playbackInfo;
        void var3_8;
        block22: {
            if (baseMediaPlayer == null) throw new IllegalArgumentException("player shouldn't be null");
            playbackInfo = this.createPlaybackInfo((VolumeProviderCompat)var3_8, baseMediaPlayer.getAudioAttributes());
            Object object2 = this.mLock;
            // MONITORENTER : object2
            bl3 = false;
            object = this.mPlayer;
            bl2 = object != baseMediaPlayer;
            object = this.mPlaylistAgent;
            bl = object != sessionPlaylistAgentImplBase;
            try {
                object = this.mPlaybackInfo;
                if (object == playbackInfo) break block22;
                bl3 = true;
            }
            catch (Throwable throwable) {
                throw baseMediaPlayer;
            }
        }
        try {
            baseMediaPlayer2 = this.mPlayer;
        }
        catch (Throwable throwable) {
            throw baseMediaPlayer;
        }
        try {
            mediaPlaylistAgent2 = this.mPlaylistAgent;
        }
        catch (Throwable throwable) {
            throw baseMediaPlayer;
        }
        try {
            this.mPlayer = baseMediaPlayer;
            object = sessionPlaylistAgentImplBase;
            if (sessionPlaylistAgentImplBase == null) {
                this.mSessionPlaylistAgent = sessionPlaylistAgentImplBase = new SessionPlaylistAgentImplBase(this, baseMediaPlayer);
                if (this.mDsmHelper != null) {
                    sessionPlaylistAgentImplBase.setOnDataSourceMissingHelper(this.mDsmHelper);
                }
                object = this.mSessionPlaylistAgent;
            }
            this.mPlaylistAgent = object;
            this.mVolumeProvider = var3_8;
            this.mPlaybackInfo = playbackInfo;
            // MONITOREXIT : object2
            if (var3_8 == null) {
                int n = this.getLegacyStreamType(baseMediaPlayer.getAudioAttributes());
                this.mSessionCompat.setPlaybackToLocal(n);
            }
            if (baseMediaPlayer != baseMediaPlayer2) {
                baseMediaPlayer.registerPlayerEventCallback(this.mCallbackExecutor, this.mPlayerEventCallback);
                if (baseMediaPlayer2 != null) {
                    baseMediaPlayer2.unregisterPlayerEventCallback(this.mPlayerEventCallback);
                }
            }
            if (object != mediaPlaylistAgent2) {
                ((MediaPlaylistAgent)object).registerPlaylistEventCallback(this.mCallbackExecutor, this.mPlaylistEventCallback);
                if (mediaPlaylistAgent2 != null) {
                    mediaPlaylistAgent2.unregisterPlaylistEventCallback(this.mPlaylistEventCallback);
                }
            }
            if (baseMediaPlayer2 == null) return;
            if (bl) {
                this.notifyAgentUpdatedNotLocked(mediaPlaylistAgent2);
            }
            if (bl2) {
                this.notifyPlayerUpdatedNotLocked(baseMediaPlayer2);
            }
            if (!bl3) return;
            this.notifyToAllControllers(new NotifyRunnable(){

                @Override
                public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                    controllerCb.onPlaybackInfoChanged(playbackInfo);
                }
            });
            return;
        }
        catch (Throwable throwable) {
            throw baseMediaPlayer;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        throw baseMediaPlayer;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void updatePlaylistMetadata(MediaMetadata2 mediaMetadata2) {
        Object object = this.mLock;
        // MONITORENTER : object
        MediaPlaylistAgent mediaPlaylistAgent = this.mPlaylistAgent;
        // MONITOREXIT : object
        if (mediaPlaylistAgent != null) {
            mediaPlaylistAgent.updatePlaylistMetadata(mediaMetadata2);
            return;
        }
        if (!DEBUG) return;
        Log.d((String)TAG, (String)"API calls after the close()", (Throwable)new IllegalStateException());
    }

    private static class MyPlayerEventCallback
    extends BaseMediaPlayer.PlayerEventCallback {
        private final WeakReference<MediaSession2ImplBase> mSession;

        private MyPlayerEventCallback(MediaSession2ImplBase mediaSession2ImplBase) {
            this.mSession = new WeakReference<MediaSession2ImplBase>(mediaSession2ImplBase);
        }

        private MediaItem2 getMediaItem(MediaSession2ImplBase object, DataSourceDesc dataSourceDesc) {
            if ((object = ((MediaSession2ImplBase)object).getPlaylistAgent()) == null) {
                if (DEBUG) {
                    Log.d((String)MediaSession2ImplBase.TAG, (String)"Session is closed", (Throwable)new IllegalStateException());
                }
                return null;
            }
            if ((object = ((MediaPlaylistAgent)object).getMediaItem(dataSourceDesc)) == null && DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Could not find matching item for dsd=");
                stringBuilder.append(dataSourceDesc);
                Log.d((String)MediaSession2ImplBase.TAG, (String)stringBuilder.toString(), (Throwable)new NoSuchElementException());
            }
            return object;
        }

        private MediaSession2ImplBase getSession() {
            MediaSession2ImplBase mediaSession2ImplBase = (MediaSession2ImplBase)this.mSession.get();
            if (mediaSession2ImplBase == null && DEBUG) {
                Log.d((String)MediaSession2ImplBase.TAG, (String)"Session is closed", (Throwable)new IllegalStateException());
            }
            return mediaSession2ImplBase;
        }

        @Override
        public void onBufferingStateChanged(final BaseMediaPlayer baseMediaPlayer, final DataSourceDesc dataSourceDesc, final int n) {
            final MediaSession2ImplBase mediaSession2ImplBase = this.getSession();
            if (mediaSession2ImplBase != null && dataSourceDesc != null) {
                mediaSession2ImplBase.getCallbackExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        final MediaItem2 mediaItem2 = this.getMediaItem(mediaSession2ImplBase, dataSourceDesc);
                        if (mediaItem2 == null) {
                            return;
                        }
                        mediaSession2ImplBase.getCallback().onBufferingStateChanged(mediaSession2ImplBase.getInstance(), baseMediaPlayer, mediaItem2, n);
                        mediaSession2ImplBase.notifyToAllControllers(new NotifyRunnable(){

                            @Override
                            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                                controllerCb.onBufferingStateChanged(mediaItem2, n, baseMediaPlayer.getBufferedPosition());
                            }
                        });
                    }
                });
                return;
            }
        }

        @Override
        public void onCurrentDataSourceChanged(final BaseMediaPlayer baseMediaPlayer, final DataSourceDesc dataSourceDesc) {
            final MediaSession2ImplBase mediaSession2ImplBase = this.getSession();
            if (mediaSession2ImplBase == null) {
                return;
            }
            mediaSession2ImplBase.getCallbackExecutor().execute(new Runnable(){

                @Override
                public void run() {
                    Object object = dataSourceDesc;
                    if (object == null) {
                        object = null;
                    } else {
                        MediaItem2 mediaItem2 = this.getMediaItem(mediaSession2ImplBase, (DataSourceDesc)object);
                        object = mediaItem2;
                        if (mediaItem2 == null) {
                            object = new StringBuilder();
                            ((StringBuilder)object).append("Cannot obtain media item from the dsd=");
                            ((StringBuilder)object).append(dataSourceDesc);
                            Log.w((String)MediaSession2ImplBase.TAG, (String)((StringBuilder)object).toString());
                            return;
                        }
                    }
                    mediaSession2ImplBase.getCallback().onCurrentMediaItemChanged(mediaSession2ImplBase.getInstance(), baseMediaPlayer, (MediaItem2)object);
                    mediaSession2ImplBase.notifyToAllControllers(new NotifyRunnable((MediaItem2)object){
                        final /* synthetic */ MediaItem2 val$item;
                        {
                            this.val$item = mediaItem2;
                        }

                        @Override
                        public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                            controllerCb.onCurrentMediaItemChanged(this.val$item);
                        }
                    });
                }
            });
        }

        @Override
        public void onMediaPrepared(final BaseMediaPlayer baseMediaPlayer, final DataSourceDesc dataSourceDesc) {
            final MediaSession2ImplBase mediaSession2ImplBase = this.getSession();
            if (mediaSession2ImplBase != null && dataSourceDesc != null) {
                mediaSession2ImplBase.getCallbackExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        MediaItem2 mediaItem2 = this.getMediaItem(mediaSession2ImplBase, dataSourceDesc);
                        if (mediaItem2 == null) {
                            return;
                        }
                        if (mediaItem2.equals(mediaSession2ImplBase.getCurrentMediaItem())) {
                            long l = mediaSession2ImplBase.getDuration();
                            if (l < 0L) {
                                return;
                            }
                            Object object = mediaItem2.getMetadata();
                            if (object != null) {
                                if (!((MediaMetadata2)object).containsKey("android.media.metadata.DURATION")) {
                                    object = new MediaMetadata2.Builder((MediaMetadata2)object).putLong("android.media.metadata.DURATION", l).build();
                                } else {
                                    long l2 = ((MediaMetadata2)object).getLong("android.media.metadata.DURATION");
                                    if (l != l2) {
                                        object = new StringBuilder();
                                        ((StringBuilder)object).append("duration mismatch for an item. duration from player=");
                                        ((StringBuilder)object).append(l);
                                        ((StringBuilder)object).append(" duration from metadata=");
                                        ((StringBuilder)object).append(l2);
                                        ((StringBuilder)object).append(". May be a timing issue?");
                                        Log.w((String)MediaSession2ImplBase.TAG, (String)((StringBuilder)object).toString());
                                    }
                                    object = null;
                                }
                            } else {
                                object = new MediaMetadata2.Builder().putLong("android.media.metadata.DURATION", l).putString("android.media.metadata.MEDIA_ID", mediaItem2.getMediaId()).build();
                            }
                            if (object != null) {
                                mediaItem2.setMetadata((MediaMetadata2)object);
                                mediaSession2ImplBase.notifyToAllControllers(new NotifyRunnable(){

                                    @Override
                                    public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                                        controllerCb.onPlaylistChanged(mediaSession2ImplBase.getPlaylist(), mediaSession2ImplBase.getPlaylistMetadata());
                                    }
                                });
                            }
                        }
                        mediaSession2ImplBase.getCallback().onMediaPrepared(mediaSession2ImplBase.getInstance(), baseMediaPlayer, mediaItem2);
                    }
                });
                return;
            }
        }

        @Override
        public void onPlaybackSpeedChanged(final BaseMediaPlayer baseMediaPlayer, final float f) {
            final MediaSession2ImplBase mediaSession2ImplBase = this.getSession();
            if (mediaSession2ImplBase == null) {
                return;
            }
            mediaSession2ImplBase.getCallbackExecutor().execute(new Runnable(){

                @Override
                public void run() {
                    mediaSession2ImplBase.getCallback().onPlaybackSpeedChanged(mediaSession2ImplBase.getInstance(), baseMediaPlayer, f);
                    mediaSession2ImplBase.notifyToAllControllers(new NotifyRunnable(){

                        @Override
                        public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                            controllerCb.onPlaybackSpeedChanged(SystemClock.elapsedRealtime(), mediaSession2ImplBase.getCurrentPosition(), f);
                        }
                    });
                }
            });
        }

        @Override
        public void onPlayerStateChanged(final BaseMediaPlayer baseMediaPlayer, final int n) {
            final MediaSession2ImplBase mediaSession2ImplBase = this.getSession();
            if (mediaSession2ImplBase == null) {
                return;
            }
            mediaSession2ImplBase.getCallbackExecutor().execute(new Runnable(){

                @Override
                public void run() {
                    mediaSession2ImplBase.mAudioFocusHandler.onPlayerStateChanged(n);
                    mediaSession2ImplBase.getCallback().onPlayerStateChanged(mediaSession2ImplBase.getInstance(), baseMediaPlayer, n);
                    mediaSession2ImplBase.notifyToAllControllers(new NotifyRunnable(){

                        @Override
                        public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                            controllerCb.onPlayerStateChanged(SystemClock.elapsedRealtime(), baseMediaPlayer.getCurrentPosition(), n);
                        }
                    });
                }
            });
        }

        @Override
        public void onSeekCompleted(final BaseMediaPlayer baseMediaPlayer, final long l) {
            final MediaSession2ImplBase mediaSession2ImplBase = this.getSession();
            if (mediaSession2ImplBase == null) {
                return;
            }
            mediaSession2ImplBase.getCallbackExecutor().execute(new Runnable(){

                @Override
                public void run() {
                    mediaSession2ImplBase.getCallback().onSeekCompleted(mediaSession2ImplBase.getInstance(), baseMediaPlayer, l);
                    mediaSession2ImplBase.notifyToAllControllers(new NotifyRunnable(){

                        @Override
                        public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                            controllerCb.onSeekCompleted(SystemClock.elapsedRealtime(), mediaSession2ImplBase.getCurrentPosition(), l);
                        }
                    });
                }
            });
        }
    }

    private static class MyPlaylistEventCallback
    extends MediaPlaylistAgent.PlaylistEventCallback {
        private final WeakReference<MediaSession2ImplBase> mSession;

        private MyPlaylistEventCallback(MediaSession2ImplBase mediaSession2ImplBase) {
            this.mSession = new WeakReference<MediaSession2ImplBase>(mediaSession2ImplBase);
        }

        @Override
        public void onPlaylistChanged(MediaPlaylistAgent mediaPlaylistAgent, List<MediaItem2> list, MediaMetadata2 mediaMetadata2) {
            MediaSession2ImplBase mediaSession2ImplBase = (MediaSession2ImplBase)this.mSession.get();
            if (mediaSession2ImplBase == null) {
                return;
            }
            mediaSession2ImplBase.notifyPlaylistChangedOnExecutor(mediaPlaylistAgent, list, mediaMetadata2);
        }

        @Override
        public void onPlaylistMetadataChanged(MediaPlaylistAgent mediaPlaylistAgent, MediaMetadata2 mediaMetadata2) {
            MediaSession2ImplBase mediaSession2ImplBase = (MediaSession2ImplBase)this.mSession.get();
            if (mediaSession2ImplBase == null) {
                return;
            }
            mediaSession2ImplBase.notifyPlaylistMetadataChangedOnExecutor(mediaPlaylistAgent, mediaMetadata2);
        }

        @Override
        public void onRepeatModeChanged(MediaPlaylistAgent mediaPlaylistAgent, int n) {
            MediaSession2ImplBase mediaSession2ImplBase = (MediaSession2ImplBase)this.mSession.get();
            if (mediaSession2ImplBase == null) {
                return;
            }
            mediaSession2ImplBase.notifyRepeatModeChangedOnExecutor(mediaPlaylistAgent, n);
        }

        @Override
        public void onShuffleModeChanged(MediaPlaylistAgent mediaPlaylistAgent, int n) {
            MediaSession2ImplBase mediaSession2ImplBase = (MediaSession2ImplBase)this.mSession.get();
            if (mediaSession2ImplBase == null) {
                return;
            }
            mediaSession2ImplBase.notifyShuffleModeChangedOnExecutor(mediaPlaylistAgent, n);
        }
    }

    @FunctionalInterface
    static interface NotifyRunnable {
        public void run(MediaSession2.ControllerCb var1) throws RemoteException;
    }
}

