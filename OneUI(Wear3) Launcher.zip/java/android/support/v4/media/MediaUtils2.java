/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.support.mediacompat.Rating2
 */
package android.support.v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.mediacompat.Rating2;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaBrowserServiceCompat;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.RatingCompat;
import java.util.ArrayList;
import java.util.List;

class MediaUtils2 {
    static final String TAG = "MediaUtils2";
    static final MediaBrowserServiceCompat.BrowserRoot sDefaultBrowserRoot = new MediaBrowserServiceCompat.BrowserRoot("android.media.MediaLibraryService2", null);

    private MediaUtils2() {
    }

    static List<MediaItem2> convertBundleListToMediaItem2List(List<Bundle> list) {
        if (list == null) {
            return null;
        }
        ArrayList<MediaItem2> arrayList = new ArrayList<MediaItem2>();
        for (int i = 0; i < list.size(); ++i) {
            Bundle bundle = list.get(i);
            if (bundle == null) continue;
            arrayList.add(MediaItem2.fromBundle(bundle));
        }
        return arrayList;
    }

    static List<Bundle> convertCommandButtonListToBundleList(List<MediaSession2.CommandButton> list) {
        ArrayList<Bundle> arrayList = new ArrayList<Bundle>();
        for (int i = 0; i < list.size(); ++i) {
            Bundle bundle = list.get(i).toBundle();
            if (bundle == null) continue;
            arrayList.add(bundle);
        }
        return arrayList;
    }

    static Parcelable[] convertCommandButtonListToParcelableArray(List<MediaSession2.CommandButton> list) {
        if (list == null) {
            return null;
        }
        ArrayList<Bundle> arrayList = new ArrayList<Bundle>();
        for (int i = 0; i < list.size(); ++i) {
            Bundle bundle = list.get(i).toBundle();
            if (bundle == null) continue;
            arrayList.add(bundle);
        }
        return arrayList.toArray(new Parcelable[0]);
    }

    static List<Bundle> convertMediaItem2ListToBundleList(List<MediaItem2> list) {
        if (list == null) {
            return null;
        }
        ArrayList<Bundle> arrayList = new ArrayList<Bundle>();
        for (int i = 0; i < list.size(); ++i) {
            MediaItem2 mediaItem2 = list.get(i);
            if (mediaItem2 == null || (mediaItem2 = mediaItem2.toBundle()) == null) continue;
            arrayList.add((Bundle)mediaItem2);
        }
        return arrayList;
    }

    static Parcelable[] convertMediaItem2ListToParcelableArray(List<MediaItem2> list) {
        if (list == null) {
            return null;
        }
        ArrayList<MediaItem2> arrayList = new ArrayList<MediaItem2>();
        for (int i = 0; i < list.size(); ++i) {
            MediaItem2 mediaItem2 = list.get(i);
            if (mediaItem2 == null || (mediaItem2 = mediaItem2.toBundle()) == null) continue;
            arrayList.add(mediaItem2);
        }
        return arrayList.toArray(new Parcelable[0]);
    }

    static List<MediaItem2> convertMediaItemListToMediaItem2List(List<MediaBrowserCompat.MediaItem> list) {
        if (list == null) {
            return null;
        }
        ArrayList<MediaItem2> arrayList = new ArrayList<MediaItem2>();
        for (int i = 0; i < list.size(); ++i) {
            arrayList.add(MediaUtils2.convertToMediaItem2(list.get(i)));
        }
        return arrayList;
    }

    static List<Bundle> convertToBundleList(Parcelable[] parcelableArray) {
        if (parcelableArray == null) {
            return null;
        }
        ArrayList<Bundle> arrayList = new ArrayList<Bundle>();
        int n = parcelableArray.length;
        for (int i = 0; i < n; ++i) {
            arrayList.add((Bundle)parcelableArray[i]);
        }
        return arrayList;
    }

    static List<MediaSession2.CommandButton> convertToCommandButtonList(List<Bundle> list) {
        ArrayList<MediaSession2.CommandButton> arrayList = new ArrayList<MediaSession2.CommandButton>();
        for (int i = 0; i < list.size(); ++i) {
            Bundle bundle = list.get(i);
            if (bundle == null) continue;
            arrayList.add(MediaSession2.CommandButton.fromBundle(bundle));
        }
        return arrayList;
    }

    static List<MediaSession2.CommandButton> convertToCommandButtonList(Parcelable[] parcelableArray) {
        ArrayList<MediaSession2.CommandButton> arrayList = new ArrayList<MediaSession2.CommandButton>();
        for (int i = 0; i < parcelableArray.length; ++i) {
            MediaSession2.CommandButton commandButton;
            if (!(parcelableArray[i] instanceof Bundle) || (commandButton = MediaSession2.CommandButton.fromBundle((Bundle)parcelableArray[i])) == null) continue;
            arrayList.add(commandButton);
        }
        return arrayList;
    }

    static MediaBrowserCompat.MediaItem convertToMediaItem(MediaItem2 mediaItem2) {
        Object object;
        if (mediaItem2 == null) {
            return null;
        }
        Object object2 = mediaItem2.getMetadata();
        if (object2 == null) {
            object = new MediaDescriptionCompat.Builder().setMediaId(mediaItem2.getMediaId()).build();
        } else {
            object = new MediaDescriptionCompat.Builder().setMediaId(mediaItem2.getMediaId()).setSubtitle(((MediaMetadata2)object2).getText("android.media.metadata.DISPLAY_SUBTITLE")).setDescription(((MediaMetadata2)object2).getText("android.media.metadata.DISPLAY_DESCRIPTION")).setIconBitmap(((MediaMetadata2)object2).getBitmap("android.media.metadata.DISPLAY_ICON")).setExtras(((MediaMetadata2)object2).getExtras());
            String string2 = ((MediaMetadata2)object2).getString("android.media.metadata.TITLE");
            if (string2 != null) {
                ((MediaDescriptionCompat.Builder)object).setTitle(string2);
            } else {
                ((MediaDescriptionCompat.Builder)object).setTitle(((MediaMetadata2)object2).getString("android.media.metadata.DISPLAY_TITLE"));
            }
            string2 = ((MediaMetadata2)object2).getString("android.media.metadata.DISPLAY_ICON_URI");
            if (string2 != null) {
                ((MediaDescriptionCompat.Builder)object).setIconUri(Uri.parse((String)string2));
            }
            if ((object2 = ((MediaMetadata2)object2).getString("android.media.metadata.MEDIA_URI")) != null) {
                ((MediaDescriptionCompat.Builder)object).setMediaUri(Uri.parse((String)object2));
            }
            object = ((MediaDescriptionCompat.Builder)object).build();
        }
        return new MediaBrowserCompat.MediaItem((MediaDescriptionCompat)object, mediaItem2.getFlags());
    }

    static MediaItem2 convertToMediaItem2(MediaBrowserCompat.MediaItem mediaItem) {
        if (mediaItem != null && mediaItem.getMediaId() != null) {
            MediaMetadata2 mediaMetadata2 = MediaUtils2.convertToMediaMetadata2(mediaItem.getDescription());
            return new MediaItem2.Builder(mediaItem.getFlags()).setMediaId(mediaItem.getMediaId()).setMetadata(mediaMetadata2).build();
        }
        return null;
    }

    static List<MediaItem2> convertToMediaItem2List(Parcelable[] parcelableArray) {
        ArrayList<MediaItem2> arrayList = new ArrayList<MediaItem2>();
        if (parcelableArray != null) {
            for (int i = 0; i < parcelableArray.length; ++i) {
                MediaItem2 mediaItem2;
                if (!(parcelableArray[i] instanceof Bundle) || (mediaItem2 = MediaItem2.fromBundle((Bundle)parcelableArray[i])) == null) continue;
                arrayList.add(mediaItem2);
            }
        }
        return arrayList;
    }

    static List<MediaBrowserCompat.MediaItem> convertToMediaItemList(List<MediaItem2> list) {
        if (list == null) {
            return null;
        }
        ArrayList<MediaBrowserCompat.MediaItem> arrayList = new ArrayList<MediaBrowserCompat.MediaItem>();
        for (int i = 0; i < list.size(); ++i) {
            arrayList.add(MediaUtils2.convertToMediaItem(list.get(i)));
        }
        return arrayList;
    }

    static MediaMetadata2 convertToMediaMetadata2(MediaDescriptionCompat mediaDescriptionCompat) {
        if (mediaDescriptionCompat == null) {
            return null;
        }
        MediaMetadata2.Builder builder = new MediaMetadata2.Builder();
        builder.putString("android.media.metadata.MEDIA_ID", mediaDescriptionCompat.getMediaId());
        CharSequence charSequence = mediaDescriptionCompat.getTitle();
        if (charSequence != null) {
            builder.putText("android.media.metadata.DISPLAY_TITLE", charSequence);
        }
        if (mediaDescriptionCompat.getDescription() != null) {
            builder.putText("android.media.metadata.DISPLAY_DESCRIPTION", mediaDescriptionCompat.getDescription());
        }
        if ((charSequence = mediaDescriptionCompat.getSubtitle()) != null) {
            builder.putText("android.media.metadata.DISPLAY_SUBTITLE", charSequence);
        }
        if ((charSequence = mediaDescriptionCompat.getIconBitmap()) != null) {
            builder.putBitmap("android.media.metadata.DISPLAY_ICON", (Bitmap)charSequence);
        }
        if ((charSequence = mediaDescriptionCompat.getIconUri()) != null) {
            builder.putText("android.media.metadata.DISPLAY_ICON_URI", charSequence.toString());
        }
        if (mediaDescriptionCompat.getExtras() != null) {
            builder.setExtras(mediaDescriptionCompat.getExtras());
        }
        if ((mediaDescriptionCompat = mediaDescriptionCompat.getMediaUri()) != null) {
            builder.putText("android.media.metadata.MEDIA_URI", mediaDescriptionCompat.toString());
        }
        return builder.build();
    }

    static MediaMetadata2 convertToMediaMetadata2(MediaMetadataCompat mediaMetadataCompat) {
        if (mediaMetadataCompat == null) {
            return null;
        }
        return new MediaMetadata2(mediaMetadataCompat.getBundle());
    }

    static MediaMetadataCompat convertToMediaMetadataCompat(MediaMetadata2 mediaMetadata2) {
        Object object;
        if (mediaMetadata2 == null) {
            return null;
        }
        Object object2 = new MediaMetadataCompat.Builder();
        Object object3 = new ArrayList();
        mediaMetadata2 = mediaMetadata2.toBundle();
        for (Object object4 : mediaMetadata2.keySet()) {
            object = mediaMetadata2.get((String)object4);
            if (object instanceof CharSequence) {
                ((MediaMetadataCompat.Builder)object2).putText((String)object4, (CharSequence)object);
                continue;
            }
            if (object instanceof Rating2) {
                ((MediaMetadataCompat.Builder)object2).putRating((String)object4, MediaUtils2.convertToRatingCompat((Rating2)object));
                continue;
            }
            if (object instanceof Bitmap) {
                ((MediaMetadataCompat.Builder)object2).putBitmap((String)object4, (Bitmap)object);
                continue;
            }
            if (object instanceof Long) {
                ((MediaMetadataCompat.Builder)object2).putLong((String)object4, (Long)object);
                continue;
            }
            object3.add(object4);
        }
        object2 = ((MediaMetadataCompat.Builder)object2).build();
        object = object3.iterator();
        while (object.hasNext()) {
            Object object4;
            object3 = (String)object.next();
            object4 = mediaMetadata2.get((String)object3);
            if (object4 instanceof Float) {
                ((MediaMetadataCompat)object2).getBundle().putFloat((String)object3, ((Float)object4).floatValue());
                continue;
            }
            if (!"android.media.metadata.EXTRAS".equals(object4)) continue;
            ((MediaMetadataCompat)object2).getBundle().putBundle((String)object3, (Bundle)object4);
        }
        return object2;
    }

    static int convertToPlaybackStateCompatState(int n, int n2) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    return 7;
                }
                if (n2 != 2) {
                    return 3;
                }
                return 6;
            }
            return 2;
        }
        return 0;
    }

    static int convertToPlayerState(int n) {
        switch (n) {
            default: {
                return 3;
            }
            case 3: 
            case 4: 
            case 5: 
            case 8: 
            case 9: 
            case 10: 
            case 11: {
                return 2;
            }
            case 1: 
            case 2: 
            case 6: {
                return 1;
            }
            case 0: 
        }
        return 0;
    }

    static Rating2 convertToRating2(RatingCompat ratingCompat) {
        if (ratingCompat == null) {
            return null;
        }
        if (!ratingCompat.isRated()) {
            return Rating2.newUnratedRating((int)ratingCompat.getRatingStyle());
        }
        switch (ratingCompat.getRatingStyle()) {
            default: {
                return null;
            }
            case 6: {
                return Rating2.newPercentageRating((float)ratingCompat.getPercentRating());
            }
            case 3: 
            case 4: 
            case 5: {
                return Rating2.newStarRating((int)ratingCompat.getRatingStyle(), (float)ratingCompat.getStarRating());
            }
            case 2: {
                return Rating2.newThumbRating((boolean)ratingCompat.isThumbUp());
            }
            case 1: 
        }
        return Rating2.newHeartRating((boolean)ratingCompat.hasHeart());
    }

    static RatingCompat convertToRatingCompat(Rating2 rating2) {
        if (rating2 == null) {
            return null;
        }
        if (!rating2.isRated()) {
            return RatingCompat.newUnratedRating(rating2.getRatingStyle());
        }
        switch (rating2.getRatingStyle()) {
            default: {
                return null;
            }
            case 6: {
                return RatingCompat.newPercentageRating(rating2.getPercentRating());
            }
            case 3: 
            case 4: 
            case 5: {
                return RatingCompat.newStarRating(rating2.getRatingStyle(), rating2.getStarRating());
            }
            case 2: {
                return RatingCompat.newThumbRating(rating2.isThumbUp());
            }
            case 1: 
        }
        return RatingCompat.newHeartRating(rating2.hasHeart());
    }

    static Bundle createBundle(Bundle bundle) {
        Bundle bundle2 = bundle == null ? new Bundle() : new Bundle(bundle);
        return bundle2;
    }

    static boolean isDefaultLibraryRootHint(Bundle bundle) {
        boolean bl;
        boolean bl2 = bl = false;
        if (bundle != null) {
            bl2 = bl;
            if (bundle.getBoolean("android.support.v4.media.root_default_root", false)) {
                bl2 = true;
            }
        }
        return bl2;
    }
}

