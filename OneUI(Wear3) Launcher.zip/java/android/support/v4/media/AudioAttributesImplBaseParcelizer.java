/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  androidx.media.AudioAttributesImplBase
 *  androidx.media.AudioAttributesImplBaseParcelizer
 *  androidx.versionedparcelable.VersionedParcel
 */
package android.support.v4.media;

import androidx.media.AudioAttributesImplBase;
import androidx.versionedparcelable.VersionedParcel;

public final class AudioAttributesImplBaseParcelizer
extends androidx.media.AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(VersionedParcel versionedParcel) {
        return androidx.media.AudioAttributesImplBaseParcelizer.read((VersionedParcel)versionedParcel);
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, VersionedParcel versionedParcel) {
        androidx.media.AudioAttributesImplBaseParcelizer.write((AudioAttributesImplBase)audioAttributesImplBase, (VersionedParcel)versionedParcel);
    }
}

