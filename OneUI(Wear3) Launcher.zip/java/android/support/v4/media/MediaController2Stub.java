/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.os.Bundle
 *  android.os.ResultReceiver
 *  android.text.TextUtils
 *  android.util.Log
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.support.v4.media.IMediaController2;
import android.support.v4.media.IMediaSession2;
import android.support.v4.media.MediaBrowser2;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaController2ImplBase;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaUtils2;
import android.support.v4.media.SessionCommand2;
import android.support.v4.media.SessionCommandGroup2;
import android.text.TextUtils;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class MediaController2Stub
extends IMediaController2.Stub {
    private static final boolean DEBUG = true;
    private static final String TAG = "MediaController2Stub";
    private final WeakReference<MediaController2ImplBase> mController;

    MediaController2Stub(MediaController2ImplBase mediaController2ImplBase) {
        this.mController = new WeakReference<MediaController2ImplBase>(mediaController2ImplBase);
    }

    private MediaBrowser2 getBrowser() throws IllegalStateException {
        MediaController2ImplBase mediaController2ImplBase = this.getController();
        if (mediaController2ImplBase.getInstance() instanceof MediaBrowser2) {
            return (MediaBrowser2)mediaController2ImplBase.getInstance();
        }
        return null;
    }

    private MediaController2ImplBase getController() throws IllegalStateException {
        MediaController2ImplBase mediaController2ImplBase = (MediaController2ImplBase)this.mController.get();
        if (mediaController2ImplBase != null) {
            return mediaController2ImplBase;
        }
        throw new IllegalStateException("Controller is released");
    }

    public void destroy() {
        this.mController.clear();
    }

    @Override
    public void onAllowedCommandsChanged(Bundle object) {
        MediaController2ImplBase mediaController2ImplBase;
        block3: {
            try {
                mediaController2ImplBase = this.getController();
                if (mediaController2ImplBase != null) break block3;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
        }
        object = SessionCommandGroup2.fromBundle(object);
        if (object == null) {
            Log.w((String)TAG, (String)"onAllowedCommandsChanged(): Ignoring null commands");
            return;
        }
        mediaController2ImplBase.onAllowedCommandsChanged((SessionCommandGroup2)object);
    }

    @Override
    public void onBufferingStateChanged(Bundle bundle, int n, long l) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyBufferingStateChanged(MediaItem2.fromBundle(bundle), n, l);
    }

    @Override
    public void onChildrenChanged(final String string2, final int n, final Bundle bundle) {
        MediaBrowser2 mediaBrowser2;
        block3: {
            if (string2 == null) {
                Log.w((String)TAG, (String)"onChildrenChanged(): Ignoring null parentId");
                return;
            }
            try {
                mediaBrowser2 = this.getBrowser();
                if (mediaBrowser2 != null) break block3;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
        }
        mediaBrowser2.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                mediaBrowser2.getCallback().onChildrenChanged(mediaBrowser2, string2, n, bundle);
            }
        });
    }

    @Override
    public void onConnected(IMediaSession2 iMediaSession2, Bundle bundle, int n, Bundle bundle2, long l, long l2, float f, long l3, Bundle bundle3, int n2, int n3, List<Bundle> list, PendingIntent pendingIntent) {
        MediaController2ImplBase mediaController2ImplBase = (MediaController2ImplBase)this.mController.get();
        if (mediaController2ImplBase == null) {
            Log.d((String)TAG, (String)"onConnected after MediaController2.close()");
            return;
        }
        if (list != null) {
            ArrayList<Bundle> arrayList = new ArrayList<Bundle>();
            for (int i = 0; i < list.size(); ++i) {
                MediaItem2 mediaItem2 = MediaItem2.fromBundle(list.get(i));
                if (mediaItem2 == null) continue;
                arrayList.add((Bundle)mediaItem2);
            }
            list = arrayList;
        } else {
            list = null;
        }
        mediaController2ImplBase.onConnectedNotLocked(iMediaSession2, SessionCommandGroup2.fromBundle(bundle), n, MediaItem2.fromBundle(bundle2), l, l2, f, l3, MediaController2.PlaybackInfo.fromBundle(bundle3), n3, n2, list, pendingIntent);
    }

    @Override
    public void onCurrentMediaItemChanged(Bundle bundle) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyCurrentMediaItemChanged(MediaItem2.fromBundle(bundle));
    }

    @Override
    public void onCustomCommand(Bundle object, Bundle bundle, ResultReceiver resultReceiver) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        object = SessionCommand2.fromBundle(object);
        if (object == null) {
            Log.w((String)TAG, (String)"onCustomCommand(): Ignoring null command");
            return;
        }
        mediaController2ImplBase.onCustomCommand((SessionCommand2)object, bundle, resultReceiver);
    }

    @Override
    public void onCustomLayoutChanged(List<Bundle> list) {
        MediaController2ImplBase mediaController2ImplBase;
        block4: {
            if (list == null) {
                Log.w((String)TAG, (String)"onCustomLayoutChanged(): Ignoring null commandButtonlist");
                return;
            }
            try {
                mediaController2ImplBase = this.getController();
                if (mediaController2ImplBase != null) break block4;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
        }
        ArrayList<MediaSession2.CommandButton> arrayList = new ArrayList<MediaSession2.CommandButton>();
        for (int i = 0; i < list.size(); ++i) {
            MediaSession2.CommandButton commandButton = MediaSession2.CommandButton.fromBundle(list.get(i));
            if (commandButton == null) continue;
            arrayList.add(commandButton);
        }
        mediaController2ImplBase.onCustomLayoutChanged(arrayList);
        return;
    }

    @Override
    public void onDisconnected() {
        MediaController2ImplBase mediaController2ImplBase = (MediaController2ImplBase)this.mController.get();
        if (mediaController2ImplBase == null) {
            Log.d((String)TAG, (String)"onDisconnected after MediaController2.close()");
            return;
        }
        mediaController2ImplBase.getInstance().close();
    }

    @Override
    public void onError(int n, Bundle bundle) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyError(n, bundle);
    }

    @Override
    public void onGetChildrenDone(final String string2, final int n, final int n2, final List<Bundle> list, final Bundle bundle) throws RuntimeException {
        MediaBrowser2 mediaBrowser2;
        block3: {
            if (string2 == null) {
                Log.w((String)TAG, (String)"onGetChildrenDone(): Ignoring null parentId");
                return;
            }
            try {
                mediaBrowser2 = this.getBrowser();
                if (mediaBrowser2 != null) break block3;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
        }
        mediaBrowser2.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                mediaBrowser2.getCallback().onGetChildrenDone(mediaBrowser2, string2, n, n2, MediaUtils2.convertBundleListToMediaItem2List(list), bundle);
            }
        });
    }

    @Override
    public void onGetItemDone(final String string2, final Bundle bundle) throws RuntimeException {
        MediaBrowser2 mediaBrowser2;
        block3: {
            if (string2 == null) {
                Log.w((String)TAG, (String)"onGetItemDone(): Ignoring null mediaId");
                return;
            }
            try {
                mediaBrowser2 = this.getBrowser();
                if (mediaBrowser2 != null) break block3;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
        }
        mediaBrowser2.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                mediaBrowser2.getCallback().onGetItemDone(mediaBrowser2, string2, MediaItem2.fromBundle(bundle));
            }
        });
    }

    @Override
    public void onGetLibraryRootDone(final Bundle bundle, final String string2, final Bundle bundle2) throws RuntimeException {
        MediaBrowser2 mediaBrowser2;
        block2: {
            try {
                mediaBrowser2 = this.getBrowser();
                if (mediaBrowser2 != null) break block2;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
        }
        mediaBrowser2.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                mediaBrowser2.getCallback().onGetLibraryRootDone(mediaBrowser2, bundle, string2, bundle2);
            }
        });
    }

    @Override
    public void onGetSearchResultDone(final String string2, final int n, final int n2, final List<Bundle> list, final Bundle bundle) throws RuntimeException {
        MediaBrowser2 mediaBrowser2;
        block3: {
            if (TextUtils.isEmpty((CharSequence)string2)) {
                Log.w((String)TAG, (String)"onGetSearchResultDone(): Ignoring empty query");
                return;
            }
            try {
                mediaBrowser2 = this.getBrowser();
                if (mediaBrowser2 != null) break block3;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
        }
        mediaBrowser2.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                mediaBrowser2.getCallback().onGetSearchResultDone(mediaBrowser2, string2, n, n2, MediaUtils2.convertBundleListToMediaItem2List(list), bundle);
            }
        });
    }

    @Override
    public void onPlaybackInfoChanged(Bundle object) throws RuntimeException {
        MediaController2ImplBase mediaController2ImplBase;
        Log.d((String)TAG, (String)"onPlaybackInfoChanged");
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        object = MediaController2.PlaybackInfo.fromBundle(object);
        if (object == null) {
            Log.w((String)TAG, (String)"onPlaybackInfoChanged(): Ignoring null playbackInfo");
            return;
        }
        mediaController2ImplBase.notifyPlaybackInfoChanges((MediaController2.PlaybackInfo)object);
    }

    @Override
    public void onPlaybackSpeedChanged(long l, long l2, float f) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyPlaybackSpeedChanges(l, l2, f);
    }

    @Override
    public void onPlayerStateChanged(long l, long l2, int n) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyPlayerStateChanges(l, l2, n);
    }

    @Override
    public void onPlaylistChanged(List<Bundle> object, Bundle bundle) {
        MediaController2ImplBase mediaController2ImplBase;
        block4: {
            try {
                mediaController2ImplBase = this.getController();
                if (object != null) break block4;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
            object = new StringBuilder();
            ((StringBuilder)object).append("onPlaylistChanged(): Ignoring null playlist from ");
            ((StringBuilder)object).append(mediaController2ImplBase);
            Log.w((String)TAG, (String)((StringBuilder)object).toString());
            return;
        }
        ArrayList<MediaItem2> arrayList = new ArrayList<MediaItem2>();
        Iterator iterator2 = object.iterator();
        while (iterator2.hasNext()) {
            object = MediaItem2.fromBundle((Bundle)iterator2.next());
            if (object == null) {
                Log.w((String)TAG, (String)"onPlaylistChanged(): Ignoring null item in playlist");
                continue;
            }
            arrayList.add((MediaItem2)object);
        }
        mediaController2ImplBase.notifyPlaylistChanges(arrayList, MediaMetadata2.fromBundle(bundle));
        return;
    }

    @Override
    public void onPlaylistMetadataChanged(Bundle bundle) throws RuntimeException {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyPlaylistMetadataChanges(MediaMetadata2.fromBundle(bundle));
    }

    @Override
    public void onRepeatModeChanged(int n) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyRepeatModeChanges(n);
    }

    @Override
    public void onRoutesInfoChanged(List<Bundle> list) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyRoutesInfoChanged(list);
    }

    @Override
    public void onSearchResultChanged(final String string2, final int n, final Bundle bundle) throws RuntimeException {
        MediaBrowser2 mediaBrowser2;
        block3: {
            if (TextUtils.isEmpty((CharSequence)string2)) {
                Log.w((String)TAG, (String)"onSearchResultChanged(): Ignoring empty query");
                return;
            }
            try {
                mediaBrowser2 = this.getBrowser();
                if (mediaBrowser2 != null) break block3;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
                return;
            }
        }
        mediaBrowser2.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                mediaBrowser2.getCallback().onSearchResultChanged(mediaBrowser2, string2, n, bundle);
            }
        });
    }

    @Override
    public void onSeekCompleted(long l, long l2, long l3) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifySeekCompleted(l, l2, l3);
    }

    @Override
    public void onShuffleModeChanged(int n) {
        MediaController2ImplBase mediaController2ImplBase;
        try {
            mediaController2ImplBase = this.getController();
        }
        catch (IllegalStateException illegalStateException) {
            Log.w((String)TAG, (String)"Don't fail silently here. Highly likely a bug");
            return;
        }
        mediaController2ImplBase.notifyShuffleModeChanges(n);
    }
}

