/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.support.mediacompat.Rating2
 *  android.util.Log
 */
package android.support.v4.media;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.mediacompat.Rating2;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.SimpleArrayMap;
import android.util.Log;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Set;

public final class MediaMetadata2 {
    public static final long BT_FOLDER_TYPE_ALBUMS = 2L;
    public static final long BT_FOLDER_TYPE_ARTISTS = 3L;
    public static final long BT_FOLDER_TYPE_GENRES = 4L;
    public static final long BT_FOLDER_TYPE_MIXED = 0L;
    public static final long BT_FOLDER_TYPE_PLAYLISTS = 5L;
    public static final long BT_FOLDER_TYPE_TITLES = 1L;
    public static final long BT_FOLDER_TYPE_YEARS = 6L;
    static final ArrayMap<String, Integer> METADATA_KEYS_TYPE;
    public static final String METADATA_KEY_ADVERTISEMENT = "android.media.metadata.ADVERTISEMENT";
    public static final String METADATA_KEY_ALBUM = "android.media.metadata.ALBUM";
    public static final String METADATA_KEY_ALBUM_ART = "android.media.metadata.ALBUM_ART";
    public static final String METADATA_KEY_ALBUM_ARTIST = "android.media.metadata.ALBUM_ARTIST";
    public static final String METADATA_KEY_ALBUM_ART_URI = "android.media.metadata.ALBUM_ART_URI";
    public static final String METADATA_KEY_ART = "android.media.metadata.ART";
    public static final String METADATA_KEY_ARTIST = "android.media.metadata.ARTIST";
    public static final String METADATA_KEY_ART_URI = "android.media.metadata.ART_URI";
    public static final String METADATA_KEY_AUTHOR = "android.media.metadata.AUTHOR";
    public static final String METADATA_KEY_BT_FOLDER_TYPE = "android.media.metadata.BT_FOLDER_TYPE";
    public static final String METADATA_KEY_COMPILATION = "android.media.metadata.COMPILATION";
    public static final String METADATA_KEY_COMPOSER = "android.media.metadata.COMPOSER";
    public static final String METADATA_KEY_DATE = "android.media.metadata.DATE";
    public static final String METADATA_KEY_DISC_NUMBER = "android.media.metadata.DISC_NUMBER";
    public static final String METADATA_KEY_DISPLAY_DESCRIPTION = "android.media.metadata.DISPLAY_DESCRIPTION";
    public static final String METADATA_KEY_DISPLAY_ICON = "android.media.metadata.DISPLAY_ICON";
    public static final String METADATA_KEY_DISPLAY_ICON_URI = "android.media.metadata.DISPLAY_ICON_URI";
    public static final String METADATA_KEY_DISPLAY_SUBTITLE = "android.media.metadata.DISPLAY_SUBTITLE";
    public static final String METADATA_KEY_DISPLAY_TITLE = "android.media.metadata.DISPLAY_TITLE";
    public static final String METADATA_KEY_DOWNLOAD_STATUS = "android.media.metadata.DOWNLOAD_STATUS";
    public static final String METADATA_KEY_DURATION = "android.media.metadata.DURATION";
    public static final String METADATA_KEY_EXTRAS = "android.media.metadata.EXTRAS";
    public static final String METADATA_KEY_GENRE = "android.media.metadata.GENRE";
    public static final String METADATA_KEY_MEDIA_ID = "android.media.metadata.MEDIA_ID";
    public static final String METADATA_KEY_MEDIA_URI = "android.media.metadata.MEDIA_URI";
    public static final String METADATA_KEY_NUM_TRACKS = "android.media.metadata.NUM_TRACKS";
    public static final String METADATA_KEY_RADIO_FREQUENCY = "android.media.metadata.RADIO_FREQUENCY";
    public static final String METADATA_KEY_RADIO_PROGRAM_NAME = "android.media.metadata.RADIO_PROGRAM_NAME";
    public static final String METADATA_KEY_RATING = "android.media.metadata.RATING";
    public static final String METADATA_KEY_TITLE = "android.media.metadata.TITLE";
    public static final String METADATA_KEY_TRACK_NUMBER = "android.media.metadata.TRACK_NUMBER";
    public static final String METADATA_KEY_USER_RATING = "android.media.metadata.USER_RATING";
    public static final String METADATA_KEY_WRITER = "android.media.metadata.WRITER";
    public static final String METADATA_KEY_YEAR = "android.media.metadata.YEAR";
    static final int METADATA_TYPE_BITMAP = 2;
    static final int METADATA_TYPE_FLOAT = 4;
    static final int METADATA_TYPE_LONG = 0;
    static final int METADATA_TYPE_RATING = 3;
    static final int METADATA_TYPE_TEXT = 1;
    private static final String[] PREFERRED_BITMAP_ORDER;
    private static final String[] PREFERRED_DESCRIPTION_ORDER;
    private static final String[] PREFERRED_URI_ORDER;
    public static final long STATUS_DOWNLOADED = 2L;
    public static final long STATUS_DOWNLOADING = 1L;
    public static final long STATUS_NOT_DOWNLOADED = 0L;
    private static final String TAG = "MediaMetadata2";
    final Bundle mBundle;

    static {
        Object object = new ArrayMap<String, Integer>();
        METADATA_KEYS_TYPE = object;
        Integer n = 1;
        ((SimpleArrayMap)object).put(METADATA_KEY_TITLE, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_ARTIST, n);
        Object object2 = METADATA_KEYS_TYPE;
        object = 0;
        ((SimpleArrayMap)object2).put((String)METADATA_KEY_DURATION, (Integer)object);
        METADATA_KEYS_TYPE.put(METADATA_KEY_ALBUM, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_AUTHOR, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_WRITER, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_COMPOSER, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_COMPILATION, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_DATE, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_YEAR, (Integer)object);
        METADATA_KEYS_TYPE.put(METADATA_KEY_GENRE, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_TRACK_NUMBER, (Integer)object);
        METADATA_KEYS_TYPE.put(METADATA_KEY_NUM_TRACKS, (Integer)object);
        METADATA_KEYS_TYPE.put(METADATA_KEY_DISC_NUMBER, (Integer)object);
        METADATA_KEYS_TYPE.put(METADATA_KEY_ALBUM_ARTIST, n);
        ArrayMap<String, Integer> arrayMap = METADATA_KEYS_TYPE;
        object2 = 2;
        arrayMap.put(METADATA_KEY_ART, (Integer)object2);
        METADATA_KEYS_TYPE.put(METADATA_KEY_ART_URI, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_ALBUM_ART, (Integer)object2);
        METADATA_KEYS_TYPE.put(METADATA_KEY_ALBUM_ART_URI, n);
        arrayMap = METADATA_KEYS_TYPE;
        Integer n2 = 3;
        arrayMap.put(METADATA_KEY_USER_RATING, n2);
        METADATA_KEYS_TYPE.put(METADATA_KEY_RATING, n2);
        METADATA_KEYS_TYPE.put(METADATA_KEY_DISPLAY_TITLE, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_DISPLAY_SUBTITLE, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_DISPLAY_DESCRIPTION, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_DISPLAY_ICON, (Integer)object2);
        METADATA_KEYS_TYPE.put(METADATA_KEY_DISPLAY_ICON_URI, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_MEDIA_ID, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_MEDIA_URI, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_RADIO_FREQUENCY, 4);
        METADATA_KEYS_TYPE.put(METADATA_KEY_RADIO_PROGRAM_NAME, n);
        METADATA_KEYS_TYPE.put(METADATA_KEY_BT_FOLDER_TYPE, (Integer)object);
        METADATA_KEYS_TYPE.put(METADATA_KEY_ADVERTISEMENT, (Integer)object);
        METADATA_KEYS_TYPE.put(METADATA_KEY_DOWNLOAD_STATUS, (Integer)object);
        PREFERRED_DESCRIPTION_ORDER = new String[]{METADATA_KEY_TITLE, METADATA_KEY_ARTIST, METADATA_KEY_ALBUM, METADATA_KEY_ALBUM_ARTIST, METADATA_KEY_WRITER, METADATA_KEY_AUTHOR, METADATA_KEY_COMPOSER};
        PREFERRED_BITMAP_ORDER = new String[]{METADATA_KEY_DISPLAY_ICON, METADATA_KEY_ART, METADATA_KEY_ALBUM_ART};
        PREFERRED_URI_ORDER = new String[]{METADATA_KEY_DISPLAY_ICON_URI, METADATA_KEY_ART_URI, METADATA_KEY_ALBUM_ART_URI};
    }

    MediaMetadata2(Bundle bundle) {
        this.mBundle = bundle = new Bundle(bundle);
        bundle.setClassLoader(MediaMetadata2.class.getClassLoader());
    }

    public static MediaMetadata2 fromBundle(Bundle object) {
        object = object == null ? null : new MediaMetadata2((Bundle)object);
        return object;
    }

    public boolean containsKey(String string2) {
        if (string2 != null) {
            return this.mBundle.containsKey(string2);
        }
        throw new IllegalArgumentException("key shouldn't be null");
    }

    public Bitmap getBitmap(String string2) {
        if (string2 != null) {
            Object var2_3 = null;
            try {
                string2 = (Bitmap)this.mBundle.getParcelable(string2);
            }
            catch (Exception exception) {
                Log.w((String)TAG, (String)"Failed to retrieve a key as Bitmap.", (Throwable)exception);
                string2 = var2_3;
            }
            return string2;
        }
        throw new IllegalArgumentException("key shouldn't be null");
    }

    public Bundle getExtras() {
        try {
            Bundle bundle = this.mBundle.getBundle(METADATA_KEY_EXTRAS);
            return bundle;
        }
        catch (Exception exception) {
            Log.w((String)TAG, (String)"Failed to retrieve an extra");
            return null;
        }
    }

    public float getFloat(String string2) {
        if (string2 != null) {
            return this.mBundle.getFloat(string2);
        }
        throw new IllegalArgumentException("key shouldn't be null");
    }

    public long getLong(String string2) {
        if (string2 != null) {
            return this.mBundle.getLong(string2, 0L);
        }
        throw new IllegalArgumentException("key shouldn't be null");
    }

    public String getMediaId() {
        return this.getString(METADATA_KEY_MEDIA_ID);
    }

    public Rating2 getRating(String string2) {
        if (string2 != null) {
            Object var2_3 = null;
            try {
                string2 = Rating2.fromBundle((Bundle)this.mBundle.getBundle(string2));
            }
            catch (Exception exception) {
                Log.w((String)TAG, (String)"Failed to retrieve a key as Rating.", (Throwable)exception);
                string2 = var2_3;
            }
            return string2;
        }
        throw new IllegalArgumentException("key shouldn't be null");
    }

    public String getString(String charSequence) {
        if (charSequence != null) {
            if ((charSequence = this.mBundle.getCharSequence((String)charSequence)) != null) {
                return charSequence.toString();
            }
            return null;
        }
        throw new IllegalArgumentException("key shouldn't be null");
    }

    public CharSequence getText(String string2) {
        if (string2 != null) {
            return this.mBundle.getCharSequence(string2);
        }
        throw new IllegalArgumentException("key shouldn't be null");
    }

    public Set<String> keySet() {
        return this.mBundle.keySet();
    }

    public int size() {
        return this.mBundle.size();
    }

    public Bundle toBundle() {
        return this.mBundle;
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface BitmapKey {
    }

    public static final class Builder {
        final Bundle mBundle;

        public Builder() {
            this.mBundle = new Bundle();
        }

        public Builder(MediaMetadata2 mediaMetadata2) {
            this.mBundle = new Bundle(mediaMetadata2.toBundle());
        }

        public Builder(MediaMetadata2 object, int n) {
            this((MediaMetadata2)object);
            for (String string2 : this.mBundle.keySet()) {
                Object object2 = this.mBundle.get(string2);
                if (!(object2 instanceof Bitmap) || (object2 = (Bitmap)object2).getHeight() <= n && object2.getWidth() <= n) continue;
                this.putBitmap(string2, this.scaleBitmap((Bitmap)object2, n));
            }
        }

        private Bitmap scaleBitmap(Bitmap bitmap, int n) {
            float f = n;
            f = Math.min(f / (float)bitmap.getWidth(), f / (float)bitmap.getHeight());
            n = (int)((float)bitmap.getHeight() * f);
            return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)((int)((float)bitmap.getWidth() * f)), (int)n, (boolean)true);
        }

        public MediaMetadata2 build() {
            return new MediaMetadata2(this.mBundle);
        }

        public Builder putBitmap(String string2, Bitmap object) {
            if (string2 != null) {
                if (METADATA_KEYS_TYPE.containsKey(string2) && (Integer)METADATA_KEYS_TYPE.get(string2) != 2) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("The ");
                    ((StringBuilder)object).append(string2);
                    ((StringBuilder)object).append(" key cannot be used to put a Bitmap");
                    throw new IllegalArgumentException(((StringBuilder)object).toString());
                }
                this.mBundle.putParcelable(string2, (Parcelable)object);
                return this;
            }
            throw new IllegalArgumentException("key shouldn't be null");
        }

        public Builder putFloat(String string2, float f) {
            if (string2 != null) {
                if (METADATA_KEYS_TYPE.containsKey(string2) && (Integer)METADATA_KEYS_TYPE.get(string2) != 4) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("The ");
                    stringBuilder.append(string2);
                    stringBuilder.append(" key cannot be used to put a float");
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                this.mBundle.putFloat(string2, f);
                return this;
            }
            throw new IllegalArgumentException("key shouldn't be null");
        }

        public Builder putLong(String string2, long l) {
            if (string2 != null) {
                if (METADATA_KEYS_TYPE.containsKey(string2) && (Integer)METADATA_KEYS_TYPE.get(string2) != 0) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("The ");
                    stringBuilder.append(string2);
                    stringBuilder.append(" key cannot be used to put a long");
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                this.mBundle.putLong(string2, l);
                return this;
            }
            throw new IllegalArgumentException("key shouldn't be null");
        }

        public Builder putRating(String string2, Rating2 object) {
            if (string2 != null) {
                if (METADATA_KEYS_TYPE.containsKey(string2) && (Integer)METADATA_KEYS_TYPE.get(string2) != 3) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("The ");
                    ((StringBuilder)object).append(string2);
                    ((StringBuilder)object).append(" key cannot be used to put a Rating");
                    throw new IllegalArgumentException(((StringBuilder)object).toString());
                }
                Bundle bundle = this.mBundle;
                object = object == null ? null : object.toBundle();
                bundle.putBundle(string2, (Bundle)object);
                return this;
            }
            throw new IllegalArgumentException("key shouldn't be null");
        }

        public Builder putString(String string2, String charSequence) {
            if (string2 != null) {
                if (METADATA_KEYS_TYPE.containsKey(string2) && (Integer)METADATA_KEYS_TYPE.get(string2) != 1) {
                    charSequence = new StringBuilder();
                    ((StringBuilder)charSequence).append("The ");
                    ((StringBuilder)charSequence).append(string2);
                    ((StringBuilder)charSequence).append(" key cannot be used to put a String");
                    throw new IllegalArgumentException(((StringBuilder)charSequence).toString());
                }
                this.mBundle.putCharSequence(string2, charSequence);
                return this;
            }
            throw new IllegalArgumentException("key shouldn't be null");
        }

        public Builder putText(String string2, CharSequence charSequence) {
            if (string2 != null) {
                if (METADATA_KEYS_TYPE.containsKey(string2) && (Integer)METADATA_KEYS_TYPE.get(string2) != 1) {
                    charSequence = new StringBuilder();
                    ((StringBuilder)charSequence).append("The ");
                    ((StringBuilder)charSequence).append(string2);
                    ((StringBuilder)charSequence).append(" key cannot be used to put a CharSequence");
                    throw new IllegalArgumentException(((StringBuilder)charSequence).toString());
                }
                this.mBundle.putCharSequence(string2, charSequence);
                return this;
            }
            throw new IllegalArgumentException("key shouldn't be null");
        }

        public Builder setExtras(Bundle bundle) {
            this.mBundle.putBundle(MediaMetadata2.METADATA_KEY_EXTRAS, bundle);
            return this;
        }
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface FloatKey {
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface LongKey {
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface RatingKey {
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface TextKey {
    }
}

