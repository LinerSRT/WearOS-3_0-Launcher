/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IBinder$DeathRecipient
 *  android.os.RemoteException
 *  android.os.ResultReceiver
 *  android.os.SystemClock
 *  android.support.mediacompat.Rating2
 *  android.util.Log
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.mediacompat.Rating2;
import android.support.v4.media.IMediaSession2;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaController2Stub;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaUtils2;
import android.support.v4.media.SessionCommand2;
import android.support.v4.media.SessionCommandGroup2;
import android.support.v4.media.SessionToken2;
import android.util.Log;
import java.util.List;
import java.util.concurrent.Executor;

class MediaController2ImplBase
implements MediaController2.SupportLibraryImpl {
    static final boolean DEBUG = Log.isLoggable((String)"MC2ImplBase", (int)3);
    static final String TAG = "MC2ImplBase";
    private SessionCommandGroup2 mAllowedCommands;
    private long mBufferedPositionMs;
    private int mBufferingState;
    private final MediaController2.ControllerCallback mCallback;
    private final Executor mCallbackExecutor;
    private final Context mContext;
    final MediaController2Stub mControllerStub;
    private MediaItem2 mCurrentMediaItem;
    private final IBinder.DeathRecipient mDeathRecipient;
    private volatile IMediaSession2 mISession2;
    private final MediaController2 mInstance;
    private boolean mIsReleased;
    private final Object mLock = new Object();
    private MediaController2.PlaybackInfo mPlaybackInfo;
    private float mPlaybackSpeed;
    private int mPlayerState;
    private List<MediaItem2> mPlaylist;
    private MediaMetadata2 mPlaylistMetadata;
    private long mPositionEventTimeMs;
    private long mPositionMs;
    private int mRepeatMode;
    private SessionServiceConnection mServiceConnection;
    private PendingIntent mSessionActivity;
    private int mShuffleMode;
    private final SessionToken2 mToken;

    MediaController2ImplBase(Context object, MediaController2 mediaController2, SessionToken2 sessionToken2, Executor executor, MediaController2.ControllerCallback controllerCallback) {
        this.mInstance = mediaController2;
        if (object != null) {
            if (sessionToken2 != null) {
                if (controllerCallback != null) {
                    if (executor != null) {
                        this.mContext = object;
                        this.mControllerStub = new MediaController2Stub(this);
                        this.mToken = sessionToken2;
                        this.mCallback = controllerCallback;
                        this.mCallbackExecutor = executor;
                        this.mDeathRecipient = new IBinder.DeathRecipient(){

                            public void binderDied() {
                                MediaController2ImplBase.this.mInstance.close();
                            }
                        };
                        object = IMediaSession2.Stub.asInterface((IBinder)this.mToken.getBinder());
                        if (this.mToken.getType() == 0) {
                            this.mServiceConnection = null;
                            this.connectToSession((IMediaSession2)object);
                        } else {
                            this.mServiceConnection = new SessionServiceConnection();
                            this.connectToService();
                        }
                        return;
                    }
                    throw new IllegalArgumentException("executor shouldn't be null");
                }
                throw new IllegalArgumentException("callback shouldn't be null");
            }
            throw new IllegalArgumentException("token shouldn't be null");
        }
        throw new IllegalArgumentException("context shouldn't be null");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void connectToService() {
        Object object = new Intent("android.media.MediaSessionService2");
        object.setClassName(this.mToken.getPackageName(), this.mToken.getServiceName());
        Object object2 = this.mLock;
        synchronized (object2) {
            if (!this.mContext.bindService((Intent)object, (ServiceConnection)this.mServiceConnection, 1)) {
                object = new StringBuilder();
                ((StringBuilder)object).append("bind to ");
                ((StringBuilder)object).append(this.mToken);
                ((StringBuilder)object).append(" failed");
                Log.w((String)TAG, (String)((StringBuilder)object).toString());
            } else if (DEBUG) {
                object = new StringBuilder();
                ((StringBuilder)object).append("bind to ");
                ((StringBuilder)object).append(this.mToken);
                ((StringBuilder)object).append(" success");
                Log.d((String)TAG, (String)((StringBuilder)object).toString());
            }
            return;
        }
    }

    private void connectToSession(IMediaSession2 iMediaSession2) {
        try {
            iMediaSession2.connect(this.mControllerStub, this.mContext.getPackageName());
        }
        catch (RemoteException remoteException) {
            Log.w((String)TAG, (String)"Failed to call connection request. Framework will retry automatically");
        }
    }

    @Override
    public void addPlaylistItem(int n, MediaItem2 mediaItem2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(15);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.addPlaylistItem(this.mControllerStub, n, mediaItem2.toBundle());
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void adjustVolume(int n, int n2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(11);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.adjustVolume(this.mControllerStub, n, n2);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void close() {
        block10: {
            Object object;
            if (DEBUG) {
                object = new StringBuilder();
                ((StringBuilder)object).append("release from ");
                ((StringBuilder)object).append(this.mToken);
                Log.d((String)TAG, (String)((StringBuilder)object).toString());
            }
            Object object2 = this.mLock;
            synchronized (object2) {
                object = this.mISession2;
                if (this.mIsReleased) {
                    return;
                }
                this.mIsReleased = true;
                if (this.mServiceConnection != null) {
                    this.mContext.unbindService((ServiceConnection)this.mServiceConnection);
                    this.mServiceConnection = null;
                }
                this.mISession2 = null;
                this.mControllerStub.destroy();
                // MONITOREXIT @DISABLED, blocks:[1, 4] lbl22 : MonitorExitStatement: MONITOREXIT : var2_4
                if (object == null) break block10;
                {
                    catch (Throwable throwable) {}
                    throw throwable;
                }
            }
            try {
                object.asBinder().unlinkToDeath(this.mDeathRecipient, 0);
                object.release(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                // empty catch block
            }
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                MediaController2ImplBase.this.mCallback.onDisconnected(MediaController2ImplBase.this.mInstance);
            }
        });
    }

    @Override
    public void fastForward() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(7);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.fastForward(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public MediaBrowserCompat getBrowserCompat() {
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public long getBufferedPosition() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mISession2 != null) return this.mBufferedPositionMs;
            IllegalStateException illegalStateException = new IllegalStateException();
            Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
            return -1L;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getBufferingState() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mISession2 != null) return this.mBufferingState;
            IllegalStateException illegalStateException = new IllegalStateException();
            Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
            return 0;
        }
    }

    @Override
    public MediaController2.ControllerCallback getCallback() {
        return this.mCallback;
    }

    @Override
    public Executor getCallbackExecutor() {
        return this.mCallbackExecutor;
    }

    @Override
    public Context getContext() {
        return this.mContext;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaItem2 getCurrentMediaItem() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mCurrentMediaItem;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public long getCurrentPosition() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mISession2 == null) {
                IllegalStateException illegalStateException = new IllegalStateException();
                Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
                return -1L;
            }
            long l = this.mInstance.mTimeDiff != null ? this.mInstance.mTimeDiff : SystemClock.elapsedRealtime() - this.mPositionEventTimeMs;
            return Math.max(0L, this.mPositionMs + (long)(this.mPlaybackSpeed * (float)l));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public long getDuration() {
        Object object = this.mLock;
        synchronized (object) {
            MediaMetadata2 mediaMetadata2 = this.mCurrentMediaItem.getMetadata();
            if (mediaMetadata2 == null) return -1L;
            if (!mediaMetadata2.containsKey("android.media.metadata.DURATION")) return -1L;
            return mediaMetadata2.getLong("android.media.metadata.DURATION");
        }
    }

    @Override
    public MediaController2 getInstance() {
        return this.mInstance;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaController2.PlaybackInfo getPlaybackInfo() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlaybackInfo;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public float getPlaybackSpeed() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mISession2 != null) return this.mPlaybackSpeed;
            IllegalStateException illegalStateException = new IllegalStateException();
            Log.w((String)TAG, (String)"Session isn't active", (Throwable)illegalStateException);
            return 0.0f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getPlayerState() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlayerState;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public List<MediaItem2> getPlaylist() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlaylist;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaMetadata2 getPlaylistMetadata() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mPlaylistMetadata;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getRepeatMode() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mRepeatMode;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public PendingIntent getSessionActivity() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mSessionActivity;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    IMediaSession2 getSessionInterfaceIfAble(int n) {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mAllowedCommands.hasCommand(n)) return this.mISession2;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Controller isn't allowed to call command, commandCode=");
            stringBuilder.append(n);
            Log.w((String)TAG, (String)stringBuilder.toString());
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    IMediaSession2 getSessionInterfaceIfAble(SessionCommand2 object) {
        Object object2 = this.mLock;
        synchronized (object2) {
            if (this.mAllowedCommands.hasCommand((SessionCommand2)object)) return this.mISession2;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Controller isn't allowed to call command, command=");
            stringBuilder.append(object);
            Log.w((String)TAG, (String)stringBuilder.toString());
            return null;
        }
    }

    @Override
    public SessionToken2 getSessionToken() {
        return this.mToken;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getShuffleMode() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mShuffleMode;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean isConnected() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mISession2 == null) return false;
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyBufferingStateChanged(final MediaItem2 mediaItem2, final int n, long l) {
        Object object = this.mLock;
        synchronized (object) {
            this.mBufferingState = n;
            this.mBufferedPositionMs = l;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onBufferingStateChanged(MediaController2ImplBase.this.mInstance, mediaItem2, n);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyCurrentMediaItemChanged(final MediaItem2 mediaItem2) {
        Object object = this.mLock;
        synchronized (object) {
            this.mCurrentMediaItem = mediaItem2;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onCurrentMediaItemChanged(MediaController2ImplBase.this.mInstance, mediaItem2);
            }
        });
    }

    void notifyError(final int n, final Bundle bundle) {
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onError(MediaController2ImplBase.this.mInstance, n, bundle);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyPlaybackInfoChanges(final MediaController2.PlaybackInfo playbackInfo) {
        Object object = this.mLock;
        synchronized (object) {
            this.mPlaybackInfo = playbackInfo;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onPlaybackInfoChanged(MediaController2ImplBase.this.mInstance, playbackInfo);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyPlaybackSpeedChanges(long l, long l2, final float f) {
        Object object = this.mLock;
        synchronized (object) {
            this.mPositionEventTimeMs = l;
            this.mPositionMs = l2;
            this.mPlaybackSpeed = f;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onPlaybackSpeedChanged(MediaController2ImplBase.this.mInstance, f);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyPlayerStateChanges(long l, long l2, final int n) {
        Object object = this.mLock;
        synchronized (object) {
            this.mPositionEventTimeMs = l;
            this.mPositionMs = l2;
            this.mPlayerState = n;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onPlayerStateChanged(MediaController2ImplBase.this.mInstance, n);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyPlaylistChanges(final List<MediaItem2> list, final MediaMetadata2 mediaMetadata2) {
        Object object = this.mLock;
        synchronized (object) {
            this.mPlaylist = list;
            this.mPlaylistMetadata = mediaMetadata2;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onPlaylistChanged(MediaController2ImplBase.this.mInstance, list, mediaMetadata2);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyPlaylistMetadataChanges(final MediaMetadata2 mediaMetadata2) {
        Object object = this.mLock;
        synchronized (object) {
            this.mPlaylistMetadata = mediaMetadata2;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onPlaylistMetadataChanged(MediaController2ImplBase.this.mInstance, mediaMetadata2);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyRepeatModeChanges(final int n) {
        Object object = this.mLock;
        synchronized (object) {
            this.mRepeatMode = n;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onRepeatModeChanged(MediaController2ImplBase.this.mInstance, n);
            }
        });
    }

    void notifyRoutesInfoChanged(final List<Bundle> list) {
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onRoutesInfoChanged(MediaController2ImplBase.this.mInstance, list);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifySeekCompleted(long l, long l2, final long l3) {
        Object object = this.mLock;
        synchronized (object) {
            this.mPositionEventTimeMs = l;
            this.mPositionMs = l2;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onSeekCompleted(MediaController2ImplBase.this.mInstance, l3);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void notifyShuffleModeChanges(final int n) {
        Object object = this.mLock;
        synchronized (object) {
            this.mShuffleMode = n;
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                if (!MediaController2ImplBase.this.mInstance.isConnected()) {
                    return;
                }
                MediaController2ImplBase.this.mCallback.onShuffleModeChanged(MediaController2ImplBase.this.mInstance, n);
            }
        });
    }

    void onAllowedCommandsChanged(final SessionCommandGroup2 sessionCommandGroup2) {
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                MediaController2ImplBase.this.mCallback.onAllowedCommandsChanged(MediaController2ImplBase.this.mInstance, sessionCommandGroup2);
            }
        });
    }

    /*
     * Exception decompiling
     */
    void onConnectedNotLocked(IMediaSession2 var1_1, SessionCommandGroup2 var2_13, int var3_14, MediaItem2 var4_15, long var5_16, long var7_17, float var9_18, long var10_19, MediaController2.PlaybackInfo var12_20, int var13_21, int var14_22, List<MediaItem2> var15_23, PendingIntent var16_24) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 30[MONITOR]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    void onCustomCommand(final SessionCommand2 sessionCommand2, final Bundle bundle, final ResultReceiver resultReceiver) {
        if (DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onCustomCommand cmd=");
            stringBuilder.append(sessionCommand2);
            Log.d((String)TAG, (String)stringBuilder.toString());
        }
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                MediaController2ImplBase.this.mCallback.onCustomCommand(MediaController2ImplBase.this.mInstance, sessionCommand2, bundle, resultReceiver);
            }
        });
    }

    void onCustomLayoutChanged(final List<MediaSession2.CommandButton> list) {
        this.mCallbackExecutor.execute(new Runnable(){

            @Override
            public void run() {
                MediaController2ImplBase.this.mCallback.onCustomLayoutChanged(MediaController2ImplBase.this.mInstance, list);
            }
        });
    }

    @Override
    public void pause() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(2);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.pause(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void play() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(1);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.play(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void playFromMediaId(String string2, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(22);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.playFromMediaId(this.mControllerStub, string2, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void playFromSearch(String string2, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(24);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.playFromSearch(this.mControllerStub, string2, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void playFromUri(Uri uri, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(23);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.playFromUri(this.mControllerStub, uri, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void prepare() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(6);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.prepare(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void prepareFromMediaId(String string2, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(25);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.prepareFromMediaId(this.mControllerStub, string2, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void prepareFromSearch(String string2, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(27);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.prepareFromSearch(this.mControllerStub, string2, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void prepareFromUri(Uri uri, Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(26);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.prepareFromUri(this.mControllerStub, uri, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void removePlaylistItem(MediaItem2 mediaItem2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(16);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.removePlaylistItem(this.mControllerStub, mediaItem2.toBundle());
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void replacePlaylistItem(int n, MediaItem2 mediaItem2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(17);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.replacePlaylistItem(this.mControllerStub, n, mediaItem2.toBundle());
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void reset() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(3);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.reset(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void rewind() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(8);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.rewind(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void seekTo(long l) {
        if (l >= 0L) {
            IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(9);
            if (iMediaSession2 != null) {
                try {
                    iMediaSession2.seekTo(this.mControllerStub, l);
                }
                catch (RemoteException remoteException) {
                    Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
                }
            }
            return;
        }
        throw new IllegalArgumentException("position shouldn't be negative");
    }

    @Override
    public void selectRoute(Bundle bundle) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(38);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.selectRoute(this.mControllerStub, bundle);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void sendCustomCommand(SessionCommand2 sessionCommand2, Bundle bundle, ResultReceiver resultReceiver) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(sessionCommand2);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.sendCustomCommand(this.mControllerStub, sessionCommand2.toBundle(), bundle, resultReceiver);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setPlaybackSpeed(float f) {
        Object object = this.mLock;
        synchronized (object) {
            IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(39);
            if (iMediaSession2 != null) {
                try {
                    iMediaSession2.setPlaybackSpeed(this.mControllerStub, f);
                }
                catch (RemoteException remoteException) {
                    Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setPlaylist(List<MediaItem2> object, MediaMetadata2 mediaMetadata2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(19);
        if (iMediaSession2 == null) return;
        try {
            MediaController2Stub mediaController2Stub = this.mControllerStub;
            List<Bundle> list = MediaUtils2.convertMediaItem2ListToBundleList((List<MediaItem2>)object);
            object = mediaMetadata2 == null ? null : mediaMetadata2.toBundle();
            iMediaSession2.setPlaylist(mediaController2Stub, list, (Bundle)object);
            return;
        }
        catch (RemoteException remoteException) {
            Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setRating(String string2, Rating2 rating2) {
        IMediaSession2 iMediaSession2;
        Object object = this.mLock;
        synchronized (object) {
            iMediaSession2 = this.mISession2;
        }
        if (iMediaSession2 == null) return;
        try {
            iMediaSession2.setRating(this.mControllerStub, string2, rating2.toBundle());
            return;
        }
        catch (RemoteException remoteException) {
            Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
        }
    }

    @Override
    public void setRepeatMode(int n) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(14);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.setRepeatMode(this.mControllerStub, n);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void setShuffleMode(int n) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(13);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.setShuffleMode(this.mControllerStub, n);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void setVolumeTo(int n, int n2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(10);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.setVolumeTo(this.mControllerStub, n, n2);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void skipBackward() {
    }

    @Override
    public void skipForward() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void skipToNextItem() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(4);
        Object object = this.mLock;
        synchronized (object) {
            if (iMediaSession2 != null) {
                try {
                    this.mISession2.skipToNextItem(this.mControllerStub);
                }
                catch (RemoteException remoteException) {
                    Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void skipToPlaylistItem(MediaItem2 mediaItem2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(12);
        Object object = this.mLock;
        synchronized (object) {
            if (iMediaSession2 != null) {
                try {
                    this.mISession2.skipToPlaylistItem(this.mControllerStub, mediaItem2.toBundle());
                }
                catch (RemoteException remoteException) {
                    Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void skipToPreviousItem() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(5);
        Object object = this.mLock;
        synchronized (object) {
            if (iMediaSession2 != null) {
                try {
                    iMediaSession2.skipToPreviousItem(this.mControllerStub);
                }
                catch (RemoteException remoteException) {
                    Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
                }
            }
            return;
        }
    }

    @Override
    public void subscribeRoutesInfo() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(36);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.subscribeRoutesInfo(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    @Override
    public void unsubscribeRoutesInfo() {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(37);
        if (iMediaSession2 != null) {
            try {
                iMediaSession2.unsubscribeRoutesInfo(this.mControllerStub);
            }
            catch (RemoteException remoteException) {
                Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void updatePlaylistMetadata(MediaMetadata2 mediaMetadata2) {
        IMediaSession2 iMediaSession2 = this.getSessionInterfaceIfAble(21);
        if (iMediaSession2 == null) return;
        try {
            MediaController2Stub mediaController2Stub = this.mControllerStub;
            mediaMetadata2 = mediaMetadata2 == null ? null : mediaMetadata2.toBundle();
            iMediaSession2.updatePlaylistMetadata(mediaController2Stub, (Bundle)mediaMetadata2);
            return;
        }
        catch (RemoteException remoteException) {
            Log.w((String)TAG, (String)"Cannot connect to the service or the session is gone", (Throwable)remoteException);
        }
    }

    private class SessionServiceConnection
    implements ServiceConnection {
        private SessionServiceConnection() {
        }

        public void onBindingDied(ComponentName componentName) {
            MediaController2ImplBase.this.close();
        }

        public void onServiceConnected(ComponentName componentName, IBinder object) {
            if (DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("onServiceConnected ");
                stringBuilder.append(componentName);
                stringBuilder.append(" ");
                stringBuilder.append(this);
                Log.d((String)MediaController2ImplBase.TAG, (String)stringBuilder.toString());
            }
            if (!MediaController2ImplBase.this.mToken.getPackageName().equals(componentName.getPackageName())) {
                object = new StringBuilder();
                ((StringBuilder)object).append(componentName);
                ((StringBuilder)object).append(" was connected, but expected pkg=");
                ((StringBuilder)object).append(MediaController2ImplBase.this.mToken.getPackageName());
                ((StringBuilder)object).append(" with id=");
                ((StringBuilder)object).append(MediaController2ImplBase.this.mToken.getId());
                Log.wtf((String)MediaController2ImplBase.TAG, (String)((StringBuilder)object).toString());
                return;
            }
            MediaController2ImplBase.this.connectToSession(IMediaSession2.Stub.asInterface((IBinder)object));
        }

        public void onServiceDisconnected(ComponentName componentName) {
            if (DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Session service ");
                stringBuilder.append(componentName);
                stringBuilder.append(" is disconnected.");
                Log.w((String)MediaController2ImplBase.TAG, (String)stringBuilder.toString());
            }
        }
    }
}

