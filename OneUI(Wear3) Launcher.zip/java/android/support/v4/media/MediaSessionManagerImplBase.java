/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.provider.Settings$Secure
 *  android.text.TextUtils
 *  android.util.Log
 */
package android.support.v4.media;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.support.v4.media.MediaSessionManager;
import android.support.v4.util.ObjectsCompat;
import android.text.TextUtils;
import android.util.Log;

class MediaSessionManagerImplBase
implements MediaSessionManager.MediaSessionManagerImpl {
    private static final boolean DEBUG = MediaSessionManager.DEBUG;
    private static final String ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";
    private static final String PERMISSION_MEDIA_CONTENT_CONTROL = "android.permission.MEDIA_CONTENT_CONTROL";
    private static final String PERMISSION_STATUS_BAR_SERVICE = "android.permission.STATUS_BAR_SERVICE";
    private static final String TAG = "MediaSessionManager";
    ContentResolver mContentResolver;
    Context mContext;

    MediaSessionManagerImplBase(Context context) {
        this.mContext = context;
        this.mContentResolver = context.getContentResolver();
    }

    private boolean isPermissionGranted(MediaSessionManager.RemoteUserInfoImpl remoteUserInfoImpl, String string2) {
        int n = remoteUserInfoImpl.getPid();
        boolean bl = true;
        boolean bl2 = true;
        if (n < 0) {
            if (this.mContext.getPackageManager().checkPermission(string2, remoteUserInfoImpl.getPackageName()) != 0) {
                bl2 = false;
            }
            return bl2;
        }
        bl2 = this.mContext.checkPermission(string2, remoteUserInfoImpl.getPid(), remoteUserInfoImpl.getUid()) == 0 ? bl : false;
        return bl2;
    }

    @Override
    public Context getContext() {
        return this.mContext;
    }

    boolean isEnabledNotificationListener(MediaSessionManager.RemoteUserInfoImpl remoteUserInfoImpl) {
        String string2 = Settings.Secure.getString((ContentResolver)this.mContentResolver, (String)ENABLED_NOTIFICATION_LISTENERS);
        if (string2 != null) {
            String[] stringArray = string2.split(":");
            for (int i = 0; i < stringArray.length; ++i) {
                string2 = ComponentName.unflattenFromString((String)stringArray[i]);
                if (string2 == null || !string2.getPackageName().equals(remoteUserInfoImpl.getPackageName())) continue;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isTrustedForMediaControl(MediaSessionManager.RemoteUserInfoImpl remoteUserInfoImpl) {
        boolean bl;
        block4: {
            block5: {
                Object object;
                bl = false;
                try {
                    object = this.mContext.getPackageManager().getApplicationInfo(remoteUserInfoImpl.getPackageName(), 0);
                    if (((ApplicationInfo)object).uid == remoteUserInfoImpl.getUid()) break block4;
                    if (!DEBUG) break block5;
                    object = new StringBuilder();
                    ((StringBuilder)object).append("Package name ");
                }
                catch (PackageManager.NameNotFoundException nameNotFoundException) {
                    if (DEBUG) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Package ");
                        stringBuilder.append(remoteUserInfoImpl.getPackageName());
                        stringBuilder.append(" doesn't exist");
                        Log.d((String)TAG, (String)stringBuilder.toString());
                    }
                    return false;
                }
                ((StringBuilder)object).append(remoteUserInfoImpl.getPackageName());
                ((StringBuilder)object).append(" doesn't match with the uid ");
                ((StringBuilder)object).append(remoteUserInfoImpl.getUid());
                Log.d((String)TAG, (String)((StringBuilder)object).toString());
            }
            return false;
        }
        if (this.isPermissionGranted(remoteUserInfoImpl, PERMISSION_STATUS_BAR_SERVICE) || this.isPermissionGranted(remoteUserInfoImpl, PERMISSION_MEDIA_CONTENT_CONTROL) || remoteUserInfoImpl.getUid() == 1000 || this.isEnabledNotificationListener(remoteUserInfoImpl)) {
            bl = true;
        }
        return bl;
    }

    static class RemoteUserInfo
    implements MediaSessionManager.RemoteUserInfoImpl {
        private String mPackageName;
        private int mPid;
        private int mUid;

        RemoteUserInfo(String string2, int n, int n2) {
            this.mPackageName = string2;
            this.mPid = n;
            this.mUid = n2;
        }

        public boolean equals(Object object) {
            boolean bl = object instanceof RemoteUserInfo;
            boolean bl2 = false;
            if (!bl) {
                return false;
            }
            object = (RemoteUserInfo)object;
            bl = bl2;
            if (TextUtils.equals((CharSequence)this.mPackageName, (CharSequence)((RemoteUserInfo)object).mPackageName)) {
                bl = bl2;
                if (this.mPid == ((RemoteUserInfo)object).mPid) {
                    bl = bl2;
                    if (this.mUid == ((RemoteUserInfo)object).mUid) {
                        bl = true;
                    }
                }
            }
            return bl;
        }

        @Override
        public String getPackageName() {
            return this.mPackageName;
        }

        @Override
        public int getPid() {
            return this.mPid;
        }

        @Override
        public int getUid() {
            return this.mUid;
        }

        public int hashCode() {
            return ObjectsCompat.hash(this.mPackageName, this.mPid, this.mUid);
        }
    }
}

