/*
 * Decompiled with CFR 0.151.
 */
package android.support.v4.media;

import android.support.v4.media.BaseMediaPlayer;
import android.support.v4.media.DataSourceDesc;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaPlaylistAgent;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaSession2ImplBase;
import android.support.v4.util.ArrayMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

class SessionPlaylistAgentImplBase
extends MediaPlaylistAgent {
    static final int END_OF_PLAYLIST = -1;
    static final int NO_VALID_ITEMS = -2;
    private PlayItem mCurrent;
    private MediaSession2.OnDataSourceMissingHelper mDsmHelper;
    private final PlayItem mEopPlayItem = new PlayItem(-1, null);
    private Map<MediaItem2, DataSourceDesc> mItemDsdMap;
    private final Object mLock = new Object();
    private MediaMetadata2 mMetadata;
    private BaseMediaPlayer mPlayer;
    private final MyPlayerEventCallback mPlayerCallback;
    private ArrayList<MediaItem2> mPlaylist = new ArrayList();
    private int mRepeatMode;
    private final MediaSession2ImplBase mSession;
    private int mShuffleMode;
    private ArrayList<MediaItem2> mShuffledList = new ArrayList();

    SessionPlaylistAgentImplBase(MediaSession2ImplBase mediaSession2ImplBase, BaseMediaPlayer baseMediaPlayer) {
        this.mItemDsdMap = new ArrayMap<MediaItem2, DataSourceDesc>();
        if (mediaSession2ImplBase != null) {
            if (baseMediaPlayer != null) {
                this.mSession = mediaSession2ImplBase;
                this.mPlayer = baseMediaPlayer;
                this.mPlayerCallback = new MyPlayerEventCallback();
                this.mPlayer.registerPlayerEventCallback(this.mSession.getCallbackExecutor(), this.mPlayerCallback);
                return;
            }
            throw new IllegalArgumentException("player shouldn't be null");
        }
        throw new IllegalArgumentException("sessionImpl shouldn't be null");
    }

    static /* synthetic */ PlayItem access$202(SessionPlaylistAgentImplBase sessionPlaylistAgentImplBase, PlayItem playItem) {
        sessionPlaylistAgentImplBase.mCurrent = playItem;
        return playItem;
    }

    private void applyShuffleModeLocked() {
        this.mShuffledList.clear();
        this.mShuffledList.addAll(this.mPlaylist);
        int n = this.mShuffleMode;
        if (n == 1 || n == 2) {
            Collections.shuffle(this.mShuffledList);
        }
    }

    private static int clamp(int n, int n2) {
        block1: {
            if (n < 0) {
                return 0;
            }
            if (n <= n2) break block1;
            n = n2;
        }
        return n;
    }

    private PlayItem getNextValidPlayItemLocked(int n, int n2) {
        int n3 = this.mPlaylist.size();
        int n4 = -1;
        int n5 = n;
        if (n == -1) {
            n = n2 > 0 ? n4 : n3;
            n5 = n;
        }
        n4 = 0;
        n = n5;
        n5 = n4;
        while (true) {
            Object object;
            block9: {
                block8: {
                    object = null;
                    if (n5 >= n3) break;
                    n4 = n + n2;
                    if (n4 < 0) break block8;
                    n = n4;
                    if (n4 < this.mPlaylist.size()) break block9;
                }
                if (this.mRepeatMode == 0) {
                    if (n5 != n3 - 1) {
                        object = this.mEopPlayItem;
                    }
                    return object;
                }
                n = n4 < 0 ? this.mPlaylist.size() - 1 : 0;
            }
            if ((object = this.retrieveDataSourceDescLocked(this.mShuffledList.get(n))) != null) {
                return new PlayItem(n, (DataSourceDesc)object);
            }
            ++n5;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean hasValidItem() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mCurrent == null) return false;
            return true;
        }
    }

    private DataSourceDesc retrieveDataSourceDescLocked(MediaItem2 mediaItem2) {
        Object object = mediaItem2.getDataSourceDesc();
        if (object != null) {
            this.mItemDsdMap.put(mediaItem2, (DataSourceDesc)object);
            return object;
        }
        object = this.mItemDsdMap.get(mediaItem2);
        if (object != null) {
            return object;
        }
        Object object2 = this.mDsmHelper;
        if (object2 != null) {
            object = object2 = object2.onDataSourceMissing(this.mSession.getInstance(), mediaItem2);
            if (object2 != null) {
                this.mItemDsdMap.put(mediaItem2, (DataSourceDesc)object2);
                object = object2;
            }
        }
        return object;
    }

    private void updateCurrentIfNeededLocked() {
        if (this.hasValidItem() && !this.mCurrent.isValid()) {
            int n = this.mShuffledList.indexOf(this.mCurrent.mediaItem);
            if (n >= 0) {
                this.mCurrent.shuffledIdx = n;
                return;
            }
            if (this.mCurrent.shuffledIdx >= this.mShuffledList.size()) {
                this.mCurrent = this.getNextValidPlayItemLocked(this.mShuffledList.size() - 1, 1);
            } else {
                PlayItem playItem = this.mCurrent;
                playItem.mediaItem = this.mShuffledList.get(playItem.shuffledIdx);
                if (this.retrieveDataSourceDescLocked(this.mCurrent.mediaItem) == null) {
                    this.mCurrent = this.getNextValidPlayItemLocked(this.mCurrent.shuffledIdx, 1);
                }
            }
            this.updatePlayerDataSourceLocked();
            return;
        }
    }

    private void updatePlayerDataSourceLocked() {
        Object object = this.mCurrent;
        if (object != null && object != this.mEopPlayItem) {
            if (this.mPlayer.getCurrentDataSource() != this.mCurrent.dsd) {
                this.mPlayer.setDataSource(this.mCurrent.dsd);
                object = this.mPlayer;
                int n = this.mRepeatMode;
                boolean bl = true;
                if (n != 1) {
                    bl = false;
                }
                ((BaseMediaPlayer)object).loopCurrent(bl);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void addPlaylistItem(int n, MediaItem2 mediaItem2) {
        if (mediaItem2 == null) {
            throw new IllegalArgumentException("item shouldn't be null");
        }
        Object object = this.mLock;
        synchronized (object) {
            n = SessionPlaylistAgentImplBase.clamp(n, this.mPlaylist.size());
            this.mPlaylist.add(n, mediaItem2);
            if (this.mShuffleMode == 0) {
                this.mShuffledList.add(n, mediaItem2);
            } else {
                n = (int)(Math.random() * (double)(this.mShuffledList.size() + 1));
                this.mShuffledList.add(n, mediaItem2);
            }
            if (!this.hasValidItem()) {
                this.mCurrent = this.getNextValidPlayItemLocked(-1, 1);
                this.updatePlayerDataSourceLocked();
            } else {
                this.updateCurrentIfNeededLocked();
            }
        }
        this.notifyPlaylistChanged();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void clearOnDataSourceMissingHelper() {
        Object object = this.mLock;
        synchronized (object) {
            this.mDsmHelper = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    int getCurShuffledIndex() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.hasValidItem()) return -2;
            return this.mCurrent.shuffledIdx;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaItem2 getCurrentMediaItem() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.mCurrent != null) return this.mCurrent.mediaItem;
            return null;
        }
    }

    @Override
    public MediaItem2 getMediaItem(DataSourceDesc dataSourceDesc) {
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public List<MediaItem2> getPlaylist() {
        Object object = this.mLock;
        synchronized (object) {
            return Collections.unmodifiableList(this.mPlaylist);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public MediaMetadata2 getPlaylistMetadata() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mMetadata;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getRepeatMode() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mRepeatMode;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getShuffleMode() {
        Object object = this.mLock;
        synchronized (object) {
            return this.mShuffleMode;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void removePlaylistItem(MediaItem2 mediaItem2) {
        if (mediaItem2 == null) {
            throw new IllegalArgumentException("item shouldn't be null");
        }
        Object object = this.mLock;
        synchronized (object) {
            if (!this.mPlaylist.remove(mediaItem2)) {
                return;
            }
            this.mShuffledList.remove(mediaItem2);
            this.mItemDsdMap.remove(mediaItem2);
            this.updateCurrentIfNeededLocked();
        }
        this.notifyPlaylistChanged();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void replacePlaylistItem(int n, MediaItem2 mediaItem2) {
        if (mediaItem2 == null) {
            throw new IllegalArgumentException("item shouldn't be null");
        }
        Object object = this.mLock;
        synchronized (object) {
            if (this.mPlaylist.size() <= 0) {
                return;
            }
            int n2 = SessionPlaylistAgentImplBase.clamp(n, this.mPlaylist.size() - 1);
            n = this.mShuffledList.indexOf(this.mPlaylist.get(n2));
            this.mItemDsdMap.remove(this.mShuffledList.get(n));
            this.mShuffledList.set(n, mediaItem2);
            this.mPlaylist.set(n2, mediaItem2);
            if (!this.hasValidItem()) {
                this.mCurrent = this.getNextValidPlayItemLocked(-1, 1);
                this.updatePlayerDataSourceLocked();
            } else {
                this.updateCurrentIfNeededLocked();
            }
        }
        this.notifyPlaylistChanged();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setOnDataSourceMissingHelper(MediaSession2.OnDataSourceMissingHelper onDataSourceMissingHelper) {
        Object object = this.mLock;
        synchronized (object) {
            this.mDsmHelper = onDataSourceMissingHelper;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setPlayer(BaseMediaPlayer baseMediaPlayer) {
        if (baseMediaPlayer == null) {
            throw new IllegalArgumentException("player shouldn't be null");
        }
        Object object = this.mLock;
        synchronized (object) {
            if (baseMediaPlayer == this.mPlayer) {
                return;
            }
            this.mPlayer.unregisterPlayerEventCallback(this.mPlayerCallback);
            this.mPlayer = baseMediaPlayer;
            baseMediaPlayer.registerPlayerEventCallback(this.mSession.getCallbackExecutor(), this.mPlayerCallback);
            this.updatePlayerDataSourceLocked();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setPlaylist(List<MediaItem2> list, MediaMetadata2 mediaMetadata2) {
        if (list != null) {
            Object object = this.mLock;
            synchronized (object) {
                this.mItemDsdMap.clear();
                this.mPlaylist.clear();
                this.mPlaylist.addAll(list);
                this.applyShuffleModeLocked();
                this.mMetadata = mediaMetadata2;
                this.mCurrent = this.getNextValidPlayItemLocked(-1, 1);
                this.updatePlayerDataSourceLocked();
            }
            this.notifyPlaylistChanged();
            return;
        }
        throw new IllegalArgumentException("list shouldn't be null");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setRepeatMode(int n) {
        block8: {
            if (n < 0) return;
            if (n > 3) {
                return;
            }
            Object object = this.mLock;
            synchronized (object) {
                block6: {
                    block7: {
                        if (this.mRepeatMode == n) {
                            return;
                        }
                        this.mRepeatMode = n;
                        if (n == 0) break block6;
                        if (n == 1) break block7;
                        if (n != 2 && n != 3) break block8;
                        if (this.mCurrent != this.mEopPlayItem) break block6;
                        this.mCurrent = this.getNextValidPlayItemLocked(-1, 1);
                        this.updatePlayerDataSourceLocked();
                        break block6;
                    }
                    if (this.mCurrent != null && this.mCurrent != this.mEopPlayItem) {
                        this.mPlayer.loopCurrent(true);
                    }
                    break block8;
                }
                this.mPlayer.loopCurrent(false);
            }
        }
        this.notifyRepeatModeChanged();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setShuffleMode(int n) {
        if (n < 0) return;
        if (n > 2) {
            return;
        }
        Object object = this.mLock;
        synchronized (object) {
            if (this.mShuffleMode == n) {
                return;
            }
            this.mShuffleMode = n;
            this.applyShuffleModeLocked();
            this.updateCurrentIfNeededLocked();
        }
        this.notifyShuffleModeChanged();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void skipToNextItem() {
        Object object = this.mLock;
        synchronized (object) {
            if (this.hasValidItem() && this.mCurrent != this.mEopPlayItem) {
                PlayItem playItem = this.getNextValidPlayItemLocked(this.mCurrent.shuffledIdx, 1);
                if (playItem != this.mEopPlayItem) {
                    this.mCurrent = playItem;
                }
                this.updateCurrentIfNeededLocked();
                return;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void skipToPlaylistItem(MediaItem2 object) {
        if (object == null) {
            throw new IllegalArgumentException("item shouldn't be null");
        }
        Object object2 = this.mLock;
        synchronized (object2) {
            if (this.hasValidItem() && !((MediaItem2)object).equals(this.mCurrent.mediaItem)) {
                int n = this.mShuffledList.indexOf(object);
                if (n < 0) {
                    return;
                }
                this.mCurrent = object = new PlayItem(n);
                this.updateCurrentIfNeededLocked();
                return;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void skipToPreviousItem() {
        Object object = this.mLock;
        synchronized (object) {
            if (!this.hasValidItem()) {
                return;
            }
            PlayItem playItem = this.getNextValidPlayItemLocked(this.mCurrent.shuffledIdx, -1);
            if (playItem != this.mEopPlayItem) {
                this.mCurrent = playItem;
            }
            this.updateCurrentIfNeededLocked();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void updatePlaylistMetadata(MediaMetadata2 mediaMetadata2) {
        Object object = this.mLock;
        synchronized (object) {
            if (mediaMetadata2 == this.mMetadata) {
                return;
            }
            this.mMetadata = mediaMetadata2;
        }
        this.notifyPlaylistMetadataChanged();
    }

    private class MyPlayerEventCallback
    extends BaseMediaPlayer.PlayerEventCallback {
        private MyPlayerEventCallback() {
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void onCurrentDataSourceChanged(BaseMediaPlayer baseMediaPlayer, DataSourceDesc dataSourceDesc) {
            Object object = SessionPlaylistAgentImplBase.this.mLock;
            synchronized (object) {
                if (SessionPlaylistAgentImplBase.this.mPlayer != baseMediaPlayer) {
                    return;
                }
                if (dataSourceDesc == null && SessionPlaylistAgentImplBase.this.mCurrent != null) {
                    SessionPlaylistAgentImplBase.access$202(SessionPlaylistAgentImplBase.this, SessionPlaylistAgentImplBase.this.getNextValidPlayItemLocked(((SessionPlaylistAgentImplBase)SessionPlaylistAgentImplBase.this).mCurrent.shuffledIdx, 1));
                    SessionPlaylistAgentImplBase.this.updateCurrentIfNeededLocked();
                }
                return;
            }
        }
    }

    private class PlayItem {
        public DataSourceDesc dsd;
        public MediaItem2 mediaItem;
        public int shuffledIdx;

        PlayItem(int n) {
            this(n, null);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        PlayItem(int n, DataSourceDesc object) {
            this.shuffledIdx = n;
            if (n < 0) return;
            this.mediaItem = (MediaItem2)SessionPlaylistAgentImplBase.this.mShuffledList.get(n);
            if (object == null) {
                object = SessionPlaylistAgentImplBase.this.mLock;
                synchronized (object) {
                    this.dsd = SessionPlaylistAgentImplBase.this.retrieveDataSourceDescLocked(this.mediaItem);
                    return;
                }
            }
            this.dsd = object;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        boolean isValid() {
            if (this == SessionPlaylistAgentImplBase.this.mEopPlayItem) {
                return true;
            }
            Object object = this.mediaItem;
            if (object == null) {
                return false;
            }
            if (this.dsd == null) {
                return false;
            }
            if (((MediaItem2)object).getDataSourceDesc() != null && !this.mediaItem.getDataSourceDesc().equals(this.dsd)) {
                return false;
            }
            object = SessionPlaylistAgentImplBase.this.mLock;
            synchronized (object) {
                if (this.shuffledIdx >= SessionPlaylistAgentImplBase.this.mShuffledList.size()) {
                    return false;
                }
                return this.mediaItem == SessionPlaylistAgentImplBase.this.mShuffledList.get(this.shuffledIdx);
                {
                }
            }
        }
    }
}

