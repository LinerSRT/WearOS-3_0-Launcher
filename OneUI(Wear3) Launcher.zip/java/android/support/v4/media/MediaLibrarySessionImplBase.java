/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.RemoteException
 *  android.text.TextUtils
 *  android.util.Log
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v4.media.BaseMediaPlayer;
import android.support.v4.media.MediaBrowserServiceCompat;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaLibraryService2;
import android.support.v4.media.MediaLibraryService2LegacyStub;
import android.support.v4.media.MediaPlaylistAgent;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaSession2ImplBase;
import android.support.v4.media.VolumeProviderCompat;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.Log;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

class MediaLibrarySessionImplBase
extends MediaSession2ImplBase
implements MediaLibraryService2.MediaLibrarySession.SupportLibraryImpl {
    private final MediaBrowserServiceCompat mBrowserServiceLegacyStub;
    private final ArrayMap<MediaSession2.ControllerInfo, Set<String>> mSubscriptions = new ArrayMap();

    MediaLibrarySessionImplBase(MediaLibraryService2.MediaLibrarySession object, Context context, String string2, BaseMediaPlayer baseMediaPlayer, MediaPlaylistAgent mediaPlaylistAgent, VolumeProviderCompat volumeProviderCompat, PendingIntent pendingIntent, Executor executor, MediaSession2.SessionCallback sessionCallback) {
        super((MediaSession2)object, context, string2, baseMediaPlayer, mediaPlaylistAgent, volumeProviderCompat, pendingIntent, executor, sessionCallback);
        object = new MediaLibraryService2LegacyStub(this);
        this.mBrowserServiceLegacyStub = object;
        ((MediaBrowserServiceCompat)((Object)object)).attachToBaseContext(context);
        this.mBrowserServiceLegacyStub.onCreate();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void dumpSubscription() {
        if (!DEBUG) {
            return;
        }
        Object object = this.mLock;
        synchronized (object) {
            CharSequence charSequence2 = new StringBuilder();
            charSequence2.append("Dumping subscription, controller sz=");
            charSequence2.append(this.mSubscriptions.size());
            Log.d((String)"MS2ImplBase", (String)charSequence2.toString());
            int n = 0;
            while (n < this.mSubscriptions.size()) {
                charSequence2 = new StringBuilder();
                charSequence2.append("  controller ");
                charSequence2.append(this.mSubscriptions.valueAt(n));
                Log.d((String)"MS2ImplBase", (String)charSequence2.toString());
                for (CharSequence charSequence2 : (Set)this.mSubscriptions.valueAt(n)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("  - ");
                    stringBuilder.append((String)charSequence2);
                    Log.d((String)"MS2ImplBase", (String)stringBuilder.toString());
                }
                ++n;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean isSubscribed(MediaSession2.ControllerInfo object, String string2) {
        Object object2 = this.mLock;
        synchronized (object2) {
            object = (Set)this.mSubscriptions.get(object);
            return object != null && object.contains(string2);
            {
            }
        }
    }

    @Override
    public MediaLibraryService2.MediaLibrarySession.MediaLibrarySessionCallback getCallback() {
        return (MediaLibraryService2.MediaLibrarySession.MediaLibrarySessionCallback)super.getCallback();
    }

    @Override
    public MediaLibraryService2.MediaLibrarySession getInstance() {
        return (MediaLibraryService2.MediaLibrarySession)super.getInstance();
    }

    @Override
    public IBinder getLegacySessionBinder() {
        Intent intent = new Intent("android.media.browse.MediaBrowserService");
        return this.mBrowserServiceLegacyStub.onBind(intent);
    }

    @Override
    public void notifyChildrenChanged(final MediaSession2.ControllerInfo controllerInfo, final String string2, final int n, final Bundle bundle) {
        if (controllerInfo != null) {
            if (!TextUtils.isEmpty((CharSequence)string2)) {
                if (n >= 0) {
                    this.notifyToController(controllerInfo, new MediaSession2ImplBase.NotifyRunnable(){

                        @Override
                        public void run(MediaSession2.ControllerCb object) throws RemoteException {
                            if (!MediaLibrarySessionImplBase.this.isSubscribed(controllerInfo, string2)) {
                                if (MediaSession2ImplBase.DEBUG) {
                                    object = new StringBuilder();
                                    ((StringBuilder)object).append("Skipping notifyChildrenChanged() to ");
                                    ((StringBuilder)object).append(controllerInfo);
                                    ((StringBuilder)object).append(" because it hasn't subscribed");
                                    Log.d((String)"MS2ImplBase", (String)((StringBuilder)object).toString());
                                    MediaLibrarySessionImplBase.this.dumpSubscription();
                                }
                                return;
                            }
                            ((MediaSession2.ControllerCb)object).onChildrenChanged(string2, n, bundle);
                        }
                    });
                    return;
                }
                throw new IllegalArgumentException("itemCount shouldn't be negative");
            }
            throw new IllegalArgumentException("query shouldn't be empty");
        }
        throw new IllegalArgumentException("controller shouldn't be null");
    }

    @Override
    public void notifyChildrenChanged(final String string2, final int n, Bundle object) {
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            if (n >= 0) {
                List<MediaSession2.ControllerInfo> list = this.getConnectedControllers();
                object = new MediaSession2ImplBase.NotifyRunnable((Bundle)object){
                    final /* synthetic */ Bundle val$extras;
                    {
                        this.val$extras = bundle;
                    }

                    @Override
                    public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                        controllerCb.onChildrenChanged(string2, n, this.val$extras);
                    }
                };
                for (n = 0; n < list.size(); ++n) {
                    if (!this.isSubscribed(list.get(n), string2)) continue;
                    this.notifyToController(list.get(n), (MediaSession2ImplBase.NotifyRunnable)object);
                }
                return;
            }
            throw new IllegalArgumentException("itemCount shouldn't be negative");
        }
        throw new IllegalArgumentException("query shouldn't be empty");
    }

    @Override
    public void notifySearchResultChanged(MediaSession2.ControllerInfo controllerInfo, final String string2, final int n, final Bundle bundle) {
        if (controllerInfo != null) {
            if (!TextUtils.isEmpty((CharSequence)string2)) {
                this.notifyToController(controllerInfo, new MediaSession2ImplBase.NotifyRunnable(){

                    @Override
                    public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                        controllerCb.onSearchResultChanged(string2, n, bundle);
                    }
                });
                return;
            }
            throw new IllegalArgumentException("query shouldn't be empty");
        }
        throw new IllegalArgumentException("controller shouldn't be null");
    }

    @Override
    public void onGetChildrenOnExecutor(MediaSession2.ControllerInfo object, final String string2, final int n, final int n2, final Bundle bundle) {
        final List<MediaItem2> list = this.getCallback().onGetChildren(this.getInstance(), (MediaSession2.ControllerInfo)object, string2, n, n2, bundle);
        if (list != null && list.size() > n2) {
            object = new StringBuilder();
            ((StringBuilder)object).append("onGetChildren() shouldn't return media items more than pageSize. result.size()=");
            ((StringBuilder)object).append(list.size());
            ((StringBuilder)object).append(" pageSize=");
            ((StringBuilder)object).append(n2);
            throw new IllegalArgumentException(((StringBuilder)object).toString());
        }
        this.notifyToController((MediaSession2.ControllerInfo)object, new MediaSession2ImplBase.NotifyRunnable(){

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onGetChildrenDone(string2, n, n2, list, bundle);
            }
        });
    }

    @Override
    public void onGetItemOnExecutor(MediaSession2.ControllerInfo controllerInfo, final String string2) {
        this.notifyToController(controllerInfo, new MediaSession2ImplBase.NotifyRunnable(this.getCallback().onGetItem(this.getInstance(), controllerInfo, string2)){
            final /* synthetic */ MediaItem2 val$result;
            {
                this.val$result = mediaItem2;
            }

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onGetItemDone(string2, this.val$result);
            }
        });
    }

    @Override
    public void onGetLibraryRootOnExecutor(MediaSession2.ControllerInfo controllerInfo, final Bundle bundle) {
        this.notifyToController(controllerInfo, new MediaSession2ImplBase.NotifyRunnable(this.getCallback().onGetLibraryRoot(this.getInstance(), controllerInfo, bundle)){
            final /* synthetic */ MediaLibraryService2.LibraryRoot val$root;
            {
                this.val$root = libraryRoot;
            }

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                Bundle bundle3 = bundle;
                Object object = this.val$root;
                Bundle bundle2 = null;
                object = object == null ? null : ((MediaLibraryService2.LibraryRoot)object).getRootId();
                MediaLibraryService2.LibraryRoot libraryRoot = this.val$root;
                if (libraryRoot != null) {
                    bundle2 = libraryRoot.getExtras();
                }
                controllerCb.onGetLibraryRootDone(bundle3, (String)object, bundle2);
            }
        });
    }

    @Override
    public void onGetSearchResultOnExecutor(MediaSession2.ControllerInfo object, final String string2, final int n, final int n2, final Bundle bundle) {
        final List<MediaItem2> list = this.getCallback().onGetSearchResult(this.getInstance(), (MediaSession2.ControllerInfo)object, string2, n, n2, bundle);
        if (list != null && list.size() > n2) {
            object = new StringBuilder();
            ((StringBuilder)object).append("onGetSearchResult() shouldn't return media items more than pageSize. result.size()=");
            ((StringBuilder)object).append(list.size());
            ((StringBuilder)object).append(" pageSize=");
            ((StringBuilder)object).append(n2);
            throw new IllegalArgumentException(((StringBuilder)object).toString());
        }
        this.notifyToController((MediaSession2.ControllerInfo)object, new MediaSession2ImplBase.NotifyRunnable(){

            @Override
            public void run(MediaSession2.ControllerCb controllerCb) throws RemoteException {
                controllerCb.onGetSearchResultDone(string2, n, n2, list, bundle);
            }
        });
    }

    @Override
    public void onSearchOnExecutor(MediaSession2.ControllerInfo controllerInfo, String string2, Bundle bundle) {
        this.getCallback().onSearch(this.getInstance(), controllerInfo, string2, bundle);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onSubscribeOnExecutor(MediaSession2.ControllerInfo controllerInfo, String string2, Bundle bundle) {
        Object object = this.mLock;
        synchronized (object) {
            HashSet<String> hashSet;
            HashSet<String> hashSet2 = hashSet = (HashSet<String>)this.mSubscriptions.get(controllerInfo);
            if (hashSet == null) {
                hashSet2 = new HashSet<String>();
                this.mSubscriptions.put(controllerInfo, hashSet2);
            }
            hashSet2.add(string2);
        }
        this.getCallback().onSubscribe(this.getInstance(), controllerInfo, string2, bundle);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onUnsubscribeOnExecutor(MediaSession2.ControllerInfo controllerInfo, String object) {
        this.getCallback().onUnsubscribe(this.getInstance(), controllerInfo, (String)object);
        object = this.mLock;
        synchronized (object) {
            this.mSubscriptions.remove(controllerInfo);
            return;
        }
    }
}

