/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Service
 *  android.content.Intent
 *  android.os.IBinder
 */
package android.support.v4.media;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaSessionService2ImplBase;

public abstract class MediaSessionService2
extends Service {
    public static final String SERVICE_INTERFACE = "android.media.MediaSessionService2";
    public static final String SERVICE_META_DATA = "android.media.session";
    private final SupportLibraryImpl mImpl = this.createImpl();

    SupportLibraryImpl createImpl() {
        return new MediaSessionService2ImplBase();
    }

    public final MediaSession2 getSession() {
        return this.mImpl.getSession();
    }

    public IBinder onBind(Intent intent) {
        return this.mImpl.onBind(intent);
    }

    public void onCreate() {
        super.onCreate();
        this.mImpl.onCreate(this);
    }

    public abstract MediaSession2 onCreateSession(String var1);

    public MediaNotification onUpdateNotification() {
        return this.mImpl.onUpdateNotification();
    }

    public static class MediaNotification {
        private final Notification mNotification;
        private final int mNotificationId;

        public MediaNotification(int n, Notification notification) {
            if (notification != null) {
                this.mNotificationId = n;
                this.mNotification = notification;
                return;
            }
            throw new IllegalArgumentException("notification shouldn't be null");
        }

        public Notification getNotification() {
            return this.mNotification;
        }

        public int getNotificationId() {
            return this.mNotificationId;
        }
    }

    static interface SupportLibraryImpl {
        public MediaSession2 getSession();

        public int getSessionType();

        public IBinder onBind(Intent var1);

        public void onCreate(MediaSessionService2 var1);

        public MediaNotification onUpdateNotification();
    }
}

