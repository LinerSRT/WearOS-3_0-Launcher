/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.media.session.MediaSessionManager
 *  android.media.session.MediaSessionManager$RemoteUserInfo
 */
package android.support.v4.media;

import android.content.Context;
import android.media.session.MediaSessionManager;
import android.support.v4.media.MediaSessionManager;
import android.support.v4.media.MediaSessionManagerImplApi21;

class MediaSessionManagerImplApi28
extends MediaSessionManagerImplApi21 {
    MediaSessionManager mObject;

    MediaSessionManagerImplApi28(Context context) {
        super(context);
        this.mObject = (MediaSessionManager)context.getSystemService("media_session");
    }

    @Override
    public boolean isTrustedForMediaControl(MediaSessionManager.RemoteUserInfoImpl remoteUserInfoImpl) {
        if (remoteUserInfoImpl instanceof RemoteUserInfo) {
            return this.mObject.isTrustedForMediaControl(((RemoteUserInfo)remoteUserInfoImpl).mObject);
        }
        return false;
    }

    static final class RemoteUserInfo
    implements MediaSessionManager.RemoteUserInfoImpl {
        MediaSessionManager.RemoteUserInfo mObject;

        RemoteUserInfo(String string2, int n, int n2) {
            this.mObject = new MediaSessionManager.RemoteUserInfo(string2, n, n2);
        }

        @Override
        public String getPackageName() {
            return this.mObject.getPackageName();
        }

        @Override
        public int getPid() {
            return this.mObject.getPid();
        }

        @Override
        public int getUid() {
            return this.mObject.getUid();
        }
    }
}

