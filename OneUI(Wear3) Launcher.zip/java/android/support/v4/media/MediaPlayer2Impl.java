/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.media.AudioAttributes
 *  android.media.DeniedByServerException
 *  android.media.MediaDataSource
 *  android.media.MediaDrm$KeyRequest
 *  android.media.MediaFormat
 *  android.media.MediaPlayer
 *  android.media.MediaPlayer$DrmInfo
 *  android.media.MediaPlayer$NoDrmSchemeException
 *  android.media.MediaPlayer$OnBufferingUpdateListener
 *  android.media.MediaPlayer$OnCompletionListener
 *  android.media.MediaPlayer$OnDrmConfigHelper
 *  android.media.MediaPlayer$OnDrmInfoListener
 *  android.media.MediaPlayer$OnDrmPreparedListener
 *  android.media.MediaPlayer$OnErrorListener
 *  android.media.MediaPlayer$OnInfoListener
 *  android.media.MediaPlayer$OnMediaTimeDiscontinuityListener
 *  android.media.MediaPlayer$OnPreparedListener
 *  android.media.MediaPlayer$OnSeekCompleteListener
 *  android.media.MediaPlayer$OnSubtitleDataListener
 *  android.media.MediaPlayer$OnTimedMetaDataAvailableListener
 *  android.media.MediaPlayer$OnVideoSizeChangedListener
 *  android.media.MediaPlayer$ProvisioningNetworkErrorException
 *  android.media.MediaPlayer$ProvisioningServerErrorException
 *  android.media.MediaPlayer$TrackInfo
 *  android.media.MediaTimestamp
 *  android.media.PlaybackParams
 *  android.media.ResourceBusyException
 *  android.media.SubtitleData
 *  android.media.SyncParams
 *  android.media.TimedMetaData
 *  android.media.UnsupportedSchemeException
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.os.Parcel
 *  android.os.PersistableBundle
 *  android.util.Log
 *  android.util.Pair
 *  android.view.Surface
 */
package android.support.v4.media;

import android.media.AudioAttributes;
import android.media.DeniedByServerException;
import android.media.MediaDataSource;
import android.media.MediaDrm;
import android.media.MediaFormat;
import android.media.MediaPlayer;
import android.media.MediaTimestamp;
import android.media.PlaybackParams;
import android.media.ResourceBusyException;
import android.media.SubtitleData;
import android.media.SyncParams;
import android.media.TimedMetaData;
import android.media.UnsupportedSchemeException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Parcel;
import android.os.PersistableBundle;
import android.support.v4.media.AudioAttributesCompat;
import android.support.v4.media.BaseMediaPlayer;
import android.support.v4.media.DataSourceDesc;
import android.support.v4.media.Media2DataSource;
import android.support.v4.media.MediaPlayer2;
import android.support.v4.media.MediaTimestamp2;
import android.support.v4.media.PlaybackParams2;
import android.support.v4.media.SubtitleData2;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.Preconditions;
import android.support.v4.util.SimpleArrayMap;
import android.util.Log;
import android.util.Pair;
import android.view.Surface;
import java.io.IOException;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

public final class MediaPlayer2Impl
extends MediaPlayer2 {
    private static final int SOURCE_STATE_ERROR = -1;
    private static final int SOURCE_STATE_INIT = 0;
    private static final int SOURCE_STATE_PREPARED = 2;
    private static final int SOURCE_STATE_PREPARING = 1;
    private static final String TAG = "MediaPlayer2Impl";
    private static ArrayMap<Integer, Integer> sErrorEventMap;
    private static ArrayMap<Integer, Integer> sInfoEventMap;
    private static ArrayMap<Integer, Integer> sPrepareDrmStatusMap;
    private static ArrayMap<Integer, Integer> sStateMap;
    private BaseMediaPlayerImpl mBaseMediaPlayerImpl;
    private Task mCurrentTask;
    private Pair<Executor, MediaPlayer2.DrmEventCallback> mDrmEventCallbackRecord;
    private final Handler mEndPositionHandler;
    private HandlerThread mHandlerThread;
    private final Object mLock;
    private Pair<Executor, MediaPlayer2.EventCallback> mMp2EventCallbackRecord;
    private final ArrayDeque<Task> mPendingTasks;
    private MediaPlayerSourceQueue mPlayer;
    private ArrayMap<BaseMediaPlayer.PlayerEventCallback, Executor> mPlayerEventCallbackMap;
    private final Handler mTaskHandler;
    private final Object mTaskLock = new Object();

    static {
        Object object = new ArrayMap<Integer, Integer>();
        sInfoEventMap = object;
        Integer n = 1;
        ((SimpleArrayMap)object).put(n, n);
        Object object2 = sInfoEventMap;
        object = 2;
        ((SimpleArrayMap)object2).put((Integer)object, (Integer)object);
        Object object3 = sInfoEventMap;
        object2 = 3;
        ((SimpleArrayMap)object3).put((Integer)object2, (Integer)object2);
        ArrayMap<Integer, Integer> arrayMap = sInfoEventMap;
        object3 = 700;
        arrayMap.put((Integer)object3, (Integer)object3);
        object3 = sInfoEventMap;
        arrayMap = 701;
        ((SimpleArrayMap)object3).put((Integer)((Object)arrayMap), (Integer)((Object)arrayMap));
        object3 = sInfoEventMap;
        arrayMap = 702;
        ((SimpleArrayMap)object3).put((Integer)((Object)arrayMap), (Integer)((Object)arrayMap));
        object3 = sInfoEventMap;
        arrayMap = 800;
        ((SimpleArrayMap)object3).put((Integer)((Object)arrayMap), (Integer)((Object)arrayMap));
        arrayMap = sInfoEventMap;
        object3 = 801;
        arrayMap.put((Integer)object3, (Integer)object3);
        object3 = sInfoEventMap;
        arrayMap = 802;
        ((SimpleArrayMap)object3).put((Integer)((Object)arrayMap), (Integer)((Object)arrayMap));
        arrayMap = sInfoEventMap;
        object3 = 804;
        arrayMap.put((Integer)object3, (Integer)object3);
        arrayMap = sInfoEventMap;
        object3 = 805;
        arrayMap.put((Integer)object3, (Integer)object3);
        arrayMap = sInfoEventMap;
        object3 = 901;
        arrayMap.put((Integer)object3, (Integer)object3);
        arrayMap = sInfoEventMap;
        object3 = 902;
        arrayMap.put((Integer)object3, (Integer)object3);
        object3 = new ArrayMap<Integer, Integer>();
        sErrorEventMap = object3;
        ((SimpleArrayMap)object3).put(n, n);
        arrayMap = sErrorEventMap;
        object3 = 200;
        arrayMap.put((Integer)object3, (Integer)object3);
        sErrorEventMap.put(-1004, -1004);
        sErrorEventMap.put(-1007, -1007);
        sErrorEventMap.put(-1010, -1010);
        sErrorEventMap.put(-110, -110);
        arrayMap = new ArrayMap();
        sPrepareDrmStatusMap = arrayMap;
        object3 = 0;
        arrayMap.put((Integer)object3, (Integer)object3);
        arrayMap = sPrepareDrmStatusMap;
        arrayMap.put(n, n);
        arrayMap = sPrepareDrmStatusMap;
        arrayMap.put((Integer)object, (Integer)object);
        arrayMap = sPrepareDrmStatusMap;
        arrayMap.put((Integer)object, (Integer)object);
        arrayMap = new ArrayMap();
        sStateMap = arrayMap;
        arrayMap.put(1001, (Integer)object3);
        sStateMap.put(1002, n);
        sStateMap.put(1003, n);
        sStateMap.put(1004, (Integer)object);
        sStateMap.put(1005, (Integer)object2);
    }

    public MediaPlayer2Impl() {
        HandlerThread handlerThread;
        this.mPendingTasks = new ArrayDeque();
        this.mLock = new Object();
        this.mPlayerEventCallbackMap = new ArrayMap();
        this.mHandlerThread = handlerThread = new HandlerThread("MediaPlayer2TaskThread");
        handlerThread.start();
        handlerThread = this.mHandlerThread.getLooper();
        this.mEndPositionHandler = new Handler((Looper)handlerThread);
        this.mTaskHandler = new Handler((Looper)handlerThread);
        this.mPlayer = new MediaPlayerSourceQueue();
    }

    static /* synthetic */ Task access$902(MediaPlayer2Impl mediaPlayer2Impl, Task task) {
        mediaPlayer2Impl.mCurrentTask = task;
        return task;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void addTask(Task task) {
        Object object = this.mTaskLock;
        synchronized (object) {
            this.mPendingTasks.add(task);
            this.processPendingTask_l();
            return;
        }
    }

    private int getBufferingState() {
        return this.mPlayer.getBufferingState();
    }

    private int getPlayerState() {
        return this.mPlayer.getPlayerState();
    }

    private static void handleDataSource(MediaPlayerSource mediaPlayerSource) throws IOException {
        final DataSourceDesc dataSourceDesc = mediaPlayerSource.getDSD();
        Preconditions.checkNotNull(dataSourceDesc, "the DataSourceDesc cannot be null");
        mediaPlayerSource = mediaPlayerSource.mPlayer;
        int n = dataSourceDesc.getType();
        if (n != 1) {
            if (n != 2) {
                if (n == 3) {
                    mediaPlayerSource.setDataSource(dataSourceDesc.getUriContext(), dataSourceDesc.getUri(), dataSourceDesc.getUriHeaders(), dataSourceDesc.getUriCookies());
                }
            } else {
                mediaPlayerSource.setDataSource(dataSourceDesc.getFileDescriptor(), dataSourceDesc.getFileDescriptorOffset(), dataSourceDesc.getFileDescriptorLength());
            }
        } else {
            mediaPlayerSource.setDataSource(new MediaDataSource(){
                Media2DataSource mDataSource;
                {
                    this.mDataSource = dataSourceDesc.getMedia2DataSource();
                }

                public void close() throws IOException {
                    this.mDataSource.close();
                }

                public long getSize() throws IOException {
                    return this.mDataSource.getSize();
                }

                public int readAt(long l, byte[] byArray, int n, int n2) throws IOException {
                    return this.mDataSource.readAt(l, byArray, n, n2);
                }
            });
        }
    }

    private void handleDataSourceError(final DataSourceError dataSourceError) {
        if (dataSourceError == null) {
            return;
        }
        this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

            @Override
            public void notify(MediaPlayer2.EventCallback eventCallback) {
                eventCallback.onError(MediaPlayer2Impl.this, dataSourceError.mDSD, dataSourceError.mWhat, dataSourceError.mExtra);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void notifyDrmEvent(final DrmEventNotifier drmEventNotifier) {
        Object object = this.mLock;
        // MONITORENTER : object
        final Pair<Executor, MediaPlayer2.DrmEventCallback> pair = this.mDrmEventCallbackRecord;
        // MONITOREXIT : object
        if (pair == null) return;
        ((Executor)pair.first).execute(new Runnable(){

            @Override
            public void run() {
                drmEventNotifier.notify((MediaPlayer2.DrmEventCallback)pair.second);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void notifyMediaPlayer2Event(final Mp2EventNotifier mp2EventNotifier) {
        Object object = this.mLock;
        // MONITORENTER : object
        final Pair<Executor, MediaPlayer2.EventCallback> pair = this.mMp2EventCallbackRecord;
        // MONITOREXIT : object
        if (pair == null) return;
        ((Executor)pair.first).execute(new Runnable(){

            @Override
            public void run() {
                mp2EventNotifier.notify((MediaPlayer2.EventCallback)pair.second);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void notifyPlayerEvent(final PlayerEventNotifier playerEventNotifier) {
        ArrayMap arrayMap;
        Object object = this.mLock;
        synchronized (object) {
            arrayMap = new ArrayMap((SimpleArrayMap)this.mPlayerEventCallbackMap);
        }
        int n = arrayMap.size();
        int n2 = 0;
        while (n2 < n) {
            ((Executor)arrayMap.valueAt(n2)).execute(new Runnable((BaseMediaPlayer.PlayerEventCallback)arrayMap.keyAt(n2)){
                final /* synthetic */ BaseMediaPlayer.PlayerEventCallback val$cb;
                {
                    this.val$cb = playerEventCallback;
                }

                @Override
                public void run() {
                    playerEventNotifier.notify(this.val$cb);
                }
            });
            ++n2;
        }
        return;
    }

    private void processPendingTask_l() {
        if (this.mCurrentTask != null) {
            return;
        }
        if (!this.mPendingTasks.isEmpty()) {
            Task task;
            this.mCurrentTask = task = this.mPendingTasks.removeFirst();
            this.mTaskHandler.post((Runnable)task);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void registerPlayerEventCallback(Executor executor, BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
        if (playerEventCallback == null) {
            throw new IllegalArgumentException("Illegal null PlayerEventCallback");
        }
        if (executor != null) {
            Object object = this.mLock;
            synchronized (object) {
                this.mPlayerEventCallbackMap.put(playerEventCallback, executor);
                return;
            }
        }
        throw new IllegalArgumentException("Illegal null Executor for the PlayerEventCallback");
    }

    private void setEndPositionTimerIfNeeded(MediaPlayer.OnCompletionListener object, final MediaPlayerSource mediaPlayerSource, MediaTimestamp mediaTimestamp) {
        block2: {
            if (mediaPlayerSource != this.mPlayer.getFirst()) break block2;
            this.mEndPositionHandler.removeCallbacksAndMessages(null);
            DataSourceDesc dataSourceDesc = mediaPlayerSource.getDSD();
            if (dataSourceDesc.getEndPosition() != 0x7FFFFFFFFFFFFFFL && mediaTimestamp.getMediaClockRate() > 0.0f) {
                long l = (System.nanoTime() - mediaTimestamp.getAnchorSytemNanoTime()) / 1000L;
                l = (mediaTimestamp.getAnchorMediaTimeUs() + l) / 1000L;
                l = (long)((float)(dataSourceDesc.getEndPosition() - l) / mediaTimestamp.getMediaClockRate());
                mediaTimestamp = this.mEndPositionHandler;
                object = new Runnable((MediaPlayer.OnCompletionListener)object){
                    final /* synthetic */ MediaPlayer.OnCompletionListener val$completionListener;
                    {
                        this.val$completionListener = onCompletionListener;
                    }

                    @Override
                    public void run() {
                        if (MediaPlayer2Impl.this.mPlayer.getFirst() != mediaPlayerSource) {
                            return;
                        }
                        MediaPlayer2Impl.this.mPlayer.pause();
                        this.val$completionListener.onCompletion(mediaPlayerSource.mPlayer);
                    }
                };
                long l2 = 0L;
                if (l < 0L) {
                    l = l2;
                }
                mediaTimestamp.postDelayed((Runnable)object, l);
            }
        }
    }

    private void setPlaybackParamsInternal(final PlaybackParams playbackParams) {
        PlaybackParams playbackParams2 = this.mPlayer.getPlaybackParams();
        this.mPlayer.setPlaybackParams(playbackParams);
        if (playbackParams2.getSpeed() != playbackParams.getSpeed()) {
            this.notifyPlayerEvent(new PlayerEventNotifier(){

                @Override
                public void notify(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
                    playerEventCallback.onPlaybackSpeedChanged(MediaPlayer2Impl.this.mBaseMediaPlayerImpl, playbackParams.getSpeed());
                }
            });
        }
    }

    private void setUpListeners(final MediaPlayerSource mediaPlayerSource) {
        MediaPlayer mediaPlayer = mediaPlayerSource.mPlayer;
        final MediaPlayer.OnPreparedListener onPreparedListener = new MediaPlayer.OnPreparedListener(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onPrepared(MediaPlayer object) {
                MediaPlayer2Impl mediaPlayer2Impl = MediaPlayer2Impl.this;
                mediaPlayer2Impl.handleDataSourceError(mediaPlayer2Impl.mPlayer.onPrepared((MediaPlayer)object));
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        eventCallback.onInfo(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), 100, 0);
                    }
                });
                MediaPlayer2Impl.this.notifyPlayerEvent(new PlayerEventNotifier(){

                    @Override
                    public void notify(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
                        playerEventCallback.onMediaPrepared(MediaPlayer2Impl.this.mBaseMediaPlayerImpl, mediaPlayerSource.getDSD());
                    }
                });
                object = MediaPlayer2Impl.this.mTaskLock;
                synchronized (object) {
                    if (MediaPlayer2Impl.this.mCurrentTask != null && MediaPlayer2Impl.this.mCurrentTask.mMediaCallType == 6 && MediaPlayer2Impl.this.mCurrentTask.mDSD == mediaPlayerSource.getDSD() && MediaPlayer2Impl.this.mCurrentTask.mNeedToWaitForEventToComplete) {
                        MediaPlayer2Impl.this.mCurrentTask.sendCompleteNotification(0);
                        MediaPlayer2Impl.access$902(MediaPlayer2Impl.this, null);
                        MediaPlayer2Impl.this.processPendingTask_l();
                    }
                    return;
                }
            }
        };
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){

            public void onPrepared(MediaPlayer mediaPlayer) {
                if (mediaPlayerSource.getDSD().getStartPosition() != 0L) {
                    mediaPlayerSource.mPlayer.seekTo((long)((int)mediaPlayerSource.getDSD().getStartPosition()), 3);
                } else {
                    onPreparedListener.onPrepared(mediaPlayer);
                }
            }
        });
        mediaPlayer.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener(){

            public void onVideoSizeChanged(MediaPlayer mediaPlayer, final int n, final int n2) {
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        eventCallback.onVideoSizeChanged(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), n, n2);
                    }
                });
            }
        });
        mediaPlayer.setOnInfoListener(new MediaPlayer.OnInfoListener(){

            public boolean onInfo(MediaPlayer mediaPlayer, int n, int n2) {
                if (n != 3) {
                    if (n != 701) {
                        if (n == 702) {
                            MediaPlayer2Impl.this.mPlayer.setBufferingState(mediaPlayer, 1);
                        }
                    } else {
                        MediaPlayer2Impl.this.mPlayer.setBufferingState(mediaPlayer, 2);
                    }
                } else {
                    MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                        @Override
                        public void notify(MediaPlayer2.EventCallback eventCallback) {
                            eventCallback.onInfo(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), 3, 0);
                        }
                    });
                }
                return false;
            }
        });
        final MediaPlayer.OnCompletionListener onCompletionListener = new MediaPlayer.OnCompletionListener(){

            public void onCompletion(MediaPlayer mediaPlayer) {
                MediaPlayer2Impl mediaPlayer2Impl = MediaPlayer2Impl.this;
                mediaPlayer2Impl.handleDataSourceError(mediaPlayer2Impl.mPlayer.onCompletion(mediaPlayer));
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        eventCallback.onInfo(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), 5, 0);
                    }
                });
            }
        };
        mediaPlayer.setOnCompletionListener(onCompletionListener);
        mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public boolean onError(MediaPlayer mediaPlayer, final int n, final int n2) {
                MediaPlayer2Impl.this.mPlayer.onError(mediaPlayer);
                Object object = MediaPlayer2Impl.this.mTaskLock;
                synchronized (object) {
                    if (MediaPlayer2Impl.this.mCurrentTask != null && MediaPlayer2Impl.this.mCurrentTask.mNeedToWaitForEventToComplete) {
                        MediaPlayer2Impl.this.mCurrentTask.sendCompleteNotification(Integer.MIN_VALUE);
                        MediaPlayer2Impl.access$902(MediaPlayer2Impl.this, null);
                        MediaPlayer2Impl.this.processPendingTask_l();
                    }
                }
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        int n3 = sErrorEventMap.getOrDefault(n, 1);
                        eventCallback.onError(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), n3, n2);
                    }
                });
                return true;
            }
        });
        mediaPlayer.setOnSeekCompleteListener(new MediaPlayer.OnSeekCompleteListener(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onSeekComplete(MediaPlayer mediaPlayer) {
                if (mediaPlayerSource.mMp2State == 1001 && mediaPlayerSource.getDSD().getStartPosition() != 0L) {
                    onPreparedListener.onPrepared(mediaPlayer);
                    return;
                }
                Object object = MediaPlayer2Impl.this.mTaskLock;
                synchronized (object) {
                    if (MediaPlayer2Impl.this.mCurrentTask != null && MediaPlayer2Impl.this.mCurrentTask.mMediaCallType == 14 && MediaPlayer2Impl.this.mCurrentTask.mNeedToWaitForEventToComplete) {
                        MediaPlayer2Impl.this.mCurrentTask.sendCompleteNotification(0);
                        MediaPlayer2Impl.access$902(MediaPlayer2Impl.this, null);
                        MediaPlayer2Impl.this.processPendingTask_l();
                    }
                }
                final long l = MediaPlayer2Impl.this.getCurrentPosition();
                MediaPlayer2Impl.this.notifyPlayerEvent(new PlayerEventNotifier(){

                    @Override
                    public void notify(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
                        playerEventCallback.onSeekCompleted(MediaPlayer2Impl.this.mBaseMediaPlayerImpl, l);
                    }
                });
            }
        });
        mediaPlayer.setOnTimedMetaDataAvailableListener(new MediaPlayer.OnTimedMetaDataAvailableListener(){

            public void onTimedMetaDataAvailable(MediaPlayer mediaPlayer, final TimedMetaData timedMetaData) {
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        eventCallback.onTimedMetaDataAvailable(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), timedMetaData);
                    }
                });
            }
        });
        mediaPlayer.setOnInfoListener(new MediaPlayer.OnInfoListener(){

            public boolean onInfo(MediaPlayer mediaPlayer, final int n, final int n2) {
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        int n3 = sInfoEventMap.getOrDefault(n, 1);
                        eventCallback.onInfo(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), n3, n2);
                    }
                });
                return true;
            }
        });
        mediaPlayer.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener(){

            public void onBufferingUpdate(MediaPlayer mediaPlayer, final int n) {
                if (n >= 100) {
                    MediaPlayer2Impl.this.mPlayer.setBufferingState(mediaPlayer, 3);
                }
                mediaPlayerSource.mBufferedPercentage.set(n);
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        eventCallback.onInfo(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), 704, n);
                    }
                });
            }
        });
        mediaPlayer.setOnMediaTimeDiscontinuityListener(new MediaPlayer.OnMediaTimeDiscontinuityListener(){

            public void onMediaTimeDiscontinuity(MediaPlayer mediaPlayer, final MediaTimestamp mediaTimestamp) {
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        eventCallback.onMediaTimeDiscontinuity(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), new MediaTimestamp2(mediaTimestamp));
                    }
                });
                MediaPlayer2Impl.this.setEndPositionTimerIfNeeded(onCompletionListener, mediaPlayerSource, mediaTimestamp);
            }
        });
        mediaPlayer.setOnSubtitleDataListener(new MediaPlayer.OnSubtitleDataListener(){

            public void onSubtitleData(MediaPlayer mediaPlayer, final SubtitleData subtitleData) {
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        eventCallback.onSubtitleData(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), new SubtitleData2(subtitleData));
                    }
                });
            }
        });
        mediaPlayer.setOnDrmInfoListener(new MediaPlayer.OnDrmInfoListener(){

            public void onDrmInfo(MediaPlayer mediaPlayer, final MediaPlayer.DrmInfo drmInfo) {
                MediaPlayer2Impl.this.notifyDrmEvent(new DrmEventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.DrmEventCallback drmEventCallback) {
                        drmEventCallback.onDrmInfo(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), new DrmInfoImpl(drmInfo.getPssh(), drmInfo.getSupportedSchemes()));
                    }
                });
            }
        });
        mediaPlayer.setOnDrmPreparedListener(new MediaPlayer.OnDrmPreparedListener(){

            public void onDrmPrepared(MediaPlayer mediaPlayer, final int n) {
                MediaPlayer2Impl.this.notifyDrmEvent(new DrmEventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.DrmEventCallback drmEventCallback) {
                        int n2 = sPrepareDrmStatusMap.getOrDefault(n, 3);
                        drmEventCallback.onDrmPrepared(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), n2);
                    }
                });
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void unregisterPlayerEventCallback(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
        if (playerEventCallback != null) {
            Object object = this.mLock;
            synchronized (object) {
                this.mPlayerEventCallbackMap.remove(playerEventCallback);
                return;
            }
        }
        throw new IllegalArgumentException("Illegal null PlayerEventCallback");
    }

    @Override
    public void attachAuxEffect(final int n) {
        this.addTask(new Task(1, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.attachAuxEffect(n);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void clearDrmEventCallback() {
        Object object = this.mLock;
        synchronized (object) {
            this.mDrmEventCallbackRecord = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void clearEventCallback() {
        Object object = this.mLock;
        synchronized (object) {
            this.mMp2EventCallbackRecord = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void clearPendingCommands() {
        Object object = this.mTaskLock;
        synchronized (object) {
            this.mPendingTasks.clear();
            return;
        }
    }

    @Override
    public void close() {
        this.mPlayer.release();
        HandlerThread handlerThread = this.mHandlerThread;
        if (handlerThread != null) {
            handlerThread.quitSafely();
            this.mHandlerThread = null;
        }
    }

    @Override
    public void deselectTrack(final int n) {
        this.addTask(new Task(2, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.deselectTrack(n);
            }
        });
    }

    @Override
    public AudioAttributesCompat getAudioAttributes() {
        return this.mPlayer.getAudioAttributes();
    }

    @Override
    public int getAudioSessionId() {
        return this.mPlayer.getAudioSessionId();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public BaseMediaPlayer getBaseMediaPlayer() {
        Object object = this.mLock;
        synchronized (object) {
            BaseMediaPlayerImpl baseMediaPlayerImpl;
            if (this.mBaseMediaPlayerImpl != null) return this.mBaseMediaPlayerImpl;
            this.mBaseMediaPlayerImpl = baseMediaPlayerImpl = new BaseMediaPlayerImpl();
            return this.mBaseMediaPlayerImpl;
        }
    }

    @Override
    public long getBufferedPosition() {
        return this.mPlayer.getBufferedPosition();
    }

    @Override
    public DataSourceDesc getCurrentDataSource() {
        return this.mPlayer.getFirst().getDSD();
    }

    @Override
    public long getCurrentPosition() {
        return this.mPlayer.getCurrentPosition();
    }

    @Override
    public MediaPlayer2.DrmInfo getDrmInfo() {
        MediaPlayer.DrmInfo drmInfo = this.mPlayer.getDrmInfo();
        DrmInfoImpl drmInfoImpl = null;
        if (drmInfo != null) {
            drmInfoImpl = new DrmInfoImpl(drmInfo.getPssh(), drmInfo.getSupportedSchemes());
        }
        return drmInfoImpl;
    }

    @Override
    public MediaDrm.KeyRequest getDrmKeyRequest(byte[] object, byte[] byArray, String string2, int n, Map<String, String> map) throws MediaPlayer2.NoDrmSchemeException {
        try {
            object = this.mPlayer.getKeyRequest((byte[])object, byArray, string2, n, map);
            return object;
        }
        catch (MediaPlayer.NoDrmSchemeException noDrmSchemeException) {
            throw new MediaPlayer2.NoDrmSchemeException(noDrmSchemeException.getMessage());
        }
    }

    @Override
    public String getDrmPropertyString(String string2) throws MediaPlayer2.NoDrmSchemeException {
        try {
            string2 = this.mPlayer.getDrmPropertyString(string2);
            return string2;
        }
        catch (MediaPlayer.NoDrmSchemeException noDrmSchemeException) {
            throw new MediaPlayer2.NoDrmSchemeException(noDrmSchemeException.getMessage());
        }
    }

    @Override
    public long getDuration() {
        return this.mPlayer.getDuration();
    }

    @Override
    public float getMaxPlayerVolume() {
        return 1.0f;
    }

    @Override
    public PersistableBundle getMetrics() {
        return this.mPlayer.getMetrics();
    }

    @Override
    public PlaybackParams2 getPlaybackParams() {
        return new PlaybackParams2.Builder(this.mPlayer.getPlaybackParams()).build();
    }

    @Override
    public float getPlayerVolume() {
        return this.mPlayer.getVolume();
    }

    @Override
    public int getSelectedTrack(int n) {
        return this.mPlayer.getSelectedTrack(n);
    }

    @Override
    public int getState() {
        return this.mPlayer.getMediaPlayer2State();
    }

    @Override
    public MediaTimestamp2 getTimestamp() {
        return this.mPlayer.getTimestamp();
    }

    @Override
    public List<MediaPlayer2.TrackInfo> getTrackInfo() {
        MediaPlayer.TrackInfo[] trackInfoArray = this.mPlayer.getTrackInfo();
        ArrayList<MediaPlayer2.TrackInfo> arrayList = new ArrayList<MediaPlayer2.TrackInfo>();
        for (MediaPlayer.TrackInfo trackInfo : trackInfoArray) {
            arrayList.add(new TrackInfoImpl(trackInfo.getTrackType(), trackInfo.getFormat()));
        }
        return arrayList;
    }

    @Override
    public int getVideoHeight() {
        return this.mPlayer.getVideoHeight();
    }

    @Override
    public int getVideoWidth() {
        return this.mPlayer.getVideoWidth();
    }

    @Override
    public void loopCurrent(final boolean bl) {
        this.addTask(new Task(3, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.setLooping(bl);
            }
        });
    }

    @Override
    public void notifyWhenCommandLabelReached(final Object object) {
        this.addTask(new Task(1003, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                    @Override
                    public void notify(MediaPlayer2.EventCallback eventCallback) {
                        eventCallback.onCommandLabelReached(MediaPlayer2Impl.this, object);
                    }
                });
            }
        });
    }

    @Override
    public void pause() {
        this.addTask(new Task(4, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.pause();
            }
        });
    }

    @Override
    public void play() {
        this.addTask(new Task(5, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.play();
            }
        });
    }

    @Override
    public void prepare() {
        this.addTask(new Task(6, true){

            @Override
            void process() throws IOException {
                MediaPlayer2Impl.this.mPlayer.prepareAsync();
            }
        });
    }

    @Override
    public void prepareDrm(UUID uUID) throws UnsupportedSchemeException, ResourceBusyException, MediaPlayer2.ProvisioningNetworkErrorException, MediaPlayer2.ProvisioningServerErrorException {
        try {
            this.mPlayer.prepareDrm(uUID);
            return;
        }
        catch (MediaPlayer.ProvisioningServerErrorException provisioningServerErrorException) {
            throw new MediaPlayer2.ProvisioningServerErrorException(provisioningServerErrorException.getMessage());
        }
        catch (MediaPlayer.ProvisioningNetworkErrorException provisioningNetworkErrorException) {
            throw new MediaPlayer2.ProvisioningNetworkErrorException(provisioningNetworkErrorException.getMessage());
        }
    }

    @Override
    public byte[] provideDrmKeyResponse(byte[] byArray, byte[] byArray2) throws MediaPlayer2.NoDrmSchemeException, DeniedByServerException {
        try {
            byArray = this.mPlayer.provideKeyResponse(byArray, byArray2);
            return byArray;
        }
        catch (MediaPlayer.NoDrmSchemeException noDrmSchemeException) {
            throw new MediaPlayer2.NoDrmSchemeException(noDrmSchemeException.getMessage());
        }
    }

    @Override
    public void releaseDrm() throws MediaPlayer2.NoDrmSchemeException {
        try {
            this.mPlayer.releaseDrm();
            return;
        }
        catch (MediaPlayer.NoDrmSchemeException noDrmSchemeException) {
            throw new MediaPlayer2.NoDrmSchemeException(noDrmSchemeException.getMessage());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void reset() {
        this.mPlayer.reset();
        Object object = this.mLock;
        synchronized (object) {
            this.mMp2EventCallbackRecord = null;
            this.mPlayerEventCallbackMap.clear();
            this.mDrmEventCallbackRecord = null;
            return;
        }
    }

    @Override
    public void restoreDrmKeys(byte[] byArray) throws MediaPlayer2.NoDrmSchemeException {
        try {
            this.mPlayer.restoreKeys(byArray);
            return;
        }
        catch (MediaPlayer.NoDrmSchemeException noDrmSchemeException) {
            throw new MediaPlayer2.NoDrmSchemeException(noDrmSchemeException.getMessage());
        }
    }

    @Override
    public void seekTo(final long l, final int n) {
        this.addTask(new Task(14, true){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.seekTo(l, n);
            }
        });
    }

    @Override
    public void selectTrack(final int n) {
        this.addTask(new Task(15, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.selectTrack(n);
            }
        });
    }

    @Override
    public void setAudioAttributes(final AudioAttributesCompat audioAttributesCompat) {
        this.addTask(new Task(16, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.setAudioAttributes(audioAttributesCompat);
            }
        });
    }

    @Override
    public void setAudioSessionId(final int n) {
        this.addTask(new Task(17, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.setAudioSessionId(n);
            }
        });
    }

    @Override
    public void setAuxEffectSendLevel(final float f) {
        this.addTask(new Task(18, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.setAuxEffectSendLevel(f);
            }
        });
    }

    @Override
    public void setDataSource(final DataSourceDesc dataSourceDesc) {
        this.addTask(new Task(19, false){

            @Override
            void process() {
                Preconditions.checkNotNull(dataSourceDesc, "the DataSourceDesc cannot be null");
                try {
                    MediaPlayer2Impl.this.mPlayer.setFirst(dataSourceDesc);
                }
                catch (IOException iOException) {
                    Log.e((String)MediaPlayer2Impl.TAG, (String)"process: setDataSource", (Throwable)iOException);
                }
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setDrmEventCallback(Executor executor, MediaPlayer2.DrmEventCallback drmEventCallback) {
        if (drmEventCallback == null) {
            throw new IllegalArgumentException("Illegal null EventCallback");
        }
        if (executor != null) {
            Object object = this.mLock;
            synchronized (object) {
                Pair pair;
                this.mDrmEventCallbackRecord = pair = new Pair((Object)executor, (Object)drmEventCallback);
                return;
            }
        }
        throw new IllegalArgumentException("Illegal null Executor for the EventCallback");
    }

    @Override
    public void setDrmPropertyString(String string2, String string3) throws MediaPlayer2.NoDrmSchemeException {
        try {
            this.mPlayer.setDrmPropertyString(string2, string3);
            return;
        }
        catch (MediaPlayer.NoDrmSchemeException noDrmSchemeException) {
            throw new MediaPlayer2.NoDrmSchemeException(noDrmSchemeException.getMessage());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setEventCallback(Executor executor, MediaPlayer2.EventCallback eventCallback) {
        if (eventCallback == null) {
            throw new IllegalArgumentException("Illegal null EventCallback");
        }
        if (executor != null) {
            Object object = this.mLock;
            synchronized (object) {
                Pair pair;
                this.mMp2EventCallbackRecord = pair = new Pair((Object)executor, (Object)eventCallback);
                return;
            }
        }
        throw new IllegalArgumentException("Illegal null Executor for the EventCallback");
    }

    @Override
    public void setNextDataSource(final DataSourceDesc dataSourceDesc) {
        this.addTask(new Task(22, false){

            @Override
            void process() {
                Preconditions.checkNotNull(dataSourceDesc, "the DataSourceDesc cannot be null");
                MediaPlayer2Impl mediaPlayer2Impl = MediaPlayer2Impl.this;
                mediaPlayer2Impl.handleDataSourceError(mediaPlayer2Impl.mPlayer.setNext(dataSourceDesc));
            }
        });
    }

    @Override
    public void setNextDataSources(final List<DataSourceDesc> list) {
        this.addTask(new Task(23, false){

            @Override
            void process() {
                Object object = list;
                if (object != null && object.size() != 0) {
                    object = list.iterator();
                    while (object.hasNext()) {
                        if ((DataSourceDesc)object.next() != null) continue;
                        throw new IllegalArgumentException("DataSourceDesc in the source list cannot be null.");
                    }
                    object = MediaPlayer2Impl.this;
                    ((MediaPlayer2Impl)object).handleDataSourceError(((MediaPlayer2Impl)object).mPlayer.setNextMultiple(list));
                    return;
                }
                throw new IllegalArgumentException("data source list cannot be null or empty.");
            }
        });
    }

    @Override
    public void setOnDrmConfigHelper(final MediaPlayer2.OnDrmConfigHelper onDrmConfigHelper) {
        this.mPlayer.setOnDrmConfigHelper(new MediaPlayer.OnDrmConfigHelper(){

            public void onDrmConfig(MediaPlayer object) {
                object = MediaPlayer2Impl.this.mPlayer.getSourceForPlayer((MediaPlayer)object);
                object = object == null ? null : ((MediaPlayerSource)object).getDSD();
                onDrmConfigHelper.onDrmConfig(MediaPlayer2Impl.this, (DataSourceDesc)object);
            }
        });
    }

    @Override
    public void setPlaybackParams(final PlaybackParams2 playbackParams2) {
        this.addTask(new Task(24, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.setPlaybackParamsInternal(playbackParams2.getPlaybackParams());
            }
        });
    }

    @Override
    public void setPlayerVolume(final float f) {
        this.addTask(new Task(26, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.setVolume(f);
            }
        });
    }

    @Override
    public void setSurface(final Surface surface) {
        this.addTask(new Task(27, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.setSurface(surface);
            }
        });
    }

    @Override
    public void skipToNext() {
        this.addTask(new Task(29, false){

            @Override
            void process() {
                MediaPlayer2Impl.this.mPlayer.skipToNext();
            }
        });
    }

    private class BaseMediaPlayerImpl
    extends BaseMediaPlayer {
        private BaseMediaPlayerImpl() {
        }

        @Override
        public void close() throws Exception {
            MediaPlayer2Impl.this.close();
        }

        @Override
        public AudioAttributesCompat getAudioAttributes() {
            return MediaPlayer2Impl.this.getAudioAttributes();
        }

        @Override
        public long getBufferedPosition() {
            return MediaPlayer2Impl.this.getBufferedPosition();
        }

        @Override
        public int getBufferingState() {
            return MediaPlayer2Impl.this.getBufferingState();
        }

        @Override
        public DataSourceDesc getCurrentDataSource() {
            return MediaPlayer2Impl.this.getCurrentDataSource();
        }

        @Override
        public long getCurrentPosition() {
            return MediaPlayer2Impl.this.getCurrentPosition();
        }

        @Override
        public long getDuration() {
            return MediaPlayer2Impl.this.getDuration();
        }

        @Override
        public float getPlaybackSpeed() {
            return MediaPlayer2Impl.this.getPlaybackParams().getSpeed().floatValue();
        }

        @Override
        public int getPlayerState() {
            return MediaPlayer2Impl.this.getPlayerState();
        }

        @Override
        public float getPlayerVolume() {
            return MediaPlayer2Impl.this.getPlayerVolume();
        }

        @Override
        public void loopCurrent(boolean bl) {
            MediaPlayer2Impl.this.loopCurrent(bl);
        }

        @Override
        public void pause() {
            MediaPlayer2Impl.this.pause();
        }

        @Override
        public void play() {
            MediaPlayer2Impl.this.play();
        }

        @Override
        public void prepare() {
            MediaPlayer2Impl.this.prepare();
        }

        @Override
        public void registerPlayerEventCallback(Executor executor, BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
            MediaPlayer2Impl.this.registerPlayerEventCallback(executor, playerEventCallback);
        }

        @Override
        public void reset() {
            MediaPlayer2Impl.this.reset();
        }

        @Override
        public void seekTo(long l) {
            MediaPlayer2Impl.this.seekTo(l);
        }

        @Override
        public void setAudioAttributes(AudioAttributesCompat audioAttributesCompat) {
            MediaPlayer2Impl.this.setAudioAttributes(audioAttributesCompat);
        }

        @Override
        public void setDataSource(DataSourceDesc dataSourceDesc) {
            MediaPlayer2Impl.this.setDataSource(dataSourceDesc);
        }

        @Override
        public void setNextDataSource(DataSourceDesc dataSourceDesc) {
            MediaPlayer2Impl.this.setNextDataSource(dataSourceDesc);
        }

        @Override
        public void setNextDataSources(List<DataSourceDesc> list) {
            MediaPlayer2Impl.this.setNextDataSources(list);
        }

        @Override
        public void setPlaybackSpeed(float f) {
            MediaPlayer2Impl mediaPlayer2Impl = MediaPlayer2Impl.this;
            mediaPlayer2Impl.setPlaybackParams(new PlaybackParams2.Builder(mediaPlayer2Impl.getPlaybackParams().getPlaybackParams()).setSpeed(f).build());
        }

        @Override
        public void setPlayerVolume(float f) {
            MediaPlayer2Impl.this.setPlayerVolume(f);
        }

        @Override
        public void skipToNext() {
            MediaPlayer2Impl.this.skipToNext();
        }

        @Override
        public void unregisterPlayerEventCallback(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
            MediaPlayer2Impl.this.unregisterPlayerEventCallback(playerEventCallback);
        }
    }

    private static class DataSourceError {
        final DataSourceDesc mDSD;
        final int mExtra;
        final int mWhat;

        DataSourceError(DataSourceDesc dataSourceDesc, int n, int n2) {
            this.mDSD = dataSourceDesc;
            this.mWhat = n;
            this.mExtra = n2;
        }
    }

    private static interface DrmEventNotifier {
        public void notify(MediaPlayer2.DrmEventCallback var1);
    }

    public static final class DrmInfoImpl
    extends MediaPlayer2.DrmInfo {
        private Map<UUID, byte[]> mMapPssh;
        private UUID[] mSupportedSchemes;

        private DrmInfoImpl(Parcel object) {
            Object object2 = new StringBuilder();
            ((StringBuilder)object2).append("DrmInfoImpl(");
            ((StringBuilder)object2).append(object);
            ((StringBuilder)object2).append(") size ");
            ((StringBuilder)object2).append(object.dataSize());
            Log.v((String)MediaPlayer2Impl.TAG, (String)((StringBuilder)object2).toString());
            int n = object.readInt();
            object2 = new byte[n];
            object.readByteArray((byte[])object2);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DrmInfoImpl() PSSH: ");
            stringBuilder.append(this.arrToHex((byte[])object2));
            Log.v((String)MediaPlayer2Impl.TAG, (String)stringBuilder.toString());
            this.mMapPssh = this.parsePSSH((byte[])object2, n);
            object2 = new StringBuilder();
            ((StringBuilder)object2).append("DrmInfoImpl() PSSH: ");
            ((StringBuilder)object2).append(this.mMapPssh);
            Log.v((String)MediaPlayer2Impl.TAG, (String)((StringBuilder)object2).toString());
            int n2 = object.readInt();
            this.mSupportedSchemes = new UUID[n2];
            for (int i = 0; i < n2; ++i) {
                object2 = new byte[16];
                object.readByteArray((byte[])object2);
                this.mSupportedSchemes[i] = this.bytesToUUID((byte[])object2);
                object2 = new StringBuilder();
                ((StringBuilder)object2).append("DrmInfoImpl() supportedScheme[");
                ((StringBuilder)object2).append(i);
                ((StringBuilder)object2).append("]: ");
                ((StringBuilder)object2).append(this.mSupportedSchemes[i]);
                Log.v((String)MediaPlayer2Impl.TAG, (String)((StringBuilder)object2).toString());
            }
            object = new StringBuilder();
            ((StringBuilder)object).append("DrmInfoImpl() Parcel psshsize: ");
            ((StringBuilder)object).append(n);
            ((StringBuilder)object).append(" supportedDRMsCount: ");
            ((StringBuilder)object).append(n2);
            Log.v((String)MediaPlayer2Impl.TAG, (String)((StringBuilder)object).toString());
        }

        private DrmInfoImpl(Map<UUID, byte[]> map, UUID[] uUIDArray) {
            this.mMapPssh = map;
            this.mSupportedSchemes = uUIDArray;
        }

        private String arrToHex(byte[] byArray) {
            String string2 = "0x";
            for (int i = 0; i < byArray.length; ++i) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string2);
                stringBuilder.append(String.format("%02x", byArray[i]));
                string2 = stringBuilder.toString();
            }
            return string2;
        }

        private UUID bytesToUUID(byte[] byArray) {
            long l = 0L;
            long l2 = 0L;
            for (int i = 0; i < 8; ++i) {
                l |= ((long)byArray[i] & 0xFFL) << (7 - i) * 8;
                l2 |= ((long)byArray[i + 8] & 0xFFL) << (7 - i) * 8;
            }
            return new UUID(l, l2);
        }

        private DrmInfoImpl makeCopy() {
            return new DrmInfoImpl(this.mMapPssh, this.mSupportedSchemes);
        }

        private Map<UUID, byte[]> parsePSSH(byte[] byArray, int n) {
            HashMap<UUID, byte[]> hashMap = new HashMap<UUID, byte[]>();
            int n2 = n;
            int n3 = 0;
            int n4 = 0;
            while (n2 > 0) {
                if (n2 < 16) {
                    Log.w((String)MediaPlayer2Impl.TAG, (String)String.format("parsePSSH: len is too short to parse UUID: (%d < 16) pssh: %d", n2, n));
                    return null;
                }
                UUID uUID = this.bytesToUUID(Arrays.copyOfRange(byArray, n4, n4 + 16));
                int n5 = n4 + 16;
                int n6 = n2 - 16;
                if (n6 < 4) {
                    Log.w((String)MediaPlayer2Impl.TAG, (String)String.format("parsePSSH: len is too short to parse datalen: (%d < 4) pssh: %d", n6, n));
                    return null;
                }
                byte[] byArray2 = Arrays.copyOfRange(byArray, n5, n5 + 4);
                if (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) {
                    n2 = (byArray2[3] & 0xFF) << 24 | (byArray2[2] & 0xFF) << 16 | (byArray2[1] & 0xFF) << 8;
                    n4 = byArray2[0] & 0xFF;
                } else {
                    n2 = (byArray2[0] & 0xFF) << 24 | (byArray2[1] & 0xFF) << 16 | (byArray2[2] & 0xFF) << 8;
                    n4 = byArray2[3] & 0xFF;
                }
                n2 |= n4;
                n4 = n5 + 4;
                if ((n6 -= 4) < n2) {
                    Log.w((String)MediaPlayer2Impl.TAG, (String)String.format("parsePSSH: len is too short to parse data: (%d < %d) pssh: %d", n6, n2, n));
                    return null;
                }
                byArray2 = Arrays.copyOfRange(byArray, n4, n4 + n2);
                n4 += n2;
                n2 = n6 - n2;
                Log.v((String)MediaPlayer2Impl.TAG, (String)String.format("parsePSSH[%d]: <%s, %s> pssh: %d", n3, uUID, this.arrToHex(byArray2), n));
                ++n3;
                hashMap.put(uUID, byArray2);
            }
            return hashMap;
        }

        @Override
        public Map<UUID, byte[]> getPssh() {
            return this.mMapPssh;
        }

        @Override
        public List<UUID> getSupportedSchemes() {
            return Arrays.asList(this.mSupportedSchemes);
        }
    }

    private class MediaPlayerSource {
        final AtomicInteger mBufferedPercentage;
        int mBufferingState = 0;
        volatile DataSourceDesc mDSD;
        int mMp2State = 1001;
        boolean mPlayPending;
        final MediaPlayer mPlayer = new MediaPlayer();
        int mPlayerState = 0;
        int mSourceState = 0;

        MediaPlayerSource(DataSourceDesc dataSourceDesc) {
            this.mBufferedPercentage = new AtomicInteger(0);
            this.mDSD = dataSourceDesc;
            MediaPlayer2Impl.this.setUpListeners(this);
        }

        DataSourceDesc getDSD() {
            return this.mDSD;
        }
    }

    private class MediaPlayerSourceQueue {
        AudioAttributesCompat mAudioAttributes;
        Integer mAudioSessionId;
        Integer mAuxEffect;
        Float mAuxEffectSendLevel;
        PlaybackParams mPlaybackParams;
        List<MediaPlayerSource> mQueue = new ArrayList<MediaPlayerSource>();
        Surface mSurface;
        SyncParams mSyncParams;
        Float mVolume = Float.valueOf(1.0f);

        MediaPlayerSourceQueue() {
            this.mQueue.add(new MediaPlayerSource(null));
        }

        void attachAuxEffect(int n) {
            synchronized (this) {
                this.getCurrentPlayer().attachAuxEffect(n);
                this.mAuxEffect = n;
                return;
            }
        }

        void deselectTrack(int n) {
            synchronized (this) {
                this.getCurrentPlayer().deselectTrack(n);
                return;
            }
        }

        AudioAttributesCompat getAudioAttributes() {
            synchronized (this) {
                AudioAttributesCompat audioAttributesCompat = this.mAudioAttributes;
                return audioAttributesCompat;
            }
        }

        int getAudioSessionId() {
            synchronized (this) {
                int n = this.getCurrentPlayer().getAudioSessionId();
                return n;
            }
        }

        long getBufferedPosition() {
            synchronized (this) {
                MediaPlayerSource mediaPlayerSource = this.mQueue.get(0);
                long l = (long)mediaPlayerSource.mPlayer.getDuration() * (long)mediaPlayerSource.mBufferedPercentage.get() / 100L;
                return l;
            }
        }

        int getBufferingState() {
            synchronized (this) {
                int n = this.mQueue.get((int)0).mBufferingState;
                return n;
            }
        }

        MediaPlayer getCurrentPlayer() {
            synchronized (this) {
                MediaPlayer mediaPlayer = this.mQueue.get((int)0).mPlayer;
                return mediaPlayer;
            }
        }

        long getCurrentPosition() {
            synchronized (this) {
                int n = this.getCurrentPlayer().getCurrentPosition();
                long l = n;
                return l;
            }
        }

        MediaPlayer.DrmInfo getDrmInfo() {
            synchronized (this) {
                MediaPlayer.DrmInfo drmInfo = this.getCurrentPlayer().getDrmInfo();
                return drmInfo;
            }
        }

        String getDrmPropertyString(String string2) throws MediaPlayer.NoDrmSchemeException {
            synchronized (this) {
                string2 = this.getCurrentPlayer().getDrmPropertyString(string2);
                return string2;
            }
        }

        long getDuration() {
            synchronized (this) {
                int n = this.getCurrentPlayer().getDuration();
                long l = n;
                return l;
            }
        }

        MediaPlayerSource getFirst() {
            synchronized (this) {
                MediaPlayerSource mediaPlayerSource = this.mQueue.get(0);
                return mediaPlayerSource;
            }
        }

        MediaDrm.KeyRequest getKeyRequest(byte[] object, byte[] byArray, String string2, int n, Map<String, String> map) throws MediaPlayer.NoDrmSchemeException {
            synchronized (this) {
                object = this.getCurrentPlayer().getKeyRequest(object, byArray, string2, n, map);
                return object;
            }
        }

        int getMediaPlayer2State() {
            synchronized (this) {
                int n = this.mQueue.get((int)0).mMp2State;
                return n;
            }
        }

        PersistableBundle getMetrics() {
            synchronized (this) {
                PersistableBundle persistableBundle = this.getCurrentPlayer().getMetrics();
                return persistableBundle;
            }
        }

        PlaybackParams getPlaybackParams() {
            synchronized (this) {
                PlaybackParams playbackParams = this.getCurrentPlayer().getPlaybackParams();
                return playbackParams;
            }
        }

        int getPlayerState() {
            synchronized (this) {
                int n = this.mQueue.get((int)0).mPlayerState;
                return n;
            }
        }

        int getSelectedTrack(int n) {
            synchronized (this) {
                n = this.getCurrentPlayer().getSelectedTrack(n);
                return n;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        MediaPlayerSource getSourceForPlayer(MediaPlayer mediaPlayer) {
            synchronized (this) {
                MediaPlayerSource mediaPlayerSource;
                MediaPlayer mediaPlayer2;
                Iterator<MediaPlayerSource> iterator2 = this.mQueue.iterator();
                do {
                    if (!iterator2.hasNext()) {
                        return null;
                    }
                    mediaPlayerSource = iterator2.next();
                } while ((mediaPlayer2 = mediaPlayerSource.mPlayer) != mediaPlayer);
                return mediaPlayerSource;
            }
        }

        SyncParams getSyncParams() {
            synchronized (this) {
                SyncParams syncParams = this.getCurrentPlayer().getSyncParams();
                return syncParams;
            }
        }

        /*
         * WARNING - void declaration
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        MediaTimestamp2 getTimestamp() {
            synchronized (this) {
                void var1_4;
                MediaTimestamp mediaTimestamp = this.getCurrentPlayer().getTimestamp();
                if (mediaTimestamp == null) {
                    Object var1_2 = null;
                } else {
                    MediaTimestamp2 mediaTimestamp2 = new MediaTimestamp2(mediaTimestamp);
                }
                return var1_4;
            }
        }

        MediaPlayer.TrackInfo[] getTrackInfo() {
            synchronized (this) {
                MediaPlayer.TrackInfo[] trackInfoArray = this.getCurrentPlayer().getTrackInfo();
                return trackInfoArray;
            }
        }

        int getVideoHeight() {
            synchronized (this) {
                int n = this.getCurrentPlayer().getVideoHeight();
                return n;
            }
        }

        int getVideoWidth() {
            synchronized (this) {
                int n = this.getCurrentPlayer().getVideoWidth();
                return n;
            }
        }

        float getVolume() {
            synchronized (this) {
                float f = this.mVolume.floatValue();
                return f;
            }
        }

        void moveToNext() {
            synchronized (this) {
                PlayerEventNotifier playerEventNotifier = this.mQueue.remove(0);
                ((MediaPlayerSource)playerEventNotifier).mPlayer.release();
                if (!this.mQueue.isEmpty()) {
                    PlayerEventNotifier playerEventNotifier2;
                    final MediaPlayerSource mediaPlayerSource = this.mQueue.get(0);
                    if (((MediaPlayerSource)playerEventNotifier).mPlayerState != mediaPlayerSource.mPlayerState) {
                        playerEventNotifier = MediaPlayer2Impl.this;
                        playerEventNotifier2 = new PlayerEventNotifier(){

                            @Override
                            public void notify(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
                                playerEventCallback.onPlayerStateChanged(MediaPlayer2Impl.this.mBaseMediaPlayerImpl, mediaPlayerSource.mPlayerState);
                            }
                        };
                        ((MediaPlayer2Impl)((Object)playerEventNotifier)).notifyPlayerEvent(playerEventNotifier2);
                    }
                    playerEventNotifier2 = MediaPlayer2Impl.this;
                    playerEventNotifier = new PlayerEventNotifier(){

                        @Override
                        public void notify(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
                            playerEventCallback.onCurrentDataSourceChanged(MediaPlayer2Impl.this.mBaseMediaPlayerImpl, mediaPlayerSource.mDSD);
                        }
                    };
                    ((MediaPlayer2Impl)((Object)playerEventNotifier2)).notifyPlayerEvent(playerEventNotifier);
                    return;
                }
                IllegalStateException illegalStateException = new IllegalStateException("player/source queue emptied");
                throw illegalStateException;
            }
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        DataSourceError onCompletion(MediaPlayer object) {
            synchronized (this) {
                block4: {
                    if (this.mQueue.isEmpty()) return this.playCurrent();
                    if (object != this.getCurrentPlayer()) return this.playCurrent();
                    if (this.mQueue.size() != 1) break block4;
                    this.setMp2State((MediaPlayer)object, 1003);
                    final DataSourceDesc dataSourceDesc = this.mQueue.get(0).getDSD();
                    MediaPlayer2Impl mediaPlayer2Impl = MediaPlayer2Impl.this;
                    Mp2EventNotifier mp2EventNotifier = new Mp2EventNotifier(){

                        @Override
                        public void notify(MediaPlayer2.EventCallback eventCallback) {
                            eventCallback.onInfo(MediaPlayer2Impl.this, dataSourceDesc, 6, 0);
                        }
                    };
                    mediaPlayer2Impl.notifyMediaPlayer2Event(mp2EventNotifier);
                    return null;
                }
                this.moveToNext();
                return this.playCurrent();
            }
        }

        void onError(MediaPlayer mediaPlayer) {
            synchronized (this) {
                this.setMp2State(mediaPlayer, 1005);
                this.setBufferingState(mediaPlayer, 0);
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        DataSourceError onPrepared(MediaPlayer object) {
            synchronized (this) {
                int n = 0;
                while (n < this.mQueue.size()) {
                    MediaPlayerSource mediaPlayerSource = this.mQueue.get(n);
                    if (object == mediaPlayerSource.mPlayer) {
                        if (n == 0) {
                            if (mediaPlayerSource.mPlayPending) {
                                mediaPlayerSource.mPlayPending = false;
                                mediaPlayerSource.mPlayer.start();
                                this.setMp2State(mediaPlayerSource.mPlayer, 1004);
                            } else {
                                this.setMp2State(mediaPlayerSource.mPlayer, 1002);
                            }
                        }
                        mediaPlayerSource.mSourceState = 2;
                        this.setBufferingState(mediaPlayerSource.mPlayer, 1);
                        return this.prepareAt(n + 1);
                    }
                    ++n;
                }
                return null;
            }
        }

        void pause() {
            synchronized (this) {
                MediaPlayer mediaPlayer = this.getCurrentPlayer();
                mediaPlayer.pause();
                this.setMp2State(mediaPlayer, 1003);
                return;
            }
        }

        void play() {
            synchronized (this) {
                Object object = this.mQueue.get(0);
                if (((MediaPlayerSource)object).mSourceState == 2) {
                    ((MediaPlayerSource)object).mPlayer.start();
                    this.setMp2State(((MediaPlayerSource)object).mPlayer, 1004);
                    return;
                }
                object = new IllegalStateException();
                throw object;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        DataSourceError playCurrent() {
            synchronized (this) {
                DataSourceError dataSourceError = null;
                Mp2EventNotifier mp2EventNotifier = null;
                final MediaPlayerSource mediaPlayerSource = this.mQueue.get(0);
                if (this.mSurface != null) {
                    mediaPlayerSource.mPlayer.setSurface(this.mSurface);
                }
                if (this.mVolume != null) {
                    mediaPlayerSource.mPlayer.setVolume(this.mVolume.floatValue(), this.mVolume.floatValue());
                }
                if (this.mAudioAttributes != null) {
                    mediaPlayerSource.mPlayer.setAudioAttributes((AudioAttributes)this.mAudioAttributes.unwrap());
                }
                if (this.mAuxEffect != null) {
                    mediaPlayerSource.mPlayer.attachAuxEffect(this.mAuxEffect.intValue());
                }
                if (this.mAuxEffectSendLevel != null) {
                    mediaPlayerSource.mPlayer.setAuxEffectSendLevel(this.mAuxEffectSendLevel.floatValue());
                }
                if (this.mSyncParams != null) {
                    mediaPlayerSource.mPlayer.setSyncParams(this.mSyncParams);
                }
                if (this.mPlaybackParams != null) {
                    mediaPlayerSource.mPlayer.setPlaybackParams(this.mPlaybackParams);
                }
                if (mediaPlayerSource.mSourceState == 2) {
                    mediaPlayerSource.mPlayer.start();
                    this.setMp2State(mediaPlayerSource.mPlayer, 1004);
                    MediaPlayer2Impl mediaPlayer2Impl = MediaPlayer2Impl.this;
                    mp2EventNotifier = new Mp2EventNotifier(){

                        @Override
                        public void notify(MediaPlayer2.EventCallback eventCallback) {
                            eventCallback.onInfo(MediaPlayer2Impl.this, mediaPlayerSource.getDSD(), 2, 0);
                        }
                    };
                    mediaPlayer2Impl.notifyMediaPlayer2Event(mp2EventNotifier);
                } else {
                    dataSourceError = mp2EventNotifier;
                    if (mediaPlayerSource.mSourceState == 0) {
                        dataSourceError = this.prepareAt(0);
                    }
                    mediaPlayerSource.mPlayPending = true;
                }
                return dataSourceError;
            }
        }

        void prepare() {
            synchronized (this) {
                this.getCurrentPlayer().prepareAsync();
                return;
            }
        }

        void prepareAsync() {
            synchronized (this) {
                MediaPlayer mediaPlayer = this.getCurrentPlayer();
                mediaPlayer.prepareAsync();
                this.setBufferingState(mediaPlayer, 2);
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        DataSourceError prepareAt(int n) {
            synchronized (this) {
                if (n >= this.mQueue.size()) return null;
                if (this.mQueue.get((int)n).mSourceState != 0) return null;
                if (n == 0 || this.getPlayerState() != 0) {
                    MediaPlayerSource object = this.mQueue.get(n);
                    try {
                        if (this.mAudioSessionId != null) {
                            object.mPlayer.setAudioSessionId(this.mAudioSessionId.intValue());
                        }
                        object.mSourceState = 1;
                        MediaPlayer2Impl.handleDataSource(object);
                        object.mPlayer.prepareAsync();
                        return null;
                    }
                    catch (Exception exception) {
                        DataSourceDesc exception2 = object.getDSD();
                        this.setMp2State(object.mPlayer, 1005);
                        return new DataSourceError(exception2, 1, -1010);
                    }
                }
                return null;
            }
        }

        void prepareDrm(UUID uUID) throws ResourceBusyException, MediaPlayer.ProvisioningServerErrorException, MediaPlayer.ProvisioningNetworkErrorException, UnsupportedSchemeException {
            synchronized (this) {
                this.getCurrentPlayer().prepareDrm(uUID);
                return;
            }
        }

        byte[] provideKeyResponse(byte[] byArray, byte[] byArray2) throws DeniedByServerException, MediaPlayer.NoDrmSchemeException {
            synchronized (this) {
                byArray = this.getCurrentPlayer().provideKeyResponse(byArray, byArray2);
                return byArray;
            }
        }

        void release() {
            synchronized (this) {
                this.getCurrentPlayer().release();
                return;
            }
        }

        void releaseDrm() throws MediaPlayer.NoDrmSchemeException {
            synchronized (this) {
                this.getCurrentPlayer().stop();
                this.getCurrentPlayer().releaseDrm();
                return;
            }
        }

        void reset() {
            synchronized (this) {
                MediaPlayerSource mediaPlayerSource = this.mQueue.get(0);
                mediaPlayerSource.mPlayer.reset();
                mediaPlayerSource.mBufferedPercentage.set(0);
                this.mVolume = Float.valueOf(1.0f);
                this.mSurface = null;
                this.mAuxEffect = null;
                this.mAuxEffectSendLevel = null;
                this.mAudioAttributes = null;
                this.mAudioSessionId = null;
                this.mSyncParams = null;
                this.mPlaybackParams = null;
                this.setMp2State(mediaPlayerSource.mPlayer, 1001);
                this.setBufferingState(mediaPlayerSource.mPlayer, 0);
                return;
            }
        }

        void restoreKeys(byte[] byArray) throws MediaPlayer.NoDrmSchemeException {
            synchronized (this) {
                this.getCurrentPlayer().restoreKeys(byArray);
                return;
            }
        }

        void seekTo(long l, int n) {
            synchronized (this) {
                this.getCurrentPlayer().seekTo(l, n);
                return;
            }
        }

        void selectTrack(int n) {
            synchronized (this) {
                this.getCurrentPlayer().selectTrack(n);
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        void setAudioAttributes(AudioAttributesCompat audioAttributesCompat) {
            synchronized (this) {
                this.mAudioAttributes = audioAttributesCompat;
                audioAttributesCompat = audioAttributesCompat == null ? null : (AudioAttributes)audioAttributesCompat.unwrap();
                this.getCurrentPlayer().setAudioAttributes((AudioAttributes)audioAttributesCompat);
                return;
            }
        }

        void setAudioSessionId(int n) {
            synchronized (this) {
                this.getCurrentPlayer().setAudioSessionId(n);
                return;
            }
        }

        void setAuxEffectSendLevel(float f) {
            synchronized (this) {
                this.getCurrentPlayer().setAuxEffectSendLevel(f);
                this.mAuxEffectSendLevel = Float.valueOf(f);
                return;
            }
        }

        /*
         * WARNING - void declaration
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        void setBufferingState(MediaPlayer object, int n) {
            synchronized (this) {
                void var2_2;
                MediaPlayerSource mediaPlayerSource;
                Object object2 = this.mQueue.iterator();
                do {
                    if (!object2.hasNext()) {
                        return;
                    }
                    mediaPlayerSource = object2.next();
                } while (mediaPlayerSource.mPlayer != object);
                int n2 = mediaPlayerSource.mBufferingState;
                if (n2 == var2_2) {
                    return;
                }
                mediaPlayerSource.mBufferingState = var2_2;
                object2 = MediaPlayer2Impl.this;
                object = new PlayerEventNotifier((int)var2_2){
                    final /* synthetic */ int val$state;
                    {
                        this.val$state = n;
                    }

                    @Override
                    public void notify(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
                        DataSourceDesc dataSourceDesc = mediaPlayerSource.getDSD();
                        playerEventCallback.onBufferingStateChanged(MediaPlayer2Impl.this.mBaseMediaPlayerImpl, dataSourceDesc, this.val$state);
                    }
                };
                ((MediaPlayer2Impl)object2).notifyPlayerEvent((PlayerEventNotifier)object);
                return;
            }
        }

        void setDrmPropertyString(String string2, String string3) throws MediaPlayer.NoDrmSchemeException {
            synchronized (this) {
                this.getCurrentPlayer().setDrmPropertyString(string2, string3);
                return;
            }
        }

        void setFirst(DataSourceDesc dataSourceDesc) throws IOException {
            synchronized (this) {
                if (this.mQueue.isEmpty()) {
                    List<MediaPlayerSource> list = this.mQueue;
                    MediaPlayerSource mediaPlayerSource = new MediaPlayerSource(dataSourceDesc);
                    list.add(0, mediaPlayerSource);
                } else {
                    this.mQueue.get((int)0).mDSD = dataSourceDesc;
                    MediaPlayer2Impl.this.setUpListeners(this.mQueue.get(0));
                }
                MediaPlayer2Impl.handleDataSource(this.mQueue.get(0));
                return;
            }
        }

        void setLooping(boolean bl) {
            synchronized (this) {
                this.getCurrentPlayer().setLooping(bl);
                return;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        void setMp2State(MediaPlayer object, int n) {
            synchronized (this) {
                int n2;
                MediaPlayerSource mediaPlayerSource;
                PlayerEventNotifier playerEventNotifier = this.mQueue.iterator();
                do {
                    if (!playerEventNotifier.hasNext()) {
                        return;
                    }
                    mediaPlayerSource = playerEventNotifier.next();
                } while (mediaPlayerSource.mPlayer != object);
                int n3 = mediaPlayerSource.mMp2State;
                if (n3 == n2) {
                    return;
                }
                mediaPlayerSource.mMp2State = n2;
                n3 = mediaPlayerSource.mPlayerState;
                n2 = (Integer)sStateMap.get(n2);
                if (n3 == n2) {
                    return;
                }
                mediaPlayerSource.mPlayerState = n2;
                object = MediaPlayer2Impl.this;
                playerEventNotifier = new PlayerEventNotifier(){

                    @Override
                    public void notify(BaseMediaPlayer.PlayerEventCallback playerEventCallback) {
                        playerEventCallback.onPlayerStateChanged(MediaPlayer2Impl.this.mBaseMediaPlayerImpl, n2);
                    }
                };
                ((MediaPlayer2Impl)object).notifyPlayerEvent(playerEventNotifier);
                return;
            }
        }

        DataSourceError setNext(DataSourceDesc object) {
            synchronized (this) {
                MediaPlayerSource mediaPlayerSource;
                block4: {
                    mediaPlayerSource = new MediaPlayerSource((DataSourceDesc)object);
                    if (!this.mQueue.isEmpty()) break block4;
                    this.mQueue.add(mediaPlayerSource);
                    object = this.prepareAt(0);
                    return object;
                }
                this.mQueue.add(1, mediaPlayerSource);
                object = this.prepareAt(1);
                return object;
            }
        }

        DataSourceError setNextMultiple(List<DataSourceDesc> object) {
            synchronized (this) {
                ArrayList<MediaPlayerSource> arrayList;
                block5: {
                    arrayList = new ArrayList<MediaPlayerSource>();
                    Iterator<DataSourceDesc> iterator2 = object.iterator();
                    while (iterator2.hasNext()) {
                        object = iterator2.next();
                        MediaPlayerSource mediaPlayerSource = new MediaPlayerSource((DataSourceDesc)object);
                        arrayList.add(mediaPlayerSource);
                    }
                    if (!this.mQueue.isEmpty()) break block5;
                    this.mQueue.addAll(arrayList);
                    object = this.prepareAt(0);
                    return object;
                }
                this.mQueue.addAll(1, arrayList);
                object = this.prepareAt(1);
                return object;
            }
        }

        void setOnDrmConfigHelper(MediaPlayer.OnDrmConfigHelper onDrmConfigHelper) {
            synchronized (this) {
                this.getCurrentPlayer().setOnDrmConfigHelper(onDrmConfigHelper);
                return;
            }
        }

        void setPlaybackParams(PlaybackParams playbackParams) {
            synchronized (this) {
                this.getCurrentPlayer().setPlaybackParams(playbackParams);
                this.mPlaybackParams = playbackParams;
                return;
            }
        }

        void setSurface(Surface surface) {
            synchronized (this) {
                this.mSurface = surface;
                this.getCurrentPlayer().setSurface(surface);
                return;
            }
        }

        void setSyncParams(SyncParams syncParams) {
            synchronized (this) {
                this.getCurrentPlayer().setSyncParams(syncParams);
                this.mSyncParams = syncParams;
                return;
            }
        }

        void setVolume(float f) {
            synchronized (this) {
                this.mVolume = Float.valueOf(f);
                this.getCurrentPlayer().setVolume(f, f);
                return;
            }
        }

        void skipToNext() {
            synchronized (this) {
                if (this.mQueue.size() > 1) {
                    MediaPlayerSource mediaPlayerSource = this.mQueue.get(0);
                    this.moveToNext();
                    if (mediaPlayerSource.mPlayerState == 2 || mediaPlayerSource.mPlayPending) {
                        this.playCurrent();
                    }
                    return;
                }
                IllegalStateException illegalStateException = new IllegalStateException("No next source available");
                throw illegalStateException;
            }
        }
    }

    private static interface Mp2EventNotifier {
        public void notify(MediaPlayer2.EventCallback var1);
    }

    public static final class NoDrmSchemeExceptionImpl
    extends MediaPlayer2.NoDrmSchemeException {
        public NoDrmSchemeExceptionImpl(String string2) {
            super(string2);
        }
    }

    private static interface PlayerEventNotifier {
        public void notify(BaseMediaPlayer.PlayerEventCallback var1);
    }

    public static final class ProvisioningNetworkErrorExceptionImpl
    extends MediaPlayer2.ProvisioningNetworkErrorException {
        public ProvisioningNetworkErrorExceptionImpl(String string2) {
            super(string2);
        }
    }

    public static final class ProvisioningServerErrorExceptionImpl
    extends MediaPlayer2.ProvisioningServerErrorException {
        public ProvisioningServerErrorExceptionImpl(String string2) {
            super(string2);
        }
    }

    private abstract class Task
    implements Runnable {
        private DataSourceDesc mDSD;
        private final int mMediaCallType;
        private final boolean mNeedToWaitForEventToComplete;

        Task(int n, boolean bl) {
            this.mMediaCallType = n;
            this.mNeedToWaitForEventToComplete = bl;
        }

        private void sendCompleteNotification(final int n) {
            if (this.mMediaCallType == 1003) {
                return;
            }
            MediaPlayer2Impl.this.notifyMediaPlayer2Event(new Mp2EventNotifier(){

                @Override
                public void notify(MediaPlayer2.EventCallback eventCallback) {
                    eventCallback.onCallCompleted(MediaPlayer2Impl.this, Task.this.mDSD, Task.this.mMediaCallType, n);
                }
            });
        }

        abstract void process() throws IOException, MediaPlayer2.NoDrmSchemeException;

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public void run() {
            int n = 0;
            try {
                this.process();
            }
            catch (Exception exception) {
                n = Integer.MIN_VALUE;
            }
            catch (IOException iOException) {
                n = 4;
            }
            catch (SecurityException securityException) {
                n = 3;
            }
            catch (IllegalArgumentException illegalArgumentException) {
                n = 2;
            }
            catch (IllegalStateException illegalStateException) {
                n = 1;
            }
            this.mDSD = MediaPlayer2Impl.this.getCurrentDataSource();
            if (!this.mNeedToWaitForEventToComplete || n != 0) {
                this.sendCompleteNotification(n);
                Object object = MediaPlayer2Impl.this.mTaskLock;
                synchronized (object) {
                    MediaPlayer2Impl.access$902(MediaPlayer2Impl.this, null);
                    MediaPlayer2Impl.this.processPendingTask_l();
                }
            }
        }
    }

    public static final class TrackInfoImpl
    extends MediaPlayer2.TrackInfo {
        final MediaFormat mFormat;
        final int mTrackType;

        TrackInfoImpl(int n, MediaFormat mediaFormat) {
            this.mTrackType = n;
            this.mFormat = mediaFormat;
        }

        @Override
        public MediaFormat getFormat() {
            int n = this.mTrackType;
            if (n != 3 && n != 4) {
                return null;
            }
            return this.mFormat;
        }

        @Override
        public String getLanguage() {
            String string2;
            block0: {
                string2 = this.mFormat.getString("language");
                if (string2 != null) break block0;
                string2 = "und";
            }
            return string2;
        }

        @Override
        public int getTrackType() {
            return this.mTrackType;
        }

        @Override
        public String toString() {
            StringBuilder stringBuilder = new StringBuilder(128);
            stringBuilder.append(this.getClass().getName());
            stringBuilder.append('{');
            int n = this.mTrackType;
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        if (n != 4) {
                            stringBuilder.append("UNKNOWN");
                        } else {
                            stringBuilder.append("SUBTITLE");
                        }
                    } else {
                        stringBuilder.append("TIMEDTEXT");
                    }
                } else {
                    stringBuilder.append("AUDIO");
                }
            } else {
                stringBuilder.append("VIDEO");
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(", ");
            stringBuilder2.append(this.mFormat.toString());
            stringBuilder.append(stringBuilder2.toString());
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }
}

