/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.RemoteException
 *  android.os.ResultReceiver
 *  android.os.SystemClock
 *  android.support.mediacompat.Rating2
 *  android.text.TextUtils
 *  android.util.Log
 *  android.util.SparseArray
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.content.Context;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.mediacompat.Rating2;
import android.support.v4.media.IMediaController2;
import android.support.v4.media.IMediaSession2;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaLibraryService2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaUtils2;
import android.support.v4.media.SessionCommand2;
import android.support.v4.media.SessionCommandGroup2;
import android.support.v4.media.VolumeProviderCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class MediaSession2Stub
extends IMediaSession2.Stub {
    private static final boolean DEBUG = true;
    private static final String TAG = "MediaSession2Stub";
    private static final SparseArray<SessionCommand2> sCommandsForOnCommandRequest = new SparseArray();
    private final ArrayMap<MediaSession2.ControllerInfo, SessionCommandGroup2> mAllowedCommandGroupMap;
    private final Set<IBinder> mConnectingControllers;
    final Context mContext;
    private final ArrayMap<IBinder, MediaSession2.ControllerInfo> mControllers;
    private final Object mLock = new Object();
    final MediaSession2.SupportLibraryImpl mSession;

    static {
        SessionCommandGroup2 sessionCommandGroup2 = new SessionCommandGroup2();
        sessionCommandGroup2.addAllPlaybackCommands();
        sessionCommandGroup2.addAllPlaylistCommands();
        sessionCommandGroup2.addAllVolumeCommands();
        for (SessionCommand2 sessionCommand2 : sessionCommandGroup2.getCommands()) {
            sCommandsForOnCommandRequest.append(sessionCommand2.getCommandCode(), (Object)sessionCommand2);
        }
    }

    MediaSession2Stub(MediaSession2.SupportLibraryImpl supportLibraryImpl) {
        this.mControllers = new ArrayMap();
        this.mConnectingControllers = new HashSet<IBinder>();
        this.mAllowedCommandGroupMap = new ArrayMap();
        this.mSession = supportLibraryImpl;
        this.mContext = supportLibraryImpl.getContext();
    }

    private MediaLibraryService2.MediaLibrarySession.SupportLibraryImpl getLibrarySession() {
        MediaSession2.SupportLibraryImpl supportLibraryImpl = this.mSession;
        if (supportLibraryImpl instanceof MediaLibraryService2.MediaLibrarySession.SupportLibraryImpl) {
            return (MediaLibraryService2.MediaLibrarySession.SupportLibraryImpl)supportLibraryImpl;
        }
        throw new RuntimeException("Session cannot be casted to library session");
    }

    /*
     * WARNING - void declaration
     */
    private boolean isAllowedCommand(MediaSession2.ControllerInfo object, int n) {
        Object object2 = this.mLock;
        synchronized (object2) {
            try {
                object = (SessionCommandGroup2)this.mAllowedCommandGroupMap.get(object);
                // MONITOREXIT @DISABLED, blocks:[0, 2] lbl5 : MonitorExitStatement: MONITOREXIT : var3_6
                boolean bl = object != null && ((SessionCommandGroup2)object).hasCommand(n);
                return bl;
            }
            catch (Throwable throwable) {
                while (true) {
                    void var1_3;
                    try {}
                    catch (Throwable throwable2) {
                        continue;
                    }
                    throw var1_3;
                }
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    private boolean isAllowedCommand(MediaSession2.ControllerInfo object, SessionCommand2 sessionCommand2) {
        Object object2 = this.mLock;
        synchronized (object2) {
            try {
                object = (SessionCommandGroup2)this.mAllowedCommandGroupMap.get(object);
                // MONITOREXIT @DISABLED, blocks:[0, 2] lbl5 : MonitorExitStatement: MONITOREXIT : var3_6
                boolean bl = object != null && ((SessionCommandGroup2)object).hasCommand(sessionCommand2);
                return bl;
            }
            catch (Throwable throwable) {
                while (true) {
                    void var1_3;
                    try {}
                    catch (Throwable throwable2) {
                        continue;
                    }
                    throw var1_3;
                }
            }
        }
    }

    private void onBrowserCommand(IMediaController2 iMediaController2, int n, SessionRunnable sessionRunnable) {
        if (this.mSession instanceof MediaLibraryService2.MediaLibrarySession.SupportLibraryImpl) {
            this.onSessionCommandInternal(iMediaController2, null, n, sessionRunnable);
            return;
        }
        throw new RuntimeException("MediaSession2 cannot handle MediaLibrarySession command");
    }

    private void onSessionCommand(IMediaController2 iMediaController2, int n, SessionRunnable sessionRunnable) {
        this.onSessionCommandInternal(iMediaController2, null, n, sessionRunnable);
    }

    private void onSessionCommand(IMediaController2 iMediaController2, SessionCommand2 sessionCommand2, SessionRunnable sessionRunnable) {
        this.onSessionCommandInternal(iMediaController2, sessionCommand2, 0, sessionRunnable);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void onSessionCommandInternal(IMediaController2 object, SessionCommand2 sessionCommand2, int n, SessionRunnable sessionRunnable) {
        Object object2 = this.mLock;
        synchronized (object2) {
            Object var6_6 = null;
            object = object == null ? var6_6 : (MediaSession2.ControllerInfo)this.mControllers.get(object.asBinder());
        }
        if (this.mSession.isClosed()) return;
        if (object == null) {
            return;
        }
        this.mSession.getCallbackExecutor().execute(new Runnable((MediaSession2.ControllerInfo)object, sessionCommand2, n, sessionRunnable){
            final /* synthetic */ int val$commandCode;
            final /* synthetic */ MediaSession2.ControllerInfo val$controller;
            final /* synthetic */ SessionRunnable val$runnable;
            final /* synthetic */ SessionCommand2 val$sessionCommand;
            {
                this.val$controller = controllerInfo;
                this.val$sessionCommand = sessionCommand2;
                this.val$commandCode = n;
                this.val$runnable = sessionRunnable;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void run() {
                Object object = MediaSession2Stub.this.mLock;
                synchronized (object) {
                    if (!MediaSession2Stub.this.mControllers.containsValue(this.val$controller)) {
                        return;
                    }
                }
                object = this.val$sessionCommand;
                if (object != null) {
                    if (!MediaSession2Stub.this.isAllowedCommand(this.val$controller, (SessionCommand2)object)) {
                        return;
                    }
                    object = (SessionCommand2)sCommandsForOnCommandRequest.get(this.val$sessionCommand.getCommandCode());
                } else {
                    if (!MediaSession2Stub.this.isAllowedCommand(this.val$controller, this.val$commandCode)) {
                        return;
                    }
                    object = (SessionCommand2)sCommandsForOnCommandRequest.get(this.val$commandCode);
                }
                if (object != null && !MediaSession2Stub.this.mSession.getCallback().onCommandRequest(MediaSession2Stub.this.mSession.getInstance(), this.val$controller, (SessionCommand2)object)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Command (");
                    stringBuilder.append(object);
                    stringBuilder.append(") from ");
                    stringBuilder.append(this.val$controller);
                    stringBuilder.append(" was rejected by ");
                    stringBuilder.append(MediaSession2Stub.this.mSession);
                    Log.d((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                try {
                    this.val$runnable.run(this.val$controller);
                    return;
                }
                catch (RemoteException remoteException) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("Exception in ");
                    ((StringBuilder)object).append(this.val$controller.toString());
                    Log.w((String)MediaSession2Stub.TAG, (String)((StringBuilder)object).toString(), (Throwable)remoteException);
                }
            }
        });
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void releaseController(IMediaController2 object) {
        Object object2 = this.mLock;
        synchronized (object2) {
            object = (MediaSession2.ControllerInfo)this.mControllers.remove(object.asBinder());
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("releasing ");
                stringBuilder.append(object);
                Log.d((String)TAG, (String)stringBuilder.toString());
                // MONITOREXIT @DISABLED, blocks:[1, 3] lbl12 : MonitorExitStatement: MONITOREXIT : var2_3
                if (this.mSession.isClosed()) return;
                if (object == null) {
                    return;
                }
                this.mSession.getCallbackExecutor().execute(new Runnable((MediaSession2.ControllerInfo)object){
                    final /* synthetic */ MediaSession2.ControllerInfo val$controller;
                    {
                        this.val$controller = controllerInfo;
                    }

                    @Override
                    public void run() {
                        MediaSession2Stub.this.mSession.getCallback().onDisconnected(MediaSession2Stub.this.mSession.getInstance(), this.val$controller);
                    }
                });
                return;
            }
            catch (Throwable throwable) {}
            throw throwable;
        }
    }

    @Override
    public void addPlaylistItem(IMediaController2 iMediaController2, final int n, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 15, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getInstance().addPlaylistItem(n, MediaItem2.fromBundle(bundle, null));
            }
        });
    }

    @Override
    public void adjustVolume(IMediaController2 iMediaController2, final int n, final int n2) throws RuntimeException {
        this.onSessionCommand(iMediaController2, 11, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo object) throws RemoteException {
                object = MediaSession2Stub.this.mSession.getVolumeProvider();
                if (object == null) {
                    object = MediaSession2Stub.this.mSession.getSessionCompat();
                    if (object != null) {
                        ((MediaSessionCompat)object).getController().adjustVolume(n, n2);
                    }
                } else {
                    ((VolumeProviderCompat)object).onAdjustVolume(n);
                }
            }
        });
    }

    @Override
    public void connect(IMediaController2 iMediaController2, String object) throws RuntimeException {
        object = new MediaSession2.ControllerInfo((String)object, Binder.getCallingPid(), Binder.getCallingUid(), new Controller2Cb(iMediaController2));
        this.mSession.getCallbackExecutor().execute(new Runnable((MediaSession2.ControllerInfo)object, iMediaController2){
            final /* synthetic */ IMediaController2 val$caller;
            final /* synthetic */ MediaSession2.ControllerInfo val$controllerInfo;
            {
                this.val$controllerInfo = controllerInfo;
                this.val$caller = iMediaController2;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void run() {
                if (MediaSession2Stub.this.mSession.isClosed()) {
                    return;
                }
                Object object = MediaSession2Stub.this.mLock;
                synchronized (object) {
                    MediaSession2Stub.this.mConnectingControllers.add(this.val$controllerInfo.getId());
                }
                object = MediaSession2Stub.this.mSession.getCallback().onConnect(MediaSession2Stub.this.mSession.getInstance(), this.val$controllerInfo);
                int n = object == null && !this.val$controllerInfo.isTrusted() ? 0 : 1;
                if (n != 0) {
                    Object object2 = new StringBuilder();
                    ((StringBuilder)object2).append("Accepting connection, controllerInfo=");
                    ((StringBuilder)object2).append(this.val$controllerInfo);
                    ((StringBuilder)object2).append(" allowedCommands=");
                    ((StringBuilder)object2).append(object);
                    Log.d((String)MediaSession2Stub.TAG, (String)((StringBuilder)object2).toString());
                    if (object == null) {
                        object = new SessionCommandGroup2();
                    }
                    object2 = MediaSession2Stub.this.mLock;
                    synchronized (object2) {
                        MediaSession2Stub.this.mConnectingControllers.remove(this.val$controllerInfo.getId());
                        MediaSession2Stub.this.mControllers.put(this.val$controllerInfo.getId(), this.val$controllerInfo);
                        MediaSession2Stub.this.mAllowedCommandGroupMap.put(this.val$controllerInfo, object);
                    }
                    int n2 = MediaSession2Stub.this.mSession.getPlayerState();
                    object2 = MediaSession2Stub.this.mSession.getCurrentMediaItem();
                    List<Object> list = null;
                    object2 = object2 == null ? null : MediaSession2Stub.this.mSession.getCurrentMediaItem().toBundle();
                    long l = SystemClock.elapsedRealtime();
                    long l2 = MediaSession2Stub.this.mSession.getCurrentPosition();
                    float f = MediaSession2Stub.this.mSession.getPlaybackSpeed();
                    long l3 = MediaSession2Stub.this.mSession.getBufferedPosition();
                    Bundle bundle = MediaSession2Stub.this.mSession.getPlaybackInfo().toBundle();
                    int n3 = MediaSession2Stub.this.mSession.getRepeatMode();
                    n = MediaSession2Stub.this.mSession.getShuffleMode();
                    PendingIntent pendingIntent = MediaSession2Stub.this.mSession.getSessionActivity();
                    if (((SessionCommandGroup2)object).hasCommand(18)) {
                        list = MediaSession2Stub.this.mSession.getPlaylist();
                    }
                    list = MediaUtils2.convertMediaItem2ListToBundleList(list);
                    if (MediaSession2Stub.this.mSession.isClosed()) {
                        return;
                    }
                    try {
                        this.val$caller.onConnected(MediaSession2Stub.this, ((SessionCommandGroup2)object).toBundle(), n2, (Bundle)object2, l, l2, f, l3, bundle, n3, n, list, pendingIntent);
                        return;
                    }
                    catch (RemoteException remoteException) {
                        return;
                    }
                }
                object = MediaSession2Stub.this.mLock;
                synchronized (object) {
                    MediaSession2Stub.this.mConnectingControllers.remove(this.val$controllerInfo.getId());
                }
                object = new StringBuilder();
                ((StringBuilder)object).append("Rejecting connection, controllerInfo=");
                ((StringBuilder)object).append(this.val$controllerInfo);
                Log.d((String)MediaSession2Stub.TAG, (String)((StringBuilder)object).toString());
                try {
                    this.val$caller.onDisconnected();
                    return;
                }
                catch (RemoteException remoteException) {
                    // empty catch block
                }
            }
        });
    }

    @Override
    public void fastForward(IMediaController2 iMediaController2) {
        this.onSessionCommand(iMediaController2, 7, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getCallback().onFastForward(MediaSession2Stub.this.mSession.getInstance(), controllerInfo);
            }
        });
    }

    @Override
    public void getChildren(IMediaController2 iMediaController2, final String string2, final int n, final int n2, final Bundle bundle) throws RuntimeException {
        this.onBrowserCommand(iMediaController2, 29, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (string2 == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("getChildren(): Ignoring null parentId from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                if (n >= 1 && n2 >= 1) {
                    MediaSession2Stub.this.getLibrarySession().onGetChildrenOnExecutor(controllerInfo, string2, n, n2, bundle);
                    return;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("getChildren(): Ignoring page nor pageSize less than 1 from ");
                stringBuilder.append(controllerInfo);
                Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    List<MediaSession2.ControllerInfo> getConnectedControllers() {
        ArrayList<MediaSession2.ControllerInfo> arrayList = new ArrayList<MediaSession2.ControllerInfo>();
        Object object = this.mLock;
        synchronized (object) {
            int n = 0;
            while (n < this.mControllers.size()) {
                arrayList.add((MediaSession2.ControllerInfo)this.mControllers.valueAt(n));
                ++n;
            }
            return arrayList;
        }
    }

    @Override
    public void getItem(IMediaController2 iMediaController2, final String string2) throws RuntimeException {
        this.onBrowserCommand(iMediaController2, 30, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (string2 == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("getItem(): Ignoring null mediaId from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.getLibrarySession().onGetItemOnExecutor(controllerInfo, string2);
            }
        });
    }

    @Override
    public void getLibraryRoot(IMediaController2 iMediaController2, final Bundle bundle) throws RuntimeException {
        this.onBrowserCommand(iMediaController2, 31, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.getLibrarySession().onGetLibraryRootOnExecutor(controllerInfo, bundle);
            }
        });
    }

    @Override
    public void getSearchResult(IMediaController2 iMediaController2, final String string2, final int n, final int n2, final Bundle bundle) {
        this.onBrowserCommand(iMediaController2, 32, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (TextUtils.isEmpty((CharSequence)string2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("getSearchResult(): Ignoring empty query from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                if (n >= 1 && n2 >= 1) {
                    MediaSession2Stub.this.getLibrarySession().onGetSearchResultOnExecutor(controllerInfo, string2, n, n2, bundle);
                    return;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("getSearchResult(): Ignoring page nor pageSize less than 1  from ");
                stringBuilder.append(controllerInfo);
                Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
            }
        });
    }

    @Override
    public void pause(IMediaController2 iMediaController2) throws RuntimeException {
        this.onSessionCommand(iMediaController2, 2, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.pause();
            }
        });
    }

    @Override
    public void play(IMediaController2 iMediaController2) throws RuntimeException {
        this.onSessionCommand(iMediaController2, 1, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.play();
            }
        });
    }

    @Override
    public void playFromMediaId(IMediaController2 iMediaController2, final String string2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 22, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (string2 == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("playFromMediaId(): Ignoring null mediaId from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.mSession.getCallback().onPlayFromMediaId(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, string2, bundle);
            }
        });
    }

    @Override
    public void playFromSearch(IMediaController2 iMediaController2, final String string2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 24, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (TextUtils.isEmpty((CharSequence)string2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("playFromSearch(): Ignoring empty query from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.mSession.getCallback().onPlayFromSearch(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, string2, bundle);
            }
        });
    }

    @Override
    public void playFromUri(IMediaController2 iMediaController2, final Uri uri, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 23, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (uri == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("playFromUri(): Ignoring null uri from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.mSession.getCallback().onPlayFromUri(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, uri, bundle);
            }
        });
    }

    @Override
    public void prepare(IMediaController2 iMediaController2) throws RuntimeException {
        this.onSessionCommand(iMediaController2, 6, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.prepare();
            }
        });
    }

    @Override
    public void prepareFromMediaId(IMediaController2 iMediaController2, final String string2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 25, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (string2 == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("prepareFromMediaId(): Ignoring null mediaId from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.mSession.getCallback().onPrepareFromMediaId(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, string2, bundle);
            }
        });
    }

    @Override
    public void prepareFromSearch(IMediaController2 iMediaController2, final String string2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 27, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (TextUtils.isEmpty((CharSequence)string2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("prepareFromSearch(): Ignoring empty query from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.mSession.getCallback().onPrepareFromSearch(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, string2, bundle);
            }
        });
    }

    @Override
    public void prepareFromUri(IMediaController2 iMediaController2, final Uri uri, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 26, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (uri == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("prepareFromUri(): Ignoring null uri from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.mSession.getCallback().onPrepareFromUri(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, uri, bundle);
            }
        });
    }

    @Override
    public void release(IMediaController2 iMediaController2) throws RemoteException {
        this.releaseController(iMediaController2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void removeControllerInfo(MediaSession2.ControllerInfo controllerInfo) {
        Object object = this.mLock;
        synchronized (object) {
            controllerInfo = (MediaSession2.ControllerInfo)this.mControllers.remove(controllerInfo.getId());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("releasing ");
            stringBuilder.append(controllerInfo);
            Log.d((String)TAG, (String)stringBuilder.toString());
            return;
        }
    }

    @Override
    public void removePlaylistItem(IMediaController2 iMediaController2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 16, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo object) throws RemoteException {
                object = MediaItem2.fromBundle(bundle);
                MediaSession2Stub.this.mSession.getInstance().removePlaylistItem((MediaItem2)object);
            }
        });
    }

    @Override
    public void replacePlaylistItem(IMediaController2 iMediaController2, final int n, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 17, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getInstance().replacePlaylistItem(n, MediaItem2.fromBundle(bundle, null));
            }
        });
    }

    @Override
    public void reset(IMediaController2 iMediaController2) throws RuntimeException {
        this.onSessionCommand(iMediaController2, 3, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.reset();
            }
        });
    }

    @Override
    public void rewind(IMediaController2 iMediaController2) {
        this.onSessionCommand(iMediaController2, 8, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getCallback().onRewind(MediaSession2Stub.this.mSession.getInstance(), controllerInfo);
            }
        });
    }

    @Override
    public void search(IMediaController2 iMediaController2, final String string2, final Bundle bundle) {
        this.onBrowserCommand(iMediaController2, 33, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (TextUtils.isEmpty((CharSequence)string2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("search(): Ignoring empty query from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.getLibrarySession().onSearchOnExecutor(controllerInfo, string2, bundle);
            }
        });
    }

    @Override
    public void seekTo(IMediaController2 iMediaController2, final long l) throws RuntimeException {
        this.onSessionCommand(iMediaController2, 9, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.seekTo(l);
            }
        });
    }

    @Override
    public void selectRoute(IMediaController2 iMediaController2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 37, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getCallback().onSelectRoute(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, bundle);
            }
        });
    }

    @Override
    public void sendCustomCommand(IMediaController2 iMediaController2, Bundle bundle, final Bundle bundle2, final ResultReceiver resultReceiver) {
        final SessionCommand2 sessionCommand2 = SessionCommand2.fromBundle(bundle);
        this.onSessionCommand(iMediaController2, SessionCommand2.fromBundle(bundle), new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getCallback().onCustomCommand(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, sessionCommand2, bundle2, resultReceiver);
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void setAllowedCommands(MediaSession2.ControllerInfo controllerInfo, SessionCommandGroup2 sessionCommandGroup2) {
        Object object = this.mLock;
        synchronized (object) {
            this.mAllowedCommandGroupMap.put(controllerInfo, sessionCommandGroup2);
            return;
        }
    }

    @Override
    public void setPlaybackSpeed(IMediaController2 iMediaController2, final float f) {
        this.onSessionCommand(iMediaController2, 39, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getInstance().setPlaybackSpeed(f);
            }
        });
    }

    @Override
    public void setPlaylist(IMediaController2 iMediaController2, final List<Bundle> list, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 19, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (list == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("setPlaylist(): Ignoring null playlist from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.mSession.getInstance().setPlaylist(MediaUtils2.convertBundleListToMediaItem2List(list), MediaMetadata2.fromBundle(bundle));
            }
        });
    }

    @Override
    public void setRating(IMediaController2 iMediaController2, final String string2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 28, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (string2 == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("setRating(): Ignoring null mediaId from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                Object object = bundle;
                if (object == null) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("setRating(): Ignoring null ratingBundle from ");
                    ((StringBuilder)object).append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)((StringBuilder)object).toString());
                    return;
                }
                if ((object = Rating2.fromBundle((Bundle)object)) == null) {
                    if (bundle == null) {
                        object = new StringBuilder();
                        ((StringBuilder)object).append("setRating(): Ignoring null rating from ");
                        ((StringBuilder)object).append(controllerInfo);
                        Log.w((String)MediaSession2Stub.TAG, (String)((StringBuilder)object).toString());
                        return;
                    }
                    return;
                }
                MediaSession2Stub.this.mSession.getCallback().onSetRating(MediaSession2Stub.this.mSession.getInstance(), controllerInfo, string2, (Rating2)object);
            }
        });
    }

    @Override
    public void setRepeatMode(IMediaController2 iMediaController2, final int n) {
        this.onSessionCommand(iMediaController2, 14, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getInstance().setRepeatMode(n);
            }
        });
    }

    @Override
    public void setShuffleMode(IMediaController2 iMediaController2, final int n) {
        this.onSessionCommand(iMediaController2, 13, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getInstance().setShuffleMode(n);
            }
        });
    }

    @Override
    public void setVolumeTo(IMediaController2 iMediaController2, final int n, final int n2) throws RuntimeException {
        this.onSessionCommand(iMediaController2, 10, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo object) throws RemoteException {
                object = MediaSession2Stub.this.mSession.getVolumeProvider();
                if (object == null) {
                    object = MediaSession2Stub.this.mSession.getSessionCompat();
                    if (object != null) {
                        ((MediaSessionCompat)object).getController().setVolumeTo(n, n2);
                    }
                } else {
                    ((VolumeProviderCompat)object).onSetVolumeTo(n);
                }
            }
        });
    }

    @Override
    public void skipToNextItem(IMediaController2 iMediaController2) {
        this.onSessionCommand(iMediaController2, 4, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getInstance().skipToNextItem();
            }
        });
    }

    @Override
    public void skipToPlaylistItem(IMediaController2 iMediaController2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 12, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (bundle == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("skipToPlaylistItem(): Ignoring null mediaItem from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                }
                MediaSession2Stub.this.mSession.getInstance().skipToPlaylistItem(MediaItem2.fromBundle(bundle));
            }
        });
    }

    @Override
    public void skipToPreviousItem(IMediaController2 iMediaController2) {
        this.onSessionCommand(iMediaController2, 5, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getInstance().skipToPreviousItem();
            }
        });
    }

    @Override
    public void subscribe(IMediaController2 iMediaController2, final String string2, final Bundle bundle) {
        this.onBrowserCommand(iMediaController2, 34, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (string2 == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("subscribe(): Ignoring null parentId from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.getLibrarySession().onSubscribeOnExecutor(controllerInfo, string2, bundle);
            }
        });
    }

    @Override
    public void subscribeRoutesInfo(IMediaController2 iMediaController2) {
        this.onSessionCommand(iMediaController2, 36, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getCallback().onSubscribeRoutesInfo(MediaSession2Stub.this.mSession.getInstance(), controllerInfo);
            }
        });
    }

    @Override
    public void unsubscribe(IMediaController2 iMediaController2, final String string2) {
        this.onBrowserCommand(iMediaController2, 35, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                if (string2 == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("unsubscribe(): Ignoring null parentId from ");
                    stringBuilder.append(controllerInfo);
                    Log.w((String)MediaSession2Stub.TAG, (String)stringBuilder.toString());
                    return;
                }
                MediaSession2Stub.this.getLibrarySession().onUnsubscribeOnExecutor(controllerInfo, string2);
            }
        });
    }

    @Override
    public void unsubscribeRoutesInfo(IMediaController2 iMediaController2) {
        this.onSessionCommand(iMediaController2, 37, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getCallback().onUnsubscribeRoutesInfo(MediaSession2Stub.this.mSession.getInstance(), controllerInfo);
            }
        });
    }

    @Override
    public void updatePlaylistMetadata(IMediaController2 iMediaController2, final Bundle bundle) {
        this.onSessionCommand(iMediaController2, 21, new SessionRunnable(){

            @Override
            public void run(MediaSession2.ControllerInfo controllerInfo) throws RemoteException {
                MediaSession2Stub.this.mSession.getInstance().updatePlaylistMetadata(MediaMetadata2.fromBundle(bundle));
            }
        });
    }

    static final class Controller2Cb
    extends MediaSession2.ControllerCb {
        private final IMediaController2 mIControllerCallback;

        Controller2Cb(IMediaController2 iMediaController2) {
            this.mIControllerCallback = iMediaController2;
        }

        @Override
        IBinder getId() {
            return this.mIControllerCallback.asBinder();
        }

        @Override
        void onAllowedCommandsChanged(SessionCommandGroup2 sessionCommandGroup2) throws RemoteException {
            this.mIControllerCallback.onAllowedCommandsChanged(sessionCommandGroup2.toBundle());
        }

        @Override
        void onBufferingStateChanged(MediaItem2 mediaItem2, int n, long l) throws RemoteException {
            IMediaController2 iMediaController2 = this.mIControllerCallback;
            mediaItem2 = mediaItem2 == null ? null : mediaItem2.toBundle();
            iMediaController2.onBufferingStateChanged((Bundle)mediaItem2, n, l);
        }

        @Override
        void onChildrenChanged(String string2, int n, Bundle bundle) throws RemoteException {
            this.mIControllerCallback.onChildrenChanged(string2, n, bundle);
        }

        @Override
        void onCurrentMediaItemChanged(MediaItem2 mediaItem2) throws RemoteException {
            IMediaController2 iMediaController2 = this.mIControllerCallback;
            mediaItem2 = mediaItem2 == null ? null : mediaItem2.toBundle();
            iMediaController2.onCurrentMediaItemChanged((Bundle)mediaItem2);
        }

        @Override
        void onCustomCommand(SessionCommand2 sessionCommand2, Bundle bundle, ResultReceiver resultReceiver) throws RemoteException {
            this.mIControllerCallback.onCustomCommand(sessionCommand2.toBundle(), bundle, resultReceiver);
        }

        @Override
        void onCustomLayoutChanged(List<MediaSession2.CommandButton> list) throws RemoteException {
            this.mIControllerCallback.onCustomLayoutChanged(MediaUtils2.convertCommandButtonListToBundleList(list));
        }

        @Override
        void onDisconnected() throws RemoteException {
            this.mIControllerCallback.onDisconnected();
        }

        @Override
        void onError(int n, Bundle bundle) throws RemoteException {
            this.mIControllerCallback.onError(n, bundle);
        }

        @Override
        void onGetChildrenDone(String string2, int n, int n2, List<MediaItem2> list, Bundle bundle) throws RemoteException {
            list = MediaUtils2.convertMediaItem2ListToBundleList(list);
            this.mIControllerCallback.onGetChildrenDone(string2, n, n2, list, bundle);
        }

        @Override
        void onGetItemDone(String string2, MediaItem2 mediaItem2) throws RemoteException {
            IMediaController2 iMediaController2 = this.mIControllerCallback;
            mediaItem2 = mediaItem2 == null ? null : mediaItem2.toBundle();
            iMediaController2.onGetItemDone(string2, (Bundle)mediaItem2);
        }

        @Override
        void onGetLibraryRootDone(Bundle bundle, String string2, Bundle bundle2) throws RemoteException {
            this.mIControllerCallback.onGetLibraryRootDone(bundle, string2, bundle2);
        }

        @Override
        void onGetSearchResultDone(String string2, int n, int n2, List<MediaItem2> list, Bundle bundle) throws RemoteException {
            list = MediaUtils2.convertMediaItem2ListToBundleList(list);
            this.mIControllerCallback.onGetSearchResultDone(string2, n, n2, list, bundle);
        }

        @Override
        void onPlaybackInfoChanged(MediaController2.PlaybackInfo playbackInfo) throws RemoteException {
            this.mIControllerCallback.onPlaybackInfoChanged(playbackInfo.toBundle());
        }

        @Override
        void onPlaybackSpeedChanged(long l, long l2, float f) throws RemoteException {
            this.mIControllerCallback.onPlaybackSpeedChanged(l, l2, f);
        }

        @Override
        void onPlayerStateChanged(long l, long l2, int n) throws RemoteException {
            this.mIControllerCallback.onPlayerStateChanged(l, l2, n);
        }

        @Override
        void onPlaylistChanged(List<MediaItem2> object, MediaMetadata2 mediaMetadata2) throws RemoteException {
            IMediaController2 iMediaController2 = this.mIControllerCallback;
            List<Bundle> list = MediaUtils2.convertMediaItem2ListToBundleList(object);
            object = mediaMetadata2 == null ? null : mediaMetadata2.toBundle();
            iMediaController2.onPlaylistChanged(list, (Bundle)object);
        }

        @Override
        void onPlaylistMetadataChanged(MediaMetadata2 mediaMetadata2) throws RemoteException {
            this.mIControllerCallback.onPlaylistMetadataChanged(mediaMetadata2.toBundle());
        }

        @Override
        void onRepeatModeChanged(int n) throws RemoteException {
            this.mIControllerCallback.onRepeatModeChanged(n);
        }

        @Override
        void onRoutesInfoChanged(List<Bundle> list) throws RemoteException {
            this.mIControllerCallback.onRoutesInfoChanged(list);
        }

        @Override
        void onSearchResultChanged(String string2, int n, Bundle bundle) throws RemoteException {
            this.mIControllerCallback.onSearchResultChanged(string2, n, bundle);
        }

        @Override
        void onSeekCompleted(long l, long l2, long l3) throws RemoteException {
            this.mIControllerCallback.onSeekCompleted(l, l2, l3);
        }

        @Override
        void onShuffleModeChanged(int n) throws RemoteException {
            this.mIControllerCallback.onShuffleModeChanged(n);
        }
    }

    @FunctionalInterface
    private static interface SessionRunnable {
        public void run(MediaSession2.ControllerInfo var1) throws RemoteException;
    }
}

