/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.text.TextUtils
 */
package android.support.v4.media;

import android.os.Bundle;
import android.support.v4.media.DataSourceDesc;
import android.support.v4.media.MediaMetadata2;
import android.text.TextUtils;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.UUID;

public class MediaItem2 {
    public static final int FLAG_BROWSABLE = 1;
    public static final int FLAG_PLAYABLE = 2;
    private static final String KEY_FLAGS = "android.media.mediaitem2.flags";
    private static final String KEY_ID = "android.media.mediaitem2.id";
    private static final String KEY_METADATA = "android.media.mediaitem2.metadata";
    private static final String KEY_UUID = "android.media.mediaitem2.uuid";
    private DataSourceDesc mDataSourceDesc;
    private final int mFlags;
    private final String mId;
    private MediaMetadata2 mMetadata;
    private final UUID mUUID;

    private MediaItem2(String string2, DataSourceDesc dataSourceDesc, MediaMetadata2 mediaMetadata2, int n) {
        this(string2, dataSourceDesc, mediaMetadata2, n, (UUID)null);
    }

    private MediaItem2(String object, DataSourceDesc dataSourceDesc, MediaMetadata2 mediaMetadata2, int n, UUID uUID) {
        if (object != null) {
            if (mediaMetadata2 != null && !TextUtils.equals((CharSequence)object, (CharSequence)mediaMetadata2.getMediaId())) {
                throw new IllegalArgumentException("metadata's id should be matched with the mediaid");
            }
            this.mId = object;
            this.mDataSourceDesc = dataSourceDesc;
            this.mMetadata = mediaMetadata2;
            this.mFlags = n;
            object = uUID == null ? UUID.randomUUID() : uUID;
            this.mUUID = object;
            return;
        }
        throw new IllegalArgumentException("mediaId shouldn't be null");
    }

    public static MediaItem2 fromBundle(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        return MediaItem2.fromBundle(bundle, UUID.fromString(bundle.getString(KEY_UUID)));
    }

    static MediaItem2 fromBundle(Bundle bundle, UUID uUID) {
        MediaMetadata2 mediaMetadata2 = null;
        if (bundle == null) {
            return null;
        }
        String string2 = bundle.getString(KEY_ID);
        Bundle bundle2 = bundle.getBundle(KEY_METADATA);
        if (bundle2 != null) {
            mediaMetadata2 = MediaMetadata2.fromBundle(bundle2);
        }
        return new MediaItem2(string2, null, mediaMetadata2, bundle.getInt(KEY_FLAGS), uUID);
    }

    public boolean equals(Object object) {
        if (!(object instanceof MediaItem2)) {
            return false;
        }
        object = (MediaItem2)object;
        return this.mUUID.equals(((MediaItem2)object).mUUID);
    }

    public DataSourceDesc getDataSourceDesc() {
        return this.mDataSourceDesc;
    }

    public int getFlags() {
        return this.mFlags;
    }

    public String getMediaId() {
        return this.mId;
    }

    public MediaMetadata2 getMetadata() {
        return this.mMetadata;
    }

    public int hashCode() {
        return this.mUUID.hashCode();
    }

    public boolean isBrowsable() {
        int n = this.mFlags;
        boolean bl = true;
        if ((n & 1) == 0) {
            bl = false;
        }
        return bl;
    }

    public boolean isPlayable() {
        boolean bl = (this.mFlags & 2) != 0;
        return bl;
    }

    public void setMetadata(MediaMetadata2 mediaMetadata2) {
        if (mediaMetadata2 != null && !TextUtils.equals((CharSequence)this.mId, (CharSequence)mediaMetadata2.getMediaId())) {
            throw new IllegalArgumentException("metadata's id should be matched with the mediaId");
        }
        this.mMetadata = mediaMetadata2;
    }

    public Bundle toBundle() {
        Bundle bundle = new Bundle();
        bundle.putString(KEY_ID, this.mId);
        bundle.putInt(KEY_FLAGS, this.mFlags);
        MediaMetadata2 mediaMetadata2 = this.mMetadata;
        if (mediaMetadata2 != null) {
            bundle.putBundle(KEY_METADATA, mediaMetadata2.toBundle());
        }
        bundle.putString(KEY_UUID, this.mUUID.toString());
        return bundle;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("MediaItem2{");
        stringBuilder.append("mFlags=");
        stringBuilder.append(this.mFlags);
        stringBuilder.append(", mMetadata=");
        stringBuilder.append(this.mMetadata);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public static final class Builder {
        private DataSourceDesc mDataSourceDesc;
        private int mFlags;
        private String mMediaId;
        private MediaMetadata2 mMetadata;

        public Builder(int n) {
            this.mFlags = n;
        }

        public MediaItem2 build() {
            Object object = this.mMetadata;
            object = object != null ? ((MediaMetadata2)object).getString("android.media.metadata.MEDIA_ID") : null;
            Object object2 = object;
            if (object == null) {
                object = this.mMediaId;
                if (object == null) {
                    object = this.toString();
                }
                object2 = object;
            }
            return new MediaItem2((String)object2, this.mDataSourceDesc, this.mMetadata, this.mFlags);
        }

        public Builder setDataSourceDesc(DataSourceDesc dataSourceDesc) {
            this.mDataSourceDesc = dataSourceDesc;
            return this;
        }

        public Builder setMediaId(String string2) {
            this.mMediaId = string2;
            return this;
        }

        public Builder setMetadata(MediaMetadata2 mediaMetadata2) {
            this.mMetadata = mediaMetadata2;
            return this;
        }
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface Flags {
    }
}

