/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.os.Bundle
 *  android.os.RemoteException
 *  android.text.TextUtils
 *  android.util.Log
 */
package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.v4.media.SessionToken2ImplBase;
import android.support.v4.media.SessionToken2ImplLegacy;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import android.util.Log;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.concurrent.Executor;

public final class SessionToken2 {
    static final String KEY_PACKAGE_NAME = "android.media.token.package_name";
    static final String KEY_SERVICE_NAME = "android.media.token.service_name";
    static final String KEY_SESSION_BINDER = "android.media.token.session_binder";
    static final String KEY_SESSION_ID = "android.media.token.session_id";
    static final String KEY_TOKEN_LEGACY = "android.media.token.LEGACY";
    static final String KEY_TYPE = "android.media.token.type";
    static final String KEY_UID = "android.media.token.uid";
    private static final String TAG = "SessionToken2";
    public static final int TYPE_LIBRARY_SERVICE = 2;
    public static final int TYPE_SESSION = 0;
    static final int TYPE_SESSION_LEGACY = 100;
    public static final int TYPE_SESSION_SERVICE = 1;
    static final int UID_UNKNOWN = -1;
    private static final long WAIT_TIME_MS_FOR_SESSION_READY = 300L;
    private final SupportLibraryImpl mImpl;

    public SessionToken2(Context context, ComponentName componentName) {
        this.mImpl = new SessionToken2ImplBase(context, componentName);
    }

    SessionToken2(SupportLibraryImpl supportLibraryImpl) {
        this.mImpl = supportLibraryImpl;
    }

    public static void createSessionToken2(final Context context, final MediaSessionCompat.Token token, Executor executor, final OnSessionToken2CreatedListener onSessionToken2CreatedListener) {
        if (context != null) {
            if (token != null) {
                if (executor != null) {
                    if (onSessionToken2CreatedListener != null) {
                        executor.execute(new Runnable(){

                            /*
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             */
                            @Override
                            public void run() {
                                Object object;
                                try {
                                    object = new MediaControllerCompat(context, token);
                                    MediaControllerCompat.Callback callback = new MediaControllerCompat.Callback((MediaControllerCompat)object){
                                        final /* synthetic */ MediaControllerCompat val$controller;
                                        {
                                            this.val$controller = mediaControllerCompat;
                                        }

                                        /*
                                         * Enabled aggressive block sorting
                                         * Enabled unnecessary exception pruning
                                         * Enabled aggressive exception aggregation
                                         */
                                        @Override
                                        public void onSessionReady() {
                                            OnSessionToken2CreatedListener onSessionToken2CreatedListener = onSessionToken2CreatedListener;
                                            synchronized (onSessionToken2CreatedListener) {
                                                onSessionToken2CreatedListener.onSessionToken2Created(token, this.val$controller.getSessionToken2());
                                                onSessionToken2CreatedListener.notify();
                                                return;
                                            }
                                        }
                                    };
                                    ((MediaControllerCompat)object).registerCallback(callback);
                                    if (((MediaControllerCompat)object).isSessionReady()) {
                                        onSessionToken2CreatedListener.onSessionToken2Created(token, ((MediaControllerCompat)object).getSessionToken2());
                                    }
                                    callback = onSessionToken2CreatedListener;
                                    synchronized (callback) {
                                    }
                                }
                                catch (InterruptedException interruptedException) {
                                    Log.e((String)SessionToken2.TAG, (String)"Failed to create session token2.", (Throwable)interruptedException);
                                    return;
                                }
                                catch (RemoteException remoteException) {
                                    Log.e((String)SessionToken2.TAG, (String)"Failed to create session token2.", (Throwable)remoteException);
                                    return;
                                }
                                {
                                    onSessionToken2CreatedListener.wait(300L);
                                    if (((MediaControllerCompat)object).isSessionReady()) return;
                                    SessionToken2ImplLegacy sessionToken2ImplLegacy = new SessionToken2ImplLegacy(token);
                                    object = new SessionToken2(sessionToken2ImplLegacy);
                                    token.setSessionToken2((SessionToken2)object);
                                    onSessionToken2CreatedListener.onSessionToken2Created(token, (SessionToken2)object);
                                    return;
                                }
                            }
                        });
                        return;
                    }
                    throw new IllegalArgumentException("listener shouldn't be null");
                }
                throw new IllegalArgumentException("executor shouldn't be null");
            }
            throw new IllegalArgumentException("token shouldn't be null");
        }
        throw new IllegalArgumentException("context shouldn't be null");
    }

    public static SessionToken2 fromBundle(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        if (bundle.getInt(KEY_TYPE, -1) == 100) {
            return new SessionToken2(SessionToken2ImplLegacy.fromBundle(bundle));
        }
        return new SessionToken2(SessionToken2ImplBase.fromBundle(bundle));
    }

    public static String getSessionId(ResolveInfo resolveInfo) {
        if (resolveInfo != null && resolveInfo.serviceInfo != null) {
            if (resolveInfo.serviceInfo.metaData == null) {
                return "";
            }
            return resolveInfo.serviceInfo.metaData.getString("android.media.session", "");
        }
        return null;
    }

    private static String getSessionIdFromService(PackageManager packageManager, String object, ComponentName componentName) {
        object = new Intent((String)object);
        object.setPackage(componentName.getPackageName());
        object = packageManager.queryIntentServices((Intent)object, 128);
        if (object != null) {
            for (int i = 0; i < object.size(); ++i) {
                packageManager = (ResolveInfo)object.get(i);
                if (packageManager == null || packageManager.serviceInfo == null || !TextUtils.equals((CharSequence)packageManager.serviceInfo.name, (CharSequence)componentName.getClassName())) continue;
                return SessionToken2.getSessionId((ResolveInfo)packageManager);
            }
        }
        return null;
    }

    public boolean equals(Object object) {
        if (!(object instanceof SessionToken2)) {
            return false;
        }
        object = (SessionToken2)object;
        return this.mImpl.equals(((SessionToken2)object).mImpl);
    }

    public Object getBinder() {
        return this.mImpl.getBinder();
    }

    public ComponentName getComponentName() {
        return this.mImpl.getComponentName();
    }

    public String getId() {
        return this.mImpl.getSessionId();
    }

    public String getPackageName() {
        return this.mImpl.getPackageName();
    }

    public String getServiceName() {
        return this.mImpl.getServiceName();
    }

    public int getType() {
        return this.mImpl.getType();
    }

    public int getUid() {
        return this.mImpl.getUid();
    }

    public int hashCode() {
        return this.mImpl.hashCode();
    }

    public boolean isLegacySession() {
        return this.mImpl instanceof SessionToken2ImplLegacy;
    }

    public Bundle toBundle() {
        return this.mImpl.toBundle();
    }

    public String toString() {
        return this.mImpl.toString();
    }

    public static interface OnSessionToken2CreatedListener {
        public void onSessionToken2Created(MediaSessionCompat.Token var1, SessionToken2 var2);
    }

    static interface SupportLibraryImpl {
        public Object getBinder();

        public ComponentName getComponentName();

        public String getPackageName();

        public String getServiceName();

        public String getSessionId();

        public int getType();

        public int getUid();

        public Bundle toBundle();
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface TokenType {
    }
}

