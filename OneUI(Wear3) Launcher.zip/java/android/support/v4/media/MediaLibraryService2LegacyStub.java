/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.BadParcelableException
 *  android.os.Bundle
 */
package android.support.v4.media;

import android.os.BadParcelableException;
import android.os.Bundle;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaBrowserServiceCompat;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaLibraryService2;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaSessionManager;
import android.support.v4.media.MediaUtils2;
import java.util.List;
import java.util.concurrent.Executor;

class MediaLibraryService2LegacyStub
extends MediaBrowserServiceCompat {
    private final MediaLibraryService2.MediaLibrarySession.SupportLibraryImpl mLibrarySession;

    MediaLibraryService2LegacyStub(MediaLibraryService2.MediaLibrarySession.SupportLibraryImpl supportLibraryImpl) {
        this.mLibrarySession = supportLibraryImpl;
    }

    private MediaSession2.ControllerInfo getController() {
        List<MediaSession2.ControllerInfo> list = this.mLibrarySession.getConnectedControllers();
        MediaSessionManager.RemoteUserInfo remoteUserInfo = this.getCurrentBrowserInfo();
        if (remoteUserInfo == null) {
            return null;
        }
        for (int i = 0; i < list.size(); ++i) {
            MediaSession2.ControllerInfo controllerInfo = list.get(i);
            if (!controllerInfo.getPackageName().equals(remoteUserInfo.getPackageName()) || controllerInfo.getUid() != remoteUserInfo.getUid()) continue;
            return controllerInfo;
        }
        return null;
    }

    @Override
    public void onCustomAction(String string2, Bundle bundle, MediaBrowserServiceCompat.Result<Bundle> result) {
    }

    @Override
    public MediaBrowserServiceCompat.BrowserRoot onGetRoot(String object, int n, Bundle bundle) {
        if (MediaUtils2.isDefaultLibraryRootHint(bundle)) {
            return MediaUtils2.sDefaultBrowserRoot;
        }
        object = this.getController();
        object = this.mLibrarySession.getCallback().onGetLibraryRoot(this.mLibrarySession.getInstance(), (MediaSession2.ControllerInfo)object, bundle);
        if (object == null) {
            return null;
        }
        return new MediaBrowserServiceCompat.BrowserRoot(((MediaLibraryService2.LibraryRoot)object).getRootId(), ((MediaLibraryService2.LibraryRoot)object).getExtras());
    }

    @Override
    public void onLoadChildren(String string2, MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>> result) {
        this.onLoadChildren(string2, result, null);
    }

    @Override
    public void onLoadChildren(final String string2, final MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>> result, final Bundle bundle) {
        result.detach();
        final MediaSession2.ControllerInfo controllerInfo = this.getController();
        this.mLibrarySession.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                Object object;
                block4: {
                    object = bundle;
                    if (object != null) {
                        object.setClassLoader(MediaLibraryService2LegacyStub.this.mLibrarySession.getContext().getClassLoader());
                        int n = bundle.getInt("android.media.browse.extra.PAGE");
                        int n2 = bundle.getInt("android.media.browse.extra.PAGE_SIZE");
                        if (n <= 0 || n2 <= 0) break block4;
                        try {
                            object = MediaLibraryService2LegacyStub.this.mLibrarySession.getCallback().onGetChildren(MediaLibraryService2LegacyStub.this.mLibrarySession.getInstance(), controllerInfo, string2, n, n2, bundle);
                            result.sendResult(MediaUtils2.convertToMediaItemList((List<MediaItem2>)object));
                            return;
                        }
                        catch (BadParcelableException badParcelableException) {
                            // empty catch block
                        }
                    }
                }
                object = MediaLibraryService2LegacyStub.this.mLibrarySession.getCallback().onGetChildren(MediaLibraryService2LegacyStub.this.mLibrarySession.getInstance(), controllerInfo, string2, 1, Integer.MAX_VALUE, null);
                result.sendResult(MediaUtils2.convertToMediaItemList((List<MediaItem2>)object));
            }
        });
    }

    @Override
    public void onLoadItem(final String string2, final MediaBrowserServiceCompat.Result<MediaBrowserCompat.MediaItem> result) {
        result.detach();
        final MediaSession2.ControllerInfo controllerInfo = this.getController();
        this.mLibrarySession.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                MediaItem2 mediaItem2 = MediaLibraryService2LegacyStub.this.mLibrarySession.getCallback().onGetItem(MediaLibraryService2LegacyStub.this.mLibrarySession.getInstance(), controllerInfo, string2);
                if (mediaItem2 == null) {
                    result.sendResult(null);
                } else {
                    result.sendResult(MediaUtils2.convertToMediaItem(mediaItem2));
                }
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onSearch(final String string2, final Bundle bundle, MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>> object) {
        ((MediaBrowserServiceCompat.Result)object).detach();
        final MediaSession2.ControllerInfo controllerInfo = this.getController();
        bundle.setClassLoader(this.mLibrarySession.getContext().getClassLoader());
        try {
            final int n = bundle.getInt("android.media.browse.extra.PAGE");
            final int n2 = bundle.getInt("android.media.browse.extra.PAGE_SIZE");
            if (n > 0 && n2 > 0) {
                Executor executor = this.mLibrarySession.getCallbackExecutor();
                Runnable runnable = new Runnable((MediaBrowserServiceCompat.Result)object){
                    final /* synthetic */ MediaBrowserServiceCompat.Result val$result;
                    {
                        this.val$result = result;
                    }

                    @Override
                    public void run() {
                        List<MediaItem2> list = MediaLibraryService2LegacyStub.this.mLibrarySession.getCallback().onGetSearchResult(MediaLibraryService2LegacyStub.this.mLibrarySession.getInstance(), controllerInfo, string2, n, n2, bundle);
                        if (list == null) {
                            this.val$result.sendResult(null);
                            return;
                        }
                        this.val$result.sendResult(MediaUtils2.convertToMediaItemList(list));
                    }
                };
                executor.execute(runnable);
                return;
            }
            object = this.mLibrarySession.getCallbackExecutor();
        }
        catch (BadParcelableException badParcelableException) {
            // empty catch block
            return;
        }
        try {
            Runnable runnable = new Runnable(){

                @Override
                public void run() {
                    MediaLibraryService2LegacyStub.this.mLibrarySession.getCallback().onSearch(MediaLibraryService2LegacyStub.this.mLibrarySession.getInstance(), controllerInfo, string2, bundle);
                }
            };
            object.execute(runnable);
            return;
        }
        catch (BadParcelableException badParcelableException) {
            return;
        }
    }
}

