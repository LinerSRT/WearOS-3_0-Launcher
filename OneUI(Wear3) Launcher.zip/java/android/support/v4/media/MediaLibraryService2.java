/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.media.BaseMediaPlayer;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaLibraryService2ImplBase;
import android.support.v4.media.MediaLibrarySessionImplBase;
import android.support.v4.media.MediaPlaylistAgent;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaSessionService2;
import android.support.v4.media.VolumeProviderCompat;
import java.util.List;
import java.util.concurrent.Executor;

public abstract class MediaLibraryService2
extends MediaSessionService2 {
    public static final String SERVICE_INTERFACE = "android.media.MediaLibraryService2";

    @Override
    MediaSessionService2.SupportLibraryImpl createImpl() {
        return new MediaLibraryService2ImplBase();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (this.getSession() instanceof MediaLibrarySession) {
            return;
        }
        throw new RuntimeException("Expected MediaLibrarySession, but returned MediaSession2");
    }

    @Override
    public abstract MediaLibrarySession onCreateSession(String var1);

    public static final class LibraryRoot {
        public static final String EXTRA_OFFLINE = "android.media.extra.OFFLINE";
        public static final String EXTRA_RECENT = "android.media.extra.RECENT";
        public static final String EXTRA_SUGGESTED = "android.media.extra.SUGGESTED";
        private final Bundle mExtras;
        private final String mRootId;

        public LibraryRoot(String string2, Bundle bundle) {
            if (string2 != null) {
                this.mRootId = string2;
                this.mExtras = bundle;
                return;
            }
            throw new IllegalArgumentException("rootId shouldn't be null");
        }

        public Bundle getExtras() {
            return this.mExtras;
        }

        public String getRootId() {
            return this.mRootId;
        }
    }

    public static final class MediaLibrarySession
    extends MediaSession2 {
        MediaLibrarySession(Context context, String string2, BaseMediaPlayer baseMediaPlayer, MediaPlaylistAgent mediaPlaylistAgent, VolumeProviderCompat volumeProviderCompat, PendingIntent pendingIntent, Executor executor, MediaSession2.SessionCallback sessionCallback) {
            super(context, string2, baseMediaPlayer, mediaPlaylistAgent, volumeProviderCompat, pendingIntent, executor, sessionCallback);
        }

        @Override
        SupportLibraryImpl createImpl(Context context, String string2, BaseMediaPlayer baseMediaPlayer, MediaPlaylistAgent mediaPlaylistAgent, VolumeProviderCompat volumeProviderCompat, PendingIntent pendingIntent, Executor executor, MediaSession2.SessionCallback sessionCallback) {
            return new MediaLibrarySessionImplBase(this, context, string2, baseMediaPlayer, mediaPlaylistAgent, volumeProviderCompat, pendingIntent, executor, sessionCallback);
        }

        @Override
        MediaLibrarySessionCallback getCallback() {
            return (MediaLibrarySessionCallback)super.getCallback();
        }

        @Override
        SupportLibraryImpl getImpl() {
            return (SupportLibraryImpl)super.getImpl();
        }

        public void notifyChildrenChanged(MediaSession2.ControllerInfo controllerInfo, String string2, int n, Bundle bundle) {
            this.getImpl().notifyChildrenChanged(controllerInfo, string2, n, bundle);
        }

        public void notifyChildrenChanged(String string2, int n, Bundle bundle) {
            this.getImpl().notifyChildrenChanged(string2, n, bundle);
        }

        public void notifySearchResultChanged(MediaSession2.ControllerInfo controllerInfo, String string2, int n, Bundle bundle) {
            this.getImpl().notifySearchResultChanged(controllerInfo, string2, n, bundle);
        }

        public static final class Builder
        extends MediaSession2.BuilderBase<MediaLibrarySession, Builder, MediaLibrarySessionCallback> {
            public Builder(MediaLibraryService2 mediaLibraryService2, Executor executor, MediaLibrarySessionCallback mediaLibrarySessionCallback) {
                super((Context)mediaLibraryService2);
                this.setSessionCallback(executor, mediaLibrarySessionCallback);
            }

            @Override
            public MediaLibrarySession build() {
                if (this.mCallbackExecutor == null) {
                    this.mCallbackExecutor = new MediaSession2.MainHandlerExecutor(this.mContext);
                }
                if (this.mCallback == null) {
                    this.mCallback = new MediaLibrarySessionCallback(){};
                }
                return new MediaLibrarySession(this.mContext, this.mId, this.mPlayer, this.mPlaylistAgent, this.mVolumeProvider, this.mSessionActivity, this.mCallbackExecutor, this.mCallback);
            }

            @Override
            public Builder setId(String string2) {
                return (Builder)super.setId(string2);
            }

            @Override
            public Builder setPlayer(BaseMediaPlayer baseMediaPlayer) {
                return (Builder)super.setPlayer(baseMediaPlayer);
            }

            @Override
            public Builder setPlaylistAgent(MediaPlaylistAgent mediaPlaylistAgent) {
                return (Builder)super.setPlaylistAgent(mediaPlaylistAgent);
            }

            @Override
            public Builder setSessionActivity(PendingIntent pendingIntent) {
                return (Builder)super.setSessionActivity(pendingIntent);
            }

            @Override
            public Builder setVolumeProvider(VolumeProviderCompat volumeProviderCompat) {
                return (Builder)super.setVolumeProvider(volumeProviderCompat);
            }
        }

        public static class MediaLibrarySessionCallback
        extends MediaSession2.SessionCallback {
            public List<MediaItem2> onGetChildren(MediaLibrarySession mediaLibrarySession, MediaSession2.ControllerInfo controllerInfo, String string2, int n, int n2, Bundle bundle) {
                return null;
            }

            public MediaItem2 onGetItem(MediaLibrarySession mediaLibrarySession, MediaSession2.ControllerInfo controllerInfo, String string2) {
                return null;
            }

            public LibraryRoot onGetLibraryRoot(MediaLibrarySession mediaLibrarySession, MediaSession2.ControllerInfo controllerInfo, Bundle bundle) {
                return null;
            }

            public List<MediaItem2> onGetSearchResult(MediaLibrarySession mediaLibrarySession, MediaSession2.ControllerInfo controllerInfo, String string2, int n, int n2, Bundle bundle) {
                return null;
            }

            public void onSearch(MediaLibrarySession mediaLibrarySession, MediaSession2.ControllerInfo controllerInfo, String string2, Bundle bundle) {
            }

            public void onSubscribe(MediaLibrarySession mediaLibrarySession, MediaSession2.ControllerInfo controllerInfo, String string2, Bundle bundle) {
            }

            public void onUnsubscribe(MediaLibrarySession mediaLibrarySession, MediaSession2.ControllerInfo controllerInfo, String string2) {
            }
        }

        static interface SupportLibraryImpl
        extends MediaSession2.SupportLibraryImpl {
            @Override
            public MediaLibrarySessionCallback getCallback();

            @Override
            public MediaLibrarySession getInstance();

            public IBinder getLegacySessionBinder();

            public void notifyChildrenChanged(MediaSession2.ControllerInfo var1, String var2, int var3, Bundle var4);

            public void notifyChildrenChanged(String var1, int var2, Bundle var3);

            public void notifySearchResultChanged(MediaSession2.ControllerInfo var1, String var2, int var3, Bundle var4);

            public void onGetChildrenOnExecutor(MediaSession2.ControllerInfo var1, String var2, int var3, int var4, Bundle var5);

            public void onGetItemOnExecutor(MediaSession2.ControllerInfo var1, String var2);

            public void onGetLibraryRootOnExecutor(MediaSession2.ControllerInfo var1, Bundle var2);

            public void onGetSearchResultOnExecutor(MediaSession2.ControllerInfo var1, String var2, int var3, int var4, Bundle var5);

            public void onSearchOnExecutor(MediaSession2.ControllerInfo var1, String var2, Bundle var3);

            public void onSubscribeOnExecutor(MediaSession2.ControllerInfo var1, String var2, Bundle var3);

            public void onUnsubscribeOnExecutor(MediaSession2.ControllerInfo var1, String var2);
        }
    }
}

