/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.RemoteException
 *  android.os.ResultReceiver
 *  android.support.mediacompat.Rating2
 */
package android.support.v4.media;

import android.app.PendingIntent;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.mediacompat.Rating2;
import android.support.v4.media.AudioFocusHandler;
import android.support.v4.media.BaseMediaPlayer;
import android.support.v4.media.DataSourceDesc;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaInterface2;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaPlaylistAgent;
import android.support.v4.media.MediaSession2ImplBase;
import android.support.v4.media.SessionCommand2;
import android.support.v4.media.SessionCommandGroup2;
import android.support.v4.media.SessionToken2;
import android.support.v4.media.VolumeProviderCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

public class MediaSession2
implements MediaInterface2.SessionPlayer,
AutoCloseable {
    public static final int ERROR_CODE_ACTION_ABORTED = 10;
    public static final int ERROR_CODE_APP_ERROR = 1;
    public static final int ERROR_CODE_AUTHENTICATION_EXPIRED = 3;
    public static final int ERROR_CODE_CONCURRENT_STREAM_LIMIT = 5;
    public static final int ERROR_CODE_CONTENT_ALREADY_PLAYING = 8;
    public static final int ERROR_CODE_END_OF_QUEUE = 11;
    public static final int ERROR_CODE_NOT_AVAILABLE_IN_REGION = 7;
    public static final int ERROR_CODE_NOT_SUPPORTED = 2;
    public static final int ERROR_CODE_PARENTAL_CONTROL_RESTRICTED = 6;
    public static final int ERROR_CODE_PREMIUM_ACCOUNT_REQUIRED = 4;
    public static final int ERROR_CODE_SETUP_REQUIRED = 12;
    public static final int ERROR_CODE_SKIP_LIMIT_REACHED = 9;
    public static final int ERROR_CODE_UNKNOWN_ERROR = 0;
    static final String TAG = "MediaSession2";
    private final SupportLibraryImpl mImpl;

    MediaSession2(Context context, String string2, BaseMediaPlayer baseMediaPlayer, MediaPlaylistAgent mediaPlaylistAgent, VolumeProviderCompat volumeProviderCompat, PendingIntent pendingIntent, Executor executor, SessionCallback sessionCallback) {
        this.mImpl = this.createImpl(context, string2, baseMediaPlayer, mediaPlaylistAgent, volumeProviderCompat, pendingIntent, executor, sessionCallback);
    }

    @Override
    public void addPlaylistItem(int n, MediaItem2 mediaItem2) {
        this.mImpl.addPlaylistItem(n, mediaItem2);
    }

    @Override
    public void clearOnDataSourceMissingHelper() {
        this.mImpl.clearOnDataSourceMissingHelper();
    }

    @Override
    public void close() {
        try {
            this.mImpl.close();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    SupportLibraryImpl createImpl(Context context, String string2, BaseMediaPlayer baseMediaPlayer, MediaPlaylistAgent mediaPlaylistAgent, VolumeProviderCompat volumeProviderCompat, PendingIntent pendingIntent, Executor executor, SessionCallback sessionCallback) {
        return new MediaSession2ImplBase(this, context, string2, baseMediaPlayer, mediaPlaylistAgent, volumeProviderCompat, pendingIntent, executor, sessionCallback);
    }

    AudioFocusHandler getAudioFocusHandler() {
        return this.mImpl.getAudioFocusHandler();
    }

    @Override
    public long getBufferedPosition() {
        return this.mImpl.getBufferedPosition();
    }

    @Override
    public int getBufferingState() {
        return this.mImpl.getBufferingState();
    }

    SessionCallback getCallback() {
        return this.mImpl.getCallback();
    }

    Executor getCallbackExecutor() {
        return this.mImpl.getCallbackExecutor();
    }

    public List<ControllerInfo> getConnectedControllers() {
        return this.mImpl.getConnectedControllers();
    }

    Context getContext() {
        return this.mImpl.getContext();
    }

    @Override
    public MediaItem2 getCurrentMediaItem() {
        return this.mImpl.getCurrentMediaItem();
    }

    @Override
    public long getCurrentPosition() {
        return this.mImpl.getCurrentPosition();
    }

    @Override
    public long getDuration() {
        return this.mImpl.getDuration();
    }

    SupportLibraryImpl getImpl() {
        return this.mImpl;
    }

    @Override
    public float getPlaybackSpeed() {
        return this.mImpl.getPlaybackSpeed();
    }

    public BaseMediaPlayer getPlayer() {
        return this.mImpl.getPlayer();
    }

    @Override
    public int getPlayerState() {
        return this.mImpl.getPlayerState();
    }

    @Override
    public List<MediaItem2> getPlaylist() {
        return this.mImpl.getPlaylist();
    }

    public MediaPlaylistAgent getPlaylistAgent() {
        return this.mImpl.getPlaylistAgent();
    }

    @Override
    public MediaMetadata2 getPlaylistMetadata() {
        return this.mImpl.getPlaylistMetadata();
    }

    @Override
    public int getRepeatMode() {
        return this.mImpl.getRepeatMode();
    }

    IBinder getSessionBinder() {
        return this.mImpl.getSessionBinder();
    }

    public MediaSessionCompat getSessionCompat() {
        return this.mImpl.getSessionCompat();
    }

    @Override
    public int getShuffleMode() {
        return this.mImpl.getShuffleMode();
    }

    public SessionToken2 getToken() {
        return this.mImpl.getToken();
    }

    public VolumeProviderCompat getVolumeProvider() {
        return this.mImpl.getVolumeProvider();
    }

    @Override
    public void notifyError(int n, Bundle bundle) {
        this.mImpl.notifyError(n, bundle);
    }

    public void notifyRoutesInfoChanged(ControllerInfo controllerInfo, List<Bundle> list) {
        this.mImpl.notifyRoutesInfoChanged(controllerInfo, list);
    }

    @Override
    public void pause() {
        this.mImpl.pause();
    }

    @Override
    public void play() {
        this.mImpl.play();
    }

    @Override
    public void prepare() {
        this.mImpl.prepare();
    }

    @Override
    public void removePlaylistItem(MediaItem2 mediaItem2) {
        this.mImpl.removePlaylistItem(mediaItem2);
    }

    @Override
    public void replacePlaylistItem(int n, MediaItem2 mediaItem2) {
        this.mImpl.replacePlaylistItem(n, mediaItem2);
    }

    @Override
    public void reset() {
        this.mImpl.reset();
    }

    @Override
    public void seekTo(long l) {
        this.mImpl.seekTo(l);
    }

    public void sendCustomCommand(ControllerInfo controllerInfo, SessionCommand2 sessionCommand2, Bundle bundle, ResultReceiver resultReceiver) {
        this.mImpl.sendCustomCommand(controllerInfo, sessionCommand2, bundle, resultReceiver);
    }

    public void sendCustomCommand(SessionCommand2 sessionCommand2, Bundle bundle) {
        this.mImpl.sendCustomCommand(sessionCommand2, bundle);
    }

    public void setAllowedCommands(ControllerInfo controllerInfo, SessionCommandGroup2 sessionCommandGroup2) {
        this.mImpl.setAllowedCommands(controllerInfo, sessionCommandGroup2);
    }

    public void setCustomLayout(ControllerInfo controllerInfo, List<CommandButton> list) {
        this.mImpl.setCustomLayout(controllerInfo, list);
    }

    @Override
    public void setOnDataSourceMissingHelper(OnDataSourceMissingHelper onDataSourceMissingHelper) {
        this.mImpl.setOnDataSourceMissingHelper(onDataSourceMissingHelper);
    }

    @Override
    public void setPlaybackSpeed(float f) {
        this.mImpl.setPlaybackSpeed(f);
    }

    @Override
    public void setPlaylist(List<MediaItem2> list, MediaMetadata2 mediaMetadata2) {
        this.mImpl.setPlaylist(list, mediaMetadata2);
    }

    @Override
    public void setRepeatMode(int n) {
        this.mImpl.setRepeatMode(n);
    }

    @Override
    public void setShuffleMode(int n) {
        this.mImpl.setShuffleMode(n);
    }

    @Override
    public void skipBackward() {
        this.mImpl.skipBackward();
    }

    @Override
    public void skipForward() {
        this.mImpl.skipForward();
    }

    @Override
    public void skipToNextItem() {
        this.mImpl.skipToNextItem();
    }

    @Override
    public void skipToPlaylistItem(MediaItem2 mediaItem2) {
        this.mImpl.skipToPlaylistItem(mediaItem2);
    }

    @Override
    public void skipToPreviousItem() {
        this.mImpl.skipToPreviousItem();
    }

    public void updatePlayer(BaseMediaPlayer baseMediaPlayer, MediaPlaylistAgent mediaPlaylistAgent, VolumeProviderCompat volumeProviderCompat) {
        this.mImpl.updatePlayer(baseMediaPlayer, mediaPlaylistAgent, volumeProviderCompat);
    }

    @Override
    public void updatePlaylistMetadata(MediaMetadata2 mediaMetadata2) {
        this.mImpl.updatePlaylistMetadata(mediaMetadata2);
    }

    public static final class Builder
    extends BuilderBase<MediaSession2, Builder, SessionCallback> {
        public Builder(Context context) {
            super(context);
        }

        @Override
        public MediaSession2 build() {
            if (this.mCallbackExecutor == null) {
                this.mCallbackExecutor = new MainHandlerExecutor(this.mContext);
            }
            if (this.mCallback == null) {
                this.mCallback = new SessionCallback(){};
            }
            return new MediaSession2(this.mContext, this.mId, this.mPlayer, this.mPlaylistAgent, this.mVolumeProvider, this.mSessionActivity, this.mCallbackExecutor, this.mCallback);
        }

        @Override
        public Builder setId(String string2) {
            return (Builder)super.setId(string2);
        }

        @Override
        public Builder setPlayer(BaseMediaPlayer baseMediaPlayer) {
            return (Builder)super.setPlayer(baseMediaPlayer);
        }

        @Override
        public Builder setPlaylistAgent(MediaPlaylistAgent mediaPlaylistAgent) {
            return (Builder)super.setPlaylistAgent(mediaPlaylistAgent);
        }

        @Override
        public Builder setSessionActivity(PendingIntent pendingIntent) {
            return (Builder)super.setSessionActivity(pendingIntent);
        }

        @Override
        public Builder setSessionCallback(Executor executor, SessionCallback sessionCallback) {
            return (Builder)super.setSessionCallback(executor, sessionCallback);
        }

        @Override
        public Builder setVolumeProvider(VolumeProviderCompat volumeProviderCompat) {
            return (Builder)super.setVolumeProvider(volumeProviderCompat);
        }
    }

    static abstract class BuilderBase<T extends MediaSession2, U extends BuilderBase<T, U, C>, C extends SessionCallback> {
        C mCallback;
        Executor mCallbackExecutor;
        final Context mContext;
        String mId;
        BaseMediaPlayer mPlayer;
        MediaPlaylistAgent mPlaylistAgent;
        PendingIntent mSessionActivity;
        VolumeProviderCompat mVolumeProvider;

        BuilderBase(Context context) {
            if (context != null) {
                this.mContext = context;
                this.mId = MediaSession2.TAG;
                return;
            }
            throw new IllegalArgumentException("context shouldn't be null");
        }

        abstract T build();

        U setId(String string2) {
            if (string2 != null) {
                this.mId = string2;
                return (U)this;
            }
            throw new IllegalArgumentException("id shouldn't be null");
        }

        U setPlayer(BaseMediaPlayer baseMediaPlayer) {
            if (baseMediaPlayer != null) {
                this.mPlayer = baseMediaPlayer;
                return (U)this;
            }
            throw new IllegalArgumentException("player shouldn't be null");
        }

        U setPlaylistAgent(MediaPlaylistAgent mediaPlaylistAgent) {
            if (mediaPlaylistAgent != null) {
                this.mPlaylistAgent = mediaPlaylistAgent;
                return (U)this;
            }
            throw new IllegalArgumentException("playlistAgent shouldn't be null");
        }

        U setSessionActivity(PendingIntent pendingIntent) {
            this.mSessionActivity = pendingIntent;
            return (U)this;
        }

        U setSessionCallback(Executor executor, C c) {
            if (executor != null) {
                if (c != null) {
                    this.mCallbackExecutor = executor;
                    this.mCallback = c;
                    return (U)this;
                }
                throw new IllegalArgumentException("callback shouldn't be null");
            }
            throw new IllegalArgumentException("executor shouldn't be null");
        }

        U setVolumeProvider(VolumeProviderCompat volumeProviderCompat) {
            this.mVolumeProvider = volumeProviderCompat;
            return (U)this;
        }
    }

    public static final class CommandButton {
        private static final String KEY_COMMAND = "android.media.media_session2.command_button.command";
        private static final String KEY_DISPLAY_NAME = "android.media.media_session2.command_button.display_name";
        private static final String KEY_ENABLED = "android.media.media_session2.command_button.enabled";
        private static final String KEY_EXTRAS = "android.media.media_session2.command_button.extras";
        private static final String KEY_ICON_RES_ID = "android.media.media_session2.command_button.icon_res_id";
        private SessionCommand2 mCommand;
        private String mDisplayName;
        private boolean mEnabled;
        private Bundle mExtras;
        private int mIconResId;

        private CommandButton(SessionCommand2 sessionCommand2, int n, String string2, Bundle bundle, boolean bl) {
            this.mCommand = sessionCommand2;
            this.mIconResId = n;
            this.mDisplayName = string2;
            this.mExtras = bundle;
            this.mEnabled = bl;
        }

        public static CommandButton fromBundle(Bundle object) {
            if (object == null) {
                return null;
            }
            Builder builder = new Builder();
            builder.setCommand(SessionCommand2.fromBundle(object.getBundle(KEY_COMMAND)));
            builder.setIconResId(object.getInt(KEY_ICON_RES_ID, 0));
            builder.setDisplayName(object.getString(KEY_DISPLAY_NAME));
            builder.setExtras(object.getBundle(KEY_EXTRAS));
            builder.setEnabled(object.getBoolean(KEY_ENABLED));
            try {
                object = builder.build();
                return object;
            }
            catch (IllegalStateException illegalStateException) {
                return null;
            }
        }

        public SessionCommand2 getCommand() {
            return this.mCommand;
        }

        public String getDisplayName() {
            return this.mDisplayName;
        }

        public Bundle getExtras() {
            return this.mExtras;
        }

        public int getIconResId() {
            return this.mIconResId;
        }

        public boolean isEnabled() {
            return this.mEnabled;
        }

        public Bundle toBundle() {
            Bundle bundle = new Bundle();
            bundle.putBundle(KEY_COMMAND, this.mCommand.toBundle());
            bundle.putInt(KEY_ICON_RES_ID, this.mIconResId);
            bundle.putString(KEY_DISPLAY_NAME, this.mDisplayName);
            bundle.putBundle(KEY_EXTRAS, this.mExtras);
            bundle.putBoolean(KEY_ENABLED, this.mEnabled);
            return bundle;
        }

        public static final class Builder {
            private SessionCommand2 mCommand;
            private String mDisplayName;
            private boolean mEnabled;
            private Bundle mExtras;
            private int mIconResId;

            public CommandButton build() {
                return new CommandButton(this.mCommand, this.mIconResId, this.mDisplayName, this.mExtras, this.mEnabled);
            }

            public Builder setCommand(SessionCommand2 sessionCommand2) {
                this.mCommand = sessionCommand2;
                return this;
            }

            public Builder setDisplayName(String string2) {
                this.mDisplayName = string2;
                return this;
            }

            public Builder setEnabled(boolean bl) {
                this.mEnabled = bl;
                return this;
            }

            public Builder setExtras(Bundle bundle) {
                this.mExtras = bundle;
                return this;
            }

            public Builder setIconResId(int n) {
                this.mIconResId = n;
                return this;
            }
        }
    }

    static abstract class ControllerCb {
        ControllerCb() {
        }

        public boolean equals(Object object) {
            if (!(object instanceof ControllerCb)) {
                return false;
            }
            object = (ControllerCb)object;
            return this.getId().equals(((ControllerCb)object).getId());
        }

        abstract IBinder getId();

        public int hashCode() {
            return this.getId().hashCode();
        }

        abstract void onAllowedCommandsChanged(SessionCommandGroup2 var1) throws RemoteException;

        abstract void onBufferingStateChanged(MediaItem2 var1, int var2, long var3) throws RemoteException;

        abstract void onChildrenChanged(String var1, int var2, Bundle var3) throws RemoteException;

        abstract void onCurrentMediaItemChanged(MediaItem2 var1) throws RemoteException;

        abstract void onCustomCommand(SessionCommand2 var1, Bundle var2, ResultReceiver var3) throws RemoteException;

        abstract void onCustomLayoutChanged(List<CommandButton> var1) throws RemoteException;

        abstract void onDisconnected() throws RemoteException;

        abstract void onError(int var1, Bundle var2) throws RemoteException;

        abstract void onGetChildrenDone(String var1, int var2, int var3, List<MediaItem2> var4, Bundle var5) throws RemoteException;

        abstract void onGetItemDone(String var1, MediaItem2 var2) throws RemoteException;

        abstract void onGetLibraryRootDone(Bundle var1, String var2, Bundle var3) throws RemoteException;

        abstract void onGetSearchResultDone(String var1, int var2, int var3, List<MediaItem2> var4, Bundle var5) throws RemoteException;

        abstract void onPlaybackInfoChanged(MediaController2.PlaybackInfo var1) throws RemoteException;

        abstract void onPlaybackSpeedChanged(long var1, long var3, float var5) throws RemoteException;

        abstract void onPlayerStateChanged(long var1, long var3, int var5) throws RemoteException;

        abstract void onPlaylistChanged(List<MediaItem2> var1, MediaMetadata2 var2) throws RemoteException;

        abstract void onPlaylistMetadataChanged(MediaMetadata2 var1) throws RemoteException;

        abstract void onRepeatModeChanged(int var1) throws RemoteException;

        abstract void onRoutesInfoChanged(List<Bundle> var1) throws RemoteException;

        abstract void onSearchResultChanged(String var1, int var2, Bundle var3) throws RemoteException;

        abstract void onSeekCompleted(long var1, long var3, long var5) throws RemoteException;

        abstract void onShuffleModeChanged(int var1) throws RemoteException;
    }

    public static final class ControllerInfo {
        private final ControllerCb mControllerCb;
        private final boolean mIsTrusted;
        private final String mPackageName;
        private final int mUid;

        ControllerInfo(String string2, int n, int n2, ControllerCb controllerCb) {
            this.mUid = n2;
            this.mPackageName = string2;
            this.mIsTrusted = false;
            this.mControllerCb = controllerCb;
        }

        public boolean equals(Object object) {
            if (!(object instanceof ControllerInfo)) {
                return false;
            }
            object = (ControllerInfo)object;
            return this.mControllerCb.equals(((ControllerInfo)object).mControllerCb);
        }

        ControllerCb getControllerCb() {
            return this.mControllerCb;
        }

        IBinder getId() {
            return this.mControllerCb.getId();
        }

        public String getPackageName() {
            return this.mPackageName;
        }

        public int getUid() {
            return this.mUid;
        }

        public int hashCode() {
            return this.mControllerCb.hashCode();
        }

        public boolean isTrusted() {
            return this.mIsTrusted;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("ControllerInfo {pkg=");
            stringBuilder.append(this.mPackageName);
            stringBuilder.append(", uid=");
            stringBuilder.append(this.mUid);
            stringBuilder.append("})");
            return stringBuilder.toString();
        }
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface ErrorCode {
    }

    static class MainHandlerExecutor
    implements Executor {
        private final Handler mHandler;

        MainHandlerExecutor(Context context) {
            this.mHandler = new Handler(context.getMainLooper());
        }

        @Override
        public void execute(Runnable object) {
            if (this.mHandler.post((Runnable)object)) {
                return;
            }
            object = new StringBuilder();
            ((StringBuilder)object).append(this.mHandler);
            ((StringBuilder)object).append(" is shutting down");
            throw new RejectedExecutionException(((StringBuilder)object).toString());
        }
    }

    public static interface OnDataSourceMissingHelper {
        public DataSourceDesc onDataSourceMissing(MediaSession2 var1, MediaItem2 var2);
    }

    public static abstract class SessionCallback {
        public void onBufferingStateChanged(MediaSession2 mediaSession2, BaseMediaPlayer baseMediaPlayer, MediaItem2 mediaItem2, int n) {
        }

        public boolean onCommandRequest(MediaSession2 mediaSession2, ControllerInfo controllerInfo, SessionCommand2 sessionCommand2) {
            return true;
        }

        public SessionCommandGroup2 onConnect(MediaSession2 object, ControllerInfo controllerInfo) {
            object = new SessionCommandGroup2();
            ((SessionCommandGroup2)object).addAllPredefinedCommands();
            return object;
        }

        public void onCurrentMediaItemChanged(MediaSession2 mediaSession2, BaseMediaPlayer baseMediaPlayer, MediaItem2 mediaItem2) {
        }

        public void onCustomCommand(MediaSession2 mediaSession2, ControllerInfo controllerInfo, SessionCommand2 sessionCommand2, Bundle bundle, ResultReceiver resultReceiver) {
        }

        public void onDisconnected(MediaSession2 mediaSession2, ControllerInfo controllerInfo) {
        }

        public void onFastForward(MediaSession2 mediaSession2, ControllerInfo controllerInfo) {
        }

        public void onMediaPrepared(MediaSession2 mediaSession2, BaseMediaPlayer baseMediaPlayer, MediaItem2 mediaItem2) {
        }

        public void onPlayFromMediaId(MediaSession2 mediaSession2, ControllerInfo controllerInfo, String string2, Bundle bundle) {
        }

        public void onPlayFromSearch(MediaSession2 mediaSession2, ControllerInfo controllerInfo, String string2, Bundle bundle) {
        }

        public void onPlayFromUri(MediaSession2 mediaSession2, ControllerInfo controllerInfo, Uri uri, Bundle bundle) {
        }

        public void onPlaybackSpeedChanged(MediaSession2 mediaSession2, BaseMediaPlayer baseMediaPlayer, float f) {
        }

        public void onPlayerStateChanged(MediaSession2 mediaSession2, BaseMediaPlayer baseMediaPlayer, int n) {
        }

        public void onPlaylistChanged(MediaSession2 mediaSession2, MediaPlaylistAgent mediaPlaylistAgent, List<MediaItem2> list, MediaMetadata2 mediaMetadata2) {
        }

        public void onPlaylistMetadataChanged(MediaSession2 mediaSession2, MediaPlaylistAgent mediaPlaylistAgent, MediaMetadata2 mediaMetadata2) {
        }

        public void onPrepareFromMediaId(MediaSession2 mediaSession2, ControllerInfo controllerInfo, String string2, Bundle bundle) {
        }

        public void onPrepareFromSearch(MediaSession2 mediaSession2, ControllerInfo controllerInfo, String string2, Bundle bundle) {
        }

        public void onPrepareFromUri(MediaSession2 mediaSession2, ControllerInfo controllerInfo, Uri uri, Bundle bundle) {
        }

        public void onRepeatModeChanged(MediaSession2 mediaSession2, MediaPlaylistAgent mediaPlaylistAgent, int n) {
        }

        public void onRewind(MediaSession2 mediaSession2, ControllerInfo controllerInfo) {
        }

        public void onSeekCompleted(MediaSession2 mediaSession2, BaseMediaPlayer baseMediaPlayer, long l) {
        }

        public void onSelectRoute(MediaSession2 mediaSession2, ControllerInfo controllerInfo, Bundle bundle) {
        }

        public void onSetRating(MediaSession2 mediaSession2, ControllerInfo controllerInfo, String string2, Rating2 rating2) {
        }

        public void onShuffleModeChanged(MediaSession2 mediaSession2, MediaPlaylistAgent mediaPlaylistAgent, int n) {
        }

        public void onSubscribeRoutesInfo(MediaSession2 mediaSession2, ControllerInfo controllerInfo) {
        }

        public void onUnsubscribeRoutesInfo(MediaSession2 mediaSession2, ControllerInfo controllerInfo) {
        }
    }

    static interface SupportLibraryImpl
    extends MediaInterface2.SessionPlayer,
    AutoCloseable {
        public AudioFocusHandler getAudioFocusHandler();

        public SessionCallback getCallback();

        public Executor getCallbackExecutor();

        public List<ControllerInfo> getConnectedControllers();

        public Context getContext();

        public MediaSession2 getInstance();

        public MediaController2.PlaybackInfo getPlaybackInfo();

        public PlaybackStateCompat getPlaybackStateCompat();

        public BaseMediaPlayer getPlayer();

        public MediaPlaylistAgent getPlaylistAgent();

        public PendingIntent getSessionActivity();

        public IBinder getSessionBinder();

        public MediaSessionCompat getSessionCompat();

        public SessionToken2 getToken();

        public VolumeProviderCompat getVolumeProvider();

        public boolean isClosed();

        public void notifyRoutesInfoChanged(ControllerInfo var1, List<Bundle> var2);

        public void sendCustomCommand(ControllerInfo var1, SessionCommand2 var2, Bundle var3, ResultReceiver var4);

        public void sendCustomCommand(SessionCommand2 var1, Bundle var2);

        public void setAllowedCommands(ControllerInfo var1, SessionCommandGroup2 var2);

        public void setCustomLayout(ControllerInfo var1, List<CommandButton> var2);

        public void updatePlayer(BaseMediaPlayer var1, MediaPlaylistAgent var2, VolumeProviderCompat var3);
    }
}

