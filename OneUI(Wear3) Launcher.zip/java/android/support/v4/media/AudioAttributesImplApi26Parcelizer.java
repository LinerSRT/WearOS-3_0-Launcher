/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  androidx.media.AudioAttributesImplApi26
 *  androidx.media.AudioAttributesImplApi26Parcelizer
 *  androidx.versionedparcelable.VersionedParcel
 */
package android.support.v4.media;

import androidx.media.AudioAttributesImplApi26;
import androidx.versionedparcelable.VersionedParcel;

public final class AudioAttributesImplApi26Parcelizer
extends androidx.media.AudioAttributesImplApi26Parcelizer {
    public static AudioAttributesImplApi26 read(VersionedParcel versionedParcel) {
        return androidx.media.AudioAttributesImplApi26Parcelizer.read((VersionedParcel)versionedParcel);
    }

    public static void write(AudioAttributesImplApi26 audioAttributesImplApi26, VersionedParcel versionedParcel) {
        androidx.media.AudioAttributesImplApi26Parcelizer.write((AudioAttributesImplApi26)audioAttributesImplApi26, (VersionedParcel)versionedParcel);
    }
}

