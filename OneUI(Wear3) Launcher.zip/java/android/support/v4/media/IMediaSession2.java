/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.os.Binder
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.RemoteException
 *  android.os.ResultReceiver
 */
package android.support.v4.media;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.IMediaController2;
import java.util.List;

public interface IMediaSession2
extends IInterface {
    public void addPlaylistItem(IMediaController2 var1, int var2, Bundle var3) throws RemoteException;

    public void adjustVolume(IMediaController2 var1, int var2, int var3) throws RemoteException;

    public void connect(IMediaController2 var1, String var2) throws RemoteException;

    public void fastForward(IMediaController2 var1) throws RemoteException;

    public void getChildren(IMediaController2 var1, String var2, int var3, int var4, Bundle var5) throws RemoteException;

    public void getItem(IMediaController2 var1, String var2) throws RemoteException;

    public void getLibraryRoot(IMediaController2 var1, Bundle var2) throws RemoteException;

    public void getSearchResult(IMediaController2 var1, String var2, int var3, int var4, Bundle var5) throws RemoteException;

    public void pause(IMediaController2 var1) throws RemoteException;

    public void play(IMediaController2 var1) throws RemoteException;

    public void playFromMediaId(IMediaController2 var1, String var2, Bundle var3) throws RemoteException;

    public void playFromSearch(IMediaController2 var1, String var2, Bundle var3) throws RemoteException;

    public void playFromUri(IMediaController2 var1, Uri var2, Bundle var3) throws RemoteException;

    public void prepare(IMediaController2 var1) throws RemoteException;

    public void prepareFromMediaId(IMediaController2 var1, String var2, Bundle var3) throws RemoteException;

    public void prepareFromSearch(IMediaController2 var1, String var2, Bundle var3) throws RemoteException;

    public void prepareFromUri(IMediaController2 var1, Uri var2, Bundle var3) throws RemoteException;

    public void release(IMediaController2 var1) throws RemoteException;

    public void removePlaylistItem(IMediaController2 var1, Bundle var2) throws RemoteException;

    public void replacePlaylistItem(IMediaController2 var1, int var2, Bundle var3) throws RemoteException;

    public void reset(IMediaController2 var1) throws RemoteException;

    public void rewind(IMediaController2 var1) throws RemoteException;

    public void search(IMediaController2 var1, String var2, Bundle var3) throws RemoteException;

    public void seekTo(IMediaController2 var1, long var2) throws RemoteException;

    public void selectRoute(IMediaController2 var1, Bundle var2) throws RemoteException;

    public void sendCustomCommand(IMediaController2 var1, Bundle var2, Bundle var3, ResultReceiver var4) throws RemoteException;

    public void setPlaybackSpeed(IMediaController2 var1, float var2) throws RemoteException;

    public void setPlaylist(IMediaController2 var1, List<Bundle> var2, Bundle var3) throws RemoteException;

    public void setRating(IMediaController2 var1, String var2, Bundle var3) throws RemoteException;

    public void setRepeatMode(IMediaController2 var1, int var2) throws RemoteException;

    public void setShuffleMode(IMediaController2 var1, int var2) throws RemoteException;

    public void setVolumeTo(IMediaController2 var1, int var2, int var3) throws RemoteException;

    public void skipToNextItem(IMediaController2 var1) throws RemoteException;

    public void skipToPlaylistItem(IMediaController2 var1, Bundle var2) throws RemoteException;

    public void skipToPreviousItem(IMediaController2 var1) throws RemoteException;

    public void subscribe(IMediaController2 var1, String var2, Bundle var3) throws RemoteException;

    public void subscribeRoutesInfo(IMediaController2 var1) throws RemoteException;

    public void unsubscribe(IMediaController2 var1, String var2) throws RemoteException;

    public void unsubscribeRoutesInfo(IMediaController2 var1) throws RemoteException;

    public void updatePlaylistMetadata(IMediaController2 var1, Bundle var2) throws RemoteException;

    public static abstract class Stub
    extends Binder
    implements IMediaSession2 {
        private static final String DESCRIPTOR = "android.support.v4.media.IMediaSession2";
        static final int TRANSACTION_addPlaylistItem = 23;
        static final int TRANSACTION_adjustVolume = 4;
        static final int TRANSACTION_connect = 1;
        static final int TRANSACTION_fastForward = 9;
        static final int TRANSACTION_getChildren = 36;
        static final int TRANSACTION_getItem = 35;
        static final int TRANSACTION_getLibraryRoot = 34;
        static final int TRANSACTION_getSearchResult = 38;
        static final int TRANSACTION_pause = 6;
        static final int TRANSACTION_play = 5;
        static final int TRANSACTION_playFromMediaId = 18;
        static final int TRANSACTION_playFromSearch = 17;
        static final int TRANSACTION_playFromUri = 16;
        static final int TRANSACTION_prepare = 8;
        static final int TRANSACTION_prepareFromMediaId = 15;
        static final int TRANSACTION_prepareFromSearch = 14;
        static final int TRANSACTION_prepareFromUri = 13;
        static final int TRANSACTION_release = 2;
        static final int TRANSACTION_removePlaylistItem = 24;
        static final int TRANSACTION_replacePlaylistItem = 25;
        static final int TRANSACTION_reset = 7;
        static final int TRANSACTION_rewind = 10;
        static final int TRANSACTION_search = 37;
        static final int TRANSACTION_seekTo = 11;
        static final int TRANSACTION_selectRoute = 33;
        static final int TRANSACTION_sendCustomCommand = 12;
        static final int TRANSACTION_setPlaybackSpeed = 20;
        static final int TRANSACTION_setPlaylist = 21;
        static final int TRANSACTION_setRating = 19;
        static final int TRANSACTION_setRepeatMode = 29;
        static final int TRANSACTION_setShuffleMode = 30;
        static final int TRANSACTION_setVolumeTo = 3;
        static final int TRANSACTION_skipToNextItem = 28;
        static final int TRANSACTION_skipToPlaylistItem = 26;
        static final int TRANSACTION_skipToPreviousItem = 27;
        static final int TRANSACTION_subscribe = 39;
        static final int TRANSACTION_subscribeRoutesInfo = 31;
        static final int TRANSACTION_unsubscribe = 40;
        static final int TRANSACTION_unsubscribeRoutesInfo = 32;
        static final int TRANSACTION_updatePlaylistMetadata = 22;

        public Stub() {
            this.attachInterface(this, DESCRIPTOR);
        }

        public static IMediaSession2 asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterface = iBinder.queryLocalInterface(DESCRIPTOR);
            if (iInterface != null && iInterface instanceof IMediaSession2) {
                return (IMediaSession2)iInterface;
            }
            return new Proxy(iBinder);
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int n, Parcel object, Parcel object2, int n2) throws RemoteException {
            if (n != 1598968902) {
                switch (n) {
                    default: {
                        return super.onTransact(n, object, object2, n2);
                    }
                    case 40: {
                        object.enforceInterface(DESCRIPTOR);
                        this.unsubscribe(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readString());
                        return true;
                    }
                    case 39: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        String string2 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.subscribe((IMediaController2)object2, string2, (Bundle)object);
                        return true;
                    }
                    case 38: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        String string3 = object.readString();
                        n2 = object.readInt();
                        n = object.readInt();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.getSearchResult((IMediaController2)object2, string3, n2, n, (Bundle)object);
                        return true;
                    }
                    case 37: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.search(iMediaController2, (String)object2, (Bundle)object);
                        return true;
                    }
                    case 36: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readString();
                        n = object.readInt();
                        n2 = object.readInt();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.getChildren(iMediaController2, (String)object2, n, n2, (Bundle)object);
                        return true;
                    }
                    case 35: {
                        object.enforceInterface(DESCRIPTOR);
                        this.getItem(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readString());
                        return true;
                    }
                    case 34: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.getLibraryRoot((IMediaController2)object2, (Bundle)object);
                        return true;
                    }
                    case 33: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.selectRoute((IMediaController2)object2, (Bundle)object);
                        return true;
                    }
                    case 32: {
                        object.enforceInterface(DESCRIPTOR);
                        this.unsubscribeRoutesInfo(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 31: {
                        object.enforceInterface(DESCRIPTOR);
                        this.subscribeRoutesInfo(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 30: {
                        object.enforceInterface(DESCRIPTOR);
                        this.setShuffleMode(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readInt());
                        return true;
                    }
                    case 29: {
                        object.enforceInterface(DESCRIPTOR);
                        this.setRepeatMode(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readInt());
                        return true;
                    }
                    case 28: {
                        object.enforceInterface(DESCRIPTOR);
                        this.skipToNextItem(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 27: {
                        object.enforceInterface(DESCRIPTOR);
                        this.skipToPreviousItem(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 26: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.skipToPlaylistItem((IMediaController2)object2, (Bundle)object);
                        return true;
                    }
                    case 25: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        n = object.readInt();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.replacePlaylistItem((IMediaController2)object2, n, (Bundle)object);
                        return true;
                    }
                    case 24: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.removePlaylistItem((IMediaController2)object2, (Bundle)object);
                        return true;
                    }
                    case 23: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        n = object.readInt();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.addPlaylistItem((IMediaController2)object2, n, (Bundle)object);
                        return true;
                    }
                    case 22: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.updatePlaylistMetadata((IMediaController2)object2, (Bundle)object);
                        return true;
                    }
                    case 21: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.createTypedArrayList(Bundle.CREATOR);
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.setPlaylist(iMediaController2, (List)object2, (Bundle)object);
                        return true;
                    }
                    case 20: {
                        object.enforceInterface(DESCRIPTOR);
                        this.setPlaybackSpeed(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readFloat());
                        return true;
                    }
                    case 19: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.setRating(iMediaController2, (String)object2, (Bundle)object);
                        return true;
                    }
                    case 18: {
                        object.enforceInterface(DESCRIPTOR);
                        object2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        String string4 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.playFromMediaId((IMediaController2)object2, string4, (Bundle)object);
                        return true;
                    }
                    case 17: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.playFromSearch(iMediaController2, (String)object2, (Bundle)object);
                        return true;
                    }
                    case 16: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readInt() != 0 ? (Uri)Uri.CREATOR.createFromParcel(object) : null;
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.playFromUri(iMediaController2, (Uri)object2, (Bundle)object);
                        return true;
                    }
                    case 15: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.prepareFromMediaId(iMediaController2, (String)object2, (Bundle)object);
                        return true;
                    }
                    case 14: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readString();
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.prepareFromSearch(iMediaController2, (String)object2, (Bundle)object);
                        return true;
                    }
                    case 13: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readInt() != 0 ? (Uri)Uri.CREATOR.createFromParcel(object) : null;
                        object = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        this.prepareFromUri(iMediaController2, (Uri)object2, (Bundle)object);
                        return true;
                    }
                    case 12: {
                        object.enforceInterface(DESCRIPTOR);
                        IMediaController2 iMediaController2 = IMediaController2.Stub.asInterface(object.readStrongBinder());
                        object2 = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        Bundle bundle = object.readInt() != 0 ? (Bundle)Bundle.CREATOR.createFromParcel(object) : null;
                        object = object.readInt() != 0 ? (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(object) : null;
                        this.sendCustomCommand(iMediaController2, (Bundle)object2, bundle, (ResultReceiver)object);
                        return true;
                    }
                    case 11: {
                        object.enforceInterface(DESCRIPTOR);
                        this.seekTo(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readLong());
                        return true;
                    }
                    case 10: {
                        object.enforceInterface(DESCRIPTOR);
                        this.rewind(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 9: {
                        object.enforceInterface(DESCRIPTOR);
                        this.fastForward(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 8: {
                        object.enforceInterface(DESCRIPTOR);
                        this.prepare(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 7: {
                        object.enforceInterface(DESCRIPTOR);
                        this.reset(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 6: {
                        object.enforceInterface(DESCRIPTOR);
                        this.pause(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 5: {
                        object.enforceInterface(DESCRIPTOR);
                        this.play(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 4: {
                        object.enforceInterface(DESCRIPTOR);
                        this.adjustVolume(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readInt(), object.readInt());
                        return true;
                    }
                    case 3: {
                        object.enforceInterface(DESCRIPTOR);
                        this.setVolumeTo(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readInt(), object.readInt());
                        return true;
                    }
                    case 2: {
                        object.enforceInterface(DESCRIPTOR);
                        this.release(IMediaController2.Stub.asInterface(object.readStrongBinder()));
                        return true;
                    }
                    case 1: 
                }
                object.enforceInterface(DESCRIPTOR);
                this.connect(IMediaController2.Stub.asInterface(object.readStrongBinder()), object.readString());
                return true;
            }
            object2.writeString(DESCRIPTOR);
            return true;
        }

        private static class Proxy
        implements IMediaSession2 {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void addPlaylistItem(IMediaController2 iMediaController2, int n, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeInt(n);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(23, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void adjustVolume(IMediaController2 iMediaController2, int n, int n2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeInt(n);
                    parcel.writeInt(n2);
                    this.mRemote.transact(4, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            public IBinder asBinder() {
                return this.mRemote;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void connect(IMediaController2 iMediaController2, String string2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    this.mRemote.transact(1, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void fastForward(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(9, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void getChildren(IMediaController2 iMediaController2, String string2, int n, int n2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    parcel.writeInt(n);
                    parcel.writeInt(n2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(36, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void getItem(IMediaController2 iMediaController2, String string2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    this.mRemote.transact(35, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void getLibraryRoot(IMediaController2 iMediaController2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(34, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void getSearchResult(IMediaController2 iMediaController2, String string2, int n, int n2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    parcel.writeInt(n);
                    parcel.writeInt(n2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(38, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void pause(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(6, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void play(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(5, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void playFromMediaId(IMediaController2 iMediaController2, String string2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(18, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void playFromSearch(IMediaController2 iMediaController2, String string2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(17, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void playFromUri(IMediaController2 iMediaController2, Uri uri, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    if (uri != null) {
                        parcel.writeInt(1);
                        uri.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(16, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void prepare(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(8, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void prepareFromMediaId(IMediaController2 iMediaController2, String string2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(15, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void prepareFromSearch(IMediaController2 iMediaController2, String string2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(14, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void prepareFromUri(IMediaController2 iMediaController2, Uri uri, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    if (uri != null) {
                        parcel.writeInt(1);
                        uri.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(13, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void release(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(2, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void removePlaylistItem(IMediaController2 iMediaController2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(24, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void replacePlaylistItem(IMediaController2 iMediaController2, int n, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeInt(n);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(25, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void reset(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(7, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void rewind(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(10, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void search(IMediaController2 iMediaController2, String string2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(37, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void seekTo(IMediaController2 iMediaController2, long l) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeLong(l);
                    this.mRemote.transact(11, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void selectRoute(IMediaController2 iMediaController2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(33, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void sendCustomCommand(IMediaController2 iMediaController2, Bundle bundle, Bundle bundle2, ResultReceiver resultReceiver) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    if (bundle2 != null) {
                        parcel.writeInt(1);
                        bundle2.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    if (resultReceiver != null) {
                        parcel.writeInt(1);
                        resultReceiver.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(12, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void setPlaybackSpeed(IMediaController2 iMediaController2, float f) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeFloat(f);
                    this.mRemote.transact(20, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void setPlaylist(IMediaController2 iMediaController2, List<Bundle> list, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeTypedList(list);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(21, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void setRating(IMediaController2 iMediaController2, String string2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(19, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void setRepeatMode(IMediaController2 iMediaController2, int n) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeInt(n);
                    this.mRemote.transact(29, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void setShuffleMode(IMediaController2 iMediaController2, int n) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeInt(n);
                    this.mRemote.transact(30, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void setVolumeTo(IMediaController2 iMediaController2, int n, int n2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeInt(n);
                    parcel.writeInt(n2);
                    this.mRemote.transact(3, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void skipToNextItem(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(28, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void skipToPlaylistItem(IMediaController2 iMediaController2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(26, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void skipToPreviousItem(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(27, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void subscribe(IMediaController2 iMediaController2, String string2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(39, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void subscribeRoutesInfo(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(31, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void unsubscribe(IMediaController2 iMediaController2, String string2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    parcel.writeString(string2);
                    this.mRemote.transact(40, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void unsubscribeRoutesInfo(IMediaController2 iMediaController2) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    this.mRemote.transact(32, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            @Override
            public void updatePlaylistMetadata(IMediaController2 iMediaController2, Bundle bundle) throws RemoteException {
                Parcel parcel = Parcel.obtain();
                try {
                    parcel.writeInterfaceToken(Stub.DESCRIPTOR);
                    iMediaController2 = iMediaController2 != null ? iMediaController2.asBinder() : null;
                    parcel.writeStrongBinder((IBinder)iMediaController2);
                    if (bundle != null) {
                        parcel.writeInt(1);
                        bundle.writeToParcel(parcel, 0);
                    } else {
                        parcel.writeInt(0);
                    }
                    this.mRemote.transact(22, parcel, null, 1);
                    return;
                }
                finally {
                    parcel.recycle();
                }
            }
        }
    }
}

