/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 */
package android.support.v4.media;

import android.os.Bundle;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaSession2;
import java.util.List;

class MediaInterface2 {
    private MediaInterface2() {
    }

    static interface SessionPlaybackControl {
        public long getBufferedPosition();

        public int getBufferingState();

        public long getCurrentPosition();

        public long getDuration();

        public float getPlaybackSpeed();

        public int getPlayerState();

        public void pause();

        public void play();

        public void prepare();

        public void reset();

        public void seekTo(long var1);

        public void setPlaybackSpeed(float var1);
    }

    static interface SessionPlayer
    extends SessionPlaybackControl,
    SessionPlaylistControl {
        public void notifyError(int var1, Bundle var2);

        public void skipBackward();

        public void skipForward();
    }

    static interface SessionPlaylistControl {
        public void addPlaylistItem(int var1, MediaItem2 var2);

        public void clearOnDataSourceMissingHelper();

        public MediaItem2 getCurrentMediaItem();

        public List<MediaItem2> getPlaylist();

        public MediaMetadata2 getPlaylistMetadata();

        public int getRepeatMode();

        public int getShuffleMode();

        public void removePlaylistItem(MediaItem2 var1);

        public void replacePlaylistItem(int var1, MediaItem2 var2);

        public void setOnDataSourceMissingHelper(MediaSession2.OnDataSourceMissingHelper var1);

        public void setPlaylist(List<MediaItem2> var1, MediaMetadata2 var2);

        public void setRepeatMode(int var1);

        public void setShuffleMode(int var1);

        public void skipToNextItem();

        public void skipToPlaylistItem(MediaItem2 var1);

        public void skipToPreviousItem();

        public void updatePlaylistMetadata(MediaMetadata2 var1);
    }
}

