/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Parcelable
 *  android.os.RemoteException
 *  android.os.ResultReceiver
 *  android.util.Log
 *  android.util.SparseArray
 */
package android.support.v4.media;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.app.BundleCompat;
import android.support.v4.media.MediaController2;
import android.support.v4.media.MediaItem2;
import android.support.v4.media.MediaMetadata2;
import android.support.v4.media.MediaSession2;
import android.support.v4.media.MediaUtils2;
import android.support.v4.media.SessionCommand2;
import android.support.v4.media.SessionCommandGroup2;
import android.support.v4.media.session.IMediaControllerCallback;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.util.ArrayMap;
import android.util.Log;
import android.util.SparseArray;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class MediaSessionLegacyStub
extends MediaSessionCompat.Callback {
    private static final boolean DEBUG = Log.isLoggable((String)"MediaSessionLegacyStub", (int)3);
    private static final String TAG = "MediaSessionLegacyStub";
    private static final SparseArray<SessionCommand2> sCommandsForOnCommandRequest = new SparseArray();
    private final ArrayMap<MediaSession2.ControllerInfo, SessionCommandGroup2> mAllowedCommandGroupMap;
    private final Set<IBinder> mConnectingControllers;
    final Context mContext;
    private final ArrayMap<IBinder, MediaSession2.ControllerInfo> mControllers;
    private final Object mLock = new Object();
    final MediaSession2.SupportLibraryImpl mSession;

    static {
        SessionCommandGroup2 object2 = new SessionCommandGroup2();
        object2.addAllPlaybackCommands();
        object2.addAllPlaylistCommands();
        object2.addAllVolumeCommands();
        for (SessionCommand2 sessionCommand2 : object2.getCommands()) {
            sCommandsForOnCommandRequest.append(sessionCommand2.getCommandCode(), (Object)sessionCommand2);
        }
    }

    MediaSessionLegacyStub(MediaSession2.SupportLibraryImpl supportLibraryImpl) {
        this.mControllers = new ArrayMap();
        this.mConnectingControllers = new HashSet<IBinder>();
        this.mAllowedCommandGroupMap = new ArrayMap();
        this.mSession = supportLibraryImpl;
        this.mContext = supportLibraryImpl.getContext();
    }

    private void connect(Bundle object, ResultReceiver resultReceiver) {
        object = this.createControllerInfo((Bundle)object);
        this.mSession.getCallbackExecutor().execute(new Runnable((MediaSession2.ControllerInfo)object, resultReceiver){
            final /* synthetic */ ResultReceiver val$cb;
            final /* synthetic */ MediaSession2.ControllerInfo val$controllerInfo;
            {
                this.val$controllerInfo = controllerInfo;
                this.val$cb = resultReceiver;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Converted monitor instructions to comments
             * Lifted jumps to return sites
             */
            @Override
            public void run() {
                if (MediaSessionLegacyStub.this.mSession.isClosed()) {
                    return;
                }
                Object object = MediaSessionLegacyStub.this.mLock;
                // MONITORENTER : object
                MediaSessionLegacyStub.this.mConnectingControllers.add(this.val$controllerInfo.getId());
                // MONITOREXIT : object
                object = MediaSessionLegacyStub.this.mSession.getCallback().onConnect(MediaSessionLegacyStub.this.mSession.getInstance(), this.val$controllerInfo);
                boolean bl = object != null || this.val$controllerInfo.isTrusted();
                Object var3_3 = null;
                if (bl) {
                    List<MediaItem2> list;
                    if (DEBUG) {
                        list = new StringBuilder();
                        ((StringBuilder)((Object)list)).append("Accepting connection, controllerInfo=");
                        ((StringBuilder)((Object)list)).append(this.val$controllerInfo);
                        ((StringBuilder)((Object)list)).append(" allowedCommands=");
                        ((StringBuilder)((Object)list)).append(object);
                        Log.d((String)MediaSessionLegacyStub.TAG, (String)((StringBuilder)((Object)list)).toString());
                    }
                    if (object == null) {
                        object = new SessionCommandGroup2();
                    }
                    list = MediaSessionLegacyStub.this.mLock;
                    // MONITORENTER : list
                    MediaSessionLegacyStub.this.mConnectingControllers.remove(this.val$controllerInfo.getId());
                    MediaSessionLegacyStub.this.mControllers.put(this.val$controllerInfo.getId(), this.val$controllerInfo);
                    MediaSessionLegacyStub.this.mAllowedCommandGroupMap.put(this.val$controllerInfo, object);
                    // MONITOREXIT : list
                    Bundle bundle = new Bundle();
                    bundle.putBundle("android.support.v4.media.argument.ALLOWED_COMMANDS", ((SessionCommandGroup2)object).toBundle());
                    bundle.putInt("android.support.v4.media.argument.PLAYER_STATE", MediaSessionLegacyStub.this.mSession.getPlayerState());
                    bundle.putInt("android.support.v4.media.argument.BUFFERING_STATE", MediaSessionLegacyStub.this.mSession.getBufferingState());
                    bundle.putParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT", (Parcelable)MediaSessionLegacyStub.this.mSession.getPlaybackStateCompat());
                    bundle.putInt("android.support.v4.media.argument.REPEAT_MODE", MediaSessionLegacyStub.this.mSession.getRepeatMode());
                    bundle.putInt("android.support.v4.media.argument.SHUFFLE_MODE", MediaSessionLegacyStub.this.mSession.getShuffleMode());
                    list = ((SessionCommandGroup2)object).hasCommand(18) ? MediaSessionLegacyStub.this.mSession.getPlaylist() : null;
                    if (list != null) {
                        bundle.putParcelableArray("android.support.v4.media.argument.PLAYLIST", MediaUtils2.convertMediaItem2ListToParcelableArray(list));
                    }
                    if ((object = ((SessionCommandGroup2)object).hasCommand(20) ? MediaSessionLegacyStub.this.mSession.getCurrentMediaItem() : var3_3) != null) {
                        bundle.putBundle("android.support.v4.media.argument.MEDIA_ITEM", ((MediaItem2)object).toBundle());
                    }
                    bundle.putBundle("android.support.v4.media.argument.PLAYBACK_INFO", MediaSessionLegacyStub.this.mSession.getPlaybackInfo().toBundle());
                    object = MediaSessionLegacyStub.this.mSession.getPlaylistMetadata();
                    if (object != null) {
                        bundle.putBundle("android.support.v4.media.argument.PLAYLIST_METADATA", ((MediaMetadata2)object).toBundle());
                    }
                    if (MediaSessionLegacyStub.this.mSession.isClosed()) {
                        return;
                    }
                    this.val$cb.send(0, bundle);
                    return;
                }
                Object object2 = MediaSessionLegacyStub.this.mLock;
                // MONITORENTER : object2
                MediaSessionLegacyStub.this.mConnectingControllers.remove(this.val$controllerInfo.getId());
                // MONITOREXIT : object2
                if (DEBUG) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("Rejecting connection, controllerInfo=");
                    ((StringBuilder)object).append(this.val$controllerInfo);
                    Log.d((String)MediaSessionLegacyStub.TAG, (String)((StringBuilder)object).toString());
                }
                this.val$cb.send(-1, null);
            }
        });
    }

    private MediaSession2.ControllerInfo createControllerInfo(Bundle bundle) {
        IMediaControllerCallback iMediaControllerCallback = IMediaControllerCallback.Stub.asInterface(BundleCompat.getBinder(bundle, "android.support.v4.media.argument.ICONTROLLER_CALLBACK"));
        String string2 = bundle.getString("android.support.v4.media.argument.PACKAGE_NAME");
        int n = bundle.getInt("android.support.v4.media.argument.UID");
        return new MediaSession2.ControllerInfo(string2, bundle.getInt("android.support.v4.media.argument.PID"), n, new ControllerLegacyCb(iMediaControllerCallback));
    }

    private void disconnect(Bundle object) {
        object = this.createControllerInfo((Bundle)object);
        this.mSession.getCallbackExecutor().execute(new Runnable((MediaSession2.ControllerInfo)object){
            final /* synthetic */ MediaSession2.ControllerInfo val$controllerInfo;
            {
                this.val$controllerInfo = controllerInfo;
            }

            @Override
            public void run() {
                if (MediaSessionLegacyStub.this.mSession.isClosed()) {
                    return;
                }
                MediaSessionLegacyStub.this.mSession.getCallback().onDisconnected(MediaSessionLegacyStub.this.mSession.getInstance(), this.val$controllerInfo);
            }
        });
    }

    /*
     * WARNING - void declaration
     */
    private boolean isAllowedCommand(MediaSession2.ControllerInfo object, int n) {
        Object object2 = this.mLock;
        synchronized (object2) {
            try {
                object = (SessionCommandGroup2)this.mAllowedCommandGroupMap.get(object);
                // MONITOREXIT @DISABLED, blocks:[0, 2] lbl5 : MonitorExitStatement: MONITOREXIT : var3_6
                boolean bl = object != null && ((SessionCommandGroup2)object).hasCommand(n);
                return bl;
            }
            catch (Throwable throwable) {
                while (true) {
                    void var1_3;
                    try {}
                    catch (Throwable throwable2) {
                        continue;
                    }
                    throw var1_3;
                }
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    private boolean isAllowedCommand(MediaSession2.ControllerInfo object, SessionCommand2 sessionCommand2) {
        Object object2 = this.mLock;
        synchronized (object2) {
            try {
                object = (SessionCommandGroup2)this.mAllowedCommandGroupMap.get(object);
                // MONITOREXIT @DISABLED, blocks:[0, 2] lbl5 : MonitorExitStatement: MONITOREXIT : var3_6
                boolean bl = object != null && ((SessionCommandGroup2)object).hasCommand(sessionCommand2);
                return bl;
            }
            catch (Throwable throwable) {
                while (true) {
                    void var1_3;
                    try {}
                    catch (Throwable throwable2) {
                        continue;
                    }
                    throw var1_3;
                }
            }
        }
    }

    private void onCommand2(IBinder iBinder, int n, Session2Runnable session2Runnable) {
        this.onCommand2Internal(iBinder, null, n, session2Runnable);
    }

    private void onCommand2(IBinder iBinder, SessionCommand2 sessionCommand2, Session2Runnable session2Runnable) {
        this.onCommand2Internal(iBinder, sessionCommand2, 0, session2Runnable);
    }

    /*
     * WARNING - void declaration
     */
    private void onCommand2Internal(IBinder object, final SessionCommand2 sessionCommand2, int n, Session2Runnable session2Runnable) {
        Object object2 = this.mLock;
        synchronized (object2) {
            try {
                object = (MediaSession2.ControllerInfo)this.mControllers.get(object);
                // MONITOREXIT @DISABLED, blocks:[0, 2] lbl5 : MonitorExitStatement: MONITOREXIT : var5_8
                object2 = this.mSession;
                if (object2 != null && object != null) {
                    object2.getCallbackExecutor().execute(new Runnable((MediaSession2.ControllerInfo)object, n, session2Runnable){
                        final /* synthetic */ int val$commandCode;
                        final /* synthetic */ MediaSession2.ControllerInfo val$controller;
                        final /* synthetic */ Session2Runnable val$runnable;
                        {
                            this.val$controller = controllerInfo;
                            this.val$commandCode = n;
                            this.val$runnable = session2Runnable;
                        }

                        @Override
                        public void run() {
                            Object object = sessionCommand2;
                            if (object != null) {
                                if (!MediaSessionLegacyStub.this.isAllowedCommand(this.val$controller, (SessionCommand2)object)) {
                                    return;
                                }
                                object = (SessionCommand2)sCommandsForOnCommandRequest.get(sessionCommand2.getCommandCode());
                            } else {
                                if (!MediaSessionLegacyStub.this.isAllowedCommand(this.val$controller, this.val$commandCode)) {
                                    return;
                                }
                                object = (SessionCommand2)sCommandsForOnCommandRequest.get(this.val$commandCode);
                            }
                            if (object != null && !MediaSessionLegacyStub.this.mSession.getCallback().onCommandRequest(MediaSessionLegacyStub.this.mSession.getInstance(), this.val$controller, (SessionCommand2)object)) {
                                if (DEBUG) {
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("Command (");
                                    stringBuilder.append(object);
                                    stringBuilder.append(") from ");
                                    stringBuilder.append(this.val$controller);
                                    stringBuilder.append(" was rejected by ");
                                    stringBuilder.append(MediaSessionLegacyStub.this.mSession);
                                    Log.d((String)MediaSessionLegacyStub.TAG, (String)stringBuilder.toString());
                                }
                                return;
                            }
                            try {
                                this.val$runnable.run(this.val$controller);
                            }
                            catch (RemoteException remoteException) {
                                object = new StringBuilder();
                                ((StringBuilder)object).append("Exception in ");
                                ((StringBuilder)object).append(this.val$controller.toString());
                                Log.w((String)MediaSessionLegacyStub.TAG, (String)((StringBuilder)object).toString(), (Throwable)remoteException);
                            }
                        }
                    });
                    return;
                }
                return;
            }
            catch (Throwable throwable) {
                while (true) {
                    void var1_3;
                    try {}
                    catch (Throwable throwable2) {
                        continue;
                    }
                    throw var1_3;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    List<MediaSession2.ControllerInfo> getConnectedControllers() {
        ArrayList<MediaSession2.ControllerInfo> arrayList = new ArrayList<MediaSession2.ControllerInfo>();
        Object object = this.mLock;
        synchronized (object) {
            int n = 0;
            while (n < this.mControllers.size()) {
                arrayList.add((MediaSession2.ControllerInfo)this.mControllers.valueAt(n));
                ++n;
            }
            return arrayList;
        }
    }

    @Override
    public void onPause() {
        this.mSession.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                if (MediaSessionLegacyStub.this.mSession.isClosed()) {
                    return;
                }
                MediaSessionLegacyStub.this.mSession.pause();
            }
        });
    }

    @Override
    public void onPlay() {
        this.mSession.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                if (MediaSessionLegacyStub.this.mSession.isClosed()) {
                    return;
                }
                MediaSessionLegacyStub.this.mSession.play();
            }
        });
    }

    @Override
    public void onPrepare() {
        this.mSession.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                if (MediaSessionLegacyStub.this.mSession.isClosed()) {
                    return;
                }
                MediaSessionLegacyStub.this.mSession.prepare();
            }
        });
    }

    @Override
    public void onSeekTo(final long l) {
        this.mSession.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                if (MediaSessionLegacyStub.this.mSession.isClosed()) {
                    return;
                }
                MediaSessionLegacyStub.this.mSession.seekTo(l);
            }
        });
    }

    @Override
    public void onStop() {
        this.mSession.getCallbackExecutor().execute(new Runnable(){

            @Override
            public void run() {
                if (MediaSessionLegacyStub.this.mSession.isClosed()) {
                    return;
                }
                MediaSessionLegacyStub.this.mSession.reset();
            }
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void removeControllerInfo(MediaSession2.ControllerInfo controllerInfo) {
        Object object = this.mLock;
        synchronized (object) {
            controllerInfo = (MediaSession2.ControllerInfo)this.mControllers.remove(controllerInfo.getId());
            if (DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("releasing ");
                stringBuilder.append(controllerInfo);
                Log.d((String)TAG, (String)stringBuilder.toString());
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void setAllowedCommands(MediaSession2.ControllerInfo controllerInfo, SessionCommandGroup2 sessionCommandGroup2) {
        Object object = this.mLock;
        synchronized (object) {
            this.mAllowedCommandGroupMap.put(controllerInfo, sessionCommandGroup2);
            return;
        }
    }

    final class ControllerLegacyCb
    extends MediaSession2.ControllerCb {
        private final IMediaControllerCallback mIControllerCallback;

        ControllerLegacyCb(IMediaControllerCallback iMediaControllerCallback) {
            this.mIControllerCallback = iMediaControllerCallback;
        }

        @Override
        IBinder getId() {
            return this.mIControllerCallback.asBinder();
        }

        @Override
        void onAllowedCommandsChanged(SessionCommandGroup2 sessionCommandGroup2) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putBundle("android.support.v4.media.argument.ALLOWED_COMMANDS", sessionCommandGroup2.toBundle());
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_ALLOWED_COMMANDS_CHANGED", bundle);
        }

        @Override
        void onBufferingStateChanged(MediaItem2 mediaItem2, int n, long l) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putBundle("android.support.v4.media.argument.MEDIA_ITEM", mediaItem2.toBundle());
            bundle.putInt("android.support.v4.media.argument.BUFFERING_STATE", n);
            bundle.putParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT", (Parcelable)MediaSessionLegacyStub.this.mSession.getPlaybackStateCompat());
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_BUFFERING_STATE_CHANGED", bundle);
        }

        @Override
        void onChildrenChanged(String string2, int n, Bundle bundle) throws RemoteException {
        }

        @Override
        void onCurrentMediaItemChanged(MediaItem2 mediaItem2) throws RemoteException {
            Bundle bundle = new Bundle();
            mediaItem2 = mediaItem2 == null ? null : mediaItem2.toBundle();
            bundle.putBundle("android.support.v4.media.argument.MEDIA_ITEM", (Bundle)mediaItem2);
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_CURRENT_MEDIA_ITEM_CHANGED", bundle);
        }

        @Override
        void onCustomCommand(SessionCommand2 sessionCommand2, Bundle bundle, ResultReceiver resultReceiver) throws RemoteException {
            Bundle bundle2 = new Bundle();
            bundle2.putBundle("android.support.v4.media.argument.CUSTOM_COMMAND", sessionCommand2.toBundle());
            bundle2.putBundle("android.support.v4.media.argument.ARGUMENTS", bundle);
            bundle2.putParcelable("android.support.v4.media.argument.RESULT_RECEIVER", (Parcelable)resultReceiver);
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.SEND_CUSTOM_COMMAND", bundle2);
        }

        @Override
        void onCustomLayoutChanged(List<MediaSession2.CommandButton> list) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putParcelableArray("android.support.v4.media.argument.COMMAND_BUTTONS", MediaUtils2.convertCommandButtonListToParcelableArray(list));
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.SET_CUSTOM_LAYOUT", bundle);
        }

        @Override
        void onDisconnected() throws RemoteException {
            this.mIControllerCallback.onSessionDestroyed();
        }

        @Override
        void onError(int n, Bundle bundle) throws RemoteException {
            Bundle bundle2 = new Bundle();
            bundle2.putInt("android.support.v4.media.argument.ERROR_CODE", n);
            bundle2.putBundle("android.support.v4.media.argument.EXTRAS", bundle);
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_ERROR", bundle2);
        }

        @Override
        void onGetChildrenDone(String string2, int n, int n2, List<MediaItem2> list, Bundle bundle) throws RemoteException {
        }

        @Override
        void onGetItemDone(String string2, MediaItem2 mediaItem2) throws RemoteException {
        }

        @Override
        void onGetLibraryRootDone(Bundle bundle, String string2, Bundle bundle2) throws RemoteException {
        }

        @Override
        void onGetSearchResultDone(String string2, int n, int n2, List<MediaItem2> list, Bundle bundle) throws RemoteException {
        }

        @Override
        void onPlaybackInfoChanged(MediaController2.PlaybackInfo playbackInfo) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putBundle("android.support.v4.media.argument.PLAYBACK_INFO", playbackInfo.toBundle());
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_PLAYBACK_INFO_CHANGED", bundle);
        }

        @Override
        void onPlaybackSpeedChanged(long l, long l2, float f) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT", (Parcelable)MediaSessionLegacyStub.this.mSession.getPlaybackStateCompat());
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_PLAYBACK_SPEED_CHANGED", bundle);
        }

        @Override
        void onPlayerStateChanged(long l, long l2, int n) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putInt("android.support.v4.media.argument.PLAYER_STATE", n);
            bundle.putParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT", (Parcelable)MediaSessionLegacyStub.this.mSession.getPlaybackStateCompat());
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_PLAYER_STATE_CHANGED", bundle);
        }

        @Override
        void onPlaylistChanged(List<MediaItem2> object, MediaMetadata2 mediaMetadata2) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putParcelableArray("android.support.v4.media.argument.PLAYLIST", MediaUtils2.convertMediaItem2ListToParcelableArray(object));
            object = mediaMetadata2 == null ? null : mediaMetadata2.toBundle();
            bundle.putBundle("android.support.v4.media.argument.PLAYLIST_METADATA", object);
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_PLAYLIST_CHANGED", bundle);
        }

        @Override
        void onPlaylistMetadataChanged(MediaMetadata2 mediaMetadata2) throws RemoteException {
            Bundle bundle = new Bundle();
            mediaMetadata2 = mediaMetadata2 == null ? null : mediaMetadata2.toBundle();
            bundle.putBundle("android.support.v4.media.argument.PLAYLIST_METADATA", (Bundle)mediaMetadata2);
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_PLAYLIST_METADATA_CHANGED", bundle);
        }

        @Override
        void onRepeatModeChanged(int n) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putInt("android.support.v4.media.argument.REPEAT_MODE", n);
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_REPEAT_MODE_CHANGED", bundle);
        }

        @Override
        void onRoutesInfoChanged(List<Bundle> list) throws RemoteException {
            Bundle bundle = null;
            if (list != null) {
                bundle = new Bundle();
                bundle.putParcelableArray("android.support.v4.media.argument.ROUTE_BUNDLE", (Parcelable[])list.toArray(new Bundle[0]));
            }
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_ROUTES_INFO_CHANGED", bundle);
        }

        @Override
        void onSearchResultChanged(String string2, int n, Bundle bundle) throws RemoteException {
        }

        @Override
        void onSeekCompleted(long l, long l2, long l3) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putLong("android.support.v4.media.argument.SEEK_POSITION", l3);
            bundle.putParcelable("android.support.v4.media.argument.PLAYBACK_STATE_COMPAT", (Parcelable)MediaSessionLegacyStub.this.mSession.getPlaybackStateCompat());
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_SEEK_COMPLETED", bundle);
        }

        @Override
        void onShuffleModeChanged(int n) throws RemoteException {
            Bundle bundle = new Bundle();
            bundle.putInt("android.support.v4.media.argument.SHUFFLE_MODE", n);
            this.mIControllerCallback.onEvent("android.support.v4.media.session.event.ON_SHUFFLE_MODE_CHANGED", bundle);
        }
    }

    @FunctionalInterface
    private static interface Session2Runnable {
        public void run(MediaSession2.ControllerInfo var1) throws RemoteException;
    }
}

