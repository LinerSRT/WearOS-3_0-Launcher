/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.os.Bundle
 *  android.text.TextUtils
 */
package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.v4.app.BundleCompat;
import android.support.v4.media.IMediaSession2;
import android.support.v4.media.SessionToken2;
import android.text.TextUtils;

final class SessionToken2ImplBase
implements SessionToken2.SupportLibraryImpl {
    private final ComponentName mComponentName;
    private final IMediaSession2 mISession2;
    private final String mPackageName;
    private final String mServiceName;
    private final String mSessionId;
    private final int mType;
    private final int mUid;

    SessionToken2ImplBase(int n, int n2, String string2, String string3, String string4, IMediaSession2 iMediaSession2) {
        this.mUid = n;
        this.mType = n2;
        this.mPackageName = string2;
        this.mServiceName = string3;
        string2 = n2 == 0 ? null : new ComponentName(string2, string3);
        this.mComponentName = string2;
        this.mSessionId = string4;
        this.mISession2 = iMediaSession2;
    }

    SessionToken2ImplBase(Context context, ComponentName componentName) {
        this(context, componentName, -1);
    }

    SessionToken2ImplBase(Context object, ComponentName componentName, int n) {
        if (componentName != null) {
            this.mComponentName = componentName;
            this.mPackageName = componentName.getPackageName();
            this.mServiceName = componentName.getClassName();
            PackageManager packageManager = object.getPackageManager();
            int n2 = n;
            if (n == -1) {
                try {
                    n2 = packageManager.getApplicationInfo((String)this.mPackageName, (int)0).uid;
                }
                catch (PackageManager.NameNotFoundException nameNotFoundException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Cannot find package ");
                    stringBuilder.append(this.mPackageName);
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
            }
            this.mUid = n2;
            object = SessionToken2ImplBase.getSessionIdFromService(packageManager, "android.media.MediaLibraryService2", componentName);
            if (object != null) {
                this.mSessionId = object;
                this.mType = 2;
            } else {
                this.mSessionId = SessionToken2ImplBase.getSessionIdFromService(packageManager, "android.media.MediaSessionService2", componentName);
                this.mType = 1;
            }
            if (this.mSessionId != null) {
                this.mISession2 = null;
                return;
            }
            object = new StringBuilder();
            ((StringBuilder)object).append("service ");
            ((StringBuilder)object).append(this.mServiceName);
            ((StringBuilder)object).append(" doesn't implement");
            ((StringBuilder)object).append(" session service nor library service. Use service's full name.");
            throw new IllegalArgumentException(((StringBuilder)object).toString());
        }
        throw new IllegalArgumentException("serviceComponent shouldn't be null");
    }

    public static SessionToken2ImplBase fromBundle(Bundle object) {
        CharSequence charSequence;
        block10: {
            String string2;
            String string3;
            int n;
            int n2;
            block9: {
                block8: {
                    if (object == null) {
                        return null;
                    }
                    n2 = object.getInt("android.media.token.uid");
                    n = object.getInt("android.media.token.type", -1);
                    string3 = object.getString("android.media.token.package_name");
                    string2 = object.getString("android.media.token.service_name");
                    charSequence = object.getString("android.media.token.session_id");
                    object = IMediaSession2.Stub.asInterface(BundleCompat.getBinder(object, "android.media.token.session_binder"));
                    if (n == 0) break block8;
                    if (n != 1 && n != 2) {
                        throw new IllegalArgumentException("Invalid type");
                    }
                    if (TextUtils.isEmpty((CharSequence)string2)) {
                        throw new IllegalArgumentException("Session service needs service name");
                    }
                    break block9;
                }
                if (object == null) break block10;
            }
            if (!TextUtils.isEmpty((CharSequence)string3) && charSequence != null) {
                return new SessionToken2ImplBase(n2, n, string3, string2, (String)charSequence, (IMediaSession2)object);
            }
            throw new IllegalArgumentException("Package name nor ID cannot be null.");
        }
        charSequence = new StringBuilder();
        ((StringBuilder)charSequence).append("Unexpected token for session, binder=");
        ((StringBuilder)charSequence).append(object);
        throw new IllegalArgumentException(((StringBuilder)charSequence).toString());
    }

    public static String getSessionId(ResolveInfo resolveInfo) {
        if (resolveInfo != null && resolveInfo.serviceInfo != null) {
            if (resolveInfo.serviceInfo.metaData == null) {
                return "";
            }
            return resolveInfo.serviceInfo.metaData.getString("android.media.session", "");
        }
        return null;
    }

    private static String getSessionIdFromService(PackageManager object, String string2, ComponentName componentName) {
        string2 = new Intent(string2);
        string2.setPackage(componentName.getPackageName());
        object = object.queryIntentServices((Intent)string2, 128);
        if (object != null) {
            for (int i = 0; i < object.size(); ++i) {
                string2 = (ResolveInfo)object.get(i);
                if (string2 == null || ((ResolveInfo)string2).serviceInfo == null || !TextUtils.equals((CharSequence)string2.serviceInfo.name, (CharSequence)componentName.getClassName())) continue;
                return SessionToken2ImplBase.getSessionId((ResolveInfo)string2);
            }
        }
        return null;
    }

    private boolean sessionBinderEquals(IMediaSession2 iMediaSession2, IMediaSession2 iMediaSession22) {
        if (iMediaSession2 != null && iMediaSession22 != null) {
            return iMediaSession2.asBinder().equals(iMediaSession22.asBinder());
        }
        boolean bl = iMediaSession2 == iMediaSession22;
        return bl;
    }

    public boolean equals(Object object) {
        boolean bl;
        block1: {
            boolean bl2 = object instanceof SessionToken2ImplBase;
            bl = false;
            if (!bl2) {
                return false;
            }
            object = (SessionToken2ImplBase)object;
            if (this.mUid != ((SessionToken2ImplBase)object).mUid || !TextUtils.equals((CharSequence)this.mPackageName, (CharSequence)((SessionToken2ImplBase)object).mPackageName) || !TextUtils.equals((CharSequence)this.mServiceName, (CharSequence)((SessionToken2ImplBase)object).mServiceName) || !TextUtils.equals((CharSequence)this.mSessionId, (CharSequence)((SessionToken2ImplBase)object).mSessionId) || this.mType != ((SessionToken2ImplBase)object).mType || !this.sessionBinderEquals(this.mISession2, ((SessionToken2ImplBase)object).mISession2)) break block1;
            bl = true;
        }
        return bl;
    }

    @Override
    public Object getBinder() {
        IMediaSession2 iMediaSession2 = this.mISession2;
        iMediaSession2 = iMediaSession2 == null ? null : iMediaSession2.asBinder();
        return iMediaSession2;
    }

    @Override
    public ComponentName getComponentName() {
        return this.mComponentName;
    }

    @Override
    public String getPackageName() {
        return this.mPackageName;
    }

    @Override
    public String getServiceName() {
        return this.mServiceName;
    }

    @Override
    public String getSessionId() {
        return this.mSessionId;
    }

    @Override
    public int getType() {
        return this.mType;
    }

    @Override
    public int getUid() {
        return this.mUid;
    }

    public int hashCode() {
        int n = this.mType;
        int n2 = this.mUid;
        int n3 = this.mPackageName.hashCode();
        int n4 = this.mSessionId.hashCode();
        String string2 = this.mServiceName;
        int n5 = string2 != null ? string2.hashCode() : 0;
        return n + (n2 + (n3 + (n4 + n5 * 31) * 31) * 31) * 31;
    }

    @Override
    public Bundle toBundle() {
        Bundle bundle = new Bundle();
        bundle.putInt("android.media.token.uid", this.mUid);
        bundle.putString("android.media.token.package_name", this.mPackageName);
        bundle.putString("android.media.token.service_name", this.mServiceName);
        bundle.putString("android.media.token.session_id", this.mSessionId);
        bundle.putInt("android.media.token.type", this.mType);
        IMediaSession2 iMediaSession2 = this.mISession2;
        if (iMediaSession2 != null) {
            BundleCompat.putBinder(bundle, "android.media.token.session_binder", iMediaSession2.asBinder());
        }
        return bundle;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SessionToken {pkg=");
        stringBuilder.append(this.mPackageName);
        stringBuilder.append(" id=");
        stringBuilder.append(this.mSessionId);
        stringBuilder.append(" type=");
        stringBuilder.append(this.mType);
        stringBuilder.append(" service=");
        stringBuilder.append(this.mServiceName);
        stringBuilder.append(" IMediaSession2=");
        stringBuilder.append(this.mISession2);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

