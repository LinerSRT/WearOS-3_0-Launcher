/*
 * Decompiled with CFR 0.151.
 */
package android.support.v4.media;

import java.io.Closeable;
import java.io.IOException;

public abstract class Media2DataSource
implements Closeable {
    public abstract long getSize() throws IOException;

    public abstract int readAt(long var1, byte[] var3, int var4, int var5) throws IOException;
}

