/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.Region$Op
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  android.os.Build$VERSION
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$ClassLoaderCreator
 *  android.os.Parcelable$Creator
 *  android.os.SystemClock
 *  android.support.coordinatorlayout.R$attr
 *  android.support.coordinatorlayout.R$style
 *  android.support.coordinatorlayout.R$styleable
 *  android.support.v4.content.ContextCompat
 *  android.support.v4.graphics.drawable.DrawableCompat
 *  android.support.v4.util.ObjectsCompat
 *  android.support.v4.util.Pools$Pool
 *  android.support.v4.util.Pools$SynchronizedPool
 *  android.support.v4.view.AbsSavedState
 *  android.support.v4.view.GravityCompat
 *  android.support.v4.view.NestedScrollingParent2
 *  android.support.v4.view.NestedScrollingParentHelper
 *  android.support.v4.view.OnApplyWindowInsetsListener
 *  android.support.v4.view.ViewCompat
 *  android.support.v4.view.WindowInsetsCompat
 *  android.support.v4.widget.DirectedAcyclicGraph
 *  android.support.v4.widget.ViewGroupUtils
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.util.SparseArray
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  android.view.ViewGroup$OnHierarchyChangeListener
 *  android.view.ViewParent
 *  android.view.ViewTreeObserver$OnPreDrawListener
 */
package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.coordinatorlayout.R;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.util.ObjectsCompat;
import android.support.v4.util.Pools;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.NestedScrollingParent2;
import android.support.v4.view.NestedScrollingParentHelper;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v4.widget.DirectedAcyclicGraph;
import android.support.v4.widget.ViewGroupUtils;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoordinatorLayout
extends ViewGroup
implements NestedScrollingParent2 {
    static final Class<?>[] CONSTRUCTOR_PARAMS;
    static final int EVENT_NESTED_SCROLL = 1;
    static final int EVENT_PRE_DRAW = 0;
    static final int EVENT_VIEW_REMOVED = 2;
    static final String TAG = "CoordinatorLayout";
    static final Comparator<View> TOP_SORTED_CHILDREN_COMPARATOR;
    private static final int TYPE_ON_INTERCEPT = 0;
    private static final int TYPE_ON_TOUCH = 1;
    static final String WIDGET_PACKAGE_NAME;
    static final ThreadLocal<Map<String, Constructor<Behavior>>> sConstructors;
    private static final Pools.Pool<Rect> sRectPool;
    private OnApplyWindowInsetsListener mApplyWindowInsetsListener;
    private View mBehaviorTouchView;
    private final DirectedAcyclicGraph<View> mChildDag;
    private final List<View> mDependencySortedChildren = new ArrayList<View>();
    private boolean mDisallowInterceptReset;
    private boolean mDrawStatusBarBackground;
    private boolean mIsAttachedToWindow;
    private int[] mKeylines;
    private WindowInsetsCompat mLastInsets;
    private boolean mNeedsPreDrawListener;
    private final NestedScrollingParentHelper mNestedScrollingParentHelper;
    private View mNestedScrollingTarget;
    ViewGroup.OnHierarchyChangeListener mOnHierarchyChangeListener;
    private OnPreDrawListener mOnPreDrawListener;
    private Paint mScrimPaint;
    private Drawable mStatusBarBackground;
    private final List<View> mTempDependenciesList;
    private final int[] mTempIntPair;
    private final List<View> mTempList1;

    static {
        Object object = CoordinatorLayout.class.getPackage();
        object = object != null ? ((Package)object).getName() : null;
        WIDGET_PACKAGE_NAME = object;
        TOP_SORTED_CHILDREN_COMPARATOR = Build.VERSION.SDK_INT >= 21 ? new ViewElevationComparator() : null;
        CONSTRUCTOR_PARAMS = new Class[]{Context.class, AttributeSet.class};
        sConstructors = new ThreadLocal();
        sRectPool = new Pools.SynchronizedPool(12);
    }

    public CoordinatorLayout(Context context) {
        this(context, null);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.coordinatorLayoutStyle);
    }

    public CoordinatorLayout(Context object, AttributeSet attributeSet, int n) {
        super(object, attributeSet, n);
        this.mChildDag = new DirectedAcyclicGraph();
        this.mTempList1 = new ArrayList<View>();
        this.mTempDependenciesList = new ArrayList<View>();
        this.mTempIntPair = new int[2];
        this.mNestedScrollingParentHelper = new NestedScrollingParentHelper((ViewGroup)this);
        attributeSet = n == 0 ? object.obtainStyledAttributes(attributeSet, R.styleable.CoordinatorLayout, 0, R.style.Widget_Support_CoordinatorLayout) : object.obtainStyledAttributes(attributeSet, R.styleable.CoordinatorLayout, n, 0);
        n = attributeSet.getResourceId(R.styleable.CoordinatorLayout_keylines, 0);
        if (n != 0) {
            object = object.getResources();
            this.mKeylines = object.getIntArray(n);
            float f = object.getDisplayMetrics().density;
            int n2 = this.mKeylines.length;
            for (n = 0; n < n2; ++n) {
                object = this.mKeylines;
                object[n] = (Context)((int)((float)object[n] * f));
            }
        }
        this.mStatusBarBackground = attributeSet.getDrawable(R.styleable.CoordinatorLayout_statusBarBackground);
        attributeSet.recycle();
        this.setupForInsets();
        super.setOnHierarchyChangeListener((ViewGroup.OnHierarchyChangeListener)new HierarchyChangeListener());
    }

    private static Rect acquireTempRect() {
        Rect rect;
        Rect rect2 = rect = (Rect)sRectPool.acquire();
        if (rect == null) {
            rect2 = new Rect();
        }
        return rect2;
    }

    private static int clamp(int n, int n2, int n3) {
        if (n < n2) {
            return n2;
        }
        if (n > n3) {
            return n3;
        }
        return n;
    }

    private void constrainChildRect(LayoutParams layoutParams, Rect rect, int n, int n2) {
        int n3 = this.getWidth();
        int n4 = this.getHeight();
        n3 = Math.max(this.getPaddingLeft() + layoutParams.leftMargin, Math.min(rect.left, n3 - this.getPaddingRight() - n - layoutParams.rightMargin));
        n4 = Math.max(this.getPaddingTop() + layoutParams.topMargin, Math.min(rect.top, n4 - this.getPaddingBottom() - n2 - layoutParams.bottomMargin));
        rect.set(n3, n4, n3 + n, n4 + n2);
    }

    private WindowInsetsCompat dispatchApplyWindowInsetsToBehaviors(WindowInsetsCompat windowInsetsCompat) {
        WindowInsetsCompat windowInsetsCompat2;
        if (windowInsetsCompat.isConsumed()) {
            return windowInsetsCompat;
        }
        int n = 0;
        int n2 = this.getChildCount();
        while (true) {
            windowInsetsCompat2 = windowInsetsCompat;
            if (n >= n2) break;
            View view = this.getChildAt(n);
            windowInsetsCompat2 = windowInsetsCompat;
            if (ViewCompat.getFitsSystemWindows((View)view)) {
                Behavior behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
                windowInsetsCompat2 = windowInsetsCompat;
                if (behavior != null) {
                    windowInsetsCompat2 = windowInsetsCompat = behavior.onApplyWindowInsets(this, view, windowInsetsCompat);
                    if (windowInsetsCompat.isConsumed()) {
                        windowInsetsCompat2 = windowInsetsCompat;
                        break;
                    }
                }
            }
            ++n;
            windowInsetsCompat = windowInsetsCompat2;
        }
        return windowInsetsCompat2;
    }

    private void getDesiredAnchoredChildRectWithoutConstraints(View view, int n, Rect rect, Rect rect2, LayoutParams layoutParams, int n2, int n3) {
        int n4 = GravityCompat.getAbsoluteGravity((int)CoordinatorLayout.resolveAnchoredChildGravity(layoutParams.gravity), (int)n);
        int n5 = GravityCompat.getAbsoluteGravity((int)CoordinatorLayout.resolveGravity(layoutParams.anchorGravity), (int)n);
        int n6 = n4 & 7;
        n4 &= 0x70;
        n = n5 & 7;
        n5 &= 0x70;
        n = n != 1 ? (n != 5 ? rect.left : rect.right) : rect.left + rect.width() / 2;
        n5 = n5 != 16 ? (n5 != 80 ? rect.top : rect.bottom) : rect.top + rect.height() / 2;
        if (n6 != 1) {
            if (n6 != 5) {
                n -= n2;
            }
        } else {
            n -= n2 / 2;
        }
        if (n4 != 16) {
            if (n4 != 80) {
                n5 -= n3;
            }
        } else {
            n5 -= n3 / 2;
        }
        rect2.set(n, n5, n + n2, n5 + n3);
    }

    private int getKeyline(int n) {
        Object object = this.mKeylines;
        if (object == null) {
            object = new StringBuilder();
            object.append("No keylines defined for ");
            object.append((Object)this);
            object.append(" - attempted index lookup ");
            object.append(n);
            Log.e((String)TAG, (String)object.toString());
            return 0;
        }
        if (n >= 0 && n < ((int[])object).length) {
            return object[n];
        }
        object = new StringBuilder();
        object.append("Keyline index ");
        object.append(n);
        object.append(" out of range for ");
        object.append((Object)this);
        Log.e((String)TAG, (String)object.toString());
        return 0;
    }

    private void getTopSortedChildren(List<View> list) {
        list.clear();
        boolean bl = this.isChildrenDrawingOrderEnabled();
        int n = this.getChildCount();
        for (int i = n - 1; i >= 0; --i) {
            int n2 = bl ? this.getChildDrawingOrder(n, i) : i;
            list.add(this.getChildAt(n2));
        }
        Comparator<View> comparator = TOP_SORTED_CHILDREN_COMPARATOR;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
    }

    private boolean hasDependencies(View view) {
        return this.mChildDag.hasOutgoingEdges((Object)view);
    }

    private void layoutChild(View view, int n) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        Rect rect = CoordinatorLayout.acquireTempRect();
        rect.set(this.getPaddingLeft() + layoutParams.leftMargin, this.getPaddingTop() + layoutParams.topMargin, this.getWidth() - this.getPaddingRight() - layoutParams.rightMargin, this.getHeight() - this.getPaddingBottom() - layoutParams.bottomMargin);
        if (this.mLastInsets != null && ViewCompat.getFitsSystemWindows((View)this) && !ViewCompat.getFitsSystemWindows((View)view)) {
            rect.left += this.mLastInsets.getSystemWindowInsetLeft();
            rect.top += this.mLastInsets.getSystemWindowInsetTop();
            rect.right -= this.mLastInsets.getSystemWindowInsetRight();
            rect.bottom -= this.mLastInsets.getSystemWindowInsetBottom();
        }
        Rect rect2 = CoordinatorLayout.acquireTempRect();
        GravityCompat.apply((int)CoordinatorLayout.resolveGravity(layoutParams.gravity), (int)view.getMeasuredWidth(), (int)view.getMeasuredHeight(), (Rect)rect, (Rect)rect2, (int)n);
        view.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
        CoordinatorLayout.releaseTempRect(rect);
        CoordinatorLayout.releaseTempRect(rect2);
    }

    private void layoutChildWithAnchor(View view, View view2, int n) {
        Rect rect = CoordinatorLayout.acquireTempRect();
        Rect rect2 = CoordinatorLayout.acquireTempRect();
        try {
            this.getDescendantRect(view2, rect);
            this.getDesiredAnchoredChildRect(view, n, rect, rect2);
            view.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
            return;
        }
        finally {
            CoordinatorLayout.releaseTempRect(rect);
            CoordinatorLayout.releaseTempRect(rect2);
        }
    }

    private void layoutChildWithKeyline(View view, int n, int n2) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        int n3 = GravityCompat.getAbsoluteGravity((int)CoordinatorLayout.resolveKeylineGravity(layoutParams.gravity), (int)n2);
        int n4 = n3 & 7;
        int n5 = n3 & 0x70;
        int n6 = this.getWidth();
        int n7 = this.getHeight();
        int n8 = view.getMeasuredWidth();
        n3 = view.getMeasuredHeight();
        if (n2 == 1) {
            n = n6 - n;
        }
        n = this.getKeyline(n) - n8;
        n2 = 0;
        if (n4 != 1) {
            if (n4 == 5) {
                n += n8;
            }
        } else {
            n += n8 / 2;
        }
        if (n5 != 16) {
            if (n5 == 80) {
                n2 = 0 + n3;
            }
        } else {
            n2 = 0 + n3 / 2;
        }
        n = Math.max(this.getPaddingLeft() + layoutParams.leftMargin, Math.min(n, n6 - this.getPaddingRight() - n8 - layoutParams.rightMargin));
        n2 = Math.max(this.getPaddingTop() + layoutParams.topMargin, Math.min(n2, n7 - this.getPaddingBottom() - n3 - layoutParams.bottomMargin));
        view.layout(n, n2, n + n8, n2 + n3);
    }

    private void offsetChildByInset(View object, Rect rect, int n) {
        if (!ViewCompat.isLaidOut((View)object)) {
            return;
        }
        if (object.getWidth() > 0 && object.getHeight() > 0) {
            int n2;
            int n3;
            LayoutParams layoutParams = (LayoutParams)object.getLayoutParams();
            Behavior behavior = layoutParams.getBehavior();
            Rect rect2 = CoordinatorLayout.acquireTempRect();
            Rect rect3 = CoordinatorLayout.acquireTempRect();
            rect3.set(object.getLeft(), object.getTop(), object.getRight(), object.getBottom());
            if (behavior != null && behavior.getInsetDodgeRect(this, object, rect2)) {
                if (!rect3.contains(rect2)) {
                    object = new StringBuilder();
                    ((StringBuilder)object).append("Rect should be within the child's bounds. Rect:");
                    ((StringBuilder)object).append(rect2.toShortString());
                    ((StringBuilder)object).append(" | Bounds:");
                    ((StringBuilder)object).append(rect3.toShortString());
                    throw new IllegalArgumentException(((StringBuilder)object).toString());
                }
            } else {
                rect2.set(rect3);
            }
            CoordinatorLayout.releaseTempRect(rect3);
            if (rect2.isEmpty()) {
                CoordinatorLayout.releaseTempRect(rect2);
                return;
            }
            int n4 = GravityCompat.getAbsoluteGravity((int)layoutParams.dodgeInsetEdges, (int)n);
            n = n3 = 0;
            if ((n4 & 0x30) == 48) {
                n2 = rect2.top - layoutParams.topMargin - layoutParams.mInsetOffsetY;
                n = n3;
                if (n2 < rect.top) {
                    this.setInsetOffsetY((View)object, rect.top - n2);
                    n = 1;
                }
            }
            n3 = n;
            if ((n4 & 0x50) == 80) {
                n2 = this.getHeight() - rect2.bottom - layoutParams.bottomMargin + layoutParams.mInsetOffsetY;
                n3 = n;
                if (n2 < rect.bottom) {
                    this.setInsetOffsetY((View)object, n2 - rect.bottom);
                    n3 = 1;
                }
            }
            if (n3 == 0) {
                this.setInsetOffsetY((View)object, 0);
            }
            n = n3 = 0;
            if ((n4 & 3) == 3) {
                n2 = rect2.left - layoutParams.leftMargin - layoutParams.mInsetOffsetX;
                n = n3;
                if (n2 < rect.left) {
                    this.setInsetOffsetX((View)object, rect.left - n2);
                    n = 1;
                }
            }
            n3 = n;
            if ((n4 & 5) == 5) {
                n4 = this.getWidth() - rect2.right - layoutParams.rightMargin + layoutParams.mInsetOffsetX;
                n3 = n;
                if (n4 < rect.right) {
                    this.setInsetOffsetX((View)object, n4 - rect.right);
                    n3 = 1;
                }
            }
            if (n3 == 0) {
                this.setInsetOffsetX((View)object, 0);
            }
            CoordinatorLayout.releaseTempRect(rect2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static Behavior parseBehavior(Context object, AttributeSet object2, String string2) {
        StringBuilder stringBuilder;
        HashMap hashMap;
        String string3;
        if (TextUtils.isEmpty((CharSequence)string3)) {
            return null;
        }
        if (string3.startsWith(".")) {
            hashMap = new StringBuilder();
            ((StringBuilder)((Object)hashMap)).append(object.getPackageName());
            ((StringBuilder)((Object)hashMap)).append(string3);
            string3 = ((StringBuilder)((Object)hashMap)).toString();
        } else if (string3.indexOf(46) < 0 && !TextUtils.isEmpty((CharSequence)WIDGET_PACKAGE_NAME)) {
            hashMap = new StringBuilder();
            ((StringBuilder)((Object)hashMap)).append(WIDGET_PACKAGE_NAME);
            ((StringBuilder)((Object)hashMap)).append('.');
            ((StringBuilder)((Object)hashMap)).append(string3);
            string3 = ((StringBuilder)((Object)hashMap)).toString();
        }
        try {
            Constructor<?> constructor = sConstructors.get();
            hashMap = constructor;
            if (constructor == null) {
                hashMap = new HashMap();
                sConstructors.set(hashMap);
            }
            Constructor constructor2 = (Constructor)hashMap.get(string3);
            constructor = constructor2;
            if (constructor2 == null) {
                constructor = object.getClassLoader().loadClass(string3).getConstructor(CONSTRUCTOR_PARAMS);
                constructor.setAccessible(true);
                hashMap.put(string3, constructor);
            }
            return (Behavior)constructor.newInstance(object, stringBuilder);
        }
        catch (Exception exception) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Could not inflate Behavior subclass ");
            stringBuilder.append(string3);
            throw new RuntimeException(stringBuilder.toString(), exception);
        }
    }

    private boolean performIntercept(MotionEvent motionEvent, int n) {
        boolean bl;
        boolean bl2 = false;
        boolean bl3 = false;
        LayoutParams layoutParams = null;
        int n2 = motionEvent.getActionMasked();
        List<View> list = this.mTempList1;
        this.getTopSortedChildren(list);
        int n3 = list.size();
        int n4 = 0;
        while (true) {
            boolean bl4;
            bl = bl2;
            if (n4 >= n3) break;
            View view = list.get(n4);
            LayoutParams layoutParams2 = (LayoutParams)view.getLayoutParams();
            Behavior behavior = layoutParams2.getBehavior();
            boolean bl5 = true;
            if ((bl2 || bl3) && n2 != 0) {
                bl4 = bl2;
                bl5 = bl3;
                layoutParams2 = layoutParams;
                if (behavior != null) {
                    layoutParams2 = layoutParams;
                    if (layoutParams == null) {
                        long l = SystemClock.uptimeMillis();
                        layoutParams2 = MotionEvent.obtain((long)l, (long)l, (int)3, (float)0.0f, (float)0.0f, (int)0);
                    }
                    if (n != 0) {
                        if (n == 1) {
                            behavior.onTouchEvent(this, view, (MotionEvent)layoutParams2);
                        }
                    } else {
                        behavior.onInterceptTouchEvent(this, view, (MotionEvent)layoutParams2);
                    }
                    bl4 = bl2;
                    bl5 = bl3;
                }
            } else {
                bl = bl2;
                if (!bl2) {
                    bl = bl2;
                    if (behavior != null) {
                        if (n != 0) {
                            if (n == 1) {
                                bl2 = behavior.onTouchEvent(this, view, motionEvent);
                            }
                        } else {
                            bl2 = behavior.onInterceptTouchEvent(this, view, motionEvent);
                        }
                        bl = bl2;
                        if (bl2) {
                            this.mBehaviorTouchView = view;
                            bl = bl2;
                        }
                    }
                }
                bl4 = layoutParams2.didBlockInteraction();
                bl2 = layoutParams2.isBlockingInteractionBelow(this, view);
                if (!bl2 || bl4) {
                    bl5 = false;
                }
                bl3 = bl5;
                bl4 = bl;
                bl5 = bl3;
                layoutParams2 = layoutParams;
                if (bl2) {
                    bl4 = bl;
                    bl5 = bl3;
                    layoutParams2 = layoutParams;
                    if (!bl3) break;
                }
            }
            ++n4;
            bl2 = bl4;
            bl3 = bl5;
            layoutParams = layoutParams2;
        }
        list.clear();
        return bl;
    }

    private void prepareChildren() {
        this.mDependencySortedChildren.clear();
        this.mChildDag.clear();
        int n = this.getChildCount();
        for (int i = 0; i < n; ++i) {
            View view = this.getChildAt(i);
            LayoutParams layoutParams = this.getResolvedLayoutParams(view);
            layoutParams.findAnchorView(this, view);
            this.mChildDag.addNode((Object)view);
            for (int j = 0; j < n; ++j) {
                View view2;
                if (j == i || !layoutParams.dependsOn(this, view, view2 = this.getChildAt(j))) continue;
                if (!this.mChildDag.contains((Object)view2)) {
                    this.mChildDag.addNode((Object)view2);
                }
                this.mChildDag.addEdge((Object)view2, (Object)view);
            }
        }
        this.mDependencySortedChildren.addAll(this.mChildDag.getSortedList());
        Collections.reverse(this.mDependencySortedChildren);
    }

    private static void releaseTempRect(Rect rect) {
        rect.setEmpty();
        sRectPool.release((Object)rect);
    }

    private void resetTouchBehaviors(boolean bl) {
        int n;
        int n2 = this.getChildCount();
        for (n = 0; n < n2; ++n) {
            View view = this.getChildAt(n);
            Behavior behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
            if (behavior == null) continue;
            long l = SystemClock.uptimeMillis();
            MotionEvent motionEvent = MotionEvent.obtain((long)l, (long)l, (int)3, (float)0.0f, (float)0.0f, (int)0);
            if (bl) {
                behavior.onInterceptTouchEvent(this, view, motionEvent);
            } else {
                behavior.onTouchEvent(this, view, motionEvent);
            }
            motionEvent.recycle();
        }
        for (n = 0; n < n2; ++n) {
            ((LayoutParams)this.getChildAt(n).getLayoutParams()).resetTouchBehaviorTracking();
        }
        this.mBehaviorTouchView = null;
        this.mDisallowInterceptReset = false;
    }

    private static int resolveAnchoredChildGravity(int n) {
        block0: {
            if (n != 0) break block0;
            n = 17;
        }
        return n;
    }

    private static int resolveGravity(int n) {
        int n2 = n;
        if ((n & 7) == 0) {
            n2 = n | 0x800003;
        }
        n = n2;
        if ((n2 & 0x70) == 0) {
            n = n2 | 0x30;
        }
        return n;
    }

    private static int resolveKeylineGravity(int n) {
        block0: {
            if (n != 0) break block0;
            n = 8388661;
        }
        return n;
    }

    private void setInsetOffsetX(View view, int n) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.mInsetOffsetX != n) {
            ViewCompat.offsetLeftAndRight((View)view, (int)(n - layoutParams.mInsetOffsetX));
            layoutParams.mInsetOffsetX = n;
        }
    }

    private void setInsetOffsetY(View view, int n) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.mInsetOffsetY != n) {
            ViewCompat.offsetTopAndBottom((View)view, (int)(n - layoutParams.mInsetOffsetY));
            layoutParams.mInsetOffsetY = n;
        }
    }

    private void setupForInsets() {
        if (Build.VERSION.SDK_INT < 21) {
            return;
        }
        if (ViewCompat.getFitsSystemWindows((View)this)) {
            if (this.mApplyWindowInsetsListener == null) {
                this.mApplyWindowInsetsListener = new OnApplyWindowInsetsListener(){

                    public WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
                        return CoordinatorLayout.this.setWindowInsets(windowInsetsCompat);
                    }
                };
            }
            ViewCompat.setOnApplyWindowInsetsListener((View)this, (OnApplyWindowInsetsListener)this.mApplyWindowInsetsListener);
            this.setSystemUiVisibility(1280);
        } else {
            ViewCompat.setOnApplyWindowInsetsListener((View)this, null);
        }
    }

    void addPreDrawListener() {
        if (this.mIsAttachedToWindow) {
            if (this.mOnPreDrawListener == null) {
                this.mOnPreDrawListener = new OnPreDrawListener();
            }
            this.getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.mOnPreDrawListener);
        }
        this.mNeedsPreDrawListener = true;
    }

    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        boolean bl = layoutParams instanceof LayoutParams && super.checkLayoutParams(layoutParams);
        return bl;
    }

    public void dispatchDependentViewsChanged(View view) {
        List list = this.mChildDag.getIncomingEdges((Object)view);
        if (list != null && !list.isEmpty()) {
            for (int i = 0; i < list.size(); ++i) {
                View view2 = (View)list.get(i);
                Behavior behavior = ((LayoutParams)view2.getLayoutParams()).getBehavior();
                if (behavior == null) continue;
                behavior.onDependentViewChanged(this, view2, view);
            }
        }
    }

    public boolean doViewsOverlap(View view, View view2) {
        int n = view.getVisibility();
        boolean bl = false;
        if (n == 0 && view2.getVisibility() == 0) {
            boolean bl2;
            Rect rect;
            block5: {
                rect = CoordinatorLayout.acquireTempRect();
                bl2 = view.getParent() != this;
                this.getChildRect(view, bl2, rect);
                view = CoordinatorLayout.acquireTempRect();
                bl2 = view2.getParent() != this;
                this.getChildRect(view2, bl2, (Rect)view);
                bl2 = bl;
                try {
                    if (rect.left > view.right) break block5;
                    bl2 = bl;
                }
                catch (Throwable throwable) {
                    CoordinatorLayout.releaseTempRect(rect);
                    CoordinatorLayout.releaseTempRect((Rect)view);
                    throw throwable;
                }
                if (rect.top > view.bottom) break block5;
                bl2 = bl;
                if (rect.right < view.left) break block5;
                n = rect.bottom;
                int n2 = view.top;
                bl2 = bl;
                if (n < n2) break block5;
                bl2 = true;
            }
            CoordinatorLayout.releaseTempRect(rect);
            CoordinatorLayout.releaseTempRect((Rect)view);
            return bl2;
        }
        return false;
    }

    protected boolean drawChild(Canvas canvas, View view, long l) {
        float f;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.mBehavior != null && (f = layoutParams.mBehavior.getScrimOpacity(this, view)) > 0.0f) {
            if (this.mScrimPaint == null) {
                this.mScrimPaint = new Paint();
            }
            this.mScrimPaint.setColor(layoutParams.mBehavior.getScrimColor(this, view));
            this.mScrimPaint.setAlpha(CoordinatorLayout.clamp(Math.round(255.0f * f), 0, 255));
            int n = canvas.save();
            if (view.isOpaque()) {
                canvas.clipRect((float)view.getLeft(), (float)view.getTop(), (float)view.getRight(), (float)view.getBottom(), Region.Op.DIFFERENCE);
            }
            canvas.drawRect((float)this.getPaddingLeft(), (float)this.getPaddingTop(), (float)(this.getWidth() - this.getPaddingRight()), (float)(this.getHeight() - this.getPaddingBottom()), this.mScrimPaint);
            canvas.restoreToCount(n);
        }
        return super.drawChild(canvas, view, l);
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] nArray = this.getDrawableState();
        boolean bl = false;
        Drawable drawable2 = this.mStatusBarBackground;
        boolean bl2 = bl;
        if (drawable2 != null) {
            bl2 = bl;
            if (drawable2.isStateful()) {
                bl2 = false | drawable2.setState(nArray);
            }
        }
        if (bl2) {
            this.invalidate();
        }
    }

    void ensurePreDrawListener() {
        boolean bl;
        boolean bl2 = false;
        int n = this.getChildCount();
        int n2 = 0;
        while (true) {
            bl = bl2;
            if (n2 >= n) break;
            if (this.hasDependencies(this.getChildAt(n2))) {
                bl = true;
                break;
            }
            ++n2;
        }
        if (bl != this.mNeedsPreDrawListener) {
            if (bl) {
                this.addPreDrawListener();
            } else {
                this.removePreDrawListener();
            }
        }
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(this.getContext(), attributeSet);
    }

    protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            return new LayoutParams((LayoutParams)layoutParams);
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new LayoutParams((ViewGroup.MarginLayoutParams)layoutParams);
        }
        return new LayoutParams(layoutParams);
    }

    void getChildRect(View view, boolean bl, Rect rect) {
        if (!view.isLayoutRequested() && view.getVisibility() != 8) {
            if (bl) {
                this.getDescendantRect(view, rect);
            } else {
                rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
            return;
        }
        rect.setEmpty();
    }

    public List<View> getDependencies(View object) {
        object = this.mChildDag.getOutgoingEdges(object);
        this.mTempDependenciesList.clear();
        if (object != null) {
            this.mTempDependenciesList.addAll((Collection<View>)object);
        }
        return this.mTempDependenciesList;
    }

    final List<View> getDependencySortedChildren() {
        this.prepareChildren();
        return Collections.unmodifiableList(this.mDependencySortedChildren);
    }

    public List<View> getDependents(View object) {
        object = this.mChildDag.getIncomingEdges(object);
        this.mTempDependenciesList.clear();
        if (object != null) {
            this.mTempDependenciesList.addAll((Collection<View>)object);
        }
        return this.mTempDependenciesList;
    }

    void getDescendantRect(View view, Rect rect) {
        ViewGroupUtils.getDescendantRect((ViewGroup)this, (View)view, (Rect)rect);
    }

    void getDesiredAnchoredChildRect(View view, int n, Rect rect, Rect rect2) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        int n2 = view.getMeasuredWidth();
        int n3 = view.getMeasuredHeight();
        this.getDesiredAnchoredChildRectWithoutConstraints(view, n, rect, rect2, layoutParams, n2, n3);
        this.constrainChildRect(layoutParams, rect2, n2, n3);
    }

    void getLastChildRect(View view, Rect rect) {
        rect.set(((LayoutParams)view.getLayoutParams()).getLastChildRect());
    }

    public final WindowInsetsCompat getLastWindowInsets() {
        return this.mLastInsets;
    }

    public int getNestedScrollAxes() {
        return this.mNestedScrollingParentHelper.getNestedScrollAxes();
    }

    LayoutParams getResolvedLayoutParams(View object) {
        LayoutParams layoutParams = (LayoutParams)object.getLayoutParams();
        if (!layoutParams.mBehaviorResolved) {
            if (object instanceof AttachedBehavior) {
                if ((object = ((AttachedBehavior)object).getBehavior()) == null) {
                    Log.e((String)TAG, (String)"Attached behavior class is null");
                }
                layoutParams.setBehavior((Behavior)object);
                layoutParams.mBehaviorResolved = true;
            } else {
                Object object2;
                Class<?> clazz = object.getClass();
                object = null;
                while (true) {
                    object2 = object;
                    if (clazz == null) break;
                    DefaultBehavior defaultBehavior = clazz.getAnnotation(DefaultBehavior.class);
                    object2 = object = defaultBehavior;
                    if (defaultBehavior != null) break;
                    clazz = clazz.getSuperclass();
                }
                if (object2 != null) {
                    try {
                        layoutParams.setBehavior(object2.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
                    }
                    catch (Exception exception) {
                        object = new StringBuilder();
                        ((StringBuilder)object).append("Default behavior class ");
                        ((StringBuilder)object).append(object2.value().getName());
                        ((StringBuilder)object).append(" could not be instantiated. Did you forget");
                        ((StringBuilder)object).append(" a default constructor?");
                        Log.e((String)TAG, (String)((StringBuilder)object).toString(), (Throwable)exception);
                    }
                }
                layoutParams.mBehaviorResolved = true;
            }
        }
        return layoutParams;
    }

    public Drawable getStatusBarBackground() {
        return this.mStatusBarBackground;
    }

    protected int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), this.getPaddingTop() + this.getPaddingBottom());
    }

    protected int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), this.getPaddingLeft() + this.getPaddingRight());
    }

    public boolean isPointInChildBounds(View view, int n, int n2) {
        Rect rect = CoordinatorLayout.acquireTempRect();
        this.getDescendantRect(view, rect);
        try {
            boolean bl = rect.contains(n, n2);
            return bl;
        }
        finally {
            CoordinatorLayout.releaseTempRect(rect);
        }
    }

    void offsetChildToAnchor(View view, int n) {
        block6: {
            Behavior behavior;
            int n2;
            int n3;
            int n4;
            Rect rect;
            Rect rect2;
            Rect rect3;
            LayoutParams layoutParams;
            block8: {
                block7: {
                    layoutParams = (LayoutParams)view.getLayoutParams();
                    if (layoutParams.mAnchorView == null) break block6;
                    rect3 = CoordinatorLayout.acquireTempRect();
                    rect2 = CoordinatorLayout.acquireTempRect();
                    rect = CoordinatorLayout.acquireTempRect();
                    this.getDescendantRect(layoutParams.mAnchorView, rect3);
                    n4 = 0;
                    this.getChildRect(view, false, rect2);
                    n3 = view.getMeasuredWidth();
                    n2 = view.getMeasuredHeight();
                    this.getDesiredAnchoredChildRectWithoutConstraints(view, n, rect3, rect, layoutParams, n3, n2);
                    if (rect.left != rect2.left) break block7;
                    n = n4;
                    if (rect.top == rect2.top) break block8;
                }
                n = 1;
            }
            this.constrainChildRect(layoutParams, rect, n3, n2);
            n3 = rect.left - rect2.left;
            n4 = rect.top - rect2.top;
            if (n3 != 0) {
                ViewCompat.offsetLeftAndRight((View)view, (int)n3);
            }
            if (n4 != 0) {
                ViewCompat.offsetTopAndBottom((View)view, (int)n4);
            }
            if (n != 0 && (behavior = layoutParams.getBehavior()) != null) {
                behavior.onDependentViewChanged(this, view, layoutParams.mAnchorView);
            }
            CoordinatorLayout.releaseTempRect(rect3);
            CoordinatorLayout.releaseTempRect(rect2);
            CoordinatorLayout.releaseTempRect(rect);
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.resetTouchBehaviors(false);
        if (this.mNeedsPreDrawListener) {
            if (this.mOnPreDrawListener == null) {
                this.mOnPreDrawListener = new OnPreDrawListener();
            }
            this.getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.mOnPreDrawListener);
        }
        if (this.mLastInsets == null && ViewCompat.getFitsSystemWindows((View)this)) {
            ViewCompat.requestApplyInsets((View)this);
        }
        this.mIsAttachedToWindow = true;
    }

    final void onChildViewsChanged(int n) {
        int n2 = ViewCompat.getLayoutDirection((View)this);
        int n3 = this.mDependencySortedChildren.size();
        Rect rect = CoordinatorLayout.acquireTempRect();
        Rect rect2 = CoordinatorLayout.acquireTempRect();
        Rect rect3 = CoordinatorLayout.acquireTempRect();
        for (int i = 0; i < n3; ++i) {
            Object object;
            int n4;
            View view = this.mDependencySortedChildren.get(i);
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            if (n == 0 && view.getVisibility() == 8) continue;
            for (n4 = 0; n4 < i; ++n4) {
                object = this.mDependencySortedChildren.get(n4);
                if (layoutParams.mAnchorDirectChild != object) continue;
                this.offsetChildToAnchor(view, n2);
            }
            this.getChildRect(view, true, rect2);
            if (layoutParams.insetEdge != 0 && !rect2.isEmpty()) {
                int n5 = GravityCompat.getAbsoluteGravity((int)layoutParams.insetEdge, (int)n2);
                n4 = n5 & 0x70;
                if (n4 != 48) {
                    if (n4 == 80) {
                        rect.bottom = Math.max(rect.bottom, this.getHeight() - rect2.top);
                    }
                } else {
                    rect.top = Math.max(rect.top, rect2.bottom);
                }
                n4 = n5 & 7;
                if (n4 != 3) {
                    if (n4 == 5) {
                        rect.right = Math.max(rect.right, this.getWidth() - rect2.left);
                    }
                } else {
                    rect.left = Math.max(rect.left, rect2.right);
                }
            }
            if (layoutParams.dodgeInsetEdges != 0 && view.getVisibility() == 0) {
                this.offsetChildByInset(view, rect, n2);
            }
            if (n != 2) {
                this.getLastChildRect(view, rect3);
                if (rect3.equals((Object)rect2)) continue;
                this.recordLastChildRect(view, rect2);
            }
            for (n4 = i + 1; n4 < n3; ++n4) {
                boolean bl;
                View view2 = this.mDependencySortedChildren.get(n4);
                layoutParams = (LayoutParams)view2.getLayoutParams();
                object = layoutParams.getBehavior();
                if (object == null || !((Behavior)object).layoutDependsOn(this, view2, view)) continue;
                if (n == 0 && layoutParams.getChangedAfterNestedScroll()) {
                    layoutParams.resetChangedAfterNestedScroll();
                    continue;
                }
                if (n != 2) {
                    bl = ((Behavior)object).onDependentViewChanged(this, view2, view);
                } else {
                    ((Behavior)object).onDependentViewRemoved(this, view2, view);
                    bl = true;
                }
                if (n != 1) continue;
                layoutParams.setChangedAfterNestedScroll(bl);
            }
        }
        CoordinatorLayout.releaseTempRect(rect);
        CoordinatorLayout.releaseTempRect(rect2);
        CoordinatorLayout.releaseTempRect(rect3);
    }

    public void onDetachedFromWindow() {
        View view;
        super.onDetachedFromWindow();
        this.resetTouchBehaviors(false);
        if (this.mNeedsPreDrawListener && this.mOnPreDrawListener != null) {
            this.getViewTreeObserver().removeOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.mOnPreDrawListener);
        }
        if ((view = this.mNestedScrollingTarget) != null) {
            this.onStopNestedScroll(view);
        }
        this.mIsAttachedToWindow = false;
    }

    public void onDraw(Canvas canvas) {
        WindowInsetsCompat windowInsetsCompat;
        int n;
        super.onDraw(canvas);
        if (this.mDrawStatusBarBackground && this.mStatusBarBackground != null && (n = (windowInsetsCompat = this.mLastInsets) != null ? windowInsetsCompat.getSystemWindowInsetTop() : 0) > 0) {
            this.mStatusBarBackground.setBounds(0, 0, this.getWidth(), n);
            this.mStatusBarBackground.draw(canvas);
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int n = motionEvent.getActionMasked();
        if (n == 0) {
            this.resetTouchBehaviors(true);
        }
        boolean bl = this.performIntercept(motionEvent, 0);
        if (n == 1 || n == 3) {
            this.resetTouchBehaviors(true);
        }
        return bl;
    }

    protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        n2 = ViewCompat.getLayoutDirection((View)this);
        n3 = this.mDependencySortedChildren.size();
        for (n = 0; n < n3; ++n) {
            Behavior behavior;
            View view = this.mDependencySortedChildren.get(n);
            if (view.getVisibility() == 8 || (behavior = ((LayoutParams)view.getLayoutParams()).getBehavior()) != null && behavior.onLayoutChild(this, view, n2)) continue;
            this.onLayoutChild(view, n2);
        }
    }

    public void onLayoutChild(View view, int n) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (!layoutParams.checkAnchorChanged()) {
            if (layoutParams.mAnchorView != null) {
                this.layoutChildWithAnchor(view, layoutParams.mAnchorView, n);
            } else if (layoutParams.keyline >= 0) {
                this.layoutChildWithKeyline(view, layoutParams.keyline, n);
            } else {
                this.layoutChild(view, n);
            }
            return;
        }
        throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
    }

    protected void onMeasure(int n, int n2) {
        this.prepareChildren();
        this.ensurePreDrawListener();
        int n3 = this.getPaddingLeft();
        int n4 = this.getPaddingTop();
        int n5 = this.getPaddingRight();
        int n6 = this.getPaddingBottom();
        int n7 = ViewCompat.getLayoutDirection((View)this);
        boolean bl = true;
        boolean bl2 = n7 == 1;
        int n8 = View.MeasureSpec.getMode((int)n);
        int n9 = View.MeasureSpec.getSize((int)n);
        int n10 = View.MeasureSpec.getMode((int)n2);
        int n11 = View.MeasureSpec.getSize((int)n2);
        int n12 = this.getSuggestedMinimumWidth();
        int n13 = this.getSuggestedMinimumHeight();
        if (this.mLastInsets == null || !ViewCompat.getFitsSystemWindows((View)this)) {
            bl = false;
        }
        int n14 = this.mDependencySortedChildren.size();
        int n15 = 0;
        for (int i = 0; i < n14; ++i) {
            int n16;
            int n17;
            View view = this.mDependencySortedChildren.get(i);
            if (view.getVisibility() == 8) continue;
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            int n18 = 0;
            if (layoutParams.keyline >= 0 && n8 != 0) {
                n17 = this.getKeyline(layoutParams.keyline);
                n16 = GravityCompat.getAbsoluteGravity((int)CoordinatorLayout.resolveKeylineGravity(layoutParams.gravity), (int)n7) & 7;
                if (n16 == 3 && !bl2 || n16 == 5 && bl2) {
                    n18 = Math.max(0, n9 - n5 - n17);
                } else if (n16 == 5 && !bl2 || n16 == 3 && bl2) {
                    n18 = Math.max(0, n17 - n3);
                }
            }
            n16 = n12;
            n17 = n15;
            if (bl && !ViewCompat.getFitsSystemWindows((View)view)) {
                int n19 = this.mLastInsets.getSystemWindowInsetLeft();
                n12 = this.mLastInsets.getSystemWindowInsetRight();
                int n20 = this.mLastInsets.getSystemWindowInsetTop();
                n15 = this.mLastInsets.getSystemWindowInsetBottom();
                n12 = View.MeasureSpec.makeMeasureSpec((int)(n9 - (n19 + n12)), (int)n8);
                n15 = View.MeasureSpec.makeMeasureSpec((int)(n11 - (n20 + n15)), (int)n10);
            } else {
                n12 = n;
                n15 = n2;
            }
            Behavior behavior = layoutParams.getBehavior();
            if (behavior == null || !behavior.onMeasureChild(this, view, n12, n18, n15, 0)) {
                this.onMeasureChild(view, n12, n18, n15, 0);
            }
            n12 = Math.max(n16, n3 + n5 + view.getMeasuredWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
            n13 = Math.max(n13, n4 + n6 + view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
            n15 = View.combineMeasuredStates((int)n17, (int)view.getMeasuredState());
        }
        this.setMeasuredDimension(View.resolveSizeAndState((int)n12, (int)n, (int)(0xFF000000 & n15)), View.resolveSizeAndState((int)n13, (int)n2, (int)(n15 << 16)));
    }

    public void onMeasureChild(View view, int n, int n2, int n3, int n4) {
        this.measureChildWithMargins(view, n, n2, n3, n4);
    }

    public boolean onNestedFling(View view, float f, float f2, boolean bl) {
        int n = this.getChildCount();
        boolean bl2 = false;
        for (int i = 0; i < n; ++i) {
            boolean bl3;
            View view2 = this.getChildAt(i);
            if (view2.getVisibility() == 8) {
                bl3 = bl2;
            } else {
                Object object = (LayoutParams)view2.getLayoutParams();
                if (!object.isNestedScrollAccepted(0)) {
                    bl3 = bl2;
                } else {
                    object = object.getBehavior();
                    bl3 = bl2;
                    if (object != null) {
                        bl3 = ((Behavior)object).onNestedFling(this, view2, view, f, f2, bl) | bl2;
                    }
                }
            }
            bl2 = bl3;
        }
        if (bl2) {
            this.onChildViewsChanged(1);
        }
        return bl2;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        boolean bl = false;
        int n = this.getChildCount();
        for (int i = 0; i < n; ++i) {
            boolean bl2;
            View view2 = this.getChildAt(i);
            if (view2.getVisibility() == 8) {
                bl2 = bl;
            } else {
                Object object = (LayoutParams)view2.getLayoutParams();
                if (!object.isNestedScrollAccepted(0)) {
                    bl2 = bl;
                } else {
                    object = object.getBehavior();
                    bl2 = bl;
                    if (object != null) {
                        bl2 = bl | ((Behavior)object).onNestedPreFling(this, view2, view, f, f2);
                    }
                }
            }
            bl = bl2;
        }
        return bl;
    }

    public void onNestedPreScroll(View view, int n, int n2, int[] nArray) {
        this.onNestedPreScroll(view, n, n2, nArray, 0);
    }

    public void onNestedPreScroll(View view, int n, int n2, int[] nArray, int n3) {
        int n4 = this.getChildCount();
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        for (int i = 0; i < n4; ++i) {
            Object object;
            Object object2 = this.getChildAt(i);
            if (object2.getVisibility() == 8 || !((LayoutParams)((Object)(object = (LayoutParams)object2.getLayoutParams()))).isNestedScrollAccepted(n3) || (object = ((LayoutParams)((Object)object)).getBehavior()) == null) continue;
            int[] nArray2 = this.mTempIntPair;
            nArray2[1] = 0;
            nArray2[0] = 0;
            ((Behavior)object).onNestedPreScroll(this, object2, view, n, n2, nArray2, n3);
            object2 = this.mTempIntPair;
            n7 = n > 0 ? Math.max(n5, (int)object2[0]) : Math.min(n5, (int)object2[0]);
            object2 = this.mTempIntPair;
            n6 = n2 > 0 ? Math.max(n6, (int)object2[1]) : Math.min(n6, (int)object2[1]);
            int n8 = 1;
            n5 = n7;
            n7 = n8;
        }
        nArray[0] = n5;
        nArray[1] = n6;
        if (n7 != 0) {
            this.onChildViewsChanged(1);
        }
    }

    public void onNestedScroll(View view, int n, int n2, int n3, int n4) {
        this.onNestedScroll(view, n, n2, n3, n4, 0);
    }

    public void onNestedScroll(View view, int n, int n2, int n3, int n4, int n5) {
        int n6 = this.getChildCount();
        boolean bl = false;
        for (int i = 0; i < n6; ++i) {
            Object object;
            View view2 = this.getChildAt(i);
            if (view2.getVisibility() == 8 || !((LayoutParams)((Object)(object = (LayoutParams)view2.getLayoutParams()))).isNestedScrollAccepted(n5) || (object = ((LayoutParams)((Object)object)).getBehavior()) == null) continue;
            ((Behavior)object).onNestedScroll(this, view2, view, n, n2, n3, n4, n5);
            bl = true;
        }
        if (bl) {
            this.onChildViewsChanged(1);
        }
    }

    public void onNestedScrollAccepted(View view, View view2, int n) {
        this.onNestedScrollAccepted(view, view2, n, 0);
    }

    public void onNestedScrollAccepted(View view, View view2, int n, int n2) {
        this.mNestedScrollingParentHelper.onNestedScrollAccepted(view, view2, n, n2);
        this.mNestedScrollingTarget = view2;
        int n3 = this.getChildCount();
        for (int i = 0; i < n3; ++i) {
            View view3 = this.getChildAt(i);
            Object object = (LayoutParams)view3.getLayoutParams();
            if (!object.isNestedScrollAccepted(n2) || (object = object.getBehavior()) == null) continue;
            ((Behavior)object).onNestedScrollAccepted(this, view3, view, view2, n, n2);
        }
    }

    protected void onRestoreInstanceState(Parcelable sparseArray) {
        if (!(sparseArray instanceof SavedState)) {
            super.onRestoreInstanceState((Parcelable)sparseArray);
            return;
        }
        sparseArray = (SavedState)sparseArray;
        super.onRestoreInstanceState(sparseArray.getSuperState());
        sparseArray = sparseArray.behaviorStates;
        int n = this.getChildCount();
        for (int i = 0; i < n; ++i) {
            Parcelable parcelable;
            View view = this.getChildAt(i);
            int n2 = view.getId();
            Behavior behavior = this.getResolvedLayoutParams(view).getBehavior();
            if (n2 == -1 || behavior == null || (parcelable = (Parcelable)sparseArray.get(n2)) == null) continue;
            behavior.onRestoreInstanceState(this, view, parcelable);
        }
    }

    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int n = this.getChildCount();
        for (int i = 0; i < n; ++i) {
            View view = this.getChildAt(i);
            int n2 = view.getId();
            Behavior behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
            if (n2 == -1 || behavior == null || (view = behavior.onSaveInstanceState(this, view)) == null) continue;
            sparseArray.append(n2, (Object)view);
        }
        savedState.behaviorStates = sparseArray;
        return savedState;
    }

    public boolean onStartNestedScroll(View view, View view2, int n) {
        return this.onStartNestedScroll(view, view2, n, 0);
    }

    public boolean onStartNestedScroll(View view, View view2, int n, int n2) {
        int n3 = this.getChildCount();
        boolean bl = false;
        for (int i = 0; i < n3; ++i) {
            View view3 = this.getChildAt(i);
            if (view3.getVisibility() == 8) continue;
            LayoutParams layoutParams = (LayoutParams)view3.getLayoutParams();
            Behavior behavior = layoutParams.getBehavior();
            if (behavior != null) {
                boolean bl2 = behavior.onStartNestedScroll(this, view3, view, view2, n, n2);
                layoutParams.setNestedScrollAccepted(n2, bl2);
                bl |= bl2;
                continue;
            }
            layoutParams.setNestedScrollAccepted(n2, false);
        }
        return bl;
    }

    public void onStopNestedScroll(View view) {
        this.onStopNestedScroll(view, 0);
    }

    public void onStopNestedScroll(View view, int n) {
        this.mNestedScrollingParentHelper.onStopNestedScroll(view, n);
        int n2 = this.getChildCount();
        for (int i = 0; i < n2; ++i) {
            View view2 = this.getChildAt(i);
            LayoutParams layoutParams = (LayoutParams)view2.getLayoutParams();
            if (!layoutParams.isNestedScrollAccepted(n)) continue;
            Behavior behavior = layoutParams.getBehavior();
            if (behavior != null) {
                behavior.onStopNestedScroll(this, view2, view, n);
            }
            layoutParams.resetNestedScroll(n);
            layoutParams.resetChangedAfterNestedScroll();
        }
        this.mNestedScrollingTarget = null;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean bl;
        boolean bl2;
        int n;
        Object var5_5;
        Object var4_4;
        boolean bl3;
        block11: {
            boolean bl4;
            block10: {
                boolean bl5;
                bl4 = false;
                bl3 = false;
                var4_4 = null;
                var5_5 = null;
                n = motionEvent.getActionMasked();
                if (this.mBehaviorTouchView != null) break block10;
                bl3 = bl5 = this.performIntercept(motionEvent, 1);
                bl2 = bl4;
                bl = bl3;
                if (!bl5) break block11;
            }
            Behavior behavior = ((LayoutParams)this.mBehaviorTouchView.getLayoutParams()).getBehavior();
            bl2 = bl4;
            bl = bl3;
            if (behavior != null) {
                bl2 = behavior.onTouchEvent(this, this.mBehaviorTouchView, motionEvent);
                bl = bl3;
            }
        }
        if (this.mBehaviorTouchView == null) {
            bl3 = bl2 | super.onTouchEvent(motionEvent);
            motionEvent = var4_4;
        } else {
            bl3 = bl2;
            motionEvent = var4_4;
            if (bl) {
                motionEvent = var5_5;
                if (!false) {
                    long l = SystemClock.uptimeMillis();
                    motionEvent = MotionEvent.obtain((long)l, (long)l, (int)3, (float)0.0f, (float)0.0f, (int)0);
                }
                super.onTouchEvent(motionEvent);
                bl3 = bl2;
            }
        }
        if (motionEvent != null) {
            motionEvent.recycle();
        }
        if (n == 1 || n == 3) {
            this.resetTouchBehaviors(false);
        }
        return bl3;
    }

    void recordLastChildRect(View view, Rect rect) {
        ((LayoutParams)view.getLayoutParams()).setLastChildRect(rect);
    }

    void removePreDrawListener() {
        if (this.mIsAttachedToWindow && this.mOnPreDrawListener != null) {
            this.getViewTreeObserver().removeOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.mOnPreDrawListener);
        }
        this.mNeedsPreDrawListener = false;
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean bl) {
        Behavior behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
        if (behavior != null && behavior.onRequestChildRectangleOnScreen(this, view, rect, bl)) {
            return true;
        }
        return super.requestChildRectangleOnScreen(view, rect, bl);
    }

    public void requestDisallowInterceptTouchEvent(boolean bl) {
        super.requestDisallowInterceptTouchEvent(bl);
        if (bl && !this.mDisallowInterceptReset) {
            this.resetTouchBehaviors(false);
            this.mDisallowInterceptReset = true;
        }
    }

    public void setFitsSystemWindows(boolean bl) {
        super.setFitsSystemWindows(bl);
        this.setupForInsets();
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.mOnHierarchyChangeListener = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable2) {
        Drawable drawable3 = this.mStatusBarBackground;
        if (drawable3 != drawable2) {
            Drawable drawable4 = null;
            if (drawable3 != null) {
                drawable3.setCallback(null);
            }
            if (drawable2 != null) {
                drawable4 = drawable2.mutate();
            }
            this.mStatusBarBackground = drawable4;
            if (drawable4 != null) {
                if (drawable4.isStateful()) {
                    this.mStatusBarBackground.setState(this.getDrawableState());
                }
                DrawableCompat.setLayoutDirection((Drawable)this.mStatusBarBackground, (int)ViewCompat.getLayoutDirection((View)this));
                drawable2 = this.mStatusBarBackground;
                boolean bl = this.getVisibility() == 0;
                drawable2.setVisible(bl, false);
                this.mStatusBarBackground.setCallback((Drawable.Callback)this);
            }
            ViewCompat.postInvalidateOnAnimation((View)this);
        }
    }

    public void setStatusBarBackgroundColor(int n) {
        this.setStatusBarBackground((Drawable)new ColorDrawable(n));
    }

    public void setStatusBarBackgroundResource(int n) {
        Drawable drawable2 = n != 0 ? ContextCompat.getDrawable((Context)this.getContext(), (int)n) : null;
        this.setStatusBarBackground(drawable2);
    }

    public void setVisibility(int n) {
        super.setVisibility(n);
        boolean bl = n == 0;
        Drawable drawable2 = this.mStatusBarBackground;
        if (drawable2 != null && drawable2.isVisible() != bl) {
            this.mStatusBarBackground.setVisible(bl, false);
        }
    }

    final WindowInsetsCompat setWindowInsets(WindowInsetsCompat windowInsetsCompat) {
        WindowInsetsCompat windowInsetsCompat2 = windowInsetsCompat;
        if (!ObjectsCompat.equals((Object)this.mLastInsets, (Object)windowInsetsCompat)) {
            this.mLastInsets = windowInsetsCompat;
            boolean bl = true;
            boolean bl2 = windowInsetsCompat != null && windowInsetsCompat.getSystemWindowInsetTop() > 0;
            this.mDrawStatusBarBackground = bl2;
            bl2 = !bl2 && this.getBackground() == null ? bl : false;
            this.setWillNotDraw(bl2);
            windowInsetsCompat2 = this.dispatchApplyWindowInsetsToBehaviors(windowInsetsCompat);
            this.requestLayout();
        }
        return windowInsetsCompat2;
    }

    protected boolean verifyDrawable(Drawable drawable2) {
        boolean bl = super.verifyDrawable(drawable2) || drawable2 == this.mStatusBarBackground;
        return bl;
    }

    public static interface AttachedBehavior {
        public Behavior getBehavior();
    }

    public static abstract class Behavior<V extends View> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
        }

        public static Object getTag(View view) {
            return ((LayoutParams)view.getLayoutParams()).mBehaviorTag;
        }

        public static void setTag(View view, Object object) {
            ((LayoutParams)view.getLayoutParams()).mBehaviorTag = object;
        }

        public boolean blocksInteractionBelow(CoordinatorLayout coordinatorLayout, V v) {
            boolean bl = this.getScrimOpacity(coordinatorLayout, v) > 0.0f;
            return bl;
        }

        public boolean getInsetDodgeRect(CoordinatorLayout coordinatorLayout, V v, Rect rect) {
            return false;
        }

        public int getScrimColor(CoordinatorLayout coordinatorLayout, V v) {
            return -16777216;
        }

        public float getScrimOpacity(CoordinatorLayout coordinatorLayout, V v) {
            return 0.0f;
        }

        public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        public WindowInsetsCompat onApplyWindowInsets(CoordinatorLayout coordinatorLayout, V v, WindowInsetsCompat windowInsetsCompat) {
            return windowInsetsCompat;
        }

        public void onAttachedToLayoutParams(LayoutParams layoutParams) {
        }

        public boolean onDependentViewChanged(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        public void onDependentViewRemoved(CoordinatorLayout coordinatorLayout, V v, View view) {
        }

        public void onDetachedFromLayoutParams() {
        }

        public boolean onInterceptTouchEvent(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, V v, int n) {
            return false;
        }

        public boolean onMeasureChild(CoordinatorLayout coordinatorLayout, V v, int n, int n2, int n3, int n4) {
            return false;
        }

        public boolean onNestedFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2, boolean bl) {
            return false;
        }

        public boolean onNestedPreFling(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
            return false;
        }

        @Deprecated
        public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V v, View view, int n, int n2, int[] nArray) {
        }

        public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V v, View view, int n, int n2, int[] nArray, int n3) {
            if (n3 == 0) {
                this.onNestedPreScroll(coordinatorLayout, v, view, n, n2, nArray);
            }
        }

        @Deprecated
        public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, int n, int n2, int n3, int n4) {
        }

        public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, int n, int n2, int n3, int n4, int n5) {
            if (n5 == 0) {
                this.onNestedScroll(coordinatorLayout, v, view, n, n2, n3, n4);
            }
        }

        @Deprecated
        public void onNestedScrollAccepted(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int n) {
        }

        public void onNestedScrollAccepted(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int n, int n2) {
            if (n2 == 0) {
                this.onNestedScrollAccepted(coordinatorLayout, v, view, view2, n);
            }
        }

        public boolean onRequestChildRectangleOnScreen(CoordinatorLayout coordinatorLayout, V v, Rect rect, boolean bl) {
            return false;
        }

        public void onRestoreInstanceState(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        }

        public Parcelable onSaveInstanceState(CoordinatorLayout coordinatorLayout, V v) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        @Deprecated
        public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int n) {
            return false;
        }

        public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int n, int n2) {
            if (n2 == 0) {
                return this.onStartNestedScroll(coordinatorLayout, v, view, view2, n);
            }
            return false;
        }

        @Deprecated
        public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view) {
        }

        public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V v, View view, int n) {
            if (n == 0) {
                this.onStopNestedScroll(coordinatorLayout, v, view);
            }
        }

        public boolean onTouchEvent(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }
    }

    @Deprecated
    @Retention(value=RetentionPolicy.RUNTIME)
    public static @interface DefaultBehavior {
        public Class<? extends Behavior> value();
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface DispatchChangeEvent {
    }

    private class HierarchyChangeListener
    implements ViewGroup.OnHierarchyChangeListener {
        HierarchyChangeListener() {
        }

        public void onChildViewAdded(View view, View view2) {
            if (CoordinatorLayout.this.mOnHierarchyChangeListener != null) {
                CoordinatorLayout.this.mOnHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        public void onChildViewRemoved(View view, View view2) {
            CoordinatorLayout.this.onChildViewsChanged(2);
            if (CoordinatorLayout.this.mOnHierarchyChangeListener != null) {
                CoordinatorLayout.this.mOnHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    public static class LayoutParams
    extends ViewGroup.MarginLayoutParams {
        public int anchorGravity = 0;
        public int dodgeInsetEdges = 0;
        public int gravity = 0;
        public int insetEdge = 0;
        public int keyline = -1;
        View mAnchorDirectChild;
        int mAnchorId = -1;
        View mAnchorView;
        Behavior mBehavior;
        boolean mBehaviorResolved = false;
        Object mBehaviorTag;
        private boolean mDidAcceptNestedScrollNonTouch;
        private boolean mDidAcceptNestedScrollTouch;
        private boolean mDidBlockInteraction;
        private boolean mDidChangeAfterNestedScroll;
        int mInsetOffsetX;
        int mInsetOffsetY;
        final Rect mLastChildRect = new Rect();

        public LayoutParams(int n, int n2) {
            super(n, n2);
        }

        LayoutParams(Context object, AttributeSet attributeSet) {
            super((Context)object, attributeSet);
            boolean bl;
            TypedArray typedArray = object.obtainStyledAttributes(attributeSet, R.styleable.CoordinatorLayout_Layout);
            this.gravity = typedArray.getInteger(R.styleable.CoordinatorLayout_Layout_android_layout_gravity, 0);
            this.mAnchorId = typedArray.getResourceId(R.styleable.CoordinatorLayout_Layout_layout_anchor, -1);
            this.anchorGravity = typedArray.getInteger(R.styleable.CoordinatorLayout_Layout_layout_anchorGravity, 0);
            this.keyline = typedArray.getInteger(R.styleable.CoordinatorLayout_Layout_layout_keyline, -1);
            this.insetEdge = typedArray.getInt(R.styleable.CoordinatorLayout_Layout_layout_insetEdge, 0);
            this.dodgeInsetEdges = typedArray.getInt(R.styleable.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
            this.mBehaviorResolved = bl = typedArray.hasValue(R.styleable.CoordinatorLayout_Layout_layout_behavior);
            if (bl) {
                this.mBehavior = CoordinatorLayout.parseBehavior((Context)object, attributeSet, typedArray.getString(R.styleable.CoordinatorLayout_Layout_layout_behavior));
            }
            typedArray.recycle();
            object = this.mBehavior;
            if (object != null) {
                ((Behavior)object).onAttachedToLayoutParams(this);
            }
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((ViewGroup.MarginLayoutParams)layoutParams);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        private void resolveAnchorView(View view, CoordinatorLayout coordinatorLayout) {
            Object object = coordinatorLayout.findViewById(this.mAnchorId);
            this.mAnchorView = object;
            if (object != null) {
                if (object == coordinatorLayout) {
                    if (coordinatorLayout.isInEditMode()) {
                        this.mAnchorDirectChild = null;
                        this.mAnchorView = null;
                        return;
                    }
                    throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
                }
                View view2 = this.mAnchorView;
                for (object = object.getParent(); object != coordinatorLayout && object != null; object = object.getParent()) {
                    if (object == view) {
                        if (coordinatorLayout.isInEditMode()) {
                            this.mAnchorDirectChild = null;
                            this.mAnchorView = null;
                            return;
                        }
                        throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
                    }
                    if (!(object instanceof View)) continue;
                    view2 = (View)object;
                }
                this.mAnchorDirectChild = view2;
                return;
            }
            if (coordinatorLayout.isInEditMode()) {
                this.mAnchorDirectChild = null;
                this.mAnchorView = null;
                return;
            }
            object = new StringBuilder();
            ((StringBuilder)object).append("Could not find CoordinatorLayout descendant view with id ");
            ((StringBuilder)object).append(coordinatorLayout.getResources().getResourceName(this.mAnchorId));
            ((StringBuilder)object).append(" to anchor view ");
            ((StringBuilder)object).append(view);
            throw new IllegalStateException(((StringBuilder)object).toString());
        }

        private boolean shouldDodge(View view, int n) {
            int n2 = GravityCompat.getAbsoluteGravity((int)((LayoutParams)view.getLayoutParams()).insetEdge, (int)n);
            boolean bl = n2 != 0 && (GravityCompat.getAbsoluteGravity((int)this.dodgeInsetEdges, (int)n) & n2) == n2;
            return bl;
        }

        private boolean verifyAnchorView(View view, CoordinatorLayout coordinatorLayout) {
            if (this.mAnchorView.getId() != this.mAnchorId) {
                return false;
            }
            View view2 = this.mAnchorView;
            for (ViewParent viewParent = this.mAnchorView.getParent(); viewParent != coordinatorLayout; viewParent = viewParent.getParent()) {
                if (viewParent != null && viewParent != view) {
                    if (!(viewParent instanceof View)) continue;
                    view2 = (View)viewParent;
                    continue;
                }
                this.mAnchorDirectChild = null;
                this.mAnchorView = null;
                return false;
            }
            this.mAnchorDirectChild = view2;
            return true;
        }

        boolean checkAnchorChanged() {
            boolean bl = this.mAnchorView == null && this.mAnchorId != -1;
            return bl;
        }

        boolean dependsOn(CoordinatorLayout coordinatorLayout, View view, View view2) {
            Behavior behavior;
            boolean bl = view2 == this.mAnchorDirectChild || this.shouldDodge(view2, ViewCompat.getLayoutDirection((View)coordinatorLayout)) || (behavior = this.mBehavior) != null && behavior.layoutDependsOn(coordinatorLayout, view, view2);
            return bl;
        }

        boolean didBlockInteraction() {
            if (this.mBehavior == null) {
                this.mDidBlockInteraction = false;
            }
            return this.mDidBlockInteraction;
        }

        View findAnchorView(CoordinatorLayout coordinatorLayout, View view) {
            if (this.mAnchorId == -1) {
                this.mAnchorDirectChild = null;
                this.mAnchorView = null;
                return null;
            }
            if (this.mAnchorView == null || !this.verifyAnchorView(view, coordinatorLayout)) {
                this.resolveAnchorView(view, coordinatorLayout);
            }
            return this.mAnchorView;
        }

        public int getAnchorId() {
            return this.mAnchorId;
        }

        public Behavior getBehavior() {
            return this.mBehavior;
        }

        boolean getChangedAfterNestedScroll() {
            return this.mDidChangeAfterNestedScroll;
        }

        Rect getLastChildRect() {
            return this.mLastChildRect;
        }

        void invalidateAnchor() {
            this.mAnchorDirectChild = null;
            this.mAnchorView = null;
        }

        boolean isBlockingInteractionBelow(CoordinatorLayout coordinatorLayout, View view) {
            boolean bl = this.mDidBlockInteraction;
            if (bl) {
                return true;
            }
            Behavior behavior = this.mBehavior;
            boolean bl2 = behavior != null ? behavior.blocksInteractionBelow(coordinatorLayout, view) : false;
            this.mDidBlockInteraction = bl2 = bl | bl2;
            return bl2;
        }

        boolean isNestedScrollAccepted(int n) {
            if (n != 0) {
                if (n != 1) {
                    return false;
                }
                return this.mDidAcceptNestedScrollNonTouch;
            }
            return this.mDidAcceptNestedScrollTouch;
        }

        void resetChangedAfterNestedScroll() {
            this.mDidChangeAfterNestedScroll = false;
        }

        void resetNestedScroll(int n) {
            this.setNestedScrollAccepted(n, false);
        }

        void resetTouchBehaviorTracking() {
            this.mDidBlockInteraction = false;
        }

        public void setAnchorId(int n) {
            this.invalidateAnchor();
            this.mAnchorId = n;
        }

        public void setBehavior(Behavior behavior) {
            Behavior behavior2 = this.mBehavior;
            if (behavior2 != behavior) {
                if (behavior2 != null) {
                    behavior2.onDetachedFromLayoutParams();
                }
                this.mBehavior = behavior;
                this.mBehaviorTag = null;
                this.mBehaviorResolved = true;
                if (behavior != null) {
                    behavior.onAttachedToLayoutParams(this);
                }
            }
        }

        void setChangedAfterNestedScroll(boolean bl) {
            this.mDidChangeAfterNestedScroll = bl;
        }

        void setLastChildRect(Rect rect) {
            this.mLastChildRect.set(rect);
        }

        void setNestedScrollAccepted(int n, boolean bl) {
            if (n != 0) {
                if (n == 1) {
                    this.mDidAcceptNestedScrollNonTouch = bl;
                }
            } else {
                this.mDidAcceptNestedScrollTouch = bl;
            }
        }
    }

    class OnPreDrawListener
    implements ViewTreeObserver.OnPreDrawListener {
        OnPreDrawListener() {
        }

        public boolean onPreDraw() {
            CoordinatorLayout.this.onChildViewsChanged(0);
            return true;
        }
    }

    protected static class SavedState
    extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.ClassLoaderCreator<SavedState>(){

            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel, null);
            }

            public SavedState createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            public SavedState[] newArray(int n) {
                return new SavedState[n];
            }
        };
        SparseArray<Parcelable> behaviorStates;

        public SavedState(Parcel parcelableArray, ClassLoader classLoader) {
            super((Parcel)parcelableArray, classLoader);
            int n = parcelableArray.readInt();
            int[] nArray = new int[n];
            parcelableArray.readIntArray(nArray);
            parcelableArray = parcelableArray.readParcelableArray(classLoader);
            this.behaviorStates = new SparseArray(n);
            for (int i = 0; i < n; ++i) {
                this.behaviorStates.append(nArray[i], (Object)parcelableArray[i]);
            }
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int n) {
            super.writeToParcel(parcel, n);
            Parcelable[] parcelableArray = this.behaviorStates;
            int n2 = parcelableArray != null ? parcelableArray.size() : 0;
            parcel.writeInt(n2);
            int[] nArray = new int[n2];
            parcelableArray = new Parcelable[n2];
            for (int i = 0; i < n2; ++i) {
                nArray[i] = this.behaviorStates.keyAt(i);
                parcelableArray[i] = (Parcelable)this.behaviorStates.valueAt(i);
            }
            parcel.writeIntArray(nArray);
            parcel.writeParcelableArray(parcelableArray, n);
        }
    }

    static class ViewElevationComparator
    implements Comparator<View> {
        ViewElevationComparator() {
        }

        @Override
        public int compare(View view, View view2) {
            float f;
            float f2 = ViewCompat.getZ((View)view);
            if (f2 > (f = ViewCompat.getZ((View)view2))) {
                return -1;
            }
            if (f2 < f) {
                return 1;
            }
            return 0;
        }
    }
}

