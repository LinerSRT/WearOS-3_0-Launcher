/*
 * Decompiled with CFR 0.151.
 */
package android.support.v7.recyclerview.extensions;

import android.support.v7.recyclerview.extensions.AsyncDifferConfig;
import android.support.v7.util.AdapterListUpdateCallback;
import android.support.v7.util.DiffUtil;
import android.support.v7.util.ListUpdateCallback;
import android.support.v7.widget.RecyclerView;
import java.util.Collections;
import java.util.List;

public class AsyncListDiffer<T> {
    private final AsyncDifferConfig<T> mConfig;
    private List<T> mList;
    private int mMaxScheduledGeneration;
    private List<T> mReadOnlyList = Collections.emptyList();
    private final ListUpdateCallback mUpdateCallback;

    public AsyncListDiffer(ListUpdateCallback listUpdateCallback, AsyncDifferConfig<T> asyncDifferConfig) {
        this.mUpdateCallback = listUpdateCallback;
        this.mConfig = asyncDifferConfig;
    }

    public AsyncListDiffer(RecyclerView.Adapter adapter, DiffUtil.ItemCallback<T> itemCallback) {
        this.mUpdateCallback = new AdapterListUpdateCallback(adapter);
        this.mConfig = new AsyncDifferConfig.Builder<T>(itemCallback).build();
    }

    private void latchList(List<T> list, DiffUtil.DiffResult diffResult) {
        this.mList = list;
        this.mReadOnlyList = Collections.unmodifiableList(list);
        diffResult.dispatchUpdatesTo(this.mUpdateCallback);
    }

    public List<T> getCurrentList() {
        return this.mReadOnlyList;
    }

    public void submitList(final List<T> list) {
        int n;
        final List<T> list2 = this.mList;
        if (list == list2) {
            return;
        }
        this.mMaxScheduledGeneration = n = this.mMaxScheduledGeneration + 1;
        if (list == null) {
            n = list2.size();
            this.mList = null;
            this.mReadOnlyList = Collections.emptyList();
            this.mUpdateCallback.onRemoved(0, n);
            return;
        }
        if (list2 == null) {
            this.mList = list;
            this.mReadOnlyList = Collections.unmodifiableList(list);
            this.mUpdateCallback.onInserted(0, list.size());
            return;
        }
        list2 = this.mList;
        this.mConfig.getBackgroundThreadExecutor().execute(new Runnable(){

            @Override
            public void run() {
                final DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(new DiffUtil.Callback(){

                    @Override
                    public boolean areContentsTheSame(int n, int n2) {
                        Object e = list2.get(n);
                        Object e2 = list.get(n2);
                        if (e != null && e2 != null) {
                            return AsyncListDiffer.this.mConfig.getDiffCallback().areContentsTheSame(e, e2);
                        }
                        if (e == null && e2 == null) {
                            return true;
                        }
                        throw new AssertionError();
                    }

                    @Override
                    public boolean areItemsTheSame(int n, int n2) {
                        Object e = list2.get(n);
                        Object e2 = list.get(n2);
                        if (e != null && e2 != null) {
                            return AsyncListDiffer.this.mConfig.getDiffCallback().areItemsTheSame(e, e2);
                        }
                        boolean bl = e == null && e2 == null;
                        return bl;
                    }

                    @Override
                    public Object getChangePayload(int n, int n2) {
                        Object e = list2.get(n);
                        Object e2 = list.get(n2);
                        if (e != null && e2 != null) {
                            return AsyncListDiffer.this.mConfig.getDiffCallback().getChangePayload(e, e2);
                        }
                        throw new AssertionError();
                    }

                    @Override
                    public int getNewListSize() {
                        return list.size();
                    }

                    @Override
                    public int getOldListSize() {
                        return list2.size();
                    }
                });
                AsyncListDiffer.this.mConfig.getMainThreadExecutor().execute(new Runnable(){

                    @Override
                    public void run() {
                        if (AsyncListDiffer.this.mMaxScheduledGeneration == n) {
                            AsyncListDiffer.this.latchList(list, diffResult);
                        }
                    }
                });
            }
        });
    }
}

