/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Rect
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.util.SparseIntArray
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 */
package android.support.v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;

public class GridLayoutManager
extends LinearLayoutManager {
    private static final boolean DEBUG = false;
    public static final int DEFAULT_SPAN_COUNT = -1;
    private static final String TAG = "GridLayoutManager";
    int[] mCachedBorders;
    final Rect mDecorInsets;
    boolean mPendingSpanCountChange = false;
    final SparseIntArray mPreLayoutSpanIndexCache;
    final SparseIntArray mPreLayoutSpanSizeCache = new SparseIntArray();
    View[] mSet;
    int mSpanCount = -1;
    SpanSizeLookup mSpanSizeLookup;

    public GridLayoutManager(Context context, int n) {
        super(context);
        this.mPreLayoutSpanIndexCache = new SparseIntArray();
        this.mSpanSizeLookup = new DefaultSpanSizeLookup();
        this.mDecorInsets = new Rect();
        this.setSpanCount(n);
    }

    public GridLayoutManager(Context context, int n, int n2, boolean bl) {
        super(context, n2, bl);
        this.mPreLayoutSpanIndexCache = new SparseIntArray();
        this.mSpanSizeLookup = new DefaultSpanSizeLookup();
        this.mDecorInsets = new Rect();
        this.setSpanCount(n);
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.mPreLayoutSpanIndexCache = new SparseIntArray();
        this.mSpanSizeLookup = new DefaultSpanSizeLookup();
        this.mDecorInsets = new Rect();
        this.setSpanCount(GridLayoutManager.getProperties((Context)context, (AttributeSet)attributeSet, (int)n, (int)n2).spanCount);
    }

    private void assignSpans(RecyclerView.Recycler recycler, RecyclerView.State state, int n, int n2, boolean bl) {
        int n3;
        int n4;
        if (bl) {
            n4 = 0;
            n3 = n;
            n2 = 1;
            n = n4;
        } else {
            --n;
            n3 = -1;
            n2 = -1;
        }
        n4 = 0;
        while (n != n3) {
            View view = this.mSet[n];
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            layoutParams.mSpanSize = this.getSpanSize(recycler, state, this.getPosition(view));
            layoutParams.mSpanIndex = n4;
            n4 += layoutParams.mSpanSize;
            n += n2;
        }
    }

    private void cachePreLayoutSpanMapping() {
        int n = this.getChildCount();
        for (int i = 0; i < n; ++i) {
            LayoutParams layoutParams = (LayoutParams)this.getChildAt(i).getLayoutParams();
            int n2 = layoutParams.getViewLayoutPosition();
            this.mPreLayoutSpanSizeCache.put(n2, layoutParams.getSpanSize());
            this.mPreLayoutSpanIndexCache.put(n2, layoutParams.getSpanIndex());
        }
    }

    private void calculateItemBorders(int n) {
        this.mCachedBorders = GridLayoutManager.calculateItemBorders(this.mCachedBorders, this.mSpanCount, n);
    }

    static int[] calculateItemBorders(int[] nArray, int n, int n2) {
        int[] nArray2;
        block7: {
            block6: {
                if (nArray == null || nArray.length != n + 1) break block6;
                nArray2 = nArray;
                if (nArray[nArray.length - 1] == n2) break block7;
            }
            nArray2 = new int[n + 1];
        }
        nArray2[0] = 0;
        int n3 = n2 / n;
        int n4 = n2 % n;
        int n5 = 0;
        n2 = 0;
        for (int i = 1; i <= n; ++i) {
            int n6;
            int n7 = n3;
            n2 = n6 = n2 + n4;
            int n8 = n7;
            if (n6 > 0) {
                n2 = n6;
                n8 = n7;
                if (n - n6 < n4) {
                    n8 = n7 + 1;
                    n2 = n6 - n;
                }
            }
            nArray2[i] = n5 += n8;
        }
        return nArray2;
    }

    private void clearPreLayoutSpanMappingCache() {
        this.mPreLayoutSpanSizeCache.clear();
        this.mPreLayoutSpanIndexCache.clear();
    }

    private void ensureAnchorIsInCorrectSpan(RecyclerView.Recycler recycler, RecyclerView.State state, LinearLayoutManager.AnchorInfo anchorInfo, int n) {
        int n2 = n == 1 ? 1 : 0;
        n = this.getSpanIndex(recycler, state, anchorInfo.mPosition);
        if (n2 != 0) {
            while (n > 0 && anchorInfo.mPosition > 0) {
                --anchorInfo.mPosition;
                n = this.getSpanIndex(recycler, state, anchorInfo.mPosition);
            }
        } else {
            int n3;
            int n4 = state.getItemCount();
            for (n2 = anchorInfo.mPosition; n2 < n4 - 1 && (n3 = this.getSpanIndex(recycler, state, n2 + 1)) > n; ++n2) {
                n = n3;
            }
            anchorInfo.mPosition = n2;
        }
    }

    private void ensureViewSet() {
        View[] viewArray = this.mSet;
        if (viewArray == null || viewArray.length != this.mSpanCount) {
            this.mSet = new View[this.mSpanCount];
        }
    }

    private int getSpanGroupIndex(RecyclerView.Recycler object, RecyclerView.State state, int n) {
        if (!state.isPreLayout()) {
            return this.mSpanSizeLookup.getSpanGroupIndex(n, this.mSpanCount);
        }
        int n2 = ((RecyclerView.Recycler)object).convertPreLayoutPositionToPostLayout(n);
        if (n2 == -1) {
            object = new StringBuilder();
            ((StringBuilder)object).append("Cannot find span size for pre layout position. ");
            ((StringBuilder)object).append(n);
            Log.w((String)TAG, (String)((StringBuilder)object).toString());
            return 0;
        }
        return this.mSpanSizeLookup.getSpanGroupIndex(n2, this.mSpanCount);
    }

    private int getSpanIndex(RecyclerView.Recycler object, RecyclerView.State state, int n) {
        if (!state.isPreLayout()) {
            return this.mSpanSizeLookup.getCachedSpanIndex(n, this.mSpanCount);
        }
        int n2 = this.mPreLayoutSpanIndexCache.get(n, -1);
        if (n2 != -1) {
            return n2;
        }
        n2 = ((RecyclerView.Recycler)object).convertPreLayoutPositionToPostLayout(n);
        if (n2 == -1) {
            object = new StringBuilder();
            ((StringBuilder)object).append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
            ((StringBuilder)object).append(n);
            Log.w((String)TAG, (String)((StringBuilder)object).toString());
            return 0;
        }
        return this.mSpanSizeLookup.getCachedSpanIndex(n2, this.mSpanCount);
    }

    private int getSpanSize(RecyclerView.Recycler object, RecyclerView.State state, int n) {
        if (!state.isPreLayout()) {
            return this.mSpanSizeLookup.getSpanSize(n);
        }
        int n2 = this.mPreLayoutSpanSizeCache.get(n, -1);
        if (n2 != -1) {
            return n2;
        }
        n2 = ((RecyclerView.Recycler)object).convertPreLayoutPositionToPostLayout(n);
        if (n2 == -1) {
            object = new StringBuilder();
            ((StringBuilder)object).append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
            ((StringBuilder)object).append(n);
            Log.w((String)TAG, (String)((StringBuilder)object).toString());
            return 1;
        }
        return this.mSpanSizeLookup.getSpanSize(n2);
    }

    private void guessMeasurement(float f, int n) {
        this.calculateItemBorders(Math.max(Math.round((float)this.mSpanCount * f), n));
    }

    private void measureChild(View view, int n, boolean bl) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        Rect rect = layoutParams.mDecorInsets;
        int n2 = rect.top + rect.bottom + layoutParams.topMargin + layoutParams.bottomMargin;
        int n3 = rect.left + rect.right + layoutParams.leftMargin + layoutParams.rightMargin;
        int n4 = this.getSpaceForSpanRange(layoutParams.mSpanIndex, layoutParams.mSpanSize);
        if (this.mOrientation == 1) {
            n = GridLayoutManager.getChildMeasureSpec(n4, n, n3, layoutParams.width, false);
            n2 = GridLayoutManager.getChildMeasureSpec(this.mOrientationHelper.getTotalSpace(), this.getHeightMode(), n2, layoutParams.height, true);
        } else {
            n2 = GridLayoutManager.getChildMeasureSpec(n4, n, n2, layoutParams.height, false);
            n = GridLayoutManager.getChildMeasureSpec(this.mOrientationHelper.getTotalSpace(), this.getWidthMode(), n3, layoutParams.width, true);
        }
        this.measureChildWithDecorationsAndMargin(view, n, n2, bl);
    }

    private void measureChildWithDecorationsAndMargin(View view, int n, int n2, boolean bl) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)view.getLayoutParams();
        if (bl = bl ? this.shouldReMeasureChild(view, n, n2, layoutParams) : this.shouldMeasureChild(view, n, n2, layoutParams)) {
            view.measure(n, n2);
        }
    }

    private void updateMeasurements() {
        int n = this.getOrientation() == 1 ? this.getWidth() - this.getPaddingRight() - this.getPaddingLeft() : this.getHeight() - this.getPaddingBottom() - this.getPaddingTop();
        this.calculateItemBorders(n);
    }

    @Override
    public boolean checkLayoutParams(RecyclerView.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override
    void collectPrefetchPositionsForLayoutState(RecyclerView.State state, LinearLayoutManager.LayoutState layoutState, RecyclerView.LayoutManager.LayoutPrefetchRegistry layoutPrefetchRegistry) {
        int n = this.mSpanCount;
        for (int i = 0; i < this.mSpanCount && layoutState.hasMore(state) && n > 0; ++i) {
            int n2 = layoutState.mCurrentPosition;
            layoutPrefetchRegistry.addPosition(n2, Math.max(0, layoutState.mScrollingOffset));
            n -= this.mSpanSizeLookup.getSpanSize(n2);
            layoutState.mCurrentPosition += layoutState.mItemDirection;
        }
    }

    @Override
    View findReferenceChild(RecyclerView.Recycler recycler, RecyclerView.State state, int n, int n2, int n3) {
        this.ensureLayoutState();
        View view = null;
        View view2 = null;
        int n4 = this.mOrientationHelper.getStartAfterPadding();
        int n5 = this.mOrientationHelper.getEndAfterPadding();
        int n6 = n2 > n ? 1 : -1;
        while (n != n2) {
            View view3 = this.getChildAt(n);
            int n7 = this.getPosition(view3);
            View view4 = view;
            View view5 = view2;
            if (n7 >= 0) {
                view4 = view;
                view5 = view2;
                if (n7 < n3) {
                    if (this.getSpanIndex(recycler, state, n7) != 0) {
                        view4 = view;
                        view5 = view2;
                    } else if (((RecyclerView.LayoutParams)view3.getLayoutParams()).isItemRemoved()) {
                        view4 = view;
                        view5 = view2;
                        if (view == null) {
                            view4 = view3;
                            view5 = view2;
                        }
                    } else {
                        if (this.mOrientationHelper.getDecoratedStart(view3) < n5 && this.mOrientationHelper.getDecoratedEnd(view3) >= n4) {
                            return view3;
                        }
                        view4 = view;
                        view5 = view2;
                        if (view2 == null) {
                            view5 = view3;
                            view4 = view;
                        }
                    }
                }
            }
            n += n6;
            view = view4;
            view2 = view5;
        }
        recycler = view2 != null ? view2 : view;
        return recycler;
    }

    @Override
    public RecyclerView.LayoutParams generateDefaultLayoutParams() {
        if (this.mOrientation == 0) {
            return new LayoutParams(-2, -1);
        }
        return new LayoutParams(-1, -2);
    }

    @Override
    public RecyclerView.LayoutParams generateLayoutParams(Context context, AttributeSet attributeSet) {
        return new LayoutParams(context, attributeSet);
    }

    @Override
    public RecyclerView.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new LayoutParams((ViewGroup.MarginLayoutParams)layoutParams);
        }
        return new LayoutParams(layoutParams);
    }

    @Override
    public int getColumnCountForAccessibility(RecyclerView.Recycler recycler, RecyclerView.State state) {
        if (this.mOrientation == 1) {
            return this.mSpanCount;
        }
        if (state.getItemCount() < 1) {
            return 0;
        }
        return this.getSpanGroupIndex(recycler, state, state.getItemCount() - 1) + 1;
    }

    @Override
    public int getRowCountForAccessibility(RecyclerView.Recycler recycler, RecyclerView.State state) {
        if (this.mOrientation == 0) {
            return this.mSpanCount;
        }
        if (state.getItemCount() < 1) {
            return 0;
        }
        return this.getSpanGroupIndex(recycler, state, state.getItemCount() - 1) + 1;
    }

    int getSpaceForSpanRange(int n, int n2) {
        if (this.mOrientation == 1 && this.isLayoutRTL()) {
            int[] nArray = this.mCachedBorders;
            int n3 = this.mSpanCount;
            return nArray[n3 - n] - nArray[n3 - n - n2];
        }
        int[] nArray = this.mCachedBorders;
        return nArray[n + n2] - nArray[n];
    }

    public int getSpanCount() {
        return this.mSpanCount;
    }

    public SpanSizeLookup getSpanSizeLookup() {
        return this.mSpanSizeLookup;
    }

    @Override
    void layoutChunk(RecyclerView.Recycler object, RecyclerView.State object2, LinearLayoutManager.LayoutState layoutState, LinearLayoutManager.LayoutChunkResult layoutChunkResult) {
        int n;
        View view;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        boolean bl;
        int n7;
        int n8;
        int n9;
        block35: {
            n9 = this.mOrientationHelper.getModeInOther();
            n8 = n9 != 0x40000000 ? 1 : 0;
            n7 = this.getChildCount() > 0 ? this.mCachedBorders[this.mSpanCount] : 0;
            if (n8 != 0) {
                this.updateMeasurements();
            }
            bl = layoutState.mItemDirection == 1;
            n6 = this.mSpanCount;
            if (!bl) {
                n6 = this.getSpanIndex((RecyclerView.Recycler)object, (RecyclerView.State)object2, layoutState.mCurrentPosition) + this.getSpanSize((RecyclerView.Recycler)object, (RecyclerView.State)object2, layoutState.mCurrentPosition);
                n5 = 0;
                n4 = 0;
            } else {
                n5 = 0;
                n4 = 0;
            }
            while (true) {
                n3 = n6;
                if (n5 >= this.mSpanCount) break block35;
                n3 = n6;
                if (!layoutState.hasMore((RecyclerView.State)object2)) break block35;
                n3 = n6;
                if (n6 <= 0) break block35;
                n2 = layoutState.mCurrentPosition;
                n3 = this.getSpanSize((RecyclerView.Recycler)object, (RecyclerView.State)object2, n2);
                if (n3 > this.mSpanCount) break;
                if ((n6 -= n3) < 0) {
                    n3 = n6;
                    break block35;
                }
                view = layoutState.next((RecyclerView.Recycler)object);
                if (view == null) {
                    n3 = n6;
                    break block35;
                }
                n4 += n3;
                this.mSet[n5] = view;
                ++n5;
            }
            object = new StringBuilder();
            ((StringBuilder)object).append("Item at position ");
            ((StringBuilder)object).append(n2);
            ((StringBuilder)object).append(" requires ");
            ((StringBuilder)object).append(n3);
            ((StringBuilder)object).append(" spans but GridLayoutManager has only ");
            ((StringBuilder)object).append(this.mSpanCount);
            ((StringBuilder)object).append(" spans.");
            throw new IllegalArgumentException(((StringBuilder)object).toString());
        }
        if (n5 == 0) {
            layoutChunkResult.mFinished = true;
            return;
        }
        this.assignSpans((RecyclerView.Recycler)object, (RecyclerView.State)object2, n5, n4, bl);
        n6 = 0;
        float f = 0.0f;
        for (n2 = 0; n2 < n5; ++n2) {
            object2 = this.mSet[n2];
            if (layoutState.mScrapList == null) {
                if (bl) {
                    this.addView((View)object2);
                } else {
                    this.addView((View)object2, 0);
                }
            } else if (bl) {
                this.addDisappearingView((View)object2);
            } else {
                this.addDisappearingView((View)object2, 0);
            }
            this.calculateItemDecorationsForChild((View)object2, this.mDecorInsets);
            this.measureChild((View)object2, n9, false);
            n = this.mOrientationHelper.getDecoratedMeasurement((View)object2);
            n4 = n6;
            if (n > n6) {
                n4 = n;
            }
            object = (LayoutParams)object2.getLayoutParams();
            float f2 = (float)this.mOrientationHelper.getDecoratedMeasurementInOther((View)object2) * 1.0f / (float)((LayoutParams)object).mSpanSize;
            float f3 = f;
            if (f2 > f) {
                f3 = f2;
            }
            n6 = n4;
            f = f3;
        }
        if (n8 != 0) {
            this.guessMeasurement(f, n7);
            n6 = 0;
            for (n4 = 0; n4 < n5; ++n4) {
                object = this.mSet[n4];
                this.measureChild((View)object, 0x40000000, true);
                n7 = this.mOrientationHelper.getDecoratedMeasurement((View)object);
                n8 = n6;
                if (n7 > n6) {
                    n8 = n7;
                }
                n6 = n8;
            }
            n7 = n6;
        } else {
            n7 = n6;
        }
        n6 = n9;
        for (n4 = 0; n4 < n5; ++n4) {
            view = this.mSet[n4];
            if (this.mOrientationHelper.getDecoratedMeasurement(view) == n7) continue;
            object = (LayoutParams)view.getLayoutParams();
            object2 = ((LayoutParams)object).mDecorInsets;
            n2 = ((Rect)object2).top + ((Rect)object2).bottom + ((LayoutParams)object).topMargin + ((LayoutParams)object).bottomMargin;
            n8 = ((Rect)object2).left + ((Rect)object2).right + ((LayoutParams)object).leftMargin + ((LayoutParams)object).rightMargin;
            n9 = this.getSpaceForSpanRange(((LayoutParams)object).mSpanIndex, ((LayoutParams)object).mSpanSize);
            if (this.mOrientation == 1) {
                n8 = GridLayoutManager.getChildMeasureSpec(n9, 0x40000000, n8, ((LayoutParams)object).width, false);
                n2 = View.MeasureSpec.makeMeasureSpec((int)(n7 - n2), (int)0x40000000);
            } else {
                n8 = View.MeasureSpec.makeMeasureSpec((int)(n7 - n8), (int)0x40000000);
                n2 = GridLayoutManager.getChildMeasureSpec(n9, 0x40000000, n2, ((LayoutParams)object).height, false);
            }
            this.measureChildWithDecorationsAndMargin(view, n8, n2, true);
        }
        layoutChunkResult.mConsumed = n7;
        n4 = 0;
        n8 = 0;
        n3 = 0;
        n6 = 0;
        if (this.mOrientation == 1) {
            if (layoutState.mLayoutDirection == -1) {
                n6 = layoutState.mOffset;
                n3 = n6 - n7;
            } else {
                n3 = layoutState.mOffset;
                n6 = n3 + n7;
            }
        } else if (layoutState.mLayoutDirection == -1) {
            n8 = layoutState.mOffset;
            n4 = n8 - n7;
        } else {
            n4 = layoutState.mOffset;
            n8 = n4 + n7;
        }
        n2 = 0;
        while (n2 < n5) {
            object = this.mSet[n2];
            object2 = (LayoutParams)object.getLayoutParams();
            if (this.mOrientation == 1) {
                if (this.isLayoutRTL()) {
                    n4 = this.getPaddingLeft() + this.mCachedBorders[this.mSpanCount - ((LayoutParams)object2).mSpanIndex];
                    n9 = n4 - this.mOrientationHelper.getDecoratedMeasurementInOther((View)object);
                    n8 = n3;
                    n3 = n6;
                    n6 = n9;
                } else {
                    n8 = this.getPaddingLeft() + this.mCachedBorders[((LayoutParams)object2).mSpanIndex];
                    n9 = this.mOrientationHelper.getDecoratedMeasurementInOther((View)object);
                    n4 = n8;
                    n9 += n8;
                    n8 = n3;
                    n3 = n6;
                    n6 = n4;
                    n4 = n9;
                }
            } else {
                n6 = n4;
                n4 = n8;
                n3 = this.getPaddingTop() + this.mCachedBorders[((LayoutParams)object2).mSpanIndex];
                n9 = this.mOrientationHelper.getDecoratedMeasurementInOther((View)object);
                n8 = n3;
                n3 = n9 + n3;
            }
            this.layoutDecoratedWithMargins((View)object, n6, n8, n4, n3);
            if (((RecyclerView.LayoutParams)((Object)object2)).isItemRemoved() || ((RecyclerView.LayoutParams)((Object)object2)).isItemChanged()) {
                layoutChunkResult.mIgnoreConsumed = true;
            }
            layoutChunkResult.mFocusable |= object.hasFocusable();
            n = n2 + 1;
            n2 = n8;
            n8 = n6;
            n9 = n4;
            n6 = n3;
            n4 = n8;
            n8 = n9;
            n3 = n2;
            n2 = n;
        }
        Arrays.fill(this.mSet, null);
    }

    @Override
    void onAnchorReady(RecyclerView.Recycler recycler, RecyclerView.State state, LinearLayoutManager.AnchorInfo anchorInfo, int n) {
        super.onAnchorReady(recycler, state, anchorInfo, n);
        this.updateMeasurements();
        if (state.getItemCount() > 0 && !state.isPreLayout()) {
            this.ensureAnchorIsInCorrectSpan(recycler, state, anchorInfo, n);
        }
        this.ensureViewSet();
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    public View onFocusSearchFailed(View var1_1, int var2_2, RecyclerView.Recycler var3_3, RecyclerView.State var4_4) {
        block16: {
            var5_5 = this.findContainingItemView(var1_1 /* !! */ );
            if (var5_5 == null) {
                return null;
            }
            var6_6 = (LayoutParams)var5_5.getLayoutParams();
            var7_7 = var6_6.mSpanIndex;
            var8_8 = var6_6.mSpanIndex + var6_6.mSpanSize;
            if (super.onFocusSearchFailed(var1_1 /* !! */ , var2_2, var3_3, var4_4) == null) {
                return null;
            }
            var9_9 = this.convertFocusDirectionToLayoutDirection(var2_2) == 1;
            if ((var2_2 = var9_9 != this.mShouldReverseLayout ? 1 : 0) != 0) {
                var2_2 = this.getChildCount() - 1;
                var10_10 = -1;
                var11_11 = -1;
            } else {
                var2_2 = 0;
                var10_10 = 1;
                var11_11 = this.getChildCount();
            }
            var12_12 = this.mOrientation == 1 && this.isLayoutRTL() != false ? 1 : 0;
            var6_6 = null;
            var1_1 /* !! */  = null;
            var13_13 = this.getSpanGroupIndex(var3_3, var4_4, var2_2);
            var14_14 = -1;
            var15_15 = 0;
            var16_16 = -1;
            var17_17 = 0;
            var19_19 = var2_2;
            for (var18_18 = var2_2; var18_18 != var11_11; var18_18 += var10_10) {
                block12: {
                    block15: {
                        block13: {
                            block14: {
                                block11: {
                                    var2_2 = this.getSpanGroupIndex(var3_3, var4_4, var18_18);
                                    var20_20 = this.getChildAt(var18_18);
                                    if (var20_20 == var5_5) break;
                                    if (var20_20.hasFocusable() && var2_2 != var13_13) {
                                        if (var6_6 == null) continue;
                                        break;
                                    }
                                    var21_21 = (LayoutParams)var20_20.getLayoutParams();
                                    var22_22 = var21_21.mSpanIndex;
                                    var23_23 = var21_21.mSpanIndex + var21_21.mSpanSize;
                                    if (var20_20.hasFocusable() && var22_22 == var7_7 && var23_23 == var8_8) {
                                        return var20_20;
                                    }
                                    if ((!var20_20.hasFocusable() || var6_6 != null) && (var20_20.hasFocusable() || var1_1 /* !! */  != null)) break block11;
                                    var2_2 = 1;
                                    break block12;
                                }
                                var2_2 = Math.max(var22_22, var7_7);
                                var24_24 = Math.min(var23_23, var8_8) - var2_2;
                                if (!var20_20.hasFocusable()) break block13;
                                if (var24_24 <= var15_15) break block14;
                                var2_2 = 1;
                                break block12;
                            }
                            if (var24_24 != var15_15 || var12_12 != (var2_2 = var22_22 > var14_14 ? 1 : 0)) ** GOTO lbl-1000
                            var2_2 = 1;
                            break block12;
                        }
                        if (var6_6 != null) ** GOTO lbl-1000
                        var2_2 = 0;
                        if (!this.isViewPartiallyVisible(var20_20, false, true)) ** GOTO lbl-1000
                        if (var24_24 <= var17_17) break block15;
                        var2_2 = 1;
                        break block12;
                    }
                    if (var24_24 != var17_17) ** GOTO lbl-1000
                    if (var22_22 > var16_16) {
                        var2_2 = 1;
                    }
                    if (var12_12 == var2_2) {
                        var2_2 = 1;
                    } else lbl-1000:
                    // 5 sources

                    {
                        var2_2 = 0;
                    }
                }
                if (var2_2 == 0) continue;
                if (var20_20.hasFocusable()) {
                    var14_14 = var21_21.mSpanIndex;
                    var2_2 = Math.min(var23_23, var8_8);
                    var15_15 = Math.max(var22_22, var7_7);
                    var6_6 = var20_20;
                    var15_15 = var2_2 - var15_15;
                    continue;
                }
                var16_16 = var21_21.mSpanIndex;
                var2_2 = Math.min(var23_23, var8_8);
                var17_17 = Math.max(var22_22, var7_7);
                var1_1 /* !! */  = var20_20;
                var17_17 = var2_2 - var17_17;
            }
            if (var6_6 == null) break block16;
            var1_1 /* !! */  = var6_6;
        }
        return var1_1 /* !! */ ;
    }

    @Override
    public void onInitializeAccessibilityNodeInfoForItem(RecyclerView.Recycler recycler, RecyclerView.State state, View object, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
        ViewGroup.LayoutParams layoutParams = object.getLayoutParams();
        if (!(layoutParams instanceof LayoutParams)) {
            super.onInitializeAccessibilityNodeInfoForItem((View)object, accessibilityNodeInfoCompat);
            return;
        }
        object = (LayoutParams)layoutParams;
        int n = this.getSpanGroupIndex(recycler, state, ((RecyclerView.LayoutParams)((Object)object)).getViewLayoutPosition());
        if (this.mOrientation == 0) {
            int n2 = ((LayoutParams)((Object)object)).getSpanIndex();
            int n3 = ((LayoutParams)((Object)object)).getSpanSize();
            boolean bl = this.mSpanCount > 1 && ((LayoutParams)((Object)object)).getSpanSize() == this.mSpanCount;
            accessibilityNodeInfoCompat.setCollectionItemInfo(AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(n2, n3, n, 1, bl, false));
        } else {
            int n4 = ((LayoutParams)((Object)object)).getSpanIndex();
            int n5 = ((LayoutParams)((Object)object)).getSpanSize();
            boolean bl = this.mSpanCount > 1 && ((LayoutParams)((Object)object)).getSpanSize() == this.mSpanCount;
            accessibilityNodeInfoCompat.setCollectionItemInfo(AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(n, 1, n4, n5, bl, false));
        }
    }

    @Override
    public void onItemsAdded(RecyclerView recyclerView, int n, int n2) {
        this.mSpanSizeLookup.invalidateSpanIndexCache();
    }

    @Override
    public void onItemsChanged(RecyclerView recyclerView) {
        this.mSpanSizeLookup.invalidateSpanIndexCache();
    }

    @Override
    public void onItemsMoved(RecyclerView recyclerView, int n, int n2, int n3) {
        this.mSpanSizeLookup.invalidateSpanIndexCache();
    }

    @Override
    public void onItemsRemoved(RecyclerView recyclerView, int n, int n2) {
        this.mSpanSizeLookup.invalidateSpanIndexCache();
    }

    @Override
    public void onItemsUpdated(RecyclerView recyclerView, int n, int n2, Object object) {
        this.mSpanSizeLookup.invalidateSpanIndexCache();
    }

    @Override
    public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
        if (state.isPreLayout()) {
            this.cachePreLayoutSpanMapping();
        }
        super.onLayoutChildren(recycler, state);
        this.clearPreLayoutSpanMappingCache();
    }

    @Override
    public void onLayoutCompleted(RecyclerView.State state) {
        super.onLayoutCompleted(state);
        this.mPendingSpanCountChange = false;
    }

    @Override
    public int scrollHorizontallyBy(int n, RecyclerView.Recycler recycler, RecyclerView.State state) {
        this.updateMeasurements();
        this.ensureViewSet();
        return super.scrollHorizontallyBy(n, recycler, state);
    }

    @Override
    public int scrollVerticallyBy(int n, RecyclerView.Recycler recycler, RecyclerView.State state) {
        this.updateMeasurements();
        this.ensureViewSet();
        return super.scrollVerticallyBy(n, recycler, state);
    }

    @Override
    public void setMeasuredDimension(Rect object, int n, int n2) {
        if (this.mCachedBorders == null) {
            super.setMeasuredDimension((Rect)object, n, n2);
        }
        int n3 = this.getPaddingLeft() + this.getPaddingRight();
        int n4 = this.getPaddingTop() + this.getPaddingBottom();
        if (this.mOrientation == 1) {
            n2 = GridLayoutManager.chooseSize(n2, object.height() + n4, this.getMinimumHeight());
            object = this.mCachedBorders;
            n = GridLayoutManager.chooseSize(n, (int)(object[((Rect)object).length - 1] + n3), this.getMinimumWidth());
        } else {
            n = GridLayoutManager.chooseSize(n, object.width() + n3, this.getMinimumWidth());
            object = this.mCachedBorders;
            n2 = GridLayoutManager.chooseSize(n2, (int)(object[((Rect)object).length - 1] + n4), this.getMinimumHeight());
        }
        this.setMeasuredDimension(n, n2);
    }

    public void setSpanCount(int n) {
        if (n == this.mSpanCount) {
            return;
        }
        this.mPendingSpanCountChange = true;
        if (n >= 1) {
            this.mSpanCount = n;
            this.mSpanSizeLookup.invalidateSpanIndexCache();
            this.requestLayout();
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Span count should be at least 1. Provided ");
        stringBuilder.append(n);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public void setSpanSizeLookup(SpanSizeLookup spanSizeLookup) {
        this.mSpanSizeLookup = spanSizeLookup;
    }

    @Override
    public void setStackFromEnd(boolean bl) {
        if (!bl) {
            super.setStackFromEnd(false);
            return;
        }
        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }

    @Override
    public boolean supportsPredictiveItemAnimations() {
        boolean bl = this.mPendingSavedState == null && !this.mPendingSpanCountChange;
        return bl;
    }

    public static final class DefaultSpanSizeLookup
    extends SpanSizeLookup {
        @Override
        public int getSpanIndex(int n, int n2) {
            return n % n2;
        }

        @Override
        public int getSpanSize(int n) {
            return 1;
        }
    }

    public static class LayoutParams
    extends RecyclerView.LayoutParams {
        public static final int INVALID_SPAN_ID = -1;
        int mSpanIndex = -1;
        int mSpanSize = 0;

        public LayoutParams(int n, int n2) {
            super(n, n2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(RecyclerView.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public int getSpanIndex() {
            return this.mSpanIndex;
        }

        public int getSpanSize() {
            return this.mSpanSize;
        }
    }

    public static abstract class SpanSizeLookup {
        private boolean mCacheSpanIndices = false;
        final SparseIntArray mSpanIndexCache = new SparseIntArray();

        int findReferenceIndexFromCache(int n) {
            int n2 = 0;
            int n3 = this.mSpanIndexCache.size() - 1;
            while (n2 <= n3) {
                int n4 = n2 + n3 >>> 1;
                if (this.mSpanIndexCache.keyAt(n4) < n) {
                    n2 = n4 + 1;
                    continue;
                }
                n3 = n4 - 1;
            }
            n = n2 - 1;
            if (n >= 0 && n < this.mSpanIndexCache.size()) {
                return this.mSpanIndexCache.keyAt(n);
            }
            return -1;
        }

        int getCachedSpanIndex(int n, int n2) {
            if (!this.mCacheSpanIndices) {
                return this.getSpanIndex(n, n2);
            }
            int n3 = this.mSpanIndexCache.get(n, -1);
            if (n3 != -1) {
                return n3;
            }
            n2 = this.getSpanIndex(n, n2);
            this.mSpanIndexCache.put(n, n2);
            return n2;
        }

        public int getSpanGroupIndex(int n, int n2) {
            int n3 = 0;
            int n4 = 0;
            int n5 = this.getSpanSize(n);
            for (int i = 0; i < n; ++i) {
                int n6;
                int n7 = this.getSpanSize(i);
                int n8 = n3 + n7;
                if (n8 == n2) {
                    n3 = 0;
                    n6 = n4 + 1;
                } else {
                    n3 = n8;
                    n6 = n4;
                    if (n8 > n2) {
                        n3 = n7;
                        n6 = n4 + 1;
                    }
                }
                n4 = n6;
            }
            n = n4;
            if (n3 + n5 > n2) {
                n = n4 + 1;
            }
            return n;
        }

        public int getSpanIndex(int n, int n2) {
            int n3 = this.getSpanSize(n);
            if (n3 == n2) {
                return 0;
            }
            int n4 = 0;
            int n5 = 0;
            int n6 = n4;
            int n7 = n5;
            if (this.mCacheSpanIndices) {
                n6 = n4;
                n7 = n5;
                if (this.mSpanIndexCache.size() > 0) {
                    int n8 = this.findReferenceIndexFromCache(n);
                    n6 = n4;
                    n7 = n5;
                    if (n8 >= 0) {
                        n6 = this.mSpanIndexCache.get(n8) + this.getSpanSize(n8);
                        n7 = n8 + 1;
                    }
                }
            }
            while (n7 < n) {
                n4 = this.getSpanSize(n7);
                n5 = n6 + n4;
                if (n5 == n2) {
                    n6 = 0;
                } else {
                    n6 = n5;
                    if (n5 > n2) {
                        n6 = n4;
                    }
                }
                ++n7;
            }
            if (n6 + n3 <= n2) {
                return n6;
            }
            return 0;
        }

        public abstract int getSpanSize(int var1);

        public void invalidateSpanIndexCache() {
            this.mSpanIndexCache.clear();
        }

        public boolean isSpanIndexCacheEnabled() {
            return this.mCacheSpanIndices;
        }

        public void setSpanIndexCacheEnabled(boolean bl) {
            this.mCacheSpanIndices = bl;
        }
    }
}

