/*
 * Decompiled with CFR 0.151.
 */
package android.support.v7.util;

public interface ListUpdateCallback {
    public void onChanged(int var1, int var2, Object var3);

    public void onInserted(int var1, int var2);

    public void onMoved(int var1, int var2);

    public void onRemoved(int var1, int var2);
}

