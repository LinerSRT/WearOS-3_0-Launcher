/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ClipDescription
 *  android.net.Uri
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.os.ResultReceiver
 *  android.text.TextUtils
 *  android.view.inputmethod.EditorInfo
 *  android.view.inputmethod.InputConnection
 *  android.view.inputmethod.InputConnectionWrapper
 *  android.view.inputmethod.InputContentInfo
 */
package android.support.v13.view.inputmethod;

import android.content.ClipDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v13.view.inputmethod.EditorInfoCompat;
import android.support.v13.view.inputmethod.InputContentInfoCompat;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputContentInfo;

public final class InputConnectionCompat {
    private static final String COMMIT_CONTENT_ACTION = "android.support.v13.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT";
    private static final String COMMIT_CONTENT_CONTENT_URI_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_URI";
    private static final String COMMIT_CONTENT_DESCRIPTION_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
    private static final String COMMIT_CONTENT_FLAGS_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
    private static final String COMMIT_CONTENT_LINK_URI_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
    private static final String COMMIT_CONTENT_OPTS_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
    private static final String COMMIT_CONTENT_RESULT_RECEIVER = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER";
    public static final int INPUT_CONTENT_GRANT_READ_URI_PERMISSION = 1;

    @Deprecated
    public InputConnectionCompat() {
    }

    public static boolean commitContent(InputConnection inputConnection, EditorInfo bundle, InputContentInfoCompat inputContentInfoCompat, int n, Bundle bundle2) {
        boolean bl;
        ClipDescription clipDescription = inputContentInfoCompat.getDescription();
        boolean bl2 = false;
        bundle = EditorInfoCompat.getContentMimeTypes((EditorInfo)bundle);
        int n2 = ((String[])bundle).length;
        int n3 = 0;
        while (true) {
            bl = bl2;
            if (n3 >= n2) break;
            if (clipDescription.hasMimeType(bundle[n3])) {
                bl = true;
                break;
            }
            ++n3;
        }
        if (!bl) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 25) {
            return inputConnection.commitContent((InputContentInfo)inputContentInfoCompat.unwrap(), n, bundle2);
        }
        bundle = new Bundle();
        bundle.putParcelable(COMMIT_CONTENT_CONTENT_URI_KEY, (Parcelable)inputContentInfoCompat.getContentUri());
        bundle.putParcelable(COMMIT_CONTENT_DESCRIPTION_KEY, (Parcelable)inputContentInfoCompat.getDescription());
        bundle.putParcelable(COMMIT_CONTENT_LINK_URI_KEY, (Parcelable)inputContentInfoCompat.getLinkUri());
        bundle.putInt(COMMIT_CONTENT_FLAGS_KEY, n);
        bundle.putParcelable(COMMIT_CONTENT_OPTS_KEY, (Parcelable)bundle2);
        return inputConnection.performPrivateCommand(COMMIT_CONTENT_ACTION, bundle);
    }

    public static InputConnection createWrapper(InputConnection inputConnection, EditorInfo editorInfo, final OnCommitContentListener onCommitContentListener) {
        if (inputConnection != null) {
            if (editorInfo != null) {
                if (onCommitContentListener != null) {
                    if (Build.VERSION.SDK_INT >= 25) {
                        return new InputConnectionWrapper(inputConnection, false){

                            public boolean commitContent(InputContentInfo inputContentInfo, int n, Bundle bundle) {
                                if (onCommitContentListener.onCommitContent(InputContentInfoCompat.wrap(inputContentInfo), n, bundle)) {
                                    return true;
                                }
                                return super.commitContent(inputContentInfo, n, bundle);
                            }
                        };
                    }
                    if (EditorInfoCompat.getContentMimeTypes(editorInfo).length == 0) {
                        return inputConnection;
                    }
                    return new InputConnectionWrapper(inputConnection, false){

                        public boolean performPrivateCommand(String string2, Bundle bundle) {
                            if (InputConnectionCompat.handlePerformPrivateCommand(string2, bundle, onCommitContentListener)) {
                                return true;
                            }
                            return super.performPrivateCommand(string2, bundle);
                        }
                    };
                }
                throw new IllegalArgumentException("onCommitContentListener must be non-null");
            }
            throw new IllegalArgumentException("editorInfo must be non-null");
        }
        throw new IllegalArgumentException("inputConnection must be non-null");
    }

    static boolean handlePerformPrivateCommand(String string2, Bundle object, OnCommitContentListener onCommitContentListener) {
        boolean bl;
        block13: {
            ResultReceiver resultReceiver;
            int n;
            block14: {
                bl = TextUtils.equals((CharSequence)COMMIT_CONTENT_ACTION, (CharSequence)string2);
                n = 0;
                if (!bl) {
                    return false;
                }
                if (object == null) {
                    return false;
                }
                string2 = null;
                try {
                    resultReceiver = (ResultReceiver)object.getParcelable(COMMIT_CONTENT_RESULT_RECEIVER);
                    string2 = resultReceiver;
                }
                catch (Throwable throwable) {
                    if (string2 != null) {
                        string2.send(0, null);
                    }
                    throw throwable;
                }
                Uri uri = (Uri)object.getParcelable(COMMIT_CONTENT_CONTENT_URI_KEY);
                string2 = resultReceiver;
                ClipDescription clipDescription = (ClipDescription)object.getParcelable(COMMIT_CONTENT_DESCRIPTION_KEY);
                string2 = resultReceiver;
                Uri uri2 = (Uri)object.getParcelable(COMMIT_CONTENT_LINK_URI_KEY);
                string2 = resultReceiver;
                int n2 = object.getInt(COMMIT_CONTENT_FLAGS_KEY);
                string2 = resultReceiver;
                Bundle bundle = (Bundle)object.getParcelable(COMMIT_CONTENT_OPTS_KEY);
                string2 = resultReceiver;
                string2 = resultReceiver;
                object = new InputContentInfoCompat(uri, clipDescription, uri2);
                string2 = resultReceiver;
                bl = onCommitContentListener.onCommitContent((InputContentInfoCompat)object, n2, bundle);
                if (resultReceiver == null) break block13;
                if (!bl) break block14;
                n = 1;
            }
            resultReceiver.send(n, null);
        }
        return bl;
    }

    public static interface OnCommitContentListener {
        public boolean onCommitContent(InputContentInfoCompat var1, int var2, Bundle var3);
    }
}

