/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.support.v4.view.MarginLayoutParamsCompat
 *  android.support.v4.view.ViewCompat
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 */
package android.support.percent;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.percent.R;
import android.support.v4.view.MarginLayoutParamsCompat;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

@Deprecated
public class PercentLayoutHelper {
    private static final boolean DEBUG = false;
    private static final String TAG = "PercentLayout";
    private static final boolean VERBOSE = false;
    private final ViewGroup mHost;

    public PercentLayoutHelper(ViewGroup viewGroup) {
        if (viewGroup != null) {
            this.mHost = viewGroup;
            return;
        }
        throw new IllegalArgumentException("host must be non-null");
    }

    public static void fetchWidthAndHeight(ViewGroup.LayoutParams layoutParams, TypedArray typedArray, int n, int n2) {
        layoutParams.width = typedArray.getLayoutDimension(n, 0);
        layoutParams.height = typedArray.getLayoutDimension(n2, 0);
    }

    public static PercentLayoutInfo getPercentLayoutInfo(Context object, AttributeSet attributeSet) {
        Object var2_2 = null;
        TypedArray typedArray = object.obtainStyledAttributes(attributeSet, R.styleable.PercentLayout_Layout);
        float f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_widthPercent, 1, 1, -1.0f);
        attributeSet = var2_2;
        if (f != -1.0f) {
            object = false ? null : new PercentLayoutInfo();
            object.widthPercent = f;
            attributeSet = object;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_heightPercent, 1, 1, -1.0f);
        object = attributeSet;
        if (f != -1.0f) {
            object = attributeSet != null ? attributeSet : new PercentLayoutInfo();
            object.heightPercent = f;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_marginPercent, 1, 1, -1.0f);
        attributeSet = object;
        if (f != -1.0f) {
            if (object == null) {
                object = new PercentLayoutInfo();
            }
            object.leftMarginPercent = f;
            object.topMarginPercent = f;
            object.rightMarginPercent = f;
            object.bottomMarginPercent = f;
            attributeSet = object;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_marginLeftPercent, 1, 1, -1.0f);
        object = attributeSet;
        if (f != -1.0f) {
            object = attributeSet != null ? attributeSet : new PercentLayoutInfo();
            object.leftMarginPercent = f;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_marginTopPercent, 1, 1, -1.0f);
        attributeSet = object;
        if (f != -1.0f) {
            if (object == null) {
                object = new PercentLayoutInfo();
            }
            object.topMarginPercent = f;
            attributeSet = object;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_marginRightPercent, 1, 1, -1.0f);
        object = attributeSet;
        if (f != -1.0f) {
            object = attributeSet != null ? attributeSet : new PercentLayoutInfo();
            object.rightMarginPercent = f;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_marginBottomPercent, 1, 1, -1.0f);
        attributeSet = object;
        if (f != -1.0f) {
            if (object == null) {
                object = new PercentLayoutInfo();
            }
            object.bottomMarginPercent = f;
            attributeSet = object;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_marginStartPercent, 1, 1, -1.0f);
        object = attributeSet;
        if (f != -1.0f) {
            object = attributeSet != null ? attributeSet : new PercentLayoutInfo();
            object.startMarginPercent = f;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_marginEndPercent, 1, 1, -1.0f);
        attributeSet = object;
        if (f != -1.0f) {
            if (object == null) {
                object = new PercentLayoutInfo();
            }
            object.endMarginPercent = f;
            attributeSet = object;
        }
        f = typedArray.getFraction(R.styleable.PercentLayout_Layout_layout_aspectRatio, 1, 1, -1.0f);
        object = attributeSet;
        if (f != -1.0f) {
            object = attributeSet != null ? attributeSet : new PercentLayoutInfo();
            object.aspectRatio = f;
        }
        typedArray.recycle();
        return object;
    }

    private static boolean shouldHandleMeasuredHeightTooSmall(View view, PercentLayoutInfo percentLayoutInfo) {
        boolean bl = (view.getMeasuredHeightAndState() & 0xFF000000) == 0x1000000 && percentLayoutInfo.heightPercent >= 0.0f && percentLayoutInfo.mPreservedParams.height == -2;
        return bl;
    }

    private static boolean shouldHandleMeasuredWidthTooSmall(View view, PercentLayoutInfo percentLayoutInfo) {
        boolean bl = (view.getMeasuredWidthAndState() & 0xFF000000) == 0x1000000 && percentLayoutInfo.widthPercent >= 0.0f && percentLayoutInfo.mPreservedParams.width == -2;
        return bl;
    }

    public void adjustChildren(int n, int n2) {
        int n3 = View.MeasureSpec.getSize((int)n) - this.mHost.getPaddingLeft() - this.mHost.getPaddingRight();
        n2 = View.MeasureSpec.getSize((int)n2) - this.mHost.getPaddingTop() - this.mHost.getPaddingBottom();
        int n4 = this.mHost.getChildCount();
        for (n = 0; n < n4; ++n) {
            PercentLayoutInfo percentLayoutInfo;
            View view = this.mHost.getChildAt(n);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (!(layoutParams instanceof PercentLayoutParams) || (percentLayoutInfo = ((PercentLayoutParams)layoutParams).getPercentLayoutInfo()) == null) continue;
            if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
                percentLayoutInfo.fillMarginLayoutParams(view, (ViewGroup.MarginLayoutParams)layoutParams, n3, n2);
                continue;
            }
            percentLayoutInfo.fillLayoutParams(layoutParams, n3, n2);
        }
    }

    public boolean handleMeasuredStateTooSmall() {
        boolean bl = false;
        int n = this.mHost.getChildCount();
        for (int i = 0; i < n; ++i) {
            View view = this.mHost.getChildAt(i);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            boolean bl2 = bl;
            if (layoutParams instanceof PercentLayoutParams) {
                PercentLayoutInfo percentLayoutInfo = ((PercentLayoutParams)layoutParams).getPercentLayoutInfo();
                bl2 = bl;
                if (percentLayoutInfo != null) {
                    if (PercentLayoutHelper.shouldHandleMeasuredWidthTooSmall(view, percentLayoutInfo)) {
                        bl = true;
                        layoutParams.width = -2;
                    }
                    bl2 = bl;
                    if (PercentLayoutHelper.shouldHandleMeasuredHeightTooSmall(view, percentLayoutInfo)) {
                        bl2 = true;
                        layoutParams.height = -2;
                    }
                }
            }
            bl = bl2;
        }
        return bl;
    }

    public void restoreOriginalParams() {
        int n = this.mHost.getChildCount();
        for (int i = 0; i < n; ++i) {
            PercentLayoutInfo percentLayoutInfo;
            ViewGroup.LayoutParams layoutParams = this.mHost.getChildAt(i).getLayoutParams();
            if (!(layoutParams instanceof PercentLayoutParams) || (percentLayoutInfo = ((PercentLayoutParams)layoutParams).getPercentLayoutInfo()) == null) continue;
            if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
                percentLayoutInfo.restoreMarginLayoutParams((ViewGroup.MarginLayoutParams)layoutParams);
                continue;
            }
            percentLayoutInfo.restoreLayoutParams(layoutParams);
        }
    }

    @Deprecated
    public static class PercentLayoutInfo {
        public float aspectRatio;
        public float bottomMarginPercent = -1.0f;
        public float endMarginPercent = -1.0f;
        public float heightPercent = -1.0f;
        public float leftMarginPercent = -1.0f;
        final PercentMarginLayoutParams mPreservedParams = new PercentMarginLayoutParams(0, 0);
        public float rightMarginPercent = -1.0f;
        public float startMarginPercent = -1.0f;
        public float topMarginPercent = -1.0f;
        public float widthPercent = -1.0f;

        public void fillLayoutParams(ViewGroup.LayoutParams layoutParams, int n, int n2) {
            float f;
            boolean bl;
            boolean bl2;
            block10: {
                boolean bl3;
                block9: {
                    this.mPreservedParams.width = layoutParams.width;
                    this.mPreservedParams.height = layoutParams.height;
                    boolean bl4 = this.mPreservedParams.mIsWidthComputedFromAspectRatio;
                    bl3 = false;
                    bl2 = (bl4 || this.mPreservedParams.width == 0) && this.widthPercent < 0.0f;
                    if (this.mPreservedParams.mIsHeightComputedFromAspectRatio) break block9;
                    bl = bl3;
                    if (this.mPreservedParams.height != 0) break block10;
                }
                bl = bl3;
                if (this.heightPercent < 0.0f) {
                    bl = true;
                }
            }
            if ((f = this.widthPercent) >= 0.0f) {
                layoutParams.width = Math.round((float)n * f);
            }
            if ((f = this.heightPercent) >= 0.0f) {
                layoutParams.height = Math.round((float)n2 * f);
            }
            if (this.aspectRatio >= 0.0f) {
                if (bl2) {
                    layoutParams.width = Math.round((float)layoutParams.height * this.aspectRatio);
                    PercentMarginLayoutParams.access$002(this.mPreservedParams, true);
                }
                if (bl) {
                    layoutParams.height = Math.round((float)layoutParams.width / this.aspectRatio);
                    PercentMarginLayoutParams.access$102(this.mPreservedParams, true);
                }
            }
        }

        public void fillMarginLayoutParams(View view, ViewGroup.MarginLayoutParams marginLayoutParams, int n, int n2) {
            this.fillLayoutParams((ViewGroup.LayoutParams)marginLayoutParams, n, n2);
            this.mPreservedParams.leftMargin = marginLayoutParams.leftMargin;
            this.mPreservedParams.topMargin = marginLayoutParams.topMargin;
            this.mPreservedParams.rightMargin = marginLayoutParams.rightMargin;
            this.mPreservedParams.bottomMargin = marginLayoutParams.bottomMargin;
            MarginLayoutParamsCompat.setMarginStart((ViewGroup.MarginLayoutParams)this.mPreservedParams, (int)MarginLayoutParamsCompat.getMarginStart((ViewGroup.MarginLayoutParams)marginLayoutParams));
            MarginLayoutParamsCompat.setMarginEnd((ViewGroup.MarginLayoutParams)this.mPreservedParams, (int)MarginLayoutParamsCompat.getMarginEnd((ViewGroup.MarginLayoutParams)marginLayoutParams));
            float f = this.leftMarginPercent;
            if (f >= 0.0f) {
                marginLayoutParams.leftMargin = Math.round((float)n * f);
            }
            if ((f = this.topMarginPercent) >= 0.0f) {
                marginLayoutParams.topMargin = Math.round((float)n2 * f);
            }
            if ((f = this.rightMarginPercent) >= 0.0f) {
                marginLayoutParams.rightMargin = Math.round((float)n * f);
            }
            if ((f = this.bottomMarginPercent) >= 0.0f) {
                marginLayoutParams.bottomMargin = Math.round((float)n2 * f);
            }
            n2 = 0;
            f = this.startMarginPercent;
            if (f >= 0.0f) {
                MarginLayoutParamsCompat.setMarginStart((ViewGroup.MarginLayoutParams)marginLayoutParams, (int)Math.round((float)n * f));
                n2 = 1;
            }
            if ((f = this.endMarginPercent) >= 0.0f) {
                MarginLayoutParamsCompat.setMarginEnd((ViewGroup.MarginLayoutParams)marginLayoutParams, (int)Math.round((float)n * f));
                n2 = 1;
            }
            if (n2 != 0 && view != null) {
                MarginLayoutParamsCompat.resolveLayoutDirection((ViewGroup.MarginLayoutParams)marginLayoutParams, (int)ViewCompat.getLayoutDirection((View)view));
            }
        }

        @Deprecated
        public void fillMarginLayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams, int n, int n2) {
            this.fillMarginLayoutParams(null, marginLayoutParams, n, n2);
        }

        public void restoreLayoutParams(ViewGroup.LayoutParams layoutParams) {
            if (!this.mPreservedParams.mIsWidthComputedFromAspectRatio) {
                layoutParams.width = this.mPreservedParams.width;
            }
            if (!this.mPreservedParams.mIsHeightComputedFromAspectRatio) {
                layoutParams.height = this.mPreservedParams.height;
            }
            PercentMarginLayoutParams.access$002(this.mPreservedParams, false);
            PercentMarginLayoutParams.access$102(this.mPreservedParams, false);
        }

        public void restoreMarginLayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            this.restoreLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
            marginLayoutParams.leftMargin = this.mPreservedParams.leftMargin;
            marginLayoutParams.topMargin = this.mPreservedParams.topMargin;
            marginLayoutParams.rightMargin = this.mPreservedParams.rightMargin;
            marginLayoutParams.bottomMargin = this.mPreservedParams.bottomMargin;
            MarginLayoutParamsCompat.setMarginStart((ViewGroup.MarginLayoutParams)marginLayoutParams, (int)MarginLayoutParamsCompat.getMarginStart((ViewGroup.MarginLayoutParams)this.mPreservedParams));
            MarginLayoutParamsCompat.setMarginEnd((ViewGroup.MarginLayoutParams)marginLayoutParams, (int)MarginLayoutParamsCompat.getMarginEnd((ViewGroup.MarginLayoutParams)this.mPreservedParams));
        }

        public String toString() {
            return String.format("PercentLayoutInformation width: %f height %f, margins (%f, %f,  %f, %f, %f, %f)", Float.valueOf(this.widthPercent), Float.valueOf(this.heightPercent), Float.valueOf(this.leftMarginPercent), Float.valueOf(this.topMarginPercent), Float.valueOf(this.rightMarginPercent), Float.valueOf(this.bottomMarginPercent), Float.valueOf(this.startMarginPercent), Float.valueOf(this.endMarginPercent));
        }
    }

    @Deprecated
    public static interface PercentLayoutParams {
        public PercentLayoutInfo getPercentLayoutInfo();
    }

    static class PercentMarginLayoutParams
    extends ViewGroup.MarginLayoutParams {
        private boolean mIsHeightComputedFromAspectRatio;
        private boolean mIsWidthComputedFromAspectRatio;

        public PercentMarginLayoutParams(int n, int n2) {
            super(n, n2);
        }

        static /* synthetic */ boolean access$002(PercentMarginLayoutParams percentMarginLayoutParams, boolean bl) {
            percentMarginLayoutParams.mIsWidthComputedFromAspectRatio = bl;
            return bl;
        }

        static /* synthetic */ boolean access$102(PercentMarginLayoutParams percentMarginLayoutParams, boolean bl) {
            percentMarginLayoutParams.mIsHeightComputedFromAspectRatio = bl;
            return bl;
        }
    }
}

