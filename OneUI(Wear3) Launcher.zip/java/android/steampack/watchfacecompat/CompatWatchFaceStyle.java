/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.support.wearable.watchface.WatchFaceStyle
 */
package android.steampack.watchfacecompat;

import android.support.wearable.watchface.WatchFaceStyle;

public final class CompatWatchFaceStyle
extends WatchFaceStyle {
    @Deprecated
    public static final int AMBIENT_PEEK_MODE_HIDDEN = 1;
    @Deprecated
    public static final int AMBIENT_PEEK_MODE_VISIBLE = 0;
    public static final int BACKGROUND_VISIBILITY_INTERRUPTIVE = 0;
    public static final int BACKGROUND_VISIBILITY_PERSISTENT = 1;
    public static final int DEFAULT_ACCENT_COLOR = -1;
    public static final String KEY_ACCENT_COLOR = "accentColor";
    public static final String KEY_ACCEPTS_TAPS = "acceptsTapEvents";
    public static final String KEY_AMBIENT_PEEK_MODE = "ambientPeekMode";
    public static final String KEY_BACKGROUND_VISIBILITY = "backgroundVisibility";
    public static final String KEY_CARD_PEEK_MODE = "cardPeekMode";
    public static final String KEY_CARD_PROGRESS_MODE = "cardProgressMode";
    public static final String KEY_COMPONENT = "component";
    public static final String KEY_HIDE_HOTWORD_INDICATOR = "showUnreadIndicator";
    public static final String KEY_HIDE_NOTIFICATION_INDICATOR = "hideNotificationIndicator";
    public static final String KEY_HIDE_STATUS_BAR = "hideStatusBar";
    public static final String KEY_HOTWORD_INDICATOR_GRAVITY = "hotwordIndicatorGravity";
    public static final String KEY_PEEK_CARD_OPACITY = "peekOpacityMode";
    public static final String KEY_SHOW_SYSTEM_UI_TIME = "showSystemUiTime";
    public static final String KEY_SHOW_UNREAD_INDICATOR = "showUnreadIndicator";
    public static final String KEY_STATUS_BAR_GRAVITY = "statusBarGravity";
    public static final String KEY_VIEW_PROTECTION_MODE = "viewProtectionMode";
    @Deprecated
    public static final int PEEK_MODE_NONE = 2;
    @Deprecated
    public static final int PEEK_MODE_SHORT = 1;
    @Deprecated
    public static final int PEEK_MODE_VARIABLE = 0;
    @Deprecated
    public static final int PEEK_OPACITY_MODE_OPAQUE = 0;
    @Deprecated
    public static final int PEEK_OPACITY_MODE_TRANSLUCENT = 1;
    @Deprecated
    public static final int PROGRESS_MODE_DISPLAY = 1;
    @Deprecated
    public static final int PROGRESS_MODE_NONE = 0;
    private final int ambientPeekMode;
    private final int backgroundVisibility;
    private final int cardPeekMode;
    private final int cardProgressMode;
    private final boolean hideHotwordIndicator;
    private final boolean hideStatusBar;
    private final int hotwordIndicatorGravity;
    private final int peekOpacityMode;
    private final boolean showSystemUiTime;

    public CompatWatchFaceStyle(WatchFaceStyle watchFaceStyle) {
        super(watchFaceStyle.getComponent(), watchFaceStyle.getViewProtectionMode(), watchFaceStyle.getStatusBarGravity(), watchFaceStyle.getAccentColor(), watchFaceStyle.getShowUnreadCountIndicator(), watchFaceStyle.getHideNotificationIndicator(), watchFaceStyle.getAcceptsTapEvents(), null);
        watchFaceStyle = watchFaceStyle.getCompatBundle();
        if (watchFaceStyle != null) {
            this.ambientPeekMode = watchFaceStyle.getInt(KEY_AMBIENT_PEEK_MODE, 0);
            this.backgroundVisibility = watchFaceStyle.getInt(KEY_BACKGROUND_VISIBILITY, 0);
            this.cardPeekMode = watchFaceStyle.getInt(KEY_CARD_PEEK_MODE, 0);
            this.cardProgressMode = watchFaceStyle.getInt(KEY_CARD_PROGRESS_MODE, 0);
            this.hotwordIndicatorGravity = watchFaceStyle.getInt(KEY_HOTWORD_INDICATOR_GRAVITY);
            this.peekOpacityMode = watchFaceStyle.getInt(KEY_PEEK_CARD_OPACITY, 0);
            this.showSystemUiTime = watchFaceStyle.getBoolean(KEY_SHOW_SYSTEM_UI_TIME);
            this.hideHotwordIndicator = watchFaceStyle.getBoolean("showUnreadIndicator");
            this.hideStatusBar = watchFaceStyle.getBoolean(KEY_HIDE_STATUS_BAR);
        } else {
            this.ambientPeekMode = 0;
            this.backgroundVisibility = 0;
            this.cardPeekMode = 2;
            this.cardProgressMode = 0;
            this.hotwordIndicatorGravity = 0;
            this.peekOpacityMode = 0;
            this.showSystemUiTime = false;
            this.hideHotwordIndicator = false;
            this.hideStatusBar = false;
        }
    }

    @Deprecated
    public int getAmbientPeekMode() {
        return this.ambientPeekMode;
    }

    @Deprecated
    public int getBackgroundVisibility() {
        return this.backgroundVisibility;
    }

    @Deprecated
    public int getCardPeekMode() {
        return this.cardPeekMode;
    }

    @Deprecated
    public int getCardProgressMode() {
        return this.cardProgressMode;
    }

    @Deprecated
    public boolean getHideHotwordIndicator() {
        return this.hideHotwordIndicator;
    }

    public boolean getHideStatusBar() {
        return this.hideStatusBar;
    }

    @Deprecated
    public int getHotwordIndicatorGravity() {
        return this.hotwordIndicatorGravity;
    }

    @Deprecated
    public int getPeekOpacityMode() {
        return this.peekOpacityMode;
    }

    public boolean getShowSystemUiTime() {
        return this.showSystemUiTime;
    }
}

