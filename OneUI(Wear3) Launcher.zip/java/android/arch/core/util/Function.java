/*
 * Decompiled with CFR 0.151.
 */
package android.arch.core.util;

public interface Function<I, O> {
    public O apply(I var1);
}

