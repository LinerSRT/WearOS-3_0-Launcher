/*
 * Decompiled with CFR 0.151.
 */
package android.arch.lifecycle;

import android.arch.lifecycle.Lifecycle;

public interface LifecycleOwner {
    public Lifecycle getLifecycle();
}

