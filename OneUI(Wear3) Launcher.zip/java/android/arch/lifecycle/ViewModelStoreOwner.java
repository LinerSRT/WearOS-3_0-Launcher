/*
 * Decompiled with CFR 0.151.
 */
package android.arch.lifecycle;

import android.arch.lifecycle.ViewModelStore;

public interface ViewModelStoreOwner {
    public ViewModelStore getViewModelStore();
}

