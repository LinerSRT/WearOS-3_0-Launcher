/*
 * Decompiled with CFR 0.151.
 */
package android.arch.lifecycle;

import android.arch.lifecycle.Lifecycle;
import android.arch.lifecycle.LifecycleOwner;
import android.arch.lifecycle.MethodCallsLogger;

public interface GeneratedAdapter {
    public void callMethods(LifecycleOwner var1, Lifecycle.Event var2, boolean var3, MethodCallsLogger var4);
}

