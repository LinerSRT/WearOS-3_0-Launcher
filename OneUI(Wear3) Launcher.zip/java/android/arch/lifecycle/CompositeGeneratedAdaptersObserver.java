/*
 * Decompiled with CFR 0.151.
 */
package android.arch.lifecycle;

import android.arch.lifecycle.GeneratedAdapter;
import android.arch.lifecycle.GenericLifecycleObserver;
import android.arch.lifecycle.Lifecycle;
import android.arch.lifecycle.LifecycleOwner;
import android.arch.lifecycle.MethodCallsLogger;

public class CompositeGeneratedAdaptersObserver
implements GenericLifecycleObserver {
    private final GeneratedAdapter[] mGeneratedAdapters;

    CompositeGeneratedAdaptersObserver(GeneratedAdapter[] generatedAdapterArray) {
        this.mGeneratedAdapters = generatedAdapterArray;
    }

    @Override
    public void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
        int n;
        MethodCallsLogger methodCallsLogger = new MethodCallsLogger();
        GeneratedAdapter[] generatedAdapterArray = this.mGeneratedAdapters;
        int n2 = generatedAdapterArray.length;
        int n3 = 0;
        for (n = 0; n < n2; ++n) {
            generatedAdapterArray[n].callMethods(lifecycleOwner, event, false, methodCallsLogger);
        }
        generatedAdapterArray = this.mGeneratedAdapters;
        n2 = generatedAdapterArray.length;
        for (n = n3; n < n2; ++n) {
            generatedAdapterArray[n].callMethods(lifecycleOwner, event, true, methodCallsLogger);
        }
    }
}

