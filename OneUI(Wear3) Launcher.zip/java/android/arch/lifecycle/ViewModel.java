/*
 * Decompiled with CFR 0.151.
 */
package android.arch.lifecycle;

public abstract class ViewModel {
    protected void onCleared() {
    }
}

