/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Application
 */
package android.arch.lifecycle;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelStore;
import android.arch.lifecycle.ViewModelStoreOwner;
import java.lang.reflect.InvocationTargetException;

public class ViewModelProvider {
    private static final String DEFAULT_KEY = "android.arch.lifecycle.ViewModelProvider.DefaultKey";
    private final Factory mFactory;
    private final ViewModelStore mViewModelStore;

    public ViewModelProvider(ViewModelStore viewModelStore, Factory factory) {
        this.mFactory = factory;
        this.mViewModelStore = viewModelStore;
    }

    public ViewModelProvider(ViewModelStoreOwner viewModelStoreOwner, Factory factory) {
        this(viewModelStoreOwner.getViewModelStore(), factory);
    }

    public <T extends ViewModel> T get(Class<T> clazz) {
        String string2 = clazz.getCanonicalName();
        if (string2 != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("android.arch.lifecycle.ViewModelProvider.DefaultKey:");
            stringBuilder.append(string2);
            return this.get(stringBuilder.toString(), clazz);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    public <T extends ViewModel> T get(String string2, Class<T> clazz) {
        ViewModel viewModel = this.mViewModelStore.get(string2);
        if (clazz.isInstance(viewModel)) {
            return (T)viewModel;
        }
        clazz = this.mFactory.create(clazz);
        this.mViewModelStore.put(string2, (ViewModel)((Object)clazz));
        return (T)clazz;
    }

    public static class AndroidViewModelFactory
    extends NewInstanceFactory {
        private static AndroidViewModelFactory sInstance;
        private Application mApplication;

        public AndroidViewModelFactory(Application application) {
            this.mApplication = application;
        }

        public static AndroidViewModelFactory getInstance(Application application) {
            if (sInstance == null) {
                sInstance = new AndroidViewModelFactory(application);
            }
            return sInstance;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> clazz) {
            if (AndroidViewModel.class.isAssignableFrom(clazz)) {
                ViewModel viewModel;
                try {
                    viewModel = (ViewModel)clazz.getConstructor(Application.class).newInstance(this.mApplication);
                }
                catch (InvocationTargetException invocationTargetException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Cannot create an instance of ");
                    stringBuilder.append(clazz);
                    throw new RuntimeException(stringBuilder.toString(), invocationTargetException);
                }
                catch (InstantiationException instantiationException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Cannot create an instance of ");
                    stringBuilder.append(clazz);
                    throw new RuntimeException(stringBuilder.toString(), instantiationException);
                }
                catch (IllegalAccessException illegalAccessException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Cannot create an instance of ");
                    stringBuilder.append(clazz);
                    throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Cannot create an instance of ");
                    stringBuilder.append(clazz);
                    throw new RuntimeException(stringBuilder.toString(), noSuchMethodException);
                }
                return (T)viewModel;
            }
            return super.create(clazz);
        }
    }

    public static interface Factory {
        public <T extends ViewModel> T create(Class<T> var1);
    }

    public static class NewInstanceFactory
    implements Factory {
        @Override
        public <T extends ViewModel> T create(Class<T> clazz) {
            ViewModel viewModel;
            try {
                viewModel = (ViewModel)clazz.newInstance();
            }
            catch (IllegalAccessException illegalAccessException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot create an instance of ");
                stringBuilder.append(clazz);
                throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
            }
            catch (InstantiationException instantiationException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot create an instance of ");
                stringBuilder.append(clazz);
                throw new RuntimeException(stringBuilder.toString(), instantiationException);
            }
            return (T)viewModel;
        }
    }
}

