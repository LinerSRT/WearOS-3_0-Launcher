/*
 * Decompiled with CFR 0.151.
 */
package android.arch.lifecycle;

import android.arch.lifecycle.FullLifecycleObserver;
import android.arch.lifecycle.GenericLifecycleObserver;
import android.arch.lifecycle.Lifecycle;
import android.arch.lifecycle.LifecycleOwner;

class FullLifecycleObserverAdapter
implements GenericLifecycleObserver {
    private final FullLifecycleObserver mObserver;

    FullLifecycleObserverAdapter(FullLifecycleObserver fullLifecycleObserver) {
        this.mObserver = fullLifecycleObserver;
    }

    @Override
    public void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
        switch (1.$SwitchMap$androidx$lifecycle$Lifecycle$Event[event.ordinal()]) {
            default: {
                break;
            }
            case 7: {
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
            }
            case 6: {
                this.mObserver.onDestroy(lifecycleOwner);
                break;
            }
            case 5: {
                this.mObserver.onStop(lifecycleOwner);
                break;
            }
            case 4: {
                this.mObserver.onPause(lifecycleOwner);
                break;
            }
            case 3: {
                this.mObserver.onResume(lifecycleOwner);
                break;
            }
            case 2: {
                this.mObserver.onStart(lifecycleOwner);
                break;
            }
            case 1: {
                this.mObserver.onCreate(lifecycleOwner);
            }
        }
    }
}

