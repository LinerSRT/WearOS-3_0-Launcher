/*
 * Decompiled with CFR 0.151.
 */
package android.arch.lifecycle;

import android.arch.lifecycle.ClassesInfoCache;
import android.arch.lifecycle.CompositeGeneratedAdaptersObserver;
import android.arch.lifecycle.FullLifecycleObserver;
import android.arch.lifecycle.FullLifecycleObserverAdapter;
import android.arch.lifecycle.GeneratedAdapter;
import android.arch.lifecycle.GenericLifecycleObserver;
import android.arch.lifecycle.LifecycleObserver;
import android.arch.lifecycle.ReflectiveGenericLifecycleObserver;
import android.arch.lifecycle.SingleGeneratedAdapterObserver;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Lifecycling {
    private static final int GENERATED_CALLBACK = 2;
    private static final int REFLECTIVE_CALLBACK = 1;
    private static Map<Class, Integer> sCallbackCache = new HashMap<Class, Integer>();
    private static Map<Class, List<Constructor<? extends GeneratedAdapter>>> sClassToAdapters = new HashMap<Class, List<Constructor<? extends GeneratedAdapter>>>();

    private Lifecycling() {
    }

    private static GeneratedAdapter createGeneratedAdapter(Constructor<? extends GeneratedAdapter> object, Object object2) {
        try {
            object = ((Constructor)object).newInstance(object2);
            return object;
        }
        catch (InvocationTargetException invocationTargetException) {
            throw new RuntimeException(invocationTargetException);
        }
        catch (InstantiationException instantiationException) {
            throw new RuntimeException(instantiationException);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new RuntimeException(illegalAccessException);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Constructor<? extends GeneratedAdapter> generatedConstructor(Class<?> genericDeclaration) {
        try {
            Object object = ((Class)genericDeclaration).getPackage();
            String string2 = ((Class)genericDeclaration).getCanonicalName();
            object = object != null ? ((Package)object).getName() : "";
            if (!((String)object).isEmpty()) {
                string2 = string2.substring(((String)object).length() + 1);
            }
            string2 = Lifecycling.getAdapterName(string2);
            if (((String)object).isEmpty()) {
                object = string2;
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append((String)object);
                stringBuilder.append(".");
                stringBuilder.append(string2);
                object = stringBuilder.toString();
            }
            genericDeclaration = Class.forName((String)object).getDeclaredConstructor(new Class[]{genericDeclaration});
            if (!((AccessibleObject)((Object)genericDeclaration)).isAccessible()) {
                ((Constructor)genericDeclaration).setAccessible(true);
            }
            return genericDeclaration;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new RuntimeException(noSuchMethodException);
        }
        catch (ClassNotFoundException classNotFoundException) {
            return null;
        }
    }

    public static String getAdapterName(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2.replace(".", "_"));
        stringBuilder.append("_LifecycleAdapter");
        return stringBuilder.toString();
    }

    static GenericLifecycleObserver getCallback(Object object) {
        if (object instanceof FullLifecycleObserver) {
            return new FullLifecycleObserverAdapter((FullLifecycleObserver)object);
        }
        if (object instanceof GenericLifecycleObserver) {
            return (GenericLifecycleObserver)object;
        }
        GeneratedAdapter[] generatedAdapterArray = object.getClass();
        if (Lifecycling.getObserverConstructorType(generatedAdapterArray) == 2) {
            List<Constructor<? extends GeneratedAdapter>> list = sClassToAdapters.get(generatedAdapterArray);
            if (list.size() == 1) {
                return new SingleGeneratedAdapterObserver(Lifecycling.createGeneratedAdapter(list.get(0), object));
            }
            generatedAdapterArray = new GeneratedAdapter[list.size()];
            for (int i = 0; i < list.size(); ++i) {
                generatedAdapterArray[i] = Lifecycling.createGeneratedAdapter(list.get(i), object);
            }
            return new CompositeGeneratedAdaptersObserver(generatedAdapterArray);
        }
        return new ReflectiveGenericLifecycleObserver(object);
    }

    private static int getObserverConstructorType(Class<?> clazz) {
        if (sCallbackCache.containsKey(clazz)) {
            return sCallbackCache.get(clazz);
        }
        int n = Lifecycling.resolveObserverCallbackType(clazz);
        sCallbackCache.put(clazz, n);
        return n;
    }

    private static boolean isLifecycleParent(Class<?> clazz) {
        boolean bl = clazz != null && LifecycleObserver.class.isAssignableFrom(clazz);
        return bl;
    }

    private static int resolveObserverCallbackType(Class<?> clazz) {
        if (clazz.getCanonicalName() == null) {
            return 1;
        }
        Object object = Lifecycling.generatedConstructor(clazz);
        if (object != null) {
            sClassToAdapters.put(clazz, Collections.singletonList(object));
            return 2;
        }
        if (ClassesInfoCache.sInstance.hasLifecycleMethods(clazz)) {
            return 1;
        }
        ArrayList arrayList = clazz.getSuperclass();
        object = null;
        if (Lifecycling.isLifecycleParent(arrayList)) {
            if (Lifecycling.getObserverConstructorType(arrayList) == 1) {
                return 1;
            }
            object = new ArrayList(sClassToAdapters.get(arrayList));
        }
        for (Class<?> clazz2 : clazz.getInterfaces()) {
            if (!Lifecycling.isLifecycleParent(clazz2)) continue;
            if (Lifecycling.getObserverConstructorType(clazz2) == 1) {
                return 1;
            }
            arrayList = object;
            if (object == null) {
                arrayList = new ArrayList();
            }
            arrayList.addAll(sClassToAdapters.get(clazz2));
            object = arrayList;
        }
        if (object != null) {
            sClassToAdapters.put(clazz, (List<Constructor<? extends GeneratedAdapter>>)object);
            return 2;
        }
        return 1;
    }
}

