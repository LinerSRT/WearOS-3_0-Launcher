package androidx.customview.widget;

import android.content.Context;
import android.support.p000v4.view.ViewCompat;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import java.util.Arrays;

/* compiled from: PG */
public final class ViewDragHelper {
    private static final Interpolator sInterpolator = new PG();
    private int mActivePointerId = -1;
    private final Callback mCallback;
    private View mCapturedView;
    private int mDragState;
    private int[] mEdgeDragsInProgress;
    private int[] mEdgeDragsLocked;
    private int mEdgeSize;
    private int[] mInitialEdgesTouched;
    private float[] mInitialMotionX;
    private float[] mInitialMotionY;
    private float[] mLastMotionX;
    private float[] mLastMotionY;
    private final float mMaxVelocity;
    private float mMinVelocity;
    private final ViewGroup mParentView;
    private int mPointersDown;
    private boolean mReleaseInProgress;
    private final OverScroller mScroller;
    private final Runnable mSetIdleRunnable = new C01442();
    private int mTouchSlop;
    public int mTrackingEdges;
    private VelocityTracker mVelocityTracker;

    /* renamed from: androidx.customview.widget.ViewDragHelper$1 */
    final class PG implements Interpolator {
        public final float getInterpolation(float f) {
            f -= 4.0f;
            return ((((f * f) * f) * f) * f) + 1.0f;
        }
    }

    /* renamed from: androidx.customview.widget.ViewDragHelper$2 */
    final class C01442 implements Runnable {
        public final void run() {
            ViewDragHelper.this.setDragState(0);
        }
    }

    /* compiled from: PG */
    public abstract class Callback {
        public int clampViewPositionVertical$ar$ds(View view, int i) {
            throw null;
        }

        public int getViewVerticalDragRange(View view) {
            throw null;
        }

        public void onEdgeDragStarted(int i, int i2) {
            throw null;
        }

        public void onViewCaptured$ar$ds(View view) {
            throw null;
        }

        public void onViewDragStateChanged(int i) {
            throw null;
        }

        public void onViewPositionChanged$ar$ds(View view, int i) {
            throw null;
        }

        public void onViewReleased$ar$ds(View view, float f) {
            throw null;
        }

        public abstract boolean tryCaptureView$ar$ds(View view);
    }

    private ViewDragHelper(Context context, ViewGroup viewGroup, Callback callback) {
        if (callback != null) {
            this.mParentView = viewGroup;
            this.mCallback = callback;
            ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
            this.mEdgeSize = (int) ((context.getResources().getDisplayMetrics().density * 20.0f) + 0.5f);
            this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
            this.mMaxVelocity = (float) viewConfiguration.getScaledMaximumFlingVelocity();
            this.mMinVelocity = (float) viewConfiguration.getScaledMinimumFlingVelocity();
            this.mScroller = new OverScroller(context, sInterpolator);
            return;
        }
        throw new NullPointerException("Callback may not be null");
    }

    private final boolean checkNewEdgeDrag(float f, float f2, int i, int i2) {
        f = Math.abs(f);
        f2 = Math.abs(f2);
        if (!((this.mInitialEdgesTouched[i] & i2) != i2 || (this.mTrackingEdges & i2) == 0 || (this.mEdgeDragsLocked[i] & i2) == i2)) {
            i = this.mEdgeDragsInProgress[i] & i2;
            if (i != i2) {
                float f3 = (float) this.mTouchSlop;
                if ((f > f3 || f2 > f3) && i == 0 && f > f3) {
                    return true;
                }
            }
        }
        return false;
    }

    private final boolean checkTouchSlop$ar$ds(View view, float f) {
        if (view != null && this.mCallback.getViewVerticalDragRange(view) > 0 && Math.abs(f) > ((float) this.mTouchSlop)) {
            return true;
        }
        return false;
    }

    private static final float clampMag$ar$ds(float f, float f2, float f3) {
        float abs = Math.abs(f);
        if (abs < f2) {
            return 0.0f;
        }
        if (abs > f3) {
            if (f > 0.0f) {
                return f3;
            }
            f = -f3;
        }
        return f;
    }

    private static final int clampMag$ar$ds$e9f0509f_0(int i, int i2, int i3) {
        int abs = Math.abs(i);
        if (abs < i2) {
            return 0;
        }
        if (abs > i3) {
            if (i > 0) {
                return i3;
            }
            i = -i3;
        }
        return i;
    }

    private final void clearMotionHistory(int i) {
        if (this.mInitialMotionX != null) {
            if (isPointerDown(i)) {
                this.mInitialMotionX[i] = 0.0f;
                this.mInitialMotionY[i] = 0.0f;
                this.mLastMotionX[i] = 0.0f;
                this.mLastMotionY[i] = 0.0f;
                this.mInitialEdgesTouched[i] = 0;
                this.mEdgeDragsInProgress[i] = 0;
                this.mEdgeDragsLocked[i] = 0;
                this.mPointersDown = ((1 << i) ^ -1) & this.mPointersDown;
            }
        }
    }

    private final int computeAxisDuration(int i, int i2, int i3) {
        if (i == 0) {
            return 0;
        }
        int width = this.mParentView.getWidth();
        float f = (float) (width / 2);
        f += ((float) Math.sin((double) ((Math.min(1.0f, ((float) Math.abs(i)) / ((float) width)) - 8.0f) * 0.47123894f))) * f;
        i2 = Math.abs(i2);
        if (i2 > 0) {
            i = Math.round(Math.abs(f / ((float) i2)) * 1000.0f) * 4;
        } else {
            i = (int) (((((float) Math.abs(i)) / ((float) i3)) + 1.0f) * 256.0f);
        }
        return Math.min(i, 600);
    }

    private final void dispatchViewReleased$ar$ds(float f) {
        this.mReleaseInProgress = true;
        this.mCallback.onViewReleased$ar$ds(this.mCapturedView, f);
        this.mReleaseInProgress = false;
        if (this.mDragState == 1) {
            setDragState(0);
        }
    }

    private final boolean forceSettleCapturedViewAt$ar$ds(int i, int i2, int i3) {
        int i4;
        float f;
        float f2;
        int left = this.mCapturedView.getLeft();
        int top = this.mCapturedView.getTop();
        int i5 = -left;
        int i6 = i - top;
        if (i5 != 0) {
            i4 = i5;
        } else if (i6 != 0) {
            i4 = 0;
        } else {
            this.mScroller.abortAnimation();
            setDragState(0);
            return false;
        }
        View view = this.mCapturedView;
        i2 = clampMag$ar$ds$e9f0509f_0(i2, (int) this.mMinVelocity, (int) this.mMaxVelocity);
        i3 = clampMag$ar$ds$e9f0509f_0(i3, (int) this.mMinVelocity, (int) this.mMaxVelocity);
        int abs = Math.abs(i4);
        int abs2 = Math.abs(i6);
        int abs3 = Math.abs(i2);
        int abs4 = Math.abs(i3);
        int i7 = abs3 + abs4;
        int i8 = abs + abs2;
        if (i2 != 0) {
            f = ((float) abs3) / ((float) i7);
        } else {
            f = ((float) abs) / ((float) i8);
        }
        if (i3 != 0) {
            f2 = ((float) abs4) / ((float) i7);
        } else {
            f2 = ((float) abs2) / ((float) i8);
        }
        i = computeAxisDuration(i4, i2, 0);
        i2 = computeAxisDuration(i6, i3, this.mCallback.getViewVerticalDragRange(view));
        this.mScroller.startScroll(left, top, i4, i6, (int) ((((float) i) * f) + (((float) i2) * f2)));
        setDragState(2);
        return true;
    }

    private final boolean isValidPointerForActionMove(int i) {
        return isPointerDown(i);
    }

    private final void releaseViewForPointerUp() {
        this.mVelocityTracker.computeCurrentVelocity(1000, this.mMaxVelocity);
        clampMag$ar$ds(this.mVelocityTracker.getXVelocity(this.mActivePointerId), this.mMinVelocity, this.mMaxVelocity);
        dispatchViewReleased$ar$ds(clampMag$ar$ds(this.mVelocityTracker.getYVelocity(this.mActivePointerId), this.mMinVelocity, this.mMaxVelocity));
    }

    private final void reportNewEdgeDrags(float f, float f2, int i) {
        int checkNewEdgeDrag = checkNewEdgeDrag(f, f2, i, 1);
        if (checkNewEdgeDrag(f2, f, i, 4)) {
            checkNewEdgeDrag |= 4;
        }
        if (checkNewEdgeDrag(f, f2, i, 2)) {
            checkNewEdgeDrag |= 2;
        }
        if (checkNewEdgeDrag(f2, f, i, 8)) {
            checkNewEdgeDrag |= 8;
        }
        if (checkNewEdgeDrag != 0) {
            int[] iArr = this.mEdgeDragsInProgress;
            iArr[i] = iArr[i] | checkNewEdgeDrag;
            this.mCallback.onEdgeDragStarted(checkNewEdgeDrag, i);
        }
    }

    private final void saveLastMotion(MotionEvent motionEvent) {
        int pointerCount = motionEvent.getPointerCount();
        for (int i = 0; i < pointerCount; i++) {
            int pointerId = motionEvent.getPointerId(i);
            if (isValidPointerForActionMove(pointerId)) {
                float x = motionEvent.getX(i);
                float y = motionEvent.getY(i);
                this.mLastMotionX[pointerId] = x;
                this.mLastMotionY[pointerId] = y;
            }
        }
    }

    public final void captureChildView(View view, int i) {
        if (view.getParent() == this.mParentView) {
            this.mCapturedView = view;
            this.mActivePointerId = i;
            this.mCallback.onViewCaptured$ar$ds(view);
            setDragState(1);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (");
        stringBuilder.append(this.mParentView);
        stringBuilder.append(")");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public final boolean continueSettling$ar$ds() {
        if (this.mDragState == 2) {
            boolean computeScrollOffset = this.mScroller.computeScrollOffset();
            int currX = this.mScroller.getCurrX();
            int currY = this.mScroller.getCurrY();
            int left = currX - this.mCapturedView.getLeft();
            int top = currY - this.mCapturedView.getTop();
            if (left != 0) {
                ViewCompat.offsetLeftAndRight(this.mCapturedView, left);
            }
            if (top != 0) {
                ViewCompat.offsetTopAndBottom(this.mCapturedView, top);
            }
            if (!(left == 0 && top == 0)) {
                this.mCallback.onViewPositionChanged$ar$ds(this.mCapturedView, currY);
            }
            if (computeScrollOffset) {
                if (currX == this.mScroller.getFinalX() && currY == this.mScroller.getFinalY()) {
                    this.mScroller.abortAnimation();
                }
            }
            this.mParentView.post(this.mSetIdleRunnable);
        }
        return this.mDragState == 2;
    }

    public final View findTopChildUnder(int i, int i2) {
        for (int childCount = this.mParentView.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = this.mParentView.getChildAt(childCount);
            if (i >= childAt.getLeft() && i < childAt.getRight() && i2 >= childAt.getTop()) {
                if (i2 < childAt.getBottom()) {
                    return childAt;
                }
            }
        }
        return null;
    }

    public final boolean isPointerDown(int i) {
        return ((1 << i) & this.mPointersDown) != 0;
    }

    public final void processTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        int i = 0;
        if (actionMasked == 0) {
            cancel();
            actionMasked = 0;
        }
        if (this.mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        }
        this.mVelocityTracker.addMovement(motionEvent);
        float x;
        float y;
        int pointerId;
        View findTopChildUnder;
        int i2;
        switch (actionMasked) {
            case 0:
                x = motionEvent.getX();
                y = motionEvent.getY();
                pointerId = motionEvent.getPointerId(0);
                findTopChildUnder = findTopChildUnder((int) x, (int) y);
                saveInitialMotion(x, y, pointerId);
                tryCaptureViewForDrag(findTopChildUnder, pointerId);
                pointerId = this.mInitialEdgesTouched[pointerId];
                return;
            case 1:
                if (this.mDragState == 1) {
                    releaseViewForPointerUp();
                }
                cancel();
                return;
            case 2:
                if (this.mDragState != 1) {
                    actionMasked = motionEvent.getPointerCount();
                    while (i < actionMasked) {
                        actionIndex = motionEvent.getPointerId(i);
                        if (isValidPointerForActionMove(actionIndex)) {
                            float x2 = motionEvent.getX(i);
                            float y2 = motionEvent.getY(i);
                            float f = y2 - this.mInitialMotionY[actionIndex];
                            reportNewEdgeDrags(x2 - this.mInitialMotionX[actionIndex], f, actionIndex);
                            if (this.mDragState != 1) {
                                View findTopChildUnder2 = findTopChildUnder((int) x2, (int) y2);
                                if (checkTouchSlop$ar$ds(findTopChildUnder2, f) && tryCaptureViewForDrag(findTopChildUnder2, actionIndex)) {
                                }
                            }
                        }
                        i++;
                    }
                } else if (isValidPointerForActionMove(this.mActivePointerId)) {
                    actionMasked = motionEvent.findPointerIndex(this.mActivePointerId);
                    if (actionMasked != -1) {
                        y = motionEvent.getX(actionMasked);
                        x = motionEvent.getY(actionMasked);
                        float[] fArr = this.mLastMotionX;
                        i2 = this.mActivePointerId;
                        actionIndex = (int) (y - fArr[i2]);
                        actionMasked = (int) (x - this.mLastMotionY[i2]);
                        this.mCapturedView.getLeft();
                        int top = this.mCapturedView.getTop() + actionMasked;
                        i2 = this.mCapturedView.getLeft();
                        int top2 = this.mCapturedView.getTop();
                        if (actionIndex != 0) {
                            ViewCompat.offsetLeftAndRight(this.mCapturedView, -i2);
                            i = actionIndex;
                        }
                        if (actionMasked != 0) {
                            top = this.mCallback.clampViewPositionVertical$ar$ds(this.mCapturedView, top);
                            ViewCompat.offsetTopAndBottom(this.mCapturedView, top - top2);
                        }
                        if (!(i == 0 && actionMasked == 0)) {
                            this.mCallback.onViewPositionChanged$ar$ds(this.mCapturedView, top);
                        }
                    }
                }
                saveLastMotion(motionEvent);
                return;
            case 3:
                if (this.mDragState == 1) {
                    dispatchViewReleased$ar$ds(0.0f);
                }
                cancel();
                return;
            case 5:
                actionMasked = motionEvent.getPointerId(actionIndex);
                float x3 = motionEvent.getX(actionIndex);
                float y3 = motionEvent.getY(actionIndex);
                saveInitialMotion(x3, y3, actionMasked);
                if (this.mDragState == 0) {
                    tryCaptureViewForDrag(findTopChildUnder((int) x3, (int) y3), actionMasked);
                    pointerId = this.mInitialEdgesTouched[actionMasked];
                    return;
                }
                actionIndex = (int) x3;
                pointerId = (int) y3;
                findTopChildUnder = this.mCapturedView;
                if (findTopChildUnder == null) {
                    break;
                } else if (actionIndex >= findTopChildUnder.getLeft() && actionIndex < findTopChildUnder.getRight() && pointerId >= findTopChildUnder.getTop() && pointerId < findTopChildUnder.getBottom()) {
                    tryCaptureViewForDrag(this.mCapturedView, actionMasked);
                    return;
                }
            case 6:
                actionMasked = motionEvent.getPointerId(actionIndex);
                if (this.mDragState == 1 && actionMasked == this.mActivePointerId) {
                    actionIndex = motionEvent.getPointerCount();
                    while (i < actionIndex) {
                        i2 = motionEvent.getPointerId(i);
                        if (i2 != this.mActivePointerId) {
                            View findTopChildUnder3 = findTopChildUnder((int) motionEvent.getX(i), (int) motionEvent.getY(i));
                            View view = this.mCapturedView;
                            if (findTopChildUnder3 == view && tryCaptureViewForDrag(view, i2)) {
                                if (this.mActivePointerId == -1) {
                                    releaseViewForPointerUp();
                                }
                            }
                        }
                        i++;
                    }
                    releaseViewForPointerUp();
                }
                clearMotionHistory(actionMasked);
                return;
            default:
                break;
        }
    }

    final void setDragState(int i) {
        this.mParentView.removeCallbacks(this.mSetIdleRunnable);
        if (this.mDragState != i) {
            this.mDragState = i;
            this.mCallback.onViewDragStateChanged(i);
            if (this.mDragState == 0) {
                this.mCapturedView = null;
            }
        }
    }

    public final void settleCapturedViewAt$ar$ds(int i) {
        if (this.mReleaseInProgress) {
            forceSettleCapturedViewAt$ar$ds(i, (int) this.mVelocityTracker.getXVelocity(this.mActivePointerId), (int) this.mVelocityTracker.getYVelocity(this.mActivePointerId));
            return;
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }

    public final boolean shouldInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            cancel();
            actionMasked = 0;
        }
        if (this.mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        }
        this.mVelocityTracker.addMovement(motionEvent);
        int pointerId;
        float x;
        switch (actionMasked) {
            case 0:
                float x2 = motionEvent.getX();
                float y = motionEvent.getY();
                pointerId = motionEvent.getPointerId(0);
                saveInitialMotion(x2, y, pointerId);
                View findTopChildUnder = findTopChildUnder((int) x2, (int) y);
                if (findTopChildUnder == this.mCapturedView && this.mDragState == 2) {
                    tryCaptureViewForDrag(findTopChildUnder, pointerId);
                }
                pointerId = this.mInitialEdgesTouched[pointerId];
                break;
            case 1:
            case 3:
                cancel();
                break;
            case 2:
                if (!(this.mInitialMotionX == null || this.mInitialMotionY == null)) {
                    actionMasked = motionEvent.getPointerCount();
                    for (actionIndex = 0; actionIndex < actionMasked; actionIndex++) {
                        int pointerId2 = motionEvent.getPointerId(actionIndex);
                        if (isValidPointerForActionMove(pointerId2)) {
                            x = motionEvent.getX(actionIndex);
                            float y2 = motionEvent.getY(actionIndex);
                            float f = x - this.mInitialMotionX[pointerId2];
                            float f2 = y2 - this.mInitialMotionY[pointerId2];
                            View findTopChildUnder2 = findTopChildUnder((int) x, (int) y2);
                            boolean checkTouchSlop$ar$ds = checkTouchSlop$ar$ds(findTopChildUnder2, f2);
                            if (checkTouchSlop$ar$ds) {
                                findTopChildUnder2.getLeft();
                                int top = findTopChildUnder2.getTop();
                                int clampViewPositionVertical$ar$ds = this.mCallback.clampViewPositionVertical$ar$ds(findTopChildUnder2, ((int) f2) + top);
                                int viewVerticalDragRange = this.mCallback.getViewVerticalDragRange(findTopChildUnder2);
                                if (viewVerticalDragRange != 0) {
                                    if (viewVerticalDragRange > 0 && clampViewPositionVertical$ar$ds == top) {
                                    }
                                }
                                saveLastMotion(motionEvent);
                                break;
                            }
                            reportNewEdgeDrags(f, f2, pointerId2);
                            if (this.mDragState != 1) {
                                if (checkTouchSlop$ar$ds && tryCaptureViewForDrag(findTopChildUnder2, pointerId2)) {
                                }
                            }
                            saveLastMotion(motionEvent);
                        }
                    }
                    saveLastMotion(motionEvent);
                }
            case 5:
                actionMasked = motionEvent.getPointerId(actionIndex);
                x = motionEvent.getX(actionIndex);
                float y3 = motionEvent.getY(actionIndex);
                saveInitialMotion(x, y3, actionMasked);
                actionIndex = this.mDragState;
                if (actionIndex != 0) {
                    if (actionIndex == 2) {
                        View findTopChildUnder3 = findTopChildUnder((int) x, (int) y3);
                        if (findTopChildUnder3 == this.mCapturedView) {
                            tryCaptureViewForDrag(findTopChildUnder3, actionMasked);
                            break;
                        }
                    }
                }
                pointerId = this.mInitialEdgesTouched[actionMasked];
                break;
                break;
            case 6:
                clearMotionHistory(motionEvent.getPointerId(actionIndex));
                break;
            default:
                break;
        }
        if (this.mDragState == 1) {
            return true;
        }
        return false;
    }

    public final void smoothSlideViewTo$ar$ds(View view, int i) {
        this.mCapturedView = view;
        this.mActivePointerId = -1;
        if (!forceSettleCapturedViewAt$ar$ds(i, 0, 0) && this.mDragState == 0 && this.mCapturedView != null) {
            this.mCapturedView = null;
        }
    }

    final boolean tryCaptureViewForDrag(View view, int i) {
        if (view == this.mCapturedView) {
            if (this.mActivePointerId == i) {
                return true;
            }
        }
        if (view == null || !this.mCallback.tryCaptureView$ar$ds(view)) {
            return false;
        }
        this.mActivePointerId = i;
        captureChildView(view, i);
        return true;
    }

    public static ViewDragHelper create$ar$ds$1b20f587_0(ViewGroup viewGroup, Callback callback) {
        ViewDragHelper viewDragHelper = new ViewDragHelper(viewGroup.getContext(), viewGroup, callback);
        viewDragHelper.mTouchSlop = (int) ((float) viewDragHelper.mTouchSlop);
        return viewDragHelper;
    }

    private final void saveInitialMotion(float f, float f2, int i) {
        Object obj = this.mInitialMotionX;
        int i2 = 0;
        if (obj == null || obj.length <= i) {
            int i3 = i + 1;
            Object obj2 = new float[i3];
            Object obj3 = new float[i3];
            Object obj4 = new float[i3];
            Object obj5 = new float[i3];
            Object obj6 = new int[i3];
            Object obj7 = new int[i3];
            Object obj8 = new int[i3];
            if (obj != null) {
                System.arraycopy(obj, 0, obj2, 0, obj.length);
                obj = this.mInitialMotionY;
                System.arraycopy(obj, 0, obj3, 0, obj.length);
                obj = this.mLastMotionX;
                System.arraycopy(obj, 0, obj4, 0, obj.length);
                obj = this.mLastMotionY;
                System.arraycopy(obj, 0, obj5, 0, obj.length);
                obj = this.mInitialEdgesTouched;
                System.arraycopy(obj, 0, obj6, 0, obj.length);
                obj = this.mEdgeDragsInProgress;
                System.arraycopy(obj, 0, obj7, 0, obj.length);
                obj = this.mEdgeDragsLocked;
                System.arraycopy(obj, 0, obj8, 0, obj.length);
            }
            this.mInitialMotionX = obj2;
            this.mInitialMotionY = obj3;
            this.mLastMotionX = obj4;
            this.mLastMotionY = obj5;
            this.mInitialEdgesTouched = obj6;
            this.mEdgeDragsInProgress = obj7;
            this.mEdgeDragsLocked = obj8;
        }
        float[] fArr = this.mInitialMotionX;
        this.mLastMotionX[i] = f;
        fArr[i] = f;
        fArr = this.mInitialMotionY;
        this.mLastMotionY[i] = f2;
        fArr[i] = f2;
        int[] iArr = this.mInitialEdgesTouched;
        int i4 = (int) f;
        int i5 = (int) f2;
        if (i4 < this.mParentView.getLeft() + this.mEdgeSize) {
            i2 = 1;
        }
        if (i5 < this.mParentView.getTop() + this.mEdgeSize) {
            i2 |= 4;
        }
        if (i4 > this.mParentView.getRight() - this.mEdgeSize) {
            i2 |= 2;
        }
        if (i5 > this.mParentView.getBottom() - this.mEdgeSize) {
            i2 |= 8;
        }
        iArr[i] = i2;
        this.mPointersDown |= 1 << i;
    }

    public final void cancel() {
        this.mActivePointerId = -1;
        float[] fArr = this.mInitialMotionX;
        if (fArr != null) {
            Arrays.fill(fArr, 0.0f);
            Arrays.fill(this.mInitialMotionY, 0.0f);
            Arrays.fill(this.mLastMotionX, 0.0f);
            Arrays.fill(this.mLastMotionY, 0.0f);
            Arrays.fill(this.mInitialEdgesTouched, 0);
            Arrays.fill(this.mEdgeDragsInProgress, 0);
            Arrays.fill(this.mEdgeDragsLocked, 0);
            this.mPointersDown = 0;
        }
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.mVelocityTracker = null;
        }
    }
}
