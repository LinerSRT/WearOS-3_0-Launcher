package androidx.customview.view;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;

/* compiled from: PG */
public class AbsSavedState implements Parcelable {
    public static final Creator CREATOR = new C01432();
    public static final AbsSavedState EMPTY_STATE = new PG();
    public final Parcelable mSuperState;

    /* renamed from: androidx.customview.view.AbsSavedState$1 */
    final class PG extends AbsSavedState {
    }

    /* renamed from: androidx.customview.view.AbsSavedState$2 */
    final class C01432 implements ClassLoaderCreator {
        public static final AbsSavedState createFromParcel$ar$ds(Parcel parcel, ClassLoader classLoader) {
            if (parcel.readParcelable(classLoader) == null) {
                return AbsSavedState.EMPTY_STATE;
            }
            throw new IllegalStateException("superState must be null");
        }

        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new AbsSavedState[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return C01432.createFromParcel$ar$ds(parcel, null);
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
            return C01432.createFromParcel$ar$ds(parcel, classLoader);
        }
    }

    public AbsSavedState() {
        this.mSuperState = null;
    }

    public final int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.mSuperState, i);
    }

    protected AbsSavedState(Parcel parcel, ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        if (readParcelable == null) {
            readParcelable = EMPTY_STATE;
        }
        this.mSuperState = readParcelable;
    }

    protected AbsSavedState(Parcelable parcelable) {
        if (parcelable != null) {
            if (parcelable == EMPTY_STATE) {
                parcelable = null;
            }
            this.mSuperState = parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }
}
