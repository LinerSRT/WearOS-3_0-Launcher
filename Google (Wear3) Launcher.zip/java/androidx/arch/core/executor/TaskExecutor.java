package androidx.arch.core.executor;

/* compiled from: PG */
public class TaskExecutor {
}
