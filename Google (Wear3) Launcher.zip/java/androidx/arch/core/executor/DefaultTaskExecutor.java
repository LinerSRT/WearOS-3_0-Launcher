package androidx.arch.core.executor;

import android.os.Handler;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: PG */
public final class DefaultTaskExecutor extends TaskExecutor {
    public final Object mLock = new Object();
    public volatile Handler mMainHandler;

    /* renamed from: androidx.arch.core.executor.DefaultTaskExecutor$1 */
    final class PG implements ThreadFactory {
        private final AtomicInteger mThreadId = new AtomicInteger(0);

        public final Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable);
            thread.setName(String.format("arch_disk_io_%d", new Object[]{Integer.valueOf(this.mThreadId.getAndIncrement())}));
            return thread;
        }
    }

    public DefaultTaskExecutor() {
        Executors.newFixedThreadPool(4, new PG());
    }
}
