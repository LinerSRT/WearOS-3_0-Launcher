package androidx.arch.core.executor;

import android.os.Looper;

/* compiled from: PG */
public final class ArchTaskExecutor extends TaskExecutor {
    private static volatile ArchTaskExecutor sInstance;
    private final TaskExecutor mDefaultTaskExecutor;
    public final TaskExecutor mDelegate;

    private ArchTaskExecutor() {
        TaskExecutor defaultTaskExecutor = new DefaultTaskExecutor();
        this.mDefaultTaskExecutor = defaultTaskExecutor;
        this.mDelegate = defaultTaskExecutor;
    }

    public static ArchTaskExecutor getInstance() {
        if (sInstance != null) {
            return sInstance;
        }
        synchronized (ArchTaskExecutor.class) {
            if (sInstance == null) {
                sInstance = new ArchTaskExecutor();
            }
        }
        return sInstance;
    }

    public static final boolean isMainThread$ar$ds() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }
}
