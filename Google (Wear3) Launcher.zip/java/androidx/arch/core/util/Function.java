package androidx.arch.core.util;

/* compiled from: PG */
public interface Function {
    Object apply(Object obj);
}
