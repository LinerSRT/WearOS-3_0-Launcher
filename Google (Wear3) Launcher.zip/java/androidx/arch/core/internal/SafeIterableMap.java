package androidx.arch.core.internal;

import java.util.Iterator;
import java.util.WeakHashMap;

/* compiled from: PG */
public class SafeIterableMap implements Iterable {
    public Entry mEnd;
    public final WeakHashMap mIterators = new WeakHashMap();
    public int mSize = 0;
    public Entry mStart;

    /* compiled from: PG */
    final class AscendingIterator extends ListIterator {
        public AscendingIterator(Entry entry, Entry entry2) {
            super(entry, entry2);
        }

        public final Entry backward(Entry entry) {
            return entry.mPrevious;
        }

        public final Entry forward(Entry entry) {
            return entry.mNext;
        }
    }

    /* compiled from: PG */
    public final class DescendingIterator extends ListIterator {
        public DescendingIterator(Entry entry, Entry entry2) {
            super(entry, entry2);
        }

        public final Entry backward(Entry entry) {
            return entry.mNext;
        }

        public final Entry forward(Entry entry) {
            return entry.mPrevious;
        }
    }

    /* compiled from: PG */
    public final class Entry implements java.util.Map.Entry {
        public final Object mKey;
        Entry mNext;
        public Entry mPrevious;
        public final Object mValue;

        public Entry(Object obj, Object obj2) {
            this.mKey = obj;
            this.mValue = obj2;
        }

        public final boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Entry)) {
                return false;
            }
            Entry entry = (Entry) obj;
            return this.mKey.equals(entry.mKey) && this.mValue.equals(entry.mValue);
        }

        public final Object getKey() {
            return this.mKey;
        }

        public final Object getValue() {
            return this.mValue;
        }

        public final int hashCode() {
            return this.mKey.hashCode() ^ this.mValue.hashCode();
        }

        public final Object setValue(Object obj) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.mKey);
            stringBuilder.append("=");
            stringBuilder.append(this.mValue);
            return stringBuilder.toString();
        }
    }

    /* compiled from: PG */
    public final class IteratorWithAdditions extends SupportRemove implements Iterator {
        private boolean mBeforeStart = true;
        private Entry mCurrent;

        public final boolean hasNext() {
            if (this.mBeforeStart) {
                return SafeIterableMap.this.mStart != null;
            } else {
                Entry entry = this.mCurrent;
                return (entry == null || entry.mNext == null) ? false : true;
            }
        }

        public final java.util.Map.Entry next() {
            Entry entry;
            if (this.mBeforeStart) {
                this.mBeforeStart = false;
                entry = SafeIterableMap.this.mStart;
            } else {
                entry = this.mCurrent;
                entry = entry != null ? entry.mNext : null;
            }
            this.mCurrent = entry;
            return this.mCurrent;
        }

        public final void supportRemove(Entry entry) {
            Entry entry2 = this.mCurrent;
            if (entry == entry2) {
                entry = entry2.mPrevious;
                this.mCurrent = entry;
                this.mBeforeStart = entry == null;
            }
        }
    }

    /* compiled from: PG */
    public abstract class ListIterator extends SupportRemove implements Iterator {
        Entry mExpectedEnd;
        Entry mNext;

        public ListIterator(Entry entry, Entry entry2) {
            this.mExpectedEnd = entry2;
            this.mNext = entry;
        }

        private final Entry nextNode() {
            Entry entry = this.mNext;
            Entry entry2 = this.mExpectedEnd;
            if (entry != entry2) {
                if (entry2 != null) {
                    return forward(entry);
                }
            }
            return null;
        }

        public abstract Entry backward(Entry entry);

        public abstract Entry forward(Entry entry);

        public final boolean hasNext() {
            return this.mNext != null;
        }

        public final void supportRemove(Entry entry) {
            if (this.mExpectedEnd == entry && entry == this.mNext) {
                this.mNext = null;
                this.mExpectedEnd = null;
            }
            Entry entry2 = this.mExpectedEnd;
            if (entry2 == entry) {
                this.mExpectedEnd = backward(entry2);
            }
            if (this.mNext == entry) {
                this.mNext = nextNode();
            }
        }

        public final java.util.Map.Entry next() {
            java.util.Map.Entry entry = this.mNext;
            this.mNext = nextNode();
            return entry;
        }
    }

    /* compiled from: PG */
    abstract class SupportRemove {
        public abstract void supportRemove(Entry entry);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof SafeIterableMap)) {
            return false;
        }
        SafeIterableMap safeIterableMap = (SafeIterableMap) obj;
        if (this.mSize != safeIterableMap.mSize) {
            return false;
        }
        Iterator it = iterator();
        Iterator it2 = safeIterableMap.iterator();
        while (it.hasNext() && it2.hasNext()) {
            java.util.Map.Entry next = ((ListIterator) it).next();
            Object next2 = ((ListIterator) it2).next();
            if (next == null) {
                if (next2 != null) {
                    return false;
                }
                next2 = null;
            }
            if (next != null && !next.equals(next2)) {
                return false;
            }
        }
        return (it.hasNext() || it2.hasNext()) ? false : true;
    }

    protected Entry get(Object obj) {
        Entry entry = this.mStart;
        while (entry != null) {
            if (entry.mKey.equals(obj)) {
                break;
            }
            entry = entry.mNext;
        }
        return entry;
    }

    public final int hashCode() {
        Iterator it = iterator();
        int i = 0;
        while (it.hasNext()) {
            i += ((ListIterator) it).next().hashCode();
        }
        return i;
    }

    public final Iterator iterator() {
        Iterator ascendingIterator = new AscendingIterator(this.mStart, this.mEnd);
        this.mIterators.put(ascendingIterator, Boolean.valueOf(false));
        return ascendingIterator;
    }

    public final IteratorWithAdditions iteratorWithAdditions() {
        IteratorWithAdditions iteratorWithAdditions = new IteratorWithAdditions();
        this.mIterators.put(iteratorWithAdditions, Boolean.valueOf(false));
        return iteratorWithAdditions;
    }

    public final Entry put(Object obj, Object obj2) {
        Entry entry = new Entry(obj, obj2);
        this.mSize++;
        Entry entry2 = this.mEnd;
        if (entry2 == null) {
            this.mStart = entry;
        } else {
            entry2.mNext = entry;
            entry.mPrevious = entry2;
        }
        this.mEnd = entry;
        return entry;
    }

    public final Object putIfAbsent(Object obj, Object obj2) {
        Entry entry = get(obj);
        if (entry != null) {
            return entry.mValue;
        }
        put(obj, obj2);
        return null;
    }

    public Object remove(Object obj) {
        Entry entry = get(obj);
        if (entry == null) {
            return null;
        }
        this.mSize--;
        if (!this.mIterators.isEmpty()) {
            for (SupportRemove supportRemove : this.mIterators.keySet()) {
                supportRemove.supportRemove(entry);
            }
        }
        Entry entry2 = entry.mPrevious;
        Entry entry3 = entry.mNext;
        if (entry2 != null) {
            entry2.mNext = entry3;
        } else {
            this.mStart = entry3;
        }
        entry3 = entry.mNext;
        if (entry3 != null) {
            entry3.mPrevious = entry2;
        } else {
            this.mEnd = entry2;
        }
        entry.mNext = null;
        entry.mPrevious = null;
        return entry.mValue;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        Iterator it = iterator();
        while (it.hasNext()) {
            stringBuilder.append(((ListIterator) it).next().toString());
            if (it.hasNext()) {
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
