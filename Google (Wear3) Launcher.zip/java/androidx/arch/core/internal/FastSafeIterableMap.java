package androidx.arch.core.internal;

import androidx.arch.core.internal.SafeIterableMap.Entry;
import java.util.HashMap;

/* compiled from: PG */
public final class FastSafeIterableMap extends SafeIterableMap {
    public final HashMap mHashMap = new HashMap();

    public final boolean contains(Object obj) {
        return this.mHashMap.containsKey(obj);
    }

    public final Entry get(Object obj) {
        return (Entry) this.mHashMap.get(obj);
    }

    public final Object remove(Object obj) {
        Object remove = super.remove(obj);
        this.mHashMap.remove(obj);
        return remove;
    }
}
