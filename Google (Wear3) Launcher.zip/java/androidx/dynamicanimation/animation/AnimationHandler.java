package androidx.dynamicanimation.animation;

import android.os.Looper;
import android.view.Choreographer;
import androidx.collection.SimpleArrayMap;
import java.util.ArrayList;

/* compiled from: PG */
public final class AnimationHandler {
    public static final ThreadLocal sAnimatorHandler = new ThreadLocal();
    final ArrayList mAnimationCallbacks = new ArrayList();
    public final AnimationCallbackDispatcher mCallbackDispatcher = new AnimationCallbackDispatcher();
    long mCurrentFrameTime = 0;
    public final SimpleArrayMap mDelayedCallbackStartTime = new SimpleArrayMap();
    public boolean mListDirty = false;
    public final Runnable mRunnable = new AnimationHandler$$ExternalSyntheticLambda0();
    public final FrameCallbackScheduler16 mScheduler$ar$class_merging;

    /* compiled from: PG */
    final class AnimationCallbackDispatcher {
    }

    /* compiled from: PG */
    interface AnimationFrameCallback {
        void doAnimationFrame$ar$ds(long j);
    }

    /* compiled from: PG */
    final class FrameCallbackScheduler16 {
        private final Choreographer mChoreographer = Choreographer.getInstance();
        public final Looper mLooper = Looper.myLooper();

        public final void postFrameCallback(Runnable runnable) {
            this.mChoreographer.postFrameCallback(new PG(runnable));
        }
    }

    public AnimationHandler(FrameCallbackScheduler16 frameCallbackScheduler16) {
        this.mScheduler$ar$class_merging = frameCallbackScheduler16;
    }

    final boolean isCurrentThread() {
        return Thread.currentThread() == this.mScheduler$ar$class_merging.mLooper.getThread();
    }
}
