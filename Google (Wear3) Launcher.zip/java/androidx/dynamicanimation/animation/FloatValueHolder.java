package androidx.dynamicanimation.animation;

/* compiled from: PG */
public class FloatValueHolder {
    public float mValue = 0.0f;

    public void setValue(float f) {
        this.mValue = f;
    }

    public FloatValueHolder(float f) {
        setValue(f);
    }
}
