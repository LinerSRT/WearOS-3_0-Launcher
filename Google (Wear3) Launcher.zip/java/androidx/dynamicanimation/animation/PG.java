package androidx.dynamicanimation.animation;

import android.view.Choreographer.FrameCallback;

/* renamed from: androidx.dynamicanimation.animation.AnimationHandler$FrameCallbackScheduler16$$ExternalSyntheticLambda0 */
public final /* synthetic */ class PG implements FrameCallback {
    public final /* synthetic */ Runnable f$0;

    public /* synthetic */ PG(Runnable runnable) {
        this.f$0 = runnable;
    }

    public final void doFrame(long j) {
        this.f$0.run();
    }
}
