package androidx.dynamicanimation.animation;

import android.view.View;
import java.util.ArrayList;

/* compiled from: PG */
public abstract class DynamicAnimation implements AnimationFrameCallback {
    public static final ViewProperty ALPHA = new C014512();
    public static final ViewProperty ROTATION = new C01496();
    public static final ViewProperty ROTATION_X = new C01507();
    public static final ViewProperty ROTATION_Y = new C01518();
    public static final ViewProperty SCALE_X = new C01474();
    public static final ViewProperty SCALE_Y = new C01485();
    public static final ViewProperty TRANSLATION_X = new PG();
    private AnimationHandler mAnimationHandler;
    private final ArrayList mEndListeners;
    private long mLastFrameTime;
    public float mMinVisibleChange;
    final FloatPropertyCompat mProperty;
    public boolean mRunning;
    boolean mStartValueIsSet;
    final Object mTarget;
    private final ArrayList mUpdateListeners;
    float mValue;
    public float mVelocity;

    /* renamed from: androidx.dynamicanimation.animation.DynamicAnimation$1 */
    final class PG extends ViewProperty {
        public final /* bridge */ /* synthetic */ float getValue(Object obj) {
            return ((View) obj).getTranslationX();
        }

        public final /* bridge */ /* synthetic */ void setValue(Object obj, float f) {
            ((View) obj).setTranslationX(f);
        }
    }

    /* renamed from: androidx.dynamicanimation.animation.DynamicAnimation$12 */
    final class C014512 extends ViewProperty {
        public final /* bridge */ /* synthetic */ float getValue(Object obj) {
            return ((View) obj).getAlpha();
        }

        public final /* bridge */ /* synthetic */ void setValue(Object obj, float f) {
            ((View) obj).setAlpha(f);
        }
    }

    /* renamed from: androidx.dynamicanimation.animation.DynamicAnimation$15 */
    final class C014615 extends FloatPropertyCompat {
        final /* synthetic */ FloatValueHolder val$floatValueHolder;

        public C014615(FloatValueHolder floatValueHolder) {
            this.val$floatValueHolder = floatValueHolder;
        }

        public final float getValue(Object obj) {
            return this.val$floatValueHolder.mValue;
        }

        public final void setValue(Object obj, float f) {
            this.val$floatValueHolder.setValue(f);
        }
    }

    /* renamed from: androidx.dynamicanimation.animation.DynamicAnimation$4 */
    final class C01474 extends ViewProperty {
        public final /* bridge */ /* synthetic */ float getValue(Object obj) {
            return ((View) obj).getScaleX();
        }

        public final /* bridge */ /* synthetic */ void setValue(Object obj, float f) {
            ((View) obj).setScaleX(f);
        }
    }

    /* renamed from: androidx.dynamicanimation.animation.DynamicAnimation$5 */
    final class C01485 extends ViewProperty {
        public final /* bridge */ /* synthetic */ float getValue(Object obj) {
            return ((View) obj).getScaleY();
        }

        public final /* bridge */ /* synthetic */ void setValue(Object obj, float f) {
            ((View) obj).setScaleY(f);
        }
    }

    /* renamed from: androidx.dynamicanimation.animation.DynamicAnimation$6 */
    final class C01496 extends ViewProperty {
        public final /* bridge */ /* synthetic */ float getValue(Object obj) {
            return ((View) obj).getRotation();
        }

        public final /* bridge */ /* synthetic */ void setValue(Object obj, float f) {
            ((View) obj).setRotation(f);
        }
    }

    /* renamed from: androidx.dynamicanimation.animation.DynamicAnimation$7 */
    final class C01507 extends ViewProperty {
        public final /* bridge */ /* synthetic */ float getValue(Object obj) {
            return ((View) obj).getRotationX();
        }

        public final /* bridge */ /* synthetic */ void setValue(Object obj, float f) {
            ((View) obj).setRotationX(f);
        }
    }

    /* renamed from: androidx.dynamicanimation.animation.DynamicAnimation$8 */
    final class C01518 extends ViewProperty {
        public final /* bridge */ /* synthetic */ float getValue(Object obj) {
            return ((View) obj).getRotationY();
        }

        public final /* bridge */ /* synthetic */ void setValue(Object obj, float f) {
            ((View) obj).setRotationY(f);
        }
    }

    /* compiled from: PG */
    final class MassState {
        float mValue;
        float mVelocity;
    }

    /* compiled from: PG */
    public interface OnAnimationEndListener {
        void onAnimationEnd$ar$ds$486c95f9_0(boolean z);
    }

    /* compiled from: PG */
    public interface OnAnimationUpdateListener {
        void onAnimationUpdate$ar$ds(DynamicAnimation dynamicAnimation, float f);
    }

    /* compiled from: PG */
    public abstract class ViewProperty extends FloatPropertyCompat {
    }

    public DynamicAnimation(FloatValueHolder floatValueHolder) {
        this.mVelocity = 0.0f;
        this.mValue = Float.MAX_VALUE;
        this.mStartValueIsSet = false;
        this.mRunning = false;
        this.mLastFrameTime = 0;
        this.mEndListeners = new ArrayList();
        this.mUpdateListeners = new ArrayList();
        this.mTarget = null;
        this.mProperty = new C014615(floatValueHolder);
        this.mMinVisibleChange = 1.0f;
    }

    private static void removeNullEntries(ArrayList arrayList) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (arrayList.get(size) == null) {
                arrayList.remove(size);
            }
        }
    }

    public final void addEndListener$ar$ds(OnAnimationEndListener onAnimationEndListener) {
        if (!this.mEndListeners.contains(onAnimationEndListener)) {
            this.mEndListeners.add(onAnimationEndListener);
        }
    }

    public final void addUpdateListener$ar$ds(OnAnimationUpdateListener onAnimationUpdateListener) {
        if (this.mRunning) {
            throw new UnsupportedOperationException("Error: Update listeners must be added beforethe animation.");
        } else if (!this.mUpdateListeners.contains(onAnimationUpdateListener)) {
            this.mUpdateListeners.add(onAnimationUpdateListener);
        }
    }

    public final void doAnimationFrame$ar$ds(long j) {
        long j2 = this.mLastFrameTime;
        int i = (j2 > 0 ? 1 : (j2 == 0 ? 0 : -1));
        this.mLastFrameTime = j;
        if (i == 0) {
            setPropertyValue(this.mValue);
            return;
        }
        boolean updateValueAndVelocity = updateValueAndVelocity(j - j2);
        float min = Math.min(this.mValue, Float.MAX_VALUE);
        this.mValue = min;
        min = Math.max(min, -3.4028235E38f);
        this.mValue = min;
        setPropertyValue(min);
        if (updateValueAndVelocity) {
            endAnimationInternal(false);
        }
    }

    public final void endAnimationInternal(boolean z) {
        int i = 0;
        this.mRunning = false;
        AnimationHandler animationHandler = getAnimationHandler();
        animationHandler.mDelayedCallbackStartTime.remove(this);
        int indexOf = animationHandler.mAnimationCallbacks.indexOf(this);
        if (indexOf >= 0) {
            animationHandler.mAnimationCallbacks.set(indexOf, null);
            animationHandler.mListDirty = true;
        }
        this.mLastFrameTime = 0;
        this.mStartValueIsSet = false;
        while (i < this.mEndListeners.size()) {
            if (this.mEndListeners.get(i) != null) {
                ((OnAnimationEndListener) this.mEndListeners.get(i)).onAnimationEnd$ar$ds$486c95f9_0(z);
            }
            i++;
        }
        removeNullEntries(this.mEndListeners);
    }

    public final AnimationHandler getAnimationHandler() {
        if (this.mAnimationHandler == null) {
            if (AnimationHandler.sAnimatorHandler.get() == null) {
                AnimationHandler.sAnimatorHandler.set(new AnimationHandler(new FrameCallbackScheduler16()));
            }
            this.mAnimationHandler = (AnimationHandler) AnimationHandler.sAnimatorHandler.get();
        }
        return this.mAnimationHandler;
    }

    public final void setMinimumVisibleChange$ar$ds() {
        this.mMinVisibleChange = 0.00390625f;
    }

    final void setPropertyValue(float f) {
        this.mProperty.setValue(this.mTarget, f);
        for (int i = 0; i < this.mUpdateListeners.size(); i++) {
            if (this.mUpdateListeners.get(i) != null) {
                ((OnAnimationUpdateListener) this.mUpdateListeners.get(i)).onAnimationUpdate$ar$ds(this, this.mValue);
            }
        }
        removeNullEntries(this.mUpdateListeners);
    }

    public final void setStartValue$ar$ds(float f) {
        this.mValue = f;
        this.mStartValueIsSet = true;
    }

    public abstract boolean updateValueAndVelocity(long j);

    public DynamicAnimation(Object obj, FloatPropertyCompat floatPropertyCompat) {
        float f;
        this.mVelocity = 0.0f;
        this.mValue = Float.MAX_VALUE;
        this.mStartValueIsSet = false;
        this.mRunning = false;
        this.mLastFrameTime = 0;
        this.mEndListeners = new ArrayList();
        this.mUpdateListeners = new ArrayList();
        this.mTarget = obj;
        this.mProperty = floatPropertyCompat;
        if (!(floatPropertyCompat == ROTATION || floatPropertyCompat == ROTATION_X)) {
            if (floatPropertyCompat != ROTATION_Y) {
                if (floatPropertyCompat == ALPHA) {
                    f = 0.00390625f;
                } else {
                    if (floatPropertyCompat != SCALE_X) {
                        if (floatPropertyCompat != SCALE_Y) {
                            f = 1.0f;
                        }
                    }
                    f = 0.002f;
                }
                this.mMinVisibleChange = f;
            }
        }
        f = 0.1f;
        this.mMinVisibleChange = f;
    }
}
