package androidx.dynamicanimation.animation;

import android.util.AndroidRuntimeException;

/* compiled from: PG */
public final class SpringAnimation extends DynamicAnimation {
    private boolean mEndRequested = false;
    private float mPendingPosition = Float.MAX_VALUE;
    public SpringForce mSpring = null;

    public SpringAnimation(FloatValueHolder floatValueHolder) {
        super(floatValueHolder);
    }

    public final boolean canSkipToEnd() {
        return this.mSpring.mDampingRatio > 0.0d;
    }

    public final void skipToEnd() {
        if (!canSkipToEnd()) {
            throw new UnsupportedOperationException("Spring animations can only come to an end when there is damping");
        } else if (!getAnimationHandler().isCurrentThread()) {
            throw new AndroidRuntimeException("Animations may only be started on the same thread as the animation handler");
        } else if (this.mRunning) {
            this.mEndRequested = true;
        }
    }

    public final boolean updateValueAndVelocity(long j) {
        float f;
        if (this.mEndRequested) {
            f = r0.mPendingPosition;
            if (f != Float.MAX_VALUE) {
                r0.mSpring.setFinalPosition$ar$ds(f);
                r0.mPendingPosition = Float.MAX_VALUE;
            }
            r0.mValue = r0.mSpring.getFinalPosition();
            r0.mVelocity = 0.0f;
            r0.mEndRequested = false;
            return true;
        }
        float f2;
        MassState updateValues;
        if (r0.mPendingPosition != Float.MAX_VALUE) {
            long j2 = j / 2;
            updateValues = r0.mSpring.updateValues((double) r0.mValue, (double) r0.mVelocity, j2);
            r0.mSpring.setFinalPosition$ar$ds(r0.mPendingPosition);
            r0.mPendingPosition = Float.MAX_VALUE;
            updateValues = r0.mSpring.updateValues((double) updateValues.mValue, (double) updateValues.mVelocity, j2);
            f2 = updateValues.mValue;
            r0.mValue = f2;
            r0.mVelocity = updateValues.mVelocity;
        } else {
            updateValues = r0.mSpring.updateValues((double) r0.mValue, (double) r0.mVelocity, j);
            f2 = updateValues.mValue;
            r0.mValue = f2;
            r0.mVelocity = updateValues.mVelocity;
        }
        f = Math.max(f2, -3.4028235E38f);
        r0.mValue = f;
        f = Math.min(f, Float.MAX_VALUE);
        r0.mValue = f;
        float f3 = r0.mVelocity;
        SpringForce springForce = r0.mSpring;
        if (((double) Math.abs(f3)) >= springForce.mVelocityThreshold || ((double) Math.abs(f - springForce.getFinalPosition())) >= springForce.mValueThreshold) {
            return false;
        }
        r0.mValue = r0.mSpring.getFinalPosition();
        r0.mVelocity = 0.0f;
        return true;
    }

    public SpringAnimation(Object obj, FloatPropertyCompat floatPropertyCompat) {
        super(obj, floatPropertyCompat);
    }

    public final void cancel() {
        if (getAnimationHandler().isCurrentThread()) {
            if (this.mRunning) {
                super.endAnimationInternal(true);
            }
            float f = this.mPendingPosition;
            if (f != Float.MAX_VALUE) {
                SpringForce springForce = this.mSpring;
                if (springForce == null) {
                    this.mSpring = new SpringForce(f);
                } else {
                    springForce.setFinalPosition$ar$ds(f);
                }
                this.mPendingPosition = Float.MAX_VALUE;
                return;
            }
            return;
        }
        throw new AndroidRuntimeException("Animations may only be canceled from the same thread as the animation handler");
    }

    public final void start() {
        SpringForce springForce = this.mSpring;
        if (springForce != null) {
            double finalPosition = (double) springForce.getFinalPosition();
            if (finalPosition > 3.4028234663852886E38d) {
                throw new UnsupportedOperationException("Final position of the spring cannot be greater than the max value.");
            } else if (finalPosition >= -3.4028234663852886E38d) {
                springForce = this.mSpring;
                double abs = Math.abs((double) (this.mMinVisibleChange * 0.75f));
                springForce.mValueThreshold = abs;
                springForce.mVelocityThreshold = abs * 62.5d;
                if (getAnimationHandler().isCurrentThread()) {
                    if (!this.mRunning) {
                        this.mRunning = true;
                        if (!this.mStartValueIsSet) {
                            this.mValue = this.mProperty.getValue(this.mTarget);
                        }
                        float f = this.mValue;
                        if (f > Float.MAX_VALUE || f < -3.4028235E38f) {
                            throw new IllegalArgumentException("Starting value need to be in between min value and max value");
                        }
                        AnimationHandler animationHandler = getAnimationHandler();
                        if (animationHandler.mAnimationCallbacks.size() == 0) {
                            animationHandler.mScheduler$ar$class_merging.postFrameCallback(animationHandler.mRunnable);
                        }
                        if (!animationHandler.mAnimationCallbacks.contains(this)) {
                            animationHandler.mAnimationCallbacks.add(this);
                            return;
                        }
                    }
                    return;
                }
                throw new AndroidRuntimeException("Animations may only be started on the same thread as the animation handler");
            } else {
                throw new UnsupportedOperationException("Final position of the spring cannot be less than the min value.");
            }
        }
        throw new UnsupportedOperationException("Incomplete SpringAnimation: Either final position or a spring force needs to be set.");
    }
}
