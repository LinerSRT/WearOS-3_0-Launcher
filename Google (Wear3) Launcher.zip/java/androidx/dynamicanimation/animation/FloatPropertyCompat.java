package androidx.dynamicanimation.animation;

import android.util.FloatProperty;

/* compiled from: PG */
public abstract class FloatPropertyCompat {

    /* renamed from: androidx.dynamicanimation.animation.FloatPropertyCompat$1 */
    public final class PG extends FloatPropertyCompat {
        final /* synthetic */ FloatProperty val$property;

        public PG(FloatProperty floatProperty) {
            this.val$property = floatProperty;
        }

        public final float getValue(Object obj) {
            return ((Float) this.val$property.get(obj)).floatValue();
        }

        public final void setValue(Object obj, float f) {
            this.val$property.setValue(obj, f);
        }
    }

    public abstract float getValue(Object obj);

    public abstract void setValue(Object obj, float f);
}
