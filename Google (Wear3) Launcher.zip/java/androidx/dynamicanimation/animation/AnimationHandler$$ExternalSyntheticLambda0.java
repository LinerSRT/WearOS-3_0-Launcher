package androidx.dynamicanimation.animation;

import android.os.SystemClock;

/* compiled from: PG */
public final /* synthetic */ class AnimationHandler$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ AnimationHandler f$0;

    public /* synthetic */ AnimationHandler$$ExternalSyntheticLambda0(AnimationHandler animationHandler) {
        this.f$0 = animationHandler;
    }

    public final void run() {
        AnimationCallbackDispatcher animationCallbackDispatcher = this.f$0.mCallbackDispatcher;
        animationCallbackDispatcher.this$0.mCurrentFrameTime = SystemClock.uptimeMillis();
        AnimationHandler animationHandler = animationCallbackDispatcher.this$0;
        long j = animationHandler.mCurrentFrameTime;
        long uptimeMillis = SystemClock.uptimeMillis();
        for (int i = 0; i < animationHandler.mAnimationCallbacks.size(); i++) {
            AnimationFrameCallback animationFrameCallback = (AnimationFrameCallback) animationHandler.mAnimationCallbacks.get(i);
            if (animationFrameCallback != null) {
                Long l = (Long) animationHandler.mDelayedCallbackStartTime.get(animationFrameCallback);
                if (l != null) {
                    if (l.longValue() < uptimeMillis) {
                        animationHandler.mDelayedCallbackStartTime.remove(animationFrameCallback);
                    }
                }
                animationFrameCallback.doAnimationFrame$ar$ds(j);
            }
        }
        if (animationHandler.mListDirty) {
            for (int size = animationHandler.mAnimationCallbacks.size() - 1; size >= 0; size--) {
                if (animationHandler.mAnimationCallbacks.get(size) == null) {
                    animationHandler.mAnimationCallbacks.remove(size);
                }
            }
            animationHandler.mListDirty = false;
        }
        if (animationCallbackDispatcher.this$0.mAnimationCallbacks.size() > 0) {
            AnimationHandler animationHandler2 = animationCallbackDispatcher.this$0;
            animationHandler2.mScheduler$ar$class_merging.postFrameCallback(animationHandler2.mRunnable);
        }
    }
}
