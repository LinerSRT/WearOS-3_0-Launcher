package androidx.dynamicanimation.animation;

/* compiled from: PG */
public final class SpringForce {
    private double mDampedFreq;
    double mDampingRatio = 0.5d;
    private double mFinalPosition = Double.MAX_VALUE;
    private double mGammaMinus;
    private double mGammaPlus;
    private boolean mInitialized = false;
    private final MassState mMassState = new MassState();
    double mNaturalFreq = Math.sqrt(1500.0d);
    public double mValueThreshold;
    public double mVelocityThreshold;

    public final float getFinalPosition() {
        return (float) this.mFinalPosition;
    }

    public final void setDampingRatio$ar$ds(float f) {
        if (f >= 0.0f) {
            this.mDampingRatio = (double) f;
            this.mInitialized = false;
            return;
        }
        throw new IllegalArgumentException("Damping ratio must be non-negative");
    }

    public final void setFinalPosition$ar$ds(float f) {
        this.mFinalPosition = (double) f;
    }

    public final void setStiffness$ar$ds(float f) {
        if (f > 0.0f) {
            this.mNaturalFreq = Math.sqrt((double) f);
            this.mInitialized = false;
            return;
        }
        throw new IllegalArgumentException("Spring stiffness constant must be positive.");
    }

    public SpringForce(float f) {
        this.mFinalPosition = (double) f;
    }

    final MassState updateValues(double d, double d2, long j) {
        double d3;
        double d4;
        double d5;
        if (!this.mInitialized) {
            if (r0.mFinalPosition != Double.MAX_VALUE) {
                d3 = r0.mDampingRatio;
                if (d3 > 1.0d) {
                    d4 = r0.mNaturalFreq;
                    r0.mGammaPlus = ((-d3) * d4) + (d4 * Math.sqrt((d3 * d3) - 4.0d));
                    d3 = r0.mDampingRatio;
                    d4 = r0.mNaturalFreq;
                    r0.mGammaMinus = ((-d3) * d4) - (d4 * Math.sqrt((d3 * d3) - 4.0d));
                } else if (d3 >= 0.0d && d3 < 1.0d) {
                    r0.mDampedFreq = r0.mNaturalFreq * Math.sqrt(1.0d - (d3 * d3));
                }
                r0.mInitialized = true;
            } else {
                throw new IllegalStateException("Error: Final position of the spring must be set before the animation starts");
            }
        }
        d3 = (double) j;
        Double.isNaN(d3);
        d3 /= 1000.0d;
        d4 = d - r0.mFinalPosition;
        double d6 = r0.mDampingRatio;
        double d7;
        double pow;
        double d8;
        if (d6 > 1.0d) {
            d5 = r0.mGammaMinus;
            d6 = ((d5 * d4) - d2) / (d5 - r0.mGammaPlus);
            d4 -= d6;
            d5 = (Math.pow(2.718281828459045d, d5 * d3) * d4) + (Math.pow(2.718281828459045d, r0.mGammaPlus * d3) * d6);
            d7 = r0.mGammaMinus;
            pow = Math.pow(2.718281828459045d, d7 * d3);
            d8 = r0.mGammaPlus;
            d4 = ((d4 * d7) * pow) + ((d6 * d8) * Math.pow(2.718281828459045d, d8 * d3));
        } else if (d6 == 1.0d) {
            d5 = r0.mNaturalFreq;
            d6 = d2 + (d5 * d4);
            d4 += d6 * d3;
            d5 = Math.pow(2.718281828459045d, (-d5) * d3) * d4;
            pow = -r0.mNaturalFreq;
            d4 = ((d4 * Math.pow(2.718281828459045d, (-r0.mNaturalFreq) * d3)) * pow) + (d6 * Math.pow(2.718281828459045d, pow * d3));
        } else {
            d8 = r0.mDampedFreq;
            d7 = r0.mNaturalFreq;
            double d9 = (1.0d / d8) * (((d6 * d7) * d4) + d2);
            d6 = Math.pow(2.718281828459045d, ((-d6) * d7) * d3) * ((Math.cos(r0.mDampedFreq * d3) * d4) + (Math.sin(r0.mDampedFreq * d3) * d9));
            d8 = r0.mNaturalFreq;
            d7 = r0.mDampingRatio;
            d2 = d9;
            d5 = Math.pow(2.718281828459045d, ((-d7) * d8) * d3);
            pow = r0.mDampedFreq;
            double sin = Math.sin(pow * d3);
            d = d5;
            d5 = r0.mDampedFreq;
            d4 = (((-d8) * d6) * d7) + (d * ((((-pow) * d4) * sin) + ((d2 * d5) * Math.cos(d5 * d3))));
            d5 = d6;
        }
        MassState massState = r0.mMassState;
        massState.mValue = (float) (d5 + r0.mFinalPosition);
        massState.mVelocity = (float) d4;
        return massState;
    }
}
