package androidx.lifecycle;

import androidx.lifecycle.Lifecycle.Event;

/* compiled from: PG */
class FullLifecycleObserverAdapter implements LifecycleEventObserver {
    private final FullLifecycleObserver mFullLifecycleObserver;
    private final LifecycleEventObserver mLifecycleEventObserver;

    public FullLifecycleObserverAdapter(FullLifecycleObserver fullLifecycleObserver, LifecycleEventObserver lifecycleEventObserver) {
        this.mFullLifecycleObserver = fullLifecycleObserver;
        this.mLifecycleEventObserver = lifecycleEventObserver;
    }

    public final void onStateChanged(LifecycleOwner lifecycleOwner, Event event) {
        switch (event.ordinal()) {
            case 0:
                this.mFullLifecycleObserver.onCreate$ar$ds$217ec4af_0();
                break;
            case 1:
                this.mFullLifecycleObserver.onStart$ar$ds();
                break;
            case 2:
                this.mFullLifecycleObserver.onResume$ar$ds();
                break;
            case 3:
                this.mFullLifecycleObserver.onPause$ar$ds();
                break;
            case 4:
                this.mFullLifecycleObserver.onStop$ar$ds();
                break;
            case 5:
                this.mFullLifecycleObserver.onDestroy$ar$ds();
                break;
            case 6:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
            default:
                break;
        }
        LifecycleEventObserver lifecycleEventObserver = this.mLifecycleEventObserver;
        if (lifecycleEventObserver != null) {
            lifecycleEventObserver.onStateChanged(lifecycleOwner, event);
        }
    }
}
