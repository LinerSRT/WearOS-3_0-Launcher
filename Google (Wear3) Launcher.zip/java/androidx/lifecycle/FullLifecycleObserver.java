package androidx.lifecycle;

/* compiled from: PG */
public interface FullLifecycleObserver extends LifecycleObserver {
    void onCreate$ar$ds$217ec4af_0();

    void onDestroy$ar$ds();

    void onPause$ar$ds();

    void onResume$ar$ds();

    void onStart$ar$ds();

    void onStop$ar$ds();
}
