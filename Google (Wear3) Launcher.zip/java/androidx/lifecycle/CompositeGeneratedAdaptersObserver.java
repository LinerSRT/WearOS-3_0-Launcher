package androidx.lifecycle;

import android.arch.lifecycle.GeneratedAdapter;
import androidx.lifecycle.Lifecycle.Event;
import java.util.HashMap;

/* compiled from: PG */
class CompositeGeneratedAdaptersObserver implements LifecycleEventObserver {
    private final GeneratedAdapter[] mGeneratedAdapters;

    public CompositeGeneratedAdaptersObserver(GeneratedAdapter[] generatedAdapterArr) {
        this.mGeneratedAdapters = generatedAdapterArr;
    }

    public final void onStateChanged(LifecycleOwner lifecycleOwner, Event event) {
        HashMap hashMap = new HashMap();
        for (GeneratedAdapter callMethods$ar$ds : this.mGeneratedAdapters) {
            callMethods$ar$ds.callMethods$ar$ds();
        }
        for (GeneratedAdapter callMethods$ar$ds2 : this.mGeneratedAdapters) {
            callMethods$ar$ds2.callMethods$ar$ds();
        }
    }
}
