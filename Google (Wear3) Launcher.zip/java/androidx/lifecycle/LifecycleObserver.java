package androidx.lifecycle;

/* compiled from: PG */
public interface LifecycleObserver {
}
