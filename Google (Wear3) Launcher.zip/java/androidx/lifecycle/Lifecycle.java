package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;

/* compiled from: PG */
public abstract class Lifecycle {

    /* compiled from: PG */
    public enum Event {
        ON_CREATE,
        ON_START,
        ON_RESUME,
        ON_PAUSE,
        ON_STOP,
        ON_DESTROY,
        ON_ANY;

        public static Event downFrom(State state) {
            State state2 = State.DESTROYED;
            switch (state.ordinal()) {
                case 2:
                    return ON_DESTROY;
                case 3:
                    return ON_STOP;
                case 4:
                    return ON_PAUSE;
                default:
                    return null;
            }
        }

        public static Event upFrom(State state) {
            State state2 = State.DESTROYED;
            switch (state.ordinal()) {
                case 1:
                    return ON_CREATE;
                case 2:
                    return ON_START;
                case 3:
                    return ON_RESUME;
                default:
                    return null;
            }
        }

        public final State getTargetState() {
            State state = State.DESTROYED;
            switch (ordinal()) {
                case 0:
                case 4:
                    return State.CREATED;
                case 1:
                case 3:
                    return State.STARTED;
                case 2:
                    return State.RESUMED;
                case 5:
                    return State.DESTROYED;
                default:
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(this);
                    stringBuilder.append(" has no target state");
                    throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
    }

    /* compiled from: PG */
    public enum State {
        DESTROYED,
        INITIALIZED,
        CREATED,
        STARTED,
        RESUMED;

        public final boolean isAtLeast(State state) {
            return compareTo(state) >= 0;
        }
    }

    public Lifecycle() {
        AtomicReference atomicReference = new AtomicReference();
    }

    public abstract void addObserver(LifecycleObserver lifecycleObserver);

    public abstract void removeObserver(LifecycleObserver lifecycleObserver);
}
