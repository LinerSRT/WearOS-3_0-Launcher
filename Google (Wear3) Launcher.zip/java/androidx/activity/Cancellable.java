package androidx.activity;

/* compiled from: PG */
public interface Cancellable {
    void cancel();
}
