package androidx.activity;

import android.os.Bundle;
import androidx.activity.contextaware.OnContextAvailableListener;
import androidx.activity.result.ActivityResultRegistry;
import java.util.ArrayList;
import java.util.Random;

/* compiled from: PG */
public final /* synthetic */ class ComponentActivity$$ExternalSyntheticLambda0 implements OnContextAvailableListener {
    public final /* synthetic */ ComponentActivity f$0;

    public /* synthetic */ ComponentActivity$$ExternalSyntheticLambda0(ComponentActivity componentActivity) {
        this.f$0 = componentActivity;
    }

    public final void onContextAvailable$ar$ds() {
        ComponentActivity componentActivity = this.f$0;
        Bundle consumeRestoredStateForKey = componentActivity.getSavedStateRegistry().consumeRestoredStateForKey("android:support:activity-result");
        if (consumeRestoredStateForKey != null) {
            ActivityResultRegistry activityResultRegistry = componentActivity.mActivityResultRegistry;
            ArrayList integerArrayList = consumeRestoredStateForKey.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList stringArrayList = consumeRestoredStateForKey.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList == null) {
                return;
            }
            if (integerArrayList != null) {
                activityResultRegistry.mLaunchedKeys = consumeRestoredStateForKey.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                activityResultRegistry.mRandom = (Random) consumeRestoredStateForKey.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
                activityResultRegistry.mPendingResults.putAll(consumeRestoredStateForKey.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
                for (int i = 0; i < stringArrayList.size(); i++) {
                    String str = (String) stringArrayList.get(i);
                    if (activityResultRegistry.mKeyToRc.containsKey(str)) {
                        Integer num = (Integer) activityResultRegistry.mKeyToRc.remove(str);
                        if (!activityResultRegistry.mPendingResults.containsKey(str)) {
                            activityResultRegistry.mRcToKey.remove(num);
                        }
                    }
                    activityResultRegistry.bindRcKey(((Integer) integerArrayList.get(i)).intValue(), (String) stringArrayList.get(i));
                }
            }
        }
    }
}
