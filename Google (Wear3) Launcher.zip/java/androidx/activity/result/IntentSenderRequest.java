package androidx.activity.result;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

/* compiled from: PG */
public final class IntentSenderRequest implements Parcelable {
    public static final Creator CREATOR = new PG();
    public final Intent mFillInIntent;
    public final int mFlagsMask;
    public final int mFlagsValues;
    public final IntentSender mIntentSender;

    /* renamed from: androidx.activity.result.IntentSenderRequest$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new IntentSenderRequest[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new IntentSenderRequest(parcel);
        }
    }

    public IntentSenderRequest(Parcel parcel) {
        this.mIntentSender = (IntentSender) parcel.readParcelable(IntentSender.class.getClassLoader());
        this.mFillInIntent = (Intent) parcel.readParcelable(Intent.class.getClassLoader());
        this.mFlagsMask = parcel.readInt();
        this.mFlagsValues = parcel.readInt();
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.mIntentSender, i);
        parcel.writeParcelable(this.mFillInIntent, i);
        parcel.writeInt(this.mFlagsMask);
        parcel.writeInt(this.mFlagsValues);
    }
}
