package androidx.activity.result.contract;

import android.content.Intent;
import androidx.activity.result.ActivityResult;

/* compiled from: PG */
public final class ActivityResultContracts$StartActivityForResult extends ActivityResultContract {
    public static final ActivityResult parseResult$ar$ds(int i, Intent intent) {
        return new ActivityResult(i, intent);
    }

    public final /* bridge */ /* synthetic */ Object parseResult(int i, Intent intent) {
        return parseResult$ar$ds(i, intent);
    }
}
