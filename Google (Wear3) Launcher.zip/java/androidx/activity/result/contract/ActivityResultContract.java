package androidx.activity.result.contract;

import android.content.Intent;

/* compiled from: PG */
public abstract class ActivityResultContract {
    public abstract Object parseResult(int i, Intent intent);
}
