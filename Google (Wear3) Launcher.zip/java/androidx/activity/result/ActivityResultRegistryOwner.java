package androidx.activity.result;

/* compiled from: PG */
public interface ActivityResultRegistryOwner {
}
