package androidx.activity.result;

/* compiled from: PG */
public abstract class ActivityResultLauncher {
    public abstract void launch$ar$ds(Object obj);

    public abstract void unregister();
}
