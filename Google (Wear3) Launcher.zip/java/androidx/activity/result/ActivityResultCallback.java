package androidx.activity.result;

/* compiled from: PG */
public interface ActivityResultCallback {
    void onActivityResult(Object obj);
}
