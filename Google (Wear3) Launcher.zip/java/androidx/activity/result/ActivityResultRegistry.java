package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts$StartActivityForResult;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.Lifecycle.Event;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/* compiled from: PG */
public abstract class ActivityResultRegistry {
    public final transient Map mKeyToCallback = new HashMap();
    public final Map mKeyToLifecycleContainers = new HashMap();
    public final Map mKeyToRc = new HashMap();
    public ArrayList mLaunchedKeys = new ArrayList();
    public final Map mParsedPendingResults = new HashMap();
    public final Bundle mPendingResults = new Bundle();
    public Random mRandom = new Random();
    public final Map mRcToKey = new HashMap();

    /* renamed from: androidx.activity.result.ActivityResultRegistry$1 */
    public class PG implements LifecycleEventObserver {
        final /* synthetic */ ActivityResultCallback val$callback;
        final /* synthetic */ ActivityResultContract val$contract;
        final /* synthetic */ String val$key;

        public PG(String str, ActivityResultCallback activityResultCallback, ActivityResultContract activityResultContract) {
            this.val$key = str;
            this.val$callback = activityResultCallback;
            this.val$contract = activityResultContract;
        }

        public final void onStateChanged(LifecycleOwner lifecycleOwner, Event event) {
            if (Event.ON_START.equals(event)) {
                ActivityResultRegistry.this.mKeyToCallback.put(this.val$key, new CallbackAndContract(this.val$callback, this.val$contract));
                if (ActivityResultRegistry.this.mParsedPendingResults.containsKey(this.val$key)) {
                    Object obj = ActivityResultRegistry.this.mParsedPendingResults.get(this.val$key);
                    ActivityResultRegistry.this.mParsedPendingResults.remove(this.val$key);
                    this.val$callback.onActivityResult(obj);
                }
                ActivityResult activityResult = (ActivityResult) ActivityResultRegistry.this.mPendingResults.getParcelable(this.val$key);
                if (activityResult != null) {
                    ActivityResultRegistry.this.mPendingResults.remove(this.val$key);
                    this.val$callback.onActivityResult(ActivityResultContracts$StartActivityForResult.parseResult$ar$ds(activityResult.mResultCode, activityResult.mData));
                }
            } else if (Event.ON_STOP.equals(event)) {
                ActivityResultRegistry.this.mKeyToCallback.remove(this.val$key);
            } else if (Event.ON_DESTROY.equals(event)) {
                ActivityResultRegistry.this.unregister(this.val$key);
            }
        }
    }

    /* renamed from: androidx.activity.result.ActivityResultRegistry$2 */
    public final class C01372 extends ActivityResultLauncher {
        final /* synthetic */ ActivityResultContract val$contract;
        final /* synthetic */ String val$key;

        public C01372(String str, ActivityResultContract activityResultContract) {
            this.val$key = str;
            this.val$contract = activityResultContract;
        }

        public final void launch$ar$ds(Object obj) {
            Integer num = (Integer) ActivityResultRegistry.this.mKeyToRc.get(this.val$key);
            if (num != null) {
                ActivityResultRegistry.this.mLaunchedKeys.add(this.val$key);
                ActivityResultRegistry.this.onLaunch$ar$ds$cab538ca_0(num.intValue(), obj);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Attempting to launch an unregistered ActivityResultLauncher with contract ");
            stringBuilder.append(this.val$contract);
            stringBuilder.append(" and input ");
            stringBuilder.append(obj);
            stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
            throw new IllegalStateException(stringBuilder.toString());
        }

        public final void unregister() {
            throw null;
        }
    }

    /* compiled from: PG */
    public final class CallbackAndContract {
        public final ActivityResultCallback mCallback;
        final ActivityResultContract mContract;

        public CallbackAndContract(ActivityResultCallback activityResultCallback, ActivityResultContract activityResultContract) {
            this.mCallback = activityResultCallback;
            this.mContract = activityResultContract;
        }
    }

    /* compiled from: PG */
    public final class LifecycleContainer {
        public final Lifecycle mLifecycle;
        public final ArrayList mObservers = new ArrayList();

        public LifecycleContainer(Lifecycle lifecycle) {
            this.mLifecycle = lifecycle;
        }
    }

    public final void bindRcKey(int i, String str) {
        Map map = this.mRcToKey;
        Integer valueOf = Integer.valueOf(i);
        map.put(valueOf, str);
        this.mKeyToRc.put(str, valueOf);
    }

    public final boolean dispatchResult(int i, int i2, Intent intent) {
        String str = (String) this.mRcToKey.get(Integer.valueOf(i));
        if (str == null) {
            return false;
        }
        this.mLaunchedKeys.remove(str);
        CallbackAndContract callbackAndContract = (CallbackAndContract) this.mKeyToCallback.get(str);
        if (callbackAndContract != null) {
            ActivityResultCallback activityResultCallback = callbackAndContract.mCallback;
            if (activityResultCallback != null) {
                activityResultCallback.onActivityResult(callbackAndContract.mContract.parseResult(i2, intent));
                return true;
            }
        }
        this.mParsedPendingResults.remove(str);
        this.mPendingResults.putParcelable(str, new ActivityResult(i2, intent));
        return true;
    }

    public abstract void onLaunch$ar$ds$cab538ca_0(int i, Object obj);

    public final ActivityResultLauncher register(final String str, ActivityResultContract activityResultContract, ActivityResultCallback activityResultCallback) {
        registerKey(str);
        this.mKeyToCallback.put(str, new CallbackAndContract(activityResultCallback, activityResultContract));
        if (this.mParsedPendingResults.containsKey(str)) {
            Object obj = this.mParsedPendingResults.get(str);
            this.mParsedPendingResults.remove(str);
            activityResultCallback.onActivityResult(obj);
        }
        ActivityResult activityResult = (ActivityResult) this.mPendingResults.getParcelable(str);
        if (activityResult != null) {
            this.mPendingResults.remove(str);
            activityResultCallback.onActivityResult(activityResultContract.parseResult(activityResult.mResultCode, activityResult.mData));
        }
        return new ActivityResultLauncher() {
            public final void launch$ar$ds(Object obj) {
                throw null;
            }

            public final void unregister() {
                ActivityResultRegistry.this.unregister(str);
            }
        };
    }

    public final void registerKey(String str) {
        if (((Integer) this.mKeyToRc.get(str)) == null) {
            int nextInt = this.mRandom.nextInt(2147418112) + 65536;
            while (this.mRcToKey.containsKey(Integer.valueOf(nextInt))) {
                nextInt = this.mRandom.nextInt(2147418112) + 65536;
            }
            bindRcKey(nextInt, str);
        }
    }

    final void unregister(String str) {
        if (!this.mLaunchedKeys.contains(str)) {
            Integer num = (Integer) this.mKeyToRc.remove(str);
            if (num != null) {
                this.mRcToKey.remove(num);
            }
        }
        this.mKeyToCallback.remove(str);
        String str2 = "ActivityResultRegistry";
        String str3 = ": ";
        String str4 = "Dropping pending result for request ";
        if (this.mParsedPendingResults.containsKey(str)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str4);
            stringBuilder.append(str);
            stringBuilder.append(str3);
            stringBuilder.append(this.mParsedPendingResults.get(str));
            Log.w(str2, stringBuilder.toString());
            this.mParsedPendingResults.remove(str);
        }
        if (this.mPendingResults.containsKey(str)) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str4);
            stringBuilder.append(str);
            stringBuilder.append(str3);
            stringBuilder.append(this.mPendingResults.getParcelable(str));
            Log.w(str2, stringBuilder.toString());
            this.mPendingResults.remove(str);
        }
        LifecycleContainer lifecycleContainer = (LifecycleContainer) this.mKeyToLifecycleContainers.get(str);
        if (lifecycleContainer != null) {
            List list = lifecycleContainer.mObservers;
            int size = list.size();
            for (int i = 0; i < size; i++) {
                lifecycleContainer.mLifecycle.removeObserver((LifecycleEventObserver) list.get(i));
            }
            lifecycleContainer.mObservers.clear();
            this.mKeyToLifecycleContainers.remove(str);
        }
    }
}
