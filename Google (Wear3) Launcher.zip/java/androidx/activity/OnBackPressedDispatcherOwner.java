package androidx.activity;

import androidx.lifecycle.LifecycleOwner;

/* compiled from: PG */
public interface OnBackPressedDispatcherOwner extends LifecycleOwner {
}
