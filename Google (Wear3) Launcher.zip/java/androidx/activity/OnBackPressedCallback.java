package androidx.activity;

import java.util.concurrent.CopyOnWriteArrayList;

/* compiled from: PG */
public abstract class OnBackPressedCallback {
    public final CopyOnWriteArrayList mCancellables = new CopyOnWriteArrayList();
    public boolean mEnabled = false;

    public final void addCancellable(Cancellable cancellable) {
        this.mCancellables.add(cancellable);
    }

    public abstract void handleOnBackPressed();

    final void removeCancellable(Cancellable cancellable) {
        this.mCancellables.remove(cancellable);
    }
}
