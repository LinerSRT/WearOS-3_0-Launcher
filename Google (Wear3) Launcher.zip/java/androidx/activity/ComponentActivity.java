package androidx.activity;

import android.app.Activity;
import android.arch.lifecycle.HasDefaultViewModelProviderFactory;
import android.arch.lifecycle.SavedStateViewModelFactory;
import android.arch.lifecycle.ViewModelProvider.Factory;
import android.arch.lifecycle.ViewModelStore;
import android.arch.lifecycle.ViewModelStoreOwner;
import android.arch.lifecycle.ViewTreeLifecycleOwner;
import android.arch.lifecycle.ViewTreeViewModelStoreOwner;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.support.p000v4.app.SupportActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import androidx.activity.contextaware.ContextAwareHelper;
import androidx.activity.contextaware.OnContextAvailableListener;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.ActivityResultRegistryOwner;
import androidx.activity.result.IntentSenderRequest;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.Lifecycle.Event;
import androidx.lifecycle.Lifecycle.State;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.ReportFragment;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.SavedStateRegistryController;
import androidx.savedstate.SavedStateRegistryOwner;
import androidx.savedstate.ViewTreeSavedStateRegistryOwner;
import androidx.tracing.TraceApi29Impl;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: PG */
public class ComponentActivity extends SupportActivity implements LifecycleOwner, ViewModelStoreOwner, HasDefaultViewModelProviderFactory, SavedStateRegistryOwner, OnBackPressedDispatcherOwner, ActivityResultRegistryOwner {
    public final ActivityResultRegistry mActivityResultRegistry;
    final ContextAwareHelper mContextAwareHelper = new ContextAwareHelper();
    private Factory mDefaultFactory;
    public final LifecycleRegistry mLifecycleRegistry;
    public final AtomicInteger mNextLocalRequestCode;
    public final OnBackPressedDispatcher mOnBackPressedDispatcher;
    final SavedStateRegistryController mSavedStateRegistryController;
    private ViewModelStore mViewModelStore;

    /* renamed from: androidx.activity.ComponentActivity$1 */
    final class PG implements Runnable {
        public final void run() {
            try {
                super.onBackPressed();
            } catch (IllegalStateException e) {
                if (!TextUtils.equals(e.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                    throw e;
                }
            }
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$2 */
    final class C01332 extends ActivityResultRegistry {
        public final void onLaunch$ar$ds$cab538ca_0(final int i, Object obj) {
            Bundle bundle;
            Activity activity = ComponentActivity.this;
            Intent intent = (Intent) obj;
            if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null) {
                intent.setExtrasClassLoader(activity.getClassLoader());
            }
            String str = "androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE";
            if (intent.hasExtra(str)) {
                Bundle bundleExtra = intent.getBundleExtra(str);
                intent.removeExtra(str);
                bundle = bundleExtra;
            } else {
                bundle = null;
            }
            if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
                String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                if (stringArrayExtra == null) {
                    stringArrayExtra = new String[0];
                }
                ActivityCompat.requestPermissions(activity, stringArrayExtra, i);
                return;
            }
            if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(intent.getAction())) {
                IntentSenderRequest intentSenderRequest = (IntentSenderRequest) intent.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
                try {
                    activity.startIntentSenderForResult(intentSenderRequest.mIntentSender, i, intentSenderRequest.mFillInIntent, intentSenderRequest.mFlagsMask, intentSenderRequest.mFlagsValues, 0, bundle);
                    return;
                } catch (final SendIntentException e) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        public final void run() {
                            C01332.this.dispatchResult(i, 0, new Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", e));
                        }
                    });
                    return;
                }
            }
            activity.startActivityForResult(intent, i, bundle);
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$3 */
    class C01343 implements LifecycleEventObserver {
        public final void onStateChanged(LifecycleOwner lifecycleOwner, Event event) {
            if (event == Event.ON_STOP) {
                View peekDecorView;
                Window window = ComponentActivity.this.getWindow();
                if (window != null) {
                    peekDecorView = window.peekDecorView();
                } else {
                    peekDecorView = null;
                }
                if (peekDecorView != null) {
                    peekDecorView.cancelPendingInputEvents();
                }
            }
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$4 */
    class C01354 implements LifecycleEventObserver {
        public final void onStateChanged(LifecycleOwner lifecycleOwner, Event event) {
            if (event == Event.ON_DESTROY) {
                ComponentActivity.this.mContextAwareHelper.mContext = null;
                if (!ComponentActivity.this.isChangingConfigurations()) {
                    ComponentActivity.this.getViewModelStore().clear();
                }
            }
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$5 */
    class C01365 implements LifecycleEventObserver {
        public final void onStateChanged(LifecycleOwner lifecycleOwner, Event event) {
            ComponentActivity.this.ensureViewModelStore();
            ComponentActivity.this.mLifecycleRegistry.removeObserver(this);
        }
    }

    /* compiled from: PG */
    final class NonConfigurationInstances {
        ViewModelStore viewModelStore;
    }

    public ComponentActivity() {
        Lifecycle lifecycleRegistry = new LifecycleRegistry(this);
        this.mLifecycleRegistry = lifecycleRegistry;
        this.mSavedStateRegistryController = SavedStateRegistryController.create(this);
        this.mOnBackPressedDispatcher = new OnBackPressedDispatcher(new PG());
        this.mNextLocalRequestCode = new AtomicInteger();
        this.mActivityResultRegistry = new C01332();
        lifecycleRegistry.addObserver(new C01343());
        lifecycleRegistry.addObserver(new C01354());
        lifecycleRegistry.addObserver(new C01365());
        getSavedStateRegistry().registerSavedStateProvider("android:support:activity-result", new ComponentActivity$$ExternalSyntheticLambda1());
        addOnContextAvailableListener(new ComponentActivity$$ExternalSyntheticLambda0());
    }

    private void initViewTreeOwners() {
        ViewTreeLifecycleOwner.set(getWindow().getDecorView(), this);
        ViewTreeViewModelStoreOwner.set(getWindow().getDecorView(), this);
        ViewTreeSavedStateRegistryOwner.set(getWindow().getDecorView(), this);
    }

    public void addContentView(View view, LayoutParams layoutParams) {
        initViewTreeOwners();
        super.addContentView(view, layoutParams);
    }

    final void ensureViewModelStore() {
        if (this.mViewModelStore == null) {
            NonConfigurationInstances nonConfigurationInstances = (NonConfigurationInstances) getLastNonConfigurationInstance();
            if (nonConfigurationInstances != null) {
                this.mViewModelStore = nonConfigurationInstances.viewModelStore;
            }
            if (this.mViewModelStore == null) {
                this.mViewModelStore = new ViewModelStore();
            }
        }
    }

    public Factory getDefaultViewModelProviderFactory() {
        if (getApplication() != null) {
            if (this.mDefaultFactory == null) {
                this.mDefaultFactory = new SavedStateViewModelFactory(getApplication(), this, getIntent() != null ? getIntent().getExtras() : null);
            }
            return this.mDefaultFactory;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public final Lifecycle getLifecycle() {
        return this.mLifecycleRegistry;
    }

    public final SavedStateRegistry getSavedStateRegistry() {
        return this.mSavedStateRegistryController.mRegistry;
    }

    public final ViewModelStore getViewModelStore() {
        if (getApplication() != null) {
            ensureViewModelStore();
            return this.mViewModelStore;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    @Deprecated
    protected void onActivityResult(int i, int i2, Intent intent) {
        if (!this.mActivityResultRegistry.dispatchResult(i, i2, intent)) {
            super.onActivityResult(i, i2, intent);
        }
    }

    public void onBackPressed() {
        this.mOnBackPressedDispatcher.onBackPressed();
    }

    protected void onCreate(Bundle bundle) {
        this.mSavedStateRegistryController.performRestore(bundle);
        ContextAwareHelper contextAwareHelper = this.mContextAwareHelper;
        contextAwareHelper.mContext = this;
        for (OnContextAvailableListener onContextAvailable$ar$ds : contextAwareHelper.mListeners) {
            onContextAvailable$ar$ds.onContextAvailable$ar$ds();
        }
        super.onCreate(bundle);
        ReportFragment.injectIfNeededIn(this);
    }

    @Deprecated
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (!this.mActivityResultRegistry.dispatchResult(i, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        }
    }

    public final Object onRetainNonConfigurationInstance() {
        NonConfigurationInstances nonConfigurationInstances;
        ViewModelStore viewModelStore = this.mViewModelStore;
        if (viewModelStore == null) {
            nonConfigurationInstances = (NonConfigurationInstances) getLastNonConfigurationInstance();
            if (nonConfigurationInstances != null) {
                viewModelStore = nonConfigurationInstances.viewModelStore;
            }
        }
        if (viewModelStore == null) {
            return null;
        }
        nonConfigurationInstances = new NonConfigurationInstances();
        nonConfigurationInstances.viewModelStore = viewModelStore;
        return nonConfigurationInstances;
    }

    protected void onSaveInstanceState(Bundle bundle) {
        LifecycleRegistry lifecycleRegistry = this.mLifecycleRegistry;
        if (lifecycleRegistry instanceof LifecycleRegistry) {
            lifecycleRegistry.setCurrentState(State.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.mSavedStateRegistryController.performSave(bundle);
    }

    public void setContentView(int i) {
        initViewTreeOwners();
        super.setContentView(i);
    }

    public final void addOnContextAvailableListener(OnContextAvailableListener onContextAvailableListener) {
        ContextAwareHelper contextAwareHelper = this.mContextAwareHelper;
        if (contextAwareHelper.mContext != null) {
            Context context = contextAwareHelper.mContext;
            onContextAvailableListener.onContextAvailable$ar$ds();
        }
        contextAwareHelper.mListeners.add(onContextAvailableListener);
    }

    public final void reportFullyDrawn() {
        try {
            if (TraceApi29Impl.isEnabled()) {
                Trace.beginSection("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
        } finally {
            Trace.endSection();
        }
    }

    public void setContentView(View view) {
        initViewTreeOwners();
        super.setContentView(view);
    }

    public void setContentView(View view, LayoutParams layoutParams) {
        initViewTreeOwners();
        super.setContentView(view, layoutParams);
    }
}
