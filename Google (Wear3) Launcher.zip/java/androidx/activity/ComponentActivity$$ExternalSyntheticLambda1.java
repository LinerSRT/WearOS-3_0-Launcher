package androidx.activity;

import android.os.Bundle;
import androidx.activity.result.ActivityResultRegistry;
import androidx.savedstate.SavedStateRegistry.SavedStateProvider;
import java.util.ArrayList;

/* compiled from: PG */
public final /* synthetic */ class ComponentActivity$$ExternalSyntheticLambda1 implements SavedStateProvider {
    public final /* synthetic */ ComponentActivity f$0;

    public /* synthetic */ ComponentActivity$$ExternalSyntheticLambda1(ComponentActivity componentActivity) {
        this.f$0 = componentActivity;
    }

    public final Bundle saveState() {
        ComponentActivity componentActivity = this.f$0;
        Bundle bundle = new Bundle();
        ActivityResultRegistry activityResultRegistry = componentActivity.mActivityResultRegistry;
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(activityResultRegistry.mKeyToRc.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(activityResultRegistry.mKeyToRc.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(activityResultRegistry.mLaunchedKeys));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) activityResultRegistry.mPendingResults.clone());
        bundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", activityResultRegistry.mRandom);
        return bundle;
    }
}
