package androidx.activity.contextaware;

import android.content.Context;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/* compiled from: PG */
public final class ContextAwareHelper {
    public volatile Context mContext;
    public final Set mListeners = new CopyOnWriteArraySet();
}
