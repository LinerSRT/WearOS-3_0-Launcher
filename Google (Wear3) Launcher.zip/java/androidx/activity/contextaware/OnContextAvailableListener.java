package androidx.activity.contextaware;

/* compiled from: PG */
public interface OnContextAvailableListener {
    void onContextAvailable$ar$ds();
}
