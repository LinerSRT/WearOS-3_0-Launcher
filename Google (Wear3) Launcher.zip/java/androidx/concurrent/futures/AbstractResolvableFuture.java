package androidx.concurrent.futures;

import com.google.common.util.concurrent.ListenableFuture;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

/* compiled from: PG */
public abstract class AbstractResolvableFuture implements ListenableFuture {
    public static final AtomicHelper ATOMIC_HELPER;
    static final boolean GENERATE_CANCELLATION_CAUSES;
    public static final Object NULL;
    private static final Logger log;
    volatile Listener listeners;
    volatile Object value;
    volatile Waiter waiters;

    /* compiled from: PG */
    public abstract class AtomicHelper {
        public abstract boolean casListeners(AbstractResolvableFuture abstractResolvableFuture, Listener listener, Listener listener2);

        public abstract boolean casValue(AbstractResolvableFuture abstractResolvableFuture, Object obj, Object obj2);

        public abstract boolean casWaiters(AbstractResolvableFuture abstractResolvableFuture, Waiter waiter, Waiter waiter2);

        public abstract void putNext(Waiter waiter, Waiter waiter2);

        public abstract void putThread(Waiter waiter, Thread thread);
    }

    /* compiled from: PG */
    final class Cancellation {
        static final Cancellation CAUSELESS_CANCELLED;
        static final Cancellation CAUSELESS_INTERRUPTED;
        final Throwable cause;
        final boolean wasInterrupted;

        static {
            if (AbstractResolvableFuture.GENERATE_CANCELLATION_CAUSES) {
                CAUSELESS_CANCELLED = null;
                CAUSELESS_INTERRUPTED = null;
                return;
            }
            CAUSELESS_CANCELLED = new Cancellation(false, null);
            CAUSELESS_INTERRUPTED = new Cancellation(true, null);
        }

        public Cancellation(boolean z, Throwable th) {
            this.wasInterrupted = z;
            this.cause = th;
        }
    }

    /* compiled from: PG */
    public final class Failure {
        static final Failure FALLBACK_INSTANCE = new Failure(new PG());
        final Throwable exception;

        /* renamed from: androidx.concurrent.futures.AbstractResolvableFuture$Failure$1 */
        class PG extends Throwable {
            public PG() {
                super("Failure occurred while trying to finish a future.");
            }

            public final synchronized Throwable fillInStackTrace() {
                return this;
            }
        }

        public Failure(Throwable th) {
            AbstractResolvableFuture.checkNotNull$ar$ds$ca384cd1_0(th);
            this.exception = th;
        }
    }

    /* compiled from: PG */
    final class Listener {
        static final Listener TOMBSTONE = new Listener(null, null);
        final Executor executor;
        Listener next;
        final Runnable task;

        public Listener(Runnable runnable, Executor executor) {
            this.task = runnable;
            this.executor = executor;
        }
    }

    /* compiled from: PG */
    final class SafeAtomicHelper extends AtomicHelper {
        final AtomicReferenceFieldUpdater listenersUpdater;
        final AtomicReferenceFieldUpdater valueUpdater;
        final AtomicReferenceFieldUpdater waiterNextUpdater;
        final AtomicReferenceFieldUpdater waiterThreadUpdater;
        final AtomicReferenceFieldUpdater waitersUpdater;

        public SafeAtomicHelper(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
            this.waiterThreadUpdater = atomicReferenceFieldUpdater;
            this.waiterNextUpdater = atomicReferenceFieldUpdater2;
            this.waitersUpdater = atomicReferenceFieldUpdater3;
            this.listenersUpdater = atomicReferenceFieldUpdater4;
            this.valueUpdater = atomicReferenceFieldUpdater5;
        }

        public final boolean casListeners(AbstractResolvableFuture abstractResolvableFuture, Listener listener, Listener listener2) {
            return this.listenersUpdater.compareAndSet(abstractResolvableFuture, listener, listener2);
        }

        public final boolean casValue(AbstractResolvableFuture abstractResolvableFuture, Object obj, Object obj2) {
            return this.valueUpdater.compareAndSet(abstractResolvableFuture, obj, obj2);
        }

        public final boolean casWaiters(AbstractResolvableFuture abstractResolvableFuture, Waiter waiter, Waiter waiter2) {
            return this.waitersUpdater.compareAndSet(abstractResolvableFuture, waiter, waiter2);
        }

        public final void putNext(Waiter waiter, Waiter waiter2) {
            this.waiterNextUpdater.lazySet(waiter, waiter2);
        }

        public final void putThread(Waiter waiter, Thread thread) {
            this.waiterThreadUpdater.lazySet(waiter, thread);
        }
    }

    /* compiled from: PG */
    final class SetFuture implements Runnable {
        final ListenableFuture future;
        final AbstractResolvableFuture owner;

        public final void run() {
            throw null;
        }
    }

    /* compiled from: PG */
    final class SynchronizedHelper extends AtomicHelper {
        public final boolean casListeners(AbstractResolvableFuture abstractResolvableFuture, Listener listener, Listener listener2) {
            synchronized (abstractResolvableFuture) {
                if (abstractResolvableFuture.listeners == listener) {
                    abstractResolvableFuture.listeners = listener2;
                    return true;
                }
                return false;
            }
        }

        public final boolean casValue(AbstractResolvableFuture abstractResolvableFuture, Object obj, Object obj2) {
            synchronized (abstractResolvableFuture) {
                if (abstractResolvableFuture.value == obj) {
                    abstractResolvableFuture.value = obj2;
                    return true;
                }
                return false;
            }
        }

        public final boolean casWaiters(AbstractResolvableFuture abstractResolvableFuture, Waiter waiter, Waiter waiter2) {
            synchronized (abstractResolvableFuture) {
                if (abstractResolvableFuture.waiters == waiter) {
                    abstractResolvableFuture.waiters = waiter2;
                    return true;
                }
                return false;
            }
        }

        public final void putNext(Waiter waiter, Waiter waiter2) {
            waiter.next = waiter2;
        }

        public final void putThread(Waiter waiter, Thread thread) {
            waiter.thread = thread;
        }
    }

    /* compiled from: PG */
    final class Waiter {
        static final Waiter TOMBSTONE = new Waiter(null);
        volatile Waiter next;
        volatile Thread thread;

        public Waiter() {
            AbstractResolvableFuture.ATOMIC_HELPER.putThread(this, Thread.currentThread());
        }

        public Waiter(byte[] bArr) {
        }

        final void setNext(Waiter waiter) {
            AbstractResolvableFuture.ATOMIC_HELPER.putNext(this, waiter);
        }
    }

    static {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Unknown predecessor block by arg (r1_5 androidx.concurrent.futures.AbstractResolvableFuture$AtomicHelper) in PHI: PHI: (r1_7 androidx.concurrent.futures.AbstractResolvableFuture$AtomicHelper) = (r1_5 androidx.concurrent.futures.AbstractResolvableFuture$AtomicHelper), (r1_6 androidx.concurrent.futures.AbstractResolvableFuture$AtomicHelper) binds: {(r1_5 androidx.concurrent.futures.AbstractResolvableFuture$AtomicHelper)=B:3:0x004c, (r1_6 androidx.concurrent.futures.AbstractResolvableFuture$AtomicHelper)=B:5:0x004f}
	at jadx.core.dex.instructions.PhiInsn.replaceArg(PhiInsn.java:79)
	at jadx.core.dex.visitors.ModVisitor.processInvoke(ModVisitor.java:222)
	at jadx.core.dex.visitors.ModVisitor.replaceStep(ModVisitor.java:83)
	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:68)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
*/
        /*
        r0 = androidx.concurrent.futures.AbstractResolvableFuture.class;
        r1 = "guava.concurrent.generate_cancellation_cause";
        r2 = "false";
        r1 = java.lang.System.getProperty(r1, r2);
        r1 = java.lang.Boolean.parseBoolean(r1);
        GENERATE_CANCELLATION_CAUSES = r1;
        r1 = r0.getName();
        r1 = java.util.logging.Logger.getLogger(r1);
        log = r1;
        r1 = new androidx.concurrent.futures.AbstractResolvableFuture$SafeAtomicHelper;	 Catch:{ all -> 0x004e }
        r2 = androidx.concurrent.futures.AbstractResolvableFuture.Waiter.class;	 Catch:{ all -> 0x004e }
        r3 = java.lang.Thread.class;	 Catch:{ all -> 0x004e }
        r4 = "thread";	 Catch:{ all -> 0x004e }
        r3 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r2, r3, r4);	 Catch:{ all -> 0x004e }
        r2 = androidx.concurrent.futures.AbstractResolvableFuture.Waiter.class;	 Catch:{ all -> 0x004e }
        r4 = androidx.concurrent.futures.AbstractResolvableFuture.Waiter.class;	 Catch:{ all -> 0x004e }
        r5 = "next";	 Catch:{ all -> 0x004e }
        r4 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r2, r4, r5);	 Catch:{ all -> 0x004e }
        r2 = androidx.concurrent.futures.AbstractResolvableFuture.Waiter.class;	 Catch:{ all -> 0x004e }
        r5 = "waiters";	 Catch:{ all -> 0x004e }
        r5 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r0, r2, r5);	 Catch:{ all -> 0x004e }
        r2 = androidx.concurrent.futures.AbstractResolvableFuture.Listener.class;	 Catch:{ all -> 0x004e }
        r6 = "listeners";	 Catch:{ all -> 0x004e }
        r6 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r0, r2, r6);	 Catch:{ all -> 0x004e }
        r2 = java.lang.Object.class;	 Catch:{ all -> 0x004e }
        r7 = "value";	 Catch:{ all -> 0x004e }
        r7 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r0, r2, r7);	 Catch:{ all -> 0x004e }
        r2 = r1;	 Catch:{ all -> 0x004e }
        r2.<init>(r3, r4, r5, r6, r7);	 Catch:{ all -> 0x004e }
        r0 = 0;
        goto L_0x0054;
    L_0x004e:
        r0 = move-exception;
        r1 = new androidx.concurrent.futures.AbstractResolvableFuture$SynchronizedHelper;
        r1.<init>();
    L_0x0054:
        ATOMIC_HELPER = r1;
        if (r0 == 0) goto L_0x0061;
    L_0x0058:
        r1 = log;
        r2 = java.util.logging.Level.SEVERE;
        r3 = "SafeAtomicHelper is broken!";
        r1.log(r2, r3, r0);
    L_0x0061:
        r0 = new java.lang.Object;
        r0.<init>();
        NULL = r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.concurrent.futures.AbstractResolvableFuture.<clinit>():void");
    }

    protected AbstractResolvableFuture() {
    }

    private final void addDoneString(StringBuilder stringBuilder) {
        String str = "]";
        try {
            Object uninterruptibly = getUninterruptibly(this);
            stringBuilder.append("SUCCESS, result=[");
            stringBuilder.append(userObjectToString(uninterruptibly));
            stringBuilder.append(str);
        } catch (ExecutionException e) {
            stringBuilder.append("FAILURE, cause=[");
            stringBuilder.append(e.getCause());
            stringBuilder.append(str);
        } catch (CancellationException e2) {
            stringBuilder.append("CANCELLED");
        } catch (RuntimeException e3) {
            stringBuilder.append("UNKNOWN, cause=[");
            stringBuilder.append(e3.getClass());
            stringBuilder.append(" thrown from get()]");
        }
    }

    static void checkNotNull$ar$ds$ca384cd1_0(Object obj) {
        if (obj == null) {
            throw null;
        }
    }

    private static void executeListener(Runnable runnable, Executor executor) {
        try {
            executor.execute(runnable);
        } catch (Throwable e) {
            Logger logger = log;
            Level level = Level.SEVERE;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("RuntimeException while executing runnable ");
            stringBuilder.append(runnable);
            stringBuilder.append(" with executor ");
            stringBuilder.append(executor);
            logger.log(level, stringBuilder.toString(), e);
        }
    }

    private static final Object getDoneValue$ar$ds(Object obj) {
        if (obj instanceof Cancellation) {
            Throwable th = ((Cancellation) obj).cause;
            CancellationException cancellationException = new CancellationException("Task was cancelled.");
            cancellationException.initCause(th);
            throw cancellationException;
        } else if (!(obj instanceof Failure)) {
            return obj == NULL ? null : obj;
        } else {
            throw new ExecutionException(((Failure) obj).exception);
        }
    }

    static Object getFutureValue(ListenableFuture listenableFuture) {
        if (listenableFuture instanceof AbstractResolvableFuture) {
            Object obj = ((AbstractResolvableFuture) listenableFuture).value;
            if (obj instanceof Cancellation) {
                Cancellation cancellation = (Cancellation) obj;
                if (cancellation.wasInterrupted) {
                    Throwable th = cancellation.cause;
                    obj = th != null ? new Cancellation(false, th) : Cancellation.CAUSELESS_CANCELLED;
                }
            }
            return obj;
        }
        boolean isCancelled = listenableFuture.isCancelled();
        if (((GENERATE_CANCELLATION_CAUSES ^ 1) & isCancelled) != 0) {
            return Cancellation.CAUSELESS_CANCELLED;
        }
        try {
            Object uninterruptibly = getUninterruptibly(listenableFuture);
            if (uninterruptibly == null) {
                uninterruptibly = NULL;
            }
            return uninterruptibly;
        } catch (ExecutionException e) {
            return new Failure(e.getCause());
        } catch (Throwable e2) {
            if (isCancelled) {
                return new Cancellation(false, e2);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("get() threw CancellationException, despite reporting isCancelled() == false: ");
            stringBuilder.append(listenableFuture);
            return new Failure(new IllegalArgumentException(stringBuilder.toString(), e2));
        } catch (Throwable th2) {
            return new Failure(th2);
        }
    }

    static Object getUninterruptibly(Future future) {
        Object obj = null;
        while (true) {
            try {
                future = future.get();
                break;
            } catch (InterruptedException e) {
                obj = 1;
            } catch (Throwable th) {
                if (obj != null) {
                    Thread.currentThread().interrupt();
                }
            }
        }
        if (obj != null) {
            Thread.currentThread().interrupt();
        }
        return future;
    }

    private final void removeWaiter(Waiter waiter) {
        waiter.thread = null;
        while (true) {
            waiter = this.waiters;
            if (waiter != Waiter.TOMBSTONE) {
                Waiter waiter2 = null;
                while (waiter != null) {
                    Waiter waiter3 = waiter.next;
                    if (waiter.thread != null) {
                        waiter2 = waiter;
                    } else if (waiter2 != null) {
                        waiter2.next = waiter3;
                        if (waiter2.thread == null) {
                        }
                    } else if (ATOMIC_HELPER.casWaiters(this, waiter, waiter3)) {
                    }
                    waiter = waiter3;
                }
                return;
            }
            return;
        }
    }

    private final String userObjectToString(Object obj) {
        return obj == this ? "this future" : String.valueOf(obj);
    }

    public final void addListener(Runnable runnable, Executor executor) {
        checkNotNull$ar$ds$ca384cd1_0(runnable);
        checkNotNull$ar$ds$ca384cd1_0(executor);
        Listener listener = this.listeners;
        if (listener != Listener.TOMBSTONE) {
            Listener listener2 = new Listener(runnable, executor);
            do {
                listener2.next = listener;
                if (!ATOMIC_HELPER.casListeners(this, listener, listener2)) {
                    listener = this.listeners;
                } else {
                    return;
                }
            } while (listener != Listener.TOMBSTONE);
        }
        executeListener(runnable, executor);
    }

    public final boolean cancel(boolean z) {
        int i;
        Object obj = this.value;
        if (obj == null) {
            i = 1;
        } else {
            i = 0;
        }
        if ((i | (obj instanceof SetFuture)) == 0) {
            return false;
        }
        ListenableFuture listenableFuture;
        Object cancellation = GENERATE_CANCELLATION_CAUSES ? new Cancellation(z, new CancellationException("Future.cancel() was called.")) : z ? Cancellation.CAUSELESS_INTERRUPTED : Cancellation.CAUSELESS_CANCELLED;
        boolean z2 = false;
        AbstractResolvableFuture abstractResolvableFuture = this;
        while (true) {
            if (ATOMIC_HELPER.casValue(abstractResolvableFuture, obj, cancellation)) {
                complete(abstractResolvableFuture);
                if (!(obj instanceof SetFuture)) {
                    break;
                }
                listenableFuture = ((SetFuture) obj).future;
                if (!(listenableFuture instanceof AbstractResolvableFuture)) {
                    break;
                }
                abstractResolvableFuture = (AbstractResolvableFuture) listenableFuture;
                obj = abstractResolvableFuture.value;
                if (((obj == null ? 1 : 0) | (obj instanceof SetFuture)) == 0) {
                    return true;
                }
                z2 = true;
                return true;
            }
            obj = abstractResolvableFuture.value;
            if (!(obj instanceof SetFuture)) {
                return z2;
            }
        }
        listenableFuture.cancel(z);
        return true;
    }

    public final Object get() {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        int i;
        Object obj = this.value;
        if (obj != null) {
            i = 1;
        } else {
            i = 0;
        }
        if ((i & ((obj instanceof SetFuture) ^ 1)) != 0) {
            return getDoneValue$ar$ds(obj);
        }
        Waiter waiter = this.waiters;
        if (waiter != Waiter.TOMBSTONE) {
            Waiter waiter2 = new Waiter();
            do {
                waiter2.setNext(waiter);
                if (ATOMIC_HELPER.casWaiters(this, waiter, waiter2)) {
                    int i2;
                    do {
                        LockSupport.park(this);
                        if (Thread.interrupted()) {
                            removeWaiter(waiter2);
                            throw new InterruptedException();
                        }
                        obj = this.value;
                        if (obj != null) {
                            i2 = 1;
                        } else {
                            i2 = 0;
                        }
                    } while ((i2 & ((obj instanceof SetFuture) ^ 1)) == 0);
                    return getDoneValue$ar$ds(obj);
                }
                waiter = this.waiters;
            } while (waiter != Waiter.TOMBSTONE);
        }
        return getDoneValue$ar$ds(this.value);
    }

    public final boolean isCancelled() {
        return this.value instanceof Cancellation;
    }

    public final boolean isDone() {
        Object obj = this.value;
        return ((obj instanceof SetFuture) ^ 1) & (obj != null ? 1 : 0);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        stringBuilder.append("[status=");
        String str = "]";
        if (isCancelled()) {
            stringBuilder.append("CANCELLED");
        } else if (isDone()) {
            addDoneString(stringBuilder);
        } else {
            String stringBuilder2;
            StringBuilder stringBuilder3;
            try {
                Object obj = this.value;
                if (obj instanceof SetFuture) {
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("setFuture=[");
                    stringBuilder3.append(userObjectToString(((SetFuture) obj).future));
                    stringBuilder3.append(str);
                    stringBuilder2 = stringBuilder3.toString();
                } else if (this instanceof ScheduledFuture) {
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append("remaining delay=[");
                    stringBuilder4.append(((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS));
                    stringBuilder4.append(" ms]");
                    stringBuilder2 = stringBuilder4.toString();
                } else {
                    stringBuilder2 = null;
                }
            } catch (RuntimeException e) {
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("Exception thrown from implementation: ");
                stringBuilder3.append(e.getClass());
                stringBuilder2 = stringBuilder3.toString();
            }
            if (stringBuilder2 != null && !stringBuilder2.isEmpty()) {
                stringBuilder.append("PENDING, info=[");
                stringBuilder.append(stringBuilder2);
                stringBuilder.append(str);
            } else if (isDone()) {
                addDoneString(stringBuilder);
            } else {
                stringBuilder.append("PENDING");
            }
        }
        stringBuilder.append(str);
        return stringBuilder.toString();
    }

    public static void complete(AbstractResolvableFuture abstractResolvableFuture) {
        Listener listener = null;
        while (true) {
            Waiter waiter = abstractResolvableFuture.waiters;
            if (ATOMIC_HELPER.casWaiters(abstractResolvableFuture, waiter, Waiter.TOMBSTONE)) {
                Listener listener2;
                Listener listener3;
                while (waiter != null) {
                    Thread thread = waiter.thread;
                    if (thread != null) {
                        waiter.thread = null;
                        LockSupport.unpark(thread);
                    }
                    waiter = waiter.next;
                }
                do {
                    listener2 = abstractResolvableFuture.listeners;
                } while (!ATOMIC_HELPER.casListeners(abstractResolvableFuture, listener2, Listener.TOMBSTONE));
                while (true) {
                    listener3 = listener;
                    listener = listener2;
                    if (listener == null) {
                        break;
                    }
                    listener2 = listener.next;
                    listener.next = listener3;
                }
                while (listener3 != null) {
                    listener = listener3.next;
                    Runnable runnable = listener3.task;
                    if (runnable instanceof SetFuture) {
                        SetFuture setFuture = (SetFuture) runnable;
                        abstractResolvableFuture = setFuture.owner;
                        if (abstractResolvableFuture.value == setFuture) {
                            if (ATOMIC_HELPER.casValue(abstractResolvableFuture, setFuture, getFutureValue(setFuture.future))) {
                            }
                        }
                    } else {
                        executeListener(runnable, listener3.executor);
                    }
                    listener3 = listener;
                }
                return;
            }
        }
    }

    public final Object get(long j, TimeUnit timeUnit) {
        AbstractResolvableFuture abstractResolvableFuture = this;
        long j2 = j;
        TimeUnit timeUnit2 = timeUnit;
        long toNanos = timeUnit2.toNanos(j2);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Object obj = abstractResolvableFuture.value;
        int i = 1;
        if (((obj != null ? 1 : 0) & ((obj instanceof SetFuture) ^ 1)) != 0) {
            return getDoneValue$ar$ds(obj);
        }
        StringBuilder stringBuilder;
        long nanoTime = toNanos > 0 ? System.nanoTime() + toNanos : 0;
        Object obj2;
        int i2;
        if (toNanos >= 1000) {
            Waiter waiter = abstractResolvableFuture.waiters;
            if (waiter != Waiter.TOMBSTONE) {
                Waiter waiter2 = new Waiter();
                do {
                    waiter2.setNext(waiter);
                    if (ATOMIC_HELPER.casWaiters(abstractResolvableFuture, waiter, waiter2)) {
                        while (true) {
                            LockSupport.parkNanos(abstractResolvableFuture, toNanos);
                            if (Thread.interrupted()) {
                                removeWaiter(waiter2);
                                throw new InterruptedException();
                            }
                            obj2 = abstractResolvableFuture.value;
                            if (obj2 != null) {
                                i2 = 1;
                            } else {
                                i2 = 0;
                            }
                            if ((i2 & ((obj2 instanceof SetFuture) ^ 1)) != 0) {
                                return getDoneValue$ar$ds(obj2);
                            }
                            toNanos = nanoTime - System.nanoTime();
                            if (toNanos < 1000) {
                                break;
                            }
                        }
                        removeWaiter(waiter2);
                    } else {
                        waiter = abstractResolvableFuture.waiters;
                    }
                } while (waiter != Waiter.TOMBSTONE);
            }
            return getDoneValue$ar$ds(abstractResolvableFuture.value);
        }
        while (toNanos > 0) {
            obj2 = abstractResolvableFuture.value;
            if (obj2 != null) {
                i2 = 1;
            } else {
                i2 = 0;
            }
            if ((i2 & ((obj2 instanceof SetFuture) ^ 1)) != 0) {
                return getDoneValue$ar$ds(obj2);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            toNanos = nanoTime - System.nanoTime();
        }
        String abstractResolvableFuture2 = toString();
        String toLowerCase = timeUnit.toString().toLowerCase(Locale.ROOT);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Waited ");
        stringBuilder2.append(j2);
        String str = " ";
        stringBuilder2.append(str);
        stringBuilder2.append(timeUnit.toString().toLowerCase(Locale.ROOT));
        String stringBuilder3 = stringBuilder2.toString();
        if (toNanos + 1000 < 0) {
            StringBuilder stringBuilder4;
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(stringBuilder3);
            stringBuilder2.append(" (plus ");
            stringBuilder3 = stringBuilder2.toString();
            toNanos = -toNanos;
            nanoTime = timeUnit2.convert(toNanos, TimeUnit.NANOSECONDS);
            toNanos -= timeUnit2.toNanos(nanoTime);
            if (nanoTime != 0) {
                if (toNanos <= 1000) {
                    i = 0;
                }
            }
            if (nanoTime > 0) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(stringBuilder3);
                stringBuilder.append(nanoTime);
                stringBuilder.append(str);
                stringBuilder.append(toLowerCase);
                stringBuilder3 = stringBuilder.toString();
                if (i != 0) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(stringBuilder3);
                    stringBuilder.append(",");
                    stringBuilder3 = stringBuilder.toString();
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append(stringBuilder3);
                stringBuilder.append(str);
                stringBuilder3 = stringBuilder.toString();
            }
            if (i != 0) {
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append(stringBuilder3);
                stringBuilder4.append(toNanos);
                stringBuilder4.append(" nanoseconds ");
                stringBuilder3 = stringBuilder4.toString();
            }
            stringBuilder4 = new StringBuilder();
            stringBuilder4.append(stringBuilder3);
            stringBuilder4.append("delay)");
            stringBuilder3 = stringBuilder4.toString();
        }
        if (isDone()) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(stringBuilder3);
            stringBuilder.append(" but future completed as timeout expired");
            throw new TimeoutException(stringBuilder.toString());
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append(stringBuilder3);
        stringBuilder.append(" for ");
        stringBuilder.append(abstractResolvableFuture2);
        throw new TimeoutException(stringBuilder.toString());
    }
}
