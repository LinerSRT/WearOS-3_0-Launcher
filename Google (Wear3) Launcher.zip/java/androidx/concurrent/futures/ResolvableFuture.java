package androidx.concurrent.futures;

/* compiled from: PG */
public final class ResolvableFuture extends AbstractResolvableFuture {
}
