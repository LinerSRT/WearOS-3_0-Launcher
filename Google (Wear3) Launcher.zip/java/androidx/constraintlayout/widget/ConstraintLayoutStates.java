package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.Log;
import android.util.Xml;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;

/* compiled from: PG */
public final class ConstraintLayoutStates {

    /* compiled from: PG */
    final class State {
        int mConstraintID = -1;
        ConstraintSet mConstraintSet;
        int mId;
        ArrayList mVariants = new ArrayList();

        public State(Context context, XmlPullParser xmlPullParser) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.State);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.mId = obtainStyledAttributes.getResourceId(0, this.mId);
                } else if (index == 1) {
                    this.mConstraintID = obtainStyledAttributes.getResourceId(1, this.mConstraintID);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.mConstraintID);
                    context.getResources().getResourceName(this.mConstraintID);
                    if ("layout".equals(resourceTypeName)) {
                        ConstraintSet constraintSet = new ConstraintSet();
                        this.mConstraintSet = constraintSet;
                        constraintSet.clone(context, this.mConstraintID);
                    }
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* compiled from: PG */
    final class Variant {
        int mConstraintID = -1;
        ConstraintSet mConstraintSet;
        float mMaxHeight = Float.NaN;
        float mMaxWidth = Float.NaN;
        float mMinHeight = Float.NaN;
        float mMinWidth = Float.NaN;

        public Variant(Context context, XmlPullParser xmlPullParser) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.Variant);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 0) {
                    this.mConstraintID = obtainStyledAttributes.getResourceId(0, this.mConstraintID);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.mConstraintID);
                    context.getResources().getResourceName(this.mConstraintID);
                    if ("layout".equals(resourceTypeName)) {
                        ConstraintSet constraintSet = new ConstraintSet();
                        this.mConstraintSet = constraintSet;
                        constraintSet.clone(context, this.mConstraintID);
                    }
                } else if (index == 1) {
                    this.mMaxHeight = obtainStyledAttributes.getDimension(1, this.mMaxHeight);
                } else if (index == 2) {
                    this.mMinHeight = obtainStyledAttributes.getDimension(2, this.mMinHeight);
                } else if (index == 3) {
                    this.mMaxWidth = obtainStyledAttributes.getDimension(3, this.mMaxWidth);
                } else if (index == 4) {
                    this.mMinWidth = obtainStyledAttributes.getDimension(4, this.mMinWidth);
                } else {
                    Log.v("ConstraintLayoutStates", "Unknown tag");
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void load$ar$objectUnboxing(android.content.Context r9, int r10, android.util.SparseArray r11, android.util.SparseArray r12) {
        /*
        r0 = "id";
        r1 = r9.getResources();
        r10 = r1.getXml(r10);
        r1 = r10.getEventType();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r2 = 0;
    L_0x000f:
        r3 = 1;
        if (r1 == r3) goto L_0x00e3;
    L_0x0012:
        switch(r1) {
            case 0: goto L_0x00da;
            case 1: goto L_0x0015;
            case 2: goto L_0x0017;
            default: goto L_0x0015;
        };	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
    L_0x0015:
        goto L_0x00dd;
    L_0x0017:
        r1 = r10.getName();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r4 = r1.hashCode();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r5 = 0;
        r6 = -1;
        switch(r4) {
            case -1349929691: goto L_0x004e;
            case 80204913: goto L_0x0044;
            case 1382829617: goto L_0x003a;
            case 1657696882: goto L_0x0030;
            case 1901439077: goto L_0x0025;
            default: goto L_0x0024;
        };
    L_0x0024:
        goto L_0x0058;
        r4 = "Variant";
        r1 = r1.equals(r4);
        if (r1 == 0) goto L_0x0024;
    L_0x002e:
        r1 = 3;
        goto L_0x0059;
    L_0x0030:
        r4 = "layoutDescription";
        r1 = r1.equals(r4);
        if (r1 == 0) goto L_0x0024;
    L_0x0038:
        r1 = 0;
        goto L_0x0059;
    L_0x003a:
        r4 = "StateSet";
        r1 = r1.equals(r4);
        if (r1 == 0) goto L_0x0024;
    L_0x0042:
        r1 = 1;
        goto L_0x0059;
    L_0x0044:
        r4 = "State";
        r1 = r1.equals(r4);
        if (r1 == 0) goto L_0x0024;
    L_0x004c:
        r1 = 2;
        goto L_0x0059;
    L_0x004e:
        r4 = "ConstraintSet";
        r1 = r1.equals(r4);
        if (r1 == 0) goto L_0x0024;
    L_0x0056:
        r1 = 4;
        goto L_0x0059;
    L_0x0058:
        r1 = -1;
    L_0x0059:
        switch(r1) {
            case 2: goto L_0x00ce;
            case 3: goto L_0x00c1;
            case 4: goto L_0x005e;
            default: goto L_0x005c;
        };
    L_0x005c:
        goto L_0x00dd;
    L_0x005e:
        r1 = new androidx.constraintlayout.widget.ConstraintSet;	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r1.<init>();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r4 = r10.getAttributeCount();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
    L_0x0067:
        if (r5 >= r4) goto L_0x00dd;
    L_0x0069:
        r7 = r10.getAttributeName(r5);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r8 = r10.getAttributeValue(r5);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        if (r7 == 0) goto L_0x00be;
    L_0x0073:
        if (r8 != 0) goto L_0x0076;
    L_0x0075:
        goto L_0x00be;
    L_0x0076:
        r7 = r0.equals(r7);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        if (r7 == 0) goto L_0x00be;
    L_0x007c:
        r4 = "/";
        r4 = r8.contains(r4);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        if (r4 == 0) goto L_0x009c;
    L_0x0084:
        r4 = 47;
        r4 = r8.indexOf(r4);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r4 = r4 + r3;
        r4 = r8.substring(r4);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r5 = r9.getResources();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r7 = r9.getPackageName();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r4 = r5.getIdentifier(r4, r0, r7);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        goto L_0x009d;
    L_0x009c:
        r4 = -1;
    L_0x009d:
        if (r4 != r6) goto L_0x00b6;
    L_0x009f:
        r4 = r8.length();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        if (r4 <= r3) goto L_0x00ae;
    L_0x00a5:
        r3 = r8.substring(r3);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r6 = java.lang.Integer.parseInt(r3);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        goto L_0x00b7;
    L_0x00ae:
        r3 = "ConstraintLayoutStates";
        r4 = "error in parsing id";
        android.util.Log.e(r3, r4);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        goto L_0x00b7;
    L_0x00b6:
        r6 = r4;
    L_0x00b7:
        r1.load(r9, r10);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r12.put(r6, r1);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        goto L_0x00dd;
    L_0x00be:
        r5 = r5 + 1;
        goto L_0x0067;
    L_0x00c1:
        r1 = new androidx.constraintlayout.widget.ConstraintLayoutStates$Variant;	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r1.<init>(r9, r10);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        if (r2 == 0) goto L_0x00dd;
    L_0x00c8:
        r3 = r2.mVariants;	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r3.add(r1);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        goto L_0x00dd;
    L_0x00ce:
        r1 = new androidx.constraintlayout.widget.ConstraintLayoutStates$State;	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r1.<init>(r9, r10);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r2 = r1.mId;	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r11.put(r2, r1);	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        r2 = r1;
        goto L_0x00dd;
    L_0x00da:
        r10.getName();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
    L_0x00dd:
        r1 = r10.next();	 Catch:{ XmlPullParserException -> 0x00e9, IOException -> 0x00e4 }
        goto L_0x000f;
    L_0x00e3:
        return;
    L_0x00e4:
        r9 = move-exception;
        r9.printStackTrace();
        return;
    L_0x00e9:
        r9 = move-exception;
        r9.printStackTrace();
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayoutStates.load$ar$objectUnboxing(android.content.Context, int, android.util.SparseArray, android.util.SparseArray):void");
    }
}
