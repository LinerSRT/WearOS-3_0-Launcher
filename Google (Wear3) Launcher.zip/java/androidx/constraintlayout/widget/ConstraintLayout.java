package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.support.p002v7.widget.LinearLayoutManager;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import androidx.constraintlayout.core.widgets.Barrier;
import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.Guideline;
import androidx.constraintlayout.core.widgets.HelperWidget;
import androidx.constraintlayout.core.widgets.Optimizer;
import androidx.constraintlayout.core.widgets.VirtualLayout;
import androidx.constraintlayout.core.widgets.WidgetContainer;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure.Measure;
import androidx.constraintlayout.core.widgets.analyzer.ChainRun;
import androidx.constraintlayout.core.widgets.analyzer.DependencyGraph;
import androidx.constraintlayout.core.widgets.analyzer.GuidelineReference;
import androidx.constraintlayout.core.widgets.analyzer.WidgetRun;
import com.google.android.clockwork.wcs.sdk.PG;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/* compiled from: PG */
public class ConstraintLayout extends ViewGroup {
    SparseArray mChildrenByIds = new SparseArray();
    public ArrayList mConstraintHelpers = new ArrayList(4);
    public ConstraintSet mConstraintSet = null;
    private int mConstraintSetId = -1;
    private HashMap mDesignIds = new HashMap();
    protected boolean mDirtyHierarchy = true;
    protected ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
    private int mMaxHeight = Integer.MAX_VALUE;
    private int mMaxWidth = Integer.MAX_VALUE;
    Measurer mMeasurer = new Measurer(this);
    public int mMinHeight = 0;
    private int mMinWidth = 0;
    public int mOptimizationLevel = 257;
    private SparseArray mTempMapIdToWidget = new SparseArray();

    /* compiled from: PG */
    public final class LayoutParams extends MarginLayoutParams {
        public int baselineMargin = 0;
        public int baselineToBaseline = -1;
        public int baselineToBottom = -1;
        public int baselineToTop = -1;
        public int bottomToBottom = -1;
        public int bottomToTop = -1;
        public float circleAngle = 0.0f;
        public int circleConstraint = -1;
        public int circleRadius = 0;
        public boolean constrainedHeight = false;
        public boolean constrainedWidth = false;
        public String constraintTag = null;
        public String dimensionRatio = null;
        public int editorAbsoluteX = -1;
        public int editorAbsoluteY = -1;
        public int endToEnd = -1;
        public int endToStart = -1;
        public int goneBaselineMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneBottomMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneEndMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneLeftMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneRightMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneStartMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneTopMargin = LinearLayoutManager.INVALID_OFFSET;
        public int guideBegin = -1;
        public int guideEnd = -1;
        public float guidePercent = -1.0f;
        public boolean helped = false;
        public float horizontalBias = 0.5f;
        public int horizontalChainStyle = 0;
        boolean horizontalDimensionFixed = true;
        public float horizontalWeight = -1.0f;
        boolean isGuideline = false;
        boolean isHelper = false;
        boolean isInPlaceholder = false;
        boolean isVirtualGroup = false;
        public int leftToLeft = -1;
        public int leftToRight = -1;
        public int matchConstraintDefaultHeight = 0;
        public int matchConstraintDefaultWidth = 0;
        public int matchConstraintMaxHeight = 0;
        public int matchConstraintMaxWidth = 0;
        public int matchConstraintMinHeight = 0;
        public int matchConstraintMinWidth = 0;
        public float matchConstraintPercentHeight = 1.0f;
        public float matchConstraintPercentWidth = 1.0f;
        boolean needsBaseline = false;
        public int orientation = -1;
        int resolveGoneLeftMargin = LinearLayoutManager.INVALID_OFFSET;
        int resolveGoneRightMargin = LinearLayoutManager.INVALID_OFFSET;
        int resolvedGuideBegin;
        int resolvedGuideEnd;
        float resolvedGuidePercent;
        float resolvedHorizontalBias = 0.5f;
        int resolvedLeftToLeft = -1;
        int resolvedLeftToRight = -1;
        int resolvedRightToLeft = -1;
        int resolvedRightToRight = -1;
        public int rightToLeft = -1;
        public int rightToRight = -1;
        public int startToEnd = -1;
        public int startToStart = -1;
        public int topToBottom = -1;
        public int topToTop = -1;
        public float verticalBias = 0.5f;
        public int verticalChainStyle = 0;
        boolean verticalDimensionFixed = true;
        public float verticalWeight = -1.0f;
        ConstraintWidget widget = new ConstraintWidget();
        public int wrapBehaviorInParent = 0;

        /* compiled from: PG */
        final class Table {
            public static final SparseIntArray map;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                map = sparseIntArray;
                int[] iArr = R$styleable.Constraint;
                sparseIntArray.append(97, 64);
                sparseIntArray.append(74, 65);
                sparseIntArray.append(83, 8);
                sparseIntArray.append(84, 9);
                sparseIntArray.append(86, 10);
                sparseIntArray.append(87, 11);
                sparseIntArray.append(93, 12);
                sparseIntArray.append(92, 13);
                sparseIntArray.append(64, 14);
                sparseIntArray.append(63, 15);
                sparseIntArray.append(59, 16);
                sparseIntArray.append(61, 52);
                sparseIntArray.append(60, 53);
                sparseIntArray.append(65, 2);
                sparseIntArray.append(67, 3);
                sparseIntArray.append(66, 4);
                sparseIntArray.append(102, 49);
                sparseIntArray.append(103, 50);
                sparseIntArray.append(71, 5);
                sparseIntArray.append(72, 6);
                sparseIntArray.append(73, 7);
                sparseIntArray.append(0, 1);
                sparseIntArray.append(88, 17);
                sparseIntArray.append(89, 18);
                sparseIntArray.append(70, 19);
                sparseIntArray.append(69, 20);
                sparseIntArray.append(107, 21);
                sparseIntArray.append(110, 22);
                sparseIntArray.append(108, 23);
                sparseIntArray.append(105, 24);
                sparseIntArray.append(109, 25);
                sparseIntArray.append(106, 26);
                sparseIntArray.append(104, 55);
                sparseIntArray.append(111, 54);
                sparseIntArray.append(79, 29);
                sparseIntArray.append(94, 30);
                sparseIntArray.append(68, 44);
                sparseIntArray.append(81, 45);
                sparseIntArray.append(96, 46);
                sparseIntArray.append(80, 47);
                sparseIntArray.append(95, 48);
                sparseIntArray.append(57, 27);
                sparseIntArray.append(56, 28);
                sparseIntArray.append(98, 31);
                sparseIntArray.append(75, 32);
                sparseIntArray.append(100, 33);
                sparseIntArray.append(99, 34);
                sparseIntArray.append(101, 35);
                sparseIntArray.append(77, 36);
                sparseIntArray.append(76, 37);
                sparseIntArray.append(78, 38);
                sparseIntArray.append(82, 39);
                sparseIntArray.append(91, 40);
                sparseIntArray.append(85, 41);
                sparseIntArray.append(62, 42);
                sparseIntArray.append(58, 43);
                sparseIntArray.append(90, 51);
                sparseIntArray.append(113, 66);
            }
        }

        public LayoutParams() {
            super(-2, -2);
        }

        public final void resolveLayoutDirection(int i) {
            int i2 = this.leftMargin;
            int i3 = this.rightMargin;
            super.resolveLayoutDirection(i);
            i = getLayoutDirection();
            this.resolvedRightToLeft = -1;
            this.resolvedRightToRight = -1;
            this.resolvedLeftToLeft = -1;
            this.resolvedLeftToRight = -1;
            this.resolveGoneLeftMargin = this.goneLeftMargin;
            this.resolveGoneRightMargin = this.goneRightMargin;
            float f = this.horizontalBias;
            this.resolvedHorizontalBias = f;
            int i4 = this.guideBegin;
            this.resolvedGuideBegin = i4;
            int i5 = this.guideEnd;
            this.resolvedGuideEnd = i5;
            float f2 = this.guidePercent;
            this.resolvedGuidePercent = f2;
            if (i == 1) {
                Object obj;
                i = this.startToEnd;
                if (i != -1) {
                    this.resolvedRightToLeft = i;
                    obj = 1;
                } else {
                    i = this.startToStart;
                    if (i != -1) {
                        this.resolvedRightToRight = i;
                        obj = 1;
                    } else {
                        obj = null;
                    }
                }
                int i6 = this.endToStart;
                if (i6 != -1) {
                    this.resolvedLeftToRight = i6;
                    obj = 1;
                }
                i6 = this.endToEnd;
                if (i6 != -1) {
                    this.resolvedLeftToLeft = i6;
                    obj = 1;
                }
                i6 = this.goneStartMargin;
                if (i6 != LinearLayoutManager.INVALID_OFFSET) {
                    this.resolveGoneRightMargin = i6;
                }
                i6 = this.goneEndMargin;
                if (i6 != LinearLayoutManager.INVALID_OFFSET) {
                    this.resolveGoneLeftMargin = i6;
                }
                if (obj != null) {
                    this.resolvedHorizontalBias = 1.0f - f;
                }
                if (this.isGuideline && this.orientation == 1) {
                    if (f2 != -1.0f) {
                        this.resolvedGuidePercent = 1.0f - f2;
                        this.resolvedGuideBegin = -1;
                        this.resolvedGuideEnd = -1;
                    } else {
                        if (i4 != -1) {
                            this.resolvedGuideEnd = i4;
                            this.resolvedGuideBegin = -1;
                        } else if (i5 != -1) {
                            this.resolvedGuideBegin = i5;
                            this.resolvedGuideEnd = -1;
                        }
                        this.resolvedGuidePercent = -1.0f;
                    }
                }
            } else {
                i = this.startToEnd;
                if (i != -1) {
                    this.resolvedLeftToRight = i;
                }
                i = this.startToStart;
                if (i != -1) {
                    this.resolvedLeftToLeft = i;
                }
                i = this.endToStart;
                if (i != -1) {
                    this.resolvedRightToLeft = i;
                }
                i = this.endToEnd;
                if (i != -1) {
                    this.resolvedRightToRight = i;
                }
                i = this.goneStartMargin;
                if (i != LinearLayoutManager.INVALID_OFFSET) {
                    this.resolveGoneLeftMargin = i;
                }
                i = this.goneEndMargin;
                if (i != LinearLayoutManager.INVALID_OFFSET) {
                    this.resolveGoneRightMargin = i;
                }
            }
            if (this.endToStart == -1 && this.endToEnd == -1 && this.startToStart == -1 && this.startToEnd == -1) {
                i = this.rightToLeft;
                if (i != -1) {
                    this.resolvedRightToLeft = i;
                    if (this.rightMargin <= 0 && i3 > 0) {
                        this.rightMargin = i3;
                    }
                } else {
                    i = this.rightToRight;
                    if (i != -1) {
                        this.resolvedRightToRight = i;
                        if (this.rightMargin <= 0 && i3 > 0) {
                            this.rightMargin = i3;
                        }
                    }
                }
                i = this.leftToLeft;
                if (i != -1) {
                    this.resolvedLeftToLeft = i;
                    if (this.leftMargin <= 0 && i2 > 0) {
                        this.leftMargin = i2;
                        return;
                    }
                }
                i = this.leftToRight;
                if (i != -1) {
                    this.resolvedLeftToRight = i;
                    if (this.leftMargin <= 0 && i2 > 0) {
                        this.leftMargin = i2;
                    }
                }
            }
        }

        public final void validate() {
            this.isGuideline = false;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            if (this.width == -2 && this.constrainedWidth) {
                this.horizontalDimensionFixed = false;
                if (this.matchConstraintDefaultWidth == 0) {
                    this.matchConstraintDefaultWidth = 1;
                }
            }
            if (this.height == -2 && this.constrainedHeight) {
                this.verticalDimensionFixed = false;
                if (this.matchConstraintDefaultHeight == 0) {
                    this.matchConstraintDefaultHeight = 1;
                }
            }
            if (this.width == 0 || this.width == -1) {
                this.horizontalDimensionFixed = false;
                if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
                    this.width = -2;
                    this.constrainedWidth = true;
                }
            }
            if (this.height == 0 || this.height == -1) {
                this.verticalDimensionFixed = false;
                if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
                    this.height = -2;
                    this.constrainedHeight = true;
                }
            }
            if (this.guidePercent == -1.0f && this.guideBegin == -1) {
                if (this.guideEnd == -1) {
                    return;
                }
            }
            this.isGuideline = true;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            if (!(this.widget instanceof Guideline)) {
                this.widget = new Guideline();
            }
            ((Guideline) this.widget).setOrientation(this.orientation);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                String str = "ConstraintLayout";
                int resourceId;
                switch (Table.map.get(index)) {
                    case 1:
                        this.orientation = obtainStyledAttributes.getInt(index, this.orientation);
                        break;
                    case 2:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.circleConstraint);
                        this.circleConstraint = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.circleConstraint = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 3:
                        this.circleRadius = obtainStyledAttributes.getDimensionPixelSize(index, this.circleRadius);
                        break;
                    case 4:
                        float f = obtainStyledAttributes.getFloat(index, this.circleAngle) % 360.0f;
                        this.circleAngle = f;
                        if (f >= 0.0f) {
                            break;
                        }
                        this.circleAngle = (360.0f - f) % 360.0f;
                        break;
                    case 5:
                        this.guideBegin = obtainStyledAttributes.getDimensionPixelOffset(index, this.guideBegin);
                        break;
                    case 6:
                        this.guideEnd = obtainStyledAttributes.getDimensionPixelOffset(index, this.guideEnd);
                        break;
                    case 7:
                        this.guidePercent = obtainStyledAttributes.getFloat(index, this.guidePercent);
                        break;
                    case 8:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.leftToLeft);
                        this.leftToLeft = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.leftToLeft = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 9:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.leftToRight);
                        this.leftToRight = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.leftToRight = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 10:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.rightToLeft);
                        this.rightToLeft = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.rightToLeft = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 11:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.rightToRight);
                        this.rightToRight = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.rightToRight = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 12:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.topToTop);
                        this.topToTop = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.topToTop = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 13:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.topToBottom);
                        this.topToBottom = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.topToBottom = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 14:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.bottomToTop);
                        this.bottomToTop = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.bottomToTop = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 15:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.bottomToBottom);
                        this.bottomToBottom = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.bottomToBottom = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 16:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.baselineToBaseline);
                        this.baselineToBaseline = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.baselineToBaseline = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 17:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.startToEnd);
                        this.startToEnd = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.startToEnd = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 18:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.startToStart);
                        this.startToStart = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.startToStart = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 19:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.endToStart);
                        this.endToStart = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.endToStart = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case PG.styleable.CircledImageView_image_circle_percentage /*20*/:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.endToEnd);
                        this.endToEnd = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.endToEnd = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 21:
                        this.goneLeftMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneLeftMargin);
                        break;
                    case 22:
                        this.goneTopMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneTopMargin);
                        break;
                    case 23:
                        this.goneRightMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneRightMargin);
                        break;
                    case 24:
                        this.goneBottomMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneBottomMargin);
                        break;
                    case 25:
                        this.goneStartMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneStartMargin);
                        break;
                    case 26:
                        this.goneEndMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneEndMargin);
                        break;
                    case PG.styleable.CircledImageView_shadow_width /*27*/:
                        this.constrainedWidth = obtainStyledAttributes.getBoolean(index, this.constrainedWidth);
                        break;
                    case PG.styleable.CircledImageView_square_dimen /*28*/:
                        this.constrainedHeight = obtainStyledAttributes.getBoolean(index, this.constrainedHeight);
                        break;
                    case 29:
                        this.horizontalBias = obtainStyledAttributes.getFloat(index, this.horizontalBias);
                        break;
                    case 30:
                        this.verticalBias = obtainStyledAttributes.getFloat(index, this.verticalBias);
                        break;
                    case 31:
                        index = obtainStyledAttributes.getInt(index, 0);
                        this.matchConstraintDefaultWidth = index;
                        if (index != 1) {
                            break;
                        }
                        Log.e(str, "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        break;
                    case 32:
                        index = obtainStyledAttributes.getInt(index, 0);
                        this.matchConstraintDefaultHeight = index;
                        if (index != 1) {
                            break;
                        }
                        Log.e(str, "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        break;
                    case 33:
                        try {
                            this.matchConstraintMinWidth = obtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMinWidth);
                            break;
                        } catch (Exception e) {
                            if (obtainStyledAttributes.getInt(index, this.matchConstraintMinWidth) != -2) {
                                break;
                            }
                            this.matchConstraintMinWidth = -2;
                            break;
                        }
                    case 34:
                        try {
                            this.matchConstraintMaxWidth = obtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMaxWidth);
                            break;
                        } catch (Exception e2) {
                            if (obtainStyledAttributes.getInt(index, this.matchConstraintMaxWidth) != -2) {
                                break;
                            }
                            this.matchConstraintMaxWidth = -2;
                            break;
                        }
                    case 35:
                        this.matchConstraintPercentWidth = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.matchConstraintPercentWidth));
                        this.matchConstraintDefaultWidth = 2;
                        break;
                    case 36:
                        try {
                            this.matchConstraintMinHeight = obtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMinHeight);
                            break;
                        } catch (Exception e3) {
                            if (obtainStyledAttributes.getInt(index, this.matchConstraintMinHeight) != -2) {
                                break;
                            }
                            this.matchConstraintMinHeight = -2;
                            break;
                        }
                    case 37:
                        try {
                            this.matchConstraintMaxHeight = obtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMaxHeight);
                            break;
                        } catch (Exception e4) {
                            if (obtainStyledAttributes.getInt(index, this.matchConstraintMaxHeight) != -2) {
                                break;
                            }
                            this.matchConstraintMaxHeight = -2;
                            break;
                        }
                    case 38:
                        this.matchConstraintPercentHeight = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.matchConstraintPercentHeight));
                        this.matchConstraintDefaultHeight = 2;
                        break;
                    case 44:
                        ConstraintSet.parseDimensionRatioString(this, obtainStyledAttributes.getString(index));
                        break;
                    case 45:
                        this.horizontalWeight = obtainStyledAttributes.getFloat(index, this.horizontalWeight);
                        break;
                    case 46:
                        this.verticalWeight = obtainStyledAttributes.getFloat(index, this.verticalWeight);
                        break;
                    case 47:
                        this.horizontalChainStyle = obtainStyledAttributes.getInt(index, 0);
                        break;
                    case 48:
                        this.verticalChainStyle = obtainStyledAttributes.getInt(index, 0);
                        break;
                    case 49:
                        this.editorAbsoluteX = obtainStyledAttributes.getDimensionPixelOffset(index, this.editorAbsoluteX);
                        break;
                    case 50:
                        this.editorAbsoluteY = obtainStyledAttributes.getDimensionPixelOffset(index, this.editorAbsoluteY);
                        break;
                    case 51:
                        this.constraintTag = obtainStyledAttributes.getString(index);
                        break;
                    case 52:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.baselineToTop);
                        this.baselineToTop = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.baselineToTop = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 53:
                        resourceId = obtainStyledAttributes.getResourceId(index, this.baselineToBottom);
                        this.baselineToBottom = resourceId;
                        if (resourceId != -1) {
                            break;
                        }
                        this.baselineToBottom = obtainStyledAttributes.getInt(index, -1);
                        break;
                    case 54:
                        this.baselineMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.baselineMargin);
                        break;
                    case 55:
                        this.goneBaselineMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneBaselineMargin);
                        break;
                    case 64:
                        ConstraintSet.parseDimensionConstraints(this, obtainStyledAttributes, index, 0);
                        break;
                    case 65:
                        ConstraintSet.parseDimensionConstraints(this, obtainStyledAttributes, index, 1);
                        break;
                    case 66:
                        this.wrapBehaviorInParent = obtainStyledAttributes.getInt(index, this.wrapBehaviorInParent);
                        break;
                    default:
                        break;
                }
            }
            obtainStyledAttributes.recycle();
            validate();
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    /* compiled from: PG */
    public final class Measurer {
        public final ConstraintLayout layout;
        int layoutHeightSpec;
        int layoutWidthSpec;
        int paddingBottom;
        int paddingHeight;
        int paddingTop;
        int paddingWidth;

        public Measurer(ConstraintLayout constraintLayout) {
            this.layout = constraintLayout;
        }

        private static final boolean isSimilarSpec$ar$ds(int i, int i2, int i3) {
            if (i == i2) {
                return true;
            }
            int mode = MeasureSpec.getMode(i);
            MeasureSpec.getSize(i);
            return MeasureSpec.getMode(i2) == 1073741824 && ((mode == LinearLayoutManager.INVALID_OFFSET || mode == 0) && i3 == MeasureSpec.getSize(i2));
        }

        public final void measure(ConstraintWidget constraintWidget, Measure measure) {
            Measurer measurer = this;
            ConstraintWidget constraintWidget2 = constraintWidget;
            Measure measure2 = measure;
            if (constraintWidget2 != null) {
                if (constraintWidget2.mVisibility == 8) {
                    measure2.measuredWidth = 0;
                    measure2.measuredHeight = 0;
                    measure2.measuredBaseline = 0;
                } else if (constraintWidget2.mParent != null) {
                    int i = measure2.horizontalBehavior$ar$edu;
                    int i2 = measure2.verticalBehavior$ar$edu;
                    int i3 = measure2.horizontalDimension;
                    int i4 = measure2.verticalDimension;
                    int i5 = measurer.paddingTop + measurer.paddingBottom;
                    int i6 = measurer.paddingWidth;
                    Object obj = constraintWidget2.mCompanionWidget;
                    int i7 = i - 1;
                    if (i != 0) {
                        switch (i7) {
                            case 0:
                                i3 = MeasureSpec.makeMeasureSpec(i3, 1073741824);
                                break;
                            case 1:
                                i3 = ViewGroup.getChildMeasureSpec(measurer.layoutWidthSpec, i6, -2);
                                break;
                            case 2:
                                i3 = ViewGroup.getChildMeasureSpec(measurer.layoutWidthSpec, i6, -2);
                                i6 = constraintWidget2.mMatchConstraintDefaultWidth;
                                i7 = measure2.measureStrategy;
                                if (i7 == 1 || i7 == 2) {
                                    i7 = ((View) obj).getMeasuredHeight();
                                    int height = constraintWidget.getHeight();
                                    if (measure2.measureStrategy == 2 || i6 != 1 || i7 == height || (obj instanceof Placeholder) || constraintWidget.isResolvedHorizontally()) {
                                        i3 = MeasureSpec.makeMeasureSpec(constraintWidget.getWidth(), 1073741824);
                                        break;
                                    }
                                }
                            case 3:
                                i3 = measurer.layoutWidthSpec;
                                ConstraintAnchor constraintAnchor = constraintWidget2.mLeft;
                                if (constraintAnchor != null) {
                                    i7 = constraintAnchor.mMargin;
                                } else {
                                    i7 = 0;
                                }
                                ConstraintAnchor constraintAnchor2 = constraintWidget2.mRight;
                                if (constraintAnchor2 != null) {
                                    i7 += constraintAnchor2.mMargin;
                                }
                                i3 = ViewGroup.getChildMeasureSpec(i3, i6 + i7, -1);
                                break;
                            default:
                                i3 = 0;
                                break;
                        }
                        int i8 = i2 - 1;
                        if (i2 != 0) {
                            switch (i8) {
                                case 0:
                                    i8 = MeasureSpec.makeMeasureSpec(i4, 1073741824);
                                    break;
                                case 1:
                                    i8 = ViewGroup.getChildMeasureSpec(measurer.layoutHeightSpec, i5, -2);
                                    break;
                                case 2:
                                    i8 = ViewGroup.getChildMeasureSpec(measurer.layoutHeightSpec, i5, -2);
                                    i4 = constraintWidget2.mMatchConstraintDefaultHeight;
                                    i5 = measure2.measureStrategy;
                                    if (i5 == 1 || i5 == 2) {
                                        i5 = ((View) obj).getMeasuredWidth();
                                        i6 = constraintWidget.getWidth();
                                        if (measure2.measureStrategy == 2 || i4 != 1 || i5 == i6 || (obj instanceof Placeholder) || constraintWidget.isResolvedVertically()) {
                                            i8 = MeasureSpec.makeMeasureSpec(constraintWidget.getHeight(), 1073741824);
                                            break;
                                        }
                                    }
                                case 3:
                                    i8 = measurer.layoutHeightSpec;
                                    if (constraintWidget2.mLeft != null) {
                                        i4 = constraintWidget2.mTop.mMargin;
                                    } else {
                                        i4 = 0;
                                    }
                                    if (constraintWidget2.mRight != null) {
                                        i4 += constraintWidget2.mBottom.mMargin;
                                    }
                                    i8 = ViewGroup.getChildMeasureSpec(i8, i5 + i4, -1);
                                    break;
                                default:
                                    i8 = 0;
                                    break;
                            }
                            ConstraintWidget constraintWidget3 = constraintWidget2.mParent;
                            if (constraintWidget3 != null && Optimizer.enabled(ConstraintLayout.this.mOptimizationLevel, 256)) {
                                View view = (View) obj;
                                if (view.getMeasuredWidth() == constraintWidget.getWidth() && view.getMeasuredWidth() < constraintWidget3.getWidth() && view.getMeasuredHeight() == constraintWidget.getHeight() && view.getMeasuredHeight() < constraintWidget3.getHeight() && view.getBaseline() == constraintWidget2.mBaselineDistance && !constraintWidget.isMeasureRequested() && isSimilarSpec$ar$ds(constraintWidget2.mLastHorizontalMeasureSpec, i3, constraintWidget.getWidth())) {
                                    if (isSimilarSpec$ar$ds(constraintWidget2.mLastVerticalMeasureSpec, i8, constraintWidget.getHeight())) {
                                        measure2.measuredWidth = constraintWidget.getWidth();
                                        measure2.measuredHeight = constraintWidget.getHeight();
                                        measure2.measuredBaseline = constraintWidget2.mBaselineDistance;
                                        return;
                                    }
                                }
                            }
                            Object obj2 = i2 != 4 ? i2 == 1 ? 1 : null : 1;
                            Object obj3 = i != 4 ? i == 1 ? 1 : null : 1;
                            Object obj4 = (i != 3 || constraintWidget2.mDimensionRatio <= 0.0f) ? null : 1;
                            Object obj5 = (i2 != 3 || constraintWidget2.mDimensionRatio <= 0.0f) ? null : 1;
                            if (obj != null) {
                                int i9;
                                int i10;
                                int i11;
                                boolean z;
                                boolean z2;
                                View view2 = (View) obj;
                                LayoutParams layoutParams = (LayoutParams) view2.getLayoutParams();
                                int i12 = measure2.measureStrategy;
                                if (i12 != 1 && i12 != 2 && i == 3 && constraintWidget2.mMatchConstraintDefaultWidth == 0 && i2 == 3) {
                                    if (constraintWidget2.mMatchConstraintDefaultHeight == 0) {
                                        i9 = 0;
                                        i10 = 0;
                                        i12 = 0;
                                        if (i9 == -1) {
                                            i11 = 0;
                                        } else {
                                            i11 = 1;
                                        }
                                        z = i10 == measure2.horizontalDimension ? i12 != measure2.verticalDimension : true;
                                        measure2.measuredNeedsSolverPass = z;
                                        z2 = i11 | layoutParams.needsBaseline;
                                        if (z2) {
                                            if (i9 != -1) {
                                                i8 = -1;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            } else if (constraintWidget2.mBaselineDistance != i9) {
                                                measure2.measuredNeedsSolverPass = true;
                                                i8 = i9;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            }
                                        }
                                        i8 = i9;
                                        measure2.measuredWidth = i10;
                                        measure2.measuredHeight = i12;
                                        measure2.measuredHasBaseline = z2;
                                        measure2.measuredBaseline = i8;
                                        return;
                                    }
                                }
                                if (obj instanceof VirtualLayout) {
                                    if (constraintWidget2 instanceof VirtualLayout) {
                                        VirtualLayout virtualLayout = (VirtualLayout) constraintWidget2;
                                        VirtualLayout virtualLayout2 = (VirtualLayout) obj;
                                        throw null;
                                    }
                                }
                                view2.measure(i3, i8);
                                constraintWidget2.setLastMeasureSpec(i3, i8);
                                i = view2.getMeasuredWidth();
                                i2 = view2.getMeasuredHeight();
                                i9 = view2.getBaseline();
                                i10 = constraintWidget2.mMatchConstraintMinWidth;
                                if (i10 > 0) {
                                    i10 = Math.max(i10, i);
                                } else {
                                    i10 = i;
                                }
                                i12 = constraintWidget2.mMatchConstraintMaxWidth;
                                if (i12 > 0) {
                                    i10 = Math.min(i12, i10);
                                }
                                i12 = constraintWidget2.mMatchConstraintMinHeight;
                                if (i12 > 0) {
                                    i12 = Math.max(i12, i2);
                                } else {
                                    i12 = i2;
                                }
                                int i13 = i8;
                                i8 = constraintWidget2.mMatchConstraintMaxHeight;
                                if (i8 > 0) {
                                    i12 = Math.min(i8, i12);
                                }
                                if (!Optimizer.enabled(ConstraintLayout.this.mOptimizationLevel, 1)) {
                                    if (obj4 != null && obj2 != null) {
                                        i10 = (int) ((((float) i12) * constraintWidget2.mDimensionRatio) + 0.5f);
                                        if (i == i10) {
                                            if (i2 != i12) {
                                                if (i9 == -1) {
                                                    i11 = 1;
                                                } else {
                                                    i11 = 0;
                                                }
                                                if (i10 == measure2.horizontalDimension) {
                                                }
                                                measure2.measuredNeedsSolverPass = z;
                                                z2 = i11 | layoutParams.needsBaseline;
                                                if (z2) {
                                                    if (i9 != -1) {
                                                        i8 = -1;
                                                        measure2.measuredWidth = i10;
                                                        measure2.measuredHeight = i12;
                                                        measure2.measuredHasBaseline = z2;
                                                        measure2.measuredBaseline = i8;
                                                        return;
                                                    } else if (constraintWidget2.mBaselineDistance != i9) {
                                                        measure2.measuredNeedsSolverPass = true;
                                                        i8 = i9;
                                                        measure2.measuredWidth = i10;
                                                        measure2.measuredHeight = i12;
                                                        measure2.measuredHasBaseline = z2;
                                                        measure2.measuredBaseline = i8;
                                                        return;
                                                    }
                                                }
                                                i8 = i9;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            }
                                        }
                                        if (i != i10) {
                                            i11 = 1073741824;
                                        } else {
                                            i11 = 1073741824;
                                            i3 = MeasureSpec.makeMeasureSpec(i10, 1073741824);
                                        }
                                        if (i2 != i12) {
                                            i8 = i13;
                                        } else {
                                            i8 = MeasureSpec.makeMeasureSpec(i12, i11);
                                        }
                                        view2.measure(i3, i8);
                                        constraintWidget2.setLastMeasureSpec(i3, i8);
                                        i10 = view2.getMeasuredWidth();
                                        i12 = view2.getMeasuredHeight();
                                        i9 = view2.getBaseline();
                                        if (i9 == -1) {
                                            i11 = 0;
                                        } else {
                                            i11 = 1;
                                        }
                                        if (i10 == measure2.horizontalDimension) {
                                            if (i12 != measure2.verticalDimension) {
                                            }
                                        }
                                        measure2.measuredNeedsSolverPass = z;
                                        z2 = i11 | layoutParams.needsBaseline;
                                        if (z2) {
                                            if (i9 != -1) {
                                                i8 = -1;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            } else if (constraintWidget2.mBaselineDistance != i9) {
                                                measure2.measuredNeedsSolverPass = true;
                                                i8 = i9;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            }
                                        }
                                        i8 = i9;
                                        measure2.measuredWidth = i10;
                                        measure2.measuredHeight = i12;
                                        measure2.measuredHasBaseline = z2;
                                        measure2.measuredBaseline = i8;
                                        return;
                                    } else if (!(obj5 == null || obj3 == null)) {
                                        i12 = (int) ((((float) i10) / constraintWidget2.mDimensionRatio) + 0.5f);
                                        if (i == i10) {
                                            if (i2 != i12) {
                                                if (i9 == -1) {
                                                    i11 = 1;
                                                } else {
                                                    i11 = 0;
                                                }
                                                if (i10 == measure2.horizontalDimension) {
                                                }
                                                measure2.measuredNeedsSolverPass = z;
                                                z2 = i11 | layoutParams.needsBaseline;
                                                if (z2) {
                                                    if (i9 != -1) {
                                                        i8 = -1;
                                                        measure2.measuredWidth = i10;
                                                        measure2.measuredHeight = i12;
                                                        measure2.measuredHasBaseline = z2;
                                                        measure2.measuredBaseline = i8;
                                                        return;
                                                    } else if (constraintWidget2.mBaselineDistance != i9) {
                                                        measure2.measuredNeedsSolverPass = true;
                                                        i8 = i9;
                                                        measure2.measuredWidth = i10;
                                                        measure2.measuredHeight = i12;
                                                        measure2.measuredHasBaseline = z2;
                                                        measure2.measuredBaseline = i8;
                                                        return;
                                                    }
                                                }
                                                i8 = i9;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            }
                                        }
                                        if (i != i10) {
                                            i11 = 1073741824;
                                            i3 = MeasureSpec.makeMeasureSpec(i10, 1073741824);
                                        } else {
                                            i11 = 1073741824;
                                        }
                                        if (i2 != i12) {
                                            i8 = MeasureSpec.makeMeasureSpec(i12, i11);
                                        } else {
                                            i8 = i13;
                                        }
                                        view2.measure(i3, i8);
                                        constraintWidget2.setLastMeasureSpec(i3, i8);
                                        i10 = view2.getMeasuredWidth();
                                        i12 = view2.getMeasuredHeight();
                                        i9 = view2.getBaseline();
                                        if (i9 == -1) {
                                            i11 = 0;
                                        } else {
                                            i11 = 1;
                                        }
                                        if (i10 == measure2.horizontalDimension) {
                                            if (i12 != measure2.verticalDimension) {
                                            }
                                        }
                                        measure2.measuredNeedsSolverPass = z;
                                        z2 = i11 | layoutParams.needsBaseline;
                                        if (z2) {
                                            if (i9 != -1) {
                                                i8 = -1;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            } else if (constraintWidget2.mBaselineDistance != i9) {
                                                measure2.measuredNeedsSolverPass = true;
                                                i8 = i9;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            }
                                        }
                                        i8 = i9;
                                        measure2.measuredWidth = i10;
                                        measure2.measuredHeight = i12;
                                        measure2.measuredHasBaseline = z2;
                                        measure2.measuredBaseline = i8;
                                        return;
                                    }
                                }
                                if (i == i10) {
                                    if (i2 != i12) {
                                        if (i9 == -1) {
                                            i11 = 1;
                                        } else {
                                            i11 = 0;
                                        }
                                        if (i10 == measure2.horizontalDimension) {
                                        }
                                        measure2.measuredNeedsSolverPass = z;
                                        z2 = i11 | layoutParams.needsBaseline;
                                        if (z2) {
                                            if (i9 != -1) {
                                                i8 = -1;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            } else if (constraintWidget2.mBaselineDistance != i9) {
                                                measure2.measuredNeedsSolverPass = true;
                                                i8 = i9;
                                                measure2.measuredWidth = i10;
                                                measure2.measuredHeight = i12;
                                                measure2.measuredHasBaseline = z2;
                                                measure2.measuredBaseline = i8;
                                                return;
                                            }
                                        }
                                        i8 = i9;
                                        measure2.measuredWidth = i10;
                                        measure2.measuredHeight = i12;
                                        measure2.measuredHasBaseline = z2;
                                        measure2.measuredBaseline = i8;
                                        return;
                                    }
                                }
                                if (i != i10) {
                                    i11 = 1073741824;
                                    i3 = MeasureSpec.makeMeasureSpec(i10, 1073741824);
                                } else {
                                    i11 = 1073741824;
                                }
                                if (i2 != i12) {
                                    i8 = MeasureSpec.makeMeasureSpec(i12, i11);
                                } else {
                                    i8 = i13;
                                }
                                view2.measure(i3, i8);
                                constraintWidget2.setLastMeasureSpec(i3, i8);
                                i10 = view2.getMeasuredWidth();
                                i12 = view2.getMeasuredHeight();
                                i9 = view2.getBaseline();
                                if (i9 == -1) {
                                    i11 = 0;
                                } else {
                                    i11 = 1;
                                }
                                if (i10 == measure2.horizontalDimension) {
                                    if (i12 != measure2.verticalDimension) {
                                    }
                                }
                                measure2.measuredNeedsSolverPass = z;
                                z2 = i11 | layoutParams.needsBaseline;
                                if (z2) {
                                    if (i9 != -1) {
                                        i8 = -1;
                                        measure2.measuredWidth = i10;
                                        measure2.measuredHeight = i12;
                                        measure2.measuredHasBaseline = z2;
                                        measure2.measuredBaseline = i8;
                                        return;
                                    } else if (constraintWidget2.mBaselineDistance != i9) {
                                        measure2.measuredNeedsSolverPass = true;
                                        i8 = i9;
                                        measure2.measuredWidth = i10;
                                        measure2.measuredHeight = i12;
                                        measure2.measuredHasBaseline = z2;
                                        measure2.measuredBaseline = i8;
                                        return;
                                    }
                                }
                                i8 = i9;
                                measure2.measuredWidth = i10;
                                measure2.measuredHeight = i12;
                                measure2.measuredHasBaseline = z2;
                                measure2.measuredBaseline = i8;
                                return;
                            }
                            return;
                        }
                        throw null;
                    }
                    throw null;
                }
            }
        }
    }

    public ConstraintLayout(Context context) {
        super(context);
        init(null, 0, 0);
    }

    protected static final LayoutParams generateDefaultLayoutParams$ar$ds$c9cc45ef_0() {
        return new LayoutParams();
    }

    private final void init(AttributeSet attributeSet, int i, int i2) {
        ConstraintWidget constraintWidget = this.mLayoutWidget;
        constraintWidget.mCompanionWidget = this;
        Measurer measurer = this.mMeasurer;
        constraintWidget.mMeasurer$ar$class_merging = measurer;
        constraintWidget.mDependencyGraph.mMeasurer$ar$class_merging = measurer;
        this.mChildrenByIds.put(getId(), this);
        this.mConstraintSet = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout, i, i2);
            i = obtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < i; i3++) {
                int index = obtainStyledAttributes.getIndex(i3);
                if (index == 16) {
                    this.mMinWidth = obtainStyledAttributes.getDimensionPixelOffset(16, this.mMinWidth);
                } else if (index == 17) {
                    this.mMinHeight = obtainStyledAttributes.getDimensionPixelOffset(17, this.mMinHeight);
                } else if (index == 14) {
                    this.mMaxWidth = obtainStyledAttributes.getDimensionPixelOffset(14, this.mMaxWidth);
                } else if (index == 15) {
                    this.mMaxHeight = obtainStyledAttributes.getDimensionPixelOffset(15, this.mMaxHeight);
                } else if (index == 112) {
                    this.mOptimizationLevel = obtainStyledAttributes.getInt(112, this.mOptimizationLevel);
                } else if (index == 55) {
                    index = obtainStyledAttributes.getResourceId(55, 0);
                    if (index != 0) {
                        try {
                            ConstraintLayoutStates.load$ar$objectUnboxing(getContext(), index, new SparseArray(), new SparseArray());
                        } catch (NotFoundException e) {
                        }
                    }
                } else if (index == 34) {
                    index = obtainStyledAttributes.getResourceId(34, 0);
                    try {
                        ConstraintSet constraintSet = new ConstraintSet();
                        this.mConstraintSet = constraintSet;
                        constraintSet.load(getContext(), index);
                    } catch (NotFoundException e2) {
                        this.mConstraintSet = null;
                    }
                    this.mConstraintSetId = index;
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
    }

    private final void markHierarchyDirty() {
        this.mDirtyHierarchy = true;
    }

    private final void setChildrenConstraints() {
        int i;
        int i2;
        View childAt;
        int indexOf;
        int indexOf2;
        ConstraintWidget constraintWidget;
        View childAt2;
        int findId;
        View view = this;
        boolean isInEditMode = isInEditMode();
        int childCount = getChildCount();
        boolean z = false;
        for (i = 0; i < childCount; i++) {
            ConstraintWidget viewWidget = getViewWidget(getChildAt(i));
            if (viewWidget != null) {
                viewWidget.reset();
            }
        }
        if (isInEditMode) {
            for (i2 = 0; i2 < childCount; i2++) {
                childAt = getChildAt(i2);
                try {
                    String resourceName = getResources().getResourceName(childAt.getId());
                    Integer valueOf = Integer.valueOf(childAt.getId());
                    if (resourceName instanceof String) {
                        Object substring;
                        if (view.mDesignIds == null) {
                            view.mDesignIds = new HashMap();
                        }
                        indexOf = resourceName.indexOf("/");
                        if (indexOf != -1) {
                            substring = resourceName.substring(indexOf + 1);
                        } else {
                            substring = resourceName;
                        }
                        view.mDesignIds.put(substring, Integer.valueOf(valueOf.intValue()));
                    }
                    indexOf2 = resourceName.indexOf(47);
                    if (indexOf2 != -1) {
                        resourceName = resourceName.substring(indexOf2 + 1);
                    }
                    i = childAt.getId();
                    if (i == 0) {
                        constraintWidget = view.mLayoutWidget;
                    } else {
                        View view2 = (View) view.mChildrenByIds.get(i);
                        if (view2 == null) {
                            view2 = findViewById(i);
                            if (!(view2 == null || view2 == view || view2.getParent() != view)) {
                                onViewAdded(view2);
                            }
                        }
                        constraintWidget = view2 == view ? view.mLayoutWidget : view2 == null ? null : ((LayoutParams) view2.getLayoutParams()).widget;
                    }
                    constraintWidget.mDebugName = resourceName;
                } catch (NotFoundException e) {
                }
            }
        }
        if (view.mConstraintSetId != -1) {
            for (i = 0; i < childCount; i++) {
                childAt2 = getChildAt(i);
                if (childAt2.getId() == view.mConstraintSetId) {
                    if (childAt2 instanceof Constraints) {
                        Constraints constraints = (Constraints) childAt2;
                        throw null;
                    }
                }
            }
        }
        ConstraintSet constraintSet = view.mConstraintSet;
        if (constraintSet != null) {
            constraintSet.applyToInternal$ar$ds(view);
        }
        view.mLayoutWidget.mChildren.clear();
        i = view.mConstraintHelpers.size();
        if (i > 0) {
            for (i2 = 0; i2 < i; i2++) {
                ConstraintHelper constraintHelper = (ConstraintHelper) view.mConstraintHelpers.get(i2);
                if (constraintHelper.isInEditMode()) {
                    constraintHelper.setIds(constraintHelper.mReferenceIds);
                }
                HelperWidget helperWidget = constraintHelper.mHelperWidget$ar$class_merging;
                if (helperWidget != null) {
                    helperWidget.mWidgetsCount = 0;
                    Arrays.fill(helperWidget.mWidgets, null);
                    for (indexOf2 = 0; indexOf2 < constraintHelper.mCount; indexOf2++) {
                        ConstraintWidget constraintWidget2;
                        ConstraintWidget viewWidget2;
                        ConstraintWidget[] constraintWidgetArr;
                        int length;
                        ConstraintWidget[] constraintWidgetArr2;
                        int i3;
                        indexOf = constraintHelper.mIds[indexOf2];
                        View viewById = getViewById(indexOf);
                        if (viewById == null) {
                            String str = (String) constraintHelper.mMap.get(Integer.valueOf(indexOf));
                            findId = constraintHelper.findId(view, str);
                            if (findId != 0) {
                                constraintHelper.mIds[indexOf2] = findId;
                                constraintHelper.mMap.put(Integer.valueOf(findId), str);
                                viewById = getViewById(findId);
                                if (viewById != null) {
                                    constraintWidget2 = constraintHelper.mHelperWidget$ar$class_merging;
                                    viewWidget2 = getViewWidget(viewById);
                                    if (viewWidget2 == constraintWidget2) {
                                        if (viewWidget2 == null) {
                                            findId = constraintWidget2.mWidgetsCount;
                                            constraintWidgetArr = constraintWidget2.mWidgets;
                                            length = constraintWidgetArr.length;
                                            if (findId + 1 > length) {
                                                constraintWidget2.mWidgets = (ConstraintWidget[]) Arrays.copyOf(constraintWidgetArr, length + length);
                                            }
                                            constraintWidgetArr2 = constraintWidget2.mWidgets;
                                            i3 = constraintWidget2.mWidgetsCount;
                                            constraintWidgetArr2[i3] = viewWidget2;
                                            constraintWidget2.mWidgetsCount = i3 + 1;
                                        }
                                    }
                                }
                            }
                        }
                        if (viewById != null) {
                            constraintWidget2 = constraintHelper.mHelperWidget$ar$class_merging;
                            viewWidget2 = getViewWidget(viewById);
                            if (viewWidget2 == constraintWidget2) {
                                if (viewWidget2 == null) {
                                    findId = constraintWidget2.mWidgetsCount;
                                    constraintWidgetArr = constraintWidget2.mWidgets;
                                    length = constraintWidgetArr.length;
                                    if (findId + 1 > length) {
                                        constraintWidget2.mWidgets = (ConstraintWidget[]) Arrays.copyOf(constraintWidgetArr, length + length);
                                    }
                                    constraintWidgetArr2 = constraintWidget2.mWidgets;
                                    i3 = constraintWidget2.mWidgetsCount;
                                    constraintWidgetArr2[i3] = viewWidget2;
                                    constraintWidget2.mWidgetsCount = i3 + 1;
                                }
                            }
                        }
                    }
                    HelperWidget helperWidget2 = constraintHelper.mHelperWidget$ar$class_merging;
                }
            }
            i = 0;
        } else {
            i = 0;
        }
        while (i < childCount) {
            childAt2 = getChildAt(i);
            if (childAt2 instanceof Placeholder) {
                Placeholder placeholder = (Placeholder) childAt2;
                throw null;
            }
            i++;
        }
        view.mTempMapIdToWidget.clear();
        view.mTempMapIdToWidget.put(0, view.mLayoutWidget);
        view.mTempMapIdToWidget.put(getId(), view.mLayoutWidget);
        for (i = 0; i < childCount; i++) {
            View childAt3 = getChildAt(i);
            view.mTempMapIdToWidget.put(childAt3.getId(), getViewWidget(childAt3));
        }
        findId = 0;
        while (findId < childCount) {
            childAt = getChildAt(findId);
            ConstraintWidget viewWidget3 = getViewWidget(childAt);
            if (viewWidget3 != null) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                viewWidget = view.mLayoutWidget;
                viewWidget.mChildren.add(viewWidget3);
                ConstraintWidget constraintWidget3 = viewWidget3.mParent;
                if (constraintWidget3 != null) {
                    ((WidgetContainer) constraintWidget3).remove(viewWidget3);
                }
                viewWidget3.mParent = viewWidget;
                SparseArray sparseArray = view.mTempMapIdToWidget;
                layoutParams.validate();
                layoutParams.helped = z;
                viewWidget3.mVisibility = childAt.getVisibility();
                boolean z2 = layoutParams.isInPlaceholder;
                viewWidget3.mCompanionWidget = childAt;
                if (childAt instanceof ConstraintHelper) {
                    ((ConstraintHelper) childAt).resolveRtl(viewWidget3, view.mLayoutWidget.mIsRtl);
                }
                int i4;
                if (layoutParams.isGuideline) {
                    Guideline guideline = (Guideline) viewWidget3;
                    i = layoutParams.resolvedGuideBegin;
                    i4 = layoutParams.resolvedGuideEnd;
                    float f = layoutParams.resolvedGuidePercent;
                    if (f != -1.0f) {
                        if (f > -1.0f) {
                            guideline.mRelativePercent = f;
                            guideline.mRelativeBegin = -1;
                        }
                    } else if (i != -1) {
                        if (i >= 0) {
                            guideline.mRelativePercent = -1.0f;
                            guideline.mRelativeBegin = i;
                        }
                    } else if (i4 != -1 && i4 >= 0) {
                        guideline.mRelativePercent = -1.0f;
                        guideline.mRelativeBegin = -1;
                        guideline.mRelativeEnd = i4;
                    }
                    guideline.mRelativeEnd = -1;
                } else {
                    float f2;
                    float f3;
                    int indexOf3;
                    float[] fArr;
                    float f4;
                    i = layoutParams.resolvedLeftToLeft;
                    i4 = layoutParams.resolvedLeftToRight;
                    indexOf = layoutParams.resolvedRightToLeft;
                    indexOf2 = layoutParams.resolvedRightToRight;
                    int i5 = layoutParams.resolveGoneLeftMargin;
                    i2 = layoutParams.resolveGoneRightMargin;
                    float f5 = layoutParams.resolvedHorizontalBias;
                    int i6 = layoutParams.circleConstraint;
                    int i7 = indexOf2;
                    ConstraintWidget constraintWidget4;
                    if (i6 != -1) {
                        constraintWidget4 = (ConstraintWidget) sparseArray.get(i6);
                        if (constraintWidget4 != null) {
                            f2 = layoutParams.circleAngle;
                            viewWidget3.immediateConnect$ar$edu(7, constraintWidget4, 7, layoutParams.circleRadius, 0);
                            viewWidget3.mCircleConstraintAngle = f2;
                        }
                    } else {
                        int i8;
                        SparseArray sparseArray2;
                        SparseArray sparseArray3;
                        int i9;
                        SparseArray sparseArray4;
                        if (i != -1) {
                            constraintWidget = (ConstraintWidget) sparseArray.get(i);
                            if (constraintWidget != null) {
                                i8 = i2;
                                i9 = i5;
                                constraintWidget4 = constraintWidget;
                                i = i7;
                                i6 = indexOf;
                                sparseArray4 = sparseArray;
                                viewWidget3.immediateConnect$ar$edu(2, constraintWidget4, 2, layoutParams.leftMargin, i9);
                                sparseArray2 = sparseArray4;
                            } else {
                                i8 = i2;
                                i6 = indexOf;
                                i = i7;
                                sparseArray2 = sparseArray;
                            }
                        } else {
                            i8 = i2;
                            i9 = i5;
                            i6 = indexOf;
                            sparseArray4 = sparseArray;
                            i = i7;
                            if (i4 != -1) {
                                sparseArray = sparseArray4;
                                constraintWidget4 = (ConstraintWidget) sparseArray.get(i4);
                                if (constraintWidget4 != null) {
                                    sparseArray2 = sparseArray;
                                    viewWidget3.immediateConnect$ar$edu(2, constraintWidget4, 4, layoutParams.leftMargin, i9);
                                } else {
                                    sparseArray2 = sparseArray;
                                }
                            } else {
                                sparseArray2 = sparseArray4;
                            }
                        }
                        if (i6 != -1) {
                            SparseArray sparseArray5 = sparseArray2;
                            constraintWidget4 = (ConstraintWidget) sparseArray5.get(i6);
                            if (constraintWidget4 != null) {
                                viewWidget3.immediateConnect$ar$edu(4, constraintWidget4, 2, layoutParams.rightMargin, i8);
                                sparseArray3 = sparseArray5;
                            } else {
                                sparseArray3 = sparseArray5;
                            }
                        } else {
                            sparseArray3 = sparseArray2;
                            if (i != -1) {
                                constraintWidget4 = (ConstraintWidget) sparseArray3.get(i);
                                if (constraintWidget4 != null) {
                                    viewWidget3.immediateConnect$ar$edu(4, constraintWidget4, 4, layoutParams.rightMargin, i8);
                                }
                            }
                        }
                        i = layoutParams.topToTop;
                        if (i != -1) {
                            constraintWidget4 = (ConstraintWidget) sparseArray3.get(i);
                            if (constraintWidget4 != null) {
                                viewWidget3.immediateConnect$ar$edu(3, constraintWidget4, 3, layoutParams.topMargin, layoutParams.goneTopMargin);
                            }
                        } else {
                            i = layoutParams.topToBottom;
                            if (i != -1) {
                                constraintWidget4 = (ConstraintWidget) sparseArray3.get(i);
                                if (constraintWidget4 != null) {
                                    viewWidget3.immediateConnect$ar$edu(3, constraintWidget4, 5, layoutParams.topMargin, layoutParams.goneTopMargin);
                                }
                            }
                        }
                        i = layoutParams.bottomToTop;
                        if (i != -1) {
                            constraintWidget4 = (ConstraintWidget) sparseArray3.get(i);
                            if (constraintWidget4 != null) {
                                viewWidget3.immediateConnect$ar$edu(5, constraintWidget4, 3, layoutParams.bottomMargin, layoutParams.goneBottomMargin);
                            }
                        } else {
                            i = layoutParams.bottomToBottom;
                            if (i != -1) {
                                constraintWidget4 = (ConstraintWidget) sparseArray3.get(i);
                                if (constraintWidget4 != null) {
                                    viewWidget3.immediateConnect$ar$edu(5, constraintWidget4, 5, layoutParams.bottomMargin, layoutParams.goneBottomMargin);
                                }
                            }
                        }
                        indexOf = layoutParams.baselineToBaseline;
                        if (indexOf != -1) {
                            setWidgetBaseline$ar$edu(viewWidget3, layoutParams, sparseArray3, indexOf, 6);
                        } else {
                            indexOf = layoutParams.baselineToTop;
                            if (indexOf != -1) {
                                setWidgetBaseline$ar$edu(viewWidget3, layoutParams, sparseArray3, indexOf, 3);
                            } else {
                                indexOf = layoutParams.baselineToBottom;
                                if (indexOf != -1) {
                                    setWidgetBaseline$ar$edu(viewWidget3, layoutParams, sparseArray3, indexOf, 5);
                                }
                            }
                        }
                        if (f5 >= 0.0f) {
                            viewWidget3.mHorizontalBiasPercent = f5;
                        }
                        f2 = layoutParams.verticalBias;
                        if (f2 >= 0.0f) {
                            viewWidget3.mVerticalBiasPercent = f2;
                        }
                    }
                    if (isInEditMode) {
                        i = layoutParams.editorAbsoluteX;
                        if (i == -1) {
                            if (layoutParams.editorAbsoluteY != -1) {
                                i = -1;
                            }
                        }
                        i4 = layoutParams.editorAbsoluteY;
                        viewWidget3.f12mX = i;
                        viewWidget3.f13mY = i4;
                    }
                    if (layoutParams.horizontalDimensionFixed) {
                        viewWidget3.setHorizontalDimensionBehaviour$ar$edu(1);
                        viewWidget3.setWidth(layoutParams.width);
                        if (layoutParams.width == -2) {
                            viewWidget3.setHorizontalDimensionBehaviour$ar$edu(2);
                        }
                    } else if (layoutParams.width == -1) {
                        if (layoutParams.constrainedWidth) {
                            viewWidget3.setHorizontalDimensionBehaviour$ar$edu(3);
                        } else {
                            viewWidget3.setHorizontalDimensionBehaviour$ar$edu(4);
                        }
                        viewWidget3.getAnchor$ar$edu(2).mMargin = layoutParams.leftMargin;
                        viewWidget3.getAnchor$ar$edu(4).mMargin = layoutParams.rightMargin;
                    } else {
                        viewWidget3.setHorizontalDimensionBehaviour$ar$edu(3);
                        viewWidget3.setWidth(0);
                    }
                    if (layoutParams.verticalDimensionFixed) {
                        viewWidget3.setVerticalDimensionBehaviour$ar$edu(1);
                        viewWidget3.setHeight(layoutParams.height);
                        if (layoutParams.height == -2) {
                            viewWidget3.setVerticalDimensionBehaviour$ar$edu(2);
                        }
                    } else if (layoutParams.height == -1) {
                        if (layoutParams.constrainedHeight) {
                            viewWidget3.setVerticalDimensionBehaviour$ar$edu(3);
                        } else {
                            viewWidget3.setVerticalDimensionBehaviour$ar$edu(4);
                        }
                        viewWidget3.getAnchor$ar$edu(3).mMargin = layoutParams.topMargin;
                        viewWidget3.getAnchor$ar$edu(5).mMargin = layoutParams.bottomMargin;
                    } else {
                        viewWidget3.setVerticalDimensionBehaviour$ar$edu(3);
                        viewWidget3.setHeight(0);
                    }
                    String str2 = layoutParams.dimensionRatio;
                    if (str2 == null) {
                        f3 = 0.0f;
                    } else if (str2.length() == 0) {
                        f3 = 0.0f;
                    } else {
                        i4 = str2.length();
                        i2 = str2.indexOf(44);
                        if (i2 <= 0 || i2 >= i4 - 1) {
                            i2 = -1;
                            indexOf = 0;
                        } else {
                            String substring2 = str2.substring(0, i2);
                            indexOf = substring2.equalsIgnoreCase("W") ? 0 : substring2.equalsIgnoreCase("H") ? 1 : -1;
                            int i10 = indexOf;
                            indexOf = i2 + 1;
                            i2 = i10;
                        }
                        indexOf3 = str2.indexOf(58);
                        if (indexOf3 < 0 || indexOf3 >= i4 - 1) {
                            str2 = str2.substring(indexOf);
                            f2 = str2.length() > 0 ? Float.parseFloat(str2) : 0.0f;
                        } else {
                            String substring3 = str2.substring(indexOf, indexOf3);
                            str2 = str2.substring(indexOf3 + 1);
                            if (substring3.length() > 0 && str2.length() > 0) {
                                try {
                                    f3 = Float.parseFloat(substring3);
                                    f2 = Float.parseFloat(str2);
                                    if (f3 > 0.0f && f2 > 0.0f) {
                                        f2 = i2 == 1 ? Math.abs(f2 / f3) : Math.abs(f3 / f2);
                                    }
                                } catch (NumberFormatException e2) {
                                    f2 = 0.0f;
                                }
                            }
                            f2 = 0.0f;
                        }
                        if (f2 > 0.0f) {
                            viewWidget3.mDimensionRatio = f2;
                            viewWidget3.mDimensionRatioSide = i2;
                        }
                        f2 = layoutParams.horizontalWeight;
                        fArr = viewWidget3.mWeight;
                        fArr[0] = f2;
                        fArr[1] = layoutParams.verticalWeight;
                        viewWidget3.mHorizontalChainStyle = layoutParams.horizontalChainStyle;
                        viewWidget3.mVerticalChainStyle = layoutParams.verticalChainStyle;
                        i = layoutParams.wrapBehaviorInParent;
                        if (i >= 0 && i <= 3) {
                            viewWidget3.mWrapBehaviorInParent = i;
                        }
                        i = layoutParams.matchConstraintDefaultWidth;
                        i4 = layoutParams.matchConstraintMinWidth;
                        indexOf2 = layoutParams.matchConstraintMaxWidth;
                        f4 = layoutParams.matchConstraintPercentWidth;
                        viewWidget3.mMatchConstraintDefaultWidth = i;
                        viewWidget3.mMatchConstraintMinWidth = i4;
                        if (indexOf2 == Integer.MAX_VALUE) {
                            indexOf2 = 0;
                        }
                        viewWidget3.mMatchConstraintMaxWidth = indexOf2;
                        viewWidget3.mMatchConstraintPercentWidth = f4;
                        if (f4 > 0.0f && f4 < 1.0f && i == 0) {
                            viewWidget3.mMatchConstraintDefaultWidth = 2;
                        }
                        i = layoutParams.matchConstraintDefaultHeight;
                        indexOf3 = layoutParams.matchConstraintMinHeight;
                        i6 = layoutParams.matchConstraintMaxHeight;
                        f5 = layoutParams.matchConstraintPercentHeight;
                        viewWidget3.mMatchConstraintDefaultHeight = i;
                        viewWidget3.mMatchConstraintMinHeight = indexOf3;
                        if (i6 == Integer.MAX_VALUE) {
                            i6 = 0;
                        }
                        viewWidget3.mMatchConstraintMaxHeight = i6;
                        viewWidget3.mMatchConstraintPercentHeight = f5;
                        if (f5 > 0.0f && f5 < 1.0f && i == 0) {
                            viewWidget3.mMatchConstraintDefaultHeight = 2;
                        }
                    }
                    viewWidget3.mDimensionRatio = f3;
                    f2 = layoutParams.horizontalWeight;
                    fArr = viewWidget3.mWeight;
                    fArr[0] = f2;
                    fArr[1] = layoutParams.verticalWeight;
                    viewWidget3.mHorizontalChainStyle = layoutParams.horizontalChainStyle;
                    viewWidget3.mVerticalChainStyle = layoutParams.verticalChainStyle;
                    i = layoutParams.wrapBehaviorInParent;
                    viewWidget3.mWrapBehaviorInParent = i;
                    i = layoutParams.matchConstraintDefaultWidth;
                    i4 = layoutParams.matchConstraintMinWidth;
                    indexOf2 = layoutParams.matchConstraintMaxWidth;
                    f4 = layoutParams.matchConstraintPercentWidth;
                    viewWidget3.mMatchConstraintDefaultWidth = i;
                    viewWidget3.mMatchConstraintMinWidth = i4;
                    if (indexOf2 == Integer.MAX_VALUE) {
                        indexOf2 = 0;
                    }
                    viewWidget3.mMatchConstraintMaxWidth = indexOf2;
                    viewWidget3.mMatchConstraintPercentWidth = f4;
                    viewWidget3.mMatchConstraintDefaultWidth = 2;
                    i = layoutParams.matchConstraintDefaultHeight;
                    indexOf3 = layoutParams.matchConstraintMinHeight;
                    i6 = layoutParams.matchConstraintMaxHeight;
                    f5 = layoutParams.matchConstraintPercentHeight;
                    viewWidget3.mMatchConstraintDefaultHeight = i;
                    viewWidget3.mMatchConstraintMinHeight = indexOf3;
                    if (i6 == Integer.MAX_VALUE) {
                        i6 = 0;
                    }
                    viewWidget3.mMatchConstraintMaxHeight = i6;
                    viewWidget3.mMatchConstraintPercentHeight = f5;
                    viewWidget3.mMatchConstraintDefaultHeight = 2;
                }
            }
            findId++;
            z = false;
        }
    }

    private final void setWidgetBaseline$ar$edu(ConstraintWidget constraintWidget, LayoutParams layoutParams, SparseArray sparseArray, int i, int i2) {
        View view = (View) this.mChildrenByIds.get(i);
        ConstraintWidget constraintWidget2 = (ConstraintWidget) sparseArray.get(i);
        if (constraintWidget2 != null && view != null && (view.getLayoutParams() instanceof LayoutParams)) {
            layoutParams.needsBaseline = true;
            if (i2 == 6) {
                LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                layoutParams2.needsBaseline = true;
                layoutParams2.widget.hasBaseline = true;
            }
            constraintWidget.getAnchor$ar$edu(6).connect$ar$ds$404e5fa_0(constraintWidget2.getAnchor$ar$edu(i2), layoutParams.baselineMargin, layoutParams.goneBaselineMargin);
            constraintWidget.hasBaseline = true;
            constraintWidget.getAnchor$ar$edu(3).reset();
            constraintWidget.getAnchor$ar$edu(5).reset();
        }
    }

    protected final boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    protected final void dispatchDraw(Canvas canvas) {
        ArrayList arrayList = this.mConstraintHelpers;
        if (arrayList != null) {
            int size = arrayList.size();
            if (size > 0) {
                for (int i = 0; i < size; i++) {
                    ConstraintHelper constraintHelper = (ConstraintHelper) r0.mConstraintHelpers.get(i);
                }
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = (float) getWidth();
            float height = (float) getHeight();
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                if (childAt.getVisibility() != 8) {
                    Object tag = childAt.getTag();
                    if (tag != null && (tag instanceof String)) {
                        String[] split = ((String) tag).split(",");
                        if (split.length == 4) {
                            int parseInt = Integer.parseInt(split[0]);
                            int parseInt2 = Integer.parseInt(split[1]);
                            int parseInt3 = Integer.parseInt(split[2]);
                            int parseInt4 = Integer.parseInt(split[3]);
                            parseInt = (int) ((((float) parseInt) / 1080.0f) * width);
                            parseInt2 = (int) ((((float) parseInt2) / 1920.0f) * height);
                            Paint paint = new Paint();
                            paint.setColor(-65536);
                            float f = (float) parseInt;
                            float f2 = (float) (parseInt + ((int) ((((float) parseInt3) / 1080.0f) * width)));
                            Canvas canvas2 = canvas;
                            float f3 = (float) parseInt2;
                            float f4 = f;
                            float f5 = f;
                            f = f3;
                            Paint paint2 = paint;
                            float f6 = f2;
                            Paint paint3 = paint2;
                            canvas2.drawLine(f4, f, f6, f3, paint3);
                            float f7 = (float) (parseInt2 + ((int) ((((float) parseInt4) / 1920.0f) * height)));
                            f4 = f2;
                            float f8 = f7;
                            canvas2.drawLine(f4, f, f6, f8, paint3);
                            f = f7;
                            f6 = f5;
                            canvas2.drawLine(f4, f, f6, f8, paint3);
                            f4 = f5;
                            canvas2.drawLine(f4, f, f6, f3, paint3);
                            Paint paint4 = paint2;
                            paint4.setColor(-16711936);
                            f6 = f2;
                            paint3 = paint4;
                            canvas2.drawLine(f4, f3, f6, f7, paint3);
                            canvas2.drawLine(f4, f7, f6, f3, paint3);
                        }
                    }
                }
            }
        }
    }

    public final void forceLayout() {
        markHierarchyDirty();
        super.forceLayout();
    }

    protected final /* bridge */ /* synthetic */ android.view.ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return generateDefaultLayoutParams$ar$ds$c9cc45ef_0();
    }

    public final Object getDesignInformation$ar$ds(Object obj) {
        if (obj instanceof String) {
            HashMap hashMap = this.mDesignIds;
            if (hashMap != null && hashMap.containsKey(obj)) {
                return this.mDesignIds.get(obj);
            }
        }
        return null;
    }

    public final View getViewById(int i) {
        return (View) this.mChildrenByIds.get(i);
    }

    public final ConstraintWidget getViewWidget(View view) {
        if (view == this) {
            return this.mLayoutWidget;
        }
        if (view != null) {
            if (view.getLayoutParams() instanceof LayoutParams) {
                return ((LayoutParams) view.getLayoutParams()).widget;
            }
            view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
            if (view.getLayoutParams() instanceof LayoutParams) {
                return ((LayoutParams) view.getLayoutParams()).widget;
            }
        }
        return null;
    }

    protected final boolean isRtl() {
        return (getContext().getApplicationInfo().flags & 4194304) != 0 && getLayoutDirection() == 1;
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            ConstraintWidget constraintWidget = layoutParams.widget;
            if (!(childAt.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper)) {
                boolean z2 = layoutParams.isVirtualGroup;
                if (!isInEditMode) {
                }
            }
            boolean z3 = layoutParams.isInPlaceholder;
            int x = constraintWidget.getX();
            int y = constraintWidget.getY();
            childAt.layout(x, y, constraintWidget.getWidth() + x, constraintWidget.getHeight() + y);
            if (childAt instanceof Placeholder) {
                Placeholder placeholder = (Placeholder) childAt;
                throw null;
            }
        }
        childCount = this.mConstraintHelpers.size();
        if (childCount > 0) {
            for (i2 = 0; i2 < childCount; i2++) {
                ConstraintHelper constraintHelper = (ConstraintHelper) this.mConstraintHelpers.get(i2);
            }
        }
    }

    protected void onMeasure(int i, int i2) {
        int childCount;
        int i3;
        ConstraintWidgetContainer constraintWidgetContainer;
        Measurer measurer;
        int i4;
        int i5;
        int[] iArr;
        BasicMeasure basicMeasure;
        Measurer measurer2;
        int width;
        boolean enabled;
        ConstraintWidget constraintWidget;
        int i6;
        Object obj;
        int i7;
        DependencyGraph dependencyGraph;
        Measurer measurer3;
        List list;
        ConstraintWidget constraintWidget2;
        List list2;
        int i8;
        WidgetRun widgetRun;
        WidgetRun widgetRun2;
        int i9;
        int i10;
        boolean optimizeFor;
        Measurer measurer4;
        ConstraintWidget constraintWidget3;
        boolean z;
        WidgetRun widgetRun3;
        WidgetRun widgetRun4;
        Object obj2;
        View childAt;
        Placeholder placeholder;
        ConstraintLayout constraintLayout;
        ConstraintHelper constraintHelper;
        ConstraintLayout constraintLayout2;
        ConstraintWidget constraintWidget4;
        int i11;
        VirtualLayout virtualLayout;
        ConstraintWidget constraintWidget5;
        ConstraintWidget constraintWidget6;
        ConstraintWidgetContainer constraintWidgetContainer2;
        boolean z2;
        boolean z3;
        Measurer measurer5;
        int i12 = i;
        int i13 = i2;
        if (!this.mDirtyHierarchy) {
            childCount = getChildCount();
            for (i3 = 0; i3 < childCount; i3++) {
                if (getChildAt(i3).isLayoutRequested()) {
                    r0.mDirtyHierarchy = true;
                    break;
                }
            }
        }
        r0.mLayoutWidget.mIsRtl = isRtl();
        if (r0.mDirtyHierarchy) {
            r0.mDirtyHierarchy = false;
            childCount = getChildCount();
            for (i3 = 0; i3 < childCount; i3++) {
                if (getChildAt(i3).isLayoutRequested()) {
                    setChildrenConstraints();
                    constraintWidgetContainer = r0.mLayoutWidget;
                    constraintWidgetContainer.mBasicMeasureSolver.updateHierarchy(constraintWidgetContainer);
                    break;
                }
            }
        }
        ConstraintWidget constraintWidget7 = r0.mLayoutWidget;
        i3 = r0.mOptimizationLevel;
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size2 = MeasureSpec.getSize(i2);
        int max = Math.max(0, getPaddingTop());
        int max2 = Math.max(0, getPaddingBottom());
        int i14 = max + max2;
        int max3 = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
        int max4 = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
        if (max4 > 0) {
            max3 = max4;
        }
        Measurer measurer6 = r0.mMeasurer;
        measurer6.paddingTop = max;
        measurer6.paddingBottom = max2;
        measurer6.paddingWidth = max3;
        measurer6.paddingHeight = i14;
        measurer6.layoutWidthSpec = i12;
        measurer6.layoutHeightSpec = i13;
        int max5 = Math.max(0, getPaddingStart());
        max2 = Math.max(0, getPaddingEnd());
        if (max5 <= 0) {
            if (max2 <= 0) {
                max5 = Math.max(0, getPaddingLeft());
                size -= max3;
                size2 -= i14;
                measurer = r0.mMeasurer;
                i14 = measurer.paddingHeight;
                max2 = measurer.paddingWidth;
                max3 = getChildCount();
                switch (mode) {
                    case LinearLayoutManager.INVALID_OFFSET /*-2147483648*/:
                        if (max3 != 0) {
                            max4 = Math.max(0, r0.mMinWidth);
                            max3 = 0;
                        } else {
                            max4 = size;
                        }
                        i4 = 2;
                        break;
                    case 0:
                        if (max3 != 0) {
                            max4 = Math.max(0, r0.mMinWidth);
                            max3 = 0;
                        } else {
                            max4 = 0;
                        }
                        i4 = 2;
                        break;
                    case 1073741824:
                        max4 = Math.min(r0.mMaxWidth - max2, size);
                        i4 = 1;
                        break;
                    default:
                        max4 = 0;
                        i4 = 1;
                        break;
                }
                switch (mode2) {
                    case LinearLayoutManager.INVALID_OFFSET /*-2147483648*/:
                        max3 = max3 != 0 ? Math.max(0, r0.mMinHeight) : size2;
                        i5 = 2;
                        break;
                    case 0:
                        max3 = max3 != 0 ? Math.max(0, r0.mMinHeight) : 0;
                        i5 = 2;
                        break;
                    case 1073741824:
                        max3 = Math.min(r0.mMaxHeight - i14, size2);
                        i5 = 1;
                        break;
                    default:
                        max3 = 0;
                        i5 = 1;
                        break;
                }
                if (max4 == constraintWidget7.getWidth()) {
                    if (max3 != constraintWidget7.getHeight()) {
                        constraintWidget7.f12mX = 0;
                        constraintWidget7.f13mY = 0;
                        i13 = r0.mMaxWidth;
                        iArr = constraintWidget7.mMaxDimension;
                        iArr[0] = i13 - max2;
                        iArr[1] = r0.mMaxHeight - i14;
                        constraintWidget7.setMinWidth(0);
                        constraintWidget7.setMinHeight(0);
                        constraintWidget7.setHorizontalDimensionBehaviour$ar$edu(i4);
                        constraintWidget7.setWidth(max4);
                        constraintWidget7.setVerticalDimensionBehaviour$ar$edu(i5);
                        constraintWidget7.setHeight(max3);
                        constraintWidget7.setMinWidth(r0.mMinWidth - max2);
                        constraintWidget7.setMinHeight(r0.mMinHeight - i14);
                        constraintWidget7.mPaddingLeft = max5;
                        constraintWidget7.mPaddingTop = max;
                        basicMeasure = constraintWidget7.mBasicMeasureSolver;
                        measurer2 = constraintWidget7.mMeasurer$ar$class_merging;
                        max5 = constraintWidget7.mChildren.size();
                        width = constraintWidget7.getWidth();
                        max = constraintWidget7.getHeight();
                        enabled = Optimizer.enabled(i3, 128);
                        i3 = enabled ? Optimizer.enabled(i3, 64) ? 1 : 0 : 1;
                        if (i3 != 0) {
                            i14 = 0;
                            while (i14 < max5) {
                                constraintWidget = (ConstraintWidget) constraintWidget7.mChildren.get(i14);
                                max4 = constraintWidget.getHorizontalDimensionBehaviour$ar$edu();
                                i6 = i3;
                                i3 = constraintWidget.getVerticalDimensionBehaviour$ar$edu();
                                if (max4 == 3 || i3 != 3 || constraintWidget.mDimensionRatio <= 0.0f) {
                                    obj = null;
                                } else {
                                    obj = 1;
                                }
                                if (constraintWidget.isInHorizontalChain()) {
                                    if (obj == null) {
                                        i6 = 0;
                                        if (mode == 1073741824) {
                                            if (mode2 != 1073741824) {
                                                mode = 1073741824;
                                            } else {
                                                i3 = 1;
                                                mode = 1073741824;
                                                mode2 = 1073741824;
                                                i3 = i6 & i3;
                                                if (i3 == 0) {
                                                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                                    max3 = mode != 1073741824 ? 0 : 1;
                                                    if (mode == 1073741824 && constraintWidget7.getWidth() != size) {
                                                        constraintWidget7.setWidth(size);
                                                        constraintWidget7.invalidateGraph();
                                                    }
                                                    size = mode2 != 1073741824 ? 0 : 1;
                                                    if (mode2 == 1073741824 && constraintWidget7.getHeight() != size2) {
                                                        constraintWidget7.setHeight(size2);
                                                        constraintWidget7.invalidateGraph();
                                                    }
                                                    if (mode == 1073741824 || mode2 != 1073741824) {
                                                        i7 = i3;
                                                        dependencyGraph = constraintWidget7.mDependencyGraph;
                                                        if (dependencyGraph.mNeedBuildGraph) {
                                                            measurer3 = measurer2;
                                                        } else {
                                                            list = dependencyGraph.container.mChildren;
                                                            i14 = list.size();
                                                            max4 = 0;
                                                            while (max4 < i14) {
                                                                constraintWidget2 = (ConstraintWidget) list.get(max4);
                                                                constraintWidget2.ensureWidgetRuns();
                                                                list2 = list;
                                                                constraintWidget2.measured = false;
                                                                i8 = i14;
                                                                widgetRun = constraintWidget2.horizontalRun;
                                                                measurer3 = measurer2;
                                                                widgetRun.dimension.resolved = false;
                                                                widgetRun.resolved = false;
                                                                widgetRun.reset();
                                                                widgetRun2 = constraintWidget2.verticalRun;
                                                                widgetRun2.dimension.resolved = false;
                                                                widgetRun2.resolved = false;
                                                                widgetRun2.reset();
                                                                max4++;
                                                                i14 = i8;
                                                                list = list2;
                                                                measurer2 = measurer3;
                                                            }
                                                            measurer3 = measurer2;
                                                            dependencyGraph.container.ensureWidgetRuns();
                                                            constraintWidget2 = dependencyGraph.container;
                                                            constraintWidget2.measured = false;
                                                            widgetRun2 = constraintWidget2.horizontalRun;
                                                            widgetRun2.dimension.resolved = false;
                                                            widgetRun2.resolved = false;
                                                            widgetRun2.reset();
                                                            widgetRun2 = dependencyGraph.container.verticalRun;
                                                            widgetRun2.dimension.resolved = false;
                                                            widgetRun2.resolved = false;
                                                            widgetRun2.reset();
                                                            dependencyGraph.buildGraph();
                                                        }
                                                        dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                                        constraintWidget2 = dependencyGraph.container;
                                                        constraintWidget2.f12mX = 0;
                                                        constraintWidget2.f13mY = 0;
                                                        constraintWidget2.horizontalRun.start.resolve(0);
                                                        dependencyGraph.container.verticalRun.start.resolve(0);
                                                        if (mode != 1073741824) {
                                                            i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                                            i13 = 1;
                                                        } else {
                                                            i13 = 0;
                                                            i3 = 1;
                                                        }
                                                        if (mode2 != 1073741824) {
                                                            i9 = 1;
                                                            i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                                            i13++;
                                                        } else {
                                                            i9 = 1;
                                                        }
                                                    } else {
                                                        ConstraintWidget constraintWidget8;
                                                        ConstraintWidget constraintWidget9;
                                                        Object obj3;
                                                        WidgetRun widgetRun5;
                                                        Object obj4;
                                                        List list3;
                                                        List list4;
                                                        int i15;
                                                        DependencyGraph dependencyGraph2 = constraintWidget7.mDependencyGraph;
                                                        if (!dependencyGraph2.mNeedBuildGraph) {
                                                            if (!dependencyGraph2.mNeedRedoMeasures) {
                                                                mode2 = 0;
                                                                dependencyGraph2.basicMeasureWidgets$ar$ds(dependencyGraph2.mContainer);
                                                                constraintWidget8 = dependencyGraph2.container;
                                                                constraintWidget8.f12mX = mode2;
                                                                constraintWidget8.f13mY = mode2;
                                                                mode = constraintWidget8.getDimensionBehaviour$ar$edu(mode2);
                                                                mode2 = dependencyGraph2.container.getDimensionBehaviour$ar$edu(1);
                                                                if (dependencyGraph2.mNeedBuildGraph) {
                                                                    dependencyGraph2.buildGraph();
                                                                }
                                                                size2 = dependencyGraph2.container.getX();
                                                                i14 = dependencyGraph2.container.getY();
                                                                dependencyGraph2.container.horizontalRun.start.resolve(size2);
                                                                dependencyGraph2.container.verticalRun.start.resolve(i14);
                                                                dependencyGraph2.measureWidgets();
                                                                if (mode != 2) {
                                                                    if (mode2 != 2) {
                                                                        mode2 = 2;
                                                                    } else {
                                                                        i7 = i3;
                                                                        constraintWidget9 = dependencyGraph2.container;
                                                                        max2 = constraintWidget9.mListDimensionBehaviors$ar$edu[0];
                                                                        if (max2 != 1) {
                                                                            if (max2 != 4) {
                                                                                obj3 = null;
                                                                                list = dependencyGraph2.mRuns;
                                                                                max2 = list.size();
                                                                                i14 = 0;
                                                                                while (i14 < max2) {
                                                                                    widgetRun5 = (WidgetRun) list.get(i14);
                                                                                    list2 = list;
                                                                                    i10 = max2;
                                                                                    if (widgetRun5.widget == dependencyGraph2.container || widgetRun5.resolved) {
                                                                                        widgetRun5.applyToWidget();
                                                                                    }
                                                                                    i14++;
                                                                                    list = list2;
                                                                                    max2 = i10;
                                                                                }
                                                                                list = dependencyGraph2.mRuns;
                                                                                max2 = list.size();
                                                                                i14 = 0;
                                                                                while (i14 < max2) {
                                                                                    widgetRun5 = (WidgetRun) list.get(i14);
                                                                                    if (obj3 != null) {
                                                                                        obj4 = obj3;
                                                                                        list3 = list;
                                                                                        if (widgetRun5.widget == dependencyGraph2.container) {
                                                                                            i14++;
                                                                                            obj3 = obj4;
                                                                                            list = list3;
                                                                                        }
                                                                                    } else {
                                                                                        obj4 = obj3;
                                                                                        list3 = list;
                                                                                    }
                                                                                    if (widgetRun5.start.resolved) {
                                                                                        i3 = 0;
                                                                                    } else if (!widgetRun5.end.resolved || (widgetRun5 instanceof GuidelineReference)) {
                                                                                        if (!(widgetRun5.dimension.resolved || (widgetRun5 instanceof ChainRun) || (widgetRun5 instanceof GuidelineReference))) {
                                                                                            i3 = 0;
                                                                                        }
                                                                                        i14++;
                                                                                        obj3 = obj4;
                                                                                        list = list3;
                                                                                    } else {
                                                                                        i3 = 0;
                                                                                    }
                                                                                    dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                                    dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                                    measurer3 = measurer2;
                                                                                    i9 = 1;
                                                                                    i13 = 2;
                                                                                }
                                                                                i3 = 1;
                                                                                dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                                dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                                measurer3 = measurer2;
                                                                                i9 = 1;
                                                                                i13 = 2;
                                                                            }
                                                                        }
                                                                        i3 = constraintWidget9.getWidth() + size2;
                                                                        dependencyGraph2.container.horizontalRun.end.resolve(i3);
                                                                        dependencyGraph2.container.horizontalRun.dimension.resolve(i3 - size2);
                                                                        dependencyGraph2.measureWidgets();
                                                                        constraintWidget9 = dependencyGraph2.container;
                                                                        size2 = constraintWidget9.mListDimensionBehaviors$ar$edu[1];
                                                                        if (size2 == 1 || size2 == 4) {
                                                                            i3 = constraintWidget9.getHeight() + i14;
                                                                            dependencyGraph2.container.verticalRun.end.resolve(i3);
                                                                            dependencyGraph2.container.verticalRun.dimension.resolve(i3 - i14);
                                                                        }
                                                                        dependencyGraph2.measureWidgets();
                                                                        obj3 = 1;
                                                                        list = dependencyGraph2.mRuns;
                                                                        max2 = list.size();
                                                                        i14 = 0;
                                                                        while (i14 < max2) {
                                                                            widgetRun5 = (WidgetRun) list.get(i14);
                                                                            list2 = list;
                                                                            i10 = max2;
                                                                            if (widgetRun5.widget == dependencyGraph2.container) {
                                                                            }
                                                                            widgetRun5.applyToWidget();
                                                                            i14++;
                                                                            list = list2;
                                                                            max2 = i10;
                                                                        }
                                                                        list = dependencyGraph2.mRuns;
                                                                        max2 = list.size();
                                                                        i14 = 0;
                                                                        while (i14 < max2) {
                                                                            widgetRun5 = (WidgetRun) list.get(i14);
                                                                            if (obj3 != null) {
                                                                                obj4 = obj3;
                                                                                list3 = list;
                                                                            } else {
                                                                                obj4 = obj3;
                                                                                list3 = list;
                                                                                if (widgetRun5.widget == dependencyGraph2.container) {
                                                                                    i14++;
                                                                                    obj3 = obj4;
                                                                                    list = list3;
                                                                                }
                                                                            }
                                                                            if (widgetRun5.start.resolved) {
                                                                                if (widgetRun5.end.resolved) {
                                                                                }
                                                                                i3 = 0;
                                                                            } else {
                                                                                i3 = 0;
                                                                            }
                                                                            dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                            dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                            measurer3 = measurer2;
                                                                            i9 = 1;
                                                                            i13 = 2;
                                                                        }
                                                                        i3 = 1;
                                                                        dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                        dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                        measurer3 = measurer2;
                                                                        i9 = 1;
                                                                        i13 = 2;
                                                                    }
                                                                }
                                                                if (enabled) {
                                                                    i7 = i3;
                                                                } else {
                                                                    list4 = dependencyGraph2.mRuns;
                                                                    max4 = list4.size();
                                                                    i7 = i3;
                                                                    i3 = 0;
                                                                    while (i3 < max4) {
                                                                        i15 = i3 + 1;
                                                                        if (!((WidgetRun) list4.get(i3)).supportsWrapComputation()) {
                                                                            i3 = i15;
                                                                        }
                                                                    }
                                                                    if (mode == 2) {
                                                                        dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(1);
                                                                        constraintWidget9 = dependencyGraph2.container;
                                                                        constraintWidget9.setWidth(dependencyGraph2.computeWrap(constraintWidget9, 0));
                                                                        constraintWidget9 = dependencyGraph2.container;
                                                                        constraintWidget9.horizontalRun.dimension.resolve(constraintWidget9.getWidth());
                                                                        mode = 2;
                                                                    }
                                                                    if (mode2 == 2) {
                                                                        dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(1);
                                                                        constraintWidget9 = dependencyGraph2.container;
                                                                        constraintWidget9.setHeight(dependencyGraph2.computeWrap(constraintWidget9, 1));
                                                                        constraintWidget9 = dependencyGraph2.container;
                                                                        constraintWidget9.verticalRun.dimension.resolve(constraintWidget9.getHeight());
                                                                    }
                                                                }
                                                                constraintWidget9 = dependencyGraph2.container;
                                                                max2 = constraintWidget9.mListDimensionBehaviors$ar$edu[0];
                                                                if (max2 != 1) {
                                                                    if (max2 != 4) {
                                                                        obj3 = null;
                                                                        list = dependencyGraph2.mRuns;
                                                                        max2 = list.size();
                                                                        i14 = 0;
                                                                        while (i14 < max2) {
                                                                            widgetRun5 = (WidgetRun) list.get(i14);
                                                                            list2 = list;
                                                                            i10 = max2;
                                                                            if (widgetRun5.widget == dependencyGraph2.container) {
                                                                            }
                                                                            widgetRun5.applyToWidget();
                                                                            i14++;
                                                                            list = list2;
                                                                            max2 = i10;
                                                                        }
                                                                        list = dependencyGraph2.mRuns;
                                                                        max2 = list.size();
                                                                        i14 = 0;
                                                                        while (i14 < max2) {
                                                                            widgetRun5 = (WidgetRun) list.get(i14);
                                                                            if (obj3 != null) {
                                                                                obj4 = obj3;
                                                                                list3 = list;
                                                                                if (widgetRun5.widget == dependencyGraph2.container) {
                                                                                    i14++;
                                                                                    obj3 = obj4;
                                                                                    list = list3;
                                                                                }
                                                                            } else {
                                                                                obj4 = obj3;
                                                                                list3 = list;
                                                                            }
                                                                            if (widgetRun5.start.resolved) {
                                                                                i3 = 0;
                                                                            } else {
                                                                                if (widgetRun5.end.resolved) {
                                                                                }
                                                                                i3 = 0;
                                                                            }
                                                                            dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                            dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                            measurer3 = measurer2;
                                                                            i9 = 1;
                                                                            i13 = 2;
                                                                        }
                                                                        i3 = 1;
                                                                        dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                        dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                        measurer3 = measurer2;
                                                                        i9 = 1;
                                                                        i13 = 2;
                                                                    }
                                                                }
                                                                i3 = constraintWidget9.getWidth() + size2;
                                                                dependencyGraph2.container.horizontalRun.end.resolve(i3);
                                                                dependencyGraph2.container.horizontalRun.dimension.resolve(i3 - size2);
                                                                dependencyGraph2.measureWidgets();
                                                                constraintWidget9 = dependencyGraph2.container;
                                                                size2 = constraintWidget9.mListDimensionBehaviors$ar$edu[1];
                                                                i3 = constraintWidget9.getHeight() + i14;
                                                                dependencyGraph2.container.verticalRun.end.resolve(i3);
                                                                dependencyGraph2.container.verticalRun.dimension.resolve(i3 - i14);
                                                                dependencyGraph2.measureWidgets();
                                                                obj3 = 1;
                                                                list = dependencyGraph2.mRuns;
                                                                max2 = list.size();
                                                                i14 = 0;
                                                                while (i14 < max2) {
                                                                    widgetRun5 = (WidgetRun) list.get(i14);
                                                                    list2 = list;
                                                                    i10 = max2;
                                                                    if (widgetRun5.widget == dependencyGraph2.container) {
                                                                    }
                                                                    widgetRun5.applyToWidget();
                                                                    i14++;
                                                                    list = list2;
                                                                    max2 = i10;
                                                                }
                                                                list = dependencyGraph2.mRuns;
                                                                max2 = list.size();
                                                                i14 = 0;
                                                                while (i14 < max2) {
                                                                    widgetRun5 = (WidgetRun) list.get(i14);
                                                                    if (obj3 != null) {
                                                                        obj4 = obj3;
                                                                        list3 = list;
                                                                    } else {
                                                                        obj4 = obj3;
                                                                        list3 = list;
                                                                        if (widgetRun5.widget == dependencyGraph2.container) {
                                                                            i14++;
                                                                            obj3 = obj4;
                                                                            list = list3;
                                                                        }
                                                                    }
                                                                    if (widgetRun5.start.resolved) {
                                                                        if (widgetRun5.end.resolved) {
                                                                        }
                                                                        i3 = 0;
                                                                    } else {
                                                                        i3 = 0;
                                                                    }
                                                                    dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                    dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                    measurer3 = measurer2;
                                                                    i9 = 1;
                                                                    i13 = 2;
                                                                }
                                                                i3 = 1;
                                                                dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                measurer3 = measurer2;
                                                                i9 = 1;
                                                                i13 = 2;
                                                            }
                                                        }
                                                        List list5 = dependencyGraph2.container.mChildren;
                                                        mode2 = list5.size();
                                                        for (size2 = 0; size2 < mode2; size2++) {
                                                            ConstraintWidget constraintWidget10 = (ConstraintWidget) list5.get(size2);
                                                            constraintWidget10.ensureWidgetRuns();
                                                            constraintWidget10.measured = false;
                                                            constraintWidget10.horizontalRun.reset();
                                                            constraintWidget10.verticalRun.reset();
                                                        }
                                                        dependencyGraph2.container.ensureWidgetRuns();
                                                        constraintWidget8 = dependencyGraph2.container;
                                                        mode2 = 0;
                                                        constraintWidget8.measured = false;
                                                        constraintWidget8.horizontalRun.reset();
                                                        dependencyGraph2.container.verticalRun.reset();
                                                        dependencyGraph2.mNeedRedoMeasures = false;
                                                        dependencyGraph2.basicMeasureWidgets$ar$ds(dependencyGraph2.mContainer);
                                                        constraintWidget8 = dependencyGraph2.container;
                                                        constraintWidget8.f12mX = mode2;
                                                        constraintWidget8.f13mY = mode2;
                                                        mode = constraintWidget8.getDimensionBehaviour$ar$edu(mode2);
                                                        mode2 = dependencyGraph2.container.getDimensionBehaviour$ar$edu(1);
                                                        if (dependencyGraph2.mNeedBuildGraph) {
                                                            dependencyGraph2.buildGraph();
                                                        }
                                                        size2 = dependencyGraph2.container.getX();
                                                        i14 = dependencyGraph2.container.getY();
                                                        dependencyGraph2.container.horizontalRun.start.resolve(size2);
                                                        dependencyGraph2.container.verticalRun.start.resolve(i14);
                                                        dependencyGraph2.measureWidgets();
                                                        if (mode != 2) {
                                                            if (mode2 != 2) {
                                                                i7 = i3;
                                                                constraintWidget9 = dependencyGraph2.container;
                                                                max2 = constraintWidget9.mListDimensionBehaviors$ar$edu[0];
                                                                if (max2 != 1) {
                                                                    if (max2 != 4) {
                                                                        obj3 = null;
                                                                        list = dependencyGraph2.mRuns;
                                                                        max2 = list.size();
                                                                        i14 = 0;
                                                                        while (i14 < max2) {
                                                                            widgetRun5 = (WidgetRun) list.get(i14);
                                                                            list2 = list;
                                                                            i10 = max2;
                                                                            if (widgetRun5.widget == dependencyGraph2.container) {
                                                                            }
                                                                            widgetRun5.applyToWidget();
                                                                            i14++;
                                                                            list = list2;
                                                                            max2 = i10;
                                                                        }
                                                                        list = dependencyGraph2.mRuns;
                                                                        max2 = list.size();
                                                                        i14 = 0;
                                                                        while (i14 < max2) {
                                                                            widgetRun5 = (WidgetRun) list.get(i14);
                                                                            if (obj3 != null) {
                                                                                obj4 = obj3;
                                                                                list3 = list;
                                                                                if (widgetRun5.widget == dependencyGraph2.container) {
                                                                                    i14++;
                                                                                    obj3 = obj4;
                                                                                    list = list3;
                                                                                }
                                                                            } else {
                                                                                obj4 = obj3;
                                                                                list3 = list;
                                                                            }
                                                                            if (widgetRun5.start.resolved) {
                                                                                i3 = 0;
                                                                            } else {
                                                                                if (widgetRun5.end.resolved) {
                                                                                }
                                                                                i3 = 0;
                                                                            }
                                                                            dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                            dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                            measurer3 = measurer2;
                                                                            i9 = 1;
                                                                            i13 = 2;
                                                                        }
                                                                        i3 = 1;
                                                                        dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                        dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                        measurer3 = measurer2;
                                                                        i9 = 1;
                                                                        i13 = 2;
                                                                    }
                                                                }
                                                                i3 = constraintWidget9.getWidth() + size2;
                                                                dependencyGraph2.container.horizontalRun.end.resolve(i3);
                                                                dependencyGraph2.container.horizontalRun.dimension.resolve(i3 - size2);
                                                                dependencyGraph2.measureWidgets();
                                                                constraintWidget9 = dependencyGraph2.container;
                                                                size2 = constraintWidget9.mListDimensionBehaviors$ar$edu[1];
                                                                i3 = constraintWidget9.getHeight() + i14;
                                                                dependencyGraph2.container.verticalRun.end.resolve(i3);
                                                                dependencyGraph2.container.verticalRun.dimension.resolve(i3 - i14);
                                                                dependencyGraph2.measureWidgets();
                                                                obj3 = 1;
                                                                list = dependencyGraph2.mRuns;
                                                                max2 = list.size();
                                                                i14 = 0;
                                                                while (i14 < max2) {
                                                                    widgetRun5 = (WidgetRun) list.get(i14);
                                                                    list2 = list;
                                                                    i10 = max2;
                                                                    if (widgetRun5.widget == dependencyGraph2.container) {
                                                                    }
                                                                    widgetRun5.applyToWidget();
                                                                    i14++;
                                                                    list = list2;
                                                                    max2 = i10;
                                                                }
                                                                list = dependencyGraph2.mRuns;
                                                                max2 = list.size();
                                                                i14 = 0;
                                                                while (i14 < max2) {
                                                                    widgetRun5 = (WidgetRun) list.get(i14);
                                                                    if (obj3 != null) {
                                                                        obj4 = obj3;
                                                                        list3 = list;
                                                                    } else {
                                                                        obj4 = obj3;
                                                                        list3 = list;
                                                                        if (widgetRun5.widget == dependencyGraph2.container) {
                                                                            i14++;
                                                                            obj3 = obj4;
                                                                            list = list3;
                                                                        }
                                                                    }
                                                                    if (widgetRun5.start.resolved) {
                                                                        if (widgetRun5.end.resolved) {
                                                                        }
                                                                        i3 = 0;
                                                                    } else {
                                                                        i3 = 0;
                                                                    }
                                                                    dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                    dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                    measurer3 = measurer2;
                                                                    i9 = 1;
                                                                    i13 = 2;
                                                                }
                                                                i3 = 1;
                                                                dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                measurer3 = measurer2;
                                                                i9 = 1;
                                                                i13 = 2;
                                                            } else {
                                                                mode2 = 2;
                                                            }
                                                        }
                                                        if (enabled) {
                                                            i7 = i3;
                                                        } else {
                                                            list4 = dependencyGraph2.mRuns;
                                                            max4 = list4.size();
                                                            i7 = i3;
                                                            i3 = 0;
                                                            while (i3 < max4) {
                                                                i15 = i3 + 1;
                                                                if (!((WidgetRun) list4.get(i3)).supportsWrapComputation()) {
                                                                    i3 = i15;
                                                                }
                                                            }
                                                            if (mode == 2) {
                                                                dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(1);
                                                                constraintWidget9 = dependencyGraph2.container;
                                                                constraintWidget9.setWidth(dependencyGraph2.computeWrap(constraintWidget9, 0));
                                                                constraintWidget9 = dependencyGraph2.container;
                                                                constraintWidget9.horizontalRun.dimension.resolve(constraintWidget9.getWidth());
                                                                mode = 2;
                                                            }
                                                            if (mode2 == 2) {
                                                                dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(1);
                                                                constraintWidget9 = dependencyGraph2.container;
                                                                constraintWidget9.setHeight(dependencyGraph2.computeWrap(constraintWidget9, 1));
                                                                constraintWidget9 = dependencyGraph2.container;
                                                                constraintWidget9.verticalRun.dimension.resolve(constraintWidget9.getHeight());
                                                            }
                                                        }
                                                        constraintWidget9 = dependencyGraph2.container;
                                                        max2 = constraintWidget9.mListDimensionBehaviors$ar$edu[0];
                                                        if (max2 != 1) {
                                                            if (max2 != 4) {
                                                                obj3 = null;
                                                                list = dependencyGraph2.mRuns;
                                                                max2 = list.size();
                                                                i14 = 0;
                                                                while (i14 < max2) {
                                                                    widgetRun5 = (WidgetRun) list.get(i14);
                                                                    list2 = list;
                                                                    i10 = max2;
                                                                    if (widgetRun5.widget == dependencyGraph2.container) {
                                                                    }
                                                                    widgetRun5.applyToWidget();
                                                                    i14++;
                                                                    list = list2;
                                                                    max2 = i10;
                                                                }
                                                                list = dependencyGraph2.mRuns;
                                                                max2 = list.size();
                                                                i14 = 0;
                                                                while (i14 < max2) {
                                                                    widgetRun5 = (WidgetRun) list.get(i14);
                                                                    if (obj3 != null) {
                                                                        obj4 = obj3;
                                                                        list3 = list;
                                                                        if (widgetRun5.widget == dependencyGraph2.container) {
                                                                            i14++;
                                                                            obj3 = obj4;
                                                                            list = list3;
                                                                        }
                                                                    } else {
                                                                        obj4 = obj3;
                                                                        list3 = list;
                                                                    }
                                                                    if (widgetRun5.start.resolved) {
                                                                        i3 = 0;
                                                                    } else {
                                                                        if (widgetRun5.end.resolved) {
                                                                        }
                                                                        i3 = 0;
                                                                    }
                                                                    dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                    dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                    measurer3 = measurer2;
                                                                    i9 = 1;
                                                                    i13 = 2;
                                                                }
                                                                i3 = 1;
                                                                dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                                dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                                measurer3 = measurer2;
                                                                i9 = 1;
                                                                i13 = 2;
                                                            }
                                                        }
                                                        i3 = constraintWidget9.getWidth() + size2;
                                                        dependencyGraph2.container.horizontalRun.end.resolve(i3);
                                                        dependencyGraph2.container.horizontalRun.dimension.resolve(i3 - size2);
                                                        dependencyGraph2.measureWidgets();
                                                        constraintWidget9 = dependencyGraph2.container;
                                                        size2 = constraintWidget9.mListDimensionBehaviors$ar$edu[1];
                                                        i3 = constraintWidget9.getHeight() + i14;
                                                        dependencyGraph2.container.verticalRun.end.resolve(i3);
                                                        dependencyGraph2.container.verticalRun.dimension.resolve(i3 - i14);
                                                        dependencyGraph2.measureWidgets();
                                                        obj3 = 1;
                                                        list = dependencyGraph2.mRuns;
                                                        max2 = list.size();
                                                        i14 = 0;
                                                        while (i14 < max2) {
                                                            widgetRun5 = (WidgetRun) list.get(i14);
                                                            list2 = list;
                                                            i10 = max2;
                                                            if (widgetRun5.widget == dependencyGraph2.container) {
                                                            }
                                                            widgetRun5.applyToWidget();
                                                            i14++;
                                                            list = list2;
                                                            max2 = i10;
                                                        }
                                                        list = dependencyGraph2.mRuns;
                                                        max2 = list.size();
                                                        i14 = 0;
                                                        while (i14 < max2) {
                                                            widgetRun5 = (WidgetRun) list.get(i14);
                                                            if (obj3 != null) {
                                                                obj4 = obj3;
                                                                list3 = list;
                                                            } else {
                                                                obj4 = obj3;
                                                                list3 = list;
                                                                if (widgetRun5.widget == dependencyGraph2.container) {
                                                                    i14++;
                                                                    obj3 = obj4;
                                                                    list = list3;
                                                                }
                                                            }
                                                            if (widgetRun5.start.resolved) {
                                                                if (widgetRun5.end.resolved) {
                                                                }
                                                                i3 = 0;
                                                            } else {
                                                                i3 = 0;
                                                            }
                                                            dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                            dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                            measurer3 = measurer2;
                                                            i9 = 1;
                                                            i13 = 2;
                                                        }
                                                        i3 = 1;
                                                        dependencyGraph2.container.setHorizontalDimensionBehaviour$ar$edu(mode);
                                                        dependencyGraph2.container.setVerticalDimensionBehaviour$ar$edu(mode2);
                                                        measurer3 = measurer2;
                                                        i9 = 1;
                                                        i13 = 2;
                                                    }
                                                    if (i3 != 0) {
                                                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                                    }
                                                } else {
                                                    measurer3 = measurer2;
                                                    i7 = i3;
                                                    i13 = 0;
                                                    i3 = 0;
                                                }
                                                if (i3 == 0 || r2 != 2) {
                                                    i9 = constraintWidget7.mOptimizationLevel;
                                                    if (max5 > 0) {
                                                        i13 = constraintWidget7.mChildren.size();
                                                        optimizeFor = constraintWidget7.optimizeFor(64);
                                                        measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                                        for (size = 0; size < i13; size++) {
                                                            constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                                            if (constraintWidget3 instanceof Guideline) {
                                                                if (!(constraintWidget3 instanceof Barrier)) {
                                                                    z = constraintWidget3.mInVirtualLayout;
                                                                    if (optimizeFor) {
                                                                        widgetRun3 = constraintWidget3.horizontalRun;
                                                                        if (widgetRun3 != null) {
                                                                            widgetRun4 = constraintWidget3.verticalRun;
                                                                            if (widgetRun4 != null && widgetRun3.dimension.resolved) {
                                                                                if (widgetRun4.dimension.resolved) {
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                    max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                                    i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                                    if (max2 == 3) {
                                                                        obj2 = null;
                                                                    } else if (constraintWidget3.mMatchConstraintDefaultWidth != 1 || i14 != 3) {
                                                                        obj2 = null;
                                                                        max2 = 3;
                                                                    } else if (constraintWidget3.mMatchConstraintDefaultHeight != 1) {
                                                                        obj2 = 1;
                                                                        max2 = 3;
                                                                        i14 = 3;
                                                                    } else {
                                                                        obj2 = null;
                                                                        max2 = 3;
                                                                        i14 = 3;
                                                                    }
                                                                    if (obj2 == null) {
                                                                        if (constraintWidget7.optimizeFor(1)) {
                                                                            if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                                                if (max2 == 3 || constraintWidget3.mMatchConstraintDefaultWidth != 0 || i14 == 3 || constraintWidget3.isInHorizontalChain()) {
                                                                                    obj2 = null;
                                                                                } else {
                                                                                    obj2 = 1;
                                                                                }
                                                                                if (i14 == 3 && constraintWidget3.mMatchConstraintDefaultHeight == 0 && max2 != 3 && !constraintWidget3.isInHorizontalChain()) {
                                                                                    obj2 = 1;
                                                                                }
                                                                                if (max2 != 3) {
                                                                                    if (i14 == 3) {
                                                                                        if (obj2 != null) {
                                                                                        }
                                                                                    }
                                                                                }
                                                                                if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                                                }
                                                                                if (obj2 != null) {
                                                                                }
                                                                            }
                                                                        }
                                                                        basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        i13 = measurer4.layout.getChildCount();
                                                        while (i3 < i13) {
                                                            childAt = measurer4.layout.getChildAt(i3);
                                                            if (childAt instanceof Placeholder) {
                                                            } else {
                                                                placeholder = (Placeholder) childAt;
                                                                constraintLayout = measurer4.layout;
                                                                throw null;
                                                            }
                                                        }
                                                        i13 = measurer4.layout.mConstraintHelpers.size();
                                                        if (i13 > 0) {
                                                            for (i3 = 0; i3 < i13; i3++) {
                                                                constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                                                constraintLayout2 = measurer4.layout;
                                                            }
                                                        }
                                                    }
                                                    basicMeasure.updateHierarchy(constraintWidget7);
                                                    i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                                    if (max5 > 0) {
                                                        basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                                    }
                                                    if (i13 <= 0) {
                                                        max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                                        i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                                        mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                                        size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                                        mode = 0;
                                                        size = 0;
                                                        while (mode < i13) {
                                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                                i5 = i9;
                                                                measurer = measurer3;
                                                            } else {
                                                                max3 = constraintWidget4.getWidth();
                                                                max4 = constraintWidget4.getHeight();
                                                                i5 = i9;
                                                                measurer = measurer3;
                                                                i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                                                size = constraintWidget4.getWidth();
                                                                i11 = i9;
                                                                i9 = constraintWidget4.getHeight();
                                                                if (size != max3) {
                                                                    constraintWidget4.setWidth(size);
                                                                    if (max5 != 2 && constraintWidget4.getRight() > mode2) {
                                                                        mode2 = Math.max(mode2, constraintWidget4.getRight() + constraintWidget4.getAnchor$ar$edu(4).getMargin());
                                                                    }
                                                                    i11 = 1;
                                                                }
                                                                if (i9 != max4) {
                                                                    constraintWidget4.setHeight(i9);
                                                                    if (i3 != 2 && constraintWidget4.getBottom() > size2) {
                                                                        size2 = Math.max(size2, constraintWidget4.getBottom() + constraintWidget4.getAnchor$ar$edu(5).getMargin());
                                                                    }
                                                                    i11 = 1;
                                                                }
                                                                virtualLayout = (VirtualLayout) constraintWidget4;
                                                                size = i11;
                                                            }
                                                            mode++;
                                                            measurer3 = measurer;
                                                            i9 = i5;
                                                        }
                                                        i5 = i9;
                                                        measurer = measurer3;
                                                        i9 = 0;
                                                        while (i9 < 2) {
                                                            mode = 0;
                                                            while (mode < i13) {
                                                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                                if (constraintWidget4 instanceof HelperWidget) {
                                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                                        i11 = i13;
                                                                        constraintWidget5 = constraintWidget7;
                                                                        mode++;
                                                                        i13 = i11;
                                                                        constraintWidget7 = constraintWidget5;
                                                                    }
                                                                }
                                                                if (!(constraintWidget4 instanceof Guideline)) {
                                                                    if (constraintWidget4.mVisibility == 8) {
                                                                        if (i7 == 0 && constraintWidget4.horizontalRun.dimension.resolved && constraintWidget4.verticalRun.dimension.resolved) {
                                                                            i11 = i13;
                                                                            constraintWidget5 = constraintWidget7;
                                                                            mode++;
                                                                            i13 = i11;
                                                                            constraintWidget7 = constraintWidget5;
                                                                        } else {
                                                                            if (!(constraintWidget4 instanceof VirtualLayout)) {
                                                                                max3 = constraintWidget4.getWidth();
                                                                                max4 = constraintWidget4.getHeight();
                                                                                i11 = i13;
                                                                                i13 = constraintWidget4.mBaselineDistance;
                                                                                constraintWidget5 = constraintWidget7;
                                                                                childCount = 1;
                                                                                if (i9 == 1) {
                                                                                    childCount = 2;
                                                                                }
                                                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                                                size = constraintWidget4.getWidth();
                                                                                i10 = childCount;
                                                                                childCount = constraintWidget4.getHeight();
                                                                                if (size != max3) {
                                                                                    constraintWidget4.setWidth(size);
                                                                                    if (max5 != 2 && constraintWidget4.getRight() > mode2) {
                                                                                        mode2 = Math.max(mode2, constraintWidget4.getRight() + constraintWidget4.getAnchor$ar$edu(4).getMargin());
                                                                                    }
                                                                                    i10 = 1;
                                                                                }
                                                                                if (childCount != max4) {
                                                                                    constraintWidget4.setHeight(childCount);
                                                                                    if (i3 != 2 && constraintWidget4.getBottom() > size2) {
                                                                                        size2 = Math.max(size2, constraintWidget4.getBottom() + constraintWidget4.getAnchor$ar$edu(5).getMargin());
                                                                                    }
                                                                                    i10 = 1;
                                                                                }
                                                                                if (constraintWidget4.hasBaseline || i13 == constraintWidget4.mBaselineDistance) {
                                                                                    size = i10;
                                                                                    mode++;
                                                                                    i13 = i11;
                                                                                    constraintWidget7 = constraintWidget5;
                                                                                } else {
                                                                                    size = 1;
                                                                                    mode++;
                                                                                    i13 = i11;
                                                                                    constraintWidget7 = constraintWidget5;
                                                                                }
                                                                            }
                                                                            i11 = i13;
                                                                            constraintWidget5 = constraintWidget7;
                                                                            mode++;
                                                                            i13 = i11;
                                                                            constraintWidget7 = constraintWidget5;
                                                                        }
                                                                    }
                                                                }
                                                                i11 = i13;
                                                                constraintWidget5 = constraintWidget7;
                                                                mode++;
                                                                i13 = i11;
                                                                constraintWidget7 = constraintWidget5;
                                                            }
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            if (size == 0) {
                                                                i9++;
                                                                constraintWidget6 = constraintWidget5;
                                                                basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                                                constraintWidget7 = constraintWidget6;
                                                                i13 = i11;
                                                                size = 0;
                                                            } else {
                                                                constraintWidgetContainer2 = constraintWidget5;
                                                            }
                                                        }
                                                        constraintWidgetContainer2 = constraintWidget7;
                                                    } else {
                                                        i5 = i9;
                                                        constraintWidgetContainer2 = constraintWidget7;
                                                    }
                                                    constraintWidgetContainer2.setOptimizationLevel(i5);
                                                }
                                                i12 = this.mLayoutWidget.getWidth();
                                                i13 = this.mLayoutWidget.getHeight();
                                                constraintWidgetContainer = this.mLayoutWidget;
                                                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                                measurer5 = this.mMeasurer;
                                                i3 = measurer5.paddingHeight;
                                                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                                if (z2) {
                                                    i12 |= 16777216;
                                                }
                                                if (z3) {
                                                    i13 |= 16777216;
                                                }
                                                setMeasuredDimension(i12, i13);
                                            }
                                        }
                                        i3 = enabled ? 1 : 0;
                                        i3 = i6 & i3;
                                        if (i3 == 0) {
                                            measurer3 = measurer2;
                                            i7 = i3;
                                            i13 = 0;
                                            i3 = 0;
                                        } else {
                                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                            if (mode != 1073741824) {
                                            }
                                            constraintWidget7.setWidth(size);
                                            constraintWidget7.invalidateGraph();
                                            if (mode2 != 1073741824) {
                                            }
                                            constraintWidget7.setHeight(size2);
                                            constraintWidget7.invalidateGraph();
                                            if (mode == 1073741824) {
                                            }
                                            i7 = i3;
                                            dependencyGraph = constraintWidget7.mDependencyGraph;
                                            if (dependencyGraph.mNeedBuildGraph) {
                                                measurer3 = measurer2;
                                            } else {
                                                list = dependencyGraph.container.mChildren;
                                                i14 = list.size();
                                                max4 = 0;
                                                while (max4 < i14) {
                                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                                    constraintWidget2.ensureWidgetRuns();
                                                    list2 = list;
                                                    constraintWidget2.measured = false;
                                                    i8 = i14;
                                                    widgetRun = constraintWidget2.horizontalRun;
                                                    measurer3 = measurer2;
                                                    widgetRun.dimension.resolved = false;
                                                    widgetRun.resolved = false;
                                                    widgetRun.reset();
                                                    widgetRun2 = constraintWidget2.verticalRun;
                                                    widgetRun2.dimension.resolved = false;
                                                    widgetRun2.resolved = false;
                                                    widgetRun2.reset();
                                                    max4++;
                                                    i14 = i8;
                                                    list = list2;
                                                    measurer2 = measurer3;
                                                }
                                                measurer3 = measurer2;
                                                dependencyGraph.container.ensureWidgetRuns();
                                                constraintWidget2 = dependencyGraph.container;
                                                constraintWidget2.measured = false;
                                                widgetRun2 = constraintWidget2.horizontalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                widgetRun2 = dependencyGraph.container.verticalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                dependencyGraph.buildGraph();
                                            }
                                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                            constraintWidget2 = dependencyGraph.container;
                                            constraintWidget2.f12mX = 0;
                                            constraintWidget2.f13mY = 0;
                                            constraintWidget2.horizontalRun.start.resolve(0);
                                            dependencyGraph.container.verticalRun.start.resolve(0);
                                            if (mode != 1073741824) {
                                                i13 = 0;
                                                i3 = 1;
                                            } else {
                                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                                i13 = 1;
                                            }
                                            if (mode2 != 1073741824) {
                                                i9 = 1;
                                            } else {
                                                i9 = 1;
                                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                                i13++;
                                            }
                                            if (i3 != 0) {
                                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                            }
                                        }
                                        i9 = constraintWidget7.mOptimizationLevel;
                                        if (max5 > 0) {
                                            i13 = constraintWidget7.mChildren.size();
                                            optimizeFor = constraintWidget7.optimizeFor(64);
                                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                            for (size = 0; size < i13; size++) {
                                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                                if (constraintWidget3 instanceof Guideline) {
                                                    if (!(constraintWidget3 instanceof Barrier)) {
                                                        z = constraintWidget3.mInVirtualLayout;
                                                        if (optimizeFor) {
                                                            widgetRun3 = constraintWidget3.horizontalRun;
                                                            if (widgetRun3 != null) {
                                                                widgetRun4 = constraintWidget3.verticalRun;
                                                                if (widgetRun4.dimension.resolved) {
                                                                }
                                                            }
                                                        }
                                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                        if (max2 == 3) {
                                                            obj2 = null;
                                                        } else {
                                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                            }
                                                            obj2 = null;
                                                            max2 = 3;
                                                        }
                                                        if (obj2 == null) {
                                                            if (constraintWidget7.optimizeFor(1)) {
                                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                                    if (max2 == 3) {
                                                                    }
                                                                    obj2 = null;
                                                                    obj2 = 1;
                                                                    if (max2 != 3) {
                                                                        if (i14 == 3) {
                                                                            if (obj2 != null) {
                                                                            }
                                                                        }
                                                                    }
                                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                                    }
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                        }
                                                    }
                                                }
                                            }
                                            i13 = measurer4.layout.getChildCount();
                                            for (i3 = 0; i3 < i13; i3++) {
                                                childAt = measurer4.layout.getChildAt(i3);
                                                if (childAt instanceof Placeholder) {
                                                    placeholder = (Placeholder) childAt;
                                                    constraintLayout = measurer4.layout;
                                                    throw null;
                                                }
                                            }
                                            i13 = measurer4.layout.mConstraintHelpers.size();
                                            if (i13 > 0) {
                                                for (i3 = 0; i3 < i13; i3++) {
                                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                                    constraintLayout2 = measurer4.layout;
                                                }
                                            }
                                        }
                                        basicMeasure.updateHierarchy(constraintWidget7);
                                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                        if (max5 > 0) {
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                        }
                                        if (i13 <= 0) {
                                            i5 = i9;
                                            constraintWidgetContainer2 = constraintWidget7;
                                        } else {
                                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                            mode = 0;
                                            size = 0;
                                            while (mode < i13) {
                                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    max3 = constraintWidget4.getWidth();
                                                    max4 = constraintWidget4.getHeight();
                                                    i5 = i9;
                                                    measurer = measurer3;
                                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                                    size = constraintWidget4.getWidth();
                                                    i11 = i9;
                                                    i9 = constraintWidget4.getHeight();
                                                    if (size != max3) {
                                                        constraintWidget4.setWidth(size);
                                                        if (max5 != 2) {
                                                        }
                                                        i11 = 1;
                                                    }
                                                    if (i9 != max4) {
                                                        constraintWidget4.setHeight(i9);
                                                        if (i3 != 2) {
                                                        }
                                                        i11 = 1;
                                                    }
                                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                                    size = i11;
                                                } else {
                                                    i5 = i9;
                                                    measurer = measurer3;
                                                }
                                                mode++;
                                                measurer3 = measurer;
                                                i9 = i5;
                                            }
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = 0;
                                            while (i9 < 2) {
                                                mode = 0;
                                                while (mode < i13) {
                                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                    if (constraintWidget4 instanceof HelperWidget) {
                                                        if (constraintWidget4 instanceof VirtualLayout) {
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                    }
                                                    if (constraintWidget4 instanceof Guideline) {
                                                        if (constraintWidget4.mVisibility == 8) {
                                                            if (i7 == 0) {
                                                            }
                                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                                max3 = constraintWidget4.getWidth();
                                                                max4 = constraintWidget4.getHeight();
                                                                i11 = i13;
                                                                i13 = constraintWidget4.mBaselineDistance;
                                                                constraintWidget5 = constraintWidget7;
                                                                childCount = 1;
                                                                if (i9 == 1) {
                                                                    childCount = 2;
                                                                }
                                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                                size = constraintWidget4.getWidth();
                                                                i10 = childCount;
                                                                childCount = constraintWidget4.getHeight();
                                                                if (size != max3) {
                                                                    constraintWidget4.setWidth(size);
                                                                    if (max5 != 2) {
                                                                    }
                                                                    i10 = 1;
                                                                }
                                                                if (childCount != max4) {
                                                                    constraintWidget4.setHeight(childCount);
                                                                    if (i3 != 2) {
                                                                    }
                                                                    i10 = 1;
                                                                }
                                                                if (constraintWidget4.hasBaseline) {
                                                                }
                                                                size = i10;
                                                                mode++;
                                                                i13 = i11;
                                                                constraintWidget7 = constraintWidget5;
                                                            }
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                                i11 = i13;
                                                constraintWidget5 = constraintWidget7;
                                                if (size == 0) {
                                                    constraintWidgetContainer2 = constraintWidget5;
                                                } else {
                                                    i9++;
                                                    constraintWidget6 = constraintWidget5;
                                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                                    constraintWidget7 = constraintWidget6;
                                                    i13 = i11;
                                                    size = 0;
                                                }
                                            }
                                            constraintWidgetContainer2 = constraintWidget7;
                                        }
                                        constraintWidgetContainer2.setOptimizationLevel(i5);
                                        i12 = this.mLayoutWidget.getWidth();
                                        i13 = this.mLayoutWidget.getHeight();
                                        constraintWidgetContainer = this.mLayoutWidget;
                                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                        measurer5 = this.mMeasurer;
                                        i3 = measurer5.paddingHeight;
                                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                        if (z2) {
                                            i12 |= 16777216;
                                        }
                                        if (z3) {
                                            i13 |= 16777216;
                                        }
                                        setMeasuredDimension(i12, i13);
                                    }
                                    obj = null;
                                }
                                if (constraintWidget.isInVerticalChain() || r0 == null) {
                                    if (constraintWidget instanceof VirtualLayout) {
                                        if (constraintWidget.isInHorizontalChain()) {
                                            if (!constraintWidget.isInVerticalChain()) {
                                                i14++;
                                                constraintLayout = this;
                                                i3 = i6;
                                            }
                                        }
                                        i6 = 0;
                                    } else {
                                        i6 = 0;
                                    }
                                    if (mode == 1073741824) {
                                        if (mode2 != 1073741824) {
                                            i3 = 1;
                                            mode = 1073741824;
                                            mode2 = 1073741824;
                                            i3 = i6 & i3;
                                            if (i3 == 0) {
                                                size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                                size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                                if (mode != 1073741824) {
                                                }
                                                constraintWidget7.setWidth(size);
                                                constraintWidget7.invalidateGraph();
                                                if (mode2 != 1073741824) {
                                                }
                                                constraintWidget7.setHeight(size2);
                                                constraintWidget7.invalidateGraph();
                                                if (mode == 1073741824) {
                                                }
                                                i7 = i3;
                                                dependencyGraph = constraintWidget7.mDependencyGraph;
                                                if (dependencyGraph.mNeedBuildGraph) {
                                                    list = dependencyGraph.container.mChildren;
                                                    i14 = list.size();
                                                    max4 = 0;
                                                    while (max4 < i14) {
                                                        constraintWidget2 = (ConstraintWidget) list.get(max4);
                                                        constraintWidget2.ensureWidgetRuns();
                                                        list2 = list;
                                                        constraintWidget2.measured = false;
                                                        i8 = i14;
                                                        widgetRun = constraintWidget2.horizontalRun;
                                                        measurer3 = measurer2;
                                                        widgetRun.dimension.resolved = false;
                                                        widgetRun.resolved = false;
                                                        widgetRun.reset();
                                                        widgetRun2 = constraintWidget2.verticalRun;
                                                        widgetRun2.dimension.resolved = false;
                                                        widgetRun2.resolved = false;
                                                        widgetRun2.reset();
                                                        max4++;
                                                        i14 = i8;
                                                        list = list2;
                                                        measurer2 = measurer3;
                                                    }
                                                    measurer3 = measurer2;
                                                    dependencyGraph.container.ensureWidgetRuns();
                                                    constraintWidget2 = dependencyGraph.container;
                                                    constraintWidget2.measured = false;
                                                    widgetRun2 = constraintWidget2.horizontalRun;
                                                    widgetRun2.dimension.resolved = false;
                                                    widgetRun2.resolved = false;
                                                    widgetRun2.reset();
                                                    widgetRun2 = dependencyGraph.container.verticalRun;
                                                    widgetRun2.dimension.resolved = false;
                                                    widgetRun2.resolved = false;
                                                    widgetRun2.reset();
                                                    dependencyGraph.buildGraph();
                                                } else {
                                                    measurer3 = measurer2;
                                                }
                                                dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                                constraintWidget2 = dependencyGraph.container;
                                                constraintWidget2.f12mX = 0;
                                                constraintWidget2.f13mY = 0;
                                                constraintWidget2.horizontalRun.start.resolve(0);
                                                dependencyGraph.container.verticalRun.start.resolve(0);
                                                if (mode != 1073741824) {
                                                    i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                                    i13 = 1;
                                                } else {
                                                    i13 = 0;
                                                    i3 = 1;
                                                }
                                                if (mode2 != 1073741824) {
                                                    i9 = 1;
                                                    i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                                    i13++;
                                                } else {
                                                    i9 = 1;
                                                }
                                                if (i3 != 0) {
                                                    constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                                }
                                            } else {
                                                measurer3 = measurer2;
                                                i7 = i3;
                                                i13 = 0;
                                                i3 = 0;
                                            }
                                            i9 = constraintWidget7.mOptimizationLevel;
                                            if (max5 > 0) {
                                                i13 = constraintWidget7.mChildren.size();
                                                optimizeFor = constraintWidget7.optimizeFor(64);
                                                measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                                for (size = 0; size < i13; size++) {
                                                    constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                                    if (constraintWidget3 instanceof Guideline) {
                                                        if (!(constraintWidget3 instanceof Barrier)) {
                                                            z = constraintWidget3.mInVirtualLayout;
                                                            if (optimizeFor) {
                                                                widgetRun3 = constraintWidget3.horizontalRun;
                                                                if (widgetRun3 != null) {
                                                                    widgetRun4 = constraintWidget3.verticalRun;
                                                                    if (widgetRun4.dimension.resolved) {
                                                                    }
                                                                }
                                                            }
                                                            max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                            i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                            if (max2 == 3) {
                                                                if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                                }
                                                                obj2 = null;
                                                                max2 = 3;
                                                            } else {
                                                                obj2 = null;
                                                            }
                                                            if (obj2 == null) {
                                                                if (constraintWidget7.optimizeFor(1)) {
                                                                    if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                                        if (max2 == 3) {
                                                                        }
                                                                        obj2 = null;
                                                                        obj2 = 1;
                                                                        if (max2 != 3) {
                                                                            if (i14 == 3) {
                                                                                if (obj2 != null) {
                                                                                }
                                                                            }
                                                                        }
                                                                        if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                                        }
                                                                        if (obj2 != null) {
                                                                        }
                                                                    }
                                                                }
                                                                basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                            }
                                                        }
                                                    }
                                                }
                                                i13 = measurer4.layout.getChildCount();
                                                while (i3 < i13) {
                                                    childAt = measurer4.layout.getChildAt(i3);
                                                    if (childAt instanceof Placeholder) {
                                                    } else {
                                                        placeholder = (Placeholder) childAt;
                                                        constraintLayout = measurer4.layout;
                                                        throw null;
                                                    }
                                                }
                                                i13 = measurer4.layout.mConstraintHelpers.size();
                                                if (i13 > 0) {
                                                    for (i3 = 0; i3 < i13; i3++) {
                                                        constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                                        constraintLayout2 = measurer4.layout;
                                                    }
                                                }
                                            }
                                            basicMeasure.updateHierarchy(constraintWidget7);
                                            i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                            if (max5 > 0) {
                                                basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                            }
                                            if (i13 <= 0) {
                                                max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                                i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                                mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                                size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                                mode = 0;
                                                size = 0;
                                                while (mode < i13) {
                                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        i5 = i9;
                                                        measurer = measurer3;
                                                    } else {
                                                        max3 = constraintWidget4.getWidth();
                                                        max4 = constraintWidget4.getHeight();
                                                        i5 = i9;
                                                        measurer = measurer3;
                                                        i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                                        size = constraintWidget4.getWidth();
                                                        i11 = i9;
                                                        i9 = constraintWidget4.getHeight();
                                                        if (size != max3) {
                                                            constraintWidget4.setWidth(size);
                                                            if (max5 != 2) {
                                                            }
                                                            i11 = 1;
                                                        }
                                                        if (i9 != max4) {
                                                            constraintWidget4.setHeight(i9);
                                                            if (i3 != 2) {
                                                            }
                                                            i11 = 1;
                                                        }
                                                        virtualLayout = (VirtualLayout) constraintWidget4;
                                                        size = i11;
                                                    }
                                                    mode++;
                                                    measurer3 = measurer;
                                                    i9 = i5;
                                                }
                                                i5 = i9;
                                                measurer = measurer3;
                                                i9 = 0;
                                                while (i9 < 2) {
                                                    mode = 0;
                                                    while (mode < i13) {
                                                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                        if (constraintWidget4 instanceof HelperWidget) {
                                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                                i11 = i13;
                                                                constraintWidget5 = constraintWidget7;
                                                                mode++;
                                                                i13 = i11;
                                                                constraintWidget7 = constraintWidget5;
                                                            }
                                                        }
                                                        if (constraintWidget4 instanceof Guideline) {
                                                            if (constraintWidget4.mVisibility == 8) {
                                                                if (i7 == 0) {
                                                                }
                                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                                    max3 = constraintWidget4.getWidth();
                                                                    max4 = constraintWidget4.getHeight();
                                                                    i11 = i13;
                                                                    i13 = constraintWidget4.mBaselineDistance;
                                                                    constraintWidget5 = constraintWidget7;
                                                                    childCount = 1;
                                                                    if (i9 == 1) {
                                                                        childCount = 2;
                                                                    }
                                                                    childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                                    size = constraintWidget4.getWidth();
                                                                    i10 = childCount;
                                                                    childCount = constraintWidget4.getHeight();
                                                                    if (size != max3) {
                                                                        constraintWidget4.setWidth(size);
                                                                        if (max5 != 2) {
                                                                        }
                                                                        i10 = 1;
                                                                    }
                                                                    if (childCount != max4) {
                                                                        constraintWidget4.setHeight(childCount);
                                                                        if (i3 != 2) {
                                                                        }
                                                                        i10 = 1;
                                                                    }
                                                                    if (constraintWidget4.hasBaseline) {
                                                                    }
                                                                    size = i10;
                                                                    mode++;
                                                                    i13 = i11;
                                                                    constraintWidget7 = constraintWidget5;
                                                                }
                                                                i11 = i13;
                                                                constraintWidget5 = constraintWidget7;
                                                                mode++;
                                                                i13 = i11;
                                                                constraintWidget7 = constraintWidget5;
                                                            }
                                                        }
                                                        i11 = i13;
                                                        constraintWidget5 = constraintWidget7;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    if (size == 0) {
                                                        i9++;
                                                        constraintWidget6 = constraintWidget5;
                                                        basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                                        constraintWidget7 = constraintWidget6;
                                                        i13 = i11;
                                                        size = 0;
                                                    } else {
                                                        constraintWidgetContainer2 = constraintWidget5;
                                                    }
                                                }
                                                constraintWidgetContainer2 = constraintWidget7;
                                            } else {
                                                i5 = i9;
                                                constraintWidgetContainer2 = constraintWidget7;
                                            }
                                            constraintWidgetContainer2.setOptimizationLevel(i5);
                                            i12 = this.mLayoutWidget.getWidth();
                                            i13 = this.mLayoutWidget.getHeight();
                                            constraintWidgetContainer = this.mLayoutWidget;
                                            z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                            z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                            measurer5 = this.mMeasurer;
                                            i3 = measurer5.paddingHeight;
                                            i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                            i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                            i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                            i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                            if (z2) {
                                                i12 |= 16777216;
                                            }
                                            if (z3) {
                                                i13 |= 16777216;
                                            }
                                            setMeasuredDimension(i12, i13);
                                        }
                                        mode = 1073741824;
                                    }
                                    if (enabled) {
                                    }
                                    i3 = i6 & i3;
                                    if (i3 == 0) {
                                        measurer3 = measurer2;
                                        i7 = i3;
                                        i13 = 0;
                                        i3 = 0;
                                    } else {
                                        size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                        size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                        if (mode != 1073741824) {
                                        }
                                        constraintWidget7.setWidth(size);
                                        constraintWidget7.invalidateGraph();
                                        if (mode2 != 1073741824) {
                                        }
                                        constraintWidget7.setHeight(size2);
                                        constraintWidget7.invalidateGraph();
                                        if (mode == 1073741824) {
                                        }
                                        i7 = i3;
                                        dependencyGraph = constraintWidget7.mDependencyGraph;
                                        if (dependencyGraph.mNeedBuildGraph) {
                                            measurer3 = measurer2;
                                        } else {
                                            list = dependencyGraph.container.mChildren;
                                            i14 = list.size();
                                            max4 = 0;
                                            while (max4 < i14) {
                                                constraintWidget2 = (ConstraintWidget) list.get(max4);
                                                constraintWidget2.ensureWidgetRuns();
                                                list2 = list;
                                                constraintWidget2.measured = false;
                                                i8 = i14;
                                                widgetRun = constraintWidget2.horizontalRun;
                                                measurer3 = measurer2;
                                                widgetRun.dimension.resolved = false;
                                                widgetRun.resolved = false;
                                                widgetRun.reset();
                                                widgetRun2 = constraintWidget2.verticalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                max4++;
                                                i14 = i8;
                                                list = list2;
                                                measurer2 = measurer3;
                                            }
                                            measurer3 = measurer2;
                                            dependencyGraph.container.ensureWidgetRuns();
                                            constraintWidget2 = dependencyGraph.container;
                                            constraintWidget2.measured = false;
                                            widgetRun2 = constraintWidget2.horizontalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            widgetRun2 = dependencyGraph.container.verticalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            dependencyGraph.buildGraph();
                                        }
                                        dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                        constraintWidget2 = dependencyGraph.container;
                                        constraintWidget2.f12mX = 0;
                                        constraintWidget2.f13mY = 0;
                                        constraintWidget2.horizontalRun.start.resolve(0);
                                        dependencyGraph.container.verticalRun.start.resolve(0);
                                        if (mode != 1073741824) {
                                            i13 = 0;
                                            i3 = 1;
                                        } else {
                                            i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                            i13 = 1;
                                        }
                                        if (mode2 != 1073741824) {
                                            i9 = 1;
                                        } else {
                                            i9 = 1;
                                            i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                            i13++;
                                        }
                                        if (i3 != 0) {
                                            constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                        }
                                    }
                                    i9 = constraintWidget7.mOptimizationLevel;
                                    if (max5 > 0) {
                                        i13 = constraintWidget7.mChildren.size();
                                        optimizeFor = constraintWidget7.optimizeFor(64);
                                        measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                        for (size = 0; size < i13; size++) {
                                            constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                            if (constraintWidget3 instanceof Guideline) {
                                                if (!(constraintWidget3 instanceof Barrier)) {
                                                    z = constraintWidget3.mInVirtualLayout;
                                                    if (optimizeFor) {
                                                        widgetRun3 = constraintWidget3.horizontalRun;
                                                        if (widgetRun3 != null) {
                                                            widgetRun4 = constraintWidget3.verticalRun;
                                                            if (widgetRun4.dimension.resolved) {
                                                            }
                                                        }
                                                    }
                                                    max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                    i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                    if (max2 == 3) {
                                                        obj2 = null;
                                                    } else {
                                                        if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                        }
                                                        obj2 = null;
                                                        max2 = 3;
                                                    }
                                                    if (obj2 == null) {
                                                        if (constraintWidget7.optimizeFor(1)) {
                                                            if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                                if (max2 == 3) {
                                                                }
                                                                obj2 = null;
                                                                obj2 = 1;
                                                                if (max2 != 3) {
                                                                    if (i14 == 3) {
                                                                        if (obj2 != null) {
                                                                        }
                                                                    }
                                                                }
                                                                if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                                }
                                                                if (obj2 != null) {
                                                                }
                                                            }
                                                        }
                                                        basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                    }
                                                }
                                            }
                                        }
                                        i13 = measurer4.layout.getChildCount();
                                        for (i3 = 0; i3 < i13; i3++) {
                                            childAt = measurer4.layout.getChildAt(i3);
                                            if (childAt instanceof Placeholder) {
                                                placeholder = (Placeholder) childAt;
                                                constraintLayout = measurer4.layout;
                                                throw null;
                                            }
                                        }
                                        i13 = measurer4.layout.mConstraintHelpers.size();
                                        if (i13 > 0) {
                                            for (i3 = 0; i3 < i13; i3++) {
                                                constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                                constraintLayout2 = measurer4.layout;
                                            }
                                        }
                                    }
                                    basicMeasure.updateHierarchy(constraintWidget7);
                                    i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                    if (max5 > 0) {
                                        basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                    }
                                    if (i13 <= 0) {
                                        i5 = i9;
                                        constraintWidgetContainer2 = constraintWidget7;
                                    } else {
                                        max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                        i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                        mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                        size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                        mode = 0;
                                        size = 0;
                                        while (mode < i13) {
                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                max3 = constraintWidget4.getWidth();
                                                max4 = constraintWidget4.getHeight();
                                                i5 = i9;
                                                measurer = measurer3;
                                                i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                                size = constraintWidget4.getWidth();
                                                i11 = i9;
                                                i9 = constraintWidget4.getHeight();
                                                if (size != max3) {
                                                    constraintWidget4.setWidth(size);
                                                    if (max5 != 2) {
                                                    }
                                                    i11 = 1;
                                                }
                                                if (i9 != max4) {
                                                    constraintWidget4.setHeight(i9);
                                                    if (i3 != 2) {
                                                    }
                                                    i11 = 1;
                                                }
                                                virtualLayout = (VirtualLayout) constraintWidget4;
                                                size = i11;
                                            } else {
                                                i5 = i9;
                                                measurer = measurer3;
                                            }
                                            mode++;
                                            measurer3 = measurer;
                                            i9 = i5;
                                        }
                                        i5 = i9;
                                        measurer = measurer3;
                                        i9 = 0;
                                        while (i9 < 2) {
                                            mode = 0;
                                            while (mode < i13) {
                                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                if (constraintWidget4 instanceof HelperWidget) {
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        i11 = i13;
                                                        constraintWidget5 = constraintWidget7;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                }
                                                if (constraintWidget4 instanceof Guideline) {
                                                    if (constraintWidget4.mVisibility == 8) {
                                                        if (i7 == 0) {
                                                        }
                                                        if (constraintWidget4 instanceof VirtualLayout) {
                                                            max3 = constraintWidget4.getWidth();
                                                            max4 = constraintWidget4.getHeight();
                                                            i11 = i13;
                                                            i13 = constraintWidget4.mBaselineDistance;
                                                            constraintWidget5 = constraintWidget7;
                                                            childCount = 1;
                                                            if (i9 == 1) {
                                                                childCount = 2;
                                                            }
                                                            childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                            size = constraintWidget4.getWidth();
                                                            i10 = childCount;
                                                            childCount = constraintWidget4.getHeight();
                                                            if (size != max3) {
                                                                constraintWidget4.setWidth(size);
                                                                if (max5 != 2) {
                                                                }
                                                                i10 = 1;
                                                            }
                                                            if (childCount != max4) {
                                                                constraintWidget4.setHeight(childCount);
                                                                if (i3 != 2) {
                                                                }
                                                                i10 = 1;
                                                            }
                                                            if (constraintWidget4.hasBaseline) {
                                                            }
                                                            size = i10;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                        i11 = i13;
                                                        constraintWidget5 = constraintWidget7;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                }
                                                i11 = i13;
                                                constraintWidget5 = constraintWidget7;
                                                mode++;
                                                i13 = i11;
                                                constraintWidget7 = constraintWidget5;
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            if (size == 0) {
                                                constraintWidgetContainer2 = constraintWidget5;
                                            } else {
                                                i9++;
                                                constraintWidget6 = constraintWidget5;
                                                basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                                constraintWidget7 = constraintWidget6;
                                                i13 = i11;
                                                size = 0;
                                            }
                                        }
                                        constraintWidgetContainer2 = constraintWidget7;
                                    }
                                    constraintWidgetContainer2.setOptimizationLevel(i5);
                                    i12 = this.mLayoutWidget.getWidth();
                                    i13 = this.mLayoutWidget.getHeight();
                                    constraintWidgetContainer = this.mLayoutWidget;
                                    z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                    z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                    measurer5 = this.mMeasurer;
                                    i3 = measurer5.paddingHeight;
                                    i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                    i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                    i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                    i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                    if (z2) {
                                        i12 |= 16777216;
                                    }
                                    if (z3) {
                                        i13 |= 16777216;
                                    }
                                    setMeasuredDimension(i12, i13);
                                }
                                i6 = 0;
                                if (mode == 1073741824) {
                                    if (mode2 != 1073741824) {
                                        mode = 1073741824;
                                    } else {
                                        i3 = 1;
                                        mode = 1073741824;
                                        mode2 = 1073741824;
                                        i3 = i6 & i3;
                                        if (i3 == 0) {
                                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                            if (mode != 1073741824) {
                                            }
                                            constraintWidget7.setWidth(size);
                                            constraintWidget7.invalidateGraph();
                                            if (mode2 != 1073741824) {
                                            }
                                            constraintWidget7.setHeight(size2);
                                            constraintWidget7.invalidateGraph();
                                            if (mode == 1073741824) {
                                            }
                                            i7 = i3;
                                            dependencyGraph = constraintWidget7.mDependencyGraph;
                                            if (dependencyGraph.mNeedBuildGraph) {
                                                list = dependencyGraph.container.mChildren;
                                                i14 = list.size();
                                                max4 = 0;
                                                while (max4 < i14) {
                                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                                    constraintWidget2.ensureWidgetRuns();
                                                    list2 = list;
                                                    constraintWidget2.measured = false;
                                                    i8 = i14;
                                                    widgetRun = constraintWidget2.horizontalRun;
                                                    measurer3 = measurer2;
                                                    widgetRun.dimension.resolved = false;
                                                    widgetRun.resolved = false;
                                                    widgetRun.reset();
                                                    widgetRun2 = constraintWidget2.verticalRun;
                                                    widgetRun2.dimension.resolved = false;
                                                    widgetRun2.resolved = false;
                                                    widgetRun2.reset();
                                                    max4++;
                                                    i14 = i8;
                                                    list = list2;
                                                    measurer2 = measurer3;
                                                }
                                                measurer3 = measurer2;
                                                dependencyGraph.container.ensureWidgetRuns();
                                                constraintWidget2 = dependencyGraph.container;
                                                constraintWidget2.measured = false;
                                                widgetRun2 = constraintWidget2.horizontalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                widgetRun2 = dependencyGraph.container.verticalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                dependencyGraph.buildGraph();
                                            } else {
                                                measurer3 = measurer2;
                                            }
                                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                            constraintWidget2 = dependencyGraph.container;
                                            constraintWidget2.f12mX = 0;
                                            constraintWidget2.f13mY = 0;
                                            constraintWidget2.horizontalRun.start.resolve(0);
                                            dependencyGraph.container.verticalRun.start.resolve(0);
                                            if (mode != 1073741824) {
                                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                                i13 = 1;
                                            } else {
                                                i13 = 0;
                                                i3 = 1;
                                            }
                                            if (mode2 != 1073741824) {
                                                i9 = 1;
                                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                                i13++;
                                            } else {
                                                i9 = 1;
                                            }
                                            if (i3 != 0) {
                                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                            }
                                        } else {
                                            measurer3 = measurer2;
                                            i7 = i3;
                                            i13 = 0;
                                            i3 = 0;
                                        }
                                        i9 = constraintWidget7.mOptimizationLevel;
                                        if (max5 > 0) {
                                            i13 = constraintWidget7.mChildren.size();
                                            optimizeFor = constraintWidget7.optimizeFor(64);
                                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                            for (size = 0; size < i13; size++) {
                                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                                if (constraintWidget3 instanceof Guideline) {
                                                    if (!(constraintWidget3 instanceof Barrier)) {
                                                        z = constraintWidget3.mInVirtualLayout;
                                                        if (optimizeFor) {
                                                            widgetRun3 = constraintWidget3.horizontalRun;
                                                            if (widgetRun3 != null) {
                                                                widgetRun4 = constraintWidget3.verticalRun;
                                                                if (widgetRun4.dimension.resolved) {
                                                                }
                                                            }
                                                        }
                                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                        if (max2 == 3) {
                                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                            }
                                                            obj2 = null;
                                                            max2 = 3;
                                                        } else {
                                                            obj2 = null;
                                                        }
                                                        if (obj2 == null) {
                                                            if (constraintWidget7.optimizeFor(1)) {
                                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                                    if (max2 == 3) {
                                                                    }
                                                                    obj2 = null;
                                                                    obj2 = 1;
                                                                    if (max2 != 3) {
                                                                        if (i14 == 3) {
                                                                            if (obj2 != null) {
                                                                            }
                                                                        }
                                                                    }
                                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                                    }
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                        }
                                                    }
                                                }
                                            }
                                            i13 = measurer4.layout.getChildCount();
                                            while (i3 < i13) {
                                                childAt = measurer4.layout.getChildAt(i3);
                                                if (childAt instanceof Placeholder) {
                                                } else {
                                                    placeholder = (Placeholder) childAt;
                                                    constraintLayout = measurer4.layout;
                                                    throw null;
                                                }
                                            }
                                            i13 = measurer4.layout.mConstraintHelpers.size();
                                            if (i13 > 0) {
                                                for (i3 = 0; i3 < i13; i3++) {
                                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                                    constraintLayout2 = measurer4.layout;
                                                }
                                            }
                                        }
                                        basicMeasure.updateHierarchy(constraintWidget7);
                                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                        if (max5 > 0) {
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                        }
                                        if (i13 <= 0) {
                                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                            mode = 0;
                                            size = 0;
                                            while (mode < i13) {
                                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i5 = i9;
                                                    measurer = measurer3;
                                                } else {
                                                    max3 = constraintWidget4.getWidth();
                                                    max4 = constraintWidget4.getHeight();
                                                    i5 = i9;
                                                    measurer = measurer3;
                                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                                    size = constraintWidget4.getWidth();
                                                    i11 = i9;
                                                    i9 = constraintWidget4.getHeight();
                                                    if (size != max3) {
                                                        constraintWidget4.setWidth(size);
                                                        if (max5 != 2) {
                                                        }
                                                        i11 = 1;
                                                    }
                                                    if (i9 != max4) {
                                                        constraintWidget4.setHeight(i9);
                                                        if (i3 != 2) {
                                                        }
                                                        i11 = 1;
                                                    }
                                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                                    size = i11;
                                                }
                                                mode++;
                                                measurer3 = measurer;
                                                i9 = i5;
                                            }
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = 0;
                                            while (i9 < 2) {
                                                mode = 0;
                                                while (mode < i13) {
                                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                    if (constraintWidget4 instanceof HelperWidget) {
                                                        if (constraintWidget4 instanceof VirtualLayout) {
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                    }
                                                    if (constraintWidget4 instanceof Guideline) {
                                                        if (constraintWidget4.mVisibility == 8) {
                                                            if (i7 == 0) {
                                                            }
                                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                                max3 = constraintWidget4.getWidth();
                                                                max4 = constraintWidget4.getHeight();
                                                                i11 = i13;
                                                                i13 = constraintWidget4.mBaselineDistance;
                                                                constraintWidget5 = constraintWidget7;
                                                                childCount = 1;
                                                                if (i9 == 1) {
                                                                    childCount = 2;
                                                                }
                                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                                size = constraintWidget4.getWidth();
                                                                i10 = childCount;
                                                                childCount = constraintWidget4.getHeight();
                                                                if (size != max3) {
                                                                    constraintWidget4.setWidth(size);
                                                                    if (max5 != 2) {
                                                                    }
                                                                    i10 = 1;
                                                                }
                                                                if (childCount != max4) {
                                                                    constraintWidget4.setHeight(childCount);
                                                                    if (i3 != 2) {
                                                                    }
                                                                    i10 = 1;
                                                                }
                                                                if (constraintWidget4.hasBaseline) {
                                                                }
                                                                size = i10;
                                                                mode++;
                                                                i13 = i11;
                                                                constraintWidget7 = constraintWidget5;
                                                            }
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                                i11 = i13;
                                                constraintWidget5 = constraintWidget7;
                                                if (size == 0) {
                                                    i9++;
                                                    constraintWidget6 = constraintWidget5;
                                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                                    constraintWidget7 = constraintWidget6;
                                                    i13 = i11;
                                                    size = 0;
                                                } else {
                                                    constraintWidgetContainer2 = constraintWidget5;
                                                }
                                            }
                                            constraintWidgetContainer2 = constraintWidget7;
                                        } else {
                                            i5 = i9;
                                            constraintWidgetContainer2 = constraintWidget7;
                                        }
                                        constraintWidgetContainer2.setOptimizationLevel(i5);
                                        i12 = this.mLayoutWidget.getWidth();
                                        i13 = this.mLayoutWidget.getHeight();
                                        constraintWidgetContainer = this.mLayoutWidget;
                                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                        measurer5 = this.mMeasurer;
                                        i3 = measurer5.paddingHeight;
                                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                        if (z2) {
                                            i12 |= 16777216;
                                        }
                                        if (z3) {
                                            i13 |= 16777216;
                                        }
                                        setMeasuredDimension(i12, i13);
                                    }
                                }
                                if (enabled) {
                                }
                                i3 = i6 & i3;
                                if (i3 == 0) {
                                    measurer3 = measurer2;
                                    i7 = i3;
                                    i13 = 0;
                                    i3 = 0;
                                } else {
                                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                    if (mode != 1073741824) {
                                    }
                                    constraintWidget7.setWidth(size);
                                    constraintWidget7.invalidateGraph();
                                    if (mode2 != 1073741824) {
                                    }
                                    constraintWidget7.setHeight(size2);
                                    constraintWidget7.invalidateGraph();
                                    if (mode == 1073741824) {
                                    }
                                    i7 = i3;
                                    dependencyGraph = constraintWidget7.mDependencyGraph;
                                    if (dependencyGraph.mNeedBuildGraph) {
                                        measurer3 = measurer2;
                                    } else {
                                        list = dependencyGraph.container.mChildren;
                                        i14 = list.size();
                                        max4 = 0;
                                        while (max4 < i14) {
                                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                                            constraintWidget2.ensureWidgetRuns();
                                            list2 = list;
                                            constraintWidget2.measured = false;
                                            i8 = i14;
                                            widgetRun = constraintWidget2.horizontalRun;
                                            measurer3 = measurer2;
                                            widgetRun.dimension.resolved = false;
                                            widgetRun.resolved = false;
                                            widgetRun.reset();
                                            widgetRun2 = constraintWidget2.verticalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            max4++;
                                            i14 = i8;
                                            list = list2;
                                            measurer2 = measurer3;
                                        }
                                        measurer3 = measurer2;
                                        dependencyGraph.container.ensureWidgetRuns();
                                        constraintWidget2 = dependencyGraph.container;
                                        constraintWidget2.measured = false;
                                        widgetRun2 = constraintWidget2.horizontalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        widgetRun2 = dependencyGraph.container.verticalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        dependencyGraph.buildGraph();
                                    }
                                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                    constraintWidget2 = dependencyGraph.container;
                                    constraintWidget2.f12mX = 0;
                                    constraintWidget2.f13mY = 0;
                                    constraintWidget2.horizontalRun.start.resolve(0);
                                    dependencyGraph.container.verticalRun.start.resolve(0);
                                    if (mode != 1073741824) {
                                        i13 = 0;
                                        i3 = 1;
                                    } else {
                                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                        i13 = 1;
                                    }
                                    if (mode2 != 1073741824) {
                                        i9 = 1;
                                    } else {
                                        i9 = 1;
                                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                        i13++;
                                    }
                                    if (i3 != 0) {
                                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                    }
                                }
                                i9 = constraintWidget7.mOptimizationLevel;
                                if (max5 > 0) {
                                    i13 = constraintWidget7.mChildren.size();
                                    optimizeFor = constraintWidget7.optimizeFor(64);
                                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                    for (size = 0; size < i13; size++) {
                                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                        if (constraintWidget3 instanceof Guideline) {
                                            if (!(constraintWidget3 instanceof Barrier)) {
                                                z = constraintWidget3.mInVirtualLayout;
                                                if (optimizeFor) {
                                                    widgetRun3 = constraintWidget3.horizontalRun;
                                                    if (widgetRun3 != null) {
                                                        widgetRun4 = constraintWidget3.verticalRun;
                                                        if (widgetRun4.dimension.resolved) {
                                                        }
                                                    }
                                                }
                                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                if (max2 == 3) {
                                                    obj2 = null;
                                                } else {
                                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                    }
                                                    obj2 = null;
                                                    max2 = 3;
                                                }
                                                if (obj2 == null) {
                                                    if (constraintWidget7.optimizeFor(1)) {
                                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                            if (max2 == 3) {
                                                            }
                                                            obj2 = null;
                                                            obj2 = 1;
                                                            if (max2 != 3) {
                                                                if (i14 == 3) {
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                            }
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                }
                                            }
                                        }
                                    }
                                    i13 = measurer4.layout.getChildCount();
                                    for (i3 = 0; i3 < i13; i3++) {
                                        childAt = measurer4.layout.getChildAt(i3);
                                        if (childAt instanceof Placeholder) {
                                            placeholder = (Placeholder) childAt;
                                            constraintLayout = measurer4.layout;
                                            throw null;
                                        }
                                    }
                                    i13 = measurer4.layout.mConstraintHelpers.size();
                                    if (i13 > 0) {
                                        for (i3 = 0; i3 < i13; i3++) {
                                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                            constraintLayout2 = measurer4.layout;
                                        }
                                    }
                                }
                                basicMeasure.updateHierarchy(constraintWidget7);
                                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                if (max5 > 0) {
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                }
                                if (i13 <= 0) {
                                    i5 = i9;
                                    constraintWidgetContainer2 = constraintWidget7;
                                } else {
                                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                    mode = 0;
                                    size = 0;
                                    while (mode < i13) {
                                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            max3 = constraintWidget4.getWidth();
                                            max4 = constraintWidget4.getHeight();
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                            size = constraintWidget4.getWidth();
                                            i11 = i9;
                                            i9 = constraintWidget4.getHeight();
                                            if (size != max3) {
                                                constraintWidget4.setWidth(size);
                                                if (max5 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            if (i9 != max4) {
                                                constraintWidget4.setHeight(i9);
                                                if (i3 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            virtualLayout = (VirtualLayout) constraintWidget4;
                                            size = i11;
                                        } else {
                                            i5 = i9;
                                            measurer = measurer3;
                                        }
                                        mode++;
                                        measurer3 = measurer;
                                        i9 = i5;
                                    }
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = 0;
                                    while (i9 < 2) {
                                        mode = 0;
                                        while (mode < i13) {
                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                            if (constraintWidget4 instanceof HelperWidget) {
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            if (constraintWidget4 instanceof Guideline) {
                                                if (constraintWidget4.mVisibility == 8) {
                                                    if (i7 == 0) {
                                                    }
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        max3 = constraintWidget4.getWidth();
                                                        max4 = constraintWidget4.getHeight();
                                                        i11 = i13;
                                                        i13 = constraintWidget4.mBaselineDistance;
                                                        constraintWidget5 = constraintWidget7;
                                                        childCount = 1;
                                                        if (i9 == 1) {
                                                            childCount = 2;
                                                        }
                                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                        size = constraintWidget4.getWidth();
                                                        i10 = childCount;
                                                        childCount = constraintWidget4.getHeight();
                                                        if (size != max3) {
                                                            constraintWidget4.setWidth(size);
                                                            if (max5 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (childCount != max4) {
                                                            constraintWidget4.setHeight(childCount);
                                                            if (i3 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (constraintWidget4.hasBaseline) {
                                                        }
                                                        size = i10;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                        i11 = i13;
                                        constraintWidget5 = constraintWidget7;
                                        if (size == 0) {
                                            constraintWidgetContainer2 = constraintWidget5;
                                        } else {
                                            i9++;
                                            constraintWidget6 = constraintWidget5;
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                            constraintWidget7 = constraintWidget6;
                                            i13 = i11;
                                            size = 0;
                                        }
                                    }
                                    constraintWidgetContainer2 = constraintWidget7;
                                }
                                constraintWidgetContainer2.setOptimizationLevel(i5);
                                i12 = this.mLayoutWidget.getWidth();
                                i13 = this.mLayoutWidget.getHeight();
                                constraintWidgetContainer = this.mLayoutWidget;
                                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                measurer5 = this.mMeasurer;
                                i3 = measurer5.paddingHeight;
                                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                if (z2) {
                                    i12 |= 16777216;
                                }
                                if (z3) {
                                    i13 |= 16777216;
                                }
                                setMeasuredDimension(i12, i13);
                            }
                        }
                        i6 = i3;
                        if (mode == 1073741824) {
                            if (mode2 != 1073741824) {
                                i3 = 1;
                                mode = 1073741824;
                                mode2 = 1073741824;
                                i3 = i6 & i3;
                                if (i3 == 0) {
                                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                    if (mode != 1073741824) {
                                    }
                                    constraintWidget7.setWidth(size);
                                    constraintWidget7.invalidateGraph();
                                    if (mode2 != 1073741824) {
                                    }
                                    constraintWidget7.setHeight(size2);
                                    constraintWidget7.invalidateGraph();
                                    if (mode == 1073741824) {
                                    }
                                    i7 = i3;
                                    dependencyGraph = constraintWidget7.mDependencyGraph;
                                    if (dependencyGraph.mNeedBuildGraph) {
                                        list = dependencyGraph.container.mChildren;
                                        i14 = list.size();
                                        max4 = 0;
                                        while (max4 < i14) {
                                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                                            constraintWidget2.ensureWidgetRuns();
                                            list2 = list;
                                            constraintWidget2.measured = false;
                                            i8 = i14;
                                            widgetRun = constraintWidget2.horizontalRun;
                                            measurer3 = measurer2;
                                            widgetRun.dimension.resolved = false;
                                            widgetRun.resolved = false;
                                            widgetRun.reset();
                                            widgetRun2 = constraintWidget2.verticalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            max4++;
                                            i14 = i8;
                                            list = list2;
                                            measurer2 = measurer3;
                                        }
                                        measurer3 = measurer2;
                                        dependencyGraph.container.ensureWidgetRuns();
                                        constraintWidget2 = dependencyGraph.container;
                                        constraintWidget2.measured = false;
                                        widgetRun2 = constraintWidget2.horizontalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        widgetRun2 = dependencyGraph.container.verticalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        dependencyGraph.buildGraph();
                                    } else {
                                        measurer3 = measurer2;
                                    }
                                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                    constraintWidget2 = dependencyGraph.container;
                                    constraintWidget2.f12mX = 0;
                                    constraintWidget2.f13mY = 0;
                                    constraintWidget2.horizontalRun.start.resolve(0);
                                    dependencyGraph.container.verticalRun.start.resolve(0);
                                    if (mode != 1073741824) {
                                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                        i13 = 1;
                                    } else {
                                        i13 = 0;
                                        i3 = 1;
                                    }
                                    if (mode2 != 1073741824) {
                                        i9 = 1;
                                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                        i13++;
                                    } else {
                                        i9 = 1;
                                    }
                                    if (i3 != 0) {
                                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                    }
                                } else {
                                    measurer3 = measurer2;
                                    i7 = i3;
                                    i13 = 0;
                                    i3 = 0;
                                }
                                i9 = constraintWidget7.mOptimizationLevel;
                                if (max5 > 0) {
                                    i13 = constraintWidget7.mChildren.size();
                                    optimizeFor = constraintWidget7.optimizeFor(64);
                                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                    for (size = 0; size < i13; size++) {
                                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                        if (constraintWidget3 instanceof Guideline) {
                                            if (!(constraintWidget3 instanceof Barrier)) {
                                                z = constraintWidget3.mInVirtualLayout;
                                                if (optimizeFor) {
                                                    widgetRun3 = constraintWidget3.horizontalRun;
                                                    if (widgetRun3 != null) {
                                                        widgetRun4 = constraintWidget3.verticalRun;
                                                        if (widgetRun4.dimension.resolved) {
                                                        }
                                                    }
                                                }
                                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                if (max2 == 3) {
                                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                    }
                                                    obj2 = null;
                                                    max2 = 3;
                                                } else {
                                                    obj2 = null;
                                                }
                                                if (obj2 == null) {
                                                    if (constraintWidget7.optimizeFor(1)) {
                                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                            if (max2 == 3) {
                                                            }
                                                            obj2 = null;
                                                            obj2 = 1;
                                                            if (max2 != 3) {
                                                                if (i14 == 3) {
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                            }
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                }
                                            }
                                        }
                                    }
                                    i13 = measurer4.layout.getChildCount();
                                    while (i3 < i13) {
                                        childAt = measurer4.layout.getChildAt(i3);
                                        if (childAt instanceof Placeholder) {
                                        } else {
                                            placeholder = (Placeholder) childAt;
                                            constraintLayout = measurer4.layout;
                                            throw null;
                                        }
                                    }
                                    i13 = measurer4.layout.mConstraintHelpers.size();
                                    if (i13 > 0) {
                                        for (i3 = 0; i3 < i13; i3++) {
                                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                            constraintLayout2 = measurer4.layout;
                                        }
                                    }
                                }
                                basicMeasure.updateHierarchy(constraintWidget7);
                                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                if (max5 > 0) {
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                }
                                if (i13 <= 0) {
                                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                    mode = 0;
                                    size = 0;
                                    while (mode < i13) {
                                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i5 = i9;
                                            measurer = measurer3;
                                        } else {
                                            max3 = constraintWidget4.getWidth();
                                            max4 = constraintWidget4.getHeight();
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                            size = constraintWidget4.getWidth();
                                            i11 = i9;
                                            i9 = constraintWidget4.getHeight();
                                            if (size != max3) {
                                                constraintWidget4.setWidth(size);
                                                if (max5 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            if (i9 != max4) {
                                                constraintWidget4.setHeight(i9);
                                                if (i3 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            virtualLayout = (VirtualLayout) constraintWidget4;
                                            size = i11;
                                        }
                                        mode++;
                                        measurer3 = measurer;
                                        i9 = i5;
                                    }
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = 0;
                                    while (i9 < 2) {
                                        mode = 0;
                                        while (mode < i13) {
                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                            if (constraintWidget4 instanceof HelperWidget) {
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            if (constraintWidget4 instanceof Guideline) {
                                                if (constraintWidget4.mVisibility == 8) {
                                                    if (i7 == 0) {
                                                    }
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        max3 = constraintWidget4.getWidth();
                                                        max4 = constraintWidget4.getHeight();
                                                        i11 = i13;
                                                        i13 = constraintWidget4.mBaselineDistance;
                                                        constraintWidget5 = constraintWidget7;
                                                        childCount = 1;
                                                        if (i9 == 1) {
                                                            childCount = 2;
                                                        }
                                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                        size = constraintWidget4.getWidth();
                                                        i10 = childCount;
                                                        childCount = constraintWidget4.getHeight();
                                                        if (size != max3) {
                                                            constraintWidget4.setWidth(size);
                                                            if (max5 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (childCount != max4) {
                                                            constraintWidget4.setHeight(childCount);
                                                            if (i3 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (constraintWidget4.hasBaseline) {
                                                        }
                                                        size = i10;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                        i11 = i13;
                                        constraintWidget5 = constraintWidget7;
                                        if (size == 0) {
                                            i9++;
                                            constraintWidget6 = constraintWidget5;
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                            constraintWidget7 = constraintWidget6;
                                            i13 = i11;
                                            size = 0;
                                        } else {
                                            constraintWidgetContainer2 = constraintWidget5;
                                        }
                                    }
                                    constraintWidgetContainer2 = constraintWidget7;
                                } else {
                                    i5 = i9;
                                    constraintWidgetContainer2 = constraintWidget7;
                                }
                                constraintWidgetContainer2.setOptimizationLevel(i5);
                                i12 = this.mLayoutWidget.getWidth();
                                i13 = this.mLayoutWidget.getHeight();
                                constraintWidgetContainer = this.mLayoutWidget;
                                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                measurer5 = this.mMeasurer;
                                i3 = measurer5.paddingHeight;
                                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                if (z2) {
                                    i12 |= 16777216;
                                }
                                if (z3) {
                                    i13 |= 16777216;
                                }
                                setMeasuredDimension(i12, i13);
                            }
                            mode = 1073741824;
                        }
                        if (enabled) {
                        }
                        i3 = i6 & i3;
                        if (i3 == 0) {
                            measurer3 = measurer2;
                            i7 = i3;
                            i13 = 0;
                            i3 = 0;
                        } else {
                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                            if (mode != 1073741824) {
                            }
                            constraintWidget7.setWidth(size);
                            constraintWidget7.invalidateGraph();
                            if (mode2 != 1073741824) {
                            }
                            constraintWidget7.setHeight(size2);
                            constraintWidget7.invalidateGraph();
                            if (mode == 1073741824) {
                            }
                            i7 = i3;
                            dependencyGraph = constraintWidget7.mDependencyGraph;
                            if (dependencyGraph.mNeedBuildGraph) {
                                measurer3 = measurer2;
                            } else {
                                list = dependencyGraph.container.mChildren;
                                i14 = list.size();
                                max4 = 0;
                                while (max4 < i14) {
                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                    constraintWidget2.ensureWidgetRuns();
                                    list2 = list;
                                    constraintWidget2.measured = false;
                                    i8 = i14;
                                    widgetRun = constraintWidget2.horizontalRun;
                                    measurer3 = measurer2;
                                    widgetRun.dimension.resolved = false;
                                    widgetRun.resolved = false;
                                    widgetRun.reset();
                                    widgetRun2 = constraintWidget2.verticalRun;
                                    widgetRun2.dimension.resolved = false;
                                    widgetRun2.resolved = false;
                                    widgetRun2.reset();
                                    max4++;
                                    i14 = i8;
                                    list = list2;
                                    measurer2 = measurer3;
                                }
                                measurer3 = measurer2;
                                dependencyGraph.container.ensureWidgetRuns();
                                constraintWidget2 = dependencyGraph.container;
                                constraintWidget2.measured = false;
                                widgetRun2 = constraintWidget2.horizontalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                widgetRun2 = dependencyGraph.container.verticalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                dependencyGraph.buildGraph();
                            }
                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                            constraintWidget2 = dependencyGraph.container;
                            constraintWidget2.f12mX = 0;
                            constraintWidget2.f13mY = 0;
                            constraintWidget2.horizontalRun.start.resolve(0);
                            dependencyGraph.container.verticalRun.start.resolve(0);
                            if (mode != 1073741824) {
                                i13 = 0;
                                i3 = 1;
                            } else {
                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                i13 = 1;
                            }
                            if (mode2 != 1073741824) {
                                i9 = 1;
                            } else {
                                i9 = 1;
                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                i13++;
                            }
                            if (i3 != 0) {
                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                            }
                        }
                        i9 = constraintWidget7.mOptimizationLevel;
                        if (max5 > 0) {
                            i13 = constraintWidget7.mChildren.size();
                            optimizeFor = constraintWidget7.optimizeFor(64);
                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                            for (size = 0; size < i13; size++) {
                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                if (constraintWidget3 instanceof Guideline) {
                                    if (!(constraintWidget3 instanceof Barrier)) {
                                        z = constraintWidget3.mInVirtualLayout;
                                        if (optimizeFor) {
                                            widgetRun3 = constraintWidget3.horizontalRun;
                                            if (widgetRun3 != null) {
                                                widgetRun4 = constraintWidget3.verticalRun;
                                                if (widgetRun4.dimension.resolved) {
                                                }
                                            }
                                        }
                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                        if (max2 == 3) {
                                            obj2 = null;
                                        } else {
                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                            }
                                            obj2 = null;
                                            max2 = 3;
                                        }
                                        if (obj2 == null) {
                                            if (constraintWidget7.optimizeFor(1)) {
                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                    if (max2 == 3) {
                                                    }
                                                    obj2 = null;
                                                    obj2 = 1;
                                                    if (max2 != 3) {
                                                        if (i14 == 3) {
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                    }
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                        }
                                    }
                                }
                            }
                            i13 = measurer4.layout.getChildCount();
                            for (i3 = 0; i3 < i13; i3++) {
                                childAt = measurer4.layout.getChildAt(i3);
                                if (childAt instanceof Placeholder) {
                                    placeholder = (Placeholder) childAt;
                                    constraintLayout = measurer4.layout;
                                    throw null;
                                }
                            }
                            i13 = measurer4.layout.mConstraintHelpers.size();
                            if (i13 > 0) {
                                for (i3 = 0; i3 < i13; i3++) {
                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                    constraintLayout2 = measurer4.layout;
                                }
                            }
                        }
                        basicMeasure.updateHierarchy(constraintWidget7);
                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                        if (max5 > 0) {
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                        }
                        if (i13 <= 0) {
                            i5 = i9;
                            constraintWidgetContainer2 = constraintWidget7;
                        } else {
                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                            mode = 0;
                            size = 0;
                            while (mode < i13) {
                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    max3 = constraintWidget4.getWidth();
                                    max4 = constraintWidget4.getHeight();
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                    size = constraintWidget4.getWidth();
                                    i11 = i9;
                                    i9 = constraintWidget4.getHeight();
                                    if (size != max3) {
                                        constraintWidget4.setWidth(size);
                                        if (max5 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    if (i9 != max4) {
                                        constraintWidget4.setHeight(i9);
                                        if (i3 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                    size = i11;
                                } else {
                                    i5 = i9;
                                    measurer = measurer3;
                                }
                                mode++;
                                measurer3 = measurer;
                                i9 = i5;
                            }
                            i5 = i9;
                            measurer = measurer3;
                            i9 = 0;
                            while (i9 < 2) {
                                mode = 0;
                                while (mode < i13) {
                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                    if (constraintWidget4 instanceof HelperWidget) {
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    if (constraintWidget4 instanceof Guideline) {
                                        if (constraintWidget4.mVisibility == 8) {
                                            if (i7 == 0) {
                                            }
                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                max3 = constraintWidget4.getWidth();
                                                max4 = constraintWidget4.getHeight();
                                                i11 = i13;
                                                i13 = constraintWidget4.mBaselineDistance;
                                                constraintWidget5 = constraintWidget7;
                                                childCount = 1;
                                                if (i9 == 1) {
                                                    childCount = 2;
                                                }
                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                size = constraintWidget4.getWidth();
                                                i10 = childCount;
                                                childCount = constraintWidget4.getHeight();
                                                if (size != max3) {
                                                    constraintWidget4.setWidth(size);
                                                    if (max5 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (childCount != max4) {
                                                    constraintWidget4.setHeight(childCount);
                                                    if (i3 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (constraintWidget4.hasBaseline) {
                                                }
                                                size = i10;
                                                mode++;
                                                i13 = i11;
                                                constraintWidget7 = constraintWidget5;
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                                i11 = i13;
                                constraintWidget5 = constraintWidget7;
                                if (size == 0) {
                                    constraintWidgetContainer2 = constraintWidget5;
                                } else {
                                    i9++;
                                    constraintWidget6 = constraintWidget5;
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                    constraintWidget7 = constraintWidget6;
                                    i13 = i11;
                                    size = 0;
                                }
                            }
                            constraintWidgetContainer2 = constraintWidget7;
                        }
                        constraintWidgetContainer2.setOptimizationLevel(i5);
                        i12 = this.mLayoutWidget.getWidth();
                        i13 = this.mLayoutWidget.getHeight();
                        constraintWidgetContainer = this.mLayoutWidget;
                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                        measurer5 = this.mMeasurer;
                        i3 = measurer5.paddingHeight;
                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                        if (z2) {
                            i12 |= 16777216;
                        }
                        if (z3) {
                            i13 |= 16777216;
                        }
                        setMeasuredDimension(i12, i13);
                    }
                }
                constraintWidget7.mDependencyGraph.mNeedRedoMeasures = true;
                constraintWidget7.f12mX = 0;
                constraintWidget7.f13mY = 0;
                i13 = r0.mMaxWidth;
                iArr = constraintWidget7.mMaxDimension;
                iArr[0] = i13 - max2;
                iArr[1] = r0.mMaxHeight - i14;
                constraintWidget7.setMinWidth(0);
                constraintWidget7.setMinHeight(0);
                constraintWidget7.setHorizontalDimensionBehaviour$ar$edu(i4);
                constraintWidget7.setWidth(max4);
                constraintWidget7.setVerticalDimensionBehaviour$ar$edu(i5);
                constraintWidget7.setHeight(max3);
                constraintWidget7.setMinWidth(r0.mMinWidth - max2);
                constraintWidget7.setMinHeight(r0.mMinHeight - i14);
                constraintWidget7.mPaddingLeft = max5;
                constraintWidget7.mPaddingTop = max;
                basicMeasure = constraintWidget7.mBasicMeasureSolver;
                measurer2 = constraintWidget7.mMeasurer$ar$class_merging;
                max5 = constraintWidget7.mChildren.size();
                width = constraintWidget7.getWidth();
                max = constraintWidget7.getHeight();
                enabled = Optimizer.enabled(i3, 128);
                if (enabled) {
                }
                if (i3 != 0) {
                    i14 = 0;
                    while (i14 < max5) {
                        constraintWidget = (ConstraintWidget) constraintWidget7.mChildren.get(i14);
                        max4 = constraintWidget.getHorizontalDimensionBehaviour$ar$edu();
                        i6 = i3;
                        i3 = constraintWidget.getVerticalDimensionBehaviour$ar$edu();
                        if (max4 == 3) {
                        }
                        obj = null;
                        if (constraintWidget.isInHorizontalChain()) {
                            if (obj == null) {
                                obj = null;
                            } else {
                                i6 = 0;
                                if (mode == 1073741824) {
                                    if (mode2 != 1073741824) {
                                        mode = 1073741824;
                                    } else {
                                        i3 = 1;
                                        mode = 1073741824;
                                        mode2 = 1073741824;
                                        i3 = i6 & i3;
                                        if (i3 == 0) {
                                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                            if (mode != 1073741824) {
                                            }
                                            constraintWidget7.setWidth(size);
                                            constraintWidget7.invalidateGraph();
                                            if (mode2 != 1073741824) {
                                            }
                                            constraintWidget7.setHeight(size2);
                                            constraintWidget7.invalidateGraph();
                                            if (mode == 1073741824) {
                                            }
                                            i7 = i3;
                                            dependencyGraph = constraintWidget7.mDependencyGraph;
                                            if (dependencyGraph.mNeedBuildGraph) {
                                                list = dependencyGraph.container.mChildren;
                                                i14 = list.size();
                                                max4 = 0;
                                                while (max4 < i14) {
                                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                                    constraintWidget2.ensureWidgetRuns();
                                                    list2 = list;
                                                    constraintWidget2.measured = false;
                                                    i8 = i14;
                                                    widgetRun = constraintWidget2.horizontalRun;
                                                    measurer3 = measurer2;
                                                    widgetRun.dimension.resolved = false;
                                                    widgetRun.resolved = false;
                                                    widgetRun.reset();
                                                    widgetRun2 = constraintWidget2.verticalRun;
                                                    widgetRun2.dimension.resolved = false;
                                                    widgetRun2.resolved = false;
                                                    widgetRun2.reset();
                                                    max4++;
                                                    i14 = i8;
                                                    list = list2;
                                                    measurer2 = measurer3;
                                                }
                                                measurer3 = measurer2;
                                                dependencyGraph.container.ensureWidgetRuns();
                                                constraintWidget2 = dependencyGraph.container;
                                                constraintWidget2.measured = false;
                                                widgetRun2 = constraintWidget2.horizontalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                widgetRun2 = dependencyGraph.container.verticalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                dependencyGraph.buildGraph();
                                            } else {
                                                measurer3 = measurer2;
                                            }
                                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                            constraintWidget2 = dependencyGraph.container;
                                            constraintWidget2.f12mX = 0;
                                            constraintWidget2.f13mY = 0;
                                            constraintWidget2.horizontalRun.start.resolve(0);
                                            dependencyGraph.container.verticalRun.start.resolve(0);
                                            if (mode != 1073741824) {
                                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                                i13 = 1;
                                            } else {
                                                i13 = 0;
                                                i3 = 1;
                                            }
                                            if (mode2 != 1073741824) {
                                                i9 = 1;
                                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                                i13++;
                                            } else {
                                                i9 = 1;
                                            }
                                            if (i3 != 0) {
                                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                            }
                                        } else {
                                            measurer3 = measurer2;
                                            i7 = i3;
                                            i13 = 0;
                                            i3 = 0;
                                        }
                                        i9 = constraintWidget7.mOptimizationLevel;
                                        if (max5 > 0) {
                                            i13 = constraintWidget7.mChildren.size();
                                            optimizeFor = constraintWidget7.optimizeFor(64);
                                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                            for (size = 0; size < i13; size++) {
                                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                                if (constraintWidget3 instanceof Guideline) {
                                                    if (!(constraintWidget3 instanceof Barrier)) {
                                                        z = constraintWidget3.mInVirtualLayout;
                                                        if (optimizeFor) {
                                                            widgetRun3 = constraintWidget3.horizontalRun;
                                                            if (widgetRun3 != null) {
                                                                widgetRun4 = constraintWidget3.verticalRun;
                                                                if (widgetRun4.dimension.resolved) {
                                                                }
                                                            }
                                                        }
                                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                        if (max2 == 3) {
                                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                            }
                                                            obj2 = null;
                                                            max2 = 3;
                                                        } else {
                                                            obj2 = null;
                                                        }
                                                        if (obj2 == null) {
                                                            if (constraintWidget7.optimizeFor(1)) {
                                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                                    if (max2 == 3) {
                                                                    }
                                                                    obj2 = null;
                                                                    obj2 = 1;
                                                                    if (max2 != 3) {
                                                                        if (i14 == 3) {
                                                                            if (obj2 != null) {
                                                                            }
                                                                        }
                                                                    }
                                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                                    }
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                        }
                                                    }
                                                }
                                            }
                                            i13 = measurer4.layout.getChildCount();
                                            while (i3 < i13) {
                                                childAt = measurer4.layout.getChildAt(i3);
                                                if (childAt instanceof Placeholder) {
                                                } else {
                                                    placeholder = (Placeholder) childAt;
                                                    constraintLayout = measurer4.layout;
                                                    throw null;
                                                }
                                            }
                                            i13 = measurer4.layout.mConstraintHelpers.size();
                                            if (i13 > 0) {
                                                for (i3 = 0; i3 < i13; i3++) {
                                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                                    constraintLayout2 = measurer4.layout;
                                                }
                                            }
                                        }
                                        basicMeasure.updateHierarchy(constraintWidget7);
                                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                        if (max5 > 0) {
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                        }
                                        if (i13 <= 0) {
                                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                            mode = 0;
                                            size = 0;
                                            while (mode < i13) {
                                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i5 = i9;
                                                    measurer = measurer3;
                                                } else {
                                                    max3 = constraintWidget4.getWidth();
                                                    max4 = constraintWidget4.getHeight();
                                                    i5 = i9;
                                                    measurer = measurer3;
                                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                                    size = constraintWidget4.getWidth();
                                                    i11 = i9;
                                                    i9 = constraintWidget4.getHeight();
                                                    if (size != max3) {
                                                        constraintWidget4.setWidth(size);
                                                        if (max5 != 2) {
                                                        }
                                                        i11 = 1;
                                                    }
                                                    if (i9 != max4) {
                                                        constraintWidget4.setHeight(i9);
                                                        if (i3 != 2) {
                                                        }
                                                        i11 = 1;
                                                    }
                                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                                    size = i11;
                                                }
                                                mode++;
                                                measurer3 = measurer;
                                                i9 = i5;
                                            }
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = 0;
                                            while (i9 < 2) {
                                                mode = 0;
                                                while (mode < i13) {
                                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                    if (constraintWidget4 instanceof HelperWidget) {
                                                        if (constraintWidget4 instanceof VirtualLayout) {
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                    }
                                                    if (constraintWidget4 instanceof Guideline) {
                                                        if (constraintWidget4.mVisibility == 8) {
                                                            if (i7 == 0) {
                                                            }
                                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                                max3 = constraintWidget4.getWidth();
                                                                max4 = constraintWidget4.getHeight();
                                                                i11 = i13;
                                                                i13 = constraintWidget4.mBaselineDistance;
                                                                constraintWidget5 = constraintWidget7;
                                                                childCount = 1;
                                                                if (i9 == 1) {
                                                                    childCount = 2;
                                                                }
                                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                                size = constraintWidget4.getWidth();
                                                                i10 = childCount;
                                                                childCount = constraintWidget4.getHeight();
                                                                if (size != max3) {
                                                                    constraintWidget4.setWidth(size);
                                                                    if (max5 != 2) {
                                                                    }
                                                                    i10 = 1;
                                                                }
                                                                if (childCount != max4) {
                                                                    constraintWidget4.setHeight(childCount);
                                                                    if (i3 != 2) {
                                                                    }
                                                                    i10 = 1;
                                                                }
                                                                if (constraintWidget4.hasBaseline) {
                                                                }
                                                                size = i10;
                                                                mode++;
                                                                i13 = i11;
                                                                constraintWidget7 = constraintWidget5;
                                                            }
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                                i11 = i13;
                                                constraintWidget5 = constraintWidget7;
                                                if (size == 0) {
                                                    i9++;
                                                    constraintWidget6 = constraintWidget5;
                                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                                    constraintWidget7 = constraintWidget6;
                                                    i13 = i11;
                                                    size = 0;
                                                } else {
                                                    constraintWidgetContainer2 = constraintWidget5;
                                                }
                                            }
                                            constraintWidgetContainer2 = constraintWidget7;
                                        } else {
                                            i5 = i9;
                                            constraintWidgetContainer2 = constraintWidget7;
                                        }
                                        constraintWidgetContainer2.setOptimizationLevel(i5);
                                        i12 = this.mLayoutWidget.getWidth();
                                        i13 = this.mLayoutWidget.getHeight();
                                        constraintWidgetContainer = this.mLayoutWidget;
                                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                        measurer5 = this.mMeasurer;
                                        i3 = measurer5.paddingHeight;
                                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                        if (z2) {
                                            i12 |= 16777216;
                                        }
                                        if (z3) {
                                            i13 |= 16777216;
                                        }
                                        setMeasuredDimension(i12, i13);
                                    }
                                }
                                if (enabled) {
                                }
                                i3 = i6 & i3;
                                if (i3 == 0) {
                                    measurer3 = measurer2;
                                    i7 = i3;
                                    i13 = 0;
                                    i3 = 0;
                                } else {
                                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                    if (mode != 1073741824) {
                                    }
                                    constraintWidget7.setWidth(size);
                                    constraintWidget7.invalidateGraph();
                                    if (mode2 != 1073741824) {
                                    }
                                    constraintWidget7.setHeight(size2);
                                    constraintWidget7.invalidateGraph();
                                    if (mode == 1073741824) {
                                    }
                                    i7 = i3;
                                    dependencyGraph = constraintWidget7.mDependencyGraph;
                                    if (dependencyGraph.mNeedBuildGraph) {
                                        measurer3 = measurer2;
                                    } else {
                                        list = dependencyGraph.container.mChildren;
                                        i14 = list.size();
                                        max4 = 0;
                                        while (max4 < i14) {
                                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                                            constraintWidget2.ensureWidgetRuns();
                                            list2 = list;
                                            constraintWidget2.measured = false;
                                            i8 = i14;
                                            widgetRun = constraintWidget2.horizontalRun;
                                            measurer3 = measurer2;
                                            widgetRun.dimension.resolved = false;
                                            widgetRun.resolved = false;
                                            widgetRun.reset();
                                            widgetRun2 = constraintWidget2.verticalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            max4++;
                                            i14 = i8;
                                            list = list2;
                                            measurer2 = measurer3;
                                        }
                                        measurer3 = measurer2;
                                        dependencyGraph.container.ensureWidgetRuns();
                                        constraintWidget2 = dependencyGraph.container;
                                        constraintWidget2.measured = false;
                                        widgetRun2 = constraintWidget2.horizontalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        widgetRun2 = dependencyGraph.container.verticalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        dependencyGraph.buildGraph();
                                    }
                                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                    constraintWidget2 = dependencyGraph.container;
                                    constraintWidget2.f12mX = 0;
                                    constraintWidget2.f13mY = 0;
                                    constraintWidget2.horizontalRun.start.resolve(0);
                                    dependencyGraph.container.verticalRun.start.resolve(0);
                                    if (mode != 1073741824) {
                                        i13 = 0;
                                        i3 = 1;
                                    } else {
                                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                        i13 = 1;
                                    }
                                    if (mode2 != 1073741824) {
                                        i9 = 1;
                                    } else {
                                        i9 = 1;
                                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                        i13++;
                                    }
                                    if (i3 != 0) {
                                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                    }
                                }
                                i9 = constraintWidget7.mOptimizationLevel;
                                if (max5 > 0) {
                                    i13 = constraintWidget7.mChildren.size();
                                    optimizeFor = constraintWidget7.optimizeFor(64);
                                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                    for (size = 0; size < i13; size++) {
                                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                        if (constraintWidget3 instanceof Guideline) {
                                            if (!(constraintWidget3 instanceof Barrier)) {
                                                z = constraintWidget3.mInVirtualLayout;
                                                if (optimizeFor) {
                                                    widgetRun3 = constraintWidget3.horizontalRun;
                                                    if (widgetRun3 != null) {
                                                        widgetRun4 = constraintWidget3.verticalRun;
                                                        if (widgetRun4.dimension.resolved) {
                                                        }
                                                    }
                                                }
                                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                if (max2 == 3) {
                                                    obj2 = null;
                                                } else {
                                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                    }
                                                    obj2 = null;
                                                    max2 = 3;
                                                }
                                                if (obj2 == null) {
                                                    if (constraintWidget7.optimizeFor(1)) {
                                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                            if (max2 == 3) {
                                                            }
                                                            obj2 = null;
                                                            obj2 = 1;
                                                            if (max2 != 3) {
                                                                if (i14 == 3) {
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                            }
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                }
                                            }
                                        }
                                    }
                                    i13 = measurer4.layout.getChildCount();
                                    for (i3 = 0; i3 < i13; i3++) {
                                        childAt = measurer4.layout.getChildAt(i3);
                                        if (childAt instanceof Placeholder) {
                                            placeholder = (Placeholder) childAt;
                                            constraintLayout = measurer4.layout;
                                            throw null;
                                        }
                                    }
                                    i13 = measurer4.layout.mConstraintHelpers.size();
                                    if (i13 > 0) {
                                        for (i3 = 0; i3 < i13; i3++) {
                                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                            constraintLayout2 = measurer4.layout;
                                        }
                                    }
                                }
                                basicMeasure.updateHierarchy(constraintWidget7);
                                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                if (max5 > 0) {
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                }
                                if (i13 <= 0) {
                                    i5 = i9;
                                    constraintWidgetContainer2 = constraintWidget7;
                                } else {
                                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                    mode = 0;
                                    size = 0;
                                    while (mode < i13) {
                                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            max3 = constraintWidget4.getWidth();
                                            max4 = constraintWidget4.getHeight();
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                            size = constraintWidget4.getWidth();
                                            i11 = i9;
                                            i9 = constraintWidget4.getHeight();
                                            if (size != max3) {
                                                constraintWidget4.setWidth(size);
                                                if (max5 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            if (i9 != max4) {
                                                constraintWidget4.setHeight(i9);
                                                if (i3 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            virtualLayout = (VirtualLayout) constraintWidget4;
                                            size = i11;
                                        } else {
                                            i5 = i9;
                                            measurer = measurer3;
                                        }
                                        mode++;
                                        measurer3 = measurer;
                                        i9 = i5;
                                    }
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = 0;
                                    while (i9 < 2) {
                                        mode = 0;
                                        while (mode < i13) {
                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                            if (constraintWidget4 instanceof HelperWidget) {
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            if (constraintWidget4 instanceof Guideline) {
                                                if (constraintWidget4.mVisibility == 8) {
                                                    if (i7 == 0) {
                                                    }
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        max3 = constraintWidget4.getWidth();
                                                        max4 = constraintWidget4.getHeight();
                                                        i11 = i13;
                                                        i13 = constraintWidget4.mBaselineDistance;
                                                        constraintWidget5 = constraintWidget7;
                                                        childCount = 1;
                                                        if (i9 == 1) {
                                                            childCount = 2;
                                                        }
                                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                        size = constraintWidget4.getWidth();
                                                        i10 = childCount;
                                                        childCount = constraintWidget4.getHeight();
                                                        if (size != max3) {
                                                            constraintWidget4.setWidth(size);
                                                            if (max5 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (childCount != max4) {
                                                            constraintWidget4.setHeight(childCount);
                                                            if (i3 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (constraintWidget4.hasBaseline) {
                                                        }
                                                        size = i10;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                        i11 = i13;
                                        constraintWidget5 = constraintWidget7;
                                        if (size == 0) {
                                            constraintWidgetContainer2 = constraintWidget5;
                                        } else {
                                            i9++;
                                            constraintWidget6 = constraintWidget5;
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                            constraintWidget7 = constraintWidget6;
                                            i13 = i11;
                                            size = 0;
                                        }
                                    }
                                    constraintWidgetContainer2 = constraintWidget7;
                                }
                                constraintWidgetContainer2.setOptimizationLevel(i5);
                                i12 = this.mLayoutWidget.getWidth();
                                i13 = this.mLayoutWidget.getHeight();
                                constraintWidgetContainer = this.mLayoutWidget;
                                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                measurer5 = this.mMeasurer;
                                i3 = measurer5.paddingHeight;
                                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                if (z2) {
                                    i12 |= 16777216;
                                }
                                if (z3) {
                                    i13 |= 16777216;
                                }
                                setMeasuredDimension(i12, i13);
                            }
                        }
                        if (constraintWidget.isInVerticalChain()) {
                        }
                        if (constraintWidget instanceof VirtualLayout) {
                            if (constraintWidget.isInHorizontalChain()) {
                                if (!constraintWidget.isInVerticalChain()) {
                                    i14++;
                                    constraintLayout = this;
                                    i3 = i6;
                                }
                            }
                            i6 = 0;
                        } else {
                            i6 = 0;
                        }
                        if (mode == 1073741824) {
                            if (mode2 != 1073741824) {
                                i3 = 1;
                                mode = 1073741824;
                                mode2 = 1073741824;
                                i3 = i6 & i3;
                                if (i3 == 0) {
                                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                    if (mode != 1073741824) {
                                    }
                                    constraintWidget7.setWidth(size);
                                    constraintWidget7.invalidateGraph();
                                    if (mode2 != 1073741824) {
                                    }
                                    constraintWidget7.setHeight(size2);
                                    constraintWidget7.invalidateGraph();
                                    if (mode == 1073741824) {
                                    }
                                    i7 = i3;
                                    dependencyGraph = constraintWidget7.mDependencyGraph;
                                    if (dependencyGraph.mNeedBuildGraph) {
                                        list = dependencyGraph.container.mChildren;
                                        i14 = list.size();
                                        max4 = 0;
                                        while (max4 < i14) {
                                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                                            constraintWidget2.ensureWidgetRuns();
                                            list2 = list;
                                            constraintWidget2.measured = false;
                                            i8 = i14;
                                            widgetRun = constraintWidget2.horizontalRun;
                                            measurer3 = measurer2;
                                            widgetRun.dimension.resolved = false;
                                            widgetRun.resolved = false;
                                            widgetRun.reset();
                                            widgetRun2 = constraintWidget2.verticalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            max4++;
                                            i14 = i8;
                                            list = list2;
                                            measurer2 = measurer3;
                                        }
                                        measurer3 = measurer2;
                                        dependencyGraph.container.ensureWidgetRuns();
                                        constraintWidget2 = dependencyGraph.container;
                                        constraintWidget2.measured = false;
                                        widgetRun2 = constraintWidget2.horizontalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        widgetRun2 = dependencyGraph.container.verticalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        dependencyGraph.buildGraph();
                                    } else {
                                        measurer3 = measurer2;
                                    }
                                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                    constraintWidget2 = dependencyGraph.container;
                                    constraintWidget2.f12mX = 0;
                                    constraintWidget2.f13mY = 0;
                                    constraintWidget2.horizontalRun.start.resolve(0);
                                    dependencyGraph.container.verticalRun.start.resolve(0);
                                    if (mode != 1073741824) {
                                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                        i13 = 1;
                                    } else {
                                        i13 = 0;
                                        i3 = 1;
                                    }
                                    if (mode2 != 1073741824) {
                                        i9 = 1;
                                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                        i13++;
                                    } else {
                                        i9 = 1;
                                    }
                                    if (i3 != 0) {
                                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                    }
                                } else {
                                    measurer3 = measurer2;
                                    i7 = i3;
                                    i13 = 0;
                                    i3 = 0;
                                }
                                i9 = constraintWidget7.mOptimizationLevel;
                                if (max5 > 0) {
                                    i13 = constraintWidget7.mChildren.size();
                                    optimizeFor = constraintWidget7.optimizeFor(64);
                                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                    for (size = 0; size < i13; size++) {
                                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                        if (constraintWidget3 instanceof Guideline) {
                                            if (!(constraintWidget3 instanceof Barrier)) {
                                                z = constraintWidget3.mInVirtualLayout;
                                                if (optimizeFor) {
                                                    widgetRun3 = constraintWidget3.horizontalRun;
                                                    if (widgetRun3 != null) {
                                                        widgetRun4 = constraintWidget3.verticalRun;
                                                        if (widgetRun4.dimension.resolved) {
                                                        }
                                                    }
                                                }
                                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                if (max2 == 3) {
                                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                    }
                                                    obj2 = null;
                                                    max2 = 3;
                                                } else {
                                                    obj2 = null;
                                                }
                                                if (obj2 == null) {
                                                    if (constraintWidget7.optimizeFor(1)) {
                                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                            if (max2 == 3) {
                                                            }
                                                            obj2 = null;
                                                            obj2 = 1;
                                                            if (max2 != 3) {
                                                                if (i14 == 3) {
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                            }
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                }
                                            }
                                        }
                                    }
                                    i13 = measurer4.layout.getChildCount();
                                    while (i3 < i13) {
                                        childAt = measurer4.layout.getChildAt(i3);
                                        if (childAt instanceof Placeholder) {
                                        } else {
                                            placeholder = (Placeholder) childAt;
                                            constraintLayout = measurer4.layout;
                                            throw null;
                                        }
                                    }
                                    i13 = measurer4.layout.mConstraintHelpers.size();
                                    if (i13 > 0) {
                                        for (i3 = 0; i3 < i13; i3++) {
                                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                            constraintLayout2 = measurer4.layout;
                                        }
                                    }
                                }
                                basicMeasure.updateHierarchy(constraintWidget7);
                                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                if (max5 > 0) {
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                }
                                if (i13 <= 0) {
                                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                    mode = 0;
                                    size = 0;
                                    while (mode < i13) {
                                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i5 = i9;
                                            measurer = measurer3;
                                        } else {
                                            max3 = constraintWidget4.getWidth();
                                            max4 = constraintWidget4.getHeight();
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                            size = constraintWidget4.getWidth();
                                            i11 = i9;
                                            i9 = constraintWidget4.getHeight();
                                            if (size != max3) {
                                                constraintWidget4.setWidth(size);
                                                if (max5 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            if (i9 != max4) {
                                                constraintWidget4.setHeight(i9);
                                                if (i3 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            virtualLayout = (VirtualLayout) constraintWidget4;
                                            size = i11;
                                        }
                                        mode++;
                                        measurer3 = measurer;
                                        i9 = i5;
                                    }
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = 0;
                                    while (i9 < 2) {
                                        mode = 0;
                                        while (mode < i13) {
                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                            if (constraintWidget4 instanceof HelperWidget) {
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            if (constraintWidget4 instanceof Guideline) {
                                                if (constraintWidget4.mVisibility == 8) {
                                                    if (i7 == 0) {
                                                    }
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        max3 = constraintWidget4.getWidth();
                                                        max4 = constraintWidget4.getHeight();
                                                        i11 = i13;
                                                        i13 = constraintWidget4.mBaselineDistance;
                                                        constraintWidget5 = constraintWidget7;
                                                        childCount = 1;
                                                        if (i9 == 1) {
                                                            childCount = 2;
                                                        }
                                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                        size = constraintWidget4.getWidth();
                                                        i10 = childCount;
                                                        childCount = constraintWidget4.getHeight();
                                                        if (size != max3) {
                                                            constraintWidget4.setWidth(size);
                                                            if (max5 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (childCount != max4) {
                                                            constraintWidget4.setHeight(childCount);
                                                            if (i3 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (constraintWidget4.hasBaseline) {
                                                        }
                                                        size = i10;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                        i11 = i13;
                                        constraintWidget5 = constraintWidget7;
                                        if (size == 0) {
                                            i9++;
                                            constraintWidget6 = constraintWidget5;
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                            constraintWidget7 = constraintWidget6;
                                            i13 = i11;
                                            size = 0;
                                        } else {
                                            constraintWidgetContainer2 = constraintWidget5;
                                        }
                                    }
                                    constraintWidgetContainer2 = constraintWidget7;
                                } else {
                                    i5 = i9;
                                    constraintWidgetContainer2 = constraintWidget7;
                                }
                                constraintWidgetContainer2.setOptimizationLevel(i5);
                                i12 = this.mLayoutWidget.getWidth();
                                i13 = this.mLayoutWidget.getHeight();
                                constraintWidgetContainer = this.mLayoutWidget;
                                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                measurer5 = this.mMeasurer;
                                i3 = measurer5.paddingHeight;
                                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                if (z2) {
                                    i12 |= 16777216;
                                }
                                if (z3) {
                                    i13 |= 16777216;
                                }
                                setMeasuredDimension(i12, i13);
                            }
                            mode = 1073741824;
                        }
                        if (enabled) {
                        }
                        i3 = i6 & i3;
                        if (i3 == 0) {
                            measurer3 = measurer2;
                            i7 = i3;
                            i13 = 0;
                            i3 = 0;
                        } else {
                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                            if (mode != 1073741824) {
                            }
                            constraintWidget7.setWidth(size);
                            constraintWidget7.invalidateGraph();
                            if (mode2 != 1073741824) {
                            }
                            constraintWidget7.setHeight(size2);
                            constraintWidget7.invalidateGraph();
                            if (mode == 1073741824) {
                            }
                            i7 = i3;
                            dependencyGraph = constraintWidget7.mDependencyGraph;
                            if (dependencyGraph.mNeedBuildGraph) {
                                measurer3 = measurer2;
                            } else {
                                list = dependencyGraph.container.mChildren;
                                i14 = list.size();
                                max4 = 0;
                                while (max4 < i14) {
                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                    constraintWidget2.ensureWidgetRuns();
                                    list2 = list;
                                    constraintWidget2.measured = false;
                                    i8 = i14;
                                    widgetRun = constraintWidget2.horizontalRun;
                                    measurer3 = measurer2;
                                    widgetRun.dimension.resolved = false;
                                    widgetRun.resolved = false;
                                    widgetRun.reset();
                                    widgetRun2 = constraintWidget2.verticalRun;
                                    widgetRun2.dimension.resolved = false;
                                    widgetRun2.resolved = false;
                                    widgetRun2.reset();
                                    max4++;
                                    i14 = i8;
                                    list = list2;
                                    measurer2 = measurer3;
                                }
                                measurer3 = measurer2;
                                dependencyGraph.container.ensureWidgetRuns();
                                constraintWidget2 = dependencyGraph.container;
                                constraintWidget2.measured = false;
                                widgetRun2 = constraintWidget2.horizontalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                widgetRun2 = dependencyGraph.container.verticalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                dependencyGraph.buildGraph();
                            }
                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                            constraintWidget2 = dependencyGraph.container;
                            constraintWidget2.f12mX = 0;
                            constraintWidget2.f13mY = 0;
                            constraintWidget2.horizontalRun.start.resolve(0);
                            dependencyGraph.container.verticalRun.start.resolve(0);
                            if (mode != 1073741824) {
                                i13 = 0;
                                i3 = 1;
                            } else {
                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                i13 = 1;
                            }
                            if (mode2 != 1073741824) {
                                i9 = 1;
                            } else {
                                i9 = 1;
                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                i13++;
                            }
                            if (i3 != 0) {
                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                            }
                        }
                        i9 = constraintWidget7.mOptimizationLevel;
                        if (max5 > 0) {
                            i13 = constraintWidget7.mChildren.size();
                            optimizeFor = constraintWidget7.optimizeFor(64);
                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                            for (size = 0; size < i13; size++) {
                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                if (constraintWidget3 instanceof Guideline) {
                                    if (!(constraintWidget3 instanceof Barrier)) {
                                        z = constraintWidget3.mInVirtualLayout;
                                        if (optimizeFor) {
                                            widgetRun3 = constraintWidget3.horizontalRun;
                                            if (widgetRun3 != null) {
                                                widgetRun4 = constraintWidget3.verticalRun;
                                                if (widgetRun4.dimension.resolved) {
                                                }
                                            }
                                        }
                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                        if (max2 == 3) {
                                            obj2 = null;
                                        } else {
                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                            }
                                            obj2 = null;
                                            max2 = 3;
                                        }
                                        if (obj2 == null) {
                                            if (constraintWidget7.optimizeFor(1)) {
                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                    if (max2 == 3) {
                                                    }
                                                    obj2 = null;
                                                    obj2 = 1;
                                                    if (max2 != 3) {
                                                        if (i14 == 3) {
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                    }
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                        }
                                    }
                                }
                            }
                            i13 = measurer4.layout.getChildCount();
                            for (i3 = 0; i3 < i13; i3++) {
                                childAt = measurer4.layout.getChildAt(i3);
                                if (childAt instanceof Placeholder) {
                                    placeholder = (Placeholder) childAt;
                                    constraintLayout = measurer4.layout;
                                    throw null;
                                }
                            }
                            i13 = measurer4.layout.mConstraintHelpers.size();
                            if (i13 > 0) {
                                for (i3 = 0; i3 < i13; i3++) {
                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                    constraintLayout2 = measurer4.layout;
                                }
                            }
                        }
                        basicMeasure.updateHierarchy(constraintWidget7);
                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                        if (max5 > 0) {
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                        }
                        if (i13 <= 0) {
                            i5 = i9;
                            constraintWidgetContainer2 = constraintWidget7;
                        } else {
                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                            mode = 0;
                            size = 0;
                            while (mode < i13) {
                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    max3 = constraintWidget4.getWidth();
                                    max4 = constraintWidget4.getHeight();
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                    size = constraintWidget4.getWidth();
                                    i11 = i9;
                                    i9 = constraintWidget4.getHeight();
                                    if (size != max3) {
                                        constraintWidget4.setWidth(size);
                                        if (max5 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    if (i9 != max4) {
                                        constraintWidget4.setHeight(i9);
                                        if (i3 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                    size = i11;
                                } else {
                                    i5 = i9;
                                    measurer = measurer3;
                                }
                                mode++;
                                measurer3 = measurer;
                                i9 = i5;
                            }
                            i5 = i9;
                            measurer = measurer3;
                            i9 = 0;
                            while (i9 < 2) {
                                mode = 0;
                                while (mode < i13) {
                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                    if (constraintWidget4 instanceof HelperWidget) {
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    if (constraintWidget4 instanceof Guideline) {
                                        if (constraintWidget4.mVisibility == 8) {
                                            if (i7 == 0) {
                                            }
                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                max3 = constraintWidget4.getWidth();
                                                max4 = constraintWidget4.getHeight();
                                                i11 = i13;
                                                i13 = constraintWidget4.mBaselineDistance;
                                                constraintWidget5 = constraintWidget7;
                                                childCount = 1;
                                                if (i9 == 1) {
                                                    childCount = 2;
                                                }
                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                size = constraintWidget4.getWidth();
                                                i10 = childCount;
                                                childCount = constraintWidget4.getHeight();
                                                if (size != max3) {
                                                    constraintWidget4.setWidth(size);
                                                    if (max5 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (childCount != max4) {
                                                    constraintWidget4.setHeight(childCount);
                                                    if (i3 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (constraintWidget4.hasBaseline) {
                                                }
                                                size = i10;
                                                mode++;
                                                i13 = i11;
                                                constraintWidget7 = constraintWidget5;
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                                i11 = i13;
                                constraintWidget5 = constraintWidget7;
                                if (size == 0) {
                                    constraintWidgetContainer2 = constraintWidget5;
                                } else {
                                    i9++;
                                    constraintWidget6 = constraintWidget5;
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                    constraintWidget7 = constraintWidget6;
                                    i13 = i11;
                                    size = 0;
                                }
                            }
                            constraintWidgetContainer2 = constraintWidget7;
                        }
                        constraintWidgetContainer2.setOptimizationLevel(i5);
                        i12 = this.mLayoutWidget.getWidth();
                        i13 = this.mLayoutWidget.getHeight();
                        constraintWidgetContainer = this.mLayoutWidget;
                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                        measurer5 = this.mMeasurer;
                        i3 = measurer5.paddingHeight;
                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                        if (z2) {
                            i12 |= 16777216;
                        }
                        if (z3) {
                            i13 |= 16777216;
                        }
                        setMeasuredDimension(i12, i13);
                    }
                }
                i6 = i3;
                if (mode == 1073741824) {
                    if (mode2 != 1073741824) {
                        mode = 1073741824;
                    } else {
                        i3 = 1;
                        mode = 1073741824;
                        mode2 = 1073741824;
                        i3 = i6 & i3;
                        if (i3 == 0) {
                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                            if (mode != 1073741824) {
                            }
                            constraintWidget7.setWidth(size);
                            constraintWidget7.invalidateGraph();
                            if (mode2 != 1073741824) {
                            }
                            constraintWidget7.setHeight(size2);
                            constraintWidget7.invalidateGraph();
                            if (mode == 1073741824) {
                            }
                            i7 = i3;
                            dependencyGraph = constraintWidget7.mDependencyGraph;
                            if (dependencyGraph.mNeedBuildGraph) {
                                list = dependencyGraph.container.mChildren;
                                i14 = list.size();
                                max4 = 0;
                                while (max4 < i14) {
                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                    constraintWidget2.ensureWidgetRuns();
                                    list2 = list;
                                    constraintWidget2.measured = false;
                                    i8 = i14;
                                    widgetRun = constraintWidget2.horizontalRun;
                                    measurer3 = measurer2;
                                    widgetRun.dimension.resolved = false;
                                    widgetRun.resolved = false;
                                    widgetRun.reset();
                                    widgetRun2 = constraintWidget2.verticalRun;
                                    widgetRun2.dimension.resolved = false;
                                    widgetRun2.resolved = false;
                                    widgetRun2.reset();
                                    max4++;
                                    i14 = i8;
                                    list = list2;
                                    measurer2 = measurer3;
                                }
                                measurer3 = measurer2;
                                dependencyGraph.container.ensureWidgetRuns();
                                constraintWidget2 = dependencyGraph.container;
                                constraintWidget2.measured = false;
                                widgetRun2 = constraintWidget2.horizontalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                widgetRun2 = dependencyGraph.container.verticalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                dependencyGraph.buildGraph();
                            } else {
                                measurer3 = measurer2;
                            }
                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                            constraintWidget2 = dependencyGraph.container;
                            constraintWidget2.f12mX = 0;
                            constraintWidget2.f13mY = 0;
                            constraintWidget2.horizontalRun.start.resolve(0);
                            dependencyGraph.container.verticalRun.start.resolve(0);
                            if (mode != 1073741824) {
                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                i13 = 1;
                            } else {
                                i13 = 0;
                                i3 = 1;
                            }
                            if (mode2 != 1073741824) {
                                i9 = 1;
                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                i13++;
                            } else {
                                i9 = 1;
                            }
                            if (i3 != 0) {
                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                            }
                        } else {
                            measurer3 = measurer2;
                            i7 = i3;
                            i13 = 0;
                            i3 = 0;
                        }
                        i9 = constraintWidget7.mOptimizationLevel;
                        if (max5 > 0) {
                            i13 = constraintWidget7.mChildren.size();
                            optimizeFor = constraintWidget7.optimizeFor(64);
                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                            for (size = 0; size < i13; size++) {
                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                if (constraintWidget3 instanceof Guideline) {
                                    if (!(constraintWidget3 instanceof Barrier)) {
                                        z = constraintWidget3.mInVirtualLayout;
                                        if (optimizeFor) {
                                            widgetRun3 = constraintWidget3.horizontalRun;
                                            if (widgetRun3 != null) {
                                                widgetRun4 = constraintWidget3.verticalRun;
                                                if (widgetRun4.dimension.resolved) {
                                                }
                                            }
                                        }
                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                        if (max2 == 3) {
                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                            }
                                            obj2 = null;
                                            max2 = 3;
                                        } else {
                                            obj2 = null;
                                        }
                                        if (obj2 == null) {
                                            if (constraintWidget7.optimizeFor(1)) {
                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                    if (max2 == 3) {
                                                    }
                                                    obj2 = null;
                                                    obj2 = 1;
                                                    if (max2 != 3) {
                                                        if (i14 == 3) {
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                    }
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                        }
                                    }
                                }
                            }
                            i13 = measurer4.layout.getChildCount();
                            while (i3 < i13) {
                                childAt = measurer4.layout.getChildAt(i3);
                                if (childAt instanceof Placeholder) {
                                } else {
                                    placeholder = (Placeholder) childAt;
                                    constraintLayout = measurer4.layout;
                                    throw null;
                                }
                            }
                            i13 = measurer4.layout.mConstraintHelpers.size();
                            if (i13 > 0) {
                                for (i3 = 0; i3 < i13; i3++) {
                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                    constraintLayout2 = measurer4.layout;
                                }
                            }
                        }
                        basicMeasure.updateHierarchy(constraintWidget7);
                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                        if (max5 > 0) {
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                        }
                        if (i13 <= 0) {
                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                            mode = 0;
                            size = 0;
                            while (mode < i13) {
                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    i5 = i9;
                                    measurer = measurer3;
                                } else {
                                    max3 = constraintWidget4.getWidth();
                                    max4 = constraintWidget4.getHeight();
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                    size = constraintWidget4.getWidth();
                                    i11 = i9;
                                    i9 = constraintWidget4.getHeight();
                                    if (size != max3) {
                                        constraintWidget4.setWidth(size);
                                        if (max5 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    if (i9 != max4) {
                                        constraintWidget4.setHeight(i9);
                                        if (i3 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                    size = i11;
                                }
                                mode++;
                                measurer3 = measurer;
                                i9 = i5;
                            }
                            i5 = i9;
                            measurer = measurer3;
                            i9 = 0;
                            while (i9 < 2) {
                                mode = 0;
                                while (mode < i13) {
                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                    if (constraintWidget4 instanceof HelperWidget) {
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    if (constraintWidget4 instanceof Guideline) {
                                        if (constraintWidget4.mVisibility == 8) {
                                            if (i7 == 0) {
                                            }
                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                max3 = constraintWidget4.getWidth();
                                                max4 = constraintWidget4.getHeight();
                                                i11 = i13;
                                                i13 = constraintWidget4.mBaselineDistance;
                                                constraintWidget5 = constraintWidget7;
                                                childCount = 1;
                                                if (i9 == 1) {
                                                    childCount = 2;
                                                }
                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                size = constraintWidget4.getWidth();
                                                i10 = childCount;
                                                childCount = constraintWidget4.getHeight();
                                                if (size != max3) {
                                                    constraintWidget4.setWidth(size);
                                                    if (max5 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (childCount != max4) {
                                                    constraintWidget4.setHeight(childCount);
                                                    if (i3 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (constraintWidget4.hasBaseline) {
                                                }
                                                size = i10;
                                                mode++;
                                                i13 = i11;
                                                constraintWidget7 = constraintWidget5;
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                                i11 = i13;
                                constraintWidget5 = constraintWidget7;
                                if (size == 0) {
                                    i9++;
                                    constraintWidget6 = constraintWidget5;
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                    constraintWidget7 = constraintWidget6;
                                    i13 = i11;
                                    size = 0;
                                } else {
                                    constraintWidgetContainer2 = constraintWidget5;
                                }
                            }
                            constraintWidgetContainer2 = constraintWidget7;
                        } else {
                            i5 = i9;
                            constraintWidgetContainer2 = constraintWidget7;
                        }
                        constraintWidgetContainer2.setOptimizationLevel(i5);
                        i12 = this.mLayoutWidget.getWidth();
                        i13 = this.mLayoutWidget.getHeight();
                        constraintWidgetContainer = this.mLayoutWidget;
                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                        measurer5 = this.mMeasurer;
                        i3 = measurer5.paddingHeight;
                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                        if (z2) {
                            i12 |= 16777216;
                        }
                        if (z3) {
                            i13 |= 16777216;
                        }
                        setMeasuredDimension(i12, i13);
                    }
                }
                if (enabled) {
                }
                i3 = i6 & i3;
                if (i3 == 0) {
                    measurer3 = measurer2;
                    i7 = i3;
                    i13 = 0;
                    i3 = 0;
                } else {
                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                    if (mode != 1073741824) {
                    }
                    constraintWidget7.setWidth(size);
                    constraintWidget7.invalidateGraph();
                    if (mode2 != 1073741824) {
                    }
                    constraintWidget7.setHeight(size2);
                    constraintWidget7.invalidateGraph();
                    if (mode == 1073741824) {
                    }
                    i7 = i3;
                    dependencyGraph = constraintWidget7.mDependencyGraph;
                    if (dependencyGraph.mNeedBuildGraph) {
                        measurer3 = measurer2;
                    } else {
                        list = dependencyGraph.container.mChildren;
                        i14 = list.size();
                        max4 = 0;
                        while (max4 < i14) {
                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                            constraintWidget2.ensureWidgetRuns();
                            list2 = list;
                            constraintWidget2.measured = false;
                            i8 = i14;
                            widgetRun = constraintWidget2.horizontalRun;
                            measurer3 = measurer2;
                            widgetRun.dimension.resolved = false;
                            widgetRun.resolved = false;
                            widgetRun.reset();
                            widgetRun2 = constraintWidget2.verticalRun;
                            widgetRun2.dimension.resolved = false;
                            widgetRun2.resolved = false;
                            widgetRun2.reset();
                            max4++;
                            i14 = i8;
                            list = list2;
                            measurer2 = measurer3;
                        }
                        measurer3 = measurer2;
                        dependencyGraph.container.ensureWidgetRuns();
                        constraintWidget2 = dependencyGraph.container;
                        constraintWidget2.measured = false;
                        widgetRun2 = constraintWidget2.horizontalRun;
                        widgetRun2.dimension.resolved = false;
                        widgetRun2.resolved = false;
                        widgetRun2.reset();
                        widgetRun2 = dependencyGraph.container.verticalRun;
                        widgetRun2.dimension.resolved = false;
                        widgetRun2.resolved = false;
                        widgetRun2.reset();
                        dependencyGraph.buildGraph();
                    }
                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                    constraintWidget2 = dependencyGraph.container;
                    constraintWidget2.f12mX = 0;
                    constraintWidget2.f13mY = 0;
                    constraintWidget2.horizontalRun.start.resolve(0);
                    dependencyGraph.container.verticalRun.start.resolve(0);
                    if (mode != 1073741824) {
                        i13 = 0;
                        i3 = 1;
                    } else {
                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                        i13 = 1;
                    }
                    if (mode2 != 1073741824) {
                        i9 = 1;
                    } else {
                        i9 = 1;
                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                        i13++;
                    }
                    if (i3 != 0) {
                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                    }
                }
                i9 = constraintWidget7.mOptimizationLevel;
                if (max5 > 0) {
                    i13 = constraintWidget7.mChildren.size();
                    optimizeFor = constraintWidget7.optimizeFor(64);
                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                    for (size = 0; size < i13; size++) {
                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                        if (constraintWidget3 instanceof Guideline) {
                            if (!(constraintWidget3 instanceof Barrier)) {
                                z = constraintWidget3.mInVirtualLayout;
                                if (optimizeFor) {
                                    widgetRun3 = constraintWidget3.horizontalRun;
                                    if (widgetRun3 != null) {
                                        widgetRun4 = constraintWidget3.verticalRun;
                                        if (widgetRun4.dimension.resolved) {
                                        }
                                    }
                                }
                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                if (max2 == 3) {
                                    obj2 = null;
                                } else {
                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                    }
                                    obj2 = null;
                                    max2 = 3;
                                }
                                if (obj2 == null) {
                                    if (constraintWidget7.optimizeFor(1)) {
                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                            if (max2 == 3) {
                                            }
                                            obj2 = null;
                                            obj2 = 1;
                                            if (max2 != 3) {
                                                if (i14 == 3) {
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                            }
                                            if (obj2 != null) {
                                            }
                                        }
                                    }
                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                }
                            }
                        }
                    }
                    i13 = measurer4.layout.getChildCount();
                    for (i3 = 0; i3 < i13; i3++) {
                        childAt = measurer4.layout.getChildAt(i3);
                        if (childAt instanceof Placeholder) {
                            placeholder = (Placeholder) childAt;
                            constraintLayout = measurer4.layout;
                            throw null;
                        }
                    }
                    i13 = measurer4.layout.mConstraintHelpers.size();
                    if (i13 > 0) {
                        for (i3 = 0; i3 < i13; i3++) {
                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                            constraintLayout2 = measurer4.layout;
                        }
                    }
                }
                basicMeasure.updateHierarchy(constraintWidget7);
                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                if (max5 > 0) {
                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                }
                if (i13 <= 0) {
                    i5 = i9;
                    constraintWidgetContainer2 = constraintWidget7;
                } else {
                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                    mode = 0;
                    size = 0;
                    while (mode < i13) {
                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                        if (constraintWidget4 instanceof VirtualLayout) {
                            max3 = constraintWidget4.getWidth();
                            max4 = constraintWidget4.getHeight();
                            i5 = i9;
                            measurer = measurer3;
                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                            size = constraintWidget4.getWidth();
                            i11 = i9;
                            i9 = constraintWidget4.getHeight();
                            if (size != max3) {
                                constraintWidget4.setWidth(size);
                                if (max5 != 2) {
                                }
                                i11 = 1;
                            }
                            if (i9 != max4) {
                                constraintWidget4.setHeight(i9);
                                if (i3 != 2) {
                                }
                                i11 = 1;
                            }
                            virtualLayout = (VirtualLayout) constraintWidget4;
                            size = i11;
                        } else {
                            i5 = i9;
                            measurer = measurer3;
                        }
                        mode++;
                        measurer3 = measurer;
                        i9 = i5;
                    }
                    i5 = i9;
                    measurer = measurer3;
                    i9 = 0;
                    while (i9 < 2) {
                        mode = 0;
                        while (mode < i13) {
                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                            if (constraintWidget4 instanceof HelperWidget) {
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                            }
                            if (constraintWidget4 instanceof Guideline) {
                                if (constraintWidget4.mVisibility == 8) {
                                    if (i7 == 0) {
                                    }
                                    if (constraintWidget4 instanceof VirtualLayout) {
                                        max3 = constraintWidget4.getWidth();
                                        max4 = constraintWidget4.getHeight();
                                        i11 = i13;
                                        i13 = constraintWidget4.mBaselineDistance;
                                        constraintWidget5 = constraintWidget7;
                                        childCount = 1;
                                        if (i9 == 1) {
                                            childCount = 2;
                                        }
                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                        size = constraintWidget4.getWidth();
                                        i10 = childCount;
                                        childCount = constraintWidget4.getHeight();
                                        if (size != max3) {
                                            constraintWidget4.setWidth(size);
                                            if (max5 != 2) {
                                            }
                                            i10 = 1;
                                        }
                                        if (childCount != max4) {
                                            constraintWidget4.setHeight(childCount);
                                            if (i3 != 2) {
                                            }
                                            i10 = 1;
                                        }
                                        if (constraintWidget4.hasBaseline) {
                                        }
                                        size = i10;
                                        mode++;
                                        i13 = i11;
                                        constraintWidget7 = constraintWidget5;
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                            }
                            i11 = i13;
                            constraintWidget5 = constraintWidget7;
                            mode++;
                            i13 = i11;
                            constraintWidget7 = constraintWidget5;
                        }
                        i11 = i13;
                        constraintWidget5 = constraintWidget7;
                        if (size == 0) {
                            constraintWidgetContainer2 = constraintWidget5;
                        } else {
                            i9++;
                            constraintWidget6 = constraintWidget5;
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                            constraintWidget7 = constraintWidget6;
                            i13 = i11;
                            size = 0;
                        }
                    }
                    constraintWidgetContainer2 = constraintWidget7;
                }
                constraintWidgetContainer2.setOptimizationLevel(i5);
                i12 = this.mLayoutWidget.getWidth();
                i13 = this.mLayoutWidget.getHeight();
                constraintWidgetContainer = this.mLayoutWidget;
                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                measurer5 = this.mMeasurer;
                i3 = measurer5.paddingHeight;
                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                if (z2) {
                    i12 |= 16777216;
                }
                if (z3) {
                    i13 |= 16777216;
                }
                setMeasuredDimension(i12, i13);
            }
        }
        if (isRtl()) {
            max5 = max2;
        }
        size -= max3;
        size2 -= i14;
        measurer = r0.mMeasurer;
        i14 = measurer.paddingHeight;
        max2 = measurer.paddingWidth;
        max3 = getChildCount();
        switch (mode) {
            case LinearLayoutManager.INVALID_OFFSET /*-2147483648*/:
                if (max3 != 0) {
                    max4 = size;
                } else {
                    max4 = Math.max(0, r0.mMinWidth);
                    max3 = 0;
                }
                i4 = 2;
                break;
            case 0:
                if (max3 != 0) {
                    max4 = 0;
                } else {
                    max4 = Math.max(0, r0.mMinWidth);
                    max3 = 0;
                }
                i4 = 2;
                break;
            case 1073741824:
                max4 = Math.min(r0.mMaxWidth - max2, size);
                i4 = 1;
                break;
            default:
                max4 = 0;
                i4 = 1;
                break;
        }
        switch (mode2) {
            case LinearLayoutManager.INVALID_OFFSET /*-2147483648*/:
                if (max3 != 0) {
                }
                i5 = 2;
                break;
            case 0:
                if (max3 != 0) {
                }
                i5 = 2;
                break;
            case 1073741824:
                max3 = Math.min(r0.mMaxHeight - i14, size2);
                i5 = 1;
                break;
            default:
                max3 = 0;
                i5 = 1;
                break;
        }
        if (max4 == constraintWidget7.getWidth()) {
            if (max3 != constraintWidget7.getHeight()) {
                constraintWidget7.f12mX = 0;
                constraintWidget7.f13mY = 0;
                i13 = r0.mMaxWidth;
                iArr = constraintWidget7.mMaxDimension;
                iArr[0] = i13 - max2;
                iArr[1] = r0.mMaxHeight - i14;
                constraintWidget7.setMinWidth(0);
                constraintWidget7.setMinHeight(0);
                constraintWidget7.setHorizontalDimensionBehaviour$ar$edu(i4);
                constraintWidget7.setWidth(max4);
                constraintWidget7.setVerticalDimensionBehaviour$ar$edu(i5);
                constraintWidget7.setHeight(max3);
                constraintWidget7.setMinWidth(r0.mMinWidth - max2);
                constraintWidget7.setMinHeight(r0.mMinHeight - i14);
                constraintWidget7.mPaddingLeft = max5;
                constraintWidget7.mPaddingTop = max;
                basicMeasure = constraintWidget7.mBasicMeasureSolver;
                measurer2 = constraintWidget7.mMeasurer$ar$class_merging;
                max5 = constraintWidget7.mChildren.size();
                width = constraintWidget7.getWidth();
                max = constraintWidget7.getHeight();
                enabled = Optimizer.enabled(i3, 128);
                if (enabled) {
                    if (Optimizer.enabled(i3, 64)) {
                    }
                }
                if (i3 != 0) {
                    i14 = 0;
                    while (i14 < max5) {
                        constraintWidget = (ConstraintWidget) constraintWidget7.mChildren.get(i14);
                        max4 = constraintWidget.getHorizontalDimensionBehaviour$ar$edu();
                        i6 = i3;
                        i3 = constraintWidget.getVerticalDimensionBehaviour$ar$edu();
                        if (max4 == 3) {
                        }
                        obj = null;
                        if (constraintWidget.isInHorizontalChain()) {
                            if (obj == null) {
                                i6 = 0;
                                if (mode == 1073741824) {
                                    if (mode2 != 1073741824) {
                                        i3 = 1;
                                        mode = 1073741824;
                                        mode2 = 1073741824;
                                        i3 = i6 & i3;
                                        if (i3 == 0) {
                                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                            if (mode != 1073741824) {
                                            }
                                            constraintWidget7.setWidth(size);
                                            constraintWidget7.invalidateGraph();
                                            if (mode2 != 1073741824) {
                                            }
                                            constraintWidget7.setHeight(size2);
                                            constraintWidget7.invalidateGraph();
                                            if (mode == 1073741824) {
                                            }
                                            i7 = i3;
                                            dependencyGraph = constraintWidget7.mDependencyGraph;
                                            if (dependencyGraph.mNeedBuildGraph) {
                                                list = dependencyGraph.container.mChildren;
                                                i14 = list.size();
                                                max4 = 0;
                                                while (max4 < i14) {
                                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                                    constraintWidget2.ensureWidgetRuns();
                                                    list2 = list;
                                                    constraintWidget2.measured = false;
                                                    i8 = i14;
                                                    widgetRun = constraintWidget2.horizontalRun;
                                                    measurer3 = measurer2;
                                                    widgetRun.dimension.resolved = false;
                                                    widgetRun.resolved = false;
                                                    widgetRun.reset();
                                                    widgetRun2 = constraintWidget2.verticalRun;
                                                    widgetRun2.dimension.resolved = false;
                                                    widgetRun2.resolved = false;
                                                    widgetRun2.reset();
                                                    max4++;
                                                    i14 = i8;
                                                    list = list2;
                                                    measurer2 = measurer3;
                                                }
                                                measurer3 = measurer2;
                                                dependencyGraph.container.ensureWidgetRuns();
                                                constraintWidget2 = dependencyGraph.container;
                                                constraintWidget2.measured = false;
                                                widgetRun2 = constraintWidget2.horizontalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                widgetRun2 = dependencyGraph.container.verticalRun;
                                                widgetRun2.dimension.resolved = false;
                                                widgetRun2.resolved = false;
                                                widgetRun2.reset();
                                                dependencyGraph.buildGraph();
                                            } else {
                                                measurer3 = measurer2;
                                            }
                                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                            constraintWidget2 = dependencyGraph.container;
                                            constraintWidget2.f12mX = 0;
                                            constraintWidget2.f13mY = 0;
                                            constraintWidget2.horizontalRun.start.resolve(0);
                                            dependencyGraph.container.verticalRun.start.resolve(0);
                                            if (mode != 1073741824) {
                                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                                i13 = 1;
                                            } else {
                                                i13 = 0;
                                                i3 = 1;
                                            }
                                            if (mode2 != 1073741824) {
                                                i9 = 1;
                                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                                i13++;
                                            } else {
                                                i9 = 1;
                                            }
                                            if (i3 != 0) {
                                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                            }
                                        } else {
                                            measurer3 = measurer2;
                                            i7 = i3;
                                            i13 = 0;
                                            i3 = 0;
                                        }
                                        i9 = constraintWidget7.mOptimizationLevel;
                                        if (max5 > 0) {
                                            i13 = constraintWidget7.mChildren.size();
                                            optimizeFor = constraintWidget7.optimizeFor(64);
                                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                            for (size = 0; size < i13; size++) {
                                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                                if (constraintWidget3 instanceof Guideline) {
                                                    if (!(constraintWidget3 instanceof Barrier)) {
                                                        z = constraintWidget3.mInVirtualLayout;
                                                        if (optimizeFor) {
                                                            widgetRun3 = constraintWidget3.horizontalRun;
                                                            if (widgetRun3 != null) {
                                                                widgetRun4 = constraintWidget3.verticalRun;
                                                                if (widgetRun4.dimension.resolved) {
                                                                }
                                                            }
                                                        }
                                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                        if (max2 == 3) {
                                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                            }
                                                            obj2 = null;
                                                            max2 = 3;
                                                        } else {
                                                            obj2 = null;
                                                        }
                                                        if (obj2 == null) {
                                                            if (constraintWidget7.optimizeFor(1)) {
                                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                                    if (max2 == 3) {
                                                                    }
                                                                    obj2 = null;
                                                                    obj2 = 1;
                                                                    if (max2 != 3) {
                                                                        if (i14 == 3) {
                                                                            if (obj2 != null) {
                                                                            }
                                                                        }
                                                                    }
                                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                                    }
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                        }
                                                    }
                                                }
                                            }
                                            i13 = measurer4.layout.getChildCount();
                                            while (i3 < i13) {
                                                childAt = measurer4.layout.getChildAt(i3);
                                                if (childAt instanceof Placeholder) {
                                                } else {
                                                    placeholder = (Placeholder) childAt;
                                                    constraintLayout = measurer4.layout;
                                                    throw null;
                                                }
                                            }
                                            i13 = measurer4.layout.mConstraintHelpers.size();
                                            if (i13 > 0) {
                                                for (i3 = 0; i3 < i13; i3++) {
                                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                                    constraintLayout2 = measurer4.layout;
                                                }
                                            }
                                        }
                                        basicMeasure.updateHierarchy(constraintWidget7);
                                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                        if (max5 > 0) {
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                        }
                                        if (i13 <= 0) {
                                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                            mode = 0;
                                            size = 0;
                                            while (mode < i13) {
                                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i5 = i9;
                                                    measurer = measurer3;
                                                } else {
                                                    max3 = constraintWidget4.getWidth();
                                                    max4 = constraintWidget4.getHeight();
                                                    i5 = i9;
                                                    measurer = measurer3;
                                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                                    size = constraintWidget4.getWidth();
                                                    i11 = i9;
                                                    i9 = constraintWidget4.getHeight();
                                                    if (size != max3) {
                                                        constraintWidget4.setWidth(size);
                                                        if (max5 != 2) {
                                                        }
                                                        i11 = 1;
                                                    }
                                                    if (i9 != max4) {
                                                        constraintWidget4.setHeight(i9);
                                                        if (i3 != 2) {
                                                        }
                                                        i11 = 1;
                                                    }
                                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                                    size = i11;
                                                }
                                                mode++;
                                                measurer3 = measurer;
                                                i9 = i5;
                                            }
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = 0;
                                            while (i9 < 2) {
                                                mode = 0;
                                                while (mode < i13) {
                                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                                    if (constraintWidget4 instanceof HelperWidget) {
                                                        if (constraintWidget4 instanceof VirtualLayout) {
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                    }
                                                    if (constraintWidget4 instanceof Guideline) {
                                                        if (constraintWidget4.mVisibility == 8) {
                                                            if (i7 == 0) {
                                                            }
                                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                                max3 = constraintWidget4.getWidth();
                                                                max4 = constraintWidget4.getHeight();
                                                                i11 = i13;
                                                                i13 = constraintWidget4.mBaselineDistance;
                                                                constraintWidget5 = constraintWidget7;
                                                                childCount = 1;
                                                                if (i9 == 1) {
                                                                    childCount = 2;
                                                                }
                                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                                size = constraintWidget4.getWidth();
                                                                i10 = childCount;
                                                                childCount = constraintWidget4.getHeight();
                                                                if (size != max3) {
                                                                    constraintWidget4.setWidth(size);
                                                                    if (max5 != 2) {
                                                                    }
                                                                    i10 = 1;
                                                                }
                                                                if (childCount != max4) {
                                                                    constraintWidget4.setHeight(childCount);
                                                                    if (i3 != 2) {
                                                                    }
                                                                    i10 = 1;
                                                                }
                                                                if (constraintWidget4.hasBaseline) {
                                                                }
                                                                size = i10;
                                                                mode++;
                                                                i13 = i11;
                                                                constraintWidget7 = constraintWidget5;
                                                            }
                                                            i11 = i13;
                                                            constraintWidget5 = constraintWidget7;
                                                            mode++;
                                                            i13 = i11;
                                                            constraintWidget7 = constraintWidget5;
                                                        }
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                                i11 = i13;
                                                constraintWidget5 = constraintWidget7;
                                                if (size == 0) {
                                                    i9++;
                                                    constraintWidget6 = constraintWidget5;
                                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                                    constraintWidget7 = constraintWidget6;
                                                    i13 = i11;
                                                    size = 0;
                                                } else {
                                                    constraintWidgetContainer2 = constraintWidget5;
                                                }
                                            }
                                            constraintWidgetContainer2 = constraintWidget7;
                                        } else {
                                            i5 = i9;
                                            constraintWidgetContainer2 = constraintWidget7;
                                        }
                                        constraintWidgetContainer2.setOptimizationLevel(i5);
                                        i12 = this.mLayoutWidget.getWidth();
                                        i13 = this.mLayoutWidget.getHeight();
                                        constraintWidgetContainer = this.mLayoutWidget;
                                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                        measurer5 = this.mMeasurer;
                                        i3 = measurer5.paddingHeight;
                                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                        if (z2) {
                                            i12 |= 16777216;
                                        }
                                        if (z3) {
                                            i13 |= 16777216;
                                        }
                                        setMeasuredDimension(i12, i13);
                                    }
                                    mode = 1073741824;
                                }
                                if (enabled) {
                                }
                                i3 = i6 & i3;
                                if (i3 == 0) {
                                    measurer3 = measurer2;
                                    i7 = i3;
                                    i13 = 0;
                                    i3 = 0;
                                } else {
                                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                    if (mode != 1073741824) {
                                    }
                                    constraintWidget7.setWidth(size);
                                    constraintWidget7.invalidateGraph();
                                    if (mode2 != 1073741824) {
                                    }
                                    constraintWidget7.setHeight(size2);
                                    constraintWidget7.invalidateGraph();
                                    if (mode == 1073741824) {
                                    }
                                    i7 = i3;
                                    dependencyGraph = constraintWidget7.mDependencyGraph;
                                    if (dependencyGraph.mNeedBuildGraph) {
                                        measurer3 = measurer2;
                                    } else {
                                        list = dependencyGraph.container.mChildren;
                                        i14 = list.size();
                                        max4 = 0;
                                        while (max4 < i14) {
                                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                                            constraintWidget2.ensureWidgetRuns();
                                            list2 = list;
                                            constraintWidget2.measured = false;
                                            i8 = i14;
                                            widgetRun = constraintWidget2.horizontalRun;
                                            measurer3 = measurer2;
                                            widgetRun.dimension.resolved = false;
                                            widgetRun.resolved = false;
                                            widgetRun.reset();
                                            widgetRun2 = constraintWidget2.verticalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            max4++;
                                            i14 = i8;
                                            list = list2;
                                            measurer2 = measurer3;
                                        }
                                        measurer3 = measurer2;
                                        dependencyGraph.container.ensureWidgetRuns();
                                        constraintWidget2 = dependencyGraph.container;
                                        constraintWidget2.measured = false;
                                        widgetRun2 = constraintWidget2.horizontalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        widgetRun2 = dependencyGraph.container.verticalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        dependencyGraph.buildGraph();
                                    }
                                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                    constraintWidget2 = dependencyGraph.container;
                                    constraintWidget2.f12mX = 0;
                                    constraintWidget2.f13mY = 0;
                                    constraintWidget2.horizontalRun.start.resolve(0);
                                    dependencyGraph.container.verticalRun.start.resolve(0);
                                    if (mode != 1073741824) {
                                        i13 = 0;
                                        i3 = 1;
                                    } else {
                                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                        i13 = 1;
                                    }
                                    if (mode2 != 1073741824) {
                                        i9 = 1;
                                    } else {
                                        i9 = 1;
                                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                        i13++;
                                    }
                                    if (i3 != 0) {
                                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                    }
                                }
                                i9 = constraintWidget7.mOptimizationLevel;
                                if (max5 > 0) {
                                    i13 = constraintWidget7.mChildren.size();
                                    optimizeFor = constraintWidget7.optimizeFor(64);
                                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                    for (size = 0; size < i13; size++) {
                                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                        if (constraintWidget3 instanceof Guideline) {
                                            if (!(constraintWidget3 instanceof Barrier)) {
                                                z = constraintWidget3.mInVirtualLayout;
                                                if (optimizeFor) {
                                                    widgetRun3 = constraintWidget3.horizontalRun;
                                                    if (widgetRun3 != null) {
                                                        widgetRun4 = constraintWidget3.verticalRun;
                                                        if (widgetRun4.dimension.resolved) {
                                                        }
                                                    }
                                                }
                                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                if (max2 == 3) {
                                                    obj2 = null;
                                                } else {
                                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                    }
                                                    obj2 = null;
                                                    max2 = 3;
                                                }
                                                if (obj2 == null) {
                                                    if (constraintWidget7.optimizeFor(1)) {
                                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                            if (max2 == 3) {
                                                            }
                                                            obj2 = null;
                                                            obj2 = 1;
                                                            if (max2 != 3) {
                                                                if (i14 == 3) {
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                            }
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                }
                                            }
                                        }
                                    }
                                    i13 = measurer4.layout.getChildCount();
                                    for (i3 = 0; i3 < i13; i3++) {
                                        childAt = measurer4.layout.getChildAt(i3);
                                        if (childAt instanceof Placeholder) {
                                            placeholder = (Placeholder) childAt;
                                            constraintLayout = measurer4.layout;
                                            throw null;
                                        }
                                    }
                                    i13 = measurer4.layout.mConstraintHelpers.size();
                                    if (i13 > 0) {
                                        for (i3 = 0; i3 < i13; i3++) {
                                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                            constraintLayout2 = measurer4.layout;
                                        }
                                    }
                                }
                                basicMeasure.updateHierarchy(constraintWidget7);
                                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                if (max5 > 0) {
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                }
                                if (i13 <= 0) {
                                    i5 = i9;
                                    constraintWidgetContainer2 = constraintWidget7;
                                } else {
                                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                    mode = 0;
                                    size = 0;
                                    while (mode < i13) {
                                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            max3 = constraintWidget4.getWidth();
                                            max4 = constraintWidget4.getHeight();
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                            size = constraintWidget4.getWidth();
                                            i11 = i9;
                                            i9 = constraintWidget4.getHeight();
                                            if (size != max3) {
                                                constraintWidget4.setWidth(size);
                                                if (max5 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            if (i9 != max4) {
                                                constraintWidget4.setHeight(i9);
                                                if (i3 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            virtualLayout = (VirtualLayout) constraintWidget4;
                                            size = i11;
                                        } else {
                                            i5 = i9;
                                            measurer = measurer3;
                                        }
                                        mode++;
                                        measurer3 = measurer;
                                        i9 = i5;
                                    }
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = 0;
                                    while (i9 < 2) {
                                        mode = 0;
                                        while (mode < i13) {
                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                            if (constraintWidget4 instanceof HelperWidget) {
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            if (constraintWidget4 instanceof Guideline) {
                                                if (constraintWidget4.mVisibility == 8) {
                                                    if (i7 == 0) {
                                                    }
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        max3 = constraintWidget4.getWidth();
                                                        max4 = constraintWidget4.getHeight();
                                                        i11 = i13;
                                                        i13 = constraintWidget4.mBaselineDistance;
                                                        constraintWidget5 = constraintWidget7;
                                                        childCount = 1;
                                                        if (i9 == 1) {
                                                            childCount = 2;
                                                        }
                                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                        size = constraintWidget4.getWidth();
                                                        i10 = childCount;
                                                        childCount = constraintWidget4.getHeight();
                                                        if (size != max3) {
                                                            constraintWidget4.setWidth(size);
                                                            if (max5 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (childCount != max4) {
                                                            constraintWidget4.setHeight(childCount);
                                                            if (i3 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (constraintWidget4.hasBaseline) {
                                                        }
                                                        size = i10;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                        i11 = i13;
                                        constraintWidget5 = constraintWidget7;
                                        if (size == 0) {
                                            constraintWidgetContainer2 = constraintWidget5;
                                        } else {
                                            i9++;
                                            constraintWidget6 = constraintWidget5;
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                            constraintWidget7 = constraintWidget6;
                                            i13 = i11;
                                            size = 0;
                                        }
                                    }
                                    constraintWidgetContainer2 = constraintWidget7;
                                }
                                constraintWidgetContainer2.setOptimizationLevel(i5);
                                i12 = this.mLayoutWidget.getWidth();
                                i13 = this.mLayoutWidget.getHeight();
                                constraintWidgetContainer = this.mLayoutWidget;
                                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                measurer5 = this.mMeasurer;
                                i3 = measurer5.paddingHeight;
                                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                if (z2) {
                                    i12 |= 16777216;
                                }
                                if (z3) {
                                    i13 |= 16777216;
                                }
                                setMeasuredDimension(i12, i13);
                            }
                            obj = null;
                        }
                        if (constraintWidget.isInVerticalChain()) {
                        }
                        if (constraintWidget instanceof VirtualLayout) {
                            i6 = 0;
                        } else {
                            if (constraintWidget.isInHorizontalChain()) {
                                if (!constraintWidget.isInVerticalChain()) {
                                    i14++;
                                    constraintLayout = this;
                                    i3 = i6;
                                }
                            }
                            i6 = 0;
                        }
                        if (mode == 1073741824) {
                            if (mode2 != 1073741824) {
                                mode = 1073741824;
                            } else {
                                i3 = 1;
                                mode = 1073741824;
                                mode2 = 1073741824;
                                i3 = i6 & i3;
                                if (i3 == 0) {
                                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                    if (mode != 1073741824) {
                                    }
                                    constraintWidget7.setWidth(size);
                                    constraintWidget7.invalidateGraph();
                                    if (mode2 != 1073741824) {
                                    }
                                    constraintWidget7.setHeight(size2);
                                    constraintWidget7.invalidateGraph();
                                    if (mode == 1073741824) {
                                    }
                                    i7 = i3;
                                    dependencyGraph = constraintWidget7.mDependencyGraph;
                                    if (dependencyGraph.mNeedBuildGraph) {
                                        list = dependencyGraph.container.mChildren;
                                        i14 = list.size();
                                        max4 = 0;
                                        while (max4 < i14) {
                                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                                            constraintWidget2.ensureWidgetRuns();
                                            list2 = list;
                                            constraintWidget2.measured = false;
                                            i8 = i14;
                                            widgetRun = constraintWidget2.horizontalRun;
                                            measurer3 = measurer2;
                                            widgetRun.dimension.resolved = false;
                                            widgetRun.resolved = false;
                                            widgetRun.reset();
                                            widgetRun2 = constraintWidget2.verticalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            max4++;
                                            i14 = i8;
                                            list = list2;
                                            measurer2 = measurer3;
                                        }
                                        measurer3 = measurer2;
                                        dependencyGraph.container.ensureWidgetRuns();
                                        constraintWidget2 = dependencyGraph.container;
                                        constraintWidget2.measured = false;
                                        widgetRun2 = constraintWidget2.horizontalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        widgetRun2 = dependencyGraph.container.verticalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        dependencyGraph.buildGraph();
                                    } else {
                                        measurer3 = measurer2;
                                    }
                                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                    constraintWidget2 = dependencyGraph.container;
                                    constraintWidget2.f12mX = 0;
                                    constraintWidget2.f13mY = 0;
                                    constraintWidget2.horizontalRun.start.resolve(0);
                                    dependencyGraph.container.verticalRun.start.resolve(0);
                                    if (mode != 1073741824) {
                                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                        i13 = 1;
                                    } else {
                                        i13 = 0;
                                        i3 = 1;
                                    }
                                    if (mode2 != 1073741824) {
                                        i9 = 1;
                                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                        i13++;
                                    } else {
                                        i9 = 1;
                                    }
                                    if (i3 != 0) {
                                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                    }
                                } else {
                                    measurer3 = measurer2;
                                    i7 = i3;
                                    i13 = 0;
                                    i3 = 0;
                                }
                                i9 = constraintWidget7.mOptimizationLevel;
                                if (max5 > 0) {
                                    i13 = constraintWidget7.mChildren.size();
                                    optimizeFor = constraintWidget7.optimizeFor(64);
                                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                    for (size = 0; size < i13; size++) {
                                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                        if (constraintWidget3 instanceof Guideline) {
                                            if (!(constraintWidget3 instanceof Barrier)) {
                                                z = constraintWidget3.mInVirtualLayout;
                                                if (optimizeFor) {
                                                    widgetRun3 = constraintWidget3.horizontalRun;
                                                    if (widgetRun3 != null) {
                                                        widgetRun4 = constraintWidget3.verticalRun;
                                                        if (widgetRun4.dimension.resolved) {
                                                        }
                                                    }
                                                }
                                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                if (max2 == 3) {
                                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                    }
                                                    obj2 = null;
                                                    max2 = 3;
                                                } else {
                                                    obj2 = null;
                                                }
                                                if (obj2 == null) {
                                                    if (constraintWidget7.optimizeFor(1)) {
                                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                            if (max2 == 3) {
                                                            }
                                                            obj2 = null;
                                                            obj2 = 1;
                                                            if (max2 != 3) {
                                                                if (i14 == 3) {
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                            }
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                }
                                            }
                                        }
                                    }
                                    i13 = measurer4.layout.getChildCount();
                                    while (i3 < i13) {
                                        childAt = measurer4.layout.getChildAt(i3);
                                        if (childAt instanceof Placeholder) {
                                        } else {
                                            placeholder = (Placeholder) childAt;
                                            constraintLayout = measurer4.layout;
                                            throw null;
                                        }
                                    }
                                    i13 = measurer4.layout.mConstraintHelpers.size();
                                    if (i13 > 0) {
                                        for (i3 = 0; i3 < i13; i3++) {
                                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                            constraintLayout2 = measurer4.layout;
                                        }
                                    }
                                }
                                basicMeasure.updateHierarchy(constraintWidget7);
                                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                if (max5 > 0) {
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                }
                                if (i13 <= 0) {
                                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                    mode = 0;
                                    size = 0;
                                    while (mode < i13) {
                                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i5 = i9;
                                            measurer = measurer3;
                                        } else {
                                            max3 = constraintWidget4.getWidth();
                                            max4 = constraintWidget4.getHeight();
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                            size = constraintWidget4.getWidth();
                                            i11 = i9;
                                            i9 = constraintWidget4.getHeight();
                                            if (size != max3) {
                                                constraintWidget4.setWidth(size);
                                                if (max5 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            if (i9 != max4) {
                                                constraintWidget4.setHeight(i9);
                                                if (i3 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            virtualLayout = (VirtualLayout) constraintWidget4;
                                            size = i11;
                                        }
                                        mode++;
                                        measurer3 = measurer;
                                        i9 = i5;
                                    }
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = 0;
                                    while (i9 < 2) {
                                        mode = 0;
                                        while (mode < i13) {
                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                            if (constraintWidget4 instanceof HelperWidget) {
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            if (constraintWidget4 instanceof Guideline) {
                                                if (constraintWidget4.mVisibility == 8) {
                                                    if (i7 == 0) {
                                                    }
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        max3 = constraintWidget4.getWidth();
                                                        max4 = constraintWidget4.getHeight();
                                                        i11 = i13;
                                                        i13 = constraintWidget4.mBaselineDistance;
                                                        constraintWidget5 = constraintWidget7;
                                                        childCount = 1;
                                                        if (i9 == 1) {
                                                            childCount = 2;
                                                        }
                                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                        size = constraintWidget4.getWidth();
                                                        i10 = childCount;
                                                        childCount = constraintWidget4.getHeight();
                                                        if (size != max3) {
                                                            constraintWidget4.setWidth(size);
                                                            if (max5 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (childCount != max4) {
                                                            constraintWidget4.setHeight(childCount);
                                                            if (i3 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (constraintWidget4.hasBaseline) {
                                                        }
                                                        size = i10;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                        i11 = i13;
                                        constraintWidget5 = constraintWidget7;
                                        if (size == 0) {
                                            i9++;
                                            constraintWidget6 = constraintWidget5;
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                            constraintWidget7 = constraintWidget6;
                                            i13 = i11;
                                            size = 0;
                                        } else {
                                            constraintWidgetContainer2 = constraintWidget5;
                                        }
                                    }
                                    constraintWidgetContainer2 = constraintWidget7;
                                } else {
                                    i5 = i9;
                                    constraintWidgetContainer2 = constraintWidget7;
                                }
                                constraintWidgetContainer2.setOptimizationLevel(i5);
                                i12 = this.mLayoutWidget.getWidth();
                                i13 = this.mLayoutWidget.getHeight();
                                constraintWidgetContainer = this.mLayoutWidget;
                                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                measurer5 = this.mMeasurer;
                                i3 = measurer5.paddingHeight;
                                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                if (z2) {
                                    i12 |= 16777216;
                                }
                                if (z3) {
                                    i13 |= 16777216;
                                }
                                setMeasuredDimension(i12, i13);
                            }
                        }
                        if (enabled) {
                        }
                        i3 = i6 & i3;
                        if (i3 == 0) {
                            measurer3 = measurer2;
                            i7 = i3;
                            i13 = 0;
                            i3 = 0;
                        } else {
                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                            if (mode != 1073741824) {
                            }
                            constraintWidget7.setWidth(size);
                            constraintWidget7.invalidateGraph();
                            if (mode2 != 1073741824) {
                            }
                            constraintWidget7.setHeight(size2);
                            constraintWidget7.invalidateGraph();
                            if (mode == 1073741824) {
                            }
                            i7 = i3;
                            dependencyGraph = constraintWidget7.mDependencyGraph;
                            if (dependencyGraph.mNeedBuildGraph) {
                                measurer3 = measurer2;
                            } else {
                                list = dependencyGraph.container.mChildren;
                                i14 = list.size();
                                max4 = 0;
                                while (max4 < i14) {
                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                    constraintWidget2.ensureWidgetRuns();
                                    list2 = list;
                                    constraintWidget2.measured = false;
                                    i8 = i14;
                                    widgetRun = constraintWidget2.horizontalRun;
                                    measurer3 = measurer2;
                                    widgetRun.dimension.resolved = false;
                                    widgetRun.resolved = false;
                                    widgetRun.reset();
                                    widgetRun2 = constraintWidget2.verticalRun;
                                    widgetRun2.dimension.resolved = false;
                                    widgetRun2.resolved = false;
                                    widgetRun2.reset();
                                    max4++;
                                    i14 = i8;
                                    list = list2;
                                    measurer2 = measurer3;
                                }
                                measurer3 = measurer2;
                                dependencyGraph.container.ensureWidgetRuns();
                                constraintWidget2 = dependencyGraph.container;
                                constraintWidget2.measured = false;
                                widgetRun2 = constraintWidget2.horizontalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                widgetRun2 = dependencyGraph.container.verticalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                dependencyGraph.buildGraph();
                            }
                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                            constraintWidget2 = dependencyGraph.container;
                            constraintWidget2.f12mX = 0;
                            constraintWidget2.f13mY = 0;
                            constraintWidget2.horizontalRun.start.resolve(0);
                            dependencyGraph.container.verticalRun.start.resolve(0);
                            if (mode != 1073741824) {
                                i13 = 0;
                                i3 = 1;
                            } else {
                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                i13 = 1;
                            }
                            if (mode2 != 1073741824) {
                                i9 = 1;
                            } else {
                                i9 = 1;
                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                i13++;
                            }
                            if (i3 != 0) {
                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                            }
                        }
                        i9 = constraintWidget7.mOptimizationLevel;
                        if (max5 > 0) {
                            i13 = constraintWidget7.mChildren.size();
                            optimizeFor = constraintWidget7.optimizeFor(64);
                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                            for (size = 0; size < i13; size++) {
                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                if (constraintWidget3 instanceof Guideline) {
                                    if (!(constraintWidget3 instanceof Barrier)) {
                                        z = constraintWidget3.mInVirtualLayout;
                                        if (optimizeFor) {
                                            widgetRun3 = constraintWidget3.horizontalRun;
                                            if (widgetRun3 != null) {
                                                widgetRun4 = constraintWidget3.verticalRun;
                                                if (widgetRun4.dimension.resolved) {
                                                }
                                            }
                                        }
                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                        if (max2 == 3) {
                                            obj2 = null;
                                        } else {
                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                            }
                                            obj2 = null;
                                            max2 = 3;
                                        }
                                        if (obj2 == null) {
                                            if (constraintWidget7.optimizeFor(1)) {
                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                    if (max2 == 3) {
                                                    }
                                                    obj2 = null;
                                                    obj2 = 1;
                                                    if (max2 != 3) {
                                                        if (i14 == 3) {
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                    }
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                        }
                                    }
                                }
                            }
                            i13 = measurer4.layout.getChildCount();
                            for (i3 = 0; i3 < i13; i3++) {
                                childAt = measurer4.layout.getChildAt(i3);
                                if (childAt instanceof Placeholder) {
                                    placeholder = (Placeholder) childAt;
                                    constraintLayout = measurer4.layout;
                                    throw null;
                                }
                            }
                            i13 = measurer4.layout.mConstraintHelpers.size();
                            if (i13 > 0) {
                                for (i3 = 0; i3 < i13; i3++) {
                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                    constraintLayout2 = measurer4.layout;
                                }
                            }
                        }
                        basicMeasure.updateHierarchy(constraintWidget7);
                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                        if (max5 > 0) {
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                        }
                        if (i13 <= 0) {
                            i5 = i9;
                            constraintWidgetContainer2 = constraintWidget7;
                        } else {
                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                            mode = 0;
                            size = 0;
                            while (mode < i13) {
                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    max3 = constraintWidget4.getWidth();
                                    max4 = constraintWidget4.getHeight();
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                    size = constraintWidget4.getWidth();
                                    i11 = i9;
                                    i9 = constraintWidget4.getHeight();
                                    if (size != max3) {
                                        constraintWidget4.setWidth(size);
                                        if (max5 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    if (i9 != max4) {
                                        constraintWidget4.setHeight(i9);
                                        if (i3 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                    size = i11;
                                } else {
                                    i5 = i9;
                                    measurer = measurer3;
                                }
                                mode++;
                                measurer3 = measurer;
                                i9 = i5;
                            }
                            i5 = i9;
                            measurer = measurer3;
                            i9 = 0;
                            while (i9 < 2) {
                                mode = 0;
                                while (mode < i13) {
                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                    if (constraintWidget4 instanceof HelperWidget) {
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    if (constraintWidget4 instanceof Guideline) {
                                        if (constraintWidget4.mVisibility == 8) {
                                            if (i7 == 0) {
                                            }
                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                max3 = constraintWidget4.getWidth();
                                                max4 = constraintWidget4.getHeight();
                                                i11 = i13;
                                                i13 = constraintWidget4.mBaselineDistance;
                                                constraintWidget5 = constraintWidget7;
                                                childCount = 1;
                                                if (i9 == 1) {
                                                    childCount = 2;
                                                }
                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                size = constraintWidget4.getWidth();
                                                i10 = childCount;
                                                childCount = constraintWidget4.getHeight();
                                                if (size != max3) {
                                                    constraintWidget4.setWidth(size);
                                                    if (max5 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (childCount != max4) {
                                                    constraintWidget4.setHeight(childCount);
                                                    if (i3 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (constraintWidget4.hasBaseline) {
                                                }
                                                size = i10;
                                                mode++;
                                                i13 = i11;
                                                constraintWidget7 = constraintWidget5;
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                                i11 = i13;
                                constraintWidget5 = constraintWidget7;
                                if (size == 0) {
                                    constraintWidgetContainer2 = constraintWidget5;
                                } else {
                                    i9++;
                                    constraintWidget6 = constraintWidget5;
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                    constraintWidget7 = constraintWidget6;
                                    i13 = i11;
                                    size = 0;
                                }
                            }
                            constraintWidgetContainer2 = constraintWidget7;
                        }
                        constraintWidgetContainer2.setOptimizationLevel(i5);
                        i12 = this.mLayoutWidget.getWidth();
                        i13 = this.mLayoutWidget.getHeight();
                        constraintWidgetContainer = this.mLayoutWidget;
                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                        measurer5 = this.mMeasurer;
                        i3 = measurer5.paddingHeight;
                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                        if (z2) {
                            i12 |= 16777216;
                        }
                        if (z3) {
                            i13 |= 16777216;
                        }
                        setMeasuredDimension(i12, i13);
                    }
                }
                i6 = i3;
                if (mode == 1073741824) {
                    if (mode2 != 1073741824) {
                        i3 = 1;
                        mode = 1073741824;
                        mode2 = 1073741824;
                        i3 = i6 & i3;
                        if (i3 == 0) {
                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                            if (mode != 1073741824) {
                            }
                            constraintWidget7.setWidth(size);
                            constraintWidget7.invalidateGraph();
                            if (mode2 != 1073741824) {
                            }
                            constraintWidget7.setHeight(size2);
                            constraintWidget7.invalidateGraph();
                            if (mode == 1073741824) {
                            }
                            i7 = i3;
                            dependencyGraph = constraintWidget7.mDependencyGraph;
                            if (dependencyGraph.mNeedBuildGraph) {
                                list = dependencyGraph.container.mChildren;
                                i14 = list.size();
                                max4 = 0;
                                while (max4 < i14) {
                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                    constraintWidget2.ensureWidgetRuns();
                                    list2 = list;
                                    constraintWidget2.measured = false;
                                    i8 = i14;
                                    widgetRun = constraintWidget2.horizontalRun;
                                    measurer3 = measurer2;
                                    widgetRun.dimension.resolved = false;
                                    widgetRun.resolved = false;
                                    widgetRun.reset();
                                    widgetRun2 = constraintWidget2.verticalRun;
                                    widgetRun2.dimension.resolved = false;
                                    widgetRun2.resolved = false;
                                    widgetRun2.reset();
                                    max4++;
                                    i14 = i8;
                                    list = list2;
                                    measurer2 = measurer3;
                                }
                                measurer3 = measurer2;
                                dependencyGraph.container.ensureWidgetRuns();
                                constraintWidget2 = dependencyGraph.container;
                                constraintWidget2.measured = false;
                                widgetRun2 = constraintWidget2.horizontalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                widgetRun2 = dependencyGraph.container.verticalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                dependencyGraph.buildGraph();
                            } else {
                                measurer3 = measurer2;
                            }
                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                            constraintWidget2 = dependencyGraph.container;
                            constraintWidget2.f12mX = 0;
                            constraintWidget2.f13mY = 0;
                            constraintWidget2.horizontalRun.start.resolve(0);
                            dependencyGraph.container.verticalRun.start.resolve(0);
                            if (mode != 1073741824) {
                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                i13 = 1;
                            } else {
                                i13 = 0;
                                i3 = 1;
                            }
                            if (mode2 != 1073741824) {
                                i9 = 1;
                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                i13++;
                            } else {
                                i9 = 1;
                            }
                            if (i3 != 0) {
                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                            }
                        } else {
                            measurer3 = measurer2;
                            i7 = i3;
                            i13 = 0;
                            i3 = 0;
                        }
                        i9 = constraintWidget7.mOptimizationLevel;
                        if (max5 > 0) {
                            i13 = constraintWidget7.mChildren.size();
                            optimizeFor = constraintWidget7.optimizeFor(64);
                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                            for (size = 0; size < i13; size++) {
                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                if (constraintWidget3 instanceof Guideline) {
                                    if (!(constraintWidget3 instanceof Barrier)) {
                                        z = constraintWidget3.mInVirtualLayout;
                                        if (optimizeFor) {
                                            widgetRun3 = constraintWidget3.horizontalRun;
                                            if (widgetRun3 != null) {
                                                widgetRun4 = constraintWidget3.verticalRun;
                                                if (widgetRun4.dimension.resolved) {
                                                }
                                            }
                                        }
                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                        if (max2 == 3) {
                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                            }
                                            obj2 = null;
                                            max2 = 3;
                                        } else {
                                            obj2 = null;
                                        }
                                        if (obj2 == null) {
                                            if (constraintWidget7.optimizeFor(1)) {
                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                    if (max2 == 3) {
                                                    }
                                                    obj2 = null;
                                                    obj2 = 1;
                                                    if (max2 != 3) {
                                                        if (i14 == 3) {
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                    }
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                        }
                                    }
                                }
                            }
                            i13 = measurer4.layout.getChildCount();
                            while (i3 < i13) {
                                childAt = measurer4.layout.getChildAt(i3);
                                if (childAt instanceof Placeholder) {
                                } else {
                                    placeholder = (Placeholder) childAt;
                                    constraintLayout = measurer4.layout;
                                    throw null;
                                }
                            }
                            i13 = measurer4.layout.mConstraintHelpers.size();
                            if (i13 > 0) {
                                for (i3 = 0; i3 < i13; i3++) {
                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                    constraintLayout2 = measurer4.layout;
                                }
                            }
                        }
                        basicMeasure.updateHierarchy(constraintWidget7);
                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                        if (max5 > 0) {
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                        }
                        if (i13 <= 0) {
                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                            mode = 0;
                            size = 0;
                            while (mode < i13) {
                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    i5 = i9;
                                    measurer = measurer3;
                                } else {
                                    max3 = constraintWidget4.getWidth();
                                    max4 = constraintWidget4.getHeight();
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                    size = constraintWidget4.getWidth();
                                    i11 = i9;
                                    i9 = constraintWidget4.getHeight();
                                    if (size != max3) {
                                        constraintWidget4.setWidth(size);
                                        if (max5 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    if (i9 != max4) {
                                        constraintWidget4.setHeight(i9);
                                        if (i3 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                    size = i11;
                                }
                                mode++;
                                measurer3 = measurer;
                                i9 = i5;
                            }
                            i5 = i9;
                            measurer = measurer3;
                            i9 = 0;
                            while (i9 < 2) {
                                mode = 0;
                                while (mode < i13) {
                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                    if (constraintWidget4 instanceof HelperWidget) {
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    if (constraintWidget4 instanceof Guideline) {
                                        if (constraintWidget4.mVisibility == 8) {
                                            if (i7 == 0) {
                                            }
                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                max3 = constraintWidget4.getWidth();
                                                max4 = constraintWidget4.getHeight();
                                                i11 = i13;
                                                i13 = constraintWidget4.mBaselineDistance;
                                                constraintWidget5 = constraintWidget7;
                                                childCount = 1;
                                                if (i9 == 1) {
                                                    childCount = 2;
                                                }
                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                size = constraintWidget4.getWidth();
                                                i10 = childCount;
                                                childCount = constraintWidget4.getHeight();
                                                if (size != max3) {
                                                    constraintWidget4.setWidth(size);
                                                    if (max5 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (childCount != max4) {
                                                    constraintWidget4.setHeight(childCount);
                                                    if (i3 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (constraintWidget4.hasBaseline) {
                                                }
                                                size = i10;
                                                mode++;
                                                i13 = i11;
                                                constraintWidget7 = constraintWidget5;
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                                i11 = i13;
                                constraintWidget5 = constraintWidget7;
                                if (size == 0) {
                                    i9++;
                                    constraintWidget6 = constraintWidget5;
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                    constraintWidget7 = constraintWidget6;
                                    i13 = i11;
                                    size = 0;
                                } else {
                                    constraintWidgetContainer2 = constraintWidget5;
                                }
                            }
                            constraintWidgetContainer2 = constraintWidget7;
                        } else {
                            i5 = i9;
                            constraintWidgetContainer2 = constraintWidget7;
                        }
                        constraintWidgetContainer2.setOptimizationLevel(i5);
                        i12 = this.mLayoutWidget.getWidth();
                        i13 = this.mLayoutWidget.getHeight();
                        constraintWidgetContainer = this.mLayoutWidget;
                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                        measurer5 = this.mMeasurer;
                        i3 = measurer5.paddingHeight;
                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                        if (z2) {
                            i12 |= 16777216;
                        }
                        if (z3) {
                            i13 |= 16777216;
                        }
                        setMeasuredDimension(i12, i13);
                    }
                    mode = 1073741824;
                }
                if (enabled) {
                }
                i3 = i6 & i3;
                if (i3 == 0) {
                    measurer3 = measurer2;
                    i7 = i3;
                    i13 = 0;
                    i3 = 0;
                } else {
                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                    if (mode != 1073741824) {
                    }
                    constraintWidget7.setWidth(size);
                    constraintWidget7.invalidateGraph();
                    if (mode2 != 1073741824) {
                    }
                    constraintWidget7.setHeight(size2);
                    constraintWidget7.invalidateGraph();
                    if (mode == 1073741824) {
                    }
                    i7 = i3;
                    dependencyGraph = constraintWidget7.mDependencyGraph;
                    if (dependencyGraph.mNeedBuildGraph) {
                        measurer3 = measurer2;
                    } else {
                        list = dependencyGraph.container.mChildren;
                        i14 = list.size();
                        max4 = 0;
                        while (max4 < i14) {
                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                            constraintWidget2.ensureWidgetRuns();
                            list2 = list;
                            constraintWidget2.measured = false;
                            i8 = i14;
                            widgetRun = constraintWidget2.horizontalRun;
                            measurer3 = measurer2;
                            widgetRun.dimension.resolved = false;
                            widgetRun.resolved = false;
                            widgetRun.reset();
                            widgetRun2 = constraintWidget2.verticalRun;
                            widgetRun2.dimension.resolved = false;
                            widgetRun2.resolved = false;
                            widgetRun2.reset();
                            max4++;
                            i14 = i8;
                            list = list2;
                            measurer2 = measurer3;
                        }
                        measurer3 = measurer2;
                        dependencyGraph.container.ensureWidgetRuns();
                        constraintWidget2 = dependencyGraph.container;
                        constraintWidget2.measured = false;
                        widgetRun2 = constraintWidget2.horizontalRun;
                        widgetRun2.dimension.resolved = false;
                        widgetRun2.resolved = false;
                        widgetRun2.reset();
                        widgetRun2 = dependencyGraph.container.verticalRun;
                        widgetRun2.dimension.resolved = false;
                        widgetRun2.resolved = false;
                        widgetRun2.reset();
                        dependencyGraph.buildGraph();
                    }
                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                    constraintWidget2 = dependencyGraph.container;
                    constraintWidget2.f12mX = 0;
                    constraintWidget2.f13mY = 0;
                    constraintWidget2.horizontalRun.start.resolve(0);
                    dependencyGraph.container.verticalRun.start.resolve(0);
                    if (mode != 1073741824) {
                        i13 = 0;
                        i3 = 1;
                    } else {
                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                        i13 = 1;
                    }
                    if (mode2 != 1073741824) {
                        i9 = 1;
                    } else {
                        i9 = 1;
                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                        i13++;
                    }
                    if (i3 != 0) {
                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                    }
                }
                i9 = constraintWidget7.mOptimizationLevel;
                if (max5 > 0) {
                    i13 = constraintWidget7.mChildren.size();
                    optimizeFor = constraintWidget7.optimizeFor(64);
                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                    for (size = 0; size < i13; size++) {
                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                        if (constraintWidget3 instanceof Guideline) {
                            if (!(constraintWidget3 instanceof Barrier)) {
                                z = constraintWidget3.mInVirtualLayout;
                                if (optimizeFor) {
                                    widgetRun3 = constraintWidget3.horizontalRun;
                                    if (widgetRun3 != null) {
                                        widgetRun4 = constraintWidget3.verticalRun;
                                        if (widgetRun4.dimension.resolved) {
                                        }
                                    }
                                }
                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                if (max2 == 3) {
                                    obj2 = null;
                                } else {
                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                    }
                                    obj2 = null;
                                    max2 = 3;
                                }
                                if (obj2 == null) {
                                    if (constraintWidget7.optimizeFor(1)) {
                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                            if (max2 == 3) {
                                            }
                                            obj2 = null;
                                            obj2 = 1;
                                            if (max2 != 3) {
                                                if (i14 == 3) {
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                            }
                                            if (obj2 != null) {
                                            }
                                        }
                                    }
                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                }
                            }
                        }
                    }
                    i13 = measurer4.layout.getChildCount();
                    for (i3 = 0; i3 < i13; i3++) {
                        childAt = measurer4.layout.getChildAt(i3);
                        if (childAt instanceof Placeholder) {
                            placeholder = (Placeholder) childAt;
                            constraintLayout = measurer4.layout;
                            throw null;
                        }
                    }
                    i13 = measurer4.layout.mConstraintHelpers.size();
                    if (i13 > 0) {
                        for (i3 = 0; i3 < i13; i3++) {
                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                            constraintLayout2 = measurer4.layout;
                        }
                    }
                }
                basicMeasure.updateHierarchy(constraintWidget7);
                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                if (max5 > 0) {
                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                }
                if (i13 <= 0) {
                    i5 = i9;
                    constraintWidgetContainer2 = constraintWidget7;
                } else {
                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                    mode = 0;
                    size = 0;
                    while (mode < i13) {
                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                        if (constraintWidget4 instanceof VirtualLayout) {
                            max3 = constraintWidget4.getWidth();
                            max4 = constraintWidget4.getHeight();
                            i5 = i9;
                            measurer = measurer3;
                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                            size = constraintWidget4.getWidth();
                            i11 = i9;
                            i9 = constraintWidget4.getHeight();
                            if (size != max3) {
                                constraintWidget4.setWidth(size);
                                if (max5 != 2) {
                                }
                                i11 = 1;
                            }
                            if (i9 != max4) {
                                constraintWidget4.setHeight(i9);
                                if (i3 != 2) {
                                }
                                i11 = 1;
                            }
                            virtualLayout = (VirtualLayout) constraintWidget4;
                            size = i11;
                        } else {
                            i5 = i9;
                            measurer = measurer3;
                        }
                        mode++;
                        measurer3 = measurer;
                        i9 = i5;
                    }
                    i5 = i9;
                    measurer = measurer3;
                    i9 = 0;
                    while (i9 < 2) {
                        mode = 0;
                        while (mode < i13) {
                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                            if (constraintWidget4 instanceof HelperWidget) {
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                            }
                            if (constraintWidget4 instanceof Guideline) {
                                if (constraintWidget4.mVisibility == 8) {
                                    if (i7 == 0) {
                                    }
                                    if (constraintWidget4 instanceof VirtualLayout) {
                                        max3 = constraintWidget4.getWidth();
                                        max4 = constraintWidget4.getHeight();
                                        i11 = i13;
                                        i13 = constraintWidget4.mBaselineDistance;
                                        constraintWidget5 = constraintWidget7;
                                        childCount = 1;
                                        if (i9 == 1) {
                                            childCount = 2;
                                        }
                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                        size = constraintWidget4.getWidth();
                                        i10 = childCount;
                                        childCount = constraintWidget4.getHeight();
                                        if (size != max3) {
                                            constraintWidget4.setWidth(size);
                                            if (max5 != 2) {
                                            }
                                            i10 = 1;
                                        }
                                        if (childCount != max4) {
                                            constraintWidget4.setHeight(childCount);
                                            if (i3 != 2) {
                                            }
                                            i10 = 1;
                                        }
                                        if (constraintWidget4.hasBaseline) {
                                        }
                                        size = i10;
                                        mode++;
                                        i13 = i11;
                                        constraintWidget7 = constraintWidget5;
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                            }
                            i11 = i13;
                            constraintWidget5 = constraintWidget7;
                            mode++;
                            i13 = i11;
                            constraintWidget7 = constraintWidget5;
                        }
                        i11 = i13;
                        constraintWidget5 = constraintWidget7;
                        if (size == 0) {
                            constraintWidgetContainer2 = constraintWidget5;
                        } else {
                            i9++;
                            constraintWidget6 = constraintWidget5;
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                            constraintWidget7 = constraintWidget6;
                            i13 = i11;
                            size = 0;
                        }
                    }
                    constraintWidgetContainer2 = constraintWidget7;
                }
                constraintWidgetContainer2.setOptimizationLevel(i5);
                i12 = this.mLayoutWidget.getWidth();
                i13 = this.mLayoutWidget.getHeight();
                constraintWidgetContainer = this.mLayoutWidget;
                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                measurer5 = this.mMeasurer;
                i3 = measurer5.paddingHeight;
                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                if (z2) {
                    i12 |= 16777216;
                }
                if (z3) {
                    i13 |= 16777216;
                }
                setMeasuredDimension(i12, i13);
            }
        }
        constraintWidget7.mDependencyGraph.mNeedRedoMeasures = true;
        constraintWidget7.f12mX = 0;
        constraintWidget7.f13mY = 0;
        i13 = r0.mMaxWidth;
        iArr = constraintWidget7.mMaxDimension;
        iArr[0] = i13 - max2;
        iArr[1] = r0.mMaxHeight - i14;
        constraintWidget7.setMinWidth(0);
        constraintWidget7.setMinHeight(0);
        constraintWidget7.setHorizontalDimensionBehaviour$ar$edu(i4);
        constraintWidget7.setWidth(max4);
        constraintWidget7.setVerticalDimensionBehaviour$ar$edu(i5);
        constraintWidget7.setHeight(max3);
        constraintWidget7.setMinWidth(r0.mMinWidth - max2);
        constraintWidget7.setMinHeight(r0.mMinHeight - i14);
        constraintWidget7.mPaddingLeft = max5;
        constraintWidget7.mPaddingTop = max;
        basicMeasure = constraintWidget7.mBasicMeasureSolver;
        measurer2 = constraintWidget7.mMeasurer$ar$class_merging;
        max5 = constraintWidget7.mChildren.size();
        width = constraintWidget7.getWidth();
        max = constraintWidget7.getHeight();
        enabled = Optimizer.enabled(i3, 128);
        if (enabled) {
        }
        if (i3 != 0) {
            i14 = 0;
            while (i14 < max5) {
                constraintWidget = (ConstraintWidget) constraintWidget7.mChildren.get(i14);
                max4 = constraintWidget.getHorizontalDimensionBehaviour$ar$edu();
                i6 = i3;
                i3 = constraintWidget.getVerticalDimensionBehaviour$ar$edu();
                if (max4 == 3) {
                }
                obj = null;
                if (constraintWidget.isInHorizontalChain()) {
                    if (obj == null) {
                        obj = null;
                    } else {
                        i6 = 0;
                        if (mode == 1073741824) {
                            if (mode2 != 1073741824) {
                                mode = 1073741824;
                            } else {
                                i3 = 1;
                                mode = 1073741824;
                                mode2 = 1073741824;
                                i3 = i6 & i3;
                                if (i3 == 0) {
                                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                                    if (mode != 1073741824) {
                                    }
                                    constraintWidget7.setWidth(size);
                                    constraintWidget7.invalidateGraph();
                                    if (mode2 != 1073741824) {
                                    }
                                    constraintWidget7.setHeight(size2);
                                    constraintWidget7.invalidateGraph();
                                    if (mode == 1073741824) {
                                    }
                                    i7 = i3;
                                    dependencyGraph = constraintWidget7.mDependencyGraph;
                                    if (dependencyGraph.mNeedBuildGraph) {
                                        list = dependencyGraph.container.mChildren;
                                        i14 = list.size();
                                        max4 = 0;
                                        while (max4 < i14) {
                                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                                            constraintWidget2.ensureWidgetRuns();
                                            list2 = list;
                                            constraintWidget2.measured = false;
                                            i8 = i14;
                                            widgetRun = constraintWidget2.horizontalRun;
                                            measurer3 = measurer2;
                                            widgetRun.dimension.resolved = false;
                                            widgetRun.resolved = false;
                                            widgetRun.reset();
                                            widgetRun2 = constraintWidget2.verticalRun;
                                            widgetRun2.dimension.resolved = false;
                                            widgetRun2.resolved = false;
                                            widgetRun2.reset();
                                            max4++;
                                            i14 = i8;
                                            list = list2;
                                            measurer2 = measurer3;
                                        }
                                        measurer3 = measurer2;
                                        dependencyGraph.container.ensureWidgetRuns();
                                        constraintWidget2 = dependencyGraph.container;
                                        constraintWidget2.measured = false;
                                        widgetRun2 = constraintWidget2.horizontalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        widgetRun2 = dependencyGraph.container.verticalRun;
                                        widgetRun2.dimension.resolved = false;
                                        widgetRun2.resolved = false;
                                        widgetRun2.reset();
                                        dependencyGraph.buildGraph();
                                    } else {
                                        measurer3 = measurer2;
                                    }
                                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                                    constraintWidget2 = dependencyGraph.container;
                                    constraintWidget2.f12mX = 0;
                                    constraintWidget2.f13mY = 0;
                                    constraintWidget2.horizontalRun.start.resolve(0);
                                    dependencyGraph.container.verticalRun.start.resolve(0);
                                    if (mode != 1073741824) {
                                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                        i13 = 1;
                                    } else {
                                        i13 = 0;
                                        i3 = 1;
                                    }
                                    if (mode2 != 1073741824) {
                                        i9 = 1;
                                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                        i13++;
                                    } else {
                                        i9 = 1;
                                    }
                                    if (i3 != 0) {
                                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                                    }
                                } else {
                                    measurer3 = measurer2;
                                    i7 = i3;
                                    i13 = 0;
                                    i3 = 0;
                                }
                                i9 = constraintWidget7.mOptimizationLevel;
                                if (max5 > 0) {
                                    i13 = constraintWidget7.mChildren.size();
                                    optimizeFor = constraintWidget7.optimizeFor(64);
                                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                                    for (size = 0; size < i13; size++) {
                                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                        if (constraintWidget3 instanceof Guideline) {
                                            if (!(constraintWidget3 instanceof Barrier)) {
                                                z = constraintWidget3.mInVirtualLayout;
                                                if (optimizeFor) {
                                                    widgetRun3 = constraintWidget3.horizontalRun;
                                                    if (widgetRun3 != null) {
                                                        widgetRun4 = constraintWidget3.verticalRun;
                                                        if (widgetRun4.dimension.resolved) {
                                                        }
                                                    }
                                                }
                                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                                if (max2 == 3) {
                                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                                    }
                                                    obj2 = null;
                                                    max2 = 3;
                                                } else {
                                                    obj2 = null;
                                                }
                                                if (obj2 == null) {
                                                    if (constraintWidget7.optimizeFor(1)) {
                                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                            if (max2 == 3) {
                                                            }
                                                            obj2 = null;
                                                            obj2 = 1;
                                                            if (max2 != 3) {
                                                                if (i14 == 3) {
                                                                    if (obj2 != null) {
                                                                    }
                                                                }
                                                            }
                                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                            }
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                                }
                                            }
                                        }
                                    }
                                    i13 = measurer4.layout.getChildCount();
                                    while (i3 < i13) {
                                        childAt = measurer4.layout.getChildAt(i3);
                                        if (childAt instanceof Placeholder) {
                                        } else {
                                            placeholder = (Placeholder) childAt;
                                            constraintLayout = measurer4.layout;
                                            throw null;
                                        }
                                    }
                                    i13 = measurer4.layout.mConstraintHelpers.size();
                                    if (i13 > 0) {
                                        for (i3 = 0; i3 < i13; i3++) {
                                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                            constraintLayout2 = measurer4.layout;
                                        }
                                    }
                                }
                                basicMeasure.updateHierarchy(constraintWidget7);
                                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                                if (max5 > 0) {
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                                }
                                if (i13 <= 0) {
                                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                                    mode = 0;
                                    size = 0;
                                    while (mode < i13) {
                                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i5 = i9;
                                            measurer = measurer3;
                                        } else {
                                            max3 = constraintWidget4.getWidth();
                                            max4 = constraintWidget4.getHeight();
                                            i5 = i9;
                                            measurer = measurer3;
                                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                            size = constraintWidget4.getWidth();
                                            i11 = i9;
                                            i9 = constraintWidget4.getHeight();
                                            if (size != max3) {
                                                constraintWidget4.setWidth(size);
                                                if (max5 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            if (i9 != max4) {
                                                constraintWidget4.setHeight(i9);
                                                if (i3 != 2) {
                                                }
                                                i11 = 1;
                                            }
                                            virtualLayout = (VirtualLayout) constraintWidget4;
                                            size = i11;
                                        }
                                        mode++;
                                        measurer3 = measurer;
                                        i9 = i5;
                                    }
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = 0;
                                    while (i9 < 2) {
                                        mode = 0;
                                        while (mode < i13) {
                                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                            if (constraintWidget4 instanceof HelperWidget) {
                                                if (constraintWidget4 instanceof VirtualLayout) {
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            if (constraintWidget4 instanceof Guideline) {
                                                if (constraintWidget4.mVisibility == 8) {
                                                    if (i7 == 0) {
                                                    }
                                                    if (constraintWidget4 instanceof VirtualLayout) {
                                                        max3 = constraintWidget4.getWidth();
                                                        max4 = constraintWidget4.getHeight();
                                                        i11 = i13;
                                                        i13 = constraintWidget4.mBaselineDistance;
                                                        constraintWidget5 = constraintWidget7;
                                                        childCount = 1;
                                                        if (i9 == 1) {
                                                            childCount = 2;
                                                        }
                                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                        size = constraintWidget4.getWidth();
                                                        i10 = childCount;
                                                        childCount = constraintWidget4.getHeight();
                                                        if (size != max3) {
                                                            constraintWidget4.setWidth(size);
                                                            if (max5 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (childCount != max4) {
                                                            constraintWidget4.setHeight(childCount);
                                                            if (i3 != 2) {
                                                            }
                                                            i10 = 1;
                                                        }
                                                        if (constraintWidget4.hasBaseline) {
                                                        }
                                                        size = i10;
                                                        mode++;
                                                        i13 = i11;
                                                        constraintWidget7 = constraintWidget5;
                                                    }
                                                    i11 = i13;
                                                    constraintWidget5 = constraintWidget7;
                                                    mode++;
                                                    i13 = i11;
                                                    constraintWidget7 = constraintWidget5;
                                                }
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                        i11 = i13;
                                        constraintWidget5 = constraintWidget7;
                                        if (size == 0) {
                                            i9++;
                                            constraintWidget6 = constraintWidget5;
                                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                            constraintWidget7 = constraintWidget6;
                                            i13 = i11;
                                            size = 0;
                                        } else {
                                            constraintWidgetContainer2 = constraintWidget5;
                                        }
                                    }
                                    constraintWidgetContainer2 = constraintWidget7;
                                } else {
                                    i5 = i9;
                                    constraintWidgetContainer2 = constraintWidget7;
                                }
                                constraintWidgetContainer2.setOptimizationLevel(i5);
                                i12 = this.mLayoutWidget.getWidth();
                                i13 = this.mLayoutWidget.getHeight();
                                constraintWidgetContainer = this.mLayoutWidget;
                                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                                measurer5 = this.mMeasurer;
                                i3 = measurer5.paddingHeight;
                                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                                if (z2) {
                                    i12 |= 16777216;
                                }
                                if (z3) {
                                    i13 |= 16777216;
                                }
                                setMeasuredDimension(i12, i13);
                            }
                        }
                        if (enabled) {
                        }
                        i3 = i6 & i3;
                        if (i3 == 0) {
                            measurer3 = measurer2;
                            i7 = i3;
                            i13 = 0;
                            i3 = 0;
                        } else {
                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                            if (mode != 1073741824) {
                            }
                            constraintWidget7.setWidth(size);
                            constraintWidget7.invalidateGraph();
                            if (mode2 != 1073741824) {
                            }
                            constraintWidget7.setHeight(size2);
                            constraintWidget7.invalidateGraph();
                            if (mode == 1073741824) {
                            }
                            i7 = i3;
                            dependencyGraph = constraintWidget7.mDependencyGraph;
                            if (dependencyGraph.mNeedBuildGraph) {
                                measurer3 = measurer2;
                            } else {
                                list = dependencyGraph.container.mChildren;
                                i14 = list.size();
                                max4 = 0;
                                while (max4 < i14) {
                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                    constraintWidget2.ensureWidgetRuns();
                                    list2 = list;
                                    constraintWidget2.measured = false;
                                    i8 = i14;
                                    widgetRun = constraintWidget2.horizontalRun;
                                    measurer3 = measurer2;
                                    widgetRun.dimension.resolved = false;
                                    widgetRun.resolved = false;
                                    widgetRun.reset();
                                    widgetRun2 = constraintWidget2.verticalRun;
                                    widgetRun2.dimension.resolved = false;
                                    widgetRun2.resolved = false;
                                    widgetRun2.reset();
                                    max4++;
                                    i14 = i8;
                                    list = list2;
                                    measurer2 = measurer3;
                                }
                                measurer3 = measurer2;
                                dependencyGraph.container.ensureWidgetRuns();
                                constraintWidget2 = dependencyGraph.container;
                                constraintWidget2.measured = false;
                                widgetRun2 = constraintWidget2.horizontalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                widgetRun2 = dependencyGraph.container.verticalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                dependencyGraph.buildGraph();
                            }
                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                            constraintWidget2 = dependencyGraph.container;
                            constraintWidget2.f12mX = 0;
                            constraintWidget2.f13mY = 0;
                            constraintWidget2.horizontalRun.start.resolve(0);
                            dependencyGraph.container.verticalRun.start.resolve(0);
                            if (mode != 1073741824) {
                                i13 = 0;
                                i3 = 1;
                            } else {
                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                i13 = 1;
                            }
                            if (mode2 != 1073741824) {
                                i9 = 1;
                            } else {
                                i9 = 1;
                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                i13++;
                            }
                            if (i3 != 0) {
                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                            }
                        }
                        i9 = constraintWidget7.mOptimizationLevel;
                        if (max5 > 0) {
                            i13 = constraintWidget7.mChildren.size();
                            optimizeFor = constraintWidget7.optimizeFor(64);
                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                            for (size = 0; size < i13; size++) {
                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                if (constraintWidget3 instanceof Guideline) {
                                    if (!(constraintWidget3 instanceof Barrier)) {
                                        z = constraintWidget3.mInVirtualLayout;
                                        if (optimizeFor) {
                                            widgetRun3 = constraintWidget3.horizontalRun;
                                            if (widgetRun3 != null) {
                                                widgetRun4 = constraintWidget3.verticalRun;
                                                if (widgetRun4.dimension.resolved) {
                                                }
                                            }
                                        }
                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                        if (max2 == 3) {
                                            obj2 = null;
                                        } else {
                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                            }
                                            obj2 = null;
                                            max2 = 3;
                                        }
                                        if (obj2 == null) {
                                            if (constraintWidget7.optimizeFor(1)) {
                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                    if (max2 == 3) {
                                                    }
                                                    obj2 = null;
                                                    obj2 = 1;
                                                    if (max2 != 3) {
                                                        if (i14 == 3) {
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                    }
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                        }
                                    }
                                }
                            }
                            i13 = measurer4.layout.getChildCount();
                            for (i3 = 0; i3 < i13; i3++) {
                                childAt = measurer4.layout.getChildAt(i3);
                                if (childAt instanceof Placeholder) {
                                    placeholder = (Placeholder) childAt;
                                    constraintLayout = measurer4.layout;
                                    throw null;
                                }
                            }
                            i13 = measurer4.layout.mConstraintHelpers.size();
                            if (i13 > 0) {
                                for (i3 = 0; i3 < i13; i3++) {
                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                    constraintLayout2 = measurer4.layout;
                                }
                            }
                        }
                        basicMeasure.updateHierarchy(constraintWidget7);
                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                        if (max5 > 0) {
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                        }
                        if (i13 <= 0) {
                            i5 = i9;
                            constraintWidgetContainer2 = constraintWidget7;
                        } else {
                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                            mode = 0;
                            size = 0;
                            while (mode < i13) {
                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    max3 = constraintWidget4.getWidth();
                                    max4 = constraintWidget4.getHeight();
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                    size = constraintWidget4.getWidth();
                                    i11 = i9;
                                    i9 = constraintWidget4.getHeight();
                                    if (size != max3) {
                                        constraintWidget4.setWidth(size);
                                        if (max5 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    if (i9 != max4) {
                                        constraintWidget4.setHeight(i9);
                                        if (i3 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                    size = i11;
                                } else {
                                    i5 = i9;
                                    measurer = measurer3;
                                }
                                mode++;
                                measurer3 = measurer;
                                i9 = i5;
                            }
                            i5 = i9;
                            measurer = measurer3;
                            i9 = 0;
                            while (i9 < 2) {
                                mode = 0;
                                while (mode < i13) {
                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                    if (constraintWidget4 instanceof HelperWidget) {
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    if (constraintWidget4 instanceof Guideline) {
                                        if (constraintWidget4.mVisibility == 8) {
                                            if (i7 == 0) {
                                            }
                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                max3 = constraintWidget4.getWidth();
                                                max4 = constraintWidget4.getHeight();
                                                i11 = i13;
                                                i13 = constraintWidget4.mBaselineDistance;
                                                constraintWidget5 = constraintWidget7;
                                                childCount = 1;
                                                if (i9 == 1) {
                                                    childCount = 2;
                                                }
                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                size = constraintWidget4.getWidth();
                                                i10 = childCount;
                                                childCount = constraintWidget4.getHeight();
                                                if (size != max3) {
                                                    constraintWidget4.setWidth(size);
                                                    if (max5 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (childCount != max4) {
                                                    constraintWidget4.setHeight(childCount);
                                                    if (i3 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (constraintWidget4.hasBaseline) {
                                                }
                                                size = i10;
                                                mode++;
                                                i13 = i11;
                                                constraintWidget7 = constraintWidget5;
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                                i11 = i13;
                                constraintWidget5 = constraintWidget7;
                                if (size == 0) {
                                    constraintWidgetContainer2 = constraintWidget5;
                                } else {
                                    i9++;
                                    constraintWidget6 = constraintWidget5;
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                    constraintWidget7 = constraintWidget6;
                                    i13 = i11;
                                    size = 0;
                                }
                            }
                            constraintWidgetContainer2 = constraintWidget7;
                        }
                        constraintWidgetContainer2.setOptimizationLevel(i5);
                        i12 = this.mLayoutWidget.getWidth();
                        i13 = this.mLayoutWidget.getHeight();
                        constraintWidgetContainer = this.mLayoutWidget;
                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                        measurer5 = this.mMeasurer;
                        i3 = measurer5.paddingHeight;
                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                        if (z2) {
                            i12 |= 16777216;
                        }
                        if (z3) {
                            i13 |= 16777216;
                        }
                        setMeasuredDimension(i12, i13);
                    }
                }
                if (constraintWidget.isInVerticalChain()) {
                }
                if (constraintWidget instanceof VirtualLayout) {
                    if (constraintWidget.isInHorizontalChain()) {
                        if (!constraintWidget.isInVerticalChain()) {
                            i14++;
                            constraintLayout = this;
                            i3 = i6;
                        }
                    }
                    i6 = 0;
                } else {
                    i6 = 0;
                }
                if (mode == 1073741824) {
                    if (mode2 != 1073741824) {
                        i3 = 1;
                        mode = 1073741824;
                        mode2 = 1073741824;
                        i3 = i6 & i3;
                        if (i3 == 0) {
                            size = Math.min(constraintWidget7.mMaxDimension[0], size);
                            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                            if (mode != 1073741824) {
                            }
                            constraintWidget7.setWidth(size);
                            constraintWidget7.invalidateGraph();
                            if (mode2 != 1073741824) {
                            }
                            constraintWidget7.setHeight(size2);
                            constraintWidget7.invalidateGraph();
                            if (mode == 1073741824) {
                            }
                            i7 = i3;
                            dependencyGraph = constraintWidget7.mDependencyGraph;
                            if (dependencyGraph.mNeedBuildGraph) {
                                list = dependencyGraph.container.mChildren;
                                i14 = list.size();
                                max4 = 0;
                                while (max4 < i14) {
                                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                                    constraintWidget2.ensureWidgetRuns();
                                    list2 = list;
                                    constraintWidget2.measured = false;
                                    i8 = i14;
                                    widgetRun = constraintWidget2.horizontalRun;
                                    measurer3 = measurer2;
                                    widgetRun.dimension.resolved = false;
                                    widgetRun.resolved = false;
                                    widgetRun.reset();
                                    widgetRun2 = constraintWidget2.verticalRun;
                                    widgetRun2.dimension.resolved = false;
                                    widgetRun2.resolved = false;
                                    widgetRun2.reset();
                                    max4++;
                                    i14 = i8;
                                    list = list2;
                                    measurer2 = measurer3;
                                }
                                measurer3 = measurer2;
                                dependencyGraph.container.ensureWidgetRuns();
                                constraintWidget2 = dependencyGraph.container;
                                constraintWidget2.measured = false;
                                widgetRun2 = constraintWidget2.horizontalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                widgetRun2 = dependencyGraph.container.verticalRun;
                                widgetRun2.dimension.resolved = false;
                                widgetRun2.resolved = false;
                                widgetRun2.reset();
                                dependencyGraph.buildGraph();
                            } else {
                                measurer3 = measurer2;
                            }
                            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                            constraintWidget2 = dependencyGraph.container;
                            constraintWidget2.f12mX = 0;
                            constraintWidget2.f13mY = 0;
                            constraintWidget2.horizontalRun.start.resolve(0);
                            dependencyGraph.container.verticalRun.start.resolve(0);
                            if (mode != 1073741824) {
                                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                                i13 = 1;
                            } else {
                                i13 = 0;
                                i3 = 1;
                            }
                            if (mode2 != 1073741824) {
                                i9 = 1;
                                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                                i13++;
                            } else {
                                i9 = 1;
                            }
                            if (i3 != 0) {
                                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                            }
                        } else {
                            measurer3 = measurer2;
                            i7 = i3;
                            i13 = 0;
                            i3 = 0;
                        }
                        i9 = constraintWidget7.mOptimizationLevel;
                        if (max5 > 0) {
                            i13 = constraintWidget7.mChildren.size();
                            optimizeFor = constraintWidget7.optimizeFor(64);
                            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                            for (size = 0; size < i13; size++) {
                                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                                if (constraintWidget3 instanceof Guideline) {
                                    if (!(constraintWidget3 instanceof Barrier)) {
                                        z = constraintWidget3.mInVirtualLayout;
                                        if (optimizeFor) {
                                            widgetRun3 = constraintWidget3.horizontalRun;
                                            if (widgetRun3 != null) {
                                                widgetRun4 = constraintWidget3.verticalRun;
                                                if (widgetRun4.dimension.resolved) {
                                                }
                                            }
                                        }
                                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                        if (max2 == 3) {
                                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                            }
                                            obj2 = null;
                                            max2 = 3;
                                        } else {
                                            obj2 = null;
                                        }
                                        if (obj2 == null) {
                                            if (constraintWidget7.optimizeFor(1)) {
                                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                                    if (max2 == 3) {
                                                    }
                                                    obj2 = null;
                                                    obj2 = 1;
                                                    if (max2 != 3) {
                                                        if (i14 == 3) {
                                                            if (obj2 != null) {
                                                            }
                                                        }
                                                    }
                                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                                    }
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                        }
                                    }
                                }
                            }
                            i13 = measurer4.layout.getChildCount();
                            while (i3 < i13) {
                                childAt = measurer4.layout.getChildAt(i3);
                                if (childAt instanceof Placeholder) {
                                } else {
                                    placeholder = (Placeholder) childAt;
                                    constraintLayout = measurer4.layout;
                                    throw null;
                                }
                            }
                            i13 = measurer4.layout.mConstraintHelpers.size();
                            if (i13 > 0) {
                                for (i3 = 0; i3 < i13; i3++) {
                                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                                    constraintLayout2 = measurer4.layout;
                                }
                            }
                        }
                        basicMeasure.updateHierarchy(constraintWidget7);
                        i13 = basicMeasure.mVariableDimensionsWidgets.size();
                        if (max5 > 0) {
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                        }
                        if (i13 <= 0) {
                            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                            mode = 0;
                            size = 0;
                            while (mode < i13) {
                                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    i5 = i9;
                                    measurer = measurer3;
                                } else {
                                    max3 = constraintWidget4.getWidth();
                                    max4 = constraintWidget4.getHeight();
                                    i5 = i9;
                                    measurer = measurer3;
                                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                                    size = constraintWidget4.getWidth();
                                    i11 = i9;
                                    i9 = constraintWidget4.getHeight();
                                    if (size != max3) {
                                        constraintWidget4.setWidth(size);
                                        if (max5 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    if (i9 != max4) {
                                        constraintWidget4.setHeight(i9);
                                        if (i3 != 2) {
                                        }
                                        i11 = 1;
                                    }
                                    virtualLayout = (VirtualLayout) constraintWidget4;
                                    size = i11;
                                }
                                mode++;
                                measurer3 = measurer;
                                i9 = i5;
                            }
                            i5 = i9;
                            measurer = measurer3;
                            i9 = 0;
                            while (i9 < 2) {
                                mode = 0;
                                while (mode < i13) {
                                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                                    if (constraintWidget4 instanceof HelperWidget) {
                                        if (constraintWidget4 instanceof VirtualLayout) {
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    if (constraintWidget4 instanceof Guideline) {
                                        if (constraintWidget4.mVisibility == 8) {
                                            if (i7 == 0) {
                                            }
                                            if (constraintWidget4 instanceof VirtualLayout) {
                                                max3 = constraintWidget4.getWidth();
                                                max4 = constraintWidget4.getHeight();
                                                i11 = i13;
                                                i13 = constraintWidget4.mBaselineDistance;
                                                constraintWidget5 = constraintWidget7;
                                                childCount = 1;
                                                if (i9 == 1) {
                                                    childCount = 2;
                                                }
                                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                                size = constraintWidget4.getWidth();
                                                i10 = childCount;
                                                childCount = constraintWidget4.getHeight();
                                                if (size != max3) {
                                                    constraintWidget4.setWidth(size);
                                                    if (max5 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (childCount != max4) {
                                                    constraintWidget4.setHeight(childCount);
                                                    if (i3 != 2) {
                                                    }
                                                    i10 = 1;
                                                }
                                                if (constraintWidget4.hasBaseline) {
                                                }
                                                size = i10;
                                                mode++;
                                                i13 = i11;
                                                constraintWidget7 = constraintWidget5;
                                            }
                                            i11 = i13;
                                            constraintWidget5 = constraintWidget7;
                                            mode++;
                                            i13 = i11;
                                            constraintWidget7 = constraintWidget5;
                                        }
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                                i11 = i13;
                                constraintWidget5 = constraintWidget7;
                                if (size == 0) {
                                    i9++;
                                    constraintWidget6 = constraintWidget5;
                                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                                    constraintWidget7 = constraintWidget6;
                                    i13 = i11;
                                    size = 0;
                                } else {
                                    constraintWidgetContainer2 = constraintWidget5;
                                }
                            }
                            constraintWidgetContainer2 = constraintWidget7;
                        } else {
                            i5 = i9;
                            constraintWidgetContainer2 = constraintWidget7;
                        }
                        constraintWidgetContainer2.setOptimizationLevel(i5);
                        i12 = this.mLayoutWidget.getWidth();
                        i13 = this.mLayoutWidget.getHeight();
                        constraintWidgetContainer = this.mLayoutWidget;
                        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                        measurer5 = this.mMeasurer;
                        i3 = measurer5.paddingHeight;
                        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                        i13 = resolveSizeAndState(i13 + i3, i2, 0);
                        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                        if (z2) {
                            i12 |= 16777216;
                        }
                        if (z3) {
                            i13 |= 16777216;
                        }
                        setMeasuredDimension(i12, i13);
                    }
                    mode = 1073741824;
                }
                if (enabled) {
                }
                i3 = i6 & i3;
                if (i3 == 0) {
                    measurer3 = measurer2;
                    i7 = i3;
                    i13 = 0;
                    i3 = 0;
                } else {
                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                    if (mode != 1073741824) {
                    }
                    constraintWidget7.setWidth(size);
                    constraintWidget7.invalidateGraph();
                    if (mode2 != 1073741824) {
                    }
                    constraintWidget7.setHeight(size2);
                    constraintWidget7.invalidateGraph();
                    if (mode == 1073741824) {
                    }
                    i7 = i3;
                    dependencyGraph = constraintWidget7.mDependencyGraph;
                    if (dependencyGraph.mNeedBuildGraph) {
                        measurer3 = measurer2;
                    } else {
                        list = dependencyGraph.container.mChildren;
                        i14 = list.size();
                        max4 = 0;
                        while (max4 < i14) {
                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                            constraintWidget2.ensureWidgetRuns();
                            list2 = list;
                            constraintWidget2.measured = false;
                            i8 = i14;
                            widgetRun = constraintWidget2.horizontalRun;
                            measurer3 = measurer2;
                            widgetRun.dimension.resolved = false;
                            widgetRun.resolved = false;
                            widgetRun.reset();
                            widgetRun2 = constraintWidget2.verticalRun;
                            widgetRun2.dimension.resolved = false;
                            widgetRun2.resolved = false;
                            widgetRun2.reset();
                            max4++;
                            i14 = i8;
                            list = list2;
                            measurer2 = measurer3;
                        }
                        measurer3 = measurer2;
                        dependencyGraph.container.ensureWidgetRuns();
                        constraintWidget2 = dependencyGraph.container;
                        constraintWidget2.measured = false;
                        widgetRun2 = constraintWidget2.horizontalRun;
                        widgetRun2.dimension.resolved = false;
                        widgetRun2.resolved = false;
                        widgetRun2.reset();
                        widgetRun2 = dependencyGraph.container.verticalRun;
                        widgetRun2.dimension.resolved = false;
                        widgetRun2.resolved = false;
                        widgetRun2.reset();
                        dependencyGraph.buildGraph();
                    }
                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                    constraintWidget2 = dependencyGraph.container;
                    constraintWidget2.f12mX = 0;
                    constraintWidget2.f13mY = 0;
                    constraintWidget2.horizontalRun.start.resolve(0);
                    dependencyGraph.container.verticalRun.start.resolve(0);
                    if (mode != 1073741824) {
                        i13 = 0;
                        i3 = 1;
                    } else {
                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                        i13 = 1;
                    }
                    if (mode2 != 1073741824) {
                        i9 = 1;
                    } else {
                        i9 = 1;
                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                        i13++;
                    }
                    if (i3 != 0) {
                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                    }
                }
                i9 = constraintWidget7.mOptimizationLevel;
                if (max5 > 0) {
                    i13 = constraintWidget7.mChildren.size();
                    optimizeFor = constraintWidget7.optimizeFor(64);
                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                    for (size = 0; size < i13; size++) {
                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                        if (constraintWidget3 instanceof Guideline) {
                            if (!(constraintWidget3 instanceof Barrier)) {
                                z = constraintWidget3.mInVirtualLayout;
                                if (optimizeFor) {
                                    widgetRun3 = constraintWidget3.horizontalRun;
                                    if (widgetRun3 != null) {
                                        widgetRun4 = constraintWidget3.verticalRun;
                                        if (widgetRun4.dimension.resolved) {
                                        }
                                    }
                                }
                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                if (max2 == 3) {
                                    obj2 = null;
                                } else {
                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                    }
                                    obj2 = null;
                                    max2 = 3;
                                }
                                if (obj2 == null) {
                                    if (constraintWidget7.optimizeFor(1)) {
                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                            if (max2 == 3) {
                                            }
                                            obj2 = null;
                                            obj2 = 1;
                                            if (max2 != 3) {
                                                if (i14 == 3) {
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                            }
                                            if (obj2 != null) {
                                            }
                                        }
                                    }
                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                }
                            }
                        }
                    }
                    i13 = measurer4.layout.getChildCount();
                    for (i3 = 0; i3 < i13; i3++) {
                        childAt = measurer4.layout.getChildAt(i3);
                        if (childAt instanceof Placeholder) {
                            placeholder = (Placeholder) childAt;
                            constraintLayout = measurer4.layout;
                            throw null;
                        }
                    }
                    i13 = measurer4.layout.mConstraintHelpers.size();
                    if (i13 > 0) {
                        for (i3 = 0; i3 < i13; i3++) {
                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                            constraintLayout2 = measurer4.layout;
                        }
                    }
                }
                basicMeasure.updateHierarchy(constraintWidget7);
                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                if (max5 > 0) {
                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                }
                if (i13 <= 0) {
                    i5 = i9;
                    constraintWidgetContainer2 = constraintWidget7;
                } else {
                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                    mode = 0;
                    size = 0;
                    while (mode < i13) {
                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                        if (constraintWidget4 instanceof VirtualLayout) {
                            max3 = constraintWidget4.getWidth();
                            max4 = constraintWidget4.getHeight();
                            i5 = i9;
                            measurer = measurer3;
                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                            size = constraintWidget4.getWidth();
                            i11 = i9;
                            i9 = constraintWidget4.getHeight();
                            if (size != max3) {
                                constraintWidget4.setWidth(size);
                                if (max5 != 2) {
                                }
                                i11 = 1;
                            }
                            if (i9 != max4) {
                                constraintWidget4.setHeight(i9);
                                if (i3 != 2) {
                                }
                                i11 = 1;
                            }
                            virtualLayout = (VirtualLayout) constraintWidget4;
                            size = i11;
                        } else {
                            i5 = i9;
                            measurer = measurer3;
                        }
                        mode++;
                        measurer3 = measurer;
                        i9 = i5;
                    }
                    i5 = i9;
                    measurer = measurer3;
                    i9 = 0;
                    while (i9 < 2) {
                        mode = 0;
                        while (mode < i13) {
                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                            if (constraintWidget4 instanceof HelperWidget) {
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                            }
                            if (constraintWidget4 instanceof Guideline) {
                                if (constraintWidget4.mVisibility == 8) {
                                    if (i7 == 0) {
                                    }
                                    if (constraintWidget4 instanceof VirtualLayout) {
                                        max3 = constraintWidget4.getWidth();
                                        max4 = constraintWidget4.getHeight();
                                        i11 = i13;
                                        i13 = constraintWidget4.mBaselineDistance;
                                        constraintWidget5 = constraintWidget7;
                                        childCount = 1;
                                        if (i9 == 1) {
                                            childCount = 2;
                                        }
                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                        size = constraintWidget4.getWidth();
                                        i10 = childCount;
                                        childCount = constraintWidget4.getHeight();
                                        if (size != max3) {
                                            constraintWidget4.setWidth(size);
                                            if (max5 != 2) {
                                            }
                                            i10 = 1;
                                        }
                                        if (childCount != max4) {
                                            constraintWidget4.setHeight(childCount);
                                            if (i3 != 2) {
                                            }
                                            i10 = 1;
                                        }
                                        if (constraintWidget4.hasBaseline) {
                                        }
                                        size = i10;
                                        mode++;
                                        i13 = i11;
                                        constraintWidget7 = constraintWidget5;
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                            }
                            i11 = i13;
                            constraintWidget5 = constraintWidget7;
                            mode++;
                            i13 = i11;
                            constraintWidget7 = constraintWidget5;
                        }
                        i11 = i13;
                        constraintWidget5 = constraintWidget7;
                        if (size == 0) {
                            constraintWidgetContainer2 = constraintWidget5;
                        } else {
                            i9++;
                            constraintWidget6 = constraintWidget5;
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                            constraintWidget7 = constraintWidget6;
                            i13 = i11;
                            size = 0;
                        }
                    }
                    constraintWidgetContainer2 = constraintWidget7;
                }
                constraintWidgetContainer2.setOptimizationLevel(i5);
                i12 = this.mLayoutWidget.getWidth();
                i13 = this.mLayoutWidget.getHeight();
                constraintWidgetContainer = this.mLayoutWidget;
                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                measurer5 = this.mMeasurer;
                i3 = measurer5.paddingHeight;
                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                if (z2) {
                    i12 |= 16777216;
                }
                if (z3) {
                    i13 |= 16777216;
                }
                setMeasuredDimension(i12, i13);
            }
        }
        i6 = i3;
        if (mode == 1073741824) {
            if (mode2 != 1073741824) {
                mode = 1073741824;
            } else {
                i3 = 1;
                mode = 1073741824;
                mode2 = 1073741824;
                i3 = i6 & i3;
                if (i3 == 0) {
                    size = Math.min(constraintWidget7.mMaxDimension[0], size);
                    size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
                    if (mode != 1073741824) {
                    }
                    constraintWidget7.setWidth(size);
                    constraintWidget7.invalidateGraph();
                    if (mode2 != 1073741824) {
                    }
                    constraintWidget7.setHeight(size2);
                    constraintWidget7.invalidateGraph();
                    if (mode == 1073741824) {
                    }
                    i7 = i3;
                    dependencyGraph = constraintWidget7.mDependencyGraph;
                    if (dependencyGraph.mNeedBuildGraph) {
                        list = dependencyGraph.container.mChildren;
                        i14 = list.size();
                        max4 = 0;
                        while (max4 < i14) {
                            constraintWidget2 = (ConstraintWidget) list.get(max4);
                            constraintWidget2.ensureWidgetRuns();
                            list2 = list;
                            constraintWidget2.measured = false;
                            i8 = i14;
                            widgetRun = constraintWidget2.horizontalRun;
                            measurer3 = measurer2;
                            widgetRun.dimension.resolved = false;
                            widgetRun.resolved = false;
                            widgetRun.reset();
                            widgetRun2 = constraintWidget2.verticalRun;
                            widgetRun2.dimension.resolved = false;
                            widgetRun2.resolved = false;
                            widgetRun2.reset();
                            max4++;
                            i14 = i8;
                            list = list2;
                            measurer2 = measurer3;
                        }
                        measurer3 = measurer2;
                        dependencyGraph.container.ensureWidgetRuns();
                        constraintWidget2 = dependencyGraph.container;
                        constraintWidget2.measured = false;
                        widgetRun2 = constraintWidget2.horizontalRun;
                        widgetRun2.dimension.resolved = false;
                        widgetRun2.resolved = false;
                        widgetRun2.reset();
                        widgetRun2 = dependencyGraph.container.verticalRun;
                        widgetRun2.dimension.resolved = false;
                        widgetRun2.resolved = false;
                        widgetRun2.reset();
                        dependencyGraph.buildGraph();
                    } else {
                        measurer3 = measurer2;
                    }
                    dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
                    constraintWidget2 = dependencyGraph.container;
                    constraintWidget2.f12mX = 0;
                    constraintWidget2.f13mY = 0;
                    constraintWidget2.horizontalRun.start.resolve(0);
                    dependencyGraph.container.verticalRun.start.resolve(0);
                    if (mode != 1073741824) {
                        i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                        i13 = 1;
                    } else {
                        i13 = 0;
                        i3 = 1;
                    }
                    if (mode2 != 1073741824) {
                        i9 = 1;
                        i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                        i13++;
                    } else {
                        i9 = 1;
                    }
                    if (i3 != 0) {
                        constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
                    }
                } else {
                    measurer3 = measurer2;
                    i7 = i3;
                    i13 = 0;
                    i3 = 0;
                }
                i9 = constraintWidget7.mOptimizationLevel;
                if (max5 > 0) {
                    i13 = constraintWidget7.mChildren.size();
                    optimizeFor = constraintWidget7.optimizeFor(64);
                    measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
                    for (size = 0; size < i13; size++) {
                        constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                        if (constraintWidget3 instanceof Guideline) {
                            if (!(constraintWidget3 instanceof Barrier)) {
                                z = constraintWidget3.mInVirtualLayout;
                                if (optimizeFor) {
                                    widgetRun3 = constraintWidget3.horizontalRun;
                                    if (widgetRun3 != null) {
                                        widgetRun4 = constraintWidget3.verticalRun;
                                        if (widgetRun4.dimension.resolved) {
                                        }
                                    }
                                }
                                max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                                i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                                if (max2 == 3) {
                                    if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                                    }
                                    obj2 = null;
                                    max2 = 3;
                                } else {
                                    obj2 = null;
                                }
                                if (obj2 == null) {
                                    if (constraintWidget7.optimizeFor(1)) {
                                        if (!(constraintWidget3 instanceof VirtualLayout)) {
                                            if (max2 == 3) {
                                            }
                                            obj2 = null;
                                            obj2 = 1;
                                            if (max2 != 3) {
                                                if (i14 == 3) {
                                                    if (obj2 != null) {
                                                    }
                                                }
                                            }
                                            if (constraintWidget3.mDimensionRatio > 0.0f) {
                                            }
                                            if (obj2 != null) {
                                            }
                                        }
                                    }
                                    basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                                }
                            }
                        }
                    }
                    i13 = measurer4.layout.getChildCount();
                    while (i3 < i13) {
                        childAt = measurer4.layout.getChildAt(i3);
                        if (childAt instanceof Placeholder) {
                        } else {
                            placeholder = (Placeholder) childAt;
                            constraintLayout = measurer4.layout;
                            throw null;
                        }
                    }
                    i13 = measurer4.layout.mConstraintHelpers.size();
                    if (i13 > 0) {
                        for (i3 = 0; i3 < i13; i3++) {
                            constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                            constraintLayout2 = measurer4.layout;
                        }
                    }
                }
                basicMeasure.updateHierarchy(constraintWidget7);
                i13 = basicMeasure.mVariableDimensionsWidgets.size();
                if (max5 > 0) {
                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
                }
                if (i13 <= 0) {
                    max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
                    i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
                    mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
                    size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
                    mode = 0;
                    size = 0;
                    while (mode < i13) {
                        constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                        if (constraintWidget4 instanceof VirtualLayout) {
                            i5 = i9;
                            measurer = measurer3;
                        } else {
                            max3 = constraintWidget4.getWidth();
                            max4 = constraintWidget4.getHeight();
                            i5 = i9;
                            measurer = measurer3;
                            i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                            size = constraintWidget4.getWidth();
                            i11 = i9;
                            i9 = constraintWidget4.getHeight();
                            if (size != max3) {
                                constraintWidget4.setWidth(size);
                                if (max5 != 2) {
                                }
                                i11 = 1;
                            }
                            if (i9 != max4) {
                                constraintWidget4.setHeight(i9);
                                if (i3 != 2) {
                                }
                                i11 = 1;
                            }
                            virtualLayout = (VirtualLayout) constraintWidget4;
                            size = i11;
                        }
                        mode++;
                        measurer3 = measurer;
                        i9 = i5;
                    }
                    i5 = i9;
                    measurer = measurer3;
                    i9 = 0;
                    while (i9 < 2) {
                        mode = 0;
                        while (mode < i13) {
                            constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                            if (constraintWidget4 instanceof HelperWidget) {
                                if (constraintWidget4 instanceof VirtualLayout) {
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                            }
                            if (constraintWidget4 instanceof Guideline) {
                                if (constraintWidget4.mVisibility == 8) {
                                    if (i7 == 0) {
                                    }
                                    if (constraintWidget4 instanceof VirtualLayout) {
                                        max3 = constraintWidget4.getWidth();
                                        max4 = constraintWidget4.getHeight();
                                        i11 = i13;
                                        i13 = constraintWidget4.mBaselineDistance;
                                        constraintWidget5 = constraintWidget7;
                                        childCount = 1;
                                        if (i9 == 1) {
                                            childCount = 2;
                                        }
                                        childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                        size = constraintWidget4.getWidth();
                                        i10 = childCount;
                                        childCount = constraintWidget4.getHeight();
                                        if (size != max3) {
                                            constraintWidget4.setWidth(size);
                                            if (max5 != 2) {
                                            }
                                            i10 = 1;
                                        }
                                        if (childCount != max4) {
                                            constraintWidget4.setHeight(childCount);
                                            if (i3 != 2) {
                                            }
                                            i10 = 1;
                                        }
                                        if (constraintWidget4.hasBaseline) {
                                        }
                                        size = i10;
                                        mode++;
                                        i13 = i11;
                                        constraintWidget7 = constraintWidget5;
                                    }
                                    i11 = i13;
                                    constraintWidget5 = constraintWidget7;
                                    mode++;
                                    i13 = i11;
                                    constraintWidget7 = constraintWidget5;
                                }
                            }
                            i11 = i13;
                            constraintWidget5 = constraintWidget7;
                            mode++;
                            i13 = i11;
                            constraintWidget7 = constraintWidget5;
                        }
                        i11 = i13;
                        constraintWidget5 = constraintWidget7;
                        if (size == 0) {
                            i9++;
                            constraintWidget6 = constraintWidget5;
                            basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                            constraintWidget7 = constraintWidget6;
                            i13 = i11;
                            size = 0;
                        } else {
                            constraintWidgetContainer2 = constraintWidget5;
                        }
                    }
                    constraintWidgetContainer2 = constraintWidget7;
                } else {
                    i5 = i9;
                    constraintWidgetContainer2 = constraintWidget7;
                }
                constraintWidgetContainer2.setOptimizationLevel(i5);
                i12 = this.mLayoutWidget.getWidth();
                i13 = this.mLayoutWidget.getHeight();
                constraintWidgetContainer = this.mLayoutWidget;
                z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
                z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
                measurer5 = this.mMeasurer;
                i3 = measurer5.paddingHeight;
                i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
                i13 = resolveSizeAndState(i13 + i3, i2, 0);
                i12 = Math.min(this.mMaxWidth, i12 & 16777215);
                i13 = Math.min(this.mMaxHeight, i13 & 16777215);
                if (z2) {
                    i12 |= 16777216;
                }
                if (z3) {
                    i13 |= 16777216;
                }
                setMeasuredDimension(i12, i13);
            }
        }
        if (enabled) {
        }
        i3 = i6 & i3;
        if (i3 == 0) {
            measurer3 = measurer2;
            i7 = i3;
            i13 = 0;
            i3 = 0;
        } else {
            size = Math.min(constraintWidget7.mMaxDimension[0], size);
            size2 = Math.min(constraintWidget7.mMaxDimension[1], size2);
            if (mode != 1073741824) {
            }
            constraintWidget7.setWidth(size);
            constraintWidget7.invalidateGraph();
            if (mode2 != 1073741824) {
            }
            constraintWidget7.setHeight(size2);
            constraintWidget7.invalidateGraph();
            if (mode == 1073741824) {
            }
            i7 = i3;
            dependencyGraph = constraintWidget7.mDependencyGraph;
            if (dependencyGraph.mNeedBuildGraph) {
                measurer3 = measurer2;
            } else {
                list = dependencyGraph.container.mChildren;
                i14 = list.size();
                max4 = 0;
                while (max4 < i14) {
                    constraintWidget2 = (ConstraintWidget) list.get(max4);
                    constraintWidget2.ensureWidgetRuns();
                    list2 = list;
                    constraintWidget2.measured = false;
                    i8 = i14;
                    widgetRun = constraintWidget2.horizontalRun;
                    measurer3 = measurer2;
                    widgetRun.dimension.resolved = false;
                    widgetRun.resolved = false;
                    widgetRun.reset();
                    widgetRun2 = constraintWidget2.verticalRun;
                    widgetRun2.dimension.resolved = false;
                    widgetRun2.resolved = false;
                    widgetRun2.reset();
                    max4++;
                    i14 = i8;
                    list = list2;
                    measurer2 = measurer3;
                }
                measurer3 = measurer2;
                dependencyGraph.container.ensureWidgetRuns();
                constraintWidget2 = dependencyGraph.container;
                constraintWidget2.measured = false;
                widgetRun2 = constraintWidget2.horizontalRun;
                widgetRun2.dimension.resolved = false;
                widgetRun2.resolved = false;
                widgetRun2.reset();
                widgetRun2 = dependencyGraph.container.verticalRun;
                widgetRun2.dimension.resolved = false;
                widgetRun2.resolved = false;
                widgetRun2.reset();
                dependencyGraph.buildGraph();
            }
            dependencyGraph.basicMeasureWidgets$ar$ds(dependencyGraph.mContainer);
            constraintWidget2 = dependencyGraph.container;
            constraintWidget2.f12mX = 0;
            constraintWidget2.f13mY = 0;
            constraintWidget2.horizontalRun.start.resolve(0);
            dependencyGraph.container.verticalRun.start.resolve(0);
            if (mode != 1073741824) {
                i13 = 0;
                i3 = 1;
            } else {
                i3 = constraintWidget7.directMeasureWithOrientation(enabled, 0);
                i13 = 1;
            }
            if (mode2 != 1073741824) {
                i9 = 1;
            } else {
                i9 = 1;
                i3 &= constraintWidget7.directMeasureWithOrientation(enabled, 1);
                i13++;
            }
            if (i3 != 0) {
                constraintWidget7.updateFromRuns(max3 ^ 1, size ^ i9);
            }
        }
        i9 = constraintWidget7.mOptimizationLevel;
        if (max5 > 0) {
            i13 = constraintWidget7.mChildren.size();
            optimizeFor = constraintWidget7.optimizeFor(64);
            measurer4 = constraintWidget7.mMeasurer$ar$class_merging;
            for (size = 0; size < i13; size++) {
                constraintWidget3 = (ConstraintWidget) constraintWidget7.mChildren.get(size);
                if (constraintWidget3 instanceof Guideline) {
                    if (!(constraintWidget3 instanceof Barrier)) {
                        z = constraintWidget3.mInVirtualLayout;
                        if (optimizeFor) {
                            widgetRun3 = constraintWidget3.horizontalRun;
                            if (widgetRun3 != null) {
                                widgetRun4 = constraintWidget3.verticalRun;
                                if (widgetRun4.dimension.resolved) {
                                }
                            }
                        }
                        max2 = constraintWidget3.getDimensionBehaviour$ar$edu(0);
                        i14 = constraintWidget3.getDimensionBehaviour$ar$edu(1);
                        if (max2 == 3) {
                            obj2 = null;
                        } else {
                            if (constraintWidget3.mMatchConstraintDefaultWidth != 1) {
                            }
                            obj2 = null;
                            max2 = 3;
                        }
                        if (obj2 == null) {
                            if (constraintWidget7.optimizeFor(1)) {
                                if (!(constraintWidget3 instanceof VirtualLayout)) {
                                    if (max2 == 3) {
                                    }
                                    obj2 = null;
                                    obj2 = 1;
                                    if (max2 != 3) {
                                        if (i14 == 3) {
                                            if (obj2 != null) {
                                            }
                                        }
                                    }
                                    if (constraintWidget3.mDimensionRatio > 0.0f) {
                                    }
                                    if (obj2 != null) {
                                    }
                                }
                            }
                            basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer4, constraintWidget3, 0);
                        }
                    }
                }
            }
            i13 = measurer4.layout.getChildCount();
            for (i3 = 0; i3 < i13; i3++) {
                childAt = measurer4.layout.getChildAt(i3);
                if (childAt instanceof Placeholder) {
                    placeholder = (Placeholder) childAt;
                    constraintLayout = measurer4.layout;
                    throw null;
                }
            }
            i13 = measurer4.layout.mConstraintHelpers.size();
            if (i13 > 0) {
                for (i3 = 0; i3 < i13; i3++) {
                    constraintHelper = (ConstraintHelper) measurer4.layout.mConstraintHelpers.get(i3);
                    constraintLayout2 = measurer4.layout;
                }
            }
        }
        basicMeasure.updateHierarchy(constraintWidget7);
        i13 = basicMeasure.mVariableDimensionsWidgets.size();
        if (max5 > 0) {
            basicMeasure.solveLinearSystem$ar$ds(constraintWidget7, 0, width, max);
        }
        if (i13 <= 0) {
            i5 = i9;
            constraintWidgetContainer2 = constraintWidget7;
        } else {
            max5 = constraintWidget7.getHorizontalDimensionBehaviour$ar$edu();
            i3 = constraintWidget7.getVerticalDimensionBehaviour$ar$edu();
            mode2 = Math.max(constraintWidget7.getWidth(), basicMeasure.constraintWidgetContainer.mMinWidth);
            size2 = Math.max(constraintWidget7.getHeight(), basicMeasure.constraintWidgetContainer.mMinHeight);
            mode = 0;
            size = 0;
            while (mode < i13) {
                constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                if (constraintWidget4 instanceof VirtualLayout) {
                    max3 = constraintWidget4.getWidth();
                    max4 = constraintWidget4.getHeight();
                    i5 = i9;
                    measurer = measurer3;
                    i9 = size | basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, 1);
                    size = constraintWidget4.getWidth();
                    i11 = i9;
                    i9 = constraintWidget4.getHeight();
                    if (size != max3) {
                        constraintWidget4.setWidth(size);
                        if (max5 != 2) {
                        }
                        i11 = 1;
                    }
                    if (i9 != max4) {
                        constraintWidget4.setHeight(i9);
                        if (i3 != 2) {
                        }
                        i11 = 1;
                    }
                    virtualLayout = (VirtualLayout) constraintWidget4;
                    size = i11;
                } else {
                    i5 = i9;
                    measurer = measurer3;
                }
                mode++;
                measurer3 = measurer;
                i9 = i5;
            }
            i5 = i9;
            measurer = measurer3;
            i9 = 0;
            while (i9 < 2) {
                mode = 0;
                while (mode < i13) {
                    constraintWidget4 = (ConstraintWidget) basicMeasure.mVariableDimensionsWidgets.get(mode);
                    if (constraintWidget4 instanceof HelperWidget) {
                        if (constraintWidget4 instanceof VirtualLayout) {
                            i11 = i13;
                            constraintWidget5 = constraintWidget7;
                            mode++;
                            i13 = i11;
                            constraintWidget7 = constraintWidget5;
                        }
                    }
                    if (constraintWidget4 instanceof Guideline) {
                        if (constraintWidget4.mVisibility == 8) {
                            if (i7 == 0) {
                            }
                            if (constraintWidget4 instanceof VirtualLayout) {
                                max3 = constraintWidget4.getWidth();
                                max4 = constraintWidget4.getHeight();
                                i11 = i13;
                                i13 = constraintWidget4.mBaselineDistance;
                                constraintWidget5 = constraintWidget7;
                                childCount = 1;
                                if (i9 == 1) {
                                    childCount = 2;
                                }
                                childCount = basicMeasure.measure$ar$class_merging$6b6fe65d_0(measurer, constraintWidget4, childCount) | size;
                                size = constraintWidget4.getWidth();
                                i10 = childCount;
                                childCount = constraintWidget4.getHeight();
                                if (size != max3) {
                                    constraintWidget4.setWidth(size);
                                    if (max5 != 2) {
                                    }
                                    i10 = 1;
                                }
                                if (childCount != max4) {
                                    constraintWidget4.setHeight(childCount);
                                    if (i3 != 2) {
                                    }
                                    i10 = 1;
                                }
                                if (constraintWidget4.hasBaseline) {
                                }
                                size = i10;
                                mode++;
                                i13 = i11;
                                constraintWidget7 = constraintWidget5;
                            }
                            i11 = i13;
                            constraintWidget5 = constraintWidget7;
                            mode++;
                            i13 = i11;
                            constraintWidget7 = constraintWidget5;
                        }
                    }
                    i11 = i13;
                    constraintWidget5 = constraintWidget7;
                    mode++;
                    i13 = i11;
                    constraintWidget7 = constraintWidget5;
                }
                i11 = i13;
                constraintWidget5 = constraintWidget7;
                if (size == 0) {
                    constraintWidgetContainer2 = constraintWidget5;
                } else {
                    i9++;
                    constraintWidget6 = constraintWidget5;
                    basicMeasure.solveLinearSystem$ar$ds(constraintWidget6, i9, width, max);
                    constraintWidget7 = constraintWidget6;
                    i13 = i11;
                    size = 0;
                }
            }
            constraintWidgetContainer2 = constraintWidget7;
        }
        constraintWidgetContainer2.setOptimizationLevel(i5);
        i12 = this.mLayoutWidget.getWidth();
        i13 = this.mLayoutWidget.getHeight();
        constraintWidgetContainer = this.mLayoutWidget;
        z2 = constraintWidgetContainer.mWidthMeasuredTooSmall;
        z3 = constraintWidgetContainer.mHeightMeasuredTooSmall;
        measurer5 = this.mMeasurer;
        i3 = measurer5.paddingHeight;
        i12 = resolveSizeAndState(i12 + measurer5.paddingWidth, i, 0);
        i13 = resolveSizeAndState(i13 + i3, i2, 0);
        i12 = Math.min(this.mMaxWidth, i12 & 16777215);
        i13 = Math.min(this.mMaxHeight, i13 & 16777215);
        if (z2) {
            i12 |= 16777216;
        }
        if (z3) {
            i13 |= 16777216;
        }
        setMeasuredDimension(i12, i13);
    }

    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        ConstraintWidget viewWidget = getViewWidget(view);
        if ((view instanceof Guideline) && !(viewWidget instanceof Guideline)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            layoutParams.widget = new Guideline();
            layoutParams.isGuideline = true;
            ((Guideline) layoutParams.widget).setOrientation(layoutParams.orientation);
        }
        if (view instanceof ConstraintHelper) {
            ConstraintHelper constraintHelper = (ConstraintHelper) view;
            constraintHelper.validateParams();
            ((LayoutParams) view.getLayoutParams()).isHelper = true;
            if (!this.mConstraintHelpers.contains(constraintHelper)) {
                this.mConstraintHelpers.add(constraintHelper);
            }
        }
        this.mChildrenByIds.put(view.getId(), view);
        this.mDirtyHierarchy = true;
    }

    public final void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.mChildrenByIds.remove(view.getId());
        this.mLayoutWidget.remove(getViewWidget(view));
        this.mConstraintHelpers.remove(view);
        this.mDirtyHierarchy = true;
    }

    public final void requestLayout() {
        markHierarchyDirty();
        super.requestLayout();
    }

    public final void setId(int i) {
        this.mChildrenByIds.remove(getId());
        super.setId(i);
        this.mChildrenByIds.put(getId(), this);
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    protected final android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(attributeSet, 0, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(attributeSet, i, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        init(attributeSet, i, i2);
    }
}
