package androidx.constraintlayout.widget;

import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;

/* compiled from: PG */
public final class Constraints extends ViewGroup {
    protected final /* bridge */ /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        throw null;
    }

    protected final LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        throw null;
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        throw null;
    }
}
