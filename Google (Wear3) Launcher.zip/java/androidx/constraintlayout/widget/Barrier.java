package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.core.widgets.ConstraintWidget;

/* compiled from: PG */
public class Barrier extends ConstraintHelper {
    public androidx.constraintlayout.core.widgets.Barrier mBarrier;
    public int mIndicatedType;

    public Barrier(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public final void setMargin(int i) {
        this.mBarrier.mMargin = i;
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }

    protected final void init(AttributeSet attributeSet) {
        int indexCount;
        int i;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            indexCount = obtainStyledAttributes.getIndexCount();
            for (i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == 35) {
                    this.mReferenceIds = obtainStyledAttributes.getString(35);
                    setIds(this.mReferenceIds);
                } else if (index == 36) {
                    this.mReferenceTags = obtainStyledAttributes.getString(36);
                    setReferenceTags(this.mReferenceTags);
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.mBarrier = new androidx.constraintlayout.core.widgets.Barrier();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount2 = obtainStyledAttributes2.getIndexCount();
            for (indexCount = 0; indexCount < indexCount2; indexCount++) {
                i = obtainStyledAttributes2.getIndex(indexCount);
                if (i == 26) {
                    this.mIndicatedType = obtainStyledAttributes2.getInt(26, 0);
                } else if (i == 25) {
                    this.mBarrier.mAllowsGoneWidget = obtainStyledAttributes2.getBoolean(25, true);
                } else if (i == 27) {
                    this.mBarrier.mMargin = obtainStyledAttributes2.getDimensionPixelSize(27, 0);
                }
            }
            obtainStyledAttributes2.recycle();
        }
        this.mHelperWidget$ar$class_merging = this.mBarrier;
        validateParams();
    }

    public final void resolveRtl(ConstraintWidget constraintWidget, boolean z) {
        int i = this.mIndicatedType;
        if (z) {
            if (i == 5) {
                i = 1;
            } else if (i == 6) {
            }
            if (!(constraintWidget instanceof androidx.constraintlayout.core.widgets.Barrier)) {
                ((androidx.constraintlayout.core.widgets.Barrier) constraintWidget).mBarrierType = i;
            }
        } else if (i != 5) {
            if (i == 6) {
                i = 1;
            }
            if (!(constraintWidget instanceof androidx.constraintlayout.core.widgets.Barrier)) {
                ((androidx.constraintlayout.core.widgets.Barrier) constraintWidget).mBarrierType = i;
            }
        }
        i = 0;
        if (!(constraintWidget instanceof androidx.constraintlayout.core.widgets.Barrier)) {
            ((androidx.constraintlayout.core.widgets.Barrier) constraintWidget).mBarrierType = i;
        }
    }

    public Barrier(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        super.setVisibility(8);
    }
}
