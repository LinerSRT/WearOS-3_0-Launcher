package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.p002v7.widget.LinearLayoutManager;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.core.motion.utils.Easing;
import androidx.constraintlayout.widget.ConstraintLayout.LayoutParams;
import com.google.android.clockwork.wcs.sdk.PG;
import com.google.android.libraries.wear.wcs.contract.deeplink.DeepLinkServiceResult;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* compiled from: PG */
public final class ConstraintSet {
    public static final int[] VISIBILITY_FLAGS = new int[]{0, 4, 8};
    private static final SparseIntArray mapToConstant;
    private static final SparseIntArray overrideMapToConstant;
    private final HashMap mConstraints = new HashMap();
    private final HashMap mSavedAttributes = new HashMap();

    /* compiled from: PG */
    public final class Constraint {
        public final Layout layout = new Layout();
        public HashMap mCustomConstraints = new HashMap();
        Delta mDelta;
        int mViewId;
        public final Motion motion = new Motion();
        public final PropertySet propertySet = new PropertySet();
        public final Transform transform = new Transform();

        /* compiled from: PG */
        final class Delta {
            int mCountBoolean = 0;
            int mCountFloat = 0;
            int mCountInt = 0;
            int mCountString = 0;
            int[] mTypeBoolean = new int[4];
            int[] mTypeFloat = new int[10];
            int[] mTypeInt = new int[10];
            int[] mTypeString = new int[5];
            boolean[] mValueBoolean = new boolean[4];
            float[] mValueFloat = new float[10];
            int[] mValueInt = new int[10];
            String[] mValueString = new String[5];

            final void add(int i, float f) {
                int length;
                int i2 = this.mCountFloat;
                int[] iArr = this.mTypeFloat;
                int length2 = iArr.length;
                if (i2 >= length2) {
                    this.mTypeFloat = Arrays.copyOf(iArr, length2 + length2);
                    float[] fArr = this.mValueFloat;
                    length = fArr.length;
                    this.mValueFloat = Arrays.copyOf(fArr, length + length);
                }
                int[] iArr2 = this.mTypeFloat;
                length = this.mCountFloat;
                iArr2[length] = i;
                float[] fArr2 = this.mValueFloat;
                this.mCountFloat = length + 1;
                fArr2[length] = f;
            }

            final void add(int i, int i2) {
                int[] iArr;
                int length;
                int i3 = this.mCountInt;
                int[] iArr2 = this.mTypeInt;
                int length2 = iArr2.length;
                if (i3 >= length2) {
                    this.mTypeInt = Arrays.copyOf(iArr2, length2 + length2);
                    iArr = this.mValueInt;
                    length = iArr.length;
                    this.mValueInt = Arrays.copyOf(iArr, length + length);
                }
                iArr = this.mTypeInt;
                length = this.mCountInt;
                iArr[length] = i;
                int[] iArr3 = this.mValueInt;
                this.mCountInt = length + 1;
                iArr3[length] = i2;
            }

            final void add(int i, String str) {
                int length;
                int i2 = this.mCountString;
                int[] iArr = this.mTypeString;
                int length2 = iArr.length;
                if (i2 >= length2) {
                    this.mTypeString = Arrays.copyOf(iArr, length2 + length2);
                    String[] strArr = this.mValueString;
                    length = strArr.length;
                    this.mValueString = (String[]) Arrays.copyOf(strArr, length + length);
                }
                int[] iArr2 = this.mTypeString;
                length = this.mCountString;
                iArr2[length] = i;
                String[] strArr2 = this.mValueString;
                this.mCountString = length + 1;
                strArr2[length] = str;
            }

            final void add(int i, boolean z) {
                int length;
                int i2 = this.mCountBoolean;
                int[] iArr = this.mTypeBoolean;
                int length2 = iArr.length;
                if (i2 >= length2) {
                    this.mTypeBoolean = Arrays.copyOf(iArr, length2 + length2);
                    boolean[] zArr = this.mValueBoolean;
                    length = zArr.length;
                    this.mValueBoolean = Arrays.copyOf(zArr, length + length);
                }
                int[] iArr2 = this.mTypeBoolean;
                length = this.mCountBoolean;
                iArr2[length] = i;
                boolean[] zArr2 = this.mValueBoolean;
                this.mCountBoolean = length + 1;
                zArr2[length] = z;
            }
        }

        public final void applyTo(LayoutParams layoutParams) {
            Layout layout = this.layout;
            layoutParams.leftToLeft = layout.leftToLeft;
            layoutParams.leftToRight = layout.leftToRight;
            layoutParams.rightToLeft = layout.rightToLeft;
            layoutParams.rightToRight = layout.rightToRight;
            layoutParams.topToTop = layout.topToTop;
            layoutParams.topToBottom = layout.topToBottom;
            layoutParams.bottomToTop = layout.bottomToTop;
            layoutParams.bottomToBottom = layout.bottomToBottom;
            layoutParams.baselineToBaseline = layout.baselineToBaseline;
            layoutParams.baselineToTop = layout.baselineToTop;
            layoutParams.baselineToBottom = layout.baselineToBottom;
            layoutParams.startToEnd = layout.startToEnd;
            layoutParams.startToStart = layout.startToStart;
            layoutParams.endToStart = layout.endToStart;
            layoutParams.endToEnd = layout.endToEnd;
            layoutParams.leftMargin = layout.leftMargin;
            layoutParams.rightMargin = this.layout.rightMargin;
            layoutParams.topMargin = this.layout.topMargin;
            layoutParams.bottomMargin = this.layout.bottomMargin;
            layout = this.layout;
            layoutParams.goneStartMargin = layout.goneStartMargin;
            layoutParams.goneEndMargin = layout.goneEndMargin;
            layoutParams.goneTopMargin = layout.goneTopMargin;
            layoutParams.goneBottomMargin = layout.goneBottomMargin;
            layoutParams.horizontalBias = layout.horizontalBias;
            layoutParams.verticalBias = layout.verticalBias;
            layoutParams.circleConstraint = layout.circleConstraint;
            layoutParams.circleRadius = layout.circleRadius;
            layoutParams.circleAngle = layout.circleAngle;
            layoutParams.dimensionRatio = layout.dimensionRatio;
            layoutParams.editorAbsoluteX = layout.editorAbsoluteX;
            layoutParams.editorAbsoluteY = layout.editorAbsoluteY;
            layoutParams.verticalWeight = layout.verticalWeight;
            layoutParams.horizontalWeight = layout.horizontalWeight;
            layoutParams.verticalChainStyle = layout.verticalChainStyle;
            layoutParams.horizontalChainStyle = layout.horizontalChainStyle;
            layoutParams.constrainedWidth = layout.constrainedWidth;
            layoutParams.constrainedHeight = layout.constrainedHeight;
            layoutParams.matchConstraintDefaultWidth = layout.widthDefault;
            layoutParams.matchConstraintDefaultHeight = layout.heightDefault;
            layoutParams.matchConstraintMaxWidth = layout.widthMax;
            layoutParams.matchConstraintMaxHeight = layout.heightMax;
            layoutParams.matchConstraintMinWidth = layout.widthMin;
            layoutParams.matchConstraintMinHeight = layout.heightMin;
            layoutParams.matchConstraintPercentWidth = layout.widthPercent;
            layoutParams.matchConstraintPercentHeight = layout.heightPercent;
            layoutParams.orientation = layout.orientation;
            layoutParams.guidePercent = layout.guidePercent;
            layoutParams.guideBegin = layout.guideBegin;
            layoutParams.guideEnd = layout.guideEnd;
            layoutParams.width = layout.mWidth;
            layoutParams.height = this.layout.mHeight;
            layout = this.layout;
            String str = layout.mConstraintTag;
            if (str != null) {
                layoutParams.constraintTag = str;
            }
            layoutParams.wrapBehaviorInParent = layout.mWrapBehavior;
            layoutParams.setMarginStart(layout.startMargin);
            layoutParams.setMarginEnd(this.layout.endMargin);
            layoutParams.validate();
        }

        public final /* bridge */ /* synthetic */ Object clone() {
            Constraint constraint = new Constraint();
            Layout layout = constraint.layout;
            Layout layout2 = this.layout;
            layout.mIsGuideline = layout2.mIsGuideline;
            layout.mWidth = layout2.mWidth;
            layout.mApply = layout2.mApply;
            layout.mHeight = layout2.mHeight;
            layout.guideBegin = layout2.guideBegin;
            layout.guideEnd = layout2.guideEnd;
            layout.guidePercent = layout2.guidePercent;
            layout.leftToLeft = layout2.leftToLeft;
            layout.leftToRight = layout2.leftToRight;
            layout.rightToLeft = layout2.rightToLeft;
            layout.rightToRight = layout2.rightToRight;
            layout.topToTop = layout2.topToTop;
            layout.topToBottom = layout2.topToBottom;
            layout.bottomToTop = layout2.bottomToTop;
            layout.bottomToBottom = layout2.bottomToBottom;
            layout.baselineToBaseline = layout2.baselineToBaseline;
            layout.baselineToTop = layout2.baselineToTop;
            layout.baselineToBottom = layout2.baselineToBottom;
            layout.startToEnd = layout2.startToEnd;
            layout.startToStart = layout2.startToStart;
            layout.endToStart = layout2.endToStart;
            layout.endToEnd = layout2.endToEnd;
            layout.horizontalBias = layout2.horizontalBias;
            layout.verticalBias = layout2.verticalBias;
            layout.dimensionRatio = layout2.dimensionRatio;
            layout.circleConstraint = layout2.circleConstraint;
            layout.circleRadius = layout2.circleRadius;
            layout.circleAngle = layout2.circleAngle;
            layout.editorAbsoluteX = layout2.editorAbsoluteX;
            layout.editorAbsoluteY = layout2.editorAbsoluteY;
            layout.orientation = layout2.orientation;
            layout.leftMargin = layout2.leftMargin;
            layout.rightMargin = layout2.rightMargin;
            layout.topMargin = layout2.topMargin;
            layout.bottomMargin = layout2.bottomMargin;
            layout.endMargin = layout2.endMargin;
            layout.startMargin = layout2.startMargin;
            layout.baselineMargin = layout2.baselineMargin;
            layout.goneLeftMargin = layout2.goneLeftMargin;
            layout.goneTopMargin = layout2.goneTopMargin;
            layout.goneRightMargin = layout2.goneRightMargin;
            layout.goneBottomMargin = layout2.goneBottomMargin;
            layout.goneEndMargin = layout2.goneEndMargin;
            layout.goneStartMargin = layout2.goneStartMargin;
            layout.goneBaselineMargin = layout2.goneBaselineMargin;
            layout.verticalWeight = layout2.verticalWeight;
            layout.horizontalWeight = layout2.horizontalWeight;
            layout.horizontalChainStyle = layout2.horizontalChainStyle;
            layout.verticalChainStyle = layout2.verticalChainStyle;
            layout.widthDefault = layout2.widthDefault;
            layout.heightDefault = layout2.heightDefault;
            layout.widthMax = layout2.widthMax;
            layout.heightMax = layout2.heightMax;
            layout.widthMin = layout2.widthMin;
            layout.heightMin = layout2.heightMin;
            layout.widthPercent = layout2.widthPercent;
            layout.heightPercent = layout2.heightPercent;
            layout.mBarrierDirection = layout2.mBarrierDirection;
            layout.mBarrierMargin = layout2.mBarrierMargin;
            layout.mHelperType = layout2.mHelperType;
            layout.mConstraintTag = layout2.mConstraintTag;
            int[] iArr = layout2.mReferenceIds;
            if (iArr != null) {
                layout.mReferenceIds = Arrays.copyOf(iArr, iArr.length);
            } else {
                layout.mReferenceIds = null;
            }
            layout.mReferenceIdString = layout2.mReferenceIdString;
            layout.constrainedWidth = layout2.constrainedWidth;
            layout.constrainedHeight = layout2.constrainedHeight;
            layout.mBarrierAllowsGoneWidgets = layout2.mBarrierAllowsGoneWidgets;
            layout.mWrapBehavior = layout2.mWrapBehavior;
            Motion motion = constraint.motion;
            Motion motion2 = this.motion;
            motion.mApply = motion2.mApply;
            motion.mAnimateRelativeTo = motion2.mAnimateRelativeTo;
            motion.mTransitionEasing = motion2.mTransitionEasing;
            motion.mPathMotionArc = motion2.mPathMotionArc;
            motion.mDrawPath = motion2.mDrawPath;
            motion.mPathRotate = motion2.mPathRotate;
            motion.mMotionStagger = motion2.mMotionStagger;
            motion.mPolarRelativeTo = motion2.mPolarRelativeTo;
            PropertySet propertySet = constraint.propertySet;
            PropertySet propertySet2 = this.propertySet;
            propertySet.mApply = propertySet2.mApply;
            propertySet.visibility = propertySet2.visibility;
            propertySet.alpha = propertySet2.alpha;
            propertySet.mProgress = propertySet2.mProgress;
            propertySet.mVisibilityMode = propertySet2.mVisibilityMode;
            Transform transform = constraint.transform;
            Transform transform2 = this.transform;
            transform.mApply = transform2.mApply;
            transform.rotation = transform2.rotation;
            transform.rotationX = transform2.rotationX;
            transform.rotationY = transform2.rotationY;
            transform.scaleX = transform2.scaleX;
            transform.scaleY = transform2.scaleY;
            transform.transformPivotX = transform2.transformPivotX;
            transform.transformPivotY = transform2.transformPivotY;
            transform.transformPivotTarget = transform2.transformPivotTarget;
            transform.translationX = transform2.translationX;
            transform.translationY = transform2.translationY;
            transform.translationZ = transform2.translationZ;
            transform.applyElevation = transform2.applyElevation;
            transform.elevation = transform2.elevation;
            constraint.mViewId = this.mViewId;
            constraint.mDelta = this.mDelta;
            return constraint;
        }
    }

    /* compiled from: PG */
    public final class Layout {
        public static final SparseIntArray mapToConstant;
        public int baselineMargin = 0;
        public int baselineToBaseline = -1;
        public int baselineToBottom = -1;
        public int baselineToTop = -1;
        public int bottomMargin = 0;
        public int bottomToBottom = -1;
        public int bottomToTop = -1;
        public float circleAngle = 0.0f;
        public int circleConstraint = -1;
        public int circleRadius = 0;
        public boolean constrainedHeight = false;
        public boolean constrainedWidth = false;
        public String dimensionRatio = null;
        public int editorAbsoluteX = -1;
        public int editorAbsoluteY = -1;
        public int endMargin = 0;
        public int endToEnd = -1;
        public int endToStart = -1;
        public int goneBaselineMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneBottomMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneEndMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneLeftMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneRightMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneStartMargin = LinearLayoutManager.INVALID_OFFSET;
        public int goneTopMargin = LinearLayoutManager.INVALID_OFFSET;
        public int guideBegin = -1;
        public int guideEnd = -1;
        public float guidePercent = -1.0f;
        public int heightDefault = 0;
        public int heightMax = -1;
        public int heightMin = -1;
        public float heightPercent = 1.0f;
        public float horizontalBias = 0.5f;
        public int horizontalChainStyle = 0;
        public float horizontalWeight = -1.0f;
        public int leftMargin = 0;
        public int leftToLeft = -1;
        public int leftToRight = -1;
        public boolean mApply = false;
        public boolean mBarrierAllowsGoneWidgets = true;
        public int mBarrierDirection = -1;
        public int mBarrierMargin = 0;
        public String mConstraintTag;
        public int mHeight;
        public int mHelperType = -1;
        public boolean mIsGuideline = false;
        public String mReferenceIdString;
        public int[] mReferenceIds;
        public int mWidth;
        public int mWrapBehavior = 0;
        public int orientation = -1;
        public int rightMargin = 0;
        public int rightToLeft = -1;
        public int rightToRight = -1;
        public int startMargin = 0;
        public int startToEnd = -1;
        public int startToStart = -1;
        public int topMargin = 0;
        public int topToBottom = -1;
        public int topToTop = -1;
        public float verticalBias = 0.5f;
        public int verticalChainStyle = 0;
        public float verticalWeight = -1.0f;
        public int widthDefault = 0;
        public int widthMax = -1;
        public int widthMin = -1;
        public float widthPercent = 1.0f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            mapToConstant = sparseIntArray;
            int[] iArr = R$styleable.Constraint;
            sparseIntArray.append(42, 24);
            sparseIntArray.append(43, 25);
            sparseIntArray.append(45, 28);
            sparseIntArray.append(46, 29);
            sparseIntArray.append(51, 35);
            sparseIntArray.append(50, 34);
            sparseIntArray.append(23, 4);
            sparseIntArray.append(22, 3);
            sparseIntArray.append(18, 1);
            sparseIntArray.append(60, 6);
            sparseIntArray.append(61, 7);
            sparseIntArray.append(30, 17);
            sparseIntArray.append(31, 18);
            sparseIntArray.append(32, 19);
            sparseIntArray.append(0, 26);
            sparseIntArray.append(47, 31);
            sparseIntArray.append(48, 32);
            sparseIntArray.append(29, 10);
            sparseIntArray.append(28, 9);
            sparseIntArray.append(65, 13);
            sparseIntArray.append(68, 16);
            sparseIntArray.append(66, 14);
            sparseIntArray.append(63, 11);
            sparseIntArray.append(67, 15);
            sparseIntArray.append(64, 12);
            sparseIntArray.append(54, 38);
            sparseIntArray.append(40, 37);
            sparseIntArray.append(39, 39);
            sparseIntArray.append(53, 40);
            sparseIntArray.append(38, 20);
            sparseIntArray.append(52, 36);
            sparseIntArray.append(27, 5);
            sparseIntArray.append(41, 76);
            sparseIntArray.append(49, 76);
            sparseIntArray.append(44, 76);
            sparseIntArray.append(21, 76);
            sparseIntArray.append(17, 76);
            sparseIntArray.append(3, 23);
            sparseIntArray.append(5, 27);
            sparseIntArray.append(7, 30);
            sparseIntArray.append(8, 8);
            sparseIntArray.append(4, 33);
            sparseIntArray.append(6, 2);
            sparseIntArray.append(1, 22);
            sparseIntArray.append(2, 21);
            sparseIntArray.append(55, 41);
            sparseIntArray.append(33, 42);
            sparseIntArray.append(16, 41);
            sparseIntArray.append(15, 42);
            sparseIntArray.append(70, 97);
            sparseIntArray.append(24, 61);
            sparseIntArray.append(26, 62);
            sparseIntArray.append(25, 63);
            sparseIntArray.append(59, 69);
            sparseIntArray.append(37, 70);
            sparseIntArray.append(12, 71);
            sparseIntArray.append(10, 72);
            sparseIntArray.append(11, 73);
            sparseIntArray.append(13, 74);
            sparseIntArray.append(9, 75);
        }
    }

    /* compiled from: PG */
    public final class Motion {
        public static final SparseIntArray mapToConstant;
        public int mAnimateCircleAngleTo = 0;
        public int mAnimateRelativeTo = -1;
        public boolean mApply = false;
        public int mDrawPath = 0;
        public float mMotionStagger = Float.NaN;
        public int mPathMotionArc = -1;
        public float mPathRotate = Float.NaN;
        public int mPolarRelativeTo = -1;
        public int mQuantizeInterpolatorID = -1;
        public String mQuantizeInterpolatorString = null;
        public int mQuantizeInterpolatorType = -3;
        public float mQuantizeMotionPhase = Float.NaN;
        public int mQuantizeMotionSteps = -1;
        public String mTransitionEasing = null;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            mapToConstant = sparseIntArray;
            int[] iArr = R$styleable.Constraint;
            sparseIntArray.append(3, 1);
            sparseIntArray.append(5, 2);
            sparseIntArray.append(9, 3);
            sparseIntArray.append(2, 4);
            sparseIntArray.append(1, 5);
            sparseIntArray.append(0, 6);
            sparseIntArray.append(4, 7);
            sparseIntArray.append(8, 8);
            sparseIntArray.append(7, 9);
            sparseIntArray.append(6, 10);
        }
    }

    /* compiled from: PG */
    public final class PropertySet {
        public float alpha = 1.0f;
        public boolean mApply = false;
        public float mProgress = Float.NaN;
        public int mVisibilityMode = 0;
        public int visibility = 0;
    }

    /* compiled from: PG */
    public final class Transform {
        public static final SparseIntArray mapToConstant;
        public boolean applyElevation = false;
        public float elevation = 0.0f;
        public boolean mApply = false;
        public float rotation = 0.0f;
        public float rotationX = 0.0f;
        public float rotationY = 0.0f;
        public float scaleX = 1.0f;
        public float scaleY = 1.0f;
        public int transformPivotTarget = -1;
        public float transformPivotX = Float.NaN;
        public float transformPivotY = Float.NaN;
        public float translationX = 0.0f;
        public float translationY = 0.0f;
        public float translationZ = 0.0f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            mapToConstant = sparseIntArray;
            int[] iArr = R$styleable.Constraint;
            sparseIntArray.append(6, 1);
            sparseIntArray.append(7, 2);
            sparseIntArray.append(8, 3);
            sparseIntArray.append(4, 4);
            sparseIntArray.append(5, 5);
            sparseIntArray.append(0, 6);
            sparseIntArray.append(1, 7);
            sparseIntArray.append(2, 8);
            sparseIntArray.append(3, 9);
            sparseIntArray.append(9, 10);
            sparseIntArray.append(10, 11);
            sparseIntArray.append(11, 12);
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        mapToConstant = sparseIntArray;
        SparseIntArray sparseIntArray2 = new SparseIntArray();
        overrideMapToConstant = sparseIntArray2;
        int[] iArr = R$styleable.Constraint;
        sparseIntArray.append(81, 25);
        sparseIntArray.append(82, 26);
        sparseIntArray.append(84, 29);
        sparseIntArray.append(85, 30);
        sparseIntArray.append(91, 36);
        sparseIntArray.append(90, 35);
        sparseIntArray.append(62, 4);
        sparseIntArray.append(61, 3);
        sparseIntArray.append(57, 1);
        sparseIntArray.append(59, 91);
        sparseIntArray.append(58, 92);
        sparseIntArray.append(100, 6);
        sparseIntArray.append(101, 7);
        sparseIntArray.append(69, 17);
        sparseIntArray.append(70, 18);
        sparseIntArray.append(71, 19);
        sparseIntArray.append(0, 27);
        sparseIntArray.append(86, 32);
        sparseIntArray.append(87, 33);
        sparseIntArray.append(68, 10);
        sparseIntArray.append(67, 9);
        sparseIntArray.append(105, 13);
        sparseIntArray.append(108, 16);
        sparseIntArray.append(106, 14);
        sparseIntArray.append(103, 11);
        sparseIntArray.append(107, 15);
        sparseIntArray.append(104, 12);
        sparseIntArray.append(94, 40);
        sparseIntArray.append(79, 39);
        sparseIntArray.append(78, 41);
        sparseIntArray.append(93, 42);
        sparseIntArray.append(77, 20);
        sparseIntArray.append(92, 37);
        sparseIntArray.append(66, 5);
        sparseIntArray.append(80, 87);
        sparseIntArray.append(89, 87);
        sparseIntArray.append(83, 87);
        sparseIntArray.append(60, 87);
        sparseIntArray.append(56, 87);
        sparseIntArray.append(5, 24);
        sparseIntArray.append(7, 28);
        sparseIntArray.append(23, 31);
        sparseIntArray.append(24, 8);
        sparseIntArray.append(6, 34);
        sparseIntArray.append(8, 2);
        sparseIntArray.append(3, 23);
        sparseIntArray.append(4, 21);
        sparseIntArray.append(95, 95);
        sparseIntArray.append(72, 96);
        sparseIntArray.append(2, 22);
        sparseIntArray.append(13, 43);
        sparseIntArray.append(26, 44);
        sparseIntArray.append(21, 45);
        sparseIntArray.append(22, 46);
        sparseIntArray.append(20, 60);
        sparseIntArray.append(18, 47);
        sparseIntArray.append(19, 48);
        sparseIntArray.append(14, 49);
        sparseIntArray.append(15, 50);
        sparseIntArray.append(16, 51);
        sparseIntArray.append(17, 52);
        sparseIntArray.append(25, 53);
        sparseIntArray.append(96, 54);
        sparseIntArray.append(73, 55);
        sparseIntArray.append(97, 56);
        sparseIntArray.append(74, 57);
        sparseIntArray.append(98, 58);
        sparseIntArray.append(75, 59);
        sparseIntArray.append(63, 61);
        sparseIntArray.append(65, 62);
        sparseIntArray.append(64, 63);
        sparseIntArray.append(28, 64);
        sparseIntArray.append(120, 65);
        sparseIntArray.append(35, 66);
        sparseIntArray.append(121, 67);
        sparseIntArray.append(112, 79);
        sparseIntArray.append(1, 38);
        sparseIntArray.append(111, 68);
        sparseIntArray.append(99, 69);
        sparseIntArray.append(76, 70);
        sparseIntArray.append(110, 97);
        sparseIntArray.append(32, 71);
        sparseIntArray.append(30, 72);
        sparseIntArray.append(31, 73);
        sparseIntArray.append(33, 74);
        sparseIntArray.append(29, 75);
        sparseIntArray.append(113, 76);
        sparseIntArray.append(88, 77);
        sparseIntArray.append(122, 78);
        sparseIntArray.append(55, 80);
        sparseIntArray.append(54, 81);
        sparseIntArray.append(115, 82);
        sparseIntArray.append(119, 83);
        sparseIntArray.append(118, 84);
        sparseIntArray.append(117, 85);
        sparseIntArray.append(116, 86);
        sparseIntArray2.append(84, 6);
        sparseIntArray2.append(84, 7);
        sparseIntArray2.append(0, 27);
        sparseIntArray2.append(88, 13);
        sparseIntArray2.append(91, 16);
        sparseIntArray2.append(89, 14);
        sparseIntArray2.append(86, 11);
        sparseIntArray2.append(90, 15);
        sparseIntArray2.append(87, 12);
        sparseIntArray2.append(77, 40);
        sparseIntArray2.append(70, 39);
        sparseIntArray2.append(69, 41);
        sparseIntArray2.append(76, 42);
        sparseIntArray2.append(68, 20);
        sparseIntArray2.append(75, 37);
        sparseIntArray2.append(59, 5);
        sparseIntArray2.append(71, 87);
        sparseIntArray2.append(74, 87);
        sparseIntArray2.append(72, 87);
        sparseIntArray2.append(56, 87);
        sparseIntArray2.append(55, 87);
        sparseIntArray2.append(5, 24);
        sparseIntArray2.append(7, 28);
        sparseIntArray2.append(23, 31);
        sparseIntArray2.append(24, 8);
        sparseIntArray2.append(6, 34);
        sparseIntArray2.append(8, 2);
        sparseIntArray2.append(3, 23);
        sparseIntArray2.append(4, 21);
        sparseIntArray2.append(78, 95);
        sparseIntArray2.append(63, 96);
        sparseIntArray2.append(2, 22);
        sparseIntArray2.append(13, 43);
        sparseIntArray2.append(26, 44);
        sparseIntArray2.append(21, 45);
        sparseIntArray2.append(22, 46);
        sparseIntArray2.append(20, 60);
        sparseIntArray2.append(18, 47);
        sparseIntArray2.append(19, 48);
        sparseIntArray2.append(14, 49);
        sparseIntArray2.append(15, 50);
        sparseIntArray2.append(16, 51);
        sparseIntArray2.append(17, 52);
        sparseIntArray2.append(25, 53);
        sparseIntArray2.append(79, 54);
        sparseIntArray2.append(64, 55);
        sparseIntArray2.append(80, 56);
        sparseIntArray2.append(65, 57);
        sparseIntArray2.append(81, 58);
        sparseIntArray2.append(66, 59);
        sparseIntArray2.append(58, 62);
        sparseIntArray2.append(57, 63);
        sparseIntArray2.append(28, 64);
        sparseIntArray2.append(104, 65);
        sparseIntArray2.append(34, 66);
        sparseIntArray2.append(105, 67);
        sparseIntArray2.append(95, 79);
        sparseIntArray2.append(1, 38);
        sparseIntArray2.append(96, 98);
        sparseIntArray2.append(94, 68);
        sparseIntArray2.append(82, 69);
        sparseIntArray2.append(67, 70);
        sparseIntArray2.append(32, 71);
        sparseIntArray2.append(30, 72);
        sparseIntArray2.append(31, 73);
        sparseIntArray2.append(33, 74);
        sparseIntArray2.append(29, 75);
        sparseIntArray2.append(97, 76);
        sparseIntArray2.append(73, 77);
        sparseIntArray2.append(106, 78);
        sparseIntArray2.append(54, 80);
        sparseIntArray2.append(53, 81);
        sparseIntArray2.append(99, 82);
        sparseIntArray2.append(103, 83);
        sparseIntArray2.append(102, 84);
        sparseIntArray2.append(101, 85);
        sparseIntArray2.append(100, 86);
        sparseIntArray2.append(93, 97);
    }

    private static final int[] convertReferenceString$ar$ds(View view, String str) {
        int length;
        String[] split = str.split(",");
        Context context = view.getContext();
        int[] iArr = new int[split.length];
        int i = 0;
        int i2 = 0;
        while (true) {
            length = split.length;
            if (i >= length) {
                break;
            }
            int i3;
            String trim = split[i].trim();
            try {
                i3 = R$id.class.getField(trim).getInt(null);
            } catch (Exception e) {
                i3 = 0;
            }
            if (i3 == 0) {
                i3 = context.getResources().getIdentifier(trim, "id", context.getPackageName());
            }
            if (i3 == 0) {
                if (view.isInEditMode() && (view.getParent() instanceof ConstraintLayout)) {
                    Object designInformation$ar$ds = ((ConstraintLayout) view.getParent()).getDesignInformation$ar$ds(trim);
                    if (designInformation$ar$ds != null && (designInformation$ar$ds instanceof Integer)) {
                        i3 = ((Integer) designInformation$ar$ds).intValue();
                    }
                }
                i3 = 0;
            }
            length = i2 + 1;
            iArr[i2] = i3;
            i++;
            i2 = length;
        }
        return i2 != length ? Arrays.copyOf(iArr, i2) : iArr;
    }

    private static final Constraint fillFromAttributeList$ar$ds(Context context, AttributeSet attributeSet, boolean z) {
        Constraint constraint = new Constraint();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z ? R$styleable.ConstraintOverride : R$styleable.Constraint);
        if (z) {
            populateOverride$ar$ds(constraint, obtainStyledAttributes);
        } else {
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (!(index == 1 || index == 23 || index == 24)) {
                    constraint.motion.mApply = true;
                    constraint.layout.mApply = true;
                    constraint.propertySet.mApply = true;
                    constraint.transform.mApply = true;
                }
                SparseIntArray sparseIntArray = mapToConstant;
                String str = "   ";
                String str2 = "ConstraintSet";
                Layout layout;
                PropertySet propertySet;
                Transform transform;
                Motion motion;
                StringBuilder stringBuilder;
                switch (sparseIntArray.get(index)) {
                    case 1:
                        layout = constraint.layout;
                        layout.baselineToBaseline = lookupID(obtainStyledAttributes, index, layout.baselineToBaseline);
                        break;
                    case 2:
                        layout = constraint.layout;
                        layout.bottomMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.bottomMargin);
                        break;
                    case 3:
                        layout = constraint.layout;
                        layout.bottomToBottom = lookupID(obtainStyledAttributes, index, layout.bottomToBottom);
                        break;
                    case 4:
                        layout = constraint.layout;
                        layout.bottomToTop = lookupID(obtainStyledAttributes, index, layout.bottomToTop);
                        break;
                    case 5:
                        constraint.layout.dimensionRatio = obtainStyledAttributes.getString(index);
                        break;
                    case 6:
                        layout = constraint.layout;
                        layout.editorAbsoluteX = obtainStyledAttributes.getDimensionPixelOffset(index, layout.editorAbsoluteX);
                        break;
                    case 7:
                        layout = constraint.layout;
                        layout.editorAbsoluteY = obtainStyledAttributes.getDimensionPixelOffset(index, layout.editorAbsoluteY);
                        break;
                    case 8:
                        layout = constraint.layout;
                        layout.endMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.endMargin);
                        break;
                    case 9:
                        layout = constraint.layout;
                        layout.endToEnd = lookupID(obtainStyledAttributes, index, layout.endToEnd);
                        break;
                    case 10:
                        layout = constraint.layout;
                        layout.endToStart = lookupID(obtainStyledAttributes, index, layout.endToStart);
                        break;
                    case 11:
                        layout = constraint.layout;
                        layout.goneBottomMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.goneBottomMargin);
                        break;
                    case 12:
                        layout = constraint.layout;
                        layout.goneEndMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.goneEndMargin);
                        break;
                    case 13:
                        layout = constraint.layout;
                        layout.goneLeftMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.goneLeftMargin);
                        break;
                    case 14:
                        layout = constraint.layout;
                        layout.goneRightMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.goneRightMargin);
                        break;
                    case 15:
                        layout = constraint.layout;
                        layout.goneStartMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.goneStartMargin);
                        break;
                    case 16:
                        layout = constraint.layout;
                        layout.goneTopMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.goneTopMargin);
                        break;
                    case 17:
                        layout = constraint.layout;
                        layout.guideBegin = obtainStyledAttributes.getDimensionPixelOffset(index, layout.guideBegin);
                        break;
                    case 18:
                        layout = constraint.layout;
                        layout.guideEnd = obtainStyledAttributes.getDimensionPixelOffset(index, layout.guideEnd);
                        break;
                    case 19:
                        layout = constraint.layout;
                        layout.guidePercent = obtainStyledAttributes.getFloat(index, layout.guidePercent);
                        break;
                    case PG.styleable.CircledImageView_image_circle_percentage /*20*/:
                        layout = constraint.layout;
                        layout.horizontalBias = obtainStyledAttributes.getFloat(index, layout.horizontalBias);
                        break;
                    case 21:
                        layout = constraint.layout;
                        layout.mHeight = obtainStyledAttributes.getLayoutDimension(index, layout.mHeight);
                        break;
                    case 22:
                        propertySet = constraint.propertySet;
                        propertySet.visibility = obtainStyledAttributes.getInt(index, propertySet.visibility);
                        constraint.propertySet.visibility = VISIBILITY_FLAGS[constraint.propertySet.visibility];
                        break;
                    case 23:
                        layout = constraint.layout;
                        layout.mWidth = obtainStyledAttributes.getLayoutDimension(index, layout.mWidth);
                        break;
                    case 24:
                        layout = constraint.layout;
                        layout.leftMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.leftMargin);
                        break;
                    case 25:
                        layout = constraint.layout;
                        layout.leftToLeft = lookupID(obtainStyledAttributes, index, layout.leftToLeft);
                        break;
                    case 26:
                        layout = constraint.layout;
                        layout.leftToRight = lookupID(obtainStyledAttributes, index, layout.leftToRight);
                        break;
                    case PG.styleable.CircledImageView_shadow_width /*27*/:
                        layout = constraint.layout;
                        layout.orientation = obtainStyledAttributes.getInt(index, layout.orientation);
                        break;
                    case PG.styleable.CircledImageView_square_dimen /*28*/:
                        layout = constraint.layout;
                        layout.rightMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.rightMargin);
                        break;
                    case 29:
                        layout = constraint.layout;
                        layout.rightToLeft = lookupID(obtainStyledAttributes, index, layout.rightToLeft);
                        break;
                    case 30:
                        layout = constraint.layout;
                        layout.rightToRight = lookupID(obtainStyledAttributes, index, layout.rightToRight);
                        break;
                    case 31:
                        layout = constraint.layout;
                        layout.startMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.startMargin);
                        break;
                    case 32:
                        layout = constraint.layout;
                        layout.startToEnd = lookupID(obtainStyledAttributes, index, layout.startToEnd);
                        break;
                    case 33:
                        layout = constraint.layout;
                        layout.startToStart = lookupID(obtainStyledAttributes, index, layout.startToStart);
                        break;
                    case 34:
                        layout = constraint.layout;
                        layout.topMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.topMargin);
                        break;
                    case 35:
                        layout = constraint.layout;
                        layout.topToBottom = lookupID(obtainStyledAttributes, index, layout.topToBottom);
                        break;
                    case 36:
                        layout = constraint.layout;
                        layout.topToTop = lookupID(obtainStyledAttributes, index, layout.topToTop);
                        break;
                    case 37:
                        layout = constraint.layout;
                        layout.verticalBias = obtainStyledAttributes.getFloat(index, layout.verticalBias);
                        break;
                    case 38:
                        constraint.mViewId = obtainStyledAttributes.getResourceId(index, constraint.mViewId);
                        break;
                    case 39:
                        layout = constraint.layout;
                        layout.horizontalWeight = obtainStyledAttributes.getFloat(index, layout.horizontalWeight);
                        break;
                    case 40:
                        layout = constraint.layout;
                        layout.verticalWeight = obtainStyledAttributes.getFloat(index, layout.verticalWeight);
                        break;
                    case 41:
                        layout = constraint.layout;
                        layout.horizontalChainStyle = obtainStyledAttributes.getInt(index, layout.horizontalChainStyle);
                        break;
                    case 42:
                        layout = constraint.layout;
                        layout.verticalChainStyle = obtainStyledAttributes.getInt(index, layout.verticalChainStyle);
                        break;
                    case 43:
                        propertySet = constraint.propertySet;
                        propertySet.alpha = obtainStyledAttributes.getFloat(index, propertySet.alpha);
                        break;
                    case 44:
                        Transform transform2 = constraint.transform;
                        transform2.applyElevation = true;
                        transform2.elevation = obtainStyledAttributes.getDimension(index, transform2.elevation);
                        break;
                    case 45:
                        transform = constraint.transform;
                        transform.rotationX = obtainStyledAttributes.getFloat(index, transform.rotationX);
                        break;
                    case 46:
                        transform = constraint.transform;
                        transform.rotationY = obtainStyledAttributes.getFloat(index, transform.rotationY);
                        break;
                    case 47:
                        transform = constraint.transform;
                        transform.scaleX = obtainStyledAttributes.getFloat(index, transform.scaleX);
                        break;
                    case 48:
                        transform = constraint.transform;
                        transform.scaleY = obtainStyledAttributes.getFloat(index, transform.scaleY);
                        break;
                    case 49:
                        transform = constraint.transform;
                        transform.transformPivotX = obtainStyledAttributes.getDimension(index, transform.transformPivotX);
                        break;
                    case 50:
                        transform = constraint.transform;
                        transform.transformPivotY = obtainStyledAttributes.getDimension(index, transform.transformPivotY);
                        break;
                    case 51:
                        transform = constraint.transform;
                        transform.translationX = obtainStyledAttributes.getDimension(index, transform.translationX);
                        break;
                    case 52:
                        transform = constraint.transform;
                        transform.translationY = obtainStyledAttributes.getDimension(index, transform.translationY);
                        break;
                    case 53:
                        transform = constraint.transform;
                        transform.translationZ = obtainStyledAttributes.getDimension(index, transform.translationZ);
                        break;
                    case 54:
                        layout = constraint.layout;
                        layout.widthDefault = obtainStyledAttributes.getInt(index, layout.widthDefault);
                        break;
                    case 55:
                        layout = constraint.layout;
                        layout.heightDefault = obtainStyledAttributes.getInt(index, layout.heightDefault);
                        break;
                    case 56:
                        layout = constraint.layout;
                        layout.widthMax = obtainStyledAttributes.getDimensionPixelSize(index, layout.widthMax);
                        break;
                    case 57:
                        layout = constraint.layout;
                        layout.heightMax = obtainStyledAttributes.getDimensionPixelSize(index, layout.heightMax);
                        break;
                    case 58:
                        layout = constraint.layout;
                        layout.widthMin = obtainStyledAttributes.getDimensionPixelSize(index, layout.widthMin);
                        break;
                    case 59:
                        layout = constraint.layout;
                        layout.heightMin = obtainStyledAttributes.getDimensionPixelSize(index, layout.heightMin);
                        break;
                    case 60:
                        transform = constraint.transform;
                        transform.rotation = obtainStyledAttributes.getFloat(index, transform.rotation);
                        break;
                    case 61:
                        layout = constraint.layout;
                        layout.circleConstraint = lookupID(obtainStyledAttributes, index, layout.circleConstraint);
                        break;
                    case 62:
                        layout = constraint.layout;
                        layout.circleRadius = obtainStyledAttributes.getDimensionPixelSize(index, layout.circleRadius);
                        break;
                    case 63:
                        layout = constraint.layout;
                        layout.circleAngle = obtainStyledAttributes.getFloat(index, layout.circleAngle);
                        break;
                    case 64:
                        motion = constraint.motion;
                        motion.mAnimateRelativeTo = lookupID(obtainStyledAttributes, index, motion.mAnimateRelativeTo);
                        break;
                    case 65:
                        if (obtainStyledAttributes.peekValue(index).type != 3) {
                            constraint.motion.mTransitionEasing = Easing.NAMED_EASING[obtainStyledAttributes.getInteger(index, 0)];
                            break;
                        }
                        constraint.motion.mTransitionEasing = obtainStyledAttributes.getString(index);
                        break;
                    case 66:
                        constraint.motion.mDrawPath = obtainStyledAttributes.getInt(index, 0);
                        break;
                    case 67:
                        motion = constraint.motion;
                        motion.mPathRotate = obtainStyledAttributes.getFloat(index, motion.mPathRotate);
                        break;
                    case 68:
                        propertySet = constraint.propertySet;
                        propertySet.mProgress = obtainStyledAttributes.getFloat(index, propertySet.mProgress);
                        break;
                    case 69:
                        constraint.layout.widthPercent = obtainStyledAttributes.getFloat(index, 1.0f);
                        break;
                    case 70:
                        constraint.layout.heightPercent = obtainStyledAttributes.getFloat(index, 1.0f);
                        break;
                    case 71:
                        Log.e(str2, "CURRENTLY UNSUPPORTED");
                        break;
                    case 72:
                        layout = constraint.layout;
                        layout.mBarrierDirection = obtainStyledAttributes.getInt(index, layout.mBarrierDirection);
                        break;
                    case 73:
                        layout = constraint.layout;
                        layout.mBarrierMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.mBarrierMargin);
                        break;
                    case 74:
                        constraint.layout.mReferenceIdString = obtainStyledAttributes.getString(index);
                        break;
                    case 75:
                        layout = constraint.layout;
                        layout.mBarrierAllowsGoneWidgets = obtainStyledAttributes.getBoolean(index, layout.mBarrierAllowsGoneWidgets);
                        break;
                    case 76:
                        motion = constraint.motion;
                        motion.mPathMotionArc = obtainStyledAttributes.getInt(index, motion.mPathMotionArc);
                        break;
                    case 77:
                        constraint.layout.mConstraintTag = obtainStyledAttributes.getString(index);
                        break;
                    case 78:
                        propertySet = constraint.propertySet;
                        propertySet.mVisibilityMode = obtainStyledAttributes.getInt(index, propertySet.mVisibilityMode);
                        break;
                    case 79:
                        motion = constraint.motion;
                        motion.mMotionStagger = obtainStyledAttributes.getFloat(index, motion.mMotionStagger);
                        break;
                    case 80:
                        layout = constraint.layout;
                        layout.constrainedWidth = obtainStyledAttributes.getBoolean(index, layout.constrainedWidth);
                        break;
                    case 81:
                        layout = constraint.layout;
                        layout.constrainedHeight = obtainStyledAttributes.getBoolean(index, layout.constrainedHeight);
                        break;
                    case 82:
                        motion = constraint.motion;
                        motion.mAnimateCircleAngleTo = obtainStyledAttributes.getInteger(index, motion.mAnimateCircleAngleTo);
                        break;
                    case 83:
                        transform = constraint.transform;
                        transform.transformPivotTarget = lookupID(obtainStyledAttributes, index, transform.transformPivotTarget);
                        break;
                    case 84:
                        motion = constraint.motion;
                        motion.mQuantizeMotionSteps = obtainStyledAttributes.getInteger(index, motion.mQuantizeMotionSteps);
                        break;
                    case 85:
                        motion = constraint.motion;
                        motion.mQuantizeMotionPhase = obtainStyledAttributes.getFloat(index, motion.mQuantizeMotionPhase);
                        break;
                    case 86:
                        TypedValue peekValue = obtainStyledAttributes.peekValue(index);
                        if (peekValue.type != 1) {
                            if (peekValue.type != 3) {
                                motion = constraint.motion;
                                motion.mQuantizeInterpolatorType = obtainStyledAttributes.getInteger(index, motion.mQuantizeInterpolatorID);
                                break;
                            }
                            constraint.motion.mQuantizeInterpolatorString = obtainStyledAttributes.getString(index);
                            if (constraint.motion.mQuantizeInterpolatorString.indexOf("/") <= 0) {
                                constraint.motion.mQuantizeInterpolatorType = -1;
                                break;
                            }
                            constraint.motion.mQuantizeInterpolatorID = obtainStyledAttributes.getResourceId(index, -1);
                            constraint.motion.mQuantizeInterpolatorType = -2;
                            break;
                        }
                        constraint.motion.mQuantizeInterpolatorID = obtainStyledAttributes.getResourceId(index, -1);
                        Motion motion2 = constraint.motion;
                        if (motion2.mQuantizeInterpolatorID == -1) {
                            break;
                        }
                        motion2.mQuantizeInterpolatorType = -2;
                        break;
                    case 87:
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("unused attribute 0x");
                        stringBuilder.append(Integer.toHexString(index));
                        stringBuilder.append(str);
                        stringBuilder.append(sparseIntArray.get(index));
                        Log.w(str2, stringBuilder.toString());
                        break;
                    case 91:
                        layout = constraint.layout;
                        layout.baselineToTop = lookupID(obtainStyledAttributes, index, layout.baselineToTop);
                        break;
                    case 92:
                        layout = constraint.layout;
                        layout.baselineToBottom = lookupID(obtainStyledAttributes, index, layout.baselineToBottom);
                        break;
                    case 93:
                        layout = constraint.layout;
                        layout.baselineMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.baselineMargin);
                        break;
                    case 94:
                        layout = constraint.layout;
                        layout.goneBaselineMargin = obtainStyledAttributes.getDimensionPixelSize(index, layout.goneBaselineMargin);
                        break;
                    case 95:
                        parseDimensionConstraints(constraint.layout, obtainStyledAttributes, index, 0);
                        break;
                    case 96:
                        parseDimensionConstraints(constraint.layout, obtainStyledAttributes, index, 1);
                        break;
                    case 97:
                        layout = constraint.layout;
                        layout.mWrapBehavior = obtainStyledAttributes.getInt(index, layout.mWrapBehavior);
                        break;
                    default:
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("Unknown attribute 0x");
                        stringBuilder.append(Integer.toHexString(index));
                        stringBuilder.append(str);
                        stringBuilder.append(sparseIntArray.get(index));
                        Log.w(str2, stringBuilder.toString());
                        break;
                }
            }
        }
        obtainStyledAttributes.recycle();
        return constraint;
    }

    public static int lookupID(TypedArray typedArray, int i, int i2) {
        i2 = typedArray.getResourceId(i, i2);
        return i2 == -1 ? typedArray.getInt(i, -1) : i2;
    }

    static void parseDimensionConstraints(Object obj, TypedArray typedArray, int i, int i2) {
        LayoutParams layoutParams;
        Layout layout;
        Delta delta;
        boolean z = true;
        int i3 = 0;
        switch (typedArray.peekValue(i).type) {
            case 3:
                String string = typedArray.getString(i);
                if (string != null) {
                    i = string.indexOf(61);
                    int length = string.length();
                    if (i > 0 && i < length - 1) {
                        String substring = string.substring(0, i);
                        string = string.substring(i + 1);
                        if (string.length() > 0) {
                            String trim = substring.trim();
                            string = string.trim();
                            if ("ratio".equalsIgnoreCase(trim)) {
                                if (obj instanceof LayoutParams) {
                                    layoutParams = (LayoutParams) obj;
                                    if (i2 == 0) {
                                        layoutParams.width = 0;
                                    } else {
                                        layoutParams.height = 0;
                                    }
                                    parseDimensionRatioString(layoutParams, string);
                                    return;
                                } else if (obj instanceof Layout) {
                                    ((Layout) obj).dimensionRatio = string;
                                    return;
                                } else if (obj instanceof Delta) {
                                    ((Delta) obj).add(5, string);
                                    return;
                                }
                            } else if ("weight".equalsIgnoreCase(trim)) {
                                try {
                                    r6 = Float.parseFloat(string);
                                    if (obj instanceof LayoutParams) {
                                        layoutParams = (LayoutParams) obj;
                                        if (i2 == 0) {
                                            layoutParams.width = 0;
                                            layoutParams.horizontalWeight = r6;
                                            return;
                                        }
                                        layoutParams.height = 0;
                                        layoutParams.verticalWeight = r6;
                                        return;
                                    } else if (obj instanceof Layout) {
                                        layout = (Layout) obj;
                                        if (i2 == 0) {
                                            layout.mWidth = 0;
                                            layout.horizontalWeight = r6;
                                            return;
                                        }
                                        layout.mHeight = 0;
                                        layout.verticalWeight = r6;
                                        return;
                                    } else if (obj instanceof Delta) {
                                        delta = (Delta) obj;
                                        if (i2 == 0) {
                                            delta.add(23, 0);
                                            delta.add(39, r6);
                                            return;
                                        }
                                        delta.add(21, 0);
                                        delta.add(40, r6);
                                        return;
                                    }
                                } catch (NumberFormatException e) {
                                    return;
                                }
                            } else if ("parent".equalsIgnoreCase(trim)) {
                                try {
                                    r6 = Math.max(0.0f, Math.min(1.0f, Float.parseFloat(string)));
                                    if (obj instanceof LayoutParams) {
                                        layoutParams = (LayoutParams) obj;
                                        if (i2 == 0) {
                                            layoutParams.width = 0;
                                            layoutParams.matchConstraintPercentWidth = r6;
                                            layoutParams.matchConstraintDefaultWidth = 2;
                                            return;
                                        }
                                        layoutParams.height = 0;
                                        layoutParams.matchConstraintPercentHeight = r6;
                                        layoutParams.matchConstraintDefaultHeight = 2;
                                        return;
                                    } else if (obj instanceof Layout) {
                                        layout = (Layout) obj;
                                        if (i2 == 0) {
                                            layout.mWidth = 0;
                                            layout.widthPercent = r6;
                                            layout.widthDefault = 2;
                                            return;
                                        }
                                        layout.mHeight = 0;
                                        layout.heightPercent = r6;
                                        layout.heightDefault = 2;
                                        return;
                                    } else if (obj instanceof Delta) {
                                        delta = (Delta) obj;
                                        if (i2 == 0) {
                                            delta.add(23, 0);
                                            delta.add(54, 2);
                                            return;
                                        }
                                        delta.add(21, 0);
                                        delta.add(55, 2);
                                        return;
                                    }
                                } catch (NumberFormatException e2) {
                                    return;
                                }
                            }
                        }
                    }
                }
                return;
            case 5:
                i3 = typedArray.getDimensionPixelSize(i, 0);
                z = false;
                break;
            default:
                int i4 = typedArray.getInt(i, 0);
                switch (i4) {
                    case -4:
                        i3 = -2;
                        break;
                    case -3:
                        break;
                    case DeepLinkServiceResult.RPC_SEND_FAILURE /*-2*/:
                    case -1:
                        i3 = i4;
                        break;
                    default:
                        z = false;
                        break;
                }
                z = false;
                break;
        }
        if (obj instanceof LayoutParams) {
            layoutParams = (LayoutParams) obj;
            if (i2 == 0) {
                layoutParams.width = i3;
                layoutParams.constrainedWidth = z;
                return;
            }
            layoutParams.height = i3;
            layoutParams.constrainedHeight = z;
        } else if (obj instanceof Layout) {
            layout = (Layout) obj;
            if (i2 == 0) {
                layout.mWidth = i3;
                layout.constrainedWidth = z;
                return;
            }
            layout.mHeight = i3;
            layout.constrainedHeight = z;
        } else {
            if (obj instanceof Delta) {
                delta = (Delta) obj;
                if (i2 == 0) {
                    delta.add(23, i3);
                    delta.add(80, z);
                    return;
                }
                delta.add(21, i3);
                delta.add(81, z);
            }
        }
    }

    static void parseDimensionRatioString(LayoutParams layoutParams, String str) {
        if (str != null) {
            int length = str.length();
            int indexOf = str.indexOf(44);
            int i = 0;
            if (indexOf <= 0 || indexOf >= length - 1) {
                indexOf = -1;
            } else {
                String substring = str.substring(0, indexOf);
                if (!substring.equalsIgnoreCase("W")) {
                    i = substring.equalsIgnoreCase("H") ? 1 : -1;
                }
                int i2 = i;
                i = indexOf + 1;
                indexOf = i2;
            }
            int indexOf2 = str.indexOf(58);
            String substring2;
            if (indexOf2 < 0 || indexOf2 >= length - 1) {
                substring2 = str.substring(i);
                if (substring2.length() > 0) {
                    Float.parseFloat(substring2);
                }
            } else {
                substring2 = str.substring(i, indexOf2);
                String substring3 = str.substring(indexOf2 + 1);
                if (substring2.length() > 0 && substring3.length() > 0) {
                    try {
                        float parseFloat = Float.parseFloat(substring2);
                        float parseFloat2 = Float.parseFloat(substring3);
                        if (parseFloat > 0.0f && parseFloat2 > 0.0f) {
                            if (indexOf == 1) {
                                Math.abs(parseFloat2 / parseFloat);
                            } else {
                                Math.abs(parseFloat / parseFloat2);
                            }
                        }
                    } catch (NumberFormatException e) {
                    }
                }
            }
        }
        layoutParams.dimensionRatio = str;
    }

    private static void populateOverride$ar$ds(Constraint constraint, TypedArray typedArray) {
        int indexCount = typedArray.getIndexCount();
        Delta delta = new Delta();
        constraint.mDelta = delta;
        constraint.motion.mApply = false;
        constraint.layout.mApply = false;
        constraint.propertySet.mApply = false;
        constraint.transform.mApply = false;
        for (int i = 0; i < indexCount; i++) {
            int index = typedArray.getIndex(i);
            String str = "   ";
            String str2 = "ConstraintSet";
            StringBuilder stringBuilder;
            switch (overrideMapToConstant.get(index)) {
                case 2:
                    delta.add(2, typedArray.getDimensionPixelSize(index, constraint.layout.bottomMargin));
                    break;
                case 5:
                    delta.add(5, typedArray.getString(index));
                    break;
                case 6:
                    delta.add(6, typedArray.getDimensionPixelOffset(index, constraint.layout.editorAbsoluteX));
                    break;
                case 7:
                    delta.add(7, typedArray.getDimensionPixelOffset(index, constraint.layout.editorAbsoluteY));
                    break;
                case 8:
                    delta.add(8, typedArray.getDimensionPixelSize(index, constraint.layout.endMargin));
                    break;
                case 11:
                    delta.add(11, typedArray.getDimensionPixelSize(index, constraint.layout.goneBottomMargin));
                    break;
                case 12:
                    delta.add(12, typedArray.getDimensionPixelSize(index, constraint.layout.goneEndMargin));
                    break;
                case 13:
                    delta.add(13, typedArray.getDimensionPixelSize(index, constraint.layout.goneLeftMargin));
                    break;
                case 14:
                    delta.add(14, typedArray.getDimensionPixelSize(index, constraint.layout.goneRightMargin));
                    break;
                case 15:
                    delta.add(15, typedArray.getDimensionPixelSize(index, constraint.layout.goneStartMargin));
                    break;
                case 16:
                    delta.add(16, typedArray.getDimensionPixelSize(index, constraint.layout.goneTopMargin));
                    break;
                case 17:
                    delta.add(17, typedArray.getDimensionPixelOffset(index, constraint.layout.guideBegin));
                    break;
                case 18:
                    delta.add(18, typedArray.getDimensionPixelOffset(index, constraint.layout.guideEnd));
                    break;
                case 19:
                    delta.add(19, typedArray.getFloat(index, constraint.layout.guidePercent));
                    break;
                case PG.styleable.CircledImageView_image_circle_percentage /*20*/:
                    delta.add(20, typedArray.getFloat(index, constraint.layout.horizontalBias));
                    break;
                case 21:
                    delta.add(21, typedArray.getLayoutDimension(index, constraint.layout.mHeight));
                    break;
                case 22:
                    delta.add(22, VISIBILITY_FLAGS[typedArray.getInt(index, constraint.propertySet.visibility)]);
                    break;
                case 23:
                    delta.add(23, typedArray.getLayoutDimension(index, constraint.layout.mWidth));
                    break;
                case 24:
                    delta.add(24, typedArray.getDimensionPixelSize(index, constraint.layout.leftMargin));
                    break;
                case PG.styleable.CircledImageView_shadow_width /*27*/:
                    delta.add(27, typedArray.getInt(index, constraint.layout.orientation));
                    break;
                case PG.styleable.CircledImageView_square_dimen /*28*/:
                    delta.add(28, typedArray.getDimensionPixelSize(index, constraint.layout.rightMargin));
                    break;
                case 31:
                    delta.add(31, typedArray.getDimensionPixelSize(index, constraint.layout.startMargin));
                    break;
                case 34:
                    delta.add(34, typedArray.getDimensionPixelSize(index, constraint.layout.topMargin));
                    break;
                case 37:
                    delta.add(37, typedArray.getFloat(index, constraint.layout.verticalBias));
                    break;
                case 38:
                    index = typedArray.getResourceId(index, constraint.mViewId);
                    constraint.mViewId = index;
                    delta.add(38, index);
                    break;
                case 39:
                    delta.add(39, typedArray.getFloat(index, constraint.layout.horizontalWeight));
                    break;
                case 40:
                    delta.add(40, typedArray.getFloat(index, constraint.layout.verticalWeight));
                    break;
                case 41:
                    delta.add(41, typedArray.getInt(index, constraint.layout.horizontalChainStyle));
                    break;
                case 42:
                    delta.add(42, typedArray.getInt(index, constraint.layout.verticalChainStyle));
                    break;
                case 43:
                    delta.add(43, typedArray.getFloat(index, constraint.propertySet.alpha));
                    break;
                case 44:
                    delta.add(44, true);
                    delta.add(44, typedArray.getDimension(index, constraint.transform.elevation));
                    break;
                case 45:
                    delta.add(45, typedArray.getFloat(index, constraint.transform.rotationX));
                    break;
                case 46:
                    delta.add(46, typedArray.getFloat(index, constraint.transform.rotationY));
                    break;
                case 47:
                    delta.add(47, typedArray.getFloat(index, constraint.transform.scaleX));
                    break;
                case 48:
                    delta.add(48, typedArray.getFloat(index, constraint.transform.scaleY));
                    break;
                case 49:
                    delta.add(49, typedArray.getDimension(index, constraint.transform.transformPivotX));
                    break;
                case 50:
                    delta.add(50, typedArray.getDimension(index, constraint.transform.transformPivotY));
                    break;
                case 51:
                    delta.add(51, typedArray.getDimension(index, constraint.transform.translationX));
                    break;
                case 52:
                    delta.add(52, typedArray.getDimension(index, constraint.transform.translationY));
                    break;
                case 53:
                    delta.add(53, typedArray.getDimension(index, constraint.transform.translationZ));
                    break;
                case 54:
                    delta.add(54, typedArray.getInt(index, constraint.layout.widthDefault));
                    break;
                case 55:
                    delta.add(55, typedArray.getInt(index, constraint.layout.heightDefault));
                    break;
                case 56:
                    delta.add(56, typedArray.getDimensionPixelSize(index, constraint.layout.widthMax));
                    break;
                case 57:
                    delta.add(57, typedArray.getDimensionPixelSize(index, constraint.layout.heightMax));
                    break;
                case 58:
                    delta.add(58, typedArray.getDimensionPixelSize(index, constraint.layout.widthMin));
                    break;
                case 59:
                    delta.add(59, typedArray.getDimensionPixelSize(index, constraint.layout.heightMin));
                    break;
                case 60:
                    delta.add(60, typedArray.getFloat(index, constraint.transform.rotation));
                    break;
                case 62:
                    delta.add(62, typedArray.getDimensionPixelSize(index, constraint.layout.circleRadius));
                    break;
                case 63:
                    delta.add(63, typedArray.getFloat(index, constraint.layout.circleAngle));
                    break;
                case 64:
                    delta.add(64, lookupID(typedArray, index, constraint.motion.mAnimateRelativeTo));
                    break;
                case 65:
                    if (typedArray.peekValue(index).type != 3) {
                        delta.add(65, Easing.NAMED_EASING[typedArray.getInteger(index, 0)]);
                        break;
                    } else {
                        delta.add(65, typedArray.getString(index));
                        break;
                    }
                case 66:
                    delta.add(66, typedArray.getInt(index, 0));
                    break;
                case 67:
                    delta.add(67, typedArray.getFloat(index, constraint.motion.mPathRotate));
                    break;
                case 68:
                    delta.add(68, typedArray.getFloat(index, constraint.propertySet.mProgress));
                    break;
                case 69:
                    delta.add(69, typedArray.getFloat(index, 1.0f));
                    break;
                case 70:
                    delta.add(70, typedArray.getFloat(index, 1.0f));
                    break;
                case 71:
                    Log.e(str2, "CURRENTLY UNSUPPORTED");
                    break;
                case 72:
                    delta.add(72, typedArray.getInt(index, constraint.layout.mBarrierDirection));
                    break;
                case 73:
                    delta.add(73, typedArray.getDimensionPixelSize(index, constraint.layout.mBarrierMargin));
                    break;
                case 74:
                    delta.add(74, typedArray.getString(index));
                    break;
                case 75:
                    delta.add(75, typedArray.getBoolean(index, constraint.layout.mBarrierAllowsGoneWidgets));
                    break;
                case 76:
                    delta.add(76, typedArray.getInt(index, constraint.motion.mPathMotionArc));
                    break;
                case 77:
                    delta.add(77, typedArray.getString(index));
                    break;
                case 78:
                    delta.add(78, typedArray.getInt(index, constraint.propertySet.mVisibilityMode));
                    break;
                case 79:
                    delta.add(79, typedArray.getFloat(index, constraint.motion.mMotionStagger));
                    break;
                case 80:
                    delta.add(80, typedArray.getBoolean(index, constraint.layout.constrainedWidth));
                    break;
                case 81:
                    delta.add(81, typedArray.getBoolean(index, constraint.layout.constrainedHeight));
                    break;
                case 82:
                    delta.add(82, typedArray.getInteger(index, constraint.motion.mAnimateCircleAngleTo));
                    break;
                case 83:
                    delta.add(83, lookupID(typedArray, index, constraint.transform.transformPivotTarget));
                    break;
                case 84:
                    delta.add(84, typedArray.getInteger(index, constraint.motion.mQuantizeMotionSteps));
                    break;
                case 85:
                    delta.add(85, typedArray.getFloat(index, constraint.motion.mQuantizeMotionPhase));
                    break;
                case 86:
                    TypedValue peekValue = typedArray.peekValue(index);
                    if (peekValue.type != 1) {
                        if (peekValue.type != 3) {
                            Motion motion = constraint.motion;
                            motion.mQuantizeInterpolatorType = typedArray.getInteger(index, motion.mQuantizeInterpolatorID);
                            delta.add(88, constraint.motion.mQuantizeInterpolatorType);
                            break;
                        }
                        constraint.motion.mQuantizeInterpolatorString = typedArray.getString(index);
                        delta.add(90, constraint.motion.mQuantizeInterpolatorString);
                        if (constraint.motion.mQuantizeInterpolatorString.indexOf("/") <= 0) {
                            constraint.motion.mQuantizeInterpolatorType = -1;
                            delta.add(88, -1);
                            break;
                        }
                        constraint.motion.mQuantizeInterpolatorID = typedArray.getResourceId(index, -1);
                        delta.add(89, constraint.motion.mQuantizeInterpolatorID);
                        constraint.motion.mQuantizeInterpolatorType = -2;
                        delta.add(88, -2);
                        break;
                    }
                    constraint.motion.mQuantizeInterpolatorID = typedArray.getResourceId(index, -1);
                    delta.add(89, constraint.motion.mQuantizeInterpolatorID);
                    Motion motion2 = constraint.motion;
                    if (motion2.mQuantizeInterpolatorID == -1) {
                        break;
                    }
                    motion2.mQuantizeInterpolatorType = -2;
                    delta.add(88, -2);
                    break;
                case 87:
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("unused attribute 0x");
                    stringBuilder.append(Integer.toHexString(index));
                    stringBuilder.append(str);
                    stringBuilder.append(mapToConstant.get(index));
                    Log.w(str2, stringBuilder.toString());
                    break;
                case 93:
                    delta.add(93, typedArray.getDimensionPixelSize(index, constraint.layout.baselineMargin));
                    break;
                case 94:
                    delta.add(94, typedArray.getDimensionPixelSize(index, constraint.layout.goneBaselineMargin));
                    break;
                case 95:
                    parseDimensionConstraints(delta, typedArray, index, 0);
                    break;
                case 96:
                    parseDimensionConstraints(delta, typedArray, index, 1);
                    break;
                case 97:
                    delta.add(97, typedArray.getInt(index, constraint.layout.mWrapBehavior));
                    break;
                case 98:
                    if (typedArray.peekValue(index).type != 3) {
                        constraint.mViewId = typedArray.getResourceId(index, constraint.mViewId);
                        break;
                    } else {
                        typedArray.getString(index);
                        break;
                    }
                default:
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("Unknown attribute 0x");
                    stringBuilder.append(Integer.toHexString(index));
                    stringBuilder.append(str);
                    stringBuilder.append(mapToConstant.get(index));
                    Log.w(str2, stringBuilder.toString());
                    break;
            }
        }
    }

    private static final String sideToString$ar$ds(int i) {
        switch (i) {
            case 3:
                return "top";
            case 4:
                return "bottom";
            case 5:
                return "baseline";
            default:
                return "start";
        }
    }

    public final void applyTo(ConstraintLayout constraintLayout) {
        applyToInternal$ar$ds(constraintLayout);
        constraintLayout.mConstraintSet = null;
        constraintLayout.requestLayout();
    }

    final void applyToInternal$ar$ds(ConstraintLayout constraintLayout) {
        int i;
        NoSuchMethodException e;
        StringBuilder stringBuilder;
        IllegalAccessException e2;
        StringBuilder stringBuilder2;
        InvocationTargetException e3;
        ViewGroup viewGroup;
        ViewGroup viewGroup2 = constraintLayout;
        String str = "\" not found on ";
        String str2 = " Custom Attribute \"";
        String str3 = "TransitionLayout";
        int childCount = constraintLayout.getChildCount();
        HashSet hashSet = new HashSet(this.mConstraints.keySet());
        int i2 = 0;
        while (i2 < childCount) {
            String str4;
            View findViewById;
            View childAt = viewGroup2.getChildAt(i2);
            int id = childAt.getId();
            HashMap hashMap = r1.mConstraints;
            Integer valueOf = Integer.valueOf(id);
            String str5 = "ConstraintSet";
            StringBuilder stringBuilder3;
            if (!hashMap.containsKey(valueOf)) {
                String resourceEntryName;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("id unknown ");
                try {
                    resourceEntryName = childAt.getContext().getResources().getResourceEntryName(childAt.getId());
                } catch (Exception e4) {
                    resourceEntryName = "UNKNOWN";
                }
                stringBuilder3.append(resourceEntryName);
                Log.w(str5, stringBuilder3.toString());
                i = childCount;
            } else if (id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            } else if (id == -1) {
                i = childCount;
            } else if (r1.mConstraints.containsKey(valueOf)) {
                hashSet.remove(valueOf);
                Constraint constraint = (Constraint) r1.mConstraints.get(valueOf);
                if (constraint != null) {
                    if (childAt instanceof Barrier) {
                        constraint.layout.mHelperType = 1;
                        Barrier barrier = (Barrier) childAt;
                        barrier.setId(id);
                        Layout layout = constraint.layout;
                        barrier.mIndicatedType = layout.mBarrierDirection;
                        barrier.setMargin(layout.mBarrierMargin);
                        layout = constraint.layout;
                        barrier.mBarrier.mAllowsGoneWidget = layout.mBarrierAllowsGoneWidgets;
                        int[] iArr = layout.mReferenceIds;
                        if (iArr != null) {
                            barrier.setReferencedIds(iArr);
                        } else {
                            String str6 = layout.mReferenceIdString;
                            if (str6 != null) {
                                layout.mReferenceIds = convertReferenceString$ar$ds(barrier, str6);
                                barrier.setReferencedIds(constraint.layout.mReferenceIds);
                            }
                        }
                    }
                    LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                    layoutParams.validate();
                    constraint.applyTo(layoutParams);
                    HashMap hashMap2 = constraint.mCustomConstraints;
                    Class cls = childAt.getClass();
                    for (String str42 : hashMap2.keySet()) {
                        HashMap hashMap3;
                        String str7;
                        ConstraintAttribute constraintAttribute = (ConstraintAttribute) hashMap2.get(str42);
                        if (constraintAttribute.mMethod) {
                            hashMap3 = hashMap2;
                            str7 = str42;
                        } else {
                            stringBuilder3 = new StringBuilder();
                            hashMap3 = hashMap2;
                            stringBuilder3.append("set");
                            stringBuilder3.append(str42);
                            str7 = stringBuilder3.toString();
                        }
                        ConstraintLayout constraintLayout2;
                        try {
                            int i3 = constraintAttribute.mType$ar$edu$527a520a_0;
                            i = i3 - 1;
                            if (i3 != 0) {
                                Method method;
                                Object[] objArr;
                                switch (i) {
                                    case 0:
                                        i = childCount;
                                        method = cls.getMethod(str7, new Class[]{Integer.TYPE});
                                        objArr = new Object[1];
                                        objArr[0] = Integer.valueOf(constraintAttribute.mIntegerValue);
                                        method.invoke(childAt, objArr);
                                        constraintLayout2 = constraintLayout;
                                        hashMap2 = hashMap3;
                                        childCount = i;
                                        break;
                                    case 1:
                                        i = childCount;
                                        method = cls.getMethod(str7, new Class[]{Float.TYPE});
                                        objArr = new Object[1];
                                        objArr[0] = Float.valueOf(constraintAttribute.mFloatValue);
                                        method.invoke(childAt, objArr);
                                        constraintLayout2 = constraintLayout;
                                        hashMap2 = hashMap3;
                                        childCount = i;
                                        break;
                                    case 2:
                                        i = childCount;
                                        method = cls.getMethod(str7, new Class[]{Integer.TYPE});
                                        objArr = new Object[1];
                                        objArr[0] = Integer.valueOf(constraintAttribute.mColorValue);
                                        method.invoke(childAt, objArr);
                                        constraintLayout2 = constraintLayout;
                                        hashMap2 = hashMap3;
                                        childCount = i;
                                        break;
                                    case 3:
                                        i = childCount;
                                        method = cls.getMethod(str7, new Class[]{Drawable.class});
                                        new ColorDrawable().setColor(constraintAttribute.mColorValue);
                                        method.invoke(childAt, new Object[]{r6});
                                        constraintLayout2 = constraintLayout;
                                        hashMap2 = hashMap3;
                                        childCount = i;
                                        break;
                                    case 4:
                                        i = childCount;
                                        method = cls.getMethod(str7, new Class[]{CharSequence.class});
                                        objArr = new Object[1];
                                        objArr[0] = constraintAttribute.mStringValue;
                                        method.invoke(childAt, objArr);
                                        constraintLayout2 = constraintLayout;
                                        hashMap2 = hashMap3;
                                        childCount = i;
                                        break;
                                    case 5:
                                        i = childCount;
                                        method = cls.getMethod(str7, new Class[]{Boolean.TYPE});
                                        objArr = new Object[1];
                                        objArr[0] = Boolean.valueOf(constraintAttribute.mBooleanValue);
                                        method.invoke(childAt, objArr);
                                        constraintLayout2 = constraintLayout;
                                        hashMap2 = hashMap3;
                                        childCount = i;
                                        break;
                                    case 6:
                                        i = childCount;
                                        method = cls.getMethod(str7, new Class[]{Float.TYPE});
                                        objArr = new Object[1];
                                        try {
                                            objArr[0] = Float.valueOf(constraintAttribute.mFloatValue);
                                            method.invoke(childAt, objArr);
                                            constraintLayout2 = constraintLayout;
                                            hashMap2 = hashMap3;
                                            childCount = i;
                                        } catch (NoSuchMethodException e5) {
                                            e = e5;
                                            Log.e(str3, e.getMessage());
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append(str2);
                                            stringBuilder.append(str42);
                                            stringBuilder.append(str);
                                            stringBuilder.append(cls.getName());
                                            Log.e(str3, stringBuilder.toString());
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append(cls.getName());
                                            stringBuilder.append(" must have a method ");
                                            stringBuilder.append(str7);
                                            Log.e(str3, stringBuilder.toString());
                                            constraintLayout2 = constraintLayout;
                                            hashMap2 = hashMap3;
                                            childCount = i;
                                        } catch (IllegalAccessException e6) {
                                            e2 = e6;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(str2);
                                            stringBuilder2.append(str42);
                                            stringBuilder2.append(str);
                                            stringBuilder2.append(cls.getName());
                                            Log.e(str3, stringBuilder2.toString());
                                            e2.printStackTrace();
                                            constraintLayout2 = constraintLayout;
                                            hashMap2 = hashMap3;
                                            childCount = i;
                                        } catch (InvocationTargetException e7) {
                                            e3 = e7;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(str2);
                                            stringBuilder2.append(str42);
                                            stringBuilder2.append(str);
                                            stringBuilder2.append(cls.getName());
                                            Log.e(str3, stringBuilder2.toString());
                                            e3.printStackTrace();
                                            constraintLayout2 = constraintLayout;
                                            hashMap2 = hashMap3;
                                            childCount = i;
                                        }
                                    case 7:
                                        i = childCount;
                                        try {
                                            cls.getMethod(str7, new Class[]{Integer.TYPE}).invoke(childAt, new Object[]{Integer.valueOf(constraintAttribute.mIntegerValue)});
                                            constraintLayout2 = constraintLayout;
                                            hashMap2 = hashMap3;
                                            childCount = i;
                                        } catch (NoSuchMethodException e8) {
                                            e = e8;
                                            Log.e(str3, e.getMessage());
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append(str2);
                                            stringBuilder.append(str42);
                                            stringBuilder.append(str);
                                            stringBuilder.append(cls.getName());
                                            Log.e(str3, stringBuilder.toString());
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append(cls.getName());
                                            stringBuilder.append(" must have a method ");
                                            stringBuilder.append(str7);
                                            Log.e(str3, stringBuilder.toString());
                                            constraintLayout2 = constraintLayout;
                                            hashMap2 = hashMap3;
                                            childCount = i;
                                        } catch (IllegalAccessException e9) {
                                            e2 = e9;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(str2);
                                            stringBuilder2.append(str42);
                                            stringBuilder2.append(str);
                                            stringBuilder2.append(cls.getName());
                                            Log.e(str3, stringBuilder2.toString());
                                            e2.printStackTrace();
                                            constraintLayout2 = constraintLayout;
                                            hashMap2 = hashMap3;
                                            childCount = i;
                                        } catch (InvocationTargetException e10) {
                                            e3 = e10;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(str2);
                                            stringBuilder2.append(str42);
                                            stringBuilder2.append(str);
                                            stringBuilder2.append(cls.getName());
                                            Log.e(str3, stringBuilder2.toString());
                                            e3.printStackTrace();
                                            constraintLayout2 = constraintLayout;
                                            hashMap2 = hashMap3;
                                            childCount = i;
                                        }
                                    default:
                                        constraintLayout2 = constraintLayout;
                                        hashMap2 = hashMap3;
                                        childCount = childCount;
                                        break;
                                }
                            }
                            i = childCount;
                            throw null;
                        } catch (NoSuchMethodException e11) {
                            e = e11;
                            i = childCount;
                            Log.e(str3, e.getMessage());
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str2);
                            stringBuilder.append(str42);
                            stringBuilder.append(str);
                            stringBuilder.append(cls.getName());
                            Log.e(str3, stringBuilder.toString());
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(cls.getName());
                            stringBuilder.append(" must have a method ");
                            stringBuilder.append(str7);
                            Log.e(str3, stringBuilder.toString());
                            constraintLayout2 = constraintLayout;
                            hashMap2 = hashMap3;
                            childCount = i;
                        } catch (IllegalAccessException e12) {
                            e2 = e12;
                            i = childCount;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str2);
                            stringBuilder2.append(str42);
                            stringBuilder2.append(str);
                            stringBuilder2.append(cls.getName());
                            Log.e(str3, stringBuilder2.toString());
                            e2.printStackTrace();
                            constraintLayout2 = constraintLayout;
                            hashMap2 = hashMap3;
                            childCount = i;
                        } catch (InvocationTargetException e13) {
                            e3 = e13;
                            i = childCount;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str2);
                            stringBuilder2.append(str42);
                            stringBuilder2.append(str);
                            stringBuilder2.append(cls.getName());
                            Log.e(str3, stringBuilder2.toString());
                            e3.printStackTrace();
                            constraintLayout2 = constraintLayout;
                            hashMap2 = hashMap3;
                            childCount = i;
                        }
                    }
                    i = childCount;
                    childAt.setLayoutParams(layoutParams);
                    PropertySet propertySet = constraint.propertySet;
                    if (propertySet.mVisibilityMode == 0) {
                        childAt.setVisibility(propertySet.visibility);
                    }
                    childAt.setAlpha(constraint.propertySet.alpha);
                    childAt.setRotation(constraint.transform.rotation);
                    childAt.setRotationX(constraint.transform.rotationX);
                    childAt.setRotationY(constraint.transform.rotationY);
                    childAt.setScaleX(constraint.transform.scaleX);
                    childAt.setScaleY(constraint.transform.scaleY);
                    Transform transform = constraint.transform;
                    if (transform.transformPivotTarget != -1) {
                        findViewById = ((View) childAt.getParent()).findViewById(constraint.transform.transformPivotTarget);
                        if (findViewById != null) {
                            float top = ((float) (findViewById.getTop() + findViewById.getBottom())) / 2.0f;
                            float left = ((float) (findViewById.getLeft() + findViewById.getRight())) / 2.0f;
                            if (childAt.getRight() - childAt.getLeft() > 0 && childAt.getBottom() - childAt.getTop() > 0) {
                                int left2 = childAt.getLeft();
                                int top2 = childAt.getTop();
                                childAt.setPivotX(left - ((float) left2));
                                childAt.setPivotY(top - ((float) top2));
                            }
                        }
                    } else {
                        if (!Float.isNaN(transform.transformPivotX)) {
                            childAt.setPivotX(constraint.transform.transformPivotX);
                        }
                        if (!Float.isNaN(constraint.transform.transformPivotY)) {
                            childAt.setPivotY(constraint.transform.transformPivotY);
                        }
                    }
                    childAt.setTranslationX(constraint.transform.translationX);
                    childAt.setTranslationY(constraint.transform.translationY);
                    childAt.setTranslationZ(constraint.transform.translationZ);
                    transform = constraint.transform;
                    if (transform.applyElevation) {
                        childAt.setElevation(transform.elevation);
                    }
                } else {
                    i = childCount;
                }
            } else {
                i = childCount;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("WARNING NO CONSTRAINTS for view ");
                stringBuilder2.append(id);
                Log.v(str5, stringBuilder2.toString());
            }
            i2++;
            viewGroup2 = constraintLayout;
            childCount = i;
        }
        i = childCount;
        childCount = 0;
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            Integer num = (Integer) it.next();
            Constraint constraint2 = (Constraint) r1.mConstraints.get(num);
            if (constraint2 != null) {
                View barrier2;
                if (constraint2.layout.mHelperType == 1) {
                    barrier2 = new Barrier(constraintLayout.getContext());
                    barrier2.setId(num.intValue());
                    Layout layout2 = constraint2.layout;
                    int[] iArr2 = layout2.mReferenceIds;
                    if (iArr2 != null) {
                        barrier2.setReferencedIds(iArr2);
                    } else {
                        str42 = layout2.mReferenceIdString;
                        if (str42 != null) {
                            layout2.mReferenceIds = convertReferenceString$ar$ds(barrier2, str42);
                            barrier2.setReferencedIds(constraint2.layout.mReferenceIds);
                        }
                    }
                    layout2 = constraint2.layout;
                    barrier2.mIndicatedType = layout2.mBarrierDirection;
                    barrier2.setMargin(layout2.mBarrierMargin);
                    ViewGroup.LayoutParams generateDefaultLayoutParams$ar$ds$c9cc45ef_0 = ConstraintLayout.generateDefaultLayoutParams$ar$ds$c9cc45ef_0();
                    barrier2.validateParams();
                    constraint2.applyTo(generateDefaultLayoutParams$ar$ds$c9cc45ef_0);
                    viewGroup = constraintLayout;
                    viewGroup.addView(barrier2, generateDefaultLayoutParams$ar$ds$c9cc45ef_0);
                } else {
                    viewGroup = constraintLayout;
                }
                if (constraint2.layout.mIsGuideline) {
                    barrier2 = new Guideline(constraintLayout.getContext());
                    barrier2.setId(num.intValue());
                    ViewGroup.LayoutParams generateDefaultLayoutParams$ar$ds$c9cc45ef_02 = ConstraintLayout.generateDefaultLayoutParams$ar$ds$c9cc45ef_0();
                    constraint2.applyTo(generateDefaultLayoutParams$ar$ds$c9cc45ef_02);
                    viewGroup.addView(barrier2, generateDefaultLayoutParams$ar$ds$c9cc45ef_02);
                }
            } else {
                ConstraintLayout constraintLayout3 = constraintLayout;
            }
        }
        viewGroup = constraintLayout;
        while (true) {
            int i4 = i;
            if (childCount < i4) {
                findViewById = viewGroup.getChildAt(childCount);
                if (findViewById instanceof ConstraintHelper) {
                    ConstraintHelper constraintHelper = (ConstraintHelper) findViewById;
                }
                childCount++;
                i = i4;
            } else {
                return;
            }
        }
    }

    public final void clear(int i, int i2) {
        HashMap hashMap = this.mConstraints;
        Integer valueOf = Integer.valueOf(i);
        if (hashMap.containsKey(valueOf)) {
            Constraint constraint = (Constraint) this.mConstraints.get(valueOf);
            if (constraint != null) {
                Layout layout = constraint.layout;
                switch (i2) {
                    case 3:
                        layout.topToBottom = -1;
                        layout.topToTop = -1;
                        layout.topMargin = 0;
                        layout.goneTopMargin = LinearLayoutManager.INVALID_OFFSET;
                        break;
                    case 4:
                        layout.bottomToTop = -1;
                        layout.bottomToBottom = -1;
                        layout.bottomMargin = 0;
                        layout.goneBottomMargin = LinearLayoutManager.INVALID_OFFSET;
                        return;
                    case 5:
                        layout.baselineToBaseline = -1;
                        layout.baselineToTop = -1;
                        layout.baselineToBottom = -1;
                        layout.baselineMargin = 0;
                        layout.goneBaselineMargin = LinearLayoutManager.INVALID_OFFSET;
                        return;
                    case 6:
                        layout.startToEnd = -1;
                        layout.startToStart = -1;
                        layout.startMargin = 0;
                        layout.goneStartMargin = LinearLayoutManager.INVALID_OFFSET;
                        return;
                    default:
                        layout.endToStart = -1;
                        layout.endToEnd = -1;
                        layout.endMargin = 0;
                        layout.goneEndMargin = LinearLayoutManager.INVALID_OFFSET;
                        return;
                }
            }
        }
    }

    public final void clone(Context context, int i) {
        clone((ConstraintLayout) LayoutInflater.from(context).inflate(i, null));
    }

    public final void connect(int i, int i2, int i3, int i4) {
        HashMap hashMap = this.mConstraints;
        Integer valueOf = Integer.valueOf(i);
        if (!hashMap.containsKey(valueOf)) {
            this.mConstraints.put(valueOf, new Constraint());
        }
        Constraint constraint = (Constraint) this.mConstraints.get(valueOf);
        if (constraint != null) {
            String str = " undefined";
            String str2 = "right to ";
            Layout layout;
            StringBuilder stringBuilder;
            switch (i2) {
                case 3:
                    if (i4 == 3) {
                        layout = constraint.layout;
                        layout.topToTop = i3;
                        layout.topToBottom = -1;
                        layout.baselineToBaseline = -1;
                        layout.baselineToTop = -1;
                        layout.baselineToBottom = -1;
                        return;
                    } else if (i4 == 4) {
                        layout = constraint.layout;
                        layout.topToBottom = i3;
                        layout.topToTop = -1;
                        layout.baselineToBaseline = -1;
                        layout.baselineToTop = -1;
                        layout.baselineToBottom = -1;
                        return;
                    } else {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str2);
                        stringBuilder.append(sideToString$ar$ds(i4));
                        stringBuilder.append(str);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                case 4:
                    if (i4 == 4) {
                        layout = constraint.layout;
                        layout.bottomToBottom = i3;
                        layout.bottomToTop = -1;
                        layout.baselineToBaseline = -1;
                        layout.baselineToTop = -1;
                        layout.baselineToBottom = -1;
                        return;
                    } else if (i4 == 3) {
                        layout = constraint.layout;
                        layout.bottomToTop = i3;
                        layout.bottomToBottom = -1;
                        layout.baselineToBaseline = -1;
                        layout.baselineToTop = -1;
                        layout.baselineToBottom = -1;
                        return;
                    } else {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str2);
                        stringBuilder.append(sideToString$ar$ds(i4));
                        stringBuilder.append(str);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                case 5:
                    if (i4 == 5) {
                        layout = constraint.layout;
                        layout.baselineToBaseline = i3;
                        layout.bottomToBottom = -1;
                        layout.bottomToTop = -1;
                        layout.topToTop = -1;
                        layout.topToBottom = -1;
                        return;
                    } else if (i4 == 3) {
                        layout = constraint.layout;
                        layout.baselineToTop = i3;
                        layout.bottomToBottom = -1;
                        layout.bottomToTop = -1;
                        layout.topToTop = -1;
                        layout.topToBottom = -1;
                        return;
                    } else if (i4 == 4) {
                        layout = constraint.layout;
                        layout.baselineToBottom = i3;
                        layout.bottomToBottom = -1;
                        layout.bottomToTop = -1;
                        layout.topToTop = -1;
                        layout.topToBottom = -1;
                        return;
                    } else {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str2);
                        stringBuilder.append(sideToString$ar$ds(i4));
                        stringBuilder.append(str);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                case 6:
                    if (i4 == 6) {
                        layout = constraint.layout;
                        layout.startToStart = i3;
                        layout.startToEnd = -1;
                        return;
                    }
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str2);
                    stringBuilder.append(sideToString$ar$ds(i4));
                    stringBuilder.append(str);
                    throw new IllegalArgumentException(stringBuilder.toString());
                default:
                    if (i4 == 6) {
                        layout = constraint.layout;
                        layout.endToStart = i3;
                        layout.endToEnd = -1;
                        return;
                    }
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str2);
                    stringBuilder.append(sideToString$ar$ds(i4));
                    stringBuilder.append(str);
                    throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
    }

    public final void connect$ar$ds$6c4e784_0(int i, int i2, int i3, int i4) {
        HashMap hashMap = this.mConstraints;
        Integer valueOf = Integer.valueOf(i);
        if (!hashMap.containsKey(valueOf)) {
            this.mConstraints.put(valueOf, new Constraint());
        }
        Constraint constraint = (Constraint) this.mConstraints.get(valueOf);
        if (constraint != null) {
            Layout layout;
            switch (i2) {
                case 3:
                    if (i4 == 3) {
                        layout = constraint.layout;
                        layout.topToTop = i3;
                        layout.topToBottom = -1;
                    } else {
                        layout = constraint.layout;
                        layout.topToBottom = i3;
                        layout.topToTop = -1;
                    }
                    layout.baselineToBaseline = -1;
                    layout.baselineToTop = -1;
                    layout.baselineToBottom = -1;
                    constraint.layout.topMargin = 0;
                    return;
                default:
                    if (i4 == 4) {
                        layout = constraint.layout;
                        layout.bottomToBottom = i3;
                        layout.bottomToTop = -1;
                    } else {
                        layout = constraint.layout;
                        layout.bottomToTop = i3;
                        layout.bottomToBottom = -1;
                    }
                    layout.baselineToBaseline = -1;
                    layout.baselineToTop = -1;
                    layout.baselineToBottom = -1;
                    constraint.layout.bottomMargin = 0;
                    return;
            }
        }
    }

    public final Constraint get(int i) {
        HashMap hashMap = this.mConstraints;
        Integer valueOf = Integer.valueOf(i);
        if (!hashMap.containsKey(valueOf)) {
            this.mConstraints.put(valueOf, new Constraint());
        }
        return (Constraint) this.mConstraints.get(valueOf);
    }

    public final void load(Context context, int i) {
        XmlPullParser xml = context.getResources().getXml(i);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                switch (eventType) {
                    case 0:
                        xml.getName();
                        break;
                    case 2:
                        String name = xml.getName();
                        Constraint fillFromAttributeList$ar$ds = fillFromAttributeList$ar$ds(context, Xml.asAttributeSet(xml), false);
                        if (name.equalsIgnoreCase("Guideline")) {
                            fillFromAttributeList$ar$ds.layout.mIsGuideline = true;
                        }
                        this.mConstraints.put(Integer.valueOf(fillFromAttributeList$ar$ds.mViewId), fillFromAttributeList$ar$ds);
                        break;
                    default:
                        break;
                }
            }
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public final void removeFromVerticalChain(int i) {
        HashMap hashMap = this.mConstraints;
        Integer valueOf = Integer.valueOf(i);
        if (hashMap.containsKey(valueOf)) {
            Constraint constraint = (Constraint) this.mConstraints.get(valueOf);
            if (constraint != null) {
                Layout layout = constraint.layout;
                int i2 = layout.topToBottom;
                int i3 = layout.bottomToTop;
                if (i2 == -1) {
                    if (i3 != -1) {
                        i2 = -1;
                    }
                }
                if (i2 == -1 || i3 == -1) {
                    int i4 = layout.bottomToBottom;
                    if (i4 != -1) {
                        connect$ar$ds$6c4e784_0(i2, 4, i4, 4);
                    } else {
                        int i5 = layout.topToTop;
                        if (i5 != -1) {
                            connect$ar$ds$6c4e784_0(i3, 3, i5, 3);
                        }
                    }
                } else {
                    connect$ar$ds$6c4e784_0(i2, 4, i3, 3);
                    connect$ar$ds$6c4e784_0(i3, 3, i2, 4);
                }
            } else {
                return;
            }
        }
        clear(i, 3);
        clear(i, 4);
    }

    public final void setGuidelineBegin(int i, int i2) {
        get(i).layout.guideBegin = i2;
        get(i).layout.guideEnd = -1;
        get(i).layout.guidePercent = -1.0f;
    }

    public final void setGuidelineEnd(int i, int i2) {
        get(i).layout.guideEnd = i2;
        get(i).layout.guideBegin = -1;
        get(i).layout.guidePercent = -1.0f;
    }

    public final void setHorizontalChainStyle(int i, int i2) {
        get(i).layout.horizontalChainStyle = i2;
    }

    public final void clone(ConstraintLayout constraintLayout) {
        NoSuchMethodException e;
        IllegalAccessException e2;
        InvocationTargetException e3;
        int childCount = constraintLayout.getChildCount();
        this.mConstraints.clear();
        int i = 0;
        while (i < childCount) {
            View childAt = constraintLayout.getChildAt(i);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (id != -1) {
                ConstraintSet constraintSet;
                HashMap hashMap = constraintSet.mConstraints;
                Integer valueOf = Integer.valueOf(id);
                if (!hashMap.containsKey(valueOf)) {
                    constraintSet.mConstraints.put(valueOf, new Constraint());
                }
                Constraint constraint = (Constraint) constraintSet.mConstraints.get(valueOf);
                if (constraint != null) {
                    HashMap hashMap2 = constraintSet.mSavedAttributes;
                    HashMap hashMap3 = new HashMap();
                    Class cls = childAt.getClass();
                    for (String str : hashMap2.keySet()) {
                        ConstraintAttribute constraintAttribute = (ConstraintAttribute) hashMap2.get(str);
                        try {
                            if (str.equals("BackgroundColor")) {
                                hashMap3.put(str, new ConstraintAttribute(constraintAttribute, Integer.valueOf(((ColorDrawable) childAt.getBackground()).getColor())));
                            } else {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("getMap");
                                stringBuilder.append(str);
                                try {
                                    hashMap3.put(str, new ConstraintAttribute(constraintAttribute, cls.getMethod(stringBuilder.toString(), new Class[0]).invoke(childAt, new Object[0])));
                                    constraintSet = this;
                                } catch (NoSuchMethodException e4) {
                                    e = e4;
                                    e.printStackTrace();
                                    constraintSet = this;
                                } catch (IllegalAccessException e5) {
                                    e2 = e5;
                                    e2.printStackTrace();
                                    constraintSet = this;
                                } catch (InvocationTargetException e6) {
                                    e3 = e6;
                                    e3.printStackTrace();
                                    constraintSet = this;
                                }
                            }
                        } catch (NoSuchMethodException e7) {
                            e = e7;
                            e.printStackTrace();
                            constraintSet = this;
                        } catch (IllegalAccessException e8) {
                            e2 = e8;
                            e2.printStackTrace();
                            constraintSet = this;
                        } catch (InvocationTargetException e9) {
                            e3 = e9;
                            e3.printStackTrace();
                            constraintSet = this;
                        }
                    }
                    constraint.mCustomConstraints = hashMap3;
                    constraint.mViewId = id;
                    Layout layout = constraint.layout;
                    layout.leftToLeft = layoutParams.leftToLeft;
                    layout.leftToRight = layoutParams.leftToRight;
                    layout.rightToLeft = layoutParams.rightToLeft;
                    layout.rightToRight = layoutParams.rightToRight;
                    layout.topToTop = layoutParams.topToTop;
                    layout.topToBottom = layoutParams.topToBottom;
                    layout.bottomToTop = layoutParams.bottomToTop;
                    layout.bottomToBottom = layoutParams.bottomToBottom;
                    layout.baselineToBaseline = layoutParams.baselineToBaseline;
                    layout.baselineToTop = layoutParams.baselineToTop;
                    layout.baselineToBottom = layoutParams.baselineToBottom;
                    layout.startToEnd = layoutParams.startToEnd;
                    layout.startToStart = layoutParams.startToStart;
                    layout.endToStart = layoutParams.endToStart;
                    layout.endToEnd = layoutParams.endToEnd;
                    layout.horizontalBias = layoutParams.horizontalBias;
                    layout.verticalBias = layoutParams.verticalBias;
                    layout.dimensionRatio = layoutParams.dimensionRatio;
                    layout.circleConstraint = layoutParams.circleConstraint;
                    layout.circleRadius = layoutParams.circleRadius;
                    layout.circleAngle = layoutParams.circleAngle;
                    layout.editorAbsoluteX = layoutParams.editorAbsoluteX;
                    layout.editorAbsoluteY = layoutParams.editorAbsoluteY;
                    layout.orientation = layoutParams.orientation;
                    layout.guidePercent = layoutParams.guidePercent;
                    layout.guideBegin = layoutParams.guideBegin;
                    layout.guideEnd = layoutParams.guideEnd;
                    layout.mWidth = layoutParams.width;
                    constraint.layout.mHeight = layoutParams.height;
                    constraint.layout.leftMargin = layoutParams.leftMargin;
                    constraint.layout.rightMargin = layoutParams.rightMargin;
                    constraint.layout.topMargin = layoutParams.topMargin;
                    constraint.layout.bottomMargin = layoutParams.bottomMargin;
                    layout = constraint.layout;
                    layout.baselineMargin = layoutParams.baselineMargin;
                    layout.verticalWeight = layoutParams.verticalWeight;
                    layout.horizontalWeight = layoutParams.horizontalWeight;
                    layout.verticalChainStyle = layoutParams.verticalChainStyle;
                    layout.horizontalChainStyle = layoutParams.horizontalChainStyle;
                    layout.constrainedWidth = layoutParams.constrainedWidth;
                    layout.constrainedHeight = layoutParams.constrainedHeight;
                    layout.widthDefault = layoutParams.matchConstraintDefaultWidth;
                    layout.heightDefault = layoutParams.matchConstraintDefaultHeight;
                    layout.widthMax = layoutParams.matchConstraintMaxWidth;
                    layout.heightMax = layoutParams.matchConstraintMaxHeight;
                    layout.widthMin = layoutParams.matchConstraintMinWidth;
                    layout.heightMin = layoutParams.matchConstraintMinHeight;
                    layout.widthPercent = layoutParams.matchConstraintPercentWidth;
                    layout.heightPercent = layoutParams.matchConstraintPercentHeight;
                    layout.mConstraintTag = layoutParams.constraintTag;
                    layout.goneTopMargin = layoutParams.goneTopMargin;
                    layout.goneBottomMargin = layoutParams.goneBottomMargin;
                    layout.goneLeftMargin = layoutParams.goneLeftMargin;
                    layout.goneRightMargin = layoutParams.goneRightMargin;
                    layout.goneStartMargin = layoutParams.goneStartMargin;
                    layout.goneEndMargin = layoutParams.goneEndMargin;
                    layout.goneBaselineMargin = layoutParams.goneBaselineMargin;
                    layout.mWrapBehavior = layoutParams.wrapBehaviorInParent;
                    layout.endMargin = layoutParams.getMarginEnd();
                    constraint.layout.startMargin = layoutParams.getMarginStart();
                    constraint.propertySet.visibility = childAt.getVisibility();
                    constraint.propertySet.alpha = childAt.getAlpha();
                    constraint.transform.rotation = childAt.getRotation();
                    constraint.transform.rotationX = childAt.getRotationX();
                    constraint.transform.rotationY = childAt.getRotationY();
                    constraint.transform.scaleX = childAt.getScaleX();
                    constraint.transform.scaleY = childAt.getScaleY();
                    float pivotX = childAt.getPivotX();
                    float pivotY = childAt.getPivotY();
                    if (!(((double) pivotX) == 0.0d && ((double) pivotY) == 0.0d)) {
                        Transform transform = constraint.transform;
                        transform.transformPivotX = pivotX;
                        transform.transformPivotY = pivotY;
                    }
                    constraint.transform.translationX = childAt.getTranslationX();
                    constraint.transform.translationY = childAt.getTranslationY();
                    constraint.transform.translationZ = childAt.getTranslationZ();
                    Transform transform2 = constraint.transform;
                    if (transform2.applyElevation) {
                        transform2.elevation = childAt.getElevation();
                    }
                    if (childAt instanceof Barrier) {
                        Barrier barrier = (Barrier) childAt;
                        layout = constraint.layout;
                        layout.mBarrierAllowsGoneWidgets = barrier.mBarrier.mAllowsGoneWidget;
                        layout.mReferenceIds = Arrays.copyOf(barrier.mIds, barrier.mCount);
                        layout = constraint.layout;
                        layout.mBarrierDirection = barrier.mIndicatedType;
                        layout.mBarrierMargin = barrier.mBarrier.mMargin;
                    }
                }
                i++;
                constraintSet = this;
            } else {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void load(android.content.Context r21, org.xmlpull.v1.XmlPullParser r22) {
        /*
        r20 = this;
        r1 = r21;
        r2 = r22.getEventType();	 Catch:{ XmlPullParserException -> 0x07a6, IOException -> 0x079e }
        r4 = 0;
    L_0x0007:
        r5 = 1;
        if (r2 == r5) goto L_0x079b;
    L_0x000a:
        r6 = 2;
        r7 = 3;
        r9 = 0;
        switch(r2) {
            case 0: goto L_0x078b;
            case 1: goto L_0x0010;
            case 2: goto L_0x0069;
            case 3: goto L_0x0014;
            default: goto L_0x0010;
        };	 Catch:{ XmlPullParserException -> 0x07a6, IOException -> 0x079e }
    L_0x0010:
        r2 = r20;
        goto L_0x0790;
    L_0x0014:
        r2 = r22.getName();	 Catch:{ XmlPullParserException -> 0x07a6, IOException -> 0x079e }
        r10 = java.util.Locale.ROOT;	 Catch:{ XmlPullParserException -> 0x07a6, IOException -> 0x079e }
        r2 = r2.toLowerCase(r10);	 Catch:{ XmlPullParserException -> 0x07a6, IOException -> 0x079e }
        r10 = r2.hashCode();	 Catch:{ XmlPullParserException -> 0x07a6, IOException -> 0x079e }
        switch(r10) {
            case -2075718416: goto L_0x0044;
            case -190376483: goto L_0x003b;
            case 426575017: goto L_0x0031;
            case 2146106725: goto L_0x0026;
            default: goto L_0x0025;
        };
    L_0x0025:
        goto L_0x004e;
        r5 = "constraintset";
        r2 = r2.equals(r5);
        if (r2 == 0) goto L_0x0025;
    L_0x002f:
        r5 = 0;
        goto L_0x004f;
    L_0x0031:
        r5 = "constraintoverride";
        r2 = r2.equals(r5);
        if (r2 == 0) goto L_0x0025;
    L_0x0039:
        r5 = 2;
        goto L_0x004f;
    L_0x003b:
        r6 = "constraint";
        r2 = r2.equals(r6);
        if (r2 == 0) goto L_0x0025;
    L_0x0043:
        goto L_0x004f;
    L_0x0044:
        r5 = "guideline";
        r2 = r2.equals(r5);
        if (r2 == 0) goto L_0x0025;
    L_0x004c:
        r5 = 3;
        goto L_0x004f;
    L_0x004e:
        r5 = -1;
    L_0x004f:
        switch(r5) {
            case 0: goto L_0x0066;
            case 1: goto L_0x0056;
            case 2: goto L_0x0056;
            case 3: goto L_0x0056;
            default: goto L_0x0052;
        };
    L_0x0052:
        r2 = r20;
        goto L_0x0790;
    L_0x0056:
        r2 = r20;
        r5 = r2.mConstraints;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = r4.mViewId;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = java.lang.Integer.valueOf(r6);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r5.put(r6, r4);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = 0;
        goto L_0x0790;
    L_0x0066:
        r2 = r20;
        return;
    L_0x0069:
        r2 = r20;
        r10 = r22.getName();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r10.hashCode();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 7;
        switch(r11) {
            case -2025855158: goto L_0x00d6;
            case -1984451626: goto L_0x00cc;
            case -1962203927: goto L_0x00c2;
            case -1269513683: goto L_0x00b8;
            case -1238332596: goto L_0x00ae;
            case -71750448: goto L_0x00a4;
            case 366511058: goto L_0x0099;
            case 1331510167: goto L_0x008f;
            case 1791837707: goto L_0x0084;
            case 1803088381: goto L_0x0079;
            default: goto L_0x0077;
        };
    L_0x0077:
        goto L_0x00e0;
        r11 = "Constraint";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x0082:
        r10 = 0;
        goto L_0x00e1;
    L_0x0084:
        r11 = "CustomAttribute";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x008c:
        r10 = 8;
        goto L_0x00e1;
    L_0x008f:
        r11 = "Barrier";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x0097:
        r10 = 3;
        goto L_0x00e1;
    L_0x0099:
        r11 = "CustomMethod";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x00a1:
        r10 = 9;
        goto L_0x00e1;
    L_0x00a4:
        r11 = "Guideline";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x00ac:
        r10 = 2;
        goto L_0x00e1;
    L_0x00ae:
        r11 = "Transform";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x00b6:
        r10 = 5;
        goto L_0x00e1;
    L_0x00b8:
        r11 = "PropertySet";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x00c0:
        r10 = 4;
        goto L_0x00e1;
    L_0x00c2:
        r11 = "ConstraintOverride";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x00ca:
        r10 = 1;
        goto L_0x00e1;
    L_0x00cc:
        r11 = "Motion";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x00d4:
        r10 = 7;
        goto L_0x00e1;
    L_0x00d6:
        r11 = "Layout";
        r10 = r10.equals(r11);
        if (r10 == 0) goto L_0x0077;
    L_0x00de:
        r10 = 6;
        goto L_0x00e1;
    L_0x00e0:
        r10 = -1;
    L_0x00e1:
        r11 = "XML parser error must be within a Constraint ";
        switch(r10) {
            case 0: goto L_0x0782;
            case 1: goto L_0x0779;
            case 2: goto L_0x076a;
            case 3: goto L_0x075d;
            case 4: goto L_0x06ec;
            case 5: goto L_0x0638;
            case 6: goto L_0x0328;
            case 7: goto L_0x0231;
            case 8: goto L_0x00e8;
            case 9: goto L_0x00e8;
            default: goto L_0x00e6;
        };
    L_0x00e6:
        goto L_0x0790;
    L_0x00e8:
        if (r4 == 0) goto L_0x0218;
    L_0x00ea:
        r10 = r4.mCustomConstraints;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = androidx.constraintlayout.widget.R$styleable.CustomAttribute;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r1.obtainStyledAttributes(r11, r12);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = r11.getIndexCount();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = 0;
        r16 = 0;
        r17 = 0;
        r18 = 0;
        r19 = 0;
    L_0x0103:
        if (r8 >= r12) goto L_0x01ff;
    L_0x0105:
        r14 = r11.getIndex(r8);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r14 != 0) goto L_0x013b;
    L_0x010b:
        r14 = r11.getString(r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r14 == 0) goto L_0x0133;
    L_0x0111:
        r16 = r14.length();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r16 <= 0) goto L_0x0133;
    L_0x0117:
        r13 = new java.lang.StringBuilder;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13.<init>();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r16 = r14.charAt(r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r15 = java.lang.Character.toUpperCase(r16);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13.append(r15);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r14 = r14.substring(r5);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13.append(r14);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r16 = r13.toString();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0135;
    L_0x0133:
        r16 = r14;
    L_0x0135:
        r3 = 8;
        r13 = 5;
        r15 = 6;
        goto L_0x01f9;
    L_0x013b:
        r13 = 10;
        if (r14 != r13) goto L_0x014b;
    L_0x013f:
        r16 = r11.getString(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r13 = 5;
        r15 = 6;
        r19 = 1;
        goto L_0x01f9;
    L_0x014b:
        if (r14 != r5) goto L_0x015d;
    L_0x014d:
        r13 = r11.getBoolean(r5, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r17 = java.lang.Boolean.valueOf(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r13 = 5;
        r15 = 6;
        r18 = 6;
        goto L_0x01f9;
    L_0x015d:
        if (r14 != r7) goto L_0x016f;
    L_0x015f:
        r13 = r11.getColor(r7, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r17 = java.lang.Integer.valueOf(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r13 = 5;
        r15 = 6;
        r18 = 3;
        goto L_0x01f9;
    L_0x016f:
        if (r14 != r6) goto L_0x0181;
    L_0x0171:
        r13 = r11.getColor(r6, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r17 = java.lang.Integer.valueOf(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r13 = 5;
        r15 = 6;
        r18 = 4;
        goto L_0x01f9;
    L_0x0181:
        r13 = 0;
        if (r14 != r3) goto L_0x019f;
    L_0x0184:
        r13 = r11.getDimension(r3, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r14 = r21.getResources();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r14 = r14.getDisplayMetrics();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13 = android.util.TypedValue.applyDimension(r5, r13, r14);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r17 = java.lang.Float.valueOf(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r13 = 5;
        r15 = 6;
        r18 = 7;
        goto L_0x01f9;
    L_0x019f:
        r15 = 4;
        if (r14 != r15) goto L_0x01b1;
    L_0x01a2:
        r13 = r11.getDimension(r15, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r17 = java.lang.Float.valueOf(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r13 = 5;
        r15 = 6;
        r18 = 7;
        goto L_0x01f9;
    L_0x01b1:
        r13 = 5;
        if (r14 != r13) goto L_0x01c4;
    L_0x01b4:
        r14 = 2143289344; // 0x7fc00000 float:NaN double:1.058925634E-314;
        r14 = r11.getFloat(r13, r14);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r17 = java.lang.Float.valueOf(r14);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r15 = 6;
        r18 = 2;
        goto L_0x01f9;
    L_0x01c4:
        r15 = 6;
        if (r14 != r15) goto L_0x01d5;
    L_0x01c7:
        r14 = -1;
        r17 = r11.getInteger(r15, r14);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r17 = java.lang.Integer.valueOf(r17);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r18 = 1;
        goto L_0x01f9;
    L_0x01d5:
        r3 = 9;
        if (r14 != r3) goto L_0x01e2;
    L_0x01d9:
        r17 = r11.getString(r3);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = 8;
        r18 = 5;
        goto L_0x01f9;
    L_0x01e2:
        r3 = 8;
        if (r14 != r3) goto L_0x01f8;
    L_0x01e6:
        r14 = -1;
        r6 = r11.getResourceId(r3, r14);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r6 != r14) goto L_0x01f1;
    L_0x01ed:
        r6 = r11.getInt(r3, r14);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x01f1:
        r17 = java.lang.Integer.valueOf(r6);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r18 = 8;
        goto L_0x01f9;
    L_0x01f9:
        r8 = r8 + 1;
        r3 = 7;
        r6 = 2;
        goto L_0x0103;
    L_0x01ff:
        r3 = r16;
        if (r3 == 0) goto L_0x0213;
    L_0x0203:
        r5 = r17;
        if (r5 == 0) goto L_0x0213;
    L_0x0207:
        r6 = new androidx.constraintlayout.widget.ConstraintAttribute;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r9 = r18;
        r7 = r19;
        r6.<init>(r3, r9, r5, r7);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10.put(r3, r6);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x0213:
        r11.recycle();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x0218:
        r1 = new java.lang.RuntimeException;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = new java.lang.StringBuilder;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.<init>();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = r22.getLineNumber();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r4);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = r3.toString();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r1.<init>(r3);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        throw r1;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x0231:
        if (r4 == 0) goto L_0x030f;
    L_0x0233:
        r3 = r4.motion;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = androidx.constraintlayout.widget.R$styleable.Motion;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = r1.obtainStyledAttributes(r6, r8);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mApply = r5;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getIndexCount();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = 0;
    L_0x0246:
        if (r10 >= r8) goto L_0x030a;
    L_0x0248:
        r11 = r6.getIndex(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = androidx.constraintlayout.widget.ConstraintSet.Motion.mapToConstant;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = r12.get(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        switch(r12) {
            case 1: goto L_0x02fd;
            case 2: goto L_0x02f3;
            case 3: goto L_0x02d8;
            case 4: goto L_0x02d0;
            case 5: goto L_0x02c6;
            case 6: goto L_0x02bc;
            case 7: goto L_0x02b2;
            case 8: goto L_0x02a8;
            case 9: goto L_0x029e;
            case 10: goto L_0x0258;
            default: goto L_0x0255;
        };	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x0255:
        r12 = -1;
        goto L_0x0306;
    L_0x0258:
        r12 = r6.peekValue(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13 = r12.type;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r14 = -2;
        if (r13 != r5) goto L_0x026f;
    L_0x0261:
        r12 = -1;
        r11 = r6.getResourceId(r11, r12);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mQuantizeInterpolatorID = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r11 == r12) goto L_0x026c;
    L_0x026a:
        r3.mQuantizeInterpolatorType = r14;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x026c:
        r12 = -1;
        goto L_0x0306;
    L_0x026f:
        r12 = r12.type;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r12 != r7) goto L_0x0294;
    L_0x0273:
        r12 = r6.getString(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mQuantizeInterpolatorString = r12;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = r3.mQuantizeInterpolatorString;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13 = "/";
        r12 = r12.indexOf(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r12 <= 0) goto L_0x028f;
    L_0x0283:
        r12 = -1;
        r11 = r6.getResourceId(r11, r12);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mQuantizeInterpolatorID = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mQuantizeInterpolatorType = r14;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = -1;
        goto L_0x0306;
    L_0x028f:
        r12 = -1;
        r3.mQuantizeInterpolatorType = r12;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x0294:
        r12 = -1;
        r13 = r3.mQuantizeInterpolatorID;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getInteger(r11, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mQuantizeInterpolatorType = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x029e:
        r12 = -1;
        r13 = r3.mQuantizeMotionPhase;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getFloat(r11, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mQuantizeMotionPhase = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02a8:
        r12 = -1;
        r13 = r3.mQuantizeMotionSteps;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getInteger(r11, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mQuantizeMotionSteps = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02b2:
        r12 = -1;
        r13 = r3.mMotionStagger;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getFloat(r11, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mMotionStagger = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02bc:
        r12 = -1;
        r13 = r3.mAnimateCircleAngleTo;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getInteger(r11, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mAnimateCircleAngleTo = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02c6:
        r12 = -1;
        r13 = r3.mAnimateRelativeTo;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = lookupID(r6, r11, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mAnimateRelativeTo = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02d0:
        r12 = -1;
        r11 = r6.getInt(r11, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mDrawPath = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02d8:
        r12 = -1;
        r13 = r6.peekValue(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13 = r13.type;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r13 != r7) goto L_0x02e8;
    L_0x02e1:
        r11 = r6.getString(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mTransitionEasing = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02e8:
        r13 = androidx.constraintlayout.core.motion.utils.Easing.NAMED_EASING;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getInteger(r11, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r13[r11];	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mTransitionEasing = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02f3:
        r12 = -1;
        r13 = r3.mPathMotionArc;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getInt(r11, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mPathMotionArc = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0306;
    L_0x02fd:
        r12 = -1;
        r13 = r3.mPathRotate;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getFloat(r11, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mPathRotate = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x0306:
        r10 = r10 + 1;
        goto L_0x0246;
    L_0x030a:
        r6.recycle();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x030f:
        r1 = new java.lang.RuntimeException;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = new java.lang.StringBuilder;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.<init>();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = r22.getLineNumber();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r4);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = r3.toString();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r1.<init>(r3);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        throw r1;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x0328:
        if (r4 == 0) goto L_0x061f;
    L_0x032a:
        r3 = r4.layout;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r7 = androidx.constraintlayout.widget.R$styleable.Layout;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = r1.obtainStyledAttributes(r6, r7);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mApply = r5;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r7 = r6.getIndexCount();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = 0;
    L_0x033d:
        if (r8 >= r7) goto L_0x061a;
    L_0x033f:
        r10 = r6.getIndex(r8);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = androidx.constraintlayout.widget.ConstraintSet.Layout.mapToConstant;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r11.get(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = "   ";
        r13 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r14 = "ConstraintSet";
        switch(r11) {
            case 1: goto L_0x05eb;
            case 2: goto L_0x05e2;
            case 3: goto L_0x05d9;
            case 4: goto L_0x05d0;
            case 5: goto L_0x05c9;
            case 6: goto L_0x05c0;
            case 7: goto L_0x05b7;
            case 8: goto L_0x05ae;
            case 9: goto L_0x05a5;
            case 10: goto L_0x059b;
            case 11: goto L_0x0591;
            case 12: goto L_0x0587;
            case 13: goto L_0x057d;
            case 14: goto L_0x0573;
            case 15: goto L_0x0569;
            case 16: goto L_0x055f;
            case 17: goto L_0x0555;
            case 18: goto L_0x054b;
            case 19: goto L_0x0541;
            case 20: goto L_0x0537;
            case 21: goto L_0x052d;
            case 22: goto L_0x0523;
            case 23: goto L_0x0519;
            case 24: goto L_0x050f;
            case 25: goto L_0x0505;
            case 26: goto L_0x04fb;
            case 27: goto L_0x04f1;
            case 28: goto L_0x04e7;
            case 29: goto L_0x04dd;
            case 30: goto L_0x04d3;
            case 31: goto L_0x04c9;
            case 32: goto L_0x04bf;
            case 33: goto L_0x04b5;
            case 34: goto L_0x04ab;
            case 35: goto L_0x04a1;
            case 36: goto L_0x0497;
            case 37: goto L_0x048d;
            case 38: goto L_0x0483;
            case 39: goto L_0x0479;
            case 40: goto L_0x046f;
            case 41: goto L_0x0469;
            case 42: goto L_0x0463;
            case 43: goto L_0x0352;
            case 44: goto L_0x0352;
            case 45: goto L_0x0352;
            case 46: goto L_0x0352;
            case 47: goto L_0x0352;
            case 48: goto L_0x0352;
            case 49: goto L_0x0352;
            case 50: goto L_0x0352;
            case 51: goto L_0x0352;
            case 52: goto L_0x0352;
            case 53: goto L_0x0352;
            case 54: goto L_0x0459;
            case 55: goto L_0x044f;
            case 56: goto L_0x0445;
            case 57: goto L_0x043b;
            case 58: goto L_0x0431;
            case 59: goto L_0x0427;
            case 60: goto L_0x0352;
            case 61: goto L_0x041d;
            case 62: goto L_0x0413;
            case 63: goto L_0x0409;
            case 64: goto L_0x0352;
            case 65: goto L_0x0352;
            case 66: goto L_0x0352;
            case 67: goto L_0x0352;
            case 68: goto L_0x0352;
            case 69: goto L_0x0400;
            case 70: goto L_0x03f7;
            case 71: goto L_0x03f0;
            case 72: goto L_0x03e6;
            case 73: goto L_0x03dc;
            case 74: goto L_0x03d4;
            case 75: goto L_0x03ca;
            case 76: goto L_0x03a4;
            case 77: goto L_0x039c;
            case 78: goto L_0x0352;
            case 79: goto L_0x0352;
            case 80: goto L_0x0392;
            case 81: goto L_0x0388;
            case 82: goto L_0x0352;
            case 83: goto L_0x0352;
            case 84: goto L_0x0352;
            case 85: goto L_0x0352;
            case 86: goto L_0x0352;
            case 87: goto L_0x0352;
            case 88: goto L_0x0352;
            case 89: goto L_0x0352;
            case 90: goto L_0x0352;
            case 91: goto L_0x037e;
            case 92: goto L_0x0374;
            case 93: goto L_0x036a;
            case 94: goto L_0x0360;
            case 95: goto L_0x0352;
            case 96: goto L_0x0352;
            case 97: goto L_0x0356;
            default: goto L_0x0352;
        };
    L_0x0352:
        r11 = new java.lang.StringBuilder;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x05f4;
    L_0x0356:
        r11 = r3.mWrapBehavior;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getInt(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mWrapBehavior = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0360:
        r11 = r3.goneBaselineMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.goneBaselineMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x036a:
        r11 = r3.baselineMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.baselineMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0374:
        r11 = r3.baselineToBottom;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.baselineToBottom = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x037e:
        r11 = r3.baselineToTop;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.baselineToTop = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0388:
        r11 = r3.constrainedHeight;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getBoolean(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.constrainedHeight = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0392:
        r11 = r3.constrainedWidth;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getBoolean(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.constrainedWidth = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x039c:
        r10 = r6.getString(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mConstraintTag = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x03a4:
        r11 = new java.lang.StringBuilder;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11.<init>();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13 = "unused attribute 0x";
        r11.append(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13 = java.lang.Integer.toHexString(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11.append(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11.append(r12);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = androidx.constraintlayout.widget.ConstraintSet.Layout.mapToConstant;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r12.get(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11.append(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r11.toString();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        android.util.Log.w(r14, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x03ca:
        r11 = r3.mBarrierAllowsGoneWidgets;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getBoolean(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mBarrierAllowsGoneWidgets = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x03d4:
        r10 = r6.getString(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mReferenceIdString = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x03dc:
        r11 = r3.mBarrierMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mBarrierMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x03e6:
        r11 = r3.mBarrierDirection;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getInt(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mBarrierDirection = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x03f0:
        r10 = "CURRENTLY UNSUPPORTED";
        android.util.Log.e(r14, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
        r10 = r6.getFloat(r10, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.heightPercent = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
        r10 = r6.getFloat(r10, r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.widthPercent = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0409:
        r11 = r3.circleAngle;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getFloat(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.circleAngle = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0413:
        r11 = r3.circleRadius;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.circleRadius = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x041d:
        r11 = r3.circleConstraint;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.circleConstraint = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0427:
        r11 = r3.heightMin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.heightMin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0431:
        r11 = r3.widthMin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.widthMin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x043b:
        r11 = r3.heightMax;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.heightMax = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0445:
        r11 = r3.widthMax;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.widthMax = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x044f:
        r11 = r3.heightDefault;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getInt(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.heightDefault = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0459:
        r11 = r3.widthDefault;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getInt(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.widthDefault = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
        parseDimensionConstraints(r3, r6, r10, r5);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
        parseDimensionConstraints(r3, r6, r10, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x046f:
        r11 = r3.verticalChainStyle;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getInt(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.verticalChainStyle = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0479:
        r11 = r3.horizontalChainStyle;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getInt(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.horizontalChainStyle = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0483:
        r11 = r3.verticalWeight;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getFloat(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.verticalWeight = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x048d:
        r11 = r3.horizontalWeight;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getFloat(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.horizontalWeight = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0497:
        r11 = r3.verticalBias;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getFloat(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.verticalBias = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04a1:
        r11 = r3.topToTop;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.topToTop = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04ab:
        r11 = r3.topToBottom;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.topToBottom = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04b5:
        r11 = r3.topMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.topMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04bf:
        r11 = r3.startToStart;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.startToStart = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04c9:
        r11 = r3.startToEnd;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.startToEnd = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04d3:
        r11 = r3.startMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.startMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04dd:
        r11 = r3.rightToRight;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.rightToRight = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04e7:
        r11 = r3.rightToLeft;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.rightToLeft = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04f1:
        r11 = r3.rightMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.rightMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x04fb:
        r11 = r3.orientation;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getInt(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.orientation = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0505:
        r11 = r3.leftToRight;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.leftToRight = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x050f:
        r11 = r3.leftToLeft;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.leftToLeft = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0519:
        r11 = r3.leftMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.leftMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0523:
        r11 = r3.mWidth;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getLayoutDimension(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mWidth = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x052d:
        r11 = r3.mHeight;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getLayoutDimension(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mHeight = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0537:
        r11 = r3.horizontalBias;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getFloat(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.horizontalBias = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0541:
        r11 = r3.guidePercent;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getFloat(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.guidePercent = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x054b:
        r11 = r3.guideEnd;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelOffset(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.guideEnd = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0555:
        r11 = r3.guideBegin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelOffset(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.guideBegin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x055f:
        r11 = r3.goneTopMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.goneTopMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0569:
        r11 = r3.goneStartMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.goneStartMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0573:
        r11 = r3.goneRightMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.goneRightMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x057d:
        r11 = r3.goneLeftMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.goneLeftMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0587:
        r11 = r3.goneEndMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.goneEndMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x0591:
        r11 = r3.goneBottomMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.goneBottomMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x059b:
        r11 = r3.endToStart;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.endToStart = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05a5:
        r11 = r3.endToEnd;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.endToEnd = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05ae:
        r11 = r3.endMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.endMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05b7:
        r11 = r3.editorAbsoluteY;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelOffset(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.editorAbsoluteY = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05c0:
        r11 = r3.editorAbsoluteX;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelOffset(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.editorAbsoluteX = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05c9:
        r10 = r6.getString(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.dimensionRatio = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05d0:
        r11 = r3.bottomToTop;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.bottomToTop = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05d9:
        r11 = r3.bottomToBottom;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.bottomToBottom = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05e2:
        r11 = r3.bottomMargin;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r6.getDimensionPixelSize(r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.bottomMargin = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05eb:
        r11 = r3.baselineToBaseline;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = lookupID(r6, r10, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.baselineToBaseline = r10;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0616;
    L_0x05f4:
        r11.<init>();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13 = "Unknown attribute 0x";
        r11.append(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r13 = java.lang.Integer.toHexString(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11.append(r13);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11.append(r12);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = androidx.constraintlayout.widget.ConstraintSet.Layout.mapToConstant;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r12.get(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11.append(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r11.toString();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        android.util.Log.w(r14, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x0616:
        r8 = r8 + 1;
        goto L_0x033d;
    L_0x061a:
        r6.recycle();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x061f:
        r1 = new java.lang.RuntimeException;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = new java.lang.StringBuilder;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.<init>();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = r22.getLineNumber();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r4);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = r3.toString();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r1.<init>(r3);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        throw r1;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x0638:
        if (r4 == 0) goto L_0x06d3;
    L_0x063a:
        r3 = r4.transform;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r7 = androidx.constraintlayout.widget.R$styleable.Transform;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = r1.obtainStyledAttributes(r6, r7);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mApply = r5;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r7 = r6.getIndexCount();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x064c:
        if (r9 >= r7) goto L_0x06ce;
    L_0x064e:
        r8 = r6.getIndex(r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = androidx.constraintlayout.widget.ConstraintSet.Transform.mapToConstant;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r10.get(r8);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        switch(r10) {
            case 1: goto L_0x06c2;
            case 2: goto L_0x06b9;
            case 3: goto L_0x06b0;
            case 4: goto L_0x06a7;
            case 5: goto L_0x069e;
            case 6: goto L_0x0695;
            case 7: goto L_0x068c;
            case 8: goto L_0x0683;
            case 9: goto L_0x067a;
            case 10: goto L_0x0671;
            case 11: goto L_0x0666;
            case 12: goto L_0x065d;
            default: goto L_0x065b;
        };	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x065b:
        goto L_0x06ca;
    L_0x065d:
        r10 = r3.transformPivotTarget;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = lookupID(r6, r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.transformPivotTarget = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x0666:
        r3.applyElevation = r5;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = r3.elevation;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getDimension(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.elevation = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x0671:
        r10 = r3.translationZ;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getDimension(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.translationZ = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x067a:
        r10 = r3.translationY;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getDimension(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.translationY = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x0683:
        r10 = r3.translationX;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getDimension(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.translationX = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x068c:
        r10 = r3.transformPivotY;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getDimension(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.transformPivotY = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x0695:
        r10 = r3.transformPivotX;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getDimension(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.transformPivotX = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x069e:
        r10 = r3.scaleY;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getFloat(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.scaleY = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x06a7:
        r10 = r3.scaleX;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getFloat(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.scaleX = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x06b0:
        r10 = r3.rotationY;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getFloat(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.rotationY = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x06b9:
        r10 = r3.rotationX;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getFloat(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.rotationX = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x06ca;
    L_0x06c2:
        r10 = r3.rotation;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getFloat(r8, r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.rotation = r8;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x06ca:
        r9 = r9 + 1;
        goto L_0x064c;
    L_0x06ce:
        r6.recycle();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x06d3:
        r1 = new java.lang.RuntimeException;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = new java.lang.StringBuilder;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.<init>();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = r22.getLineNumber();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r4);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = r3.toString();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r1.<init>(r3);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        throw r1;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x06ec:
        if (r4 == 0) goto L_0x0744;
    L_0x06ee:
        r3 = r4.propertySet;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = androidx.constraintlayout.widget.R$styleable.PropertySet;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r6 = r1.obtainStyledAttributes(r6, r8);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mApply = r5;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r8 = r6.getIndexCount();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r10 = 0;
    L_0x0701:
        if (r10 >= r8) goto L_0x0740;
    L_0x0703:
        r11 = r6.getIndex(r10);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        if (r11 != r5) goto L_0x0713;
    L_0x0709:
        r11 = r3.alpha;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getFloat(r5, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.alpha = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = 4;
        goto L_0x073d;
    L_0x0713:
        if (r11 != 0) goto L_0x0727;
    L_0x0715:
        r11 = r3.visibility;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getInt(r9, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.visibility = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = VISIBILITY_FLAGS;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = r3.visibility;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r11[r12];	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.visibility = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r12 = 4;
        goto L_0x073d;
    L_0x0727:
        r12 = 4;
        if (r11 != r12) goto L_0x0733;
    L_0x072a:
        r11 = r3.mVisibilityMode;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getInt(r12, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mVisibilityMode = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x073d;
    L_0x0733:
        if (r11 != r7) goto L_0x073d;
    L_0x0735:
        r11 = r3.mProgress;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r11 = r6.getFloat(r7, r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mProgress = r11;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x073d:
        r10 = r10 + 1;
        goto L_0x0701;
    L_0x0740:
        r6.recycle();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x0744:
        r1 = new java.lang.RuntimeException;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = new java.lang.StringBuilder;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.<init>();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r11);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = r22.getLineNumber();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.append(r4);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = r3.toString();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r1.<init>(r3);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        throw r1;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x075d:
        r3 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = fillFromAttributeList$ar$ds(r1, r3, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = r4.layout;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mHelperType = r5;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x076a:
        r3 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = fillFromAttributeList$ar$ds(r1, r3, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3 = r4.layout;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mIsGuideline = r5;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r3.mApply = r5;	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x0779:
        r3 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = fillFromAttributeList$ar$ds(r1, r3, r5);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x0782:
        r3 = android.util.Xml.asAttributeSet(r22);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r4 = fillFromAttributeList$ar$ds(r1, r3, r9);	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        goto L_0x0790;
    L_0x078b:
        r2 = r20;
        r22.getName();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
    L_0x0790:
        r3 = r22.next();	 Catch:{ XmlPullParserException -> 0x0799, IOException -> 0x0797 }
        r2 = r3;
        goto L_0x0007;
    L_0x0797:
        r0 = move-exception;
        goto L_0x07a1;
    L_0x0799:
        r0 = move-exception;
        goto L_0x07a9;
    L_0x079b:
        r2 = r20;
        return;
    L_0x079e:
        r0 = move-exception;
        r2 = r20;
    L_0x07a1:
        r1 = r0;
        r1.printStackTrace();
        return;
    L_0x07a6:
        r0 = move-exception;
        r2 = r20;
    L_0x07a9:
        r1 = r0;
        r1.printStackTrace();
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintSet.load(android.content.Context, org.xmlpull.v1.XmlPullParser):void");
    }
}
