package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.view.View;

/* compiled from: PG */
public final class Placeholder extends View {
    public final void onDraw(Canvas canvas) {
        throw null;
    }
}
