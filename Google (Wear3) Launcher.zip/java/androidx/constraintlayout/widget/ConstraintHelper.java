package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.HelperWidget;
import java.util.Arrays;
import java.util.HashMap;

/* compiled from: PG */
public class ConstraintHelper extends View {
    protected int mCount;
    protected HelperWidget mHelperWidget$ar$class_merging;
    protected int[] mIds;
    protected final HashMap mMap;
    protected String mReferenceIds;
    protected String mReferenceTags;
    protected final Context myContext;

    public ConstraintHelper(Context context) {
        super(context);
        this.mIds = new int[32];
        this.mMap = new HashMap();
        this.myContext = context;
        init(null);
    }

    private final void addID(String str) {
        if (str != null) {
            if (str.length() != 0) {
                if (this.myContext != null) {
                    ConstraintLayout constraintLayout;
                    int intValue;
                    StringBuilder stringBuilder;
                    str = str.trim();
                    if (getParent() instanceof ConstraintLayout) {
                        constraintLayout = (ConstraintLayout) getParent();
                    }
                    if (getParent() instanceof ConstraintLayout) {
                        constraintLayout = (ConstraintLayout) getParent();
                    } else {
                        constraintLayout = null;
                    }
                    int i = 0;
                    if (isInEditMode() && constraintLayout != null) {
                        Object designInformation$ar$ds = constraintLayout.getDesignInformation$ar$ds(str);
                        if (designInformation$ar$ds instanceof Integer) {
                            intValue = ((Integer) designInformation$ar$ds).intValue();
                            if (intValue == 0) {
                                if (constraintLayout == null) {
                                    intValue = findId(constraintLayout, str);
                                } else {
                                    intValue = 0;
                                }
                            }
                            if (intValue != 0) {
                                try {
                                    i = R$id.class.getField(str).getInt(null);
                                } catch (Exception e) {
                                }
                            } else {
                                i = intValue;
                            }
                            if (i == 0) {
                                i = this.myContext.getResources().getIdentifier(str, "id", this.myContext.getPackageName());
                            }
                            if (i == 0) {
                                this.mMap.put(Integer.valueOf(i), str);
                                addRscID(i);
                            }
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("Could not find id of \"");
                            stringBuilder.append(str);
                            stringBuilder.append("\"");
                            Log.w("ConstraintHelper", stringBuilder.toString());
                            return;
                        }
                    }
                    intValue = 0;
                    if (intValue == 0) {
                        if (constraintLayout == null) {
                            intValue = 0;
                        } else {
                            intValue = findId(constraintLayout, str);
                        }
                    }
                    if (intValue != 0) {
                        i = intValue;
                    } else {
                        i = R$id.class.getField(str).getInt(null);
                    }
                    if (i == 0) {
                        i = this.myContext.getResources().getIdentifier(str, "id", this.myContext.getPackageName());
                    }
                    if (i == 0) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("Could not find id of \"");
                        stringBuilder.append(str);
                        stringBuilder.append("\"");
                        Log.w("ConstraintHelper", stringBuilder.toString());
                        return;
                    }
                    this.mMap.put(Integer.valueOf(i), str);
                    addRscID(i);
                }
            }
        }
    }

    private final void addRscID(int i) {
        if (i != getId()) {
            int i2 = this.mCount;
            int[] iArr = this.mIds;
            int length = iArr.length;
            if (i2 + 1 > length) {
                this.mIds = Arrays.copyOf(iArr, length + length);
            }
            int[] iArr2 = this.mIds;
            int i3 = this.mCount;
            iArr2[i3] = i;
            this.mCount = i3 + 1;
        }
    }

    private final void addTag(String str) {
        if (str != null) {
            if (str.length() != 0) {
                if (this.myContext != null) {
                    ViewGroup viewGroup;
                    str = str.trim();
                    if (getParent() instanceof ConstraintLayout) {
                        viewGroup = (ConstraintLayout) getParent();
                    } else {
                        viewGroup = null;
                    }
                    String str2 = "ConstraintHelper";
                    if (viewGroup == null) {
                        Log.w(str2, "Parent not a ConstraintLayout");
                        return;
                    }
                    int childCount = viewGroup.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        View childAt = viewGroup.getChildAt(i);
                        LayoutParams layoutParams = childAt.getLayoutParams();
                        if ((layoutParams instanceof ConstraintLayout.LayoutParams) && str.equals(((ConstraintLayout.LayoutParams) layoutParams).constraintTag)) {
                            if (childAt.getId() == -1) {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("to use ConstraintTag view ");
                                stringBuilder.append(childAt.getClass().getSimpleName());
                                stringBuilder.append(" must have an ID");
                                Log.w(str2, stringBuilder.toString());
                            } else {
                                addRscID(childAt.getId());
                            }
                        }
                    }
                }
            }
        }
    }

    public final int findId(ConstraintLayout constraintLayout, String str) {
        if (str != null) {
            Resources resources = this.myContext.getResources();
            if (resources == null) {
                return 0;
            }
            int childCount = constraintLayout.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = constraintLayout.getChildAt(i);
                if (childAt.getId() != -1) {
                    Object resourceEntryName;
                    try {
                        resourceEntryName = resources.getResourceEntryName(childAt.getId());
                    } catch (NotFoundException e) {
                        resourceEntryName = null;
                    }
                    if (str.equals(resourceEntryName)) {
                        return childAt.getId();
                    }
                }
            }
        }
        return 0;
    }

    protected void init(AttributeSet attributeSet) {
        throw null;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.mReferenceIds;
        if (str != null) {
            setIds(str);
        }
        str = this.mReferenceTags;
        if (str != null) {
            setReferenceTags(str);
        }
    }

    public final void onDraw(Canvas canvas) {
    }

    protected final void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    public void resolveRtl(ConstraintWidget constraintWidget, boolean z) {
    }

    protected final void setIds(String str) {
        this.mReferenceIds = str;
        if (str != null) {
            int i = 0;
            this.mCount = 0;
            while (true) {
                int indexOf = str.indexOf(44, i);
                if (indexOf == -1) {
                    addID(str.substring(i));
                    return;
                } else {
                    addID(str.substring(i, indexOf));
                    i = indexOf + 1;
                }
            }
        }
    }

    protected final void setReferenceTags(String str) {
        this.mReferenceTags = str;
        if (str != null) {
            int i = 0;
            this.mCount = 0;
            while (true) {
                int indexOf = str.indexOf(44, i);
                if (indexOf == -1) {
                    addTag(str.substring(i));
                    return;
                } else {
                    addTag(str.substring(i, indexOf));
                    i = indexOf + 1;
                }
            }
        }
    }

    public final void setReferencedIds(int[] iArr) {
        this.mReferenceIds = null;
        int i = 0;
        this.mCount = 0;
        while (i < iArr.length) {
            addRscID(iArr[i]);
            i++;
        }
    }

    public final void setTag(int i, Object obj) {
        super.setTag(i, obj);
        if (obj == null && this.mReferenceIds == null) {
            addRscID(i);
        }
    }

    public final void validateParams() {
        if (this.mHelperWidget$ar$class_merging != null) {
            LayoutParams layoutParams = getLayoutParams();
            if (layoutParams instanceof ConstraintLayout.LayoutParams) {
                ((ConstraintLayout.LayoutParams) layoutParams).widget = this.mHelperWidget$ar$class_merging;
            }
        }
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mIds = new int[32];
        this.mMap = new HashMap();
        this.myContext = context;
        init(attributeSet);
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mIds = new int[32];
        this.mMap = new HashMap();
        this.myContext = context;
        init(attributeSet);
    }
}
