package androidx.constraintlayout.widget;

/* compiled from: PG */
public final class VirtualLayout extends ConstraintHelper {
    public final void onAttachedToWindow() {
        throw null;
    }

    public final void setElevation(float f) {
        throw null;
    }

    public final void setVisibility(int i) {
        throw null;
    }
}
