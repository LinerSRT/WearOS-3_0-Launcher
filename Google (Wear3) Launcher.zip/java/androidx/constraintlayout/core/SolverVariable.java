package androidx.constraintlayout.core;

import java.util.Arrays;

/* compiled from: PG */
public final class SolverVariable implements Comparable {
    public static int uniqueErrorId = 1;
    public float computedValue;
    int definitionId = -1;
    final float[] goalStrengthVector = new float[9];
    /* renamed from: id */
    public int f11id = -1;
    public boolean inGoal;
    public boolean isFinalValue = false;
    boolean isSynonym = false;
    ArrayRow[] mClientEquations = new ArrayRow[16];
    int mClientEquationsCount = 0;
    int mType$ar$edu;
    public int strength = 0;
    final float[] strengthVector = new float[9];
    public int usageInRowCount = 0;

    public SolverVariable(int i) {
        this.mType$ar$edu = i;
    }

    public final void addToRow(ArrayRow arrayRow) {
        int i;
        int i2 = 0;
        while (true) {
            i = this.mClientEquationsCount;
            if (i2 >= i) {
                break;
            } else if (this.mClientEquations[i2] != arrayRow) {
                i2++;
            } else {
                return;
            }
        }
        ArrayRow[] arrayRowArr = this.mClientEquations;
        int length = arrayRowArr.length;
        if (i >= length) {
            this.mClientEquations = (ArrayRow[]) Arrays.copyOf(arrayRowArr, length + length);
        }
        arrayRowArr = this.mClientEquations;
        i = this.mClientEquationsCount;
        arrayRowArr[i] = arrayRow;
        this.mClientEquationsCount = i + 1;
    }

    public final /* bridge */ /* synthetic */ int compareTo(Object obj) {
        return this.f11id - ((SolverVariable) obj).f11id;
    }

    public final void removeFromRow(ArrayRow arrayRow) {
        int i = this.mClientEquationsCount;
        int i2 = 0;
        while (i2 < i) {
            if (this.mClientEquations[i2] == arrayRow) {
                while (i2 < i - 1) {
                    ArrayRow[] arrayRowArr = this.mClientEquations;
                    int i3 = i2 + 1;
                    arrayRowArr[i2] = arrayRowArr[i3];
                    i2 = i3;
                }
                this.mClientEquationsCount--;
                return;
            }
            i2++;
        }
    }

    public final void reset() {
        this.mType$ar$edu = 5;
        this.strength = 0;
        this.f11id = -1;
        this.definitionId = -1;
        this.computedValue = 0.0f;
        this.isFinalValue = false;
        this.isSynonym = false;
        int i = this.mClientEquationsCount;
        for (int i2 = 0; i2 < i; i2++) {
            this.mClientEquations[i2] = null;
        }
        this.mClientEquationsCount = 0;
        this.usageInRowCount = 0;
        this.inGoal = false;
        Arrays.fill(this.goalStrengthVector, 0.0f);
    }

    public final void setFinalValue(LinearSystem linearSystem, float f) {
        this.computedValue = f;
        this.isFinalValue = true;
        this.isSynonym = false;
        int i = this.mClientEquationsCount;
        this.definitionId = -1;
        for (int i2 = 0; i2 < i; i2++) {
            this.mClientEquations[i2].updateFromFinalVariable(linearSystem, this, false);
        }
        this.mClientEquationsCount = 0;
    }

    public final String toString() {
        int i = this.f11id;
        StringBuilder stringBuilder = new StringBuilder(11);
        stringBuilder.append("");
        stringBuilder.append(i);
        return stringBuilder.toString();
    }

    public final void updateReferencesWithNewDefinition(LinearSystem linearSystem, ArrayRow arrayRow) {
        int i = this.mClientEquationsCount;
        for (int i2 = 0; i2 < i; i2++) {
            this.mClientEquations[i2].updateFromRow(linearSystem, arrayRow, false);
        }
        this.mClientEquationsCount = 0;
    }
}
