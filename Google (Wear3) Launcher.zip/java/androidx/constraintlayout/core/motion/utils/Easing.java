package androidx.constraintlayout.core.motion.utils;

/* compiled from: PG */
public final class Easing {
    public static final String[] NAMED_EASING = new String[]{"standard", "accelerate", "decelerate", "linear"};
}
