package androidx.constraintlayout.core;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import java.util.Arrays;

/* compiled from: PG */
public final class LinearSystem {
    public static long ARRAY_ROW_CREATION = 0;
    private static int POOL_SIZE = 1000;
    public static boolean USE_DEPENDENCY_ORDERING = false;
    private int TABLE_SIZE;
    public boolean graphOptimizer;
    public boolean hasSimpleDefinition;
    private boolean[] mAlreadyTestedCandidates;
    public final Cache mCache;
    private final ArrayRow mGoal$ar$class_merging;
    private int mMaxColumns;
    private int mMaxRows;
    int mNumColumns;
    int mNumRows;
    private SolverVariable[] mPoolVariables;
    private int mPoolVariablesCount;
    ArrayRow[] mRows;
    private ArrayRow mTempGoal$ar$class_merging;
    int mVariablesID;
    public boolean newgraphOptimizer;

    public LinearSystem() {
        this.hasSimpleDefinition = false;
        this.mVariablesID = 0;
        this.TABLE_SIZE = 32;
        this.mMaxColumns = 32;
        this.mRows = null;
        this.graphOptimizer = false;
        this.newgraphOptimizer = false;
        this.mAlreadyTestedCandidates = new boolean[32];
        this.mNumColumns = 1;
        this.mNumRows = 0;
        this.mMaxRows = 32;
        this.mPoolVariables = new SolverVariable[POOL_SIZE];
        this.mPoolVariablesCount = 0;
        this.mRows = new ArrayRow[32];
        releaseRows();
        Cache cache = new Cache();
        this.mCache = cache;
        this.mGoal$ar$class_merging = new PriorityGoalRow(cache);
        this.mTempGoal$ar$class_merging = new ArrayRow(cache);
    }

    private final SolverVariable acquireSolverVariable$ar$edu$ar$ds(int i) {
        SolverVariable solverVariable = (SolverVariable) this.mCache.solverVariablePool$ar$class_merging.acquire();
        if (solverVariable == null) {
            solverVariable = new SolverVariable(i);
            solverVariable.mType$ar$edu = i;
        } else {
            solverVariable.reset();
            solverVariable.mType$ar$edu = i;
        }
        i = this.mPoolVariablesCount;
        int i2 = POOL_SIZE;
        if (i >= i2) {
            i2 += i2;
            POOL_SIZE = i2;
            this.mPoolVariables = (SolverVariable[]) Arrays.copyOf(this.mPoolVariables, i2);
        }
        SolverVariable[] solverVariableArr = this.mPoolVariables;
        i2 = this.mPoolVariablesCount;
        this.mPoolVariablesCount = i2 + 1;
        solverVariableArr[i2] = solverVariable;
        return solverVariable;
    }

    private final void computeValues() {
        for (int i = 0; i < this.mNumRows; i++) {
            ArrayRow arrayRow = this.mRows[i];
            arrayRow.variable.computedValue = arrayRow.constantValue;
        }
    }

    public static final int getObjectVariableValue$ar$ds(Object obj) {
        SolverVariable solverVariable = ((ConstraintAnchor) obj).mSolverVariable;
        return solverVariable != null ? (int) (solverVariable.computedValue + 0.5f) : 0;
    }

    private final void increaseTableSize() {
        int i = this.TABLE_SIZE;
        i += i;
        this.TABLE_SIZE = i;
        this.mRows = (ArrayRow[]) Arrays.copyOf(this.mRows, i);
        Cache cache = this.mCache;
        cache.mIndexedVariables = (SolverVariable[]) Arrays.copyOf(cache.mIndexedVariables, this.TABLE_SIZE);
        i = this.TABLE_SIZE;
        this.mAlreadyTestedCandidates = new boolean[i];
        this.mMaxColumns = i;
        this.mMaxRows = i;
    }

    private final void optimize$ar$class_merging$ar$ds(ArrayRow arrayRow) {
        LinearSystem linearSystem = this;
        ArrayRow arrayRow2 = arrayRow;
        for (int i = 0; i < linearSystem.mNumColumns; i++) {
            linearSystem.mAlreadyTestedCandidates[i] = false;
        }
        Object obj = null;
        int i2 = 0;
        while (obj == null) {
            i2++;
            int i3 = linearSystem.mNumColumns;
            if (i2 >= i3 + i3) {
                break;
            }
            SolverVariable solverVariable = arrayRow2.variable;
            if (solverVariable != null) {
                linearSystem.mAlreadyTestedCandidates[solverVariable.f11id] = true;
            }
            solverVariable = arrayRow2.getPivotCandidate$ar$ds(linearSystem.mAlreadyTestedCandidates);
            if (solverVariable != null) {
                boolean[] zArr = linearSystem.mAlreadyTestedCandidates;
                int i4 = solverVariable.f11id;
                if (!zArr[i4]) {
                    zArr[i4] = true;
                } else {
                    return;
                }
            }
            if (solverVariable != null) {
                float f = Float.MAX_VALUE;
                int i5 = -1;
                for (int i6 = 0; i6 < linearSystem.mNumRows; i6++) {
                    ArrayRow arrayRow3 = linearSystem.mRows[i6];
                    if (arrayRow3.variable.mType$ar$edu != 1) {
                        if (!arrayRow3.isSimpleDefinition) {
                            ArrayLinkedVariables arrayLinkedVariables = arrayRow3.variables$ar$class_merging;
                            int i7 = arrayLinkedVariables.mHead;
                            if (i7 != -1) {
                                int i8 = 0;
                                while (i7 != -1 && i8 < arrayLinkedVariables.currentSize) {
                                    if (arrayLinkedVariables.mArrayIndices[i7] == solverVariable.f11id) {
                                        float f2 = arrayRow3.variables$ar$class_merging.get(solverVariable);
                                        if (f2 < 0.0f) {
                                            float f3 = (-arrayRow3.constantValue) / f2;
                                            if (f3 < f) {
                                                i5 = i6;
                                                f = f3;
                                            }
                                        }
                                    } else {
                                        i7 = arrayLinkedVariables.mArrayNextIndices[i7];
                                        i8++;
                                    }
                                }
                            }
                        }
                    }
                }
                if (i5 >= 0) {
                    ArrayRow arrayRow4 = linearSystem.mRows[i5];
                    arrayRow4.variable.definitionId = -1;
                    arrayRow4.pivot(solverVariable);
                    SolverVariable solverVariable2 = arrayRow4.variable;
                    solverVariable2.definitionId = i5;
                    solverVariable2.updateReferencesWithNewDefinition(linearSystem, arrayRow4);
                }
            } else {
                obj = 1;
            }
        }
    }

    private final void releaseRows() {
        for (int i = 0; i < this.mNumRows; i++) {
            Object obj = this.mRows[i];
            if (obj != null) {
                this.mCache.arrayRowPool$ar$class_merging.release$ar$ds(obj);
            }
            this.mRows[i] = null;
        }
    }

    public final void addCentering(SolverVariable solverVariable, SolverVariable solverVariable2, int i, float f, SolverVariable solverVariable3, SolverVariable solverVariable4, int i2, int i3) {
        ArrayRow createRow = createRow();
        if (solverVariable2 == solverVariable3) {
            createRow.variables$ar$class_merging.put(solverVariable, 1.0f);
            createRow.variables$ar$class_merging.put(solverVariable4, 1.0f);
            createRow.variables$ar$class_merging.put(solverVariable2, -2.0f);
        } else if (f == 0.5f) {
            createRow.variables$ar$class_merging.put(solverVariable, 1.0f);
            createRow.variables$ar$class_merging.put(solverVariable2, -1.0f);
            createRow.variables$ar$class_merging.put(solverVariable3, -1.0f);
            createRow.variables$ar$class_merging.put(solverVariable4, 1.0f);
            if (i > 0 || i2 > 0) {
                createRow.constantValue = (float) ((-i) + i2);
            }
        } else if (f <= 0.0f) {
            createRow.variables$ar$class_merging.put(solverVariable, -1.0f);
            createRow.variables$ar$class_merging.put(solverVariable2, 1.0f);
            createRow.constantValue = (float) i;
        } else if (f >= 1.0f) {
            createRow.variables$ar$class_merging.put(solverVariable4, -1.0f);
            createRow.variables$ar$class_merging.put(solverVariable3, 1.0f);
            createRow.constantValue = (float) (-i2);
        } else {
            float f2 = 1.0f - f;
            createRow.variables$ar$class_merging.put(solverVariable, f2);
            createRow.variables$ar$class_merging.put(solverVariable2, -f2);
            createRow.variables$ar$class_merging.put(solverVariable3, -f);
            createRow.variables$ar$class_merging.put(solverVariable4, f);
            if (i > 0 || i2 > 0) {
                createRow.constantValue = (((float) (-i)) * f2) + (((float) i2) * f);
            }
        }
        if (i3 != 8) {
            createRow.addError$ar$ds(this, i3);
        }
        addConstraint(createRow);
    }

    public final void addConstraint(ArrayRow arrayRow) {
        ArrayRow arrayRow2 = arrayRow;
        if (this.mNumRows + 1 >= this.mMaxRows || r0.mNumColumns + 1 >= r0.mMaxColumns) {
            increaseTableSize();
        }
        if (!arrayRow2.isSimpleDefinition) {
            Object obj;
            int i;
            if (r0.mRows.length != 0) {
                obj = null;
                while (obj == null) {
                    SolverVariable variable;
                    int i2 = arrayRow2.variables$ar$class_merging.currentSize;
                    for (i = 0; i < i2; i++) {
                        variable = arrayRow2.variables$ar$class_merging.getVariable(i);
                        if (variable.definitionId != -1 || variable.isFinalValue) {
                            arrayRow2.variablesToUpdate.add(variable);
                        } else {
                            boolean z = variable.isSynonym;
                        }
                    }
                    i2 = arrayRow2.variablesToUpdate.size();
                    if (i2 > 0) {
                        for (i = 0; i < i2; i++) {
                            variable = (SolverVariable) arrayRow2.variablesToUpdate.get(i);
                            if (variable.isFinalValue) {
                                arrayRow2.updateFromFinalVariable(r0, variable, true);
                            } else {
                                boolean z2 = variable.isSynonym;
                                arrayRow2.updateFromRow(r0, r0.mRows[variable.definitionId], true);
                            }
                        }
                        arrayRow2.variablesToUpdate.clear();
                    } else {
                        obj = 1;
                    }
                }
                if (arrayRow2.variable != null && arrayRow2.variables$ar$class_merging.currentSize == 0) {
                    arrayRow2.isSimpleDefinition = true;
                    r0.hasSimpleDefinition = true;
                }
            }
            if (!arrayRow.isEmpty()) {
                int i3;
                SolverVariable acquireSolverVariable$ar$edu$ar$ds;
                Object obj2;
                float f = arrayRow2.constantValue;
                if (f < 0.0f) {
                    arrayRow2.constantValue = -f;
                    ArrayLinkedVariables arrayLinkedVariables = arrayRow2.variables$ar$class_merging;
                    i = arrayLinkedVariables.mHead;
                    i3 = 0;
                    while (i != -1 && i3 < arrayLinkedVariables.currentSize) {
                        float[] fArr = arrayLinkedVariables.mArrayValues;
                        fArr[i] = -fArr[i];
                        i = arrayLinkedVariables.mArrayNextIndices[i];
                        i3++;
                    }
                }
                int i4 = arrayRow2.variables$ar$class_merging.currentSize;
                SolverVariable solverVariable = null;
                SolverVariable solverVariable2 = solverVariable;
                float f2 = 0.0f;
                float f3 = 0.0f;
                boolean z3 = false;
                boolean z4 = false;
                for (i3 = 0; i3 < i4; i3++) {
                    float variableValue = arrayRow2.variables$ar$class_merging.getVariableValue(i3);
                    SolverVariable variable2 = arrayRow2.variables$ar$class_merging.getVariable(i3);
                    if (variable2.mType$ar$edu == 1) {
                        if (solverVariable == null) {
                            z4 = ArrayRow.isNew$ar$ds(variable2);
                            solverVariable = variable2;
                            f2 = variableValue;
                        } else if (f2 > variableValue) {
                            z4 = ArrayRow.isNew$ar$ds(variable2);
                            solverVariable = variable2;
                            f2 = variableValue;
                        } else if (!z4 && ArrayRow.isNew$ar$ds(variable2)) {
                            solverVariable = variable2;
                            f2 = variableValue;
                            z4 = true;
                        }
                    } else if (solverVariable == null && variableValue < 0.0f) {
                        if (solverVariable2 == null) {
                            z3 = ArrayRow.isNew$ar$ds(variable2);
                            solverVariable2 = variable2;
                            f3 = variableValue;
                        } else if (f3 > variableValue) {
                            z3 = ArrayRow.isNew$ar$ds(variable2);
                            solverVariable2 = variable2;
                            f3 = variableValue;
                        } else if (!z3 && ArrayRow.isNew$ar$ds(variable2)) {
                            solverVariable2 = variable2;
                            f3 = variableValue;
                            z3 = true;
                        }
                    }
                }
                if (solverVariable == null) {
                    solverVariable = solverVariable2;
                }
                if (solverVariable == null) {
                    obj = 1;
                } else {
                    arrayRow2.pivot(solverVariable);
                    obj = null;
                }
                if (arrayRow2.variables$ar$class_merging.currentSize == 0) {
                    arrayRow2.isSimpleDefinition = true;
                }
                if (obj != null) {
                    if (r0.mNumColumns + 1 >= r0.mMaxColumns) {
                        increaseTableSize();
                    }
                    acquireSolverVariable$ar$edu$ar$ds = acquireSolverVariable$ar$edu$ar$ds(3);
                    int i5 = r0.mVariablesID + 1;
                    r0.mVariablesID = i5;
                    r0.mNumColumns++;
                    acquireSolverVariable$ar$edu$ar$ds.f11id = i5;
                    r0.mCache.mIndexedVariables[i5] = acquireSolverVariable$ar$edu$ar$ds;
                    arrayRow2.variable = acquireSolverVariable$ar$edu$ar$ds;
                    i5 = r0.mNumRows;
                    addRow(arrayRow);
                    if (r0.mNumRows == i5 + 1) {
                        ArrayRow arrayRow3 = r0.mTempGoal$ar$class_merging;
                        arrayRow3.variable = null;
                        arrayRow3.variables$ar$class_merging.clear();
                        int i6 = 0;
                        while (true) {
                            ArrayLinkedVariables arrayLinkedVariables2 = arrayRow2.variables$ar$class_merging;
                            if (i6 >= arrayLinkedVariables2.currentSize) {
                                break;
                            }
                            arrayRow3.variables$ar$class_merging.add(arrayLinkedVariables2.getVariable(i6), arrayRow2.variables$ar$class_merging.getVariableValue(i6), true);
                            i6++;
                        }
                        optimize$ar$class_merging$ar$ds(r0.mTempGoal$ar$class_merging);
                        if (acquireSolverVariable$ar$edu$ar$ds.definitionId == -1) {
                            if (arrayRow2.variable == acquireSolverVariable$ar$edu$ar$ds) {
                                acquireSolverVariable$ar$edu$ar$ds = arrayRow2.pickPivotInVariables(null, acquireSolverVariable$ar$edu$ar$ds);
                                if (acquireSolverVariable$ar$edu$ar$ds != null) {
                                    arrayRow2.pivot(acquireSolverVariable$ar$edu$ar$ds);
                                }
                            }
                            if (!arrayRow2.isSimpleDefinition) {
                                arrayRow2.variable.updateReferencesWithNewDefinition(r0, arrayRow2);
                            }
                            r0.mCache.arrayRowPool$ar$class_merging.release$ar$ds(arrayRow2);
                            r0.mNumRows--;
                            obj2 = 1;
                        } else {
                            obj2 = 1;
                        }
                        acquireSolverVariable$ar$edu$ar$ds = arrayRow2.variable;
                        if (acquireSolverVariable$ar$edu$ar$ds != null || ((acquireSolverVariable$ar$edu$ar$ds.mType$ar$edu != 1 && arrayRow2.constantValue < 0.0f) || obj2 != null)) {
                            return;
                        }
                    }
                }
                obj2 = null;
                acquireSolverVariable$ar$edu$ar$ds = arrayRow2.variable;
                if (acquireSolverVariable$ar$edu$ar$ds != null) {
                }
                return;
            }
            return;
        }
        addRow(arrayRow);
    }

    public final void addEquality(SolverVariable solverVariable, int i) {
        int i2 = solverVariable.definitionId;
        if (i2 == -1) {
            solverVariable.setFinalValue(this, (float) i);
            for (int i3 = 0; i3 < this.mVariablesID + 1; i3++) {
                SolverVariable solverVariable2 = this.mCache.mIndexedVariables[i3];
            }
        } else if (i2 != -1) {
            r0 = this.mRows[i2];
            if (r0.isSimpleDefinition) {
                r0.constantValue = (float) i;
            } else if (r0.variables$ar$class_merging.currentSize == 0) {
                r0.isSimpleDefinition = true;
                r0.constantValue = (float) i;
            } else {
                r0 = createRow();
                if (i < 0) {
                    r0.constantValue = (float) (-i);
                    r0.variables$ar$class_merging.put(solverVariable, 1.0f);
                } else {
                    r0.constantValue = (float) i;
                    r0.variables$ar$class_merging.put(solverVariable, -1.0f);
                }
                addConstraint(r0);
            }
        } else {
            r0 = createRow();
            r0.variable = solverVariable;
            float f = (float) i;
            solverVariable.computedValue = f;
            r0.constantValue = f;
            r0.isSimpleDefinition = true;
            addConstraint(r0);
        }
    }

    public final void addEquality$ar$ds(SolverVariable solverVariable, SolverVariable solverVariable2, int i, int i2) {
        if (i2 == 8) {
            if (!solverVariable2.isFinalValue) {
                i2 = 8;
            } else if (solverVariable.definitionId != -1) {
                i2 = 8;
            } else {
                solverVariable.setFinalValue(this, solverVariable2.computedValue + ((float) i));
                return;
            }
        }
        ArrayRow createRow = createRow();
        if (i != 0) {
            Object obj;
            if (i < 0) {
                i = -i;
                obj = 1;
            } else {
                obj = null;
            }
            createRow.constantValue = (float) i;
            if (obj != null) {
                createRow.variables$ar$class_merging.put(solverVariable, 1.0f);
                createRow.variables$ar$class_merging.put(solverVariable2, -1.0f);
                if (i2 != 8) {
                    createRow.addError$ar$ds(this, i2);
                }
                addConstraint(createRow);
            }
        }
        createRow.variables$ar$class_merging.put(solverVariable, -1.0f);
        createRow.variables$ar$class_merging.put(solverVariable2, 1.0f);
        if (i2 != 8) {
            createRow.addError$ar$ds(this, i2);
        }
        addConstraint(createRow);
    }

    public final void addGreaterThan(SolverVariable solverVariable, SolverVariable solverVariable2, int i, int i2) {
        ArrayRow createRow = createRow();
        SolverVariable createSlackVariable = createSlackVariable();
        createSlackVariable.strength = 0;
        createRow.createRowGreaterThan$ar$ds(solverVariable, solverVariable2, createSlackVariable, i);
        if (i2 != 8) {
            addSingleError(createRow, (int) (-createRow.variables$ar$class_merging.get(createSlackVariable)), i2);
        }
        addConstraint(createRow);
    }

    public final void addLowerThan(SolverVariable solverVariable, SolverVariable solverVariable2, int i, int i2) {
        ArrayRow createRow = createRow();
        SolverVariable createSlackVariable = createSlackVariable();
        createSlackVariable.strength = 0;
        createRow.createRowLowerThan$ar$ds(solverVariable, solverVariable2, createSlackVariable, i);
        if (i2 != 8) {
            addSingleError(createRow, (int) (-createRow.variables$ar$class_merging.get(createSlackVariable)), i2);
        }
        addConstraint(createRow);
    }

    public final void addRatio$ar$ds(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, SolverVariable solverVariable4, float f) {
        ArrayRow createRow = createRow();
        createRow.createRowDimensionRatio$ar$ds(solverVariable, solverVariable2, solverVariable3, solverVariable4, f);
        addConstraint(createRow);
    }

    final void addSingleError(ArrayRow arrayRow, int i, int i2) {
        arrayRow.variables$ar$class_merging.put(createErrorVariable$ar$ds(i2), (float) i);
    }

    public final SolverVariable createErrorVariable$ar$ds(int i) {
        if (this.mNumColumns + 1 >= this.mMaxColumns) {
            increaseTableSize();
        }
        SolverVariable acquireSolverVariable$ar$edu$ar$ds = acquireSolverVariable$ar$edu$ar$ds(4);
        int i2 = this.mVariablesID + 1;
        this.mVariablesID = i2;
        this.mNumColumns++;
        acquireSolverVariable$ar$edu$ar$ds.f11id = i2;
        acquireSolverVariable$ar$edu$ar$ds.strength = i;
        this.mCache.mIndexedVariables[i2] = acquireSolverVariable$ar$edu$ar$ds;
        PriorityGoalRow priorityGoalRow = (PriorityGoalRow) this.mGoal$ar$class_merging;
        GoalVariableAccessor goalVariableAccessor = priorityGoalRow.accessor;
        goalVariableAccessor.variable = acquireSolverVariable$ar$edu$ar$ds;
        Arrays.fill(goalVariableAccessor.variable.goalStrengthVector, 0.0f);
        acquireSolverVariable$ar$edu$ar$ds.goalStrengthVector[acquireSolverVariable$ar$edu$ar$ds.strength] = 1.0f;
        priorityGoalRow.addToGoal(acquireSolverVariable$ar$edu$ar$ds);
        return acquireSolverVariable$ar$edu$ar$ds;
    }

    public final SolverVariable createObjectVariable(Object obj) {
        if (obj == null) {
            return null;
        }
        if (this.mNumColumns + 1 >= this.mMaxColumns) {
            increaseTableSize();
        }
        ConstraintAnchor constraintAnchor = (ConstraintAnchor) obj;
        SolverVariable solverVariable = constraintAnchor.mSolverVariable;
        if (solverVariable == null) {
            constraintAnchor.resetSolverVariable$ar$ds();
            solverVariable = constraintAnchor.mSolverVariable;
        }
        int i = solverVariable.f11id;
        if (i != -1) {
            if (i > this.mVariablesID || this.mCache.mIndexedVariables[i] == null) {
                if (i != -1) {
                    solverVariable.reset();
                }
            }
            return solverVariable;
        }
        i = this.mVariablesID + 1;
        this.mVariablesID = i;
        this.mNumColumns++;
        solverVariable.f11id = i;
        solverVariable.mType$ar$edu = 1;
        this.mCache.mIndexedVariables[i] = solverVariable;
        return solverVariable;
    }

    public final ArrayRow createRow() {
        ArrayRow arrayRow = (ArrayRow) this.mCache.arrayRowPool$ar$class_merging.acquire();
        if (arrayRow == null) {
            arrayRow = new ArrayRow(this.mCache);
            ARRAY_ROW_CREATION++;
        } else {
            arrayRow.variable = null;
            arrayRow.variables$ar$class_merging.clear();
            arrayRow.constantValue = 0.0f;
            arrayRow.isSimpleDefinition = false;
        }
        SolverVariable.uniqueErrorId++;
        return arrayRow;
    }

    public final SolverVariable createSlackVariable() {
        if (this.mNumColumns + 1 >= this.mMaxColumns) {
            increaseTableSize();
        }
        SolverVariable acquireSolverVariable$ar$edu$ar$ds = acquireSolverVariable$ar$edu$ar$ds(3);
        int i = this.mVariablesID + 1;
        this.mVariablesID = i;
        this.mNumColumns++;
        acquireSolverVariable$ar$edu$ar$ds.f11id = i;
        this.mCache.mIndexedVariables[i] = acquireSolverVariable$ar$edu$ar$ds;
        return acquireSolverVariable$ar$edu$ar$ds;
    }

    public final void minimize() {
        if (this.mGoal$ar$class_merging.isEmpty()) {
            computeValues();
        } else if (this.newgraphOptimizer) {
            int i = 0;
            while (i < this.mNumRows) {
                if (this.mRows[i].isSimpleDefinition) {
                    i++;
                } else {
                    minimizeGoal$ar$class_merging(this.mGoal$ar$class_merging);
                    return;
                }
            }
            computeValues();
        } else {
            minimizeGoal$ar$class_merging(this.mGoal$ar$class_merging);
        }
    }

    public final void reset() {
        Cache cache;
        int i = 0;
        while (true) {
            cache = this.mCache;
            SolverVariable[] solverVariableArr = cache.mIndexedVariables;
            if (i >= solverVariableArr.length) {
                break;
            }
            SolverVariable solverVariable = solverVariableArr[i];
            if (solverVariable != null) {
                solverVariable.reset();
            }
            i++;
        }
        Pools$SimplePool pools$SimplePool = cache.solverVariablePool$ar$class_merging;
        SolverVariable[] solverVariableArr2 = this.mPoolVariables;
        int i2 = this.mPoolVariablesCount;
        int length = solverVariableArr2.length;
        if (i2 > length) {
            i2 = length;
        }
        for (length = 0; length < i2; length++) {
            SolverVariable solverVariable2 = solverVariableArr2[length];
            int i3 = pools$SimplePool.mPoolSize;
            if (i3 < 256) {
                pools$SimplePool.mPool[i3] = solverVariable2;
                pools$SimplePool.mPoolSize = i3 + 1;
            }
        }
        this.mPoolVariablesCount = 0;
        Arrays.fill(this.mCache.mIndexedVariables, null);
        this.mVariablesID = 0;
        PriorityGoalRow priorityGoalRow = (PriorityGoalRow) this.mGoal$ar$class_merging;
        priorityGoalRow.numGoals = 0;
        priorityGoalRow.constantValue = 0.0f;
        this.mNumColumns = 1;
        for (i = 0; i < this.mNumRows; i++) {
            ArrayRow arrayRow = this.mRows[i];
        }
        releaseRows();
        this.mNumRows = 0;
        this.mTempGoal$ar$class_merging = new ArrayRow(this.mCache);
    }

    final void minimizeGoal$ar$class_merging(ArrayRow arrayRow) {
        LinearSystem linearSystem = this;
        for (int i = 0; i < linearSystem.mNumRows; i++) {
            ArrayRow arrayRow2 = linearSystem.mRows[i];
            if (arrayRow2.variable.mType$ar$edu != 1) {
                float f = 0.0f;
                if (arrayRow2.constantValue < 0.0f) {
                    i = 0;
                    int i2 = 0;
                    while (i == 0) {
                        int i3;
                        i2++;
                        float f2 = Float.MAX_VALUE;
                        int i4 = 0;
                        int i5 = -1;
                        int i6 = -1;
                        int i7 = 0;
                        while (i4 < linearSystem.mNumRows) {
                            ArrayRow arrayRow3 = linearSystem.mRows[i4];
                            if (arrayRow3.variable.mType$ar$edu != 1) {
                                if (!arrayRow3.isSimpleDefinition) {
                                    if (arrayRow3.constantValue < f) {
                                        int i8 = arrayRow3.variables$ar$class_merging.currentSize;
                                        int i9 = 0;
                                        while (i9 < i8) {
                                            SolverVariable variable = arrayRow3.variables$ar$class_merging.getVariable(i9);
                                            float f3 = arrayRow3.variables$ar$class_merging.get(variable);
                                            if (f3 > f) {
                                                i3 = 0;
                                                while (i3 < 9) {
                                                    f = variable.strengthVector[i3] / f3;
                                                    if ((f < f2 && i3 == r10) || i3 > r10) {
                                                        i6 = variable.f11id;
                                                        i7 = i3;
                                                        f2 = f;
                                                        i5 = i4;
                                                    }
                                                    i3++;
                                                }
                                            }
                                            i9++;
                                            f = 0.0f;
                                        }
                                    }
                                }
                            }
                            i4++;
                            f = 0.0f;
                        }
                        if (i5 != -1) {
                            ArrayRow arrayRow4 = linearSystem.mRows[i5];
                            arrayRow4.variable.definitionId = -1;
                            arrayRow4.pivot(linearSystem.mCache.mIndexedVariables[i6]);
                            SolverVariable solverVariable = arrayRow4.variable;
                            solverVariable.definitionId = i5;
                            solverVariable.updateReferencesWithNewDefinition(linearSystem, arrayRow4);
                            i3 = 0;
                        } else {
                            i3 = 1;
                        }
                        i = ((i2 > linearSystem.mNumColumns / 2 ? 0 : 1) ^ 1) | i3;
                        f = 0.0f;
                    }
                    optimize$ar$class_merging$ar$ds(arrayRow);
                    computeValues();
                }
            }
        }
        optimize$ar$class_merging$ar$ds(arrayRow);
        computeValues();
    }

    private final void addRow(ArrayRow arrayRow) {
        if (arrayRow.isSimpleDefinition) {
            arrayRow.variable.setFinalValue(this, arrayRow.constantValue);
        } else {
            ArrayRow[] arrayRowArr = this.mRows;
            int i = this.mNumRows;
            arrayRowArr[i] = arrayRow;
            SolverVariable solverVariable = arrayRow.variable;
            solverVariable.definitionId = i;
            this.mNumRows = i + 1;
            solverVariable.updateReferencesWithNewDefinition(this, arrayRow);
        }
        if (this.hasSimpleDefinition) {
            int i2 = 0;
            while (i2 < this.mNumRows) {
                if (this.mRows[i2] == null) {
                    System.out.println("WTF");
                }
                ArrayRow arrayRow2 = this.mRows[i2];
                if (arrayRow2 != null && arrayRow2.isSimpleDefinition) {
                    int i3;
                    arrayRow2.variable.setFinalValue(this, arrayRow2.constantValue);
                    this.mCache.arrayRowPool$ar$class_merging.release$ar$ds(arrayRow2);
                    this.mRows[i2] = null;
                    i = i2 + 1;
                    int i4 = i;
                    while (true) {
                        i3 = this.mNumRows;
                        if (i >= i3) {
                            break;
                        }
                        ArrayRow[] arrayRowArr2 = this.mRows;
                        i3 = i - 1;
                        ArrayRow arrayRow3 = arrayRowArr2[i];
                        arrayRowArr2[i3] = arrayRow3;
                        SolverVariable solverVariable2 = arrayRow3.variable;
                        if (solverVariable2.definitionId == i) {
                            solverVariable2.definitionId = i3;
                        }
                        i4 = i;
                        i++;
                    }
                    if (i4 < i3) {
                        this.mRows[i4] = null;
                    }
                    this.mNumRows = i3 - 1;
                    i2--;
                }
                i2++;
            }
            this.hasSimpleDefinition = false;
        }
    }
}
