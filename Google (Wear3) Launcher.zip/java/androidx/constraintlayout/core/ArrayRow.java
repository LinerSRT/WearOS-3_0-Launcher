package androidx.constraintlayout.core;

import java.util.ArrayList;

/* compiled from: PG */
public class ArrayRow {
    public float constantValue = 0.0f;
    boolean isSimpleDefinition = false;
    SolverVariable variable = null;
    public ArrayLinkedVariables variables$ar$class_merging;
    final ArrayList variablesToUpdate = new ArrayList();

    public static final boolean isNew$ar$ds(SolverVariable solverVariable) {
        return solverVariable.usageInRowCount <= 1;
    }

    public final void addError$ar$ds(LinearSystem linearSystem, int i) {
        this.variables$ar$class_merging.put(linearSystem.createErrorVariable$ar$ds(i), 1.0f);
        this.variables$ar$class_merging.put(linearSystem.createErrorVariable$ar$ds(i), -1.0f);
    }

    public final void createRowDimensionRatio$ar$ds(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, SolverVariable solverVariable4, float f) {
        this.variables$ar$class_merging.put(solverVariable, -1.0f);
        this.variables$ar$class_merging.put(solverVariable2, 1.0f);
        this.variables$ar$class_merging.put(solverVariable3, f);
        this.variables$ar$class_merging.put(solverVariable4, -f);
    }

    public final void createRowGreaterThan$ar$ds(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, int i) {
        if (i != 0) {
            Object obj;
            if (i < 0) {
                i = -i;
                obj = 1;
            } else {
                obj = null;
            }
            this.constantValue = (float) i;
            if (obj != null) {
                this.variables$ar$class_merging.put(solverVariable, 1.0f);
                this.variables$ar$class_merging.put(solverVariable2, -1.0f);
                this.variables$ar$class_merging.put(solverVariable3, -1.0f);
                return;
            }
        }
        this.variables$ar$class_merging.put(solverVariable, -1.0f);
        this.variables$ar$class_merging.put(solverVariable2, 1.0f);
        this.variables$ar$class_merging.put(solverVariable3, 1.0f);
    }

    public final void createRowLowerThan$ar$ds(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, int i) {
        if (i != 0) {
            Object obj;
            if (i < 0) {
                i = -i;
                obj = 1;
            } else {
                obj = null;
            }
            this.constantValue = (float) i;
            if (obj != null) {
                this.variables$ar$class_merging.put(solverVariable, 1.0f);
                this.variables$ar$class_merging.put(solverVariable2, -1.0f);
                this.variables$ar$class_merging.put(solverVariable3, 1.0f);
                return;
            }
        }
        this.variables$ar$class_merging.put(solverVariable, -1.0f);
        this.variables$ar$class_merging.put(solverVariable2, 1.0f);
        this.variables$ar$class_merging.put(solverVariable3, -1.0f);
    }

    public final void createRowWithAngle$ar$ds(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, SolverVariable solverVariable4, float f) {
        this.variables$ar$class_merging.put(solverVariable3, 0.5f);
        this.variables$ar$class_merging.put(solverVariable4, 0.5f);
        this.variables$ar$class_merging.put(solverVariable, -0.5f);
        this.variables$ar$class_merging.put(solverVariable2, -0.5f);
        this.constantValue = -f;
    }

    public SolverVariable getPivotCandidate$ar$ds(boolean[] zArr) {
        return pickPivotInVariables(zArr, null);
    }

    public boolean isEmpty() {
        return this.variable == null && this.constantValue == 0.0f && this.variables$ar$class_merging.currentSize == 0;
    }

    public final SolverVariable pickPivotInVariables(boolean[] zArr, SolverVariable solverVariable) {
        int i = this.variables$ar$class_merging.currentSize;
        SolverVariable solverVariable2 = null;
        float f = 0.0f;
        for (int i2 = 0; i2 < i; i2++) {
            float variableValue = this.variables$ar$class_merging.getVariableValue(i2);
            if (variableValue < 0.0f) {
                SolverVariable variable = this.variables$ar$class_merging.getVariable(i2);
                if ((zArr == null || !zArr[variable.f11id]) && variable != solverVariable) {
                    int i3 = variable.mType$ar$edu;
                    if ((i3 == 3 || i3 == 4) && variableValue < f) {
                        f = variableValue;
                        solverVariable2 = variable;
                    }
                }
            }
        }
        return solverVariable2;
    }

    final void pivot(SolverVariable solverVariable) {
        SolverVariable solverVariable2 = this.variable;
        if (solverVariable2 != null) {
            this.variables$ar$class_merging.put(solverVariable2, -1.0f);
            this.variable.definitionId = -1;
            this.variable = null;
        }
        float f = -this.variables$ar$class_merging.remove(solverVariable, true);
        this.variable = solverVariable;
        if (f != 1.0f) {
            this.constantValue /= f;
            ArrayLinkedVariables arrayLinkedVariables = this.variables$ar$class_merging;
            int i = arrayLinkedVariables.mHead;
            int i2 = 0;
            while (i != -1 && i2 < arrayLinkedVariables.currentSize) {
                float[] fArr = arrayLinkedVariables.mArrayValues;
                fArr[i] = fArr[i] / f;
                i = arrayLinkedVariables.mArrayNextIndices[i];
                i2++;
            }
        }
    }

    public final void updateFromFinalVariable(LinearSystem linearSystem, SolverVariable solverVariable, boolean z) {
        if (solverVariable != null) {
            if (solverVariable.isFinalValue) {
                this.constantValue += solverVariable.computedValue * this.variables$ar$class_merging.get(solverVariable);
                this.variables$ar$class_merging.remove(solverVariable, z);
                if (z) {
                    solverVariable.removeFromRow(this);
                }
                if (this.variables$ar$class_merging.currentSize == 0) {
                    this.isSimpleDefinition = true;
                    linearSystem.hasSimpleDefinition = true;
                }
            }
        }
    }

    public void updateFromRow(LinearSystem linearSystem, ArrayRow arrayRow, boolean z) {
        ArrayLinkedVariables arrayLinkedVariables = this.variables$ar$class_merging;
        float f = arrayLinkedVariables.get(arrayRow.variable);
        arrayLinkedVariables.remove(arrayRow.variable, z);
        ArrayLinkedVariables arrayLinkedVariables2 = arrayRow.variables$ar$class_merging;
        int i = arrayLinkedVariables2.currentSize;
        for (int i2 = 0; i2 < i; i2++) {
            SolverVariable variable = arrayLinkedVariables2.getVariable(i2);
            arrayLinkedVariables.add(variable, arrayLinkedVariables2.get(variable) * f, z);
        }
        this.constantValue += arrayRow.constantValue * f;
        if (z) {
            arrayRow.variable.removeFromRow(this);
        }
        if (this.variable != null && this.variables$ar$class_merging.currentSize == 0) {
            this.isSimpleDefinition = true;
            linearSystem.hasSimpleDefinition = true;
        }
    }

    public ArrayRow(Cache cache) {
        this.variables$ar$class_merging = new ArrayLinkedVariables(this, cache);
    }

    public String toString() {
        Object obj;
        String valueOf;
        Object obj2;
        SolverVariable solverVariable = this.variable;
        if (solverVariable == null) {
            obj = "0";
        } else {
            valueOf = String.valueOf(solverVariable);
            StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf).length());
            stringBuilder.append("");
            stringBuilder.append(valueOf);
            obj = stringBuilder.toString();
        }
        valueOf = String.valueOf(obj).concat(" = ");
        if (this.constantValue != 0.0f) {
            valueOf = String.valueOf(valueOf);
            float f = this.constantValue;
            StringBuilder stringBuilder2 = new StringBuilder(String.valueOf(valueOf).length() + 15);
            stringBuilder2.append(valueOf);
            stringBuilder2.append(f);
            valueOf = stringBuilder2.toString();
            obj2 = 1;
        } else {
            obj2 = null;
        }
        int i = this.variables$ar$class_merging.currentSize;
        for (int i2 = 0; i2 < i; i2++) {
            SolverVariable variable = this.variables$ar$class_merging.getVariable(i2);
            if (variable != null) {
                float variableValue = this.variables$ar$class_merging.getVariableValue(i2);
                if (variableValue != 0.0f) {
                    String solverVariable2 = variable.toString();
                    if (obj2 == null) {
                        if (variableValue < 0.0f) {
                            obj = String.valueOf(valueOf).concat("- ");
                            variableValue = -variableValue;
                        }
                    } else if (variableValue > 0.0f) {
                        obj = String.valueOf(valueOf).concat(" + ");
                    } else {
                        obj = String.valueOf(valueOf).concat(" - ");
                        variableValue = -variableValue;
                    }
                    if (variableValue == 1.0f) {
                        valueOf = String.valueOf(obj);
                        String valueOf2 = String.valueOf(solverVariable2);
                        valueOf = valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
                    } else {
                        valueOf = String.valueOf(obj);
                        StringBuilder stringBuilder3 = new StringBuilder((String.valueOf(valueOf).length() + 16) + String.valueOf(solverVariable2).length());
                        stringBuilder3.append(valueOf);
                        stringBuilder3.append(variableValue);
                        stringBuilder3.append(" ");
                        stringBuilder3.append(solverVariable2);
                        valueOf = stringBuilder3.toString();
                    }
                    obj2 = 1;
                }
            }
        }
        return obj2 == null ? String.valueOf(valueOf).concat("0.0") : valueOf;
    }
}
