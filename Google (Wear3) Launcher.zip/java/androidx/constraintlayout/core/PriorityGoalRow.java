package androidx.constraintlayout.core;

import java.util.Arrays;
import java.util.Comparator;

/* compiled from: PG */
public final class PriorityGoalRow extends ArrayRow {
    final GoalVariableAccessor accessor = new GoalVariableAccessor();
    private SolverVariable[] arrayGoals = new SolverVariable[128];
    public int numGoals = 0;
    private SolverVariable[] sortArray = new SolverVariable[128];

    /* renamed from: androidx.constraintlayout.core.PriorityGoalRow$1 */
    final class PG implements Comparator {
        public final /* bridge */ /* synthetic */ int compare(Object obj, Object obj2) {
            return ((SolverVariable) obj).f11id - ((SolverVariable) obj2).f11id;
        }
    }

    /* compiled from: PG */
    final class GoalVariableAccessor {
        SolverVariable variable;

        public final String toString() {
            String valueOf;
            StringBuilder stringBuilder;
            Object obj = "[ ";
            if (this.variable != null) {
                for (int i = 0; i < 9; i++) {
                    valueOf = String.valueOf(obj);
                    float f = this.variable.goalStrengthVector[i];
                    stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 16);
                    stringBuilder.append(valueOf);
                    stringBuilder.append(f);
                    stringBuilder.append(" ");
                    obj = stringBuilder.toString();
                }
            }
            String valueOf2 = String.valueOf(obj);
            valueOf = String.valueOf(this.variable);
            stringBuilder = new StringBuilder((String.valueOf(valueOf2).length() + 2) + String.valueOf(valueOf).length());
            stringBuilder.append(valueOf2);
            stringBuilder.append("] ");
            stringBuilder.append(valueOf);
            return stringBuilder.toString();
        }
    }

    public PriorityGoalRow(Cache cache) {
        super(cache);
    }

    public final void addToGoal(SolverVariable solverVariable) {
        SolverVariable[] solverVariableArr;
        int length;
        int i = this.numGoals;
        SolverVariable[] solverVariableArr2 = this.arrayGoals;
        int length2 = solverVariableArr2.length;
        if (i + 1 > length2) {
            solverVariableArr = (SolverVariable[]) Arrays.copyOf(solverVariableArr2, length2 + length2);
            this.arrayGoals = solverVariableArr;
            length = solverVariableArr.length;
            this.sortArray = (SolverVariable[]) Arrays.copyOf(solverVariableArr, length + length);
        }
        solverVariableArr = this.arrayGoals;
        length = this.numGoals;
        solverVariableArr[length] = solverVariable;
        length++;
        this.numGoals = length;
        if (length > 1 && solverVariableArr[length - 1].f11id > solverVariable.f11id) {
            i = 0;
            length = 0;
            while (true) {
                length2 = this.numGoals;
                if (length >= length2) {
                    break;
                }
                this.sortArray[length] = this.arrayGoals[length];
                length++;
            }
            Arrays.sort(this.sortArray, 0, length2, new PG());
            while (i < this.numGoals) {
                this.arrayGoals[i] = this.sortArray[i];
                i++;
            }
        }
        solverVariable.inGoal = true;
        solverVariable.addToRow(this);
    }

    public final SolverVariable getPivotCandidate$ar$ds(boolean[] zArr) {
        int i = -1;
        for (int i2 = 0; i2 < this.numGoals; i2++) {
            SolverVariable[] solverVariableArr = this.arrayGoals;
            SolverVariable solverVariable = solverVariableArr[i2];
            if (!zArr[solverVariable.f11id]) {
                GoalVariableAccessor goalVariableAccessor = this.accessor;
                goalVariableAccessor.variable = solverVariable;
                int i3 = 8;
                if (i == -1) {
                    while (i3 >= 0) {
                        float f = goalVariableAccessor.variable.goalStrengthVector[i3];
                        if (f > 0.0f) {
                            break;
                        } else if (f >= 0.0f) {
                            i3--;
                        }
                    }
                } else {
                    SolverVariable solverVariable2 = solverVariableArr[i];
                    while (i3 >= 0) {
                        float f2 = solverVariable2.goalStrengthVector[i3];
                        float f3 = goalVariableAccessor.variable.goalStrengthVector[i3];
                        if (f3 == f2) {
                            i3--;
                        } else if (f3 >= f2) {
                        }
                    }
                }
                i = i2;
            }
        }
        if (i == -1) {
            return null;
        }
        return this.arrayGoals[i];
    }

    public final boolean isEmpty() {
        return this.numGoals == 0;
    }

    public final void removeGoal(SolverVariable solverVariable) {
        int i = 0;
        while (i < this.numGoals) {
            if (this.arrayGoals[i] == solverVariable) {
                while (true) {
                    int i2 = this.numGoals - 1;
                    if (i < i2) {
                        SolverVariable[] solverVariableArr = this.arrayGoals;
                        int i3 = i + 1;
                        solverVariableArr[i] = solverVariableArr[i3];
                        i = i3;
                    } else {
                        this.numGoals = i2;
                        solverVariable.inGoal = false;
                        return;
                    }
                }
            }
            i++;
        }
    }

    public final String toString() {
        float f = this.constantValue;
        StringBuilder stringBuilder = new StringBuilder(29);
        stringBuilder.append(" goal -> (");
        stringBuilder.append(f);
        stringBuilder.append(") : ");
        String stringBuilder2 = stringBuilder.toString();
        for (int i = 0; i < this.numGoals; i++) {
            this.accessor.variable = this.arrayGoals[i];
            stringBuilder2 = String.valueOf(stringBuilder2);
            String valueOf = String.valueOf(this.accessor);
            StringBuilder stringBuilder3 = new StringBuilder((String.valueOf(stringBuilder2).length() + 1) + String.valueOf(valueOf).length());
            stringBuilder3.append(stringBuilder2);
            stringBuilder3.append(valueOf);
            stringBuilder3.append(" ");
            stringBuilder2 = stringBuilder3.toString();
        }
        return stringBuilder2;
    }

    public final void updateFromRow(LinearSystem linearSystem, ArrayRow arrayRow, boolean z) {
        ArrayRow arrayRow2 = this;
        ArrayRow arrayRow3 = arrayRow;
        SolverVariable solverVariable = arrayRow3.variable;
        if (solverVariable != null) {
            ArrayLinkedVariables arrayLinkedVariables = arrayRow3.variables$ar$class_merging;
            int i = arrayLinkedVariables.currentSize;
            for (int i2 = 0; i2 < i; i2++) {
                SolverVariable variable = arrayLinkedVariables.getVariable(i2);
                float variableValue = arrayLinkedVariables.getVariableValue(i2);
                GoalVariableAccessor goalVariableAccessor = arrayRow2.accessor;
                goalVariableAccessor.variable = variable;
                if (goalVariableAccessor.variable.inGoal) {
                    Object obj = 1;
                    for (int i3 = 0; i3 < 9; i3++) {
                        float[] fArr = goalVariableAccessor.variable.goalStrengthVector;
                        float f = fArr[i3] + (solverVariable.goalStrengthVector[i3] * variableValue);
                        fArr[i3] = f;
                        if (Math.abs(f) < 1.0E-4f) {
                            goalVariableAccessor.variable.goalStrengthVector[i3] = 0.0f;
                        } else {
                            obj = null;
                        }
                    }
                    if (obj != null) {
                        goalVariableAccessor.this$0.removeGoal(goalVariableAccessor.variable);
                    }
                } else {
                    for (int i4 = 0; i4 < 9; i4++) {
                        float f2 = solverVariable.goalStrengthVector[i4];
                        if (f2 != 0.0f) {
                            f2 *= variableValue;
                            if (Math.abs(f2) < 1.0E-4f) {
                                f2 = 0.0f;
                            }
                            goalVariableAccessor.variable.goalStrengthVector[i4] = f2;
                        } else {
                            goalVariableAccessor.variable.goalStrengthVector[i4] = 0.0f;
                        }
                    }
                    addToGoal(variable);
                }
                arrayRow2.constantValue += arrayRow3.constantValue * variableValue;
            }
            removeGoal(solverVariable);
        }
    }
}
