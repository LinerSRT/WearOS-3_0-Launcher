package androidx.constraintlayout.core;

import java.util.Arrays;

/* compiled from: PG */
public final class ArrayLinkedVariables {
    private int ROW_SIZE = 8;
    int currentSize = 0;
    public int[] mArrayIndices = new int[8];
    public int[] mArrayNextIndices = new int[8];
    public float[] mArrayValues = new float[8];
    protected final Cache mCache;
    private boolean mDidFillOnce = false;
    public int mHead = -1;
    private int mLast = -1;
    private final ArrayRow mRow;

    public ArrayLinkedVariables(ArrayRow arrayRow, Cache cache) {
        this.mRow = arrayRow;
        this.mCache = cache;
    }

    public final void clear() {
        int i = this.mHead;
        int i2 = 0;
        while (i != -1 && i2 < this.currentSize) {
            SolverVariable solverVariable = this.mCache.mIndexedVariables[this.mArrayIndices[i]];
            if (solverVariable != null) {
                solverVariable.removeFromRow(this.mRow);
            }
            i = this.mArrayNextIndices[i];
            i2++;
        }
        this.mHead = -1;
        this.mLast = -1;
        this.mDidFillOnce = false;
        this.currentSize = 0;
    }

    public final float get(SolverVariable solverVariable) {
        int i = this.mHead;
        int i2 = 0;
        while (i != -1 && i2 < this.currentSize) {
            if (this.mArrayIndices[i] == solverVariable.f11id) {
                return this.mArrayValues[i];
            }
            i = this.mArrayNextIndices[i];
            i2++;
        }
        return 0.0f;
    }

    public final void put(SolverVariable solverVariable, float f) {
        if (f == 0.0f) {
            remove(solverVariable, true);
            return;
        }
        int i = this.mHead;
        int length;
        if (i == -1) {
            this.mHead = 0;
            this.mArrayValues[0] = f;
            this.mArrayIndices[0] = solverVariable.f11id;
            this.mArrayNextIndices[0] = -1;
            solverVariable.usageInRowCount++;
            solverVariable.addToRow(this.mRow);
            this.currentSize++;
            if (!this.mDidFillOnce) {
                int i2;
                i2 = this.mLast + 1;
                this.mLast = i2;
                length = this.mArrayIndices.length;
                if (i2 >= length) {
                    this.mDidFillOnce = true;
                    this.mLast = length - 1;
                }
            }
            return;
        }
        int i3 = 0;
        int i4 = -1;
        while (i != -1 && i3 < this.currentSize) {
            int i5 = this.mArrayIndices[i];
            int i6 = solverVariable.f11id;
            if (i5 == i6) {
                this.mArrayValues[i] = f;
                return;
            }
            if (i5 < i6) {
                i4 = i;
            }
            i = this.mArrayNextIndices[i];
            i3++;
        }
        i = this.mLast;
        i3 = i + 1;
        if (this.mDidFillOnce) {
            int[] iArr = this.mArrayIndices;
            if (iArr[i] != -1) {
                i = iArr.length;
            }
        } else {
            i = i3;
        }
        i3 = this.mArrayIndices.length;
        if (i >= i3 && this.currentSize < i3) {
            i3 = 0;
            while (true) {
                int[] iArr2 = this.mArrayIndices;
                if (i3 >= iArr2.length) {
                    break;
                } else if (iArr2[i3] == -1) {
                    break;
                } else {
                    i3++;
                }
            }
            i = i3;
        }
        i3 = this.mArrayIndices.length;
        if (i >= i3) {
            i = this.ROW_SIZE;
            i += i;
            this.ROW_SIZE = i;
            this.mDidFillOnce = false;
            this.mLast = i3 - 1;
            this.mArrayValues = Arrays.copyOf(this.mArrayValues, i);
            this.mArrayIndices = Arrays.copyOf(this.mArrayIndices, this.ROW_SIZE);
            this.mArrayNextIndices = Arrays.copyOf(this.mArrayNextIndices, this.ROW_SIZE);
            i = i3;
        }
        this.mArrayIndices[i] = solverVariable.f11id;
        this.mArrayValues[i] = f;
        if (i4 != -1) {
            int[] iArr3 = this.mArrayNextIndices;
            iArr3[i] = iArr3[i4];
            iArr3[i4] = i;
        } else {
            this.mArrayNextIndices[i] = this.mHead;
            this.mHead = i;
        }
        solverVariable.usageInRowCount++;
        solverVariable.addToRow(this.mRow);
        i2 = this.currentSize + 1;
        this.currentSize = i2;
        if (!this.mDidFillOnce) {
            this.mLast++;
        }
        length = this.mArrayIndices.length;
        if (i2 >= length) {
            this.mDidFillOnce = true;
        }
        if (this.mLast >= length) {
            this.mDidFillOnce = true;
            this.mLast = length - 1;
        }
    }

    public final float remove(SolverVariable solverVariable, boolean z) {
        int i = this.mHead;
        if (i != -1) {
            int i2 = 0;
            int i3 = -1;
            while (i != -1 && i2 < this.currentSize) {
                if (this.mArrayIndices[i] == solverVariable.f11id) {
                    if (i == this.mHead) {
                        this.mHead = this.mArrayNextIndices[i];
                    } else {
                        int[] iArr = this.mArrayNextIndices;
                        iArr[i3] = iArr[i];
                    }
                    if (z) {
                        solverVariable.removeFromRow(this.mRow);
                    }
                    solverVariable.usageInRowCount--;
                    this.currentSize--;
                    this.mArrayIndices[i] = -1;
                    if (this.mDidFillOnce) {
                        this.mLast = i;
                    }
                    return this.mArrayValues[i];
                }
                i2++;
                i3 = i;
                i = this.mArrayNextIndices[i];
            }
        }
        return 0.0f;
    }

    public final String toString() {
        int i = this.mHead;
        String str = "";
        int i2 = 0;
        while (i != -1 && i2 < this.currentSize) {
            str = String.valueOf(String.valueOf(str).concat(" -> "));
            float f = this.mArrayValues[i];
            StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 18);
            stringBuilder.append(str);
            stringBuilder.append(f);
            stringBuilder.append(" : ");
            str = String.valueOf(stringBuilder.toString());
            String valueOf = String.valueOf(this.mCache.mIndexedVariables[this.mArrayIndices[i]]);
            StringBuilder stringBuilder2 = new StringBuilder(String.valueOf(str).length() + String.valueOf(valueOf).length());
            stringBuilder2.append(str);
            stringBuilder2.append(valueOf);
            str = stringBuilder2.toString();
            i = this.mArrayNextIndices[i];
            i2++;
        }
        return str;
    }

    public final SolverVariable getVariable(int i) {
        int i2 = this.mHead;
        int i3 = 0;
        while (i2 != -1 && i3 < this.currentSize) {
            if (i3 == i) {
                return this.mCache.mIndexedVariables[this.mArrayIndices[i2]];
            }
            i2 = this.mArrayNextIndices[i2];
            i3++;
        }
        return null;
    }

    public final float getVariableValue(int i) {
        int i2 = this.mHead;
        int i3 = 0;
        while (i2 != -1 && i3 < this.currentSize) {
            if (i3 == i) {
                return this.mArrayValues[i2];
            }
            i2 = this.mArrayNextIndices[i2];
            i3++;
        }
        return 0.0f;
    }

    public final void add(SolverVariable solverVariable, float f, boolean z) {
        if (f > -0.001f) {
            if (f < 0.001f) {
                return;
            }
        }
        int i = this.mHead;
        int length;
        if (i == -1) {
            this.mHead = 0;
            this.mArrayValues[0] = f;
            this.mArrayIndices[0] = solverVariable.f11id;
            this.mArrayNextIndices[0] = -1;
            solverVariable.usageInRowCount++;
            solverVariable.addToRow(this.mRow);
            this.currentSize++;
            if (!this.mDidFillOnce) {
                int i2;
                i2 = this.mLast + 1;
                this.mLast = i2;
                length = this.mArrayIndices.length;
                if (i2 >= length) {
                    this.mDidFillOnce = true;
                    this.mLast = length - 1;
                }
            }
            return;
        }
        int i3 = 0;
        int i4 = -1;
        while (i != -1 && i3 < this.currentSize) {
            int i5 = this.mArrayIndices[i];
            int i6 = solverVariable.f11id;
            if (i5 == i6) {
                float[] fArr = this.mArrayValues;
                float f2 = fArr[i] + f;
                if (f2 > -0.001f && f2 < 0.001f) {
                    f2 = 0.0f;
                }
                fArr[i] = f2;
                if (f2 == 0.0f) {
                    if (i == this.mHead) {
                        this.mHead = this.mArrayNextIndices[i];
                    } else {
                        int[] iArr = this.mArrayNextIndices;
                        iArr[i4] = iArr[i];
                    }
                    if (z) {
                        solverVariable.removeFromRow(this.mRow);
                    }
                    if (this.mDidFillOnce) {
                        this.mLast = i;
                    }
                    solverVariable.usageInRowCount--;
                    this.currentSize--;
                    return;
                }
                return;
            }
            if (i5 < i6) {
                i4 = i;
            }
            i = this.mArrayNextIndices[i];
            i3++;
        }
        int i7 = this.mLast;
        int i8 = i7 + 1;
        if (this.mDidFillOnce) {
            int[] iArr2 = this.mArrayIndices;
            if (iArr2[i7] != -1) {
                i7 = iArr2.length;
            }
        } else {
            i7 = i8;
        }
        i8 = this.mArrayIndices.length;
        if (i7 >= i8 && this.currentSize < i8) {
            i8 = 0;
            while (true) {
                int[] iArr3 = this.mArrayIndices;
                if (i8 >= iArr3.length) {
                    break;
                } else if (iArr3[i8] == -1) {
                    break;
                } else {
                    i8++;
                }
            }
            i7 = i8;
        }
        i8 = this.mArrayIndices.length;
        if (i7 >= i8) {
            i7 = this.ROW_SIZE;
            i7 += i7;
            this.ROW_SIZE = i7;
            this.mDidFillOnce = false;
            this.mLast = i8 - 1;
            this.mArrayValues = Arrays.copyOf(this.mArrayValues, i7);
            this.mArrayIndices = Arrays.copyOf(this.mArrayIndices, this.ROW_SIZE);
            this.mArrayNextIndices = Arrays.copyOf(this.mArrayNextIndices, this.ROW_SIZE);
            i7 = i8;
        }
        this.mArrayIndices[i7] = solverVariable.f11id;
        this.mArrayValues[i7] = f;
        if (i4 != -1) {
            iArr = this.mArrayNextIndices;
            iArr[i7] = iArr[i4];
            iArr[i4] = i7;
        } else {
            this.mArrayNextIndices[i7] = this.mHead;
            this.mHead = i7;
        }
        solverVariable.usageInRowCount++;
        solverVariable.addToRow(this.mRow);
        this.currentSize++;
        if (!this.mDidFillOnce) {
            this.mLast++;
        }
        i2 = this.mLast;
        length = this.mArrayIndices.length;
        if (i2 >= length) {
            this.mDidFillOnce = true;
            this.mLast = length - 1;
        }
    }
}
