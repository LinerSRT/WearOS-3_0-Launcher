package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.Guideline;
import androidx.constraintlayout.core.widgets.HelperWidget;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure.Measure;
import androidx.constraintlayout.widget.ConstraintLayout.Measurer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

/* compiled from: PG */
public final class DependencyGraph {
    public final ConstraintWidgetContainer container;
    public final ConstraintWidgetContainer mContainer;
    final ArrayList mGroups;
    private final Measure mMeasure;
    public Measurer mMeasurer$ar$class_merging;
    public boolean mNeedBuildGraph = true;
    public boolean mNeedRedoMeasures = true;
    public final ArrayList mRuns = new ArrayList();

    public DependencyGraph(ConstraintWidgetContainer constraintWidgetContainer) {
        ArrayList arrayList = new ArrayList();
        this.mMeasurer$ar$class_merging = null;
        this.mMeasure = new Measure();
        this.mGroups = new ArrayList();
        this.container = constraintWidgetContainer;
        this.mContainer = constraintWidgetContainer;
    }

    private final void applyGroup$ar$ds(DependencyNode dependencyNode, int i, DependencyNode dependencyNode2, ArrayList arrayList, RunGroup runGroup) {
        WidgetRun widgetRun = dependencyNode.run;
        if (widgetRun.runGroup == null) {
            ConstraintWidget constraintWidget = this.container;
            if (widgetRun != constraintWidget.horizontalRun) {
                if (widgetRun != constraintWidget.verticalRun) {
                    if (runGroup == null) {
                        runGroup = new RunGroup(widgetRun);
                        arrayList.add(runGroup);
                    }
                    widgetRun.runGroup = runGroup;
                    runGroup.runs.add(widgetRun);
                    for (Dependency dependency : widgetRun.start.dependencies) {
                        if (dependency instanceof DependencyNode) {
                            applyGroup$ar$ds((DependencyNode) dependency, i, dependencyNode2, arrayList, runGroup);
                        }
                    }
                    for (Dependency dependency2 : widgetRun.end.dependencies) {
                        if (dependency2 instanceof DependencyNode) {
                            applyGroup$ar$ds((DependencyNode) dependency2, i, dependencyNode2, arrayList, runGroup);
                        }
                    }
                    if (i == 1 && (widgetRun instanceof VerticalWidgetRun)) {
                        for (Dependency dependency22 : ((VerticalWidgetRun) widgetRun).baseline.dependencies) {
                            if (dependency22 instanceof DependencyNode) {
                                applyGroup$ar$ds((DependencyNode) dependency22, 1, dependencyNode2, arrayList, runGroup);
                            }
                        }
                    }
                    for (DependencyNode applyGroup$ar$ds : widgetRun.start.targets) {
                        applyGroup$ar$ds(applyGroup$ar$ds, i, dependencyNode2, arrayList, runGroup);
                    }
                    for (DependencyNode applyGroup$ar$ds2 : widgetRun.end.targets) {
                        applyGroup$ar$ds(applyGroup$ar$ds2, i, dependencyNode2, arrayList, runGroup);
                    }
                    if (i == 1 && (widgetRun instanceof VerticalWidgetRun)) {
                        for (DependencyNode applyGroup$ar$ds22 : ((VerticalWidgetRun) widgetRun).baseline.targets) {
                            applyGroup$ar$ds(applyGroup$ar$ds22, 1, dependencyNode2, arrayList, runGroup);
                        }
                    }
                }
            }
        }
    }

    private final void findGroup(WidgetRun widgetRun, int i, ArrayList arrayList) {
        for (Dependency dependency : widgetRun.start.dependencies) {
            if (dependency instanceof DependencyNode) {
                applyGroup$ar$ds((DependencyNode) dependency, i, widgetRun.end, arrayList, null);
            } else if (dependency instanceof WidgetRun) {
                applyGroup$ar$ds(((WidgetRun) dependency).start, i, widgetRun.end, arrayList, null);
            }
        }
        for (Dependency dependency2 : widgetRun.end.dependencies) {
            if (dependency2 instanceof DependencyNode) {
                applyGroup$ar$ds((DependencyNode) dependency2, i, widgetRun.start, arrayList, null);
            } else if (dependency2 instanceof WidgetRun) {
                applyGroup$ar$ds(((WidgetRun) dependency2).end, i, widgetRun.start, arrayList, null);
            }
        }
        if (i == 1) {
            for (Dependency dependency3 : ((VerticalWidgetRun) widgetRun).baseline.dependencies) {
                if (dependency3 instanceof DependencyNode) {
                    applyGroup$ar$ds((DependencyNode) dependency3, 1, null, arrayList, null);
                }
            }
        }
    }

    private final void measure$ar$edu(ConstraintWidget constraintWidget, int i, int i2, int i3, int i4) {
        Measure measure = this.mMeasure;
        measure.horizontalBehavior$ar$edu = i;
        measure.verticalBehavior$ar$edu = i3;
        measure.horizontalDimension = i2;
        measure.verticalDimension = i4;
        this.mMeasurer$ar$class_merging.measure(constraintWidget, measure);
        constraintWidget.setWidth(this.mMeasure.measuredWidth);
        constraintWidget.setHeight(this.mMeasure.measuredHeight);
        Measure measure2 = this.mMeasure;
        constraintWidget.hasBaseline = measure2.measuredHasBaseline;
        constraintWidget.setBaselineDistance(measure2.measuredBaseline);
    }

    public final void basicMeasureWidgets$ar$ds(ConstraintWidgetContainer constraintWidgetContainer) {
        ConstraintWidget constraintWidget = constraintWidgetContainer;
        List list = constraintWidget.mChildren;
        int size = list.size();
        int i = 0;
        int i2 = 0;
        while (i2 < size) {
            ConstraintWidget constraintWidget2 = (ConstraintWidget) list.get(i2);
            int[] iArr = constraintWidget2.mListDimensionBehaviors$ar$edu;
            int i3 = iArr[i];
            int i4 = iArr[1];
            if (constraintWidget2.mVisibility == 8) {
                constraintWidget2.measured = true;
            } else {
                int i5;
                WidgetRun widgetRun;
                int i6;
                int i7;
                int height;
                int width;
                ConstraintAnchor[] constraintAnchorArr;
                int i8;
                float f = constraintWidget2.mMatchConstraintPercentWidth;
                int i9 = 2;
                if (f < 1.0f && i3 == 3) {
                    constraintWidget2.mMatchConstraintDefaultWidth = 2;
                    i3 = 3;
                }
                float f2 = constraintWidget2.mMatchConstraintPercentHeight;
                if (f2 < 1.0f && i4 == 3) {
                    constraintWidget2.mMatchConstraintDefaultHeight = 2;
                    i4 = 3;
                }
                if (constraintWidget2.mDimensionRatio > 0.0f) {
                    if (i3 == 3 && (i4 == 2 || i4 == 1)) {
                        constraintWidget2.mMatchConstraintDefaultWidth = 3;
                    } else if (i4 == 3 && (i3 == 2 || i3 == 1)) {
                        constraintWidget2.mMatchConstraintDefaultHeight = 3;
                    } else if (i3 == 3 && i4 == 3) {
                        if (constraintWidget2.mMatchConstraintDefaultWidth == 0) {
                            constraintWidget2.mMatchConstraintDefaultWidth = 3;
                        }
                        if (constraintWidget2.mMatchConstraintDefaultHeight == 0) {
                            constraintWidget2.mMatchConstraintDefaultHeight = 3;
                        }
                    }
                }
                if (i3 == 3 && constraintWidget2.mMatchConstraintDefaultWidth == 1) {
                    if (constraintWidget2.mLeft.mTarget == null) {
                        i3 = 2;
                    } else if (constraintWidget2.mRight.mTarget == null) {
                        i3 = 2;
                    }
                }
                if (i4 == 3 && constraintWidget2.mMatchConstraintDefaultHeight == 1) {
                    if (constraintWidget2.mTop.mTarget == null) {
                        i5 = 2;
                    } else if (constraintWidget2.mBottom.mTarget == null) {
                        i5 = 2;
                    }
                    widgetRun = constraintWidget2.horizontalRun;
                    widgetRun.dimensionBehavior$ar$edu = i3;
                    i6 = constraintWidget2.mMatchConstraintDefaultWidth;
                    widgetRun.matchConstraintsType = i6;
                    widgetRun = constraintWidget2.verticalRun;
                    widgetRun.dimensionBehavior$ar$edu = i5;
                    i7 = constraintWidget2.mMatchConstraintDefaultHeight;
                    widgetRun.matchConstraintsType = i7;
                    if (!(i3 == 4 || i3 == 1)) {
                        if (i3 == 2) {
                            i3 = 2;
                        }
                        if (i3 == 3 && (i5 == 2 || i5 == 1)) {
                            if (i6 != 3) {
                                if (i5 == 2) {
                                    measure$ar$edu(constraintWidget2, 2, 0, 2, 0);
                                }
                                height = constraintWidget2.getHeight();
                                measure$ar$edu(constraintWidget2, 1, (int) ((((float) height) * constraintWidget2.mDimensionRatio) + 0.5f), 1, height);
                                constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                                constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                                constraintWidget2.measured = true;
                            } else if (i6 != 1) {
                                measure$ar$edu(constraintWidget2, 2, 0, i5, 0);
                                constraintWidget2.horizontalRun.dimension.wrapValue = constraintWidget2.getWidth();
                            } else if (i6 == 2) {
                                i9 = constraintWidget.mListDimensionBehaviors$ar$edu[i];
                                if (i9 == 1 || i9 == 4) {
                                    width = (int) ((f * ((float) constraintWidgetContainer.getWidth())) + 0.5f);
                                    measure$ar$edu(constraintWidget2, 1, width, i5, constraintWidget2.getHeight());
                                    constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                                    constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                                    constraintWidget2.measured = true;
                                }
                            } else {
                                constraintAnchorArr = constraintWidget2.mListAnchors;
                                if (constraintAnchorArr[i].mTarget == null || constraintAnchorArr[1].mTarget == null) {
                                    measure$ar$edu(constraintWidget2, 2, 0, i5, 0);
                                    constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                                    constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                                    constraintWidget2.measured = true;
                                }
                            }
                        }
                        if (i5 == 3) {
                            if (i3 != 2) {
                                if (i3 != 1) {
                                    i9 = i3;
                                }
                            }
                            if (i7 == 3) {
                                if (i3 == 2) {
                                    measure$ar$edu(constraintWidget2, 2, 0, 2, 0);
                                }
                                i9 = constraintWidget2.getWidth();
                                float f3 = constraintWidget2.mDimensionRatio;
                                if (constraintWidget2.mDimensionRatioSide == -1) {
                                    f3 = 1.0f / f3;
                                }
                                measure$ar$edu(constraintWidget2, 1, i9, 1, (int) ((((float) i9) * f3) + 0.5f));
                                constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                                constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                                constraintWidget2.measured = true;
                            } else if (i7 == 1) {
                                measure$ar$edu(constraintWidget2, i3, 0, 2, 0);
                                constraintWidget2.verticalRun.dimension.wrapValue = constraintWidget2.getHeight();
                            } else {
                                i9 = i3;
                                if (i7 == 2) {
                                    i4 = constraintWidget.mListDimensionBehaviors$ar$edu[1];
                                    if (i4 == 1 || i4 == 4) {
                                        measure$ar$edu(constraintWidget2, i9, constraintWidget2.getWidth(), 1, (int) ((f2 * ((float) constraintWidgetContainer.getHeight())) + 0.5f));
                                        constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                                        constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                                        constraintWidget2.measured = true;
                                    }
                                } else {
                                    ConstraintAnchor[] constraintAnchorArr2 = constraintWidget2.mListAnchors;
                                    if (constraintAnchorArr2[2].mTarget == null || constraintAnchorArr2[3].mTarget == null) {
                                        measure$ar$edu(constraintWidget2, 2, 0, 3, 0);
                                        constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                                        constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                                        constraintWidget2.measured = true;
                                    }
                                }
                            }
                        } else {
                            i9 = i3;
                        }
                        if (i9 == 3 && i5 == 3) {
                            if (i6 != 1) {
                                if (i7 != 1) {
                                    if (i7 == 2 && i6 == 2) {
                                        int[] iArr2 = constraintWidget.mListDimensionBehaviors$ar$edu;
                                        if (iArr2[0] == 1 && iArr2[1] == 1) {
                                            measure$ar$edu(constraintWidget2, 1, (int) ((f * ((float) constraintWidgetContainer.getWidth())) + 0.5f), 1, (int) ((f2 * ((float) constraintWidgetContainer.getHeight())) + 0.5f));
                                            constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                                            constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                                            constraintWidget2.measured = true;
                                        }
                                    }
                                }
                            }
                            measure$ar$edu(constraintWidget2, 2, 0, 2, 0);
                            constraintWidget2.horizontalRun.dimension.wrapValue = constraintWidget2.getWidth();
                            constraintWidget2.verticalRun.dimension.wrapValue = constraintWidget2.getHeight();
                        }
                    }
                    if (i5 != 4 || i5 == 1) {
                        i9 = i5;
                    } else {
                        if (i5 == 2) {
                        }
                        if (i6 != 3) {
                            if (i5 == 2) {
                                measure$ar$edu(constraintWidget2, 2, 0, 2, 0);
                            }
                            height = constraintWidget2.getHeight();
                            measure$ar$edu(constraintWidget2, 1, (int) ((((float) height) * constraintWidget2.mDimensionRatio) + 0.5f), 1, height);
                            constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                            constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                            constraintWidget2.measured = true;
                        } else if (i6 != 1) {
                            measure$ar$edu(constraintWidget2, 2, 0, i5, 0);
                            constraintWidget2.horizontalRun.dimension.wrapValue = constraintWidget2.getWidth();
                        } else if (i6 == 2) {
                            constraintAnchorArr = constraintWidget2.mListAnchors;
                            measure$ar$edu(constraintWidget2, 2, 0, i5, 0);
                            constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                            constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                            constraintWidget2.measured = true;
                        } else {
                            i9 = constraintWidget.mListDimensionBehaviors$ar$edu[i];
                            width = (int) ((f * ((float) constraintWidgetContainer.getWidth())) + 0.5f);
                            measure$ar$edu(constraintWidget2, 1, width, i5, constraintWidget2.getHeight());
                            constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                            constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                            constraintWidget2.measured = true;
                        }
                    }
                    i = constraintWidget2.getWidth();
                    if (i3 != 4) {
                        i = (constraintWidgetContainer.getWidth() - constraintWidget2.mLeft.mMargin) - constraintWidget2.mRight.mMargin;
                        i8 = 1;
                    } else {
                        i8 = i3;
                    }
                    i4 = constraintWidget2.getHeight();
                    if (i9 != 4) {
                        height = (constraintWidgetContainer.getHeight() - constraintWidget2.mTop.mMargin) - constraintWidget2.mBottom.mMargin;
                        width = 1;
                    } else {
                        height = i4;
                        width = i9;
                    }
                    measure$ar$edu(constraintWidget2, i8, i, width, height);
                    constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                    constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                    constraintWidget2.measured = true;
                }
                i5 = i4;
                widgetRun = constraintWidget2.horizontalRun;
                widgetRun.dimensionBehavior$ar$edu = i3;
                i6 = constraintWidget2.mMatchConstraintDefaultWidth;
                widgetRun.matchConstraintsType = i6;
                widgetRun = constraintWidget2.verticalRun;
                widgetRun.dimensionBehavior$ar$edu = i5;
                i7 = constraintWidget2.mMatchConstraintDefaultHeight;
                widgetRun.matchConstraintsType = i7;
                if (i3 == 2) {
                    i3 = 2;
                    if (i5 != 4) {
                    }
                    i9 = i5;
                    i = constraintWidget2.getWidth();
                    if (i3 != 4) {
                        i8 = i3;
                    } else {
                        i = (constraintWidgetContainer.getWidth() - constraintWidget2.mLeft.mMargin) - constraintWidget2.mRight.mMargin;
                        i8 = 1;
                    }
                    i4 = constraintWidget2.getHeight();
                    if (i9 != 4) {
                        height = i4;
                        width = i9;
                    } else {
                        height = (constraintWidgetContainer.getHeight() - constraintWidget2.mTop.mMargin) - constraintWidget2.mBottom.mMargin;
                        width = 1;
                    }
                    measure$ar$edu(constraintWidget2, i8, i, width, height);
                    constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                    constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                    constraintWidget2.measured = true;
                }
                if (i6 != 3) {
                    if (i5 == 2) {
                        measure$ar$edu(constraintWidget2, 2, 0, 2, 0);
                    }
                    height = constraintWidget2.getHeight();
                    measure$ar$edu(constraintWidget2, 1, (int) ((((float) height) * constraintWidget2.mDimensionRatio) + 0.5f), 1, height);
                    constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                    constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                    constraintWidget2.measured = true;
                } else if (i6 != 1) {
                    measure$ar$edu(constraintWidget2, 2, 0, i5, 0);
                    constraintWidget2.horizontalRun.dimension.wrapValue = constraintWidget2.getWidth();
                } else if (i6 == 2) {
                    i9 = constraintWidget.mListDimensionBehaviors$ar$edu[i];
                    width = (int) ((f * ((float) constraintWidgetContainer.getWidth())) + 0.5f);
                    measure$ar$edu(constraintWidget2, 1, width, i5, constraintWidget2.getHeight());
                    constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                    constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                    constraintWidget2.measured = true;
                } else {
                    constraintAnchorArr = constraintWidget2.mListAnchors;
                    measure$ar$edu(constraintWidget2, 2, 0, i5, 0);
                    constraintWidget2.horizontalRun.dimension.resolve(constraintWidget2.getWidth());
                    constraintWidget2.verticalRun.dimension.resolve(constraintWidget2.getHeight());
                    constraintWidget2.measured = true;
                }
            }
            i2++;
            i = 0;
        }
    }

    public final int computeWrap(ConstraintWidgetContainer constraintWidgetContainer, int i) {
        ConstraintWidget constraintWidget = constraintWidgetContainer;
        int i2 = i;
        int size = this.mGroups.size();
        long j = 0;
        int i3 = 0;
        long j2 = 0;
        while (i3 < size) {
            DependencyGraph dependencyGraph;
            long j3;
            RunGroup runGroup = (RunGroup) dependencyGraph.mGroups.get(i3);
            WidgetRun widgetRun = runGroup.firstRun;
            if (widgetRun instanceof ChainRun) {
                if (((ChainRun) widgetRun).orientation != i2) {
                    j3 = j;
                    j2 = Math.max(j2, j3);
                    i3++;
                    dependencyGraph = this;
                    constraintWidget = constraintWidgetContainer;
                    j = 0;
                }
            } else if (i2 == 0) {
                if (!(widgetRun instanceof HorizontalWidgetRun)) {
                    j3 = j;
                    j2 = Math.max(j2, j3);
                    i3++;
                    dependencyGraph = this;
                    constraintWidget = constraintWidgetContainer;
                    j = 0;
                }
            } else if (!(widgetRun instanceof VerticalWidgetRun)) {
                j3 = j;
                j2 = Math.max(j2, j3);
                i3++;
                dependencyGraph = this;
                constraintWidget = constraintWidgetContainer;
                j = 0;
            }
            Object obj = i2 == 0 ? constraintWidget.horizontalRun.start : constraintWidget.verticalRun.start;
            Object obj2 = i2 == 0 ? constraintWidget.horizontalRun.end : constraintWidget.verticalRun.end;
            boolean contains = widgetRun.start.targets.contains(obj);
            boolean contains2 = runGroup.firstRun.end.targets.contains(obj2);
            long wrapDimension = runGroup.firstRun.getWrapDimension();
            if (contains && contains2) {
                long traverseStart = runGroup.traverseStart(runGroup.firstRun.start, j);
                long traverseEnd = runGroup.traverseEnd(runGroup.firstRun.end, j);
                traverseStart -= wrapDimension;
                WidgetRun widgetRun2 = runGroup.firstRun;
                int i4 = widgetRun2.end.margin;
                if (traverseStart >= ((long) (-i4))) {
                    traverseStart += (long) i4;
                }
                j3 = (long) widgetRun2.start.margin;
                traverseEnd = ((-traverseEnd) - wrapDimension) - j3;
                if (traverseEnd >= j3) {
                    traverseEnd -= j3;
                }
                ConstraintWidget constraintWidget2 = widgetRun2.widget;
                float f = i2 == 0 ? constraintWidget2.mHorizontalBiasPercent : constraintWidget2.mVerticalBiasPercent;
                float f2 = (float) (f > 0.0f ? (long) ((((float) traverseEnd) / f) + (((float) traverseStart) / (1.0f - f))) : 0);
                j3 = (j3 + ((((long) ((f2 * f) + 0.5f)) + wrapDimension) + ((long) ((f2 * (1.0f - f)) + 0.5f)))) - ((long) i4);
            } else if (contains) {
                r0 = runGroup.firstRun.start;
                j3 = Math.max(runGroup.traverseStart(r0, (long) r0.margin), ((long) runGroup.firstRun.start.margin) + wrapDimension);
            } else if (contains2) {
                r0 = runGroup.firstRun.end;
                j3 = Math.max(-runGroup.traverseEnd(r0, (long) r0.margin), ((long) (-runGroup.firstRun.end.margin)) + wrapDimension);
            } else {
                WidgetRun widgetRun3 = runGroup.firstRun;
                j3 = (((long) widgetRun3.start.margin) + widgetRun3.getWrapDimension()) - ((long) runGroup.firstRun.end.margin);
            }
            j2 = Math.max(j2, j3);
            i3++;
            dependencyGraph = this;
            constraintWidget = constraintWidgetContainer;
            j = 0;
        }
        return (int) j2;
    }

    public final void measureWidgets() {
        List list = this.container.mChildren;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) list.get(i);
            if (!constraintWidget.measured) {
                int i2;
                int i3;
                int[] iArr = constraintWidget.mListDimensionBehaviors$ar$edu;
                int i4 = iArr[0];
                int i5 = iArr[1];
                int i6 = constraintWidget.mMatchConstraintDefaultWidth;
                int i7 = constraintWidget.mMatchConstraintDefaultHeight;
                Object obj;
                if (i4 == 2) {
                    i2 = i4;
                    obj = 1;
                } else if (i4 != 3) {
                    i2 = i4;
                    obj = null;
                } else if (i6 == 1) {
                    obj = 1;
                    i2 = 3;
                } else {
                    obj = null;
                    i2 = 3;
                }
                Object obj2;
                if (i5 == 2) {
                    i3 = i5;
                    obj2 = 1;
                } else if (i5 != 3) {
                    i3 = i5;
                    obj2 = null;
                } else if (i7 == 1) {
                    obj2 = 1;
                    i3 = 3;
                } else {
                    obj2 = null;
                    i3 = 3;
                }
                DependencyNode dependencyNode = constraintWidget.horizontalRun.dimension;
                boolean z = dependencyNode.resolved;
                DependencyNode dependencyNode2 = constraintWidget.verticalRun.dimension;
                boolean z2 = dependencyNode2.resolved;
                if (z && z2) {
                    measure$ar$edu(constraintWidget, 1, dependencyNode.value, 1, dependencyNode2.value);
                    constraintWidget.measured = true;
                } else if (z && obj2 != null) {
                    measure$ar$edu(constraintWidget, 1, dependencyNode.value, 2, dependencyNode2.value);
                    if (i3 == 3) {
                        constraintWidget.verticalRun.dimension.wrapValue = constraintWidget.getHeight();
                    } else {
                        constraintWidget.verticalRun.dimension.resolve(constraintWidget.getHeight());
                        constraintWidget.measured = true;
                    }
                } else if (z2 && obj != null) {
                    measure$ar$edu(constraintWidget, 2, dependencyNode.value, 1, dependencyNode2.value);
                    if (i2 == 3) {
                        constraintWidget.horizontalRun.dimension.wrapValue = constraintWidget.getWidth();
                    } else {
                        constraintWidget.horizontalRun.dimension.resolve(constraintWidget.getWidth());
                        constraintWidget.measured = true;
                    }
                }
                if (constraintWidget.measured) {
                    DependencyNode dependencyNode3 = constraintWidget.verticalRun.baselineDimension;
                    if (dependencyNode3 != null) {
                        dependencyNode3.resolve(constraintWidget.mBaselineDistance);
                    }
                }
            }
        }
    }

    public final void buildGraph() {
        List list = this.mRuns;
        list.clear();
        this.mContainer.horizontalRun.clear();
        this.mContainer.verticalRun.clear();
        list.add(this.mContainer.horizontalRun);
        list.add(this.mContainer.verticalRun);
        List list2 = this.mContainer.mChildren;
        int size = list2.size();
        Collection collection = null;
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) list2.get(i);
            if (constraintWidget instanceof Guideline) {
                list.add(new GuidelineReference(constraintWidget));
            } else {
                if (constraintWidget.isInHorizontalChain()) {
                    if (constraintWidget.horizontalChainRun == null) {
                        constraintWidget.horizontalChainRun = new ChainRun(constraintWidget, 0);
                    }
                    if (collection == null) {
                        collection = new HashSet();
                    }
                    collection.add(constraintWidget.horizontalChainRun);
                } else {
                    list.add(constraintWidget.horizontalRun);
                }
                if (constraintWidget.isInVerticalChain()) {
                    if (constraintWidget.verticalChainRun == null) {
                        constraintWidget.verticalChainRun = new ChainRun(constraintWidget, 1);
                    }
                    if (collection == null) {
                        collection = new HashSet();
                    }
                    collection.add(constraintWidget.verticalChainRun);
                } else {
                    list.add(constraintWidget.verticalRun);
                }
                if (constraintWidget instanceof HelperWidget) {
                    list.add(new HelperReferences(constraintWidget));
                }
            }
        }
        if (collection != null) {
            list.addAll(collection);
        }
        int size2 = list.size();
        for (size = 0; size < size2; size++) {
            ((WidgetRun) list.get(size)).clear();
        }
        size2 = list.size();
        for (size = 0; size < size2; size++) {
            WidgetRun widgetRun = (WidgetRun) list.get(size);
            if (widgetRun.widget != this.mContainer) {
                widgetRun.apply();
            }
        }
        this.mGroups.clear();
        RunGroup.index = 0;
        findGroup(this.container.horizontalRun, 0, this.mGroups);
        findGroup(this.container.verticalRun, 1, this.mGroups);
        this.mNeedBuildGraph = false;
    }
}
