package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.widgets.Chain;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
public final class WidgetGroup {
    static int count = 0;
    /* renamed from: id */
    int f14id = -1;
    private int moveTo = -1;
    public int orientation = 0;
    ArrayList results = null;
    final ArrayList widgets = new ArrayList();

    /* compiled from: PG */
    final class MeasureResult {
        public MeasureResult(ConstraintWidget constraintWidget) {
            WeakReference weakReference = new WeakReference(constraintWidget);
            LinearSystem.getObjectVariableValue$ar$ds(constraintWidget.mLeft);
            LinearSystem.getObjectVariableValue$ar$ds(constraintWidget.mTop);
            LinearSystem.getObjectVariableValue$ar$ds(constraintWidget.mRight);
            LinearSystem.getObjectVariableValue$ar$ds(constraintWidget.mBottom);
            LinearSystem.getObjectVariableValue$ar$ds(constraintWidget.mBaseline);
        }
    }

    public WidgetGroup(int i) {
        int i2 = count;
        count = i2 + 1;
        this.f14id = i2;
        this.orientation = i;
    }

    public final boolean add(ConstraintWidget constraintWidget) {
        if (this.widgets.contains(constraintWidget)) {
            return false;
        }
        this.widgets.add(constraintWidget);
        return true;
    }

    public final void cleanup(ArrayList arrayList) {
        int size = this.widgets.size();
        if (this.moveTo != -1 && size > 0) {
            for (int i = 0; i < arrayList.size(); i++) {
                WidgetGroup widgetGroup = (WidgetGroup) arrayList.get(i);
                if (this.moveTo == widgetGroup.f14id) {
                    moveTo(this.orientation, widgetGroup);
                }
            }
        }
        if (size == 0) {
            arrayList.remove(this);
        }
    }

    public final int measureWrap(LinearSystem linearSystem, int i) {
        int i2 = 0;
        if (this.widgets.size() == 0) {
            return 0;
        }
        int objectVariableValue$ar$ds;
        ArrayList arrayList = this.widgets;
        ConstraintWidget constraintWidget = ((ConstraintWidget) arrayList.get(0)).mParent;
        linearSystem.reset();
        constraintWidget.addToSolver(linearSystem, false);
        for (int i3 = 0; i3 < arrayList.size(); i3++) {
            ((ConstraintWidget) arrayList.get(i3)).addToSolver(linearSystem, false);
        }
        if (i == 0) {
            ConstraintWidgetContainer constraintWidgetContainer = (ConstraintWidgetContainer) constraintWidget;
            if (constraintWidgetContainer.mHorizontalChainsSize > 0) {
                Chain.applyChainConstraints(constraintWidgetContainer, linearSystem, arrayList, 0);
            }
        }
        if (i == 1) {
            ConstraintWidgetContainer constraintWidgetContainer2 = (ConstraintWidgetContainer) constraintWidget;
            if (constraintWidgetContainer2.mVerticalChainsSize > 0) {
                Chain.applyChainConstraints(constraintWidgetContainer2, linearSystem, arrayList, 1);
            }
        }
        try {
            linearSystem.minimize();
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.results = new ArrayList();
        while (i2 < arrayList.size()) {
            this.results.add(new MeasureResult((ConstraintWidget) arrayList.get(i2)));
            i2++;
        }
        ConstraintWidgetContainer constraintWidgetContainer3;
        if (i == 0) {
            constraintWidgetContainer3 = (ConstraintWidgetContainer) constraintWidget;
            i = LinearSystem.getObjectVariableValue$ar$ds(constraintWidgetContainer3.mLeft);
            objectVariableValue$ar$ds = LinearSystem.getObjectVariableValue$ar$ds(constraintWidgetContainer3.mRight);
            linearSystem.reset();
            objectVariableValue$ar$ds -= i;
        } else {
            constraintWidgetContainer3 = (ConstraintWidgetContainer) constraintWidget;
            i = LinearSystem.getObjectVariableValue$ar$ds(constraintWidgetContainer3.mTop);
            objectVariableValue$ar$ds = LinearSystem.getObjectVariableValue$ar$ds(constraintWidgetContainer3.mBottom);
            linearSystem.reset();
            objectVariableValue$ar$ds -= i;
        }
        return objectVariableValue$ar$ds;
    }

    public final void moveTo(int i, WidgetGroup widgetGroup) {
        List list = this.widgets;
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) list.get(i2);
            widgetGroup.add(constraintWidget);
            if (i == 0) {
                constraintWidget.horizontalGroup = widgetGroup.f14id;
            } else {
                constraintWidget.verticalGroup = widgetGroup.f14id;
            }
        }
        this.moveTo = widgetGroup.f14id;
    }

    public final String toString() {
        int i = this.orientation;
        String str = i == 0 ? "Horizontal" : i == 1 ? "Vertical" : "Both";
        int i2 = this.f14id;
        StringBuilder stringBuilder = new StringBuilder(str.length() + 16);
        stringBuilder.append(str);
        stringBuilder.append(" [");
        stringBuilder.append(i2);
        stringBuilder.append("] <");
        Object stringBuilder2 = stringBuilder.toString();
        List list = this.widgets;
        int size = list.size();
        for (int i3 = 0; i3 < size; i3++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) list.get(i3);
            str = String.valueOf(stringBuilder2);
            String str2 = constraintWidget.mDebugName;
            StringBuilder stringBuilder3 = new StringBuilder((String.valueOf(str).length() + 1) + String.valueOf(str2).length());
            stringBuilder3.append(str);
            stringBuilder3.append(" ");
            stringBuilder3.append(str2);
            stringBuilder2 = stringBuilder3.toString();
        }
        return String.valueOf(stringBuilder2).concat(" >");
    }
}
