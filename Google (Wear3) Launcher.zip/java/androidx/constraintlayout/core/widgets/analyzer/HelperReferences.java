package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.Barrier;
import androidx.constraintlayout.core.widgets.ConstraintWidget;

/* compiled from: PG */
final class HelperReferences extends WidgetRun {
    public HelperReferences(ConstraintWidget constraintWidget) {
        super(constraintWidget);
    }

    private final void addDependency(DependencyNode dependencyNode) {
        this.start.dependencies.add(dependencyNode);
        dependencyNode.targets.add(this.start);
    }

    public final void apply() {
        ConstraintWidget constraintWidget = this.widget;
        if (constraintWidget instanceof Barrier) {
            DependencyNode dependencyNode = this.start;
            dependencyNode.delegateToWidgetRun = true;
            Barrier barrier = (Barrier) constraintWidget;
            int i = barrier.mBarrierType;
            boolean z = barrier.mAllowsGoneWidget;
            int i2 = 0;
            ConstraintWidget constraintWidget2;
            switch (i) {
                case 0:
                    dependencyNode.type$ar$edu = 4;
                    while (i2 < barrier.mWidgetsCount) {
                        constraintWidget2 = barrier.mWidgets[i2];
                        if (z || constraintWidget2.mVisibility != 8) {
                            dependencyNode = constraintWidget2.horizontalRun.start;
                            dependencyNode.dependencies.add(this.start);
                            this.start.targets.add(dependencyNode);
                        }
                        i2++;
                    }
                    addDependency(this.widget.horizontalRun.start);
                    addDependency(this.widget.horizontalRun.end);
                    break;
                case 1:
                    dependencyNode.type$ar$edu = 5;
                    while (i2 < barrier.mWidgetsCount) {
                        constraintWidget2 = barrier.mWidgets[i2];
                        if (z || constraintWidget2.mVisibility != 8) {
                            dependencyNode = constraintWidget2.horizontalRun.end;
                            dependencyNode.dependencies.add(this.start);
                            this.start.targets.add(dependencyNode);
                        }
                        i2++;
                    }
                    addDependency(this.widget.horizontalRun.start);
                    addDependency(this.widget.horizontalRun.end);
                    return;
                case 2:
                    dependencyNode.type$ar$edu = 6;
                    while (i2 < barrier.mWidgetsCount) {
                        constraintWidget2 = barrier.mWidgets[i2];
                        if (z || constraintWidget2.mVisibility != 8) {
                            dependencyNode = constraintWidget2.verticalRun.start;
                            dependencyNode.dependencies.add(this.start);
                            this.start.targets.add(dependencyNode);
                        }
                        i2++;
                    }
                    addDependency(this.widget.verticalRun.start);
                    addDependency(this.widget.verticalRun.end);
                    return;
                case 3:
                    dependencyNode.type$ar$edu = 7;
                    while (i2 < barrier.mWidgetsCount) {
                        constraintWidget2 = barrier.mWidgets[i2];
                        if (z || constraintWidget2.mVisibility != 8) {
                            dependencyNode = constraintWidget2.verticalRun.end;
                            dependencyNode.dependencies.add(this.start);
                            this.start.targets.add(dependencyNode);
                        }
                        i2++;
                    }
                    addDependency(this.widget.verticalRun.start);
                    addDependency(this.widget.verticalRun.end);
                    return;
                default:
                    break;
            }
        }
    }

    public final void applyToWidget() {
        ConstraintWidget constraintWidget = this.widget;
        if (constraintWidget instanceof Barrier) {
            int i = ((Barrier) constraintWidget).mBarrierType;
            if (i != 0) {
                if (i != 1) {
                    constraintWidget.f13mY = this.start.value;
                    return;
                }
            }
            constraintWidget.f12mX = this.start.value;
        }
    }

    public final void clear() {
        this.runGroup = null;
        this.start.clear();
    }

    public final boolean supportsWrapComputation() {
        return false;
    }

    public final void update$ar$ds$4cba2fec_0() {
        Barrier barrier = (Barrier) this.widget;
        int i = barrier.mBarrierType;
        int i2 = 0;
        int i3 = -1;
        for (DependencyNode dependencyNode : this.start.targets) {
            int i4 = dependencyNode.value;
            if (i3 == -1 || i4 < i3) {
                i3 = i4;
            }
            if (i2 < i4) {
                i2 = i4;
            }
        }
        if (i != 0) {
            if (i != 2) {
                this.start.resolve(i2 + barrier.mMargin);
                return;
            }
        }
        this.start.resolve(i3 + barrier.mMargin);
    }
}
