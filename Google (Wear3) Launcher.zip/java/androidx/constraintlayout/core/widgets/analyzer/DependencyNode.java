package androidx.constraintlayout.core.widgets.analyzer;

import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
public class DependencyNode implements Dependency {
    public boolean delegateToWidgetRun = false;
    final List dependencies = new ArrayList();
    int margin;
    DimensionDependency marginDependency = null;
    int marginFactor = 1;
    public boolean readyToSolve = false;
    public boolean resolved = false;
    final WidgetRun run;
    final List targets = new ArrayList();
    int type$ar$edu = 1;
    public Dependency updateDelegate = null;
    public int value;

    public DependencyNode(WidgetRun widgetRun) {
        this.run = widgetRun;
    }

    public final void addDependency(Dependency dependency) {
        this.dependencies.add(dependency);
        if (this.resolved) {
            dependency.update$ar$ds$4cba2fec_0();
        }
    }

    public final void clear() {
        this.targets.clear();
        this.dependencies.clear();
        this.resolved = false;
        this.value = 0;
        this.readyToSolve = false;
        this.delegateToWidgetRun = false;
    }

    public void resolve(int i) {
        if (!this.resolved) {
            this.resolved = true;
            this.value = i;
            for (Dependency update$ar$ds$4cba2fec_0 : this.dependencies) {
                update$ar$ds$4cba2fec_0.update$ar$ds$4cba2fec_0();
            }
        }
    }

    public final String toString() {
        String str;
        String str2 = this.run.widget.mDebugName;
        switch (this.type$ar$edu) {
            case 1:
                str = "UNKNOWN";
                break;
            case 2:
                str = "HORIZONTAL_DIMENSION";
                break;
            case 3:
                str = "VERTICAL_DIMENSION";
                break;
            case 4:
                str = "LEFT";
                break;
            case 5:
                str = "RIGHT";
                break;
            case 6:
                str = "TOP";
                break;
            case 7:
                str = "BOTTOM";
                break;
            case 8:
                str = "BASELINE";
                break;
            default:
                str = "null";
                break;
        }
        String valueOf = String.valueOf(this.resolved ? Integer.valueOf(this.value) : "unresolved");
        int size = this.targets.size();
        int size2 = this.dependencies.size();
        StringBuilder stringBuilder = new StringBuilder(((String.valueOf(str2).length() + 33) + str.length()) + String.valueOf(valueOf).length());
        stringBuilder.append(str2);
        stringBuilder.append(":");
        stringBuilder.append(str);
        stringBuilder.append("(");
        stringBuilder.append(valueOf);
        stringBuilder.append(") <t=");
        stringBuilder.append(size);
        stringBuilder.append(":d=");
        stringBuilder.append(size2);
        stringBuilder.append(">");
        return stringBuilder.toString();
    }

    public final void update$ar$ds$4cba2fec_0() {
        for (DependencyNode dependencyNode : this.targets) {
            if (!dependencyNode.resolved) {
                return;
            }
        }
        this.readyToSolve = true;
        Dependency dependency = this.updateDelegate;
        if (dependency != null) {
            dependency.update$ar$ds$4cba2fec_0();
        }
        if (this.delegateToWidgetRun) {
            this.run.update$ar$ds$4cba2fec_0();
            return;
        }
        DependencyNode dependencyNode2 = null;
        int i = 0;
        for (DependencyNode dependencyNode3 : this.targets) {
            if (!(dependencyNode3 instanceof DimensionDependency)) {
                i++;
                dependencyNode2 = dependencyNode3;
            }
        }
        if (dependencyNode2 != null && i == 1 && dependencyNode2.resolved) {
            DependencyNode dependencyNode4 = this.marginDependency;
            if (dependencyNode4 != null) {
                if (dependencyNode4.resolved) {
                    this.margin = this.marginFactor * dependencyNode4.value;
                } else {
                    return;
                }
            }
            resolve(dependencyNode2.value + this.margin);
        }
        Dependency dependency2 = this.updateDelegate;
        if (dependency2 != null) {
            dependency2.update$ar$ds$4cba2fec_0();
        }
    }
}
