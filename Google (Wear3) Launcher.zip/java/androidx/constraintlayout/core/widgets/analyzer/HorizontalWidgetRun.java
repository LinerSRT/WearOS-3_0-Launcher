package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.HelperWidget;

/* compiled from: PG */
public final class HorizontalWidgetRun extends WidgetRun {
    private static final int[] tempDimensions = new int[2];

    public HorizontalWidgetRun(ConstraintWidget constraintWidget) {
        super(constraintWidget);
        this.start.type$ar$edu = 4;
        this.end.type$ar$edu = 5;
        this.orientation = 0;
    }

    private static final void computeInsetRatio$ar$ds(int[] iArr, int i, int i2, int i3, int i4, float f, int i5) {
        i2 -= i;
        i4 -= i3;
        switch (i5) {
            case -1:
                i5 = (int) ((((float) i4) * f) + 0.5f);
                int i6 = (int) ((((float) i2) / f) + 0.5f);
                if (i5 <= i2) {
                    iArr[0] = i5;
                    iArr[1] = i4;
                    return;
                }
                if (i6 <= i4) {
                    iArr[0] = i2;
                    iArr[1] = i6;
                }
                return;
            case 0:
                iArr[0] = (int) ((((float) i4) * f) + 0.5f);
                iArr[1] = i4;
                return;
            default:
                iArr[0] = i2;
                iArr[1] = (int) ((((float) i2) * f) + 0.5f);
                return;
        }
    }

    public final void apply() {
        ConstraintWidget constraintWidget;
        ConstraintAnchor constraintAnchor;
        ConstraintWidget constraintWidget2;
        DependencyNode dependencyNode;
        ConstraintWidget constraintWidget3 = this.widget;
        if (constraintWidget3.measured) {
            this.dimension.resolve(constraintWidget3.getWidth());
        }
        if (!this.dimension.resolved) {
            int horizontalDimensionBehaviour$ar$edu = this.widget.getHorizontalDimensionBehaviour$ar$edu();
            this.dimensionBehavior$ar$edu = horizontalDimensionBehaviour$ar$edu;
            if (horizontalDimensionBehaviour$ar$edu != 3) {
                if (this.dimensionBehavior$ar$edu == 4) {
                    constraintWidget3 = this.widget.mParent;
                    if (constraintWidget3 != null) {
                        if (constraintWidget3.getHorizontalDimensionBehaviour$ar$edu() == 1 || constraintWidget3.getHorizontalDimensionBehaviour$ar$edu() == 4) {
                            int width = constraintWidget3.getWidth();
                            int margin = this.widget.mLeft.getMargin();
                            int margin2 = this.widget.mRight.getMargin();
                            WidgetRun.addTarget$ar$ds(this.start, constraintWidget3.horizontalRun.start, this.widget.mLeft.getMargin());
                            WidgetRun.addTarget$ar$ds(this.end, constraintWidget3.horizontalRun.end, -this.widget.mRight.getMargin());
                            this.dimension.resolve((width - margin) - margin2);
                            return;
                        }
                    }
                }
                if (this.dimensionBehavior$ar$edu == 1) {
                    this.dimension.resolve(this.widget.getWidth());
                }
            }
        } else if (this.dimensionBehavior$ar$edu == 4) {
            constraintWidget3 = this.widget.mParent;
            if (constraintWidget3 != null && (constraintWidget3.getHorizontalDimensionBehaviour$ar$edu() == 1 || constraintWidget3.getHorizontalDimensionBehaviour$ar$edu() == 4)) {
                WidgetRun.addTarget$ar$ds(this.start, constraintWidget3.horizontalRun.start, this.widget.mLeft.getMargin());
                WidgetRun.addTarget$ar$ds(this.end, constraintWidget3.horizontalRun.end, -this.widget.mRight.getMargin());
                return;
            }
        }
        DependencyNode dependencyNode2 = this.dimension;
        if (dependencyNode2.resolved) {
            constraintWidget = this.widget;
            if (constraintWidget.measured) {
                ConstraintAnchor[] constraintAnchorArr = constraintWidget.mListAnchors;
                constraintAnchor = constraintAnchorArr[0];
                ConstraintAnchor constraintAnchor2 = constraintAnchor.mTarget;
                if (constraintAnchor2 == null || constraintAnchorArr[1].mTarget == null) {
                    if (constraintAnchor2 != null) {
                        dependencyNode2 = WidgetRun.getTarget$ar$ds(constraintAnchor);
                        if (dependencyNode2 != null) {
                            WidgetRun.addTarget$ar$ds(this.start, dependencyNode2, this.widget.mListAnchors[0].getMargin());
                            WidgetRun.addTarget$ar$ds(this.end, this.start, this.dimension.value);
                            return;
                        }
                    }
                    ConstraintAnchor constraintAnchor3 = constraintAnchorArr[1];
                    if (constraintAnchor3.mTarget != null) {
                        dependencyNode2 = WidgetRun.getTarget$ar$ds(constraintAnchor3);
                        if (dependencyNode2 != null) {
                            WidgetRun.addTarget$ar$ds(this.end, dependencyNode2, -this.widget.mListAnchors[1].getMargin());
                            WidgetRun.addTarget$ar$ds(this.start, this.end, -this.dimension.value);
                            return;
                        }
                    } else if (!((constraintWidget instanceof HelperWidget) || constraintWidget.mParent == null || constraintWidget.getAnchor$ar$edu(7).mTarget != null)) {
                        constraintWidget3 = this.widget;
                        WidgetRun.addTarget$ar$ds(this.start, constraintWidget3.mParent.horizontalRun.start, constraintWidget3.getX());
                        WidgetRun.addTarget$ar$ds(this.end, this.start, this.dimension.value);
                        return;
                    }
                } else if (constraintWidget.isInHorizontalChain()) {
                    this.start.margin = this.widget.mListAnchors[0].getMargin();
                    this.end.margin = -this.widget.mListAnchors[1].getMargin();
                    return;
                } else {
                    dependencyNode2 = WidgetRun.getTarget$ar$ds(this.widget.mListAnchors[0]);
                    if (dependencyNode2 != null) {
                        WidgetRun.addTarget$ar$ds(this.start, dependencyNode2, this.widget.mListAnchors[0].getMargin());
                    }
                    dependencyNode2 = WidgetRun.getTarget$ar$ds(this.widget.mListAnchors[1]);
                    if (dependencyNode2 != null) {
                        WidgetRun.addTarget$ar$ds(this.end, dependencyNode2, -this.widget.mListAnchors[1].getMargin());
                    }
                    this.start.delegateToWidgetRun = true;
                    this.end.delegateToWidgetRun = true;
                    return;
                }
            }
        }
        if (this.dimensionBehavior$ar$edu == 3) {
            constraintWidget = this.widget;
            switch (constraintWidget.mMatchConstraintDefaultWidth) {
                case 2:
                    constraintWidget2 = constraintWidget.mParent;
                    if (constraintWidget2 != null) {
                        dependencyNode = constraintWidget2.verticalRun.dimension;
                        dependencyNode2.targets.add(dependencyNode);
                        dependencyNode.dependencies.add(this.dimension);
                        dependencyNode2 = this.dimension;
                        dependencyNode2.delegateToWidgetRun = true;
                        dependencyNode2.dependencies.add(this.start);
                        this.dimension.dependencies.add(this.end);
                        break;
                    }
                    break;
                case 3:
                    if (constraintWidget.mMatchConstraintDefaultHeight != 3) {
                        dependencyNode = constraintWidget.verticalRun.dimension;
                        dependencyNode2.targets.add(dependencyNode);
                        dependencyNode.dependencies.add(this.dimension);
                        this.widget.verticalRun.start.dependencies.add(this.dimension);
                        this.widget.verticalRun.end.dependencies.add(this.dimension);
                        dependencyNode2 = this.dimension;
                        dependencyNode2.delegateToWidgetRun = true;
                        dependencyNode2.dependencies.add(this.start);
                        this.dimension.dependencies.add(this.end);
                        this.start.targets.add(this.dimension);
                        this.end.targets.add(this.dimension);
                        break;
                    }
                    this.start.updateDelegate = this;
                    this.end.updateDelegate = this;
                    WidgetRun widgetRun = constraintWidget.verticalRun;
                    widgetRun.start.updateDelegate = this;
                    widgetRun.end.updateDelegate = this;
                    dependencyNode2.updateDelegate = this;
                    if (!constraintWidget.isInVerticalChain()) {
                        if (!this.widget.isInHorizontalChain()) {
                            this.widget.verticalRun.dimension.targets.add(this.dimension);
                            break;
                        }
                        this.widget.verticalRun.dimension.targets.add(this.dimension);
                        this.dimension.dependencies.add(this.widget.verticalRun.dimension);
                        break;
                    }
                    this.dimension.targets.add(this.widget.verticalRun.dimension);
                    this.widget.verticalRun.dimension.dependencies.add(this.dimension);
                    WidgetRun widgetRun2 = this.widget.verticalRun;
                    widgetRun2.dimension.updateDelegate = this;
                    this.dimension.targets.add(widgetRun2.start);
                    this.dimension.targets.add(this.widget.verticalRun.end);
                    this.widget.verticalRun.start.dependencies.add(this.dimension);
                    this.widget.verticalRun.end.dependencies.add(this.dimension);
                    break;
                default:
                    break;
            }
        }
        constraintWidget3 = this.widget;
        ConstraintAnchor[] constraintAnchorArr2 = constraintWidget3.mListAnchors;
        ConstraintAnchor constraintAnchor4 = constraintAnchorArr2[0];
        ConstraintAnchor constraintAnchor5 = constraintAnchor4.mTarget;
        if (constraintAnchor5 == null || constraintAnchorArr2[1].mTarget == null) {
            if (constraintAnchor5 != null) {
                dependencyNode2 = WidgetRun.getTarget$ar$ds(constraintAnchor4);
                if (dependencyNode2 != null) {
                    WidgetRun.addTarget$ar$ds(this.start, dependencyNode2, this.widget.mListAnchors[0].getMargin());
                    addTarget(this.end, this.start, 1, this.dimension);
                    return;
                }
            }
            constraintAnchor = constraintAnchorArr2[1];
            if (constraintAnchor.mTarget != null) {
                dependencyNode2 = WidgetRun.getTarget$ar$ds(constraintAnchor);
                if (dependencyNode2 != null) {
                    WidgetRun.addTarget$ar$ds(this.end, dependencyNode2, -this.widget.mListAnchors[1].getMargin());
                    addTarget(this.start, this.end, -1, this.dimension);
                }
            } else if (!(constraintWidget3 instanceof HelperWidget)) {
                constraintWidget2 = constraintWidget3.mParent;
                if (constraintWidget2 != null) {
                    WidgetRun.addTarget$ar$ds(this.start, constraintWidget2.horizontalRun.start, constraintWidget3.getX());
                    addTarget(this.end, this.start, 1, this.dimension);
                }
            }
        } else if (constraintWidget3.isInHorizontalChain()) {
            this.start.margin = this.widget.mListAnchors[0].getMargin();
            this.end.margin = -this.widget.mListAnchors[1].getMargin();
        } else {
            dependencyNode2 = WidgetRun.getTarget$ar$ds(this.widget.mListAnchors[0]);
            dependencyNode = WidgetRun.getTarget$ar$ds(this.widget.mListAnchors[1]);
            if (dependencyNode2 != null) {
                dependencyNode2.addDependency(this);
            }
            if (dependencyNode != null) {
                dependencyNode.addDependency(this);
            }
            this.mRunType$ar$edu = 4;
        }
    }

    public final void applyToWidget() {
        DependencyNode dependencyNode = this.start;
        if (dependencyNode.resolved) {
            this.widget.f12mX = dependencyNode.value;
        }
    }

    public final void clear() {
        this.runGroup = null;
        this.start.clear();
        this.end.clear();
        this.dimension.clear();
        this.resolved = false;
    }

    public final void reset() {
        this.resolved = false;
        this.start.clear();
        this.start.resolved = false;
        this.end.clear();
        this.end.resolved = false;
        this.dimension.resolved = false;
    }

    public final boolean supportsWrapComputation() {
        return this.dimensionBehavior$ar$edu != 3 || this.widget.mMatchConstraintDefaultWidth == 0;
    }

    public final String toString() {
        String valueOf = String.valueOf(this.widget.mDebugName);
        String str = "HorizontalRun ";
        return valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
    }

    public final void update$ar$ds$4cba2fec_0() {
        int i = this.mRunType$ar$edu;
        int i2 = i - 1;
        if (i != 0) {
            ConstraintWidget constraintWidget;
            switch (i2) {
                case 3:
                    constraintWidget = r0.widget;
                    updateRunCenter$ar$ds(constraintWidget.mLeft, constraintWidget.mRight, 0);
                    return;
                default:
                    ConstraintWidget constraintWidget2;
                    int i3;
                    int i4;
                    int limitedDimension;
                    DependencyNode dependencyNode;
                    int i5;
                    DependencyNode dependencyNode2 = r0.dimension;
                    if (!dependencyNode2.resolved && r0.dimensionBehavior$ar$edu == 3) {
                        constraintWidget2 = r0.widget;
                        DependencyNode dependencyNode3;
                        switch (constraintWidget2.mMatchConstraintDefaultWidth) {
                            case 2:
                                ConstraintWidget constraintWidget3 = constraintWidget2.mParent;
                                if (constraintWidget3 != null) {
                                    dependencyNode3 = constraintWidget3.horizontalRun.dimension;
                                    if (dependencyNode3.resolved) {
                                        dependencyNode2.resolve((int) ((((float) dependencyNode3.value) * constraintWidget2.mMatchConstraintPercentWidth) + 0.5f));
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                i3 = constraintWidget2.mMatchConstraintDefaultHeight;
                                if (i3 != 0) {
                                    if (i3 != 3) {
                                        switch (constraintWidget2.mDimensionRatioSide) {
                                            case -1:
                                                i4 = (int) ((((float) constraintWidget2.verticalRun.dimension.value) * constraintWidget2.mDimensionRatio) + 0.5f);
                                                break;
                                            case 0:
                                                i4 = (int) ((((float) constraintWidget2.verticalRun.dimension.value) / constraintWidget2.mDimensionRatio) + 0.5f);
                                                break;
                                            default:
                                                i4 = (int) ((((float) constraintWidget2.verticalRun.dimension.value) * constraintWidget2.mDimensionRatio) + 0.5f);
                                                break;
                                        }
                                        dependencyNode2.resolve(i4);
                                        break;
                                    }
                                }
                                WidgetRun widgetRun = constraintWidget2.verticalRun;
                                dependencyNode3 = widgetRun.start;
                                dependencyNode2 = widgetRun.end;
                                ConstraintAnchor constraintAnchor = constraintWidget2.mLeft.mTarget;
                                ConstraintAnchor constraintAnchor2 = constraintWidget2.mTop.mTarget;
                                ConstraintAnchor constraintAnchor3 = constraintWidget2.mRight.mTarget;
                                ConstraintAnchor constraintAnchor4 = constraintWidget2.mBottom.mTarget;
                                int i6 = constraintWidget2.mDimensionRatioSide;
                                int i7;
                                float f;
                                if (constraintAnchor == null || constraintAnchor2 == null || constraintAnchor3 == null || constraintAnchor4 == null) {
                                    i7 = i6;
                                    if (constraintAnchor != null && constraintAnchor3 != null) {
                                        dependencyNode2 = r0.start;
                                        if (dependencyNode2.readyToSolve) {
                                            if (r0.end.readyToSolve) {
                                                f = constraintWidget2.mDimensionRatio;
                                                i2 = ((DependencyNode) dependencyNode2.targets.get(0)).value + r0.start.margin;
                                                i3 = ((DependencyNode) r0.end.targets.get(0)).value - r0.end.margin;
                                                switch (i7) {
                                                    case -1:
                                                    case 0:
                                                        i2 = getLimitedDimension(i3 - i2, 0);
                                                        i3 = (int) ((((float) i2) * f) + 0.5f);
                                                        limitedDimension = getLimitedDimension(i3, 1);
                                                        if (i3 != limitedDimension) {
                                                            i2 = (int) ((((float) limitedDimension) / f) + 0.5f);
                                                        }
                                                        r0.dimension.resolve(i2);
                                                        r0.widget.verticalRun.dimension.resolve(limitedDimension);
                                                        break;
                                                    default:
                                                        i2 = getLimitedDimension(i3 - i2, 0);
                                                        i3 = (int) ((((float) i2) / f) + 0.5f);
                                                        limitedDimension = getLimitedDimension(i3, 1);
                                                        if (i3 != limitedDimension) {
                                                            i2 = (int) ((((float) limitedDimension) * f) + 0.5f);
                                                        }
                                                        r0.dimension.resolve(i2);
                                                        r0.widget.verticalRun.dimension.resolve(limitedDimension);
                                                        break;
                                                }
                                            }
                                        }
                                        return;
                                    } else if (!(constraintAnchor2 == null || constraintAnchor4 == null)) {
                                        if (dependencyNode3.readyToSolve) {
                                            if (dependencyNode2.readyToSolve) {
                                                f = constraintWidget2.mDimensionRatio;
                                                limitedDimension = ((DependencyNode) dependencyNode3.targets.get(0)).value + dependencyNode3.margin;
                                                i3 = ((DependencyNode) dependencyNode2.targets.get(0)).value - dependencyNode2.margin;
                                                switch (i7) {
                                                    case 0:
                                                        i2 = getLimitedDimension(i3 - limitedDimension, 1);
                                                        i3 = (int) ((((float) i2) * f) + 0.5f);
                                                        limitedDimension = getLimitedDimension(i3, 0);
                                                        if (i3 != limitedDimension) {
                                                            i2 = (int) ((((float) limitedDimension) / f) + 0.5f);
                                                        }
                                                        r0.dimension.resolve(limitedDimension);
                                                        r0.widget.verticalRun.dimension.resolve(i2);
                                                        break;
                                                    default:
                                                        i2 = getLimitedDimension(i3 - limitedDimension, 1);
                                                        i3 = (int) ((((float) i2) / f) + 0.5f);
                                                        limitedDimension = getLimitedDimension(i3, 0);
                                                        if (i3 != limitedDimension) {
                                                            i2 = (int) ((((float) limitedDimension) * f) + 0.5f);
                                                        }
                                                        r0.dimension.resolve(limitedDimension);
                                                        r0.widget.verticalRun.dimension.resolve(i2);
                                                        break;
                                                }
                                            }
                                        }
                                        return;
                                    }
                                }
                                f = constraintWidget2.mDimensionRatio;
                                int i8;
                                int i9;
                                int i10;
                                int[] iArr;
                                if (dependencyNode3.resolved && dependencyNode2.resolved) {
                                    dependencyNode = r0.start;
                                    if (dependencyNode.readyToSolve) {
                                        if (r0.end.readyToSolve) {
                                            i5 = ((DependencyNode) dependencyNode.targets.get(0)).value;
                                            int i11 = r0.start.margin;
                                            limitedDimension = ((DependencyNode) r0.end.targets.get(0)).value;
                                            i8 = r0.end.margin;
                                            i9 = dependencyNode3.value;
                                            i3 = dependencyNode3.margin;
                                            i10 = dependencyNode2.value;
                                            i2 = dependencyNode2.margin;
                                            iArr = tempDimensions;
                                            i7 = i6;
                                            computeInsetRatio$ar$ds(iArr, i5 + i11, limitedDimension - i8, i9 + i3, i10 - i2, f, i7);
                                            r0.dimension.resolve(iArr[0]);
                                            r0.widget.verticalRun.dimension.resolve(iArr[1]);
                                            return;
                                        }
                                    }
                                    return;
                                }
                                int i12;
                                int i13;
                                i7 = i6;
                                DependencyNode dependencyNode4 = r0.start;
                                if (dependencyNode4.resolved) {
                                    DependencyNode dependencyNode5 = r0.end;
                                    if (dependencyNode5.resolved) {
                                        if (dependencyNode3.readyToSolve) {
                                            if (dependencyNode2.readyToSolve) {
                                                i9 = dependencyNode4.value;
                                                limitedDimension = dependencyNode4.margin;
                                                i10 = dependencyNode5.value;
                                                i8 = dependencyNode5.margin;
                                                i12 = ((DependencyNode) dependencyNode3.targets.get(0)).value;
                                                i13 = dependencyNode3.margin;
                                                int i14 = ((DependencyNode) dependencyNode2.targets.get(0)).value;
                                                i6 = dependencyNode2.margin;
                                                iArr = tempDimensions;
                                                computeInsetRatio$ar$ds(iArr, limitedDimension + i9, i10 - i8, i12 + i13, i14 - i6, f, i7);
                                                r0.dimension.resolve(iArr[0]);
                                                r0.widget.verticalRun.dimension.resolve(iArr[1]);
                                            }
                                        }
                                        return;
                                    }
                                }
                                dependencyNode4 = r0.start;
                                if (dependencyNode4.readyToSolve && r0.end.readyToSolve && dependencyNode3.readyToSolve) {
                                    if (dependencyNode2.readyToSolve) {
                                        limitedDimension = ((DependencyNode) dependencyNode4.targets.get(0)).value;
                                        i8 = r0.start.margin;
                                        i9 = ((DependencyNode) r0.end.targets.get(0)).value;
                                        i10 = r0.end.margin;
                                        i12 = ((DependencyNode) dependencyNode3.targets.get(0)).value;
                                        i3 = dependencyNode3.margin;
                                        i13 = ((DependencyNode) dependencyNode2.targets.get(0)).value;
                                        i2 = dependencyNode2.margin;
                                        iArr = tempDimensions;
                                        i6 = i12 + i3;
                                        int i15 = i13 - i2;
                                        computeInsetRatio$ar$ds(iArr, limitedDimension + i8, i9 - i10, i6, i15, f, i7);
                                        r0.dimension.resolve(iArr[0]);
                                        r0.widget.verticalRun.dimension.resolve(iArr[1]);
                                        break;
                                    }
                                }
                                return;
                                break;
                            default:
                                break;
                        }
                    }
                    dependencyNode2 = r0.start;
                    if (dependencyNode2.readyToSolve) {
                        DependencyNode dependencyNode6 = r0.end;
                        if (dependencyNode6.readyToSolve) {
                            DependencyNode dependencyNode7;
                            if (dependencyNode2.resolved && dependencyNode6.resolved) {
                                if (r0.dimension.resolved) {
                                    return;
                                }
                            }
                            if (!r0.dimension.resolved && r0.dimensionBehavior$ar$edu == 3) {
                                constraintWidget = r0.widget;
                                if (constraintWidget.mMatchConstraintDefaultWidth == 0) {
                                    if (!constraintWidget.isInHorizontalChain()) {
                                        dependencyNode7 = (DependencyNode) r0.end.targets.get(0);
                                        i2 = ((DependencyNode) r0.start.targets.get(0)).value;
                                        dependencyNode6 = r0.start;
                                        i2 += dependencyNode6.margin;
                                        i = dependencyNode7.value + r0.end.margin;
                                        dependencyNode6.resolve(i2);
                                        r0.end.resolve(i);
                                        r0.dimension.resolve(i - i2);
                                        return;
                                    }
                                }
                            }
                            if (!r0.dimension.resolved && r0.dimensionBehavior$ar$edu == 3 && r0.matchConstraintsType == 1 && r0.start.targets.size() > 0 && r0.end.targets.size() > 0) {
                                dependencyNode6 = (DependencyNode) r0.end.targets.get(0);
                                i2 = ((DependencyNode) r0.start.targets.get(0)).value;
                                i5 = r0.start.margin;
                                i2 = Math.min((dependencyNode6.value + r0.end.margin) - (i2 + i5), r0.dimension.wrapValue);
                                constraintWidget2 = r0.widget;
                                i5 = constraintWidget2.mMatchConstraintMaxWidth;
                                i2 = Math.max(constraintWidget2.mMatchConstraintMinWidth, i2);
                                if (i5 > 0) {
                                    i2 = Math.min(i5, i2);
                                }
                                r0.dimension.resolve(i2);
                            }
                            if (r0.dimension.resolved) {
                                dependencyNode2 = (DependencyNode) r0.start.targets.get(0);
                                dependencyNode7 = (DependencyNode) r0.end.targets.get(0);
                                i4 = dependencyNode2.value;
                                dependencyNode = r0.start;
                                int i16 = dependencyNode.margin + i4;
                                i3 = dependencyNode7.value;
                                limitedDimension = r0.end.margin + i3;
                                float f2 = r0.widget.mHorizontalBiasPercent;
                                if (dependencyNode2 == dependencyNode7) {
                                    f2 = 0.5f;
                                }
                                if (dependencyNode2 != dependencyNode7) {
                                    i3 = limitedDimension;
                                }
                                if (dependencyNode2 != dependencyNode7) {
                                    i4 = i16;
                                }
                                dependencyNode.resolve((int) ((((float) i4) + 0.5f) + (((float) ((i3 - i4) - r0.dimension.value)) * f2)));
                                r0.end.resolve(r0.start.value + r0.dimension.value);
                                return;
                            }
                            return;
                        }
                    }
                    return;
            }
        }
        throw null;
    }
}
