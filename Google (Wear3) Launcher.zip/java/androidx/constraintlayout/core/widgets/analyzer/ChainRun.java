package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
public final class ChainRun extends WidgetRun {
    private int chainStyle;
    ArrayList widgets = new ArrayList();

    public ChainRun(ConstraintWidget constraintWidget, int i) {
        super(constraintWidget);
        this.orientation = i;
        constraintWidget = this.widget;
        ConstraintWidget previousChainMember = constraintWidget.getPreviousChainMember(i);
        ConstraintWidget constraintWidget2 = constraintWidget;
        constraintWidget = previousChainMember;
        while (constraintWidget != null) {
            constraintWidget2 = constraintWidget;
            constraintWidget = constraintWidget.getPreviousChainMember(this.orientation);
        }
        this.widget = constraintWidget2;
        this.widgets.add(constraintWidget2.getRun(this.orientation));
        constraintWidget = constraintWidget2.getNextChainMember(this.orientation);
        while (constraintWidget != null) {
            this.widgets.add(constraintWidget.getRun(this.orientation));
            constraintWidget = constraintWidget.getNextChainMember(this.orientation);
        }
        List list = this.widgets;
        i = list.size();
        for (int i2 = 0; i2 < i; i2++) {
            WidgetRun widgetRun = (WidgetRun) list.get(i2);
            int i3 = this.orientation;
            if (i3 == 0) {
                widgetRun.widget.horizontalChainRun = this;
            } else if (i3 == 1) {
                widgetRun.widget.verticalChainRun = this;
            }
        }
        if (this.orientation == 0 && ((ConstraintWidgetContainer) this.widget.mParent).mIsRtl && this.widgets.size() > 1) {
            ArrayList arrayList = this.widgets;
            this.widget = ((WidgetRun) arrayList.get(arrayList.size() - 1)).widget;
        }
        this.chainStyle = this.orientation == 0 ? this.widget.mHorizontalChainStyle : this.widget.mVerticalChainStyle;
    }

    private final ConstraintWidget getFirstVisibleWidget() {
        for (int i = 0; i < this.widgets.size(); i++) {
            ConstraintWidget constraintWidget = ((WidgetRun) this.widgets.get(i)).widget;
            if (constraintWidget.mVisibility != 8) {
                return constraintWidget;
            }
        }
        return null;
    }

    private final ConstraintWidget getLastVisibleWidget() {
        for (int size = this.widgets.size() - 1; size >= 0; size--) {
            ConstraintWidget constraintWidget = ((WidgetRun) this.widgets.get(size)).widget;
            if (constraintWidget.mVisibility != 8) {
                return constraintWidget;
            }
        }
        return null;
    }

    public final void apply() {
        List list = this.widgets;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            ((WidgetRun) list.get(i)).apply();
        }
        int size2 = this.widgets.size();
        if (size2 > 0) {
            ConstraintWidget constraintWidget = ((WidgetRun) this.widgets.get(0)).widget;
            ConstraintWidget constraintWidget2 = ((WidgetRun) this.widgets.get(size2 - 1)).widget;
            ConstraintAnchor constraintAnchor;
            ConstraintAnchor constraintAnchor2;
            DependencyNode target$ar$ds$554e726e_0;
            ConstraintWidget firstVisibleWidget;
            DependencyNode target$ar$ds$554e726e_02;
            ConstraintWidget lastVisibleWidget;
            if (this.orientation == 0) {
                constraintAnchor = constraintWidget.mLeft;
                constraintAnchor2 = constraintWidget2.mRight;
                target$ar$ds$554e726e_0 = WidgetRun.getTarget$ar$ds$554e726e_0(constraintAnchor, 0);
                size = constraintAnchor.getMargin();
                firstVisibleWidget = getFirstVisibleWidget();
                if (firstVisibleWidget != null) {
                    size = firstVisibleWidget.mLeft.getMargin();
                }
                if (target$ar$ds$554e726e_0 != null) {
                    WidgetRun.addTarget$ar$ds(this.start, target$ar$ds$554e726e_0, size);
                }
                target$ar$ds$554e726e_02 = WidgetRun.getTarget$ar$ds$554e726e_0(constraintAnchor2, 0);
                size2 = constraintAnchor2.getMargin();
                lastVisibleWidget = getLastVisibleWidget();
                if (lastVisibleWidget != null) {
                    size2 = lastVisibleWidget.mRight.getMargin();
                }
                if (target$ar$ds$554e726e_02 != null) {
                    WidgetRun.addTarget$ar$ds(this.end, target$ar$ds$554e726e_02, -size2);
                }
            } else {
                constraintAnchor = constraintWidget.mTop;
                constraintAnchor2 = constraintWidget2.mBottom;
                target$ar$ds$554e726e_0 = WidgetRun.getTarget$ar$ds$554e726e_0(constraintAnchor, 1);
                size = constraintAnchor.getMargin();
                firstVisibleWidget = getFirstVisibleWidget();
                if (firstVisibleWidget != null) {
                    size = firstVisibleWidget.mTop.getMargin();
                }
                if (target$ar$ds$554e726e_0 != null) {
                    WidgetRun.addTarget$ar$ds(this.start, target$ar$ds$554e726e_0, size);
                }
                target$ar$ds$554e726e_02 = WidgetRun.getTarget$ar$ds$554e726e_0(constraintAnchor2, 1);
                size2 = constraintAnchor2.getMargin();
                lastVisibleWidget = getLastVisibleWidget();
                if (lastVisibleWidget != null) {
                    size2 = lastVisibleWidget.mBottom.getMargin();
                }
                if (target$ar$ds$554e726e_02 != null) {
                    WidgetRun.addTarget$ar$ds(this.end, target$ar$ds$554e726e_02, -size2);
                }
            }
            this.start.updateDelegate = this;
            this.end.updateDelegate = this;
        }
    }

    public final void applyToWidget() {
        for (int i = 0; i < this.widgets.size(); i++) {
            ((WidgetRun) this.widgets.get(i)).applyToWidget();
        }
    }

    public final void clear() {
        this.runGroup = null;
        List list = this.widgets;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            ((WidgetRun) list.get(i)).clear();
        }
    }

    public final long getWrapDimension() {
        long j = 0;
        for (int i = 0; i < this.widgets.size(); i++) {
            WidgetRun widgetRun = (WidgetRun) this.widgets.get(i);
            j = ((j + ((long) widgetRun.start.margin)) + widgetRun.getWrapDimension()) + ((long) widgetRun.end.margin);
        }
        return j;
    }

    public final boolean supportsWrapComputation() {
        int size = this.widgets.size();
        for (int i = 0; i < size; i++) {
            if (!((WidgetRun) this.widgets.get(i)).supportsWrapComputation()) {
                return false;
            }
        }
        return true;
    }

    public final String toString() {
        String str;
        StringBuilder stringBuilder = new StringBuilder("ChainRun ");
        if (this.orientation == 0) {
            str = "horizontal : ";
        } else {
            str = "vertical : ";
        }
        stringBuilder.append(str);
        List list = this.widgets;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            WidgetRun widgetRun = (WidgetRun) list.get(i);
            stringBuilder.append("<");
            stringBuilder.append(widgetRun);
            stringBuilder.append("> ");
        }
        return stringBuilder.toString();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void update$ar$ds$4cba2fec_0() {
        /*
        r25 = this;
        r0 = r25;
        r1 = r0.start;
        r2 = r1.resolved;
        if (r2 == 0) goto L_0x0415;
    L_0x0008:
        r2 = r0.end;
        r3 = r2.resolved;
        if (r3 != 0) goto L_0x0010;
    L_0x000e:
        goto L_0x0415;
    L_0x0010:
        r3 = r0.widget;
        r3 = r3.mParent;
        r4 = r3 instanceof androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
        if (r4 == 0) goto L_0x001d;
    L_0x0018:
        r3 = (androidx.constraintlayout.core.widgets.ConstraintWidgetContainer) r3;
        r3 = r3.mIsRtl;
        goto L_0x001e;
    L_0x001d:
        r3 = 0;
    L_0x001e:
        r2 = r2.value;
        r1 = r1.value;
        r2 = r2 - r1;
        r1 = r0.widgets;
        r1 = r1.size();
        r4 = 0;
    L_0x002a:
        r7 = 8;
        if (r4 >= r1) goto L_0x003f;
    L_0x002e:
        r8 = r0.widgets;
        r8 = r8.get(r4);
        r8 = (androidx.constraintlayout.core.widgets.analyzer.WidgetRun) r8;
        r8 = r8.widget;
        r8 = r8.mVisibility;
        if (r8 != r7) goto L_0x0040;
    L_0x003c:
        r4 = r4 + 1;
        goto L_0x002a;
    L_0x003f:
        r4 = -1;
    L_0x0040:
        r8 = r1 + -1;
        r9 = r8;
    L_0x0043:
        if (r9 < 0) goto L_0x0056;
    L_0x0045:
        r10 = r0.widgets;
        r10 = r10.get(r9);
        r10 = (androidx.constraintlayout.core.widgets.analyzer.WidgetRun) r10;
        r10 = r10.widget;
        r10 = r10.mVisibility;
        if (r10 != r7) goto L_0x0057;
    L_0x0053:
        r9 = r9 + -1;
        goto L_0x0043;
    L_0x0056:
        r9 = -1;
    L_0x0057:
        r10 = 0;
    L_0x0058:
        r12 = 3;
        r13 = 2;
        if (r10 >= r13) goto L_0x0101;
    L_0x005c:
        r6 = 0;
        r15 = 0;
        r16 = 0;
        r17 = 0;
        r18 = 0;
    L_0x0064:
        if (r15 >= r1) goto L_0x00f0;
    L_0x0066:
        r5 = r0.widgets;
        r5 = r5.get(r15);
        r5 = (androidx.constraintlayout.core.widgets.analyzer.WidgetRun) r5;
        r13 = r5.widget;
        r11 = r13.mVisibility;
        if (r11 != r7) goto L_0x0076;
    L_0x0074:
        goto L_0x00e8;
    L_0x0076:
        r18 = r18 + 1;
        if (r15 <= 0) goto L_0x0081;
    L_0x007a:
        if (r15 < r4) goto L_0x0081;
    L_0x007c:
        r11 = r5.start;
        r11 = r11.margin;
        r6 = r6 + r11;
    L_0x0081:
        r11 = r5.dimension;
        r7 = r11.value;
        r14 = r5.dimensionBehavior$ar$edu;
        if (r14 == r12) goto L_0x008b;
    L_0x0089:
        r14 = 1;
        goto L_0x008c;
    L_0x008b:
        r14 = 0;
    L_0x008c:
        if (r14 == 0) goto L_0x00ae;
    L_0x008e:
        r11 = r0.orientation;
        if (r11 != 0) goto L_0x009e;
    L_0x0092:
        r11 = r13.horizontalRun;
        r11 = r11.dimension;
        r11 = r11.resolved;
        if (r11 == 0) goto L_0x009d;
    L_0x009a:
        r20 = r7;
        goto L_0x00c5;
    L_0x009d:
        return;
    L_0x009e:
        r12 = 1;
        if (r11 != r12) goto L_0x00ab;
    L_0x00a1:
        r11 = r13.verticalRun;
        r11 = r11.dimension;
        r11 = r11.resolved;
        if (r11 == 0) goto L_0x00aa;
    L_0x00a9:
        goto L_0x00ab;
    L_0x00aa:
        return;
    L_0x00ab:
        r20 = r7;
        goto L_0x00c5;
    L_0x00ae:
        r12 = r5.matchConstraintsType;
        r20 = r7;
        r7 = 1;
        if (r12 != r7) goto L_0x00bd;
    L_0x00b5:
        if (r10 != 0) goto L_0x00bd;
    L_0x00b7:
        r7 = r11.wrapValue;
        r16 = r16 + 1;
        r14 = 1;
        goto L_0x00c7;
    L_0x00bd:
        r7 = r11.resolved;
        if (r7 == 0) goto L_0x00c5;
    L_0x00c1:
        r7 = r20;
        r14 = 1;
        goto L_0x00c7;
    L_0x00c5:
        r7 = r20;
    L_0x00c7:
        if (r14 != 0) goto L_0x00db;
    L_0x00c9:
        r16 = r16 + 1;
        r7 = r13.mWeight;
        r11 = r0.orientation;
        r7 = r7[r11];
        r11 = 0;
        r12 = (r7 > r11 ? 1 : (r7 == r11 ? 0 : -1));
        if (r12 < 0) goto L_0x00d9;
    L_0x00d6:
        r17 = r17 + r7;
        goto L_0x00da;
    L_0x00da:
        goto L_0x00dc;
    L_0x00db:
        r6 = r6 + r7;
    L_0x00dc:
        if (r15 >= r8) goto L_0x00e7;
    L_0x00de:
        if (r15 >= r9) goto L_0x00e7;
    L_0x00e0:
        r5 = r5.end;
        r5 = r5.margin;
        r5 = -r5;
        r6 = r6 + r5;
        goto L_0x00e8;
    L_0x00e8:
        r15 = r15 + 1;
        r7 = 8;
        r12 = 3;
        r13 = 2;
        goto L_0x0064;
    L_0x00f0:
        if (r6 < r2) goto L_0x00fb;
    L_0x00f2:
        if (r16 != 0) goto L_0x00f5;
    L_0x00f4:
        goto L_0x00fc;
    L_0x00f5:
        r10 = r10 + 1;
        r7 = 8;
        goto L_0x0058;
    L_0x00fc:
        r5 = r16;
        r7 = r18;
        goto L_0x0106;
    L_0x0101:
        r5 = 0;
        r6 = 0;
        r7 = 0;
        r17 = 0;
    L_0x0106:
        r10 = r0.start;
        r10 = r10.value;
        if (r3 == 0) goto L_0x0110;
    L_0x010c:
        r10 = r0.end;
        r10 = r10.value;
    L_0x0110:
        r11 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        if (r6 <= r2) goto L_0x0127;
    L_0x0114:
        r12 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r3 == 0) goto L_0x0120;
    L_0x0118:
        r13 = r6 - r2;
        r13 = (float) r13;
        r13 = r13 / r12;
        r13 = r13 + r11;
        r12 = (int) r13;
        r10 = r10 + r12;
        goto L_0x0127;
    L_0x0120:
        r13 = r6 - r2;
        r13 = (float) r13;
        r13 = r13 / r12;
        r13 = r13 + r11;
        r12 = (int) r13;
        r10 = r10 - r12;
    L_0x0127:
        if (r5 <= 0) goto L_0x020f;
    L_0x0129:
        r12 = r2 - r6;
        r12 = (float) r12;
        r13 = (float) r5;
        r13 = r12 / r13;
        r13 = r13 + r11;
        r13 = (int) r13;
        r14 = 0;
        r15 = 0;
    L_0x0133:
        if (r14 >= r1) goto L_0x01c7;
    L_0x0135:
        r11 = r0.widgets;
        r11 = r11.get(r14);
        r11 = (androidx.constraintlayout.core.widgets.analyzer.WidgetRun) r11;
        r18 = r6;
        r6 = r11.widget;
        r20 = r13;
        r13 = r6.mVisibility;
        r21 = r10;
        r10 = 8;
        if (r13 != r10) goto L_0x0153;
    L_0x014b:
        r22 = r3;
        r24 = r7;
        r23 = r12;
        goto L_0x01b5;
    L_0x0153:
        r10 = r11.dimensionBehavior$ar$edu;
        r13 = 3;
        if (r10 != r13) goto L_0x01af;
    L_0x0158:
        r10 = r11.dimension;
        r13 = r10.resolved;
        if (r13 != 0) goto L_0x01af;
    L_0x015e:
        r13 = 0;
        r19 = (r17 > r13 ? 1 : (r17 == r13 ? 0 : -1));
        if (r19 <= 0) goto L_0x0174;
    L_0x0163:
        r13 = r6.mWeight;
        r22 = r3;
        r3 = r0.orientation;
        r3 = r13[r3];
        r3 = r3 * r12;
        r3 = r3 / r17;
        r13 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r3 = r3 + r13;
        r3 = (int) r3;
        goto L_0x0178;
    L_0x0174:
        r22 = r3;
        r3 = r20;
    L_0x0178:
        r13 = r0.orientation;
        if (r13 != 0) goto L_0x0181;
    L_0x017c:
        r13 = r6.mMatchConstraintMaxWidth;
        r6 = r6.mMatchConstraintMinWidth;
        goto L_0x0185;
    L_0x0181:
        r13 = r6.mMatchConstraintMaxHeight;
        r6 = r6.mMatchConstraintMinHeight;
    L_0x0185:
        r23 = r12;
        r12 = r11.matchConstraintsType;
        r24 = r7;
        r7 = 1;
        if (r12 != r7) goto L_0x0195;
    L_0x018e:
        r7 = r10.wrapValue;
        r7 = java.lang.Math.min(r3, r7);
        goto L_0x0196;
    L_0x0195:
        r7 = r3;
    L_0x0196:
        r6 = java.lang.Math.max(r6, r7);
        if (r13 <= 0) goto L_0x01a1;
    L_0x019c:
        r6 = java.lang.Math.min(r13, r6);
        goto L_0x01a2;
    L_0x01a2:
        if (r6 == r3) goto L_0x01a8;
    L_0x01a4:
        r15 = r15 + 1;
        r3 = r6;
        goto L_0x01a9;
    L_0x01a9:
        r6 = r11.dimension;
        r6.resolve(r3);
        goto L_0x01b5;
    L_0x01af:
        r22 = r3;
        r24 = r7;
        r23 = r12;
    L_0x01b5:
        r14 = r14 + 1;
        r6 = r18;
        r13 = r20;
        r10 = r21;
        r3 = r22;
        r12 = r23;
        r7 = r24;
        r11 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        goto L_0x0133;
    L_0x01c7:
        r22 = r3;
        r18 = r6;
        r24 = r7;
        r21 = r10;
        if (r15 <= 0) goto L_0x0202;
    L_0x01d1:
        r5 = r5 - r15;
        r3 = 0;
        r6 = 0;
    L_0x01d4:
        if (r3 >= r1) goto L_0x0204;
    L_0x01d6:
        r7 = r0.widgets;
        r7 = r7.get(r3);
        r7 = (androidx.constraintlayout.core.widgets.analyzer.WidgetRun) r7;
        r10 = r7.widget;
        r10 = r10.mVisibility;
        r11 = 8;
        if (r10 != r11) goto L_0x01e7;
    L_0x01e6:
        goto L_0x01ff;
    L_0x01e7:
        if (r3 <= 0) goto L_0x01f0;
    L_0x01e9:
        if (r3 < r4) goto L_0x01f0;
    L_0x01eb:
        r10 = r7.start;
        r10 = r10.margin;
        r6 = r6 + r10;
    L_0x01f0:
        r10 = r7.dimension;
        r10 = r10.value;
        r6 = r6 + r10;
        if (r3 >= r8) goto L_0x01ff;
    L_0x01f7:
        if (r3 >= r9) goto L_0x01ff;
    L_0x01f9:
        r7 = r7.end;
        r7 = r7.margin;
        r7 = -r7;
        r6 = r6 + r7;
    L_0x01ff:
        r3 = r3 + 1;
        goto L_0x01d4;
    L_0x0202:
        r6 = r18;
    L_0x0204:
        r3 = r0.chainStyle;
        r7 = 2;
        if (r3 != r7) goto L_0x0217;
    L_0x0209:
        if (r15 != 0) goto L_0x0217;
    L_0x020b:
        r3 = 0;
        r0.chainStyle = r3;
        goto L_0x0218;
    L_0x020f:
        r22 = r3;
        r18 = r6;
        r24 = r7;
        r21 = r10;
    L_0x0217:
        r3 = 0;
    L_0x0218:
        if (r6 <= r2) goto L_0x021e;
    L_0x021a:
        r7 = 2;
        r0.chainStyle = r7;
        goto L_0x021f;
    L_0x021e:
        r7 = 2;
    L_0x021f:
        if (r24 <= 0) goto L_0x022b;
    L_0x0221:
        if (r5 != 0) goto L_0x022b;
    L_0x0223:
        if (r4 != r9) goto L_0x0229;
    L_0x0225:
        r0.chainStyle = r7;
        r5 = 0;
        goto L_0x022c;
    L_0x0229:
        r5 = 0;
        goto L_0x022c;
    L_0x022c:
        r7 = r0.chainStyle;
        r10 = 1;
        if (r7 != r10) goto L_0x02d1;
    L_0x0231:
        r11 = r24;
        if (r11 <= r10) goto L_0x023b;
    L_0x0235:
        r2 = r2 - r6;
        r6 = -1;
        r7 = r11 + -1;
        r2 = r2 / r7;
        goto L_0x0242;
    L_0x023b:
        if (r11 != r10) goto L_0x0241;
    L_0x023d:
        r2 = r2 - r6;
        r6 = 2;
        r2 = r2 / r6;
        goto L_0x0242;
    L_0x0241:
        r2 = 0;
    L_0x0242:
        if (r5 <= 0) goto L_0x0245;
    L_0x0244:
        r2 = 0;
    L_0x0245:
        r10 = r21;
        r5 = 0;
    L_0x0248:
        if (r5 >= r1) goto L_0x0414;
    L_0x024a:
        if (r22 == 0) goto L_0x0251;
    L_0x024c:
        r3 = r5 + 1;
        r3 = r1 - r3;
        goto L_0x0252;
    L_0x0251:
        r3 = r5;
    L_0x0252:
        r6 = r0.widgets;
        r3 = r6.get(r3);
        r3 = (androidx.constraintlayout.core.widgets.analyzer.WidgetRun) r3;
        r6 = r3.widget;
        r6 = r6.mVisibility;
        r7 = 8;
        if (r6 != r7) goto L_0x026d;
    L_0x0262:
        r6 = r3.start;
        r6.resolve(r10);
        r3 = r3.end;
        r3.resolve(r10);
        goto L_0x02cd;
    L_0x026d:
        if (r5 <= 0) goto L_0x0274;
    L_0x026f:
        if (r22 == 0) goto L_0x0273;
    L_0x0271:
        r10 = r10 - r2;
        goto L_0x0274;
    L_0x0273:
        r10 = r10 + r2;
    L_0x0274:
        if (r5 <= 0) goto L_0x0285;
    L_0x0276:
        if (r5 < r4) goto L_0x0285;
    L_0x0278:
        if (r22 == 0) goto L_0x0280;
    L_0x027a:
        r6 = r3.start;
        r6 = r6.margin;
        r10 = r10 - r6;
        goto L_0x0285;
    L_0x0280:
        r6 = r3.start;
        r6 = r6.margin;
        r10 = r10 + r6;
    L_0x0285:
        if (r22 == 0) goto L_0x028d;
    L_0x0287:
        r6 = r3.end;
        r6.resolve(r10);
        goto L_0x0292;
    L_0x028d:
        r6 = r3.start;
        r6.resolve(r10);
    L_0x0292:
        r6 = r3.dimension;
        r7 = r6.value;
        r11 = r3.dimensionBehavior$ar$edu;
        r12 = 3;
        if (r11 != r12) goto L_0x02a3;
    L_0x029b:
        r11 = r3.matchConstraintsType;
        r12 = 1;
        if (r11 != r12) goto L_0x02a3;
    L_0x02a0:
        r7 = r6.wrapValue;
        goto L_0x02a4;
    L_0x02a4:
        if (r22 == 0) goto L_0x02a8;
    L_0x02a6:
        r10 = r10 - r7;
        goto L_0x02a9;
    L_0x02a8:
        r10 = r10 + r7;
    L_0x02a9:
        if (r22 == 0) goto L_0x02b1;
    L_0x02ab:
        r6 = r3.start;
        r6.resolve(r10);
        goto L_0x02b6;
    L_0x02b1:
        r6 = r3.end;
        r6.resolve(r10);
        r6 = 1;
        r3.resolved = r6;
        if (r5 >= r8) goto L_0x02cd;
    L_0x02bc:
        if (r5 >= r9) goto L_0x02cd;
    L_0x02be:
        if (r22 == 0) goto L_0x02c7;
    L_0x02c0:
        r3 = r3.end;
        r3 = r3.margin;
        r3 = -r3;
        r10 = r10 - r3;
        goto L_0x02cd;
    L_0x02c7:
        r3 = r3.end;
        r3 = r3.margin;
        r3 = -r3;
        r10 = r10 + r3;
    L_0x02cd:
        r5 = r5 + 1;
        goto L_0x0248;
    L_0x02d1:
        r11 = r24;
        if (r7 != 0) goto L_0x0367;
    L_0x02d5:
        r2 = r2 - r6;
        r6 = 1;
        r7 = r11 + 1;
        r2 = r2 / r7;
        if (r5 <= 0) goto L_0x02dd;
    L_0x02dc:
        r2 = 0;
    L_0x02dd:
        r10 = r21;
        r5 = 0;
    L_0x02e0:
        if (r5 >= r1) goto L_0x0414;
    L_0x02e2:
        if (r22 == 0) goto L_0x02e9;
    L_0x02e4:
        r3 = r5 + 1;
        r3 = r1 - r3;
        goto L_0x02ea;
    L_0x02e9:
        r3 = r5;
    L_0x02ea:
        r6 = r0.widgets;
        r3 = r6.get(r3);
        r3 = (androidx.constraintlayout.core.widgets.analyzer.WidgetRun) r3;
        r6 = r3.widget;
        r6 = r6.mVisibility;
        r7 = 8;
        if (r6 != r7) goto L_0x0305;
    L_0x02fa:
        r6 = r3.start;
        r6.resolve(r10);
        r3 = r3.end;
        r3.resolve(r10);
        goto L_0x0363;
    L_0x0305:
        if (r22 == 0) goto L_0x0309;
    L_0x0307:
        r10 = r10 - r2;
        goto L_0x030a;
    L_0x0309:
        r10 = r10 + r2;
    L_0x030a:
        if (r5 <= 0) goto L_0x031b;
    L_0x030c:
        if (r5 < r4) goto L_0x031b;
    L_0x030e:
        if (r22 == 0) goto L_0x0316;
    L_0x0310:
        r6 = r3.start;
        r6 = r6.margin;
        r10 = r10 - r6;
        goto L_0x031b;
    L_0x0316:
        r6 = r3.start;
        r6 = r6.margin;
        r10 = r10 + r6;
    L_0x031b:
        if (r22 == 0) goto L_0x0323;
    L_0x031d:
        r6 = r3.end;
        r6.resolve(r10);
        goto L_0x0328;
    L_0x0323:
        r6 = r3.start;
        r6.resolve(r10);
    L_0x0328:
        r6 = r3.dimension;
        r7 = r6.value;
        r11 = r3.dimensionBehavior$ar$edu;
        r12 = 3;
        if (r11 != r12) goto L_0x033d;
    L_0x0331:
        r11 = r3.matchConstraintsType;
        r12 = 1;
        if (r11 != r12) goto L_0x033d;
    L_0x0336:
        r6 = r6.wrapValue;
        r7 = java.lang.Math.min(r7, r6);
        goto L_0x033e;
    L_0x033e:
        if (r22 == 0) goto L_0x0342;
    L_0x0340:
        r10 = r10 - r7;
        goto L_0x0343;
    L_0x0342:
        r10 = r10 + r7;
    L_0x0343:
        if (r22 == 0) goto L_0x034b;
    L_0x0345:
        r6 = r3.start;
        r6.resolve(r10);
        goto L_0x0350;
    L_0x034b:
        r6 = r3.end;
        r6.resolve(r10);
    L_0x0350:
        if (r5 >= r8) goto L_0x0363;
    L_0x0352:
        if (r5 >= r9) goto L_0x0363;
    L_0x0354:
        if (r22 == 0) goto L_0x035d;
    L_0x0356:
        r3 = r3.end;
        r3 = r3.margin;
        r3 = -r3;
        r10 = r10 - r3;
        goto L_0x0363;
    L_0x035d:
        r3 = r3.end;
        r3 = r3.margin;
        r3 = -r3;
        r10 = r10 + r3;
    L_0x0363:
        r5 = r5 + 1;
        goto L_0x02e0;
    L_0x0367:
        r10 = 2;
        if (r7 != r10) goto L_0x0414;
    L_0x036a:
        r7 = r0.orientation;
        if (r7 != 0) goto L_0x0373;
    L_0x036e:
        r7 = r0.widget;
        r7 = r7.mHorizontalBiasPercent;
        goto L_0x0377;
    L_0x0373:
        r7 = r0.widget;
        r7 = r7.mVerticalBiasPercent;
    L_0x0377:
        if (r22 == 0) goto L_0x037d;
    L_0x0379:
        r10 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r7 = r10 - r7;
    L_0x037d:
        r2 = r2 - r6;
        r2 = (float) r2;
        r2 = r2 * r7;
        r6 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r2 = r2 + r6;
        r2 = (int) r2;
        if (r2 < 0) goto L_0x038b;
    L_0x0387:
        if (r5 <= 0) goto L_0x038c;
    L_0x0389:
        r2 = 0;
        goto L_0x038c;
    L_0x038b:
        r2 = 0;
    L_0x038c:
        if (r22 == 0) goto L_0x0391;
    L_0x038e:
        r10 = r21 - r2;
        goto L_0x0393;
    L_0x0391:
        r10 = r21 + r2;
    L_0x0393:
        r5 = 0;
    L_0x0394:
        if (r5 >= r1) goto L_0x0414;
    L_0x0396:
        if (r22 == 0) goto L_0x039d;
    L_0x0398:
        r2 = r5 + 1;
        r2 = r1 - r2;
        goto L_0x039e;
    L_0x039d:
        r2 = r5;
    L_0x039e:
        r3 = r0.widgets;
        r2 = r3.get(r2);
        r2 = (androidx.constraintlayout.core.widgets.analyzer.WidgetRun) r2;
        r3 = r2.widget;
        r3 = r3.mVisibility;
        r6 = 8;
        if (r3 != r6) goto L_0x03bb;
    L_0x03ae:
        r3 = r2.start;
        r3.resolve(r10);
        r2 = r2.end;
        r2.resolve(r10);
        r12 = 3;
        r13 = 1;
        goto L_0x0411;
    L_0x03bb:
        if (r5 <= 0) goto L_0x03cc;
    L_0x03bd:
        if (r5 < r4) goto L_0x03cc;
    L_0x03bf:
        if (r22 == 0) goto L_0x03c7;
    L_0x03c1:
        r3 = r2.start;
        r3 = r3.margin;
        r10 = r10 - r3;
        goto L_0x03cc;
    L_0x03c7:
        r3 = r2.start;
        r3 = r3.margin;
        r10 = r10 + r3;
    L_0x03cc:
        if (r22 == 0) goto L_0x03d4;
    L_0x03ce:
        r3 = r2.end;
        r3.resolve(r10);
        goto L_0x03d9;
    L_0x03d4:
        r3 = r2.start;
        r3.resolve(r10);
    L_0x03d9:
        r3 = r2.dimension;
        r7 = r3.value;
        r11 = r2.dimensionBehavior$ar$edu;
        r12 = 3;
        if (r11 != r12) goto L_0x03ea;
    L_0x03e2:
        r11 = r2.matchConstraintsType;
        r13 = 1;
        if (r11 != r13) goto L_0x03eb;
    L_0x03e7:
        r7 = r3.wrapValue;
        goto L_0x03ec;
    L_0x03ea:
        r13 = 1;
    L_0x03ec:
        if (r22 == 0) goto L_0x03f0;
    L_0x03ee:
        r10 = r10 - r7;
        goto L_0x03f1;
    L_0x03f0:
        r10 = r10 + r7;
    L_0x03f1:
        if (r22 == 0) goto L_0x03f9;
    L_0x03f3:
        r3 = r2.start;
        r3.resolve(r10);
        goto L_0x03fe;
    L_0x03f9:
        r3 = r2.end;
        r3.resolve(r10);
    L_0x03fe:
        if (r5 >= r8) goto L_0x0411;
    L_0x0400:
        if (r5 >= r9) goto L_0x0411;
    L_0x0402:
        if (r22 == 0) goto L_0x040b;
    L_0x0404:
        r2 = r2.end;
        r2 = r2.margin;
        r2 = -r2;
        r10 = r10 - r2;
        goto L_0x0411;
    L_0x040b:
        r2 = r2.end;
        r2 = r2.margin;
        r2 = -r2;
        r10 = r10 + r2;
    L_0x0411:
        r5 = r5 + 1;
        goto L_0x0394;
    L_0x0414:
        return;
    L_0x0415:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.core.widgets.analyzer.ChainRun.update$ar$ds$4cba2fec_0():void");
    }
}
