package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintWidget;

/* compiled from: PG */
public final class VerticalWidgetRun extends WidgetRun {
    public final DependencyNode baseline;
    DimensionDependency baselineDimension;

    public VerticalWidgetRun(ConstraintWidget constraintWidget) {
        super(constraintWidget);
        DependencyNode dependencyNode = new DependencyNode(this);
        this.baseline = dependencyNode;
        this.baselineDimension = null;
        this.start.type$ar$edu = 6;
        this.end.type$ar$edu = 7;
        dependencyNode.type$ar$edu = 8;
        this.orientation = 1;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void apply() {
        /*
        r10 = this;
        r0 = r10.widget;
        r1 = r0.measured;
        if (r1 == 0) goto L_0x000f;
    L_0x0006:
        r1 = r10.dimension;
        r0 = r0.getHeight();
        r1.resolve(r0);
    L_0x000f:
        r0 = r10.dimension;
        r0 = r0.resolved;
        r1 = 4;
        r2 = 1;
        r3 = 3;
        if (r0 != 0) goto L_0x0091;
    L_0x0018:
        r0 = r10.widget;
        r0 = r0.getVerticalDimensionBehaviour$ar$edu();
        r10.dimensionBehavior$ar$edu = r0;
        r0 = r10.widget;
        r0 = r0.hasBaseline;
        if (r0 == 0) goto L_0x002d;
    L_0x0026:
        r0 = new androidx.constraintlayout.core.widgets.analyzer.BaselineDimensionDependency;
        r0.<init>(r10);
        r10.baselineDimension = r0;
    L_0x002d:
        r0 = r10.dimensionBehavior$ar$edu;
        if (r0 == r3) goto L_0x00c5;
    L_0x0031:
        r0 = r10.dimensionBehavior$ar$edu;
        if (r0 != r1) goto L_0x0081;
    L_0x0035:
        r0 = r10.widget;
        r0 = r0.mParent;
        if (r0 == 0) goto L_0x0081;
    L_0x003b:
        r4 = r0.getVerticalDimensionBehaviour$ar$edu();
        if (r4 == r2) goto L_0x0042;
    L_0x0041:
        goto L_0x0081;
    L_0x0042:
        r1 = r0.getHeight();
        r2 = r10.widget;
        r2 = r2.mTop;
        r2 = r2.getMargin();
        r3 = r10.widget;
        r3 = r3.mBottom;
        r3 = r3.getMargin();
        r4 = r10.start;
        r5 = r0.verticalRun;
        r5 = r5.start;
        r6 = r10.widget;
        r6 = r6.mTop;
        r6 = r6.getMargin();
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r4, r5, r6);
        r4 = r10.end;
        r0 = r0.verticalRun;
        r0 = r0.end;
        r5 = r10.widget;
        r5 = r5.mBottom;
        r5 = r5.getMargin();
        r5 = -r5;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r4, r0, r5);
        r0 = r10.dimension;
        r1 = r1 - r2;
        r1 = r1 - r3;
        r0.resolve(r1);
        return;
    L_0x0081:
        r0 = r10.dimensionBehavior$ar$edu;
        if (r0 != r2) goto L_0x00c5;
    L_0x0085:
        r0 = r10.dimension;
        r4 = r10.widget;
        r4 = r4.getHeight();
        r0.resolve(r4);
        goto L_0x00c5;
    L_0x0091:
        r0 = r10.dimensionBehavior$ar$edu;
        if (r0 != r1) goto L_0x00c5;
    L_0x0095:
        r0 = r10.widget;
        r0 = r0.mParent;
        if (r0 == 0) goto L_0x00c5;
    L_0x009b:
        r4 = r0.getVerticalDimensionBehaviour$ar$edu();
        if (r4 != r2) goto L_0x00c5;
    L_0x00a1:
        r1 = r10.start;
        r2 = r0.verticalRun;
        r2 = r2.start;
        r3 = r10.widget;
        r3 = r3.mTop;
        r3 = r3.getMargin();
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r2, r3);
        r1 = r10.end;
        r0 = r0.verticalRun;
        r0 = r0.end;
        r2 = r10.widget;
        r2 = r2.mBottom;
        r2 = r2.getMargin();
        r2 = -r2;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r2);
        return;
    L_0x00c5:
        r0 = r10.dimension;
        r4 = r0.resolved;
        r5 = 0;
        r6 = 2;
        if (r4 == 0) goto L_0x0226;
    L_0x00cd:
        r4 = r10.widget;
        r7 = r4.measured;
        if (r7 == 0) goto L_0x028e;
    L_0x00d3:
        r0 = r4.mListAnchors;
        r7 = r0[r6];
        r8 = r7.mTarget;
        if (r8 == 0) goto L_0x0154;
    L_0x00db:
        r9 = r0[r3];
        r9 = r9.mTarget;
        if (r9 == 0) goto L_0x0154;
    L_0x00e1:
        r0 = r4.isInVerticalChain();
        if (r0 == 0) goto L_0x0105;
    L_0x00e7:
        r0 = r10.start;
        r1 = r10.widget;
        r1 = r1.mListAnchors;
        r1 = r1[r6];
        r1 = r1.getMargin();
        r0.margin = r1;
        r0 = r10.end;
        r1 = r10.widget;
        r1 = r1.mListAnchors;
        r1 = r1[r3];
        r1 = r1.getMargin();
        r1 = -r1;
        r0.margin = r1;
        goto L_0x0144;
    L_0x0105:
        r0 = r10.widget;
        r0 = r0.mListAnchors;
        r0 = r0[r6];
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r0);
        if (r0 == 0) goto L_0x0120;
    L_0x0111:
        r1 = r10.start;
        r4 = r10.widget;
        r4 = r4.mListAnchors;
        r4 = r4[r6];
        r4 = r4.getMargin();
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r4);
    L_0x0120:
        r0 = r10.widget;
        r0 = r0.mListAnchors;
        r0 = r0[r3];
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r0);
        if (r0 == 0) goto L_0x013c;
    L_0x012c:
        r1 = r10.end;
        r4 = r10.widget;
        r4 = r4.mListAnchors;
        r3 = r4[r3];
        r3 = r3.getMargin();
        r3 = -r3;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r3);
    L_0x013c:
        r0 = r10.start;
        r0.delegateToWidgetRun = r2;
        r0 = r10.end;
        r0.delegateToWidgetRun = r2;
    L_0x0144:
        r0 = r10.widget;
        r1 = r0.hasBaseline;
        if (r1 == 0) goto L_0x0419;
    L_0x014a:
        r1 = r10.baseline;
        r2 = r10.start;
        r0 = r0.mBaselineDistance;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r2, r0);
        return;
    L_0x0154:
        if (r8 == 0) goto L_0x0186;
    L_0x0156:
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r7);
        if (r0 == 0) goto L_0x0419;
    L_0x015c:
        r1 = r10.start;
        r2 = r10.widget;
        r2 = r2.mListAnchors;
        r2 = r2[r6];
        r2 = r2.getMargin();
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r2);
        r0 = r10.end;
        r1 = r10.start;
        r2 = r10.dimension;
        r2 = r2.value;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r0, r1, r2);
        r0 = r10.widget;
        r1 = r0.hasBaseline;
        if (r1 == 0) goto L_0x0419;
    L_0x017c:
        r1 = r10.baseline;
        r2 = r10.start;
        r0 = r0.mBaselineDistance;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r2, r0);
        return;
        r2 = r0[r3];
        r6 = r2.mTarget;
        if (r6 == 0) goto L_0x01bf;
    L_0x018d:
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r2);
        if (r0 == 0) goto L_0x01af;
    L_0x0193:
        r1 = r10.end;
        r2 = r10.widget;
        r2 = r2.mListAnchors;
        r2 = r2[r3];
        r2 = r2.getMargin();
        r2 = -r2;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r2);
        r0 = r10.start;
        r1 = r10.end;
        r2 = r10.dimension;
        r2 = r2.value;
        r2 = -r2;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r0, r1, r2);
    L_0x01af:
        r0 = r10.widget;
        r1 = r0.hasBaseline;
        if (r1 == 0) goto L_0x0419;
    L_0x01b5:
        r1 = r10.baseline;
        r2 = r10.start;
        r0 = r0.mBaselineDistance;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r2, r0);
        return;
        r0 = r0[r1];
        r1 = r0.mTarget;
        if (r1 == 0) goto L_0x01e9;
    L_0x01c6:
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r0);
        if (r0 == 0) goto L_0x0419;
    L_0x01cc:
        r1 = r10.baseline;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r5);
        r0 = r10.start;
        r1 = r10.baseline;
        r2 = r10.widget;
        r2 = r2.mBaselineDistance;
        r2 = -r2;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r0, r1, r2);
        r0 = r10.end;
        r1 = r10.start;
        r2 = r10.dimension;
        r2 = r2.value;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r0, r1, r2);
        return;
    L_0x01e9:
        r0 = r4 instanceof androidx.constraintlayout.core.widgets.HelperWidget;
        if (r0 != 0) goto L_0x0419;
    L_0x01ed:
        r0 = r4.mParent;
        if (r0 == 0) goto L_0x0419;
    L_0x01f1:
        r0 = 7;
        r0 = r4.getAnchor$ar$edu(r0);
        r0 = r0.mTarget;
        if (r0 != 0) goto L_0x0419;
    L_0x01fa:
        r0 = r10.widget;
        r1 = r0.mParent;
        r1 = r1.verticalRun;
        r1 = r1.start;
        r2 = r10.start;
        r0 = r0.getY();
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r2, r1, r0);
        r0 = r10.end;
        r1 = r10.start;
        r2 = r10.dimension;
        r2 = r2.value;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r0, r1, r2);
        r0 = r10.widget;
        r1 = r0.hasBaseline;
        if (r1 == 0) goto L_0x0419;
    L_0x021c:
        r1 = r10.baseline;
        r2 = r10.start;
        r0 = r0.mBaselineDistance;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r2, r0);
        return;
    L_0x0226:
        r4 = r10.dimensionBehavior$ar$edu;
        if (r4 != r3) goto L_0x028e;
    L_0x022a:
        r4 = r10.widget;
        r7 = r4.mMatchConstraintDefaultHeight;
        switch(r7) {
            case 2: goto L_0x0265;
            case 3: goto L_0x0232;
            default: goto L_0x0231;
        };
    L_0x0231:
        goto L_0x0291;
    L_0x0232:
        r0 = r4.isInVerticalChain();
        if (r0 != 0) goto L_0x0291;
    L_0x0238:
        r0 = r10.widget;
        r4 = r0.mMatchConstraintDefaultWidth;
        if (r4 == r3) goto L_0x0291;
    L_0x023e:
        r0 = r0.horizontalRun;
        r0 = r0.dimension;
        r4 = r10.dimension;
        r4 = r4.targets;
        r4.add(r0);
        r0 = r0.dependencies;
        r4 = r10.dimension;
        r0.add(r4);
        r0 = r10.dimension;
        r0.delegateToWidgetRun = r2;
        r0 = r0.dependencies;
        r4 = r10.start;
        r0.add(r4);
        r0 = r10.dimension;
        r0 = r0.dependencies;
        r4 = r10.end;
        r0.add(r4);
        goto L_0x0291;
    L_0x0265:
        r4 = r4.mParent;
        if (r4 == 0) goto L_0x0231;
    L_0x0269:
        r4 = r4.verticalRun;
        r4 = r4.dimension;
        r0 = r0.targets;
        r0.add(r4);
        r0 = r4.dependencies;
        r4 = r10.dimension;
        r0.add(r4);
        r0 = r10.dimension;
        r0.delegateToWidgetRun = r2;
        r0 = r0.dependencies;
        r4 = r10.start;
        r0.add(r4);
        r0 = r10.dimension;
        r0 = r0.dependencies;
        r4 = r10.end;
        r0.add(r4);
        goto L_0x0291;
    L_0x028e:
        r0.addDependency(r10);
    L_0x0291:
        r0 = r10.widget;
        r4 = r0.mListAnchors;
        r7 = r4[r6];
        r8 = r7.mTarget;
        if (r8 == 0) goto L_0x02f6;
    L_0x029b:
        r9 = r4[r3];
        r9 = r9.mTarget;
        if (r9 == 0) goto L_0x02f6;
    L_0x02a1:
        r0 = r0.isInVerticalChain();
        if (r0 == 0) goto L_0x02c5;
    L_0x02a7:
        r0 = r10.start;
        r1 = r10.widget;
        r1 = r1.mListAnchors;
        r1 = r1[r6];
        r1 = r1.getMargin();
        r0.margin = r1;
        r0 = r10.end;
        r1 = r10.widget;
        r1 = r1.mListAnchors;
        r1 = r1[r3];
        r1 = r1.getMargin();
        r1 = -r1;
        r0.margin = r1;
        goto L_0x02e5;
    L_0x02c5:
        r0 = r10.widget;
        r0 = r0.mListAnchors;
        r0 = r0[r6];
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r0);
        r4 = r10.widget;
        r4 = r4.mListAnchors;
        r3 = r4[r3];
        r3 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r3);
        if (r0 == 0) goto L_0x02de;
    L_0x02db:
        r0.addDependency(r10);
    L_0x02de:
        if (r3 == 0) goto L_0x02e3;
    L_0x02e0:
        r3.addDependency(r10);
    L_0x02e3:
        r10.mRunType$ar$edu = r1;
    L_0x02e5:
        r0 = r10.widget;
        r0 = r0.hasBaseline;
        if (r0 == 0) goto L_0x040a;
    L_0x02eb:
        r0 = r10.baseline;
        r1 = r10.start;
        r3 = r10.baselineDimension;
        r10.addTarget(r0, r1, r2, r3);
        goto L_0x040a;
    L_0x02f6:
        r9 = 0;
        if (r8 == 0) goto L_0x0354;
    L_0x02f9:
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r7);
        if (r0 == 0) goto L_0x040a;
    L_0x02ff:
        r1 = r10.start;
        r4 = r10.widget;
        r4 = r4.mListAnchors;
        r4 = r4[r6];
        r4 = r4.getMargin();
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r4);
        r0 = r10.end;
        r1 = r10.start;
        r4 = r10.dimension;
        r10.addTarget(r0, r1, r2, r4);
        r0 = r10.widget;
        r0 = r0.hasBaseline;
        if (r0 == 0) goto L_0x0326;
    L_0x031d:
        r0 = r10.baseline;
        r1 = r10.start;
        r4 = r10.baselineDimension;
        r10.addTarget(r0, r1, r2, r4);
    L_0x0326:
        r0 = r10.dimensionBehavior$ar$edu;
        if (r0 != r3) goto L_0x040a;
    L_0x032a:
        r0 = r10.widget;
        r1 = r0.mDimensionRatio;
        r1 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1));
        if (r1 <= 0) goto L_0x040a;
    L_0x0332:
        r0 = r0.horizontalRun;
        r1 = r0.dimensionBehavior$ar$edu;
        if (r1 != r3) goto L_0x040a;
    L_0x0338:
        r0 = r0.dimension;
        r0 = r0.dependencies;
        r1 = r10.dimension;
        r0.add(r1);
        r0 = r10.dimension;
        r0 = r0.targets;
        r1 = r10.widget;
        r1 = r1.horizontalRun;
        r1 = r1.dimension;
        r0.add(r1);
        r0 = r10.dimension;
        r0.updateDelegate = r10;
        goto L_0x040a;
        r6 = r4[r3];
        r7 = r6.mTarget;
        r8 = -1;
        if (r7 == 0) goto L_0x038c;
    L_0x035c:
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r6);
        if (r0 == 0) goto L_0x040a;
    L_0x0362:
        r1 = r10.end;
        r4 = r10.widget;
        r4 = r4.mListAnchors;
        r3 = r4[r3];
        r3 = r3.getMargin();
        r3 = -r3;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r3);
        r0 = r10.start;
        r1 = r10.end;
        r3 = r10.dimension;
        r10.addTarget(r0, r1, r8, r3);
        r0 = r10.widget;
        r0 = r0.hasBaseline;
        if (r0 == 0) goto L_0x040a;
    L_0x0381:
        r0 = r10.baseline;
        r1 = r10.start;
        r3 = r10.baselineDimension;
        r10.addTarget(r0, r1, r2, r3);
        goto L_0x040a;
        r1 = r4[r1];
        r4 = r1.mTarget;
        if (r4 == 0) goto L_0x03b1;
    L_0x0393:
        r0 = androidx.constraintlayout.core.widgets.analyzer.WidgetRun.getTarget$ar$ds(r1);
        if (r0 == 0) goto L_0x040a;
    L_0x0399:
        r1 = r10.baseline;
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r1, r0, r5);
        r0 = r10.start;
        r1 = r10.baseline;
        r3 = r10.baselineDimension;
        r10.addTarget(r0, r1, r8, r3);
        r0 = r10.end;
        r1 = r10.start;
        r3 = r10.dimension;
        r10.addTarget(r0, r1, r2, r3);
        goto L_0x040a;
    L_0x03b1:
        r1 = r0 instanceof androidx.constraintlayout.core.widgets.HelperWidget;
        if (r1 != 0) goto L_0x040a;
    L_0x03b5:
        r1 = r0.mParent;
        if (r1 == 0) goto L_0x040a;
    L_0x03b9:
        r1 = r1.verticalRun;
        r1 = r1.start;
        r4 = r10.start;
        r0 = r0.getY();
        androidx.constraintlayout.core.widgets.analyzer.WidgetRun.addTarget$ar$ds(r4, r1, r0);
        r0 = r10.end;
        r1 = r10.start;
        r4 = r10.dimension;
        r10.addTarget(r0, r1, r2, r4);
        r0 = r10.widget;
        r0 = r0.hasBaseline;
        if (r0 == 0) goto L_0x03de;
    L_0x03d5:
        r0 = r10.baseline;
        r1 = r10.start;
        r4 = r10.baselineDimension;
        r10.addTarget(r0, r1, r2, r4);
    L_0x03de:
        r0 = r10.dimensionBehavior$ar$edu;
        if (r0 != r3) goto L_0x040a;
    L_0x03e2:
        r0 = r10.widget;
        r1 = r0.mDimensionRatio;
        r1 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1));
        if (r1 <= 0) goto L_0x040a;
    L_0x03ea:
        r0 = r0.horizontalRun;
        r1 = r0.dimensionBehavior$ar$edu;
        if (r1 != r3) goto L_0x040a;
    L_0x03f0:
        r0 = r0.dimension;
        r0 = r0.dependencies;
        r1 = r10.dimension;
        r0.add(r1);
        r0 = r10.dimension;
        r0 = r0.targets;
        r1 = r10.widget;
        r1 = r1.horizontalRun;
        r1 = r1.dimension;
        r0.add(r1);
        r0 = r10.dimension;
        r0.updateDelegate = r10;
    L_0x040a:
        r0 = r10.dimension;
        r0 = r0.targets;
        r0 = r0.size();
        if (r0 != 0) goto L_0x0419;
    L_0x0414:
        r0 = r10.dimension;
        r0.readyToSolve = r2;
        return;
    L_0x0419:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.core.widgets.analyzer.VerticalWidgetRun.apply():void");
    }

    public final void applyToWidget() {
        DependencyNode dependencyNode = this.start;
        if (dependencyNode.resolved) {
            this.widget.f13mY = dependencyNode.value;
        }
    }

    public final void clear() {
        this.runGroup = null;
        this.start.clear();
        this.end.clear();
        this.baseline.clear();
        this.dimension.clear();
        this.resolved = false;
    }

    public final void reset() {
        this.resolved = false;
        this.start.clear();
        this.start.resolved = false;
        this.end.clear();
        this.end.resolved = false;
        this.baseline.clear();
        this.baseline.resolved = false;
        this.dimension.resolved = false;
    }

    public final boolean supportsWrapComputation() {
        return this.dimensionBehavior$ar$edu != 3 || this.widget.mMatchConstraintDefaultHeight == 0;
    }

    public final String toString() {
        String valueOf = String.valueOf(this.widget.mDebugName);
        String str = "VerticalRun ";
        return valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
    }

    public final void update$ar$ds$4cba2fec_0() {
        int i = this.mRunType$ar$edu;
        int i2 = i - 1;
        if (i != 0) {
            ConstraintWidget constraintWidget;
            switch (i2) {
                case 3:
                    constraintWidget = this.widget;
                    updateRunCenter$ar$ds(constraintWidget.mTop, constraintWidget.mBottom, 1);
                    return;
                default:
                    int i3;
                    DependencyNode dependencyNode = this.dimension;
                    if (dependencyNode.readyToSolve && !dependencyNode.resolved && this.dimensionBehavior$ar$edu == 3) {
                        ConstraintWidget constraintWidget2 = this.widget;
                        DependencyNode dependencyNode2;
                        switch (constraintWidget2.mMatchConstraintDefaultHeight) {
                            case 2:
                                ConstraintWidget constraintWidget3 = constraintWidget2.mParent;
                                if (constraintWidget3 != null) {
                                    dependencyNode2 = constraintWidget3.verticalRun.dimension;
                                    if (dependencyNode2.resolved) {
                                        dependencyNode.resolve((int) ((((float) dependencyNode2.value) * constraintWidget2.mMatchConstraintPercentHeight) + 0.5f));
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                dependencyNode2 = constraintWidget2.horizontalRun.dimension;
                                if (dependencyNode2.resolved) {
                                    switch (constraintWidget2.mDimensionRatioSide) {
                                        case -1:
                                            i3 = (int) ((((float) dependencyNode2.value) / constraintWidget2.mDimensionRatio) + 0.5f);
                                            break;
                                        case 0:
                                            i3 = (int) ((((float) dependencyNode2.value) * constraintWidget2.mDimensionRatio) + 0.5f);
                                            break;
                                        default:
                                            i3 = (int) ((((float) dependencyNode2.value) / constraintWidget2.mDimensionRatio) + 0.5f);
                                            break;
                                    }
                                    dependencyNode.resolve(i3);
                                    break;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    dependencyNode = this.start;
                    if (dependencyNode.readyToSolve) {
                        DependencyNode dependencyNode3 = this.end;
                        if (dependencyNode3.readyToSolve) {
                            DependencyNode dependencyNode4;
                            if (dependencyNode.resolved && dependencyNode3.resolved) {
                                if (this.dimension.resolved) {
                                    return;
                                }
                            }
                            if (!this.dimension.resolved && this.dimensionBehavior$ar$edu == 3) {
                                constraintWidget = this.widget;
                                if (constraintWidget.mMatchConstraintDefaultWidth == 0) {
                                    if (!constraintWidget.isInVerticalChain()) {
                                        dependencyNode = (DependencyNode) this.end.targets.get(0);
                                        i = ((DependencyNode) this.start.targets.get(0)).value;
                                        dependencyNode3 = this.start;
                                        i += dependencyNode3.margin;
                                        i2 = dependencyNode.value + this.end.margin;
                                        dependencyNode3.resolve(i);
                                        this.end.resolve(i2);
                                        this.dimension.resolve(i2 - i);
                                        return;
                                    }
                                }
                            }
                            if (!this.dimension.resolved && this.dimensionBehavior$ar$edu == 3 && this.matchConstraintsType == 1 && this.start.targets.size() > 0 && this.end.targets.size() > 0) {
                                i2 = (((DependencyNode) this.end.targets.get(0)).value + this.end.margin) - (((DependencyNode) this.start.targets.get(0)).value + this.start.margin);
                                dependencyNode4 = this.dimension;
                                int i4 = dependencyNode4.wrapValue;
                                if (i2 < i4) {
                                    dependencyNode4.resolve(i2);
                                } else {
                                    dependencyNode4.resolve(i4);
                                }
                            }
                            if (this.dimension.resolved && this.start.targets.size() > 0 && this.end.targets.size() > 0) {
                                dependencyNode4 = (DependencyNode) this.start.targets.get(0);
                                dependencyNode = (DependencyNode) this.end.targets.get(0);
                                i3 = dependencyNode4.value;
                                DependencyNode dependencyNode5 = this.start;
                                int i5 = dependencyNode5.margin + i3;
                                int i6 = dependencyNode.value;
                                int i7 = this.end.margin + i6;
                                float f = this.widget.mVerticalBiasPercent;
                                if (dependencyNode4 == dependencyNode) {
                                    f = 0.5f;
                                }
                                if (dependencyNode4 != dependencyNode) {
                                    i6 = i7;
                                }
                                if (dependencyNode4 != dependencyNode) {
                                    i3 = i5;
                                }
                                dependencyNode5.resolve((int) ((((float) i3) + 0.5f) + (((float) ((i6 - i3) - this.dimension.value)) * f)));
                                this.end.resolve(this.start.value + this.dimension.value);
                            }
                            return;
                        }
                    }
                    return;
            }
        }
        throw null;
    }
}
