package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.WidgetContainer;
import androidx.constraintlayout.widget.ConstraintLayout.Measurer;
import java.util.ArrayList;

/* compiled from: PG */
public final class BasicMeasure {
    public final ConstraintWidgetContainer constraintWidgetContainer;
    private final Measure mMeasure = new Measure();
    public final ArrayList mVariableDimensionsWidgets = new ArrayList();

    /* compiled from: PG */
    public final class Measure {
        public int horizontalBehavior$ar$edu;
        public int horizontalDimension;
        public int measureStrategy;
        public int measuredBaseline;
        public boolean measuredHasBaseline;
        public int measuredHeight;
        public boolean measuredNeedsSolverPass;
        public int measuredWidth;
        public int verticalBehavior$ar$edu;
        public int verticalDimension;
    }

    public BasicMeasure(ConstraintWidgetContainer constraintWidgetContainer) {
        this.constraintWidgetContainer = constraintWidgetContainer;
    }

    public final boolean measure$ar$class_merging$6b6fe65d_0(Measurer measurer, ConstraintWidget constraintWidget, int i) {
        Object obj;
        Object obj2;
        this.mMeasure.horizontalBehavior$ar$edu = constraintWidget.getHorizontalDimensionBehaviour$ar$edu();
        this.mMeasure.verticalBehavior$ar$edu = constraintWidget.getVerticalDimensionBehaviour$ar$edu();
        this.mMeasure.horizontalDimension = constraintWidget.getWidth();
        this.mMeasure.verticalDimension = constraintWidget.getHeight();
        Measure measure = this.mMeasure;
        measure.measuredNeedsSolverPass = false;
        measure.measureStrategy = i;
        i = measure.horizontalBehavior$ar$edu;
        int i2 = measure.verticalBehavior$ar$edu;
        if (i != 3 || constraintWidget.mDimensionRatio <= 0.0f) {
            obj = null;
        } else {
            obj = 1;
        }
        if (i2 != 3 || constraintWidget.mDimensionRatio <= 0.0f) {
            obj2 = null;
        } else {
            obj2 = 1;
        }
        if (obj != null && constraintWidget.mResolvedMatchConstraintDefault[0] == 4) {
            measure.horizontalBehavior$ar$edu = 1;
        }
        if (obj2 != null && constraintWidget.mResolvedMatchConstraintDefault[1] == 4) {
            measure.verticalBehavior$ar$edu = 1;
        }
        measurer.measure(constraintWidget, measure);
        constraintWidget.setWidth(this.mMeasure.measuredWidth);
        constraintWidget.setHeight(this.mMeasure.measuredHeight);
        Measure measure2 = this.mMeasure;
        constraintWidget.hasBaseline = measure2.measuredHasBaseline;
        constraintWidget.setBaselineDistance(measure2.measuredBaseline);
        measure2 = this.mMeasure;
        measure2.measureStrategy = 0;
        return measure2.measuredNeedsSolverPass;
    }

    public final void solveLinearSystem$ar$ds(ConstraintWidgetContainer constraintWidgetContainer, int i, int i2, int i3) {
        int i4 = constraintWidgetContainer.mMinWidth;
        int i5 = constraintWidgetContainer.mMinHeight;
        constraintWidgetContainer.setMinWidth(0);
        constraintWidgetContainer.setMinHeight(0);
        constraintWidgetContainer.setWidth(i2);
        constraintWidgetContainer.setHeight(i3);
        constraintWidgetContainer.setMinWidth(i4);
        constraintWidgetContainer.setMinHeight(i5);
        WidgetContainer widgetContainer = this.constraintWidgetContainer;
        widgetContainer.pass = i;
        widgetContainer.layout();
    }

    public final void updateHierarchy(ConstraintWidgetContainer constraintWidgetContainer) {
        this.mVariableDimensionsWidgets.clear();
        int size = constraintWidgetContainer.mChildren.size();
        for (int i = 0; i < size; i++) {
            ConstraintWidget constraintWidget = (ConstraintWidget) constraintWidgetContainer.mChildren.get(i);
            if (constraintWidget.getHorizontalDimensionBehaviour$ar$edu() == 3 || constraintWidget.getVerticalDimensionBehaviour$ar$edu() == 3) {
                this.mVariableDimensionsWidgets.add(constraintWidget);
            }
        }
        constraintWidgetContainer.invalidateGraph();
    }
}
