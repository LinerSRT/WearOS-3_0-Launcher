package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.Barrier;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure.Measure;
import androidx.constraintlayout.widget.ConstraintLayout.Measurer;

/* compiled from: PG */
public final class Direct {
    public static int hcount = 0;
    public static final Measure measure = new Measure();
    public static int vcount = 0;

    public static boolean canMeasure$ar$ds(ConstraintWidget constraintWidget) {
        Object obj;
        Object obj2;
        int horizontalDimensionBehaviour$ar$edu = constraintWidget.getHorizontalDimensionBehaviour$ar$edu();
        int verticalDimensionBehaviour$ar$edu = constraintWidget.getVerticalDimensionBehaviour$ar$edu();
        ConstraintWidget constraintWidget2 = constraintWidget.mParent;
        if (constraintWidget2 == null) {
            constraintWidget2 = null;
        }
        if (constraintWidget2 != null) {
            constraintWidget2.getHorizontalDimensionBehaviour$ar$edu();
        }
        if (constraintWidget2 != null) {
            constraintWidget2.getVerticalDimensionBehaviour$ar$edu();
        }
        if (horizontalDimensionBehaviour$ar$edu != 1 && !constraintWidget.isResolvedHorizontally() && horizontalDimensionBehaviour$ar$edu != 2) {
            if (horizontalDimensionBehaviour$ar$edu == 3) {
                if (constraintWidget.mMatchConstraintDefaultWidth != 0 || constraintWidget.mDimensionRatio != 0.0f) {
                    horizontalDimensionBehaviour$ar$edu = 3;
                } else if (constraintWidget.hasDanglingDimension(0)) {
                    horizontalDimensionBehaviour$ar$edu = 3;
                } else {
                    horizontalDimensionBehaviour$ar$edu = 3;
                }
            }
            obj = (horizontalDimensionBehaviour$ar$edu == 3 && constraintWidget.mMatchConstraintDefaultWidth == 1 && constraintWidget.hasResolvedTargets(0, constraintWidget.getWidth())) ? 1 : null;
            obj2 = (verticalDimensionBehaviour$ar$edu != 1 || constraintWidget.isResolvedVertically() || verticalDimensionBehaviour$ar$edu == 2 || (verticalDimensionBehaviour$ar$edu == 3 && constraintWidget.mMatchConstraintDefaultHeight == 0 && constraintWidget.mDimensionRatio == 0.0f && constraintWidget.hasDanglingDimension(1))) ? 1 : (horizontalDimensionBehaviour$ar$edu == 3 && constraintWidget.mMatchConstraintDefaultHeight == 1 && constraintWidget.hasResolvedTargets(1, constraintWidget.getHeight())) ? 1 : null;
            if (constraintWidget.mDimensionRatio > 0.0f) {
                if (obj == null || r0 != null) {
                    return true;
                }
                obj2 = null;
                obj = null;
            }
            return obj == null && obj2 != null;
        }
        obj = 1;
        if (verticalDimensionBehaviour$ar$edu != 1) {
        }
        if (constraintWidget.mDimensionRatio > 0.0f) {
            if (obj == null) {
            }
            return true;
        }
        if (obj == null) {
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void horizontalSolvingPass$ar$class_merging(int r16, androidx.constraintlayout.core.widgets.ConstraintWidget r17, androidx.constraintlayout.widget.ConstraintLayout.Measurer r18, boolean r19) {
        /*
        r0 = r17;
        r1 = r18;
        r2 = r19;
        r3 = r0.horizontalSolvingPass;
        if (r3 == 0) goto L_0x000b;
    L_0x000a:
        return;
    L_0x000b:
        r3 = hcount;
        r4 = 1;
        r3 = r3 + r4;
        hcount = r3;
        r3 = r0 instanceof androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
        if (r3 != 0) goto L_0x0029;
    L_0x0015:
        r3 = r17.isMeasureRequested();
        if (r3 == 0) goto L_0x0029;
    L_0x001b:
        r3 = canMeasure$ar$ds(r17);
        if (r3 == 0) goto L_0x0029;
    L_0x0021:
        r3 = new androidx.constraintlayout.core.widgets.analyzer.BasicMeasure$Measure;
        r3.<init>();
        androidx.constraintlayout.core.widgets.ConstraintWidgetContainer.measure$ar$class_merging$ar$ds(r0, r1, r3);
    L_0x0029:
        r3 = 2;
        r3 = r0.getAnchor$ar$edu(r3);
        r5 = 4;
        r5 = r0.getAnchor$ar$edu(r5);
        r6 = r3.getFinalValue();
        r7 = r5.getFinalValue();
        r8 = r3.mDependents;
        r9 = 0;
        r10 = 8;
        r11 = 3;
        if (r8 == 0) goto L_0x011d;
    L_0x0043:
        r3 = r3.mHasFinalValue;
        if (r3 == 0) goto L_0x011d;
    L_0x0047:
        r3 = r8.iterator();
    L_0x004b:
        r8 = r3.hasNext();
        if (r8 == 0) goto L_0x011d;
    L_0x0051:
        r8 = r3.next();
        r8 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r8;
        r12 = r8.mOwner;
        r13 = r16 + 1;
        r14 = canMeasure$ar$ds(r12);
        r15 = r12.isMeasureRequested();
        if (r15 == 0) goto L_0x006f;
    L_0x0065:
        if (r14 == 0) goto L_0x006f;
    L_0x0067:
        r15 = new androidx.constraintlayout.core.widgets.analyzer.BasicMeasure$Measure;
        r15.<init>();
        androidx.constraintlayout.core.widgets.ConstraintWidgetContainer.measure$ar$class_merging$ar$ds(r12, r1, r15);
    L_0x006f:
        r15 = r12.getHorizontalDimensionBehaviour$ar$edu();
        if (r15 != r11) goto L_0x00be;
    L_0x0075:
        if (r14 == 0) goto L_0x0078;
    L_0x0077:
        goto L_0x00be;
    L_0x0078:
        r14 = r12.getHorizontalDimensionBehaviour$ar$edu();
        if (r14 != r11) goto L_0x004b;
    L_0x007e:
        r14 = r12.mMatchConstraintMaxWidth;
        if (r14 < 0) goto L_0x004b;
    L_0x0082:
        r14 = r12.mMatchConstraintMinWidth;
        if (r14 < 0) goto L_0x004b;
    L_0x0086:
        r14 = r12.mVisibility;
        if (r14 == r10) goto L_0x0094;
    L_0x008a:
        r14 = r12.mMatchConstraintDefaultWidth;
        if (r14 != 0) goto L_0x004b;
    L_0x008e:
        r14 = r12.mDimensionRatio;
        r14 = (r14 > r9 ? 1 : (r14 == r9 ? 0 : -1));
        if (r14 != 0) goto L_0x004b;
    L_0x0094:
        r14 = r12.isInHorizontalChain();
        if (r14 != 0) goto L_0x004b;
    L_0x009a:
        r14 = r12.mLeft;
        if (r8 != r14) goto L_0x00a8;
    L_0x009e:
        r15 = r12.mRight;
        r15 = r15.mTarget;
        if (r15 == 0) goto L_0x00a8;
    L_0x00a4:
        r15 = r15.mHasFinalValue;
        if (r15 != 0) goto L_0x00b4;
    L_0x00a8:
        r15 = r12.mRight;
        if (r8 != r15) goto L_0x004b;
    L_0x00ac:
        r8 = r14.mTarget;
        if (r8 == 0) goto L_0x004b;
    L_0x00b0:
        r8 = r8.mHasFinalValue;
        if (r8 == 0) goto L_0x004b;
    L_0x00b4:
        r8 = r12.isInHorizontalChain();
        if (r8 != 0) goto L_0x004b;
    L_0x00ba:
        solveHorizontalMatchConstraint$ar$class_merging(r13, r0, r1, r12, r2);
        goto L_0x004b;
    L_0x00be:
        r14 = r12.isMeasureRequested();
        if (r14 != 0) goto L_0x011a;
    L_0x00c4:
        r14 = r12.mLeft;
        if (r8 != r14) goto L_0x00e0;
    L_0x00c8:
        r15 = r12.mRight;
        r15 = r15.mTarget;
        if (r15 != 0) goto L_0x00e0;
    L_0x00ce:
        r8 = r14.getMargin();
        r8 = r8 + r6;
        r14 = r12.getWidth();
        r14 = r14 + r8;
        r12.setFinalHorizontal(r8, r14);
        horizontalSolvingPass$ar$class_merging(r13, r12, r1, r2);
        goto L_0x004b;
    L_0x00e0:
        r15 = r12.mRight;
        if (r8 != r15) goto L_0x00fb;
    L_0x00e4:
        r9 = r14.mTarget;
        if (r9 != 0) goto L_0x00fb;
    L_0x00e8:
        r8 = r15.getMargin();
        r8 = r6 - r8;
        r9 = r12.getWidth();
        r9 = r8 - r9;
        r12.setFinalHorizontal(r9, r8);
        horizontalSolvingPass$ar$class_merging(r13, r12, r1, r2);
        goto L_0x0117;
    L_0x00fb:
        if (r8 != r14) goto L_0x0117;
    L_0x00fd:
        r8 = r15.mTarget;
        if (r8 == 0) goto L_0x0114;
    L_0x0101:
        r8 = r8.mHasFinalValue;
        if (r8 == 0) goto L_0x0114;
    L_0x0105:
        r8 = r12.isInHorizontalChain();
        if (r8 != 0) goto L_0x0111;
    L_0x010b:
        solveHorizontalCenterConstraints$ar$class_merging(r13, r1, r12, r2);
        r9 = 0;
        goto L_0x004b;
    L_0x0111:
        r9 = 0;
        goto L_0x004b;
    L_0x0114:
        r9 = 0;
        goto L_0x004b;
    L_0x0117:
        r9 = 0;
        goto L_0x004b;
    L_0x011a:
        r9 = 0;
        goto L_0x004b;
    L_0x011d:
        r3 = r0 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r3 != 0) goto L_0x01fe;
    L_0x0121:
        r3 = r5.mDependents;
        if (r3 == 0) goto L_0x01fc;
    L_0x0125:
        r5 = r5.mHasFinalValue;
        if (r5 == 0) goto L_0x01fc;
    L_0x0129:
        r3 = r3.iterator();
    L_0x012d:
        r5 = r3.hasNext();
        if (r5 == 0) goto L_0x01fc;
    L_0x0133:
        r5 = r3.next();
        r5 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r5;
        r6 = r5.mOwner;
        r8 = r16 + 1;
        r9 = canMeasure$ar$ds(r6);
        r12 = r6.isMeasureRequested();
        if (r12 == 0) goto L_0x0151;
    L_0x0147:
        if (r9 == 0) goto L_0x0151;
    L_0x0149:
        r12 = new androidx.constraintlayout.core.widgets.analyzer.BasicMeasure$Measure;
        r12.<init>();
        androidx.constraintlayout.core.widgets.ConstraintWidgetContainer.measure$ar$class_merging$ar$ds(r6, r1, r12);
    L_0x0151:
        r12 = r6.mLeft;
        r13 = 0;
        if (r5 != r12) goto L_0x0163;
    L_0x0156:
        r14 = r6.mRight;
        r14 = r14.mTarget;
        if (r14 == 0) goto L_0x0163;
    L_0x015c:
        r14 = r14.mHasFinalValue;
        if (r14 != 0) goto L_0x0161;
    L_0x0160:
        goto L_0x0163;
    L_0x0161:
        r13 = 1;
        goto L_0x0172;
    L_0x0163:
        r14 = r6.mRight;
        if (r5 != r14) goto L_0x0171;
    L_0x0167:
        r12 = r12.mTarget;
        if (r12 == 0) goto L_0x0171;
    L_0x016b:
        r12 = r12.mHasFinalValue;
        if (r12 == 0) goto L_0x0171;
    L_0x016f:
        r13 = 1;
        goto L_0x0172;
    L_0x0172:
        r12 = r6.getHorizontalDimensionBehaviour$ar$edu();
        if (r12 != r11) goto L_0x01b0;
    L_0x0178:
        if (r9 == 0) goto L_0x017c;
    L_0x017a:
        r9 = 0;
        goto L_0x01b1;
    L_0x017c:
        r5 = r6.getHorizontalDimensionBehaviour$ar$edu();
        if (r5 != r11) goto L_0x01ad;
    L_0x0182:
        r5 = r6.mMatchConstraintMaxWidth;
        if (r5 < 0) goto L_0x01ad;
    L_0x0186:
        r5 = r6.mMatchConstraintMinWidth;
        if (r5 < 0) goto L_0x01ad;
    L_0x018a:
        r5 = r6.mVisibility;
        if (r5 == r10) goto L_0x019a;
    L_0x018e:
        r5 = r6.mMatchConstraintDefaultWidth;
        if (r5 != 0) goto L_0x01ad;
    L_0x0192:
        r5 = r6.mDimensionRatio;
        r9 = 0;
        r5 = (r5 > r9 ? 1 : (r5 == r9 ? 0 : -1));
        if (r5 != 0) goto L_0x012d;
    L_0x0199:
        goto L_0x019b;
    L_0x019a:
        r9 = 0;
    L_0x019b:
        r5 = r6.isInHorizontalChain();
        if (r5 != 0) goto L_0x012d;
    L_0x01a1:
        if (r13 == 0) goto L_0x012d;
    L_0x01a3:
        r5 = r6.isInHorizontalChain();
        if (r5 != 0) goto L_0x012d;
    L_0x01a9:
        solveHorizontalMatchConstraint$ar$class_merging(r8, r0, r1, r6, r2);
        goto L_0x012d;
    L_0x01ad:
        r9 = 0;
        goto L_0x012d;
    L_0x01b0:
        r9 = 0;
    L_0x01b1:
        r12 = r6.isMeasureRequested();
        if (r12 != 0) goto L_0x012d;
    L_0x01b7:
        r12 = r6.mLeft;
        if (r5 != r12) goto L_0x01d3;
    L_0x01bb:
        r14 = r6.mRight;
        r14 = r14.mTarget;
        if (r14 != 0) goto L_0x01d3;
    L_0x01c1:
        r5 = r12.getMargin();
        r5 = r5 + r7;
        r12 = r6.getWidth();
        r12 = r12 + r5;
        r6.setFinalHorizontal(r5, r12);
        horizontalSolvingPass$ar$class_merging(r8, r6, r1, r2);
        goto L_0x012d;
    L_0x01d3:
        r14 = r6.mRight;
        if (r5 != r14) goto L_0x01ef;
    L_0x01d7:
        r5 = r12.mTarget;
        if (r5 != 0) goto L_0x01ef;
    L_0x01db:
        r5 = r14.getMargin();
        r5 = r7 - r5;
        r12 = r6.getWidth();
        r12 = r5 - r12;
        r6.setFinalHorizontal(r12, r5);
        horizontalSolvingPass$ar$class_merging(r8, r6, r1, r2);
        goto L_0x012d;
    L_0x01ef:
        if (r13 == 0) goto L_0x012d;
    L_0x01f1:
        r5 = r6.isInHorizontalChain();
        if (r5 != 0) goto L_0x012d;
    L_0x01f7:
        solveHorizontalCenterConstraints$ar$class_merging(r8, r1, r6, r2);
        goto L_0x012d;
    L_0x01fc:
        r0.horizontalSolvingPass = r4;
    L_0x01fe:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.core.widgets.analyzer.Direct.horizontalSolvingPass$ar$class_merging(int, androidx.constraintlayout.core.widgets.ConstraintWidget, androidx.constraintlayout.widget.ConstraintLayout$Measurer, boolean):void");
    }

    public static void solveBarrier$ar$class_merging$ar$ds(Barrier barrier, Measurer measurer, int i, boolean z) {
        if (barrier.allSolved()) {
            if (i == 0) {
                horizontalSolvingPass$ar$class_merging(1, barrier, measurer, z);
                return;
            }
            verticalSolvingPass$ar$class_merging(1, barrier, measurer);
        }
    }

    private static void solveHorizontalCenterConstraints$ar$class_merging(int i, Measurer measurer, ConstraintWidget constraintWidget, boolean z) {
        int i2;
        float f = constraintWidget.mHorizontalBiasPercent;
        int finalValue = constraintWidget.mLeft.mTarget.getFinalValue();
        int finalValue2 = constraintWidget.mRight.mTarget.getFinalValue();
        int margin = constraintWidget.mLeft.getMargin() + finalValue;
        int margin2 = finalValue2 - constraintWidget.mRight.getMargin();
        if (finalValue == finalValue2) {
            margin2 = finalValue2;
        }
        if (finalValue == finalValue2) {
            margin = finalValue;
        }
        if (finalValue == finalValue2) {
            f = 0.5f;
        }
        finalValue = constraintWidget.getWidth();
        finalValue2 = (margin2 - margin) - finalValue;
        if (margin > margin2) {
            finalValue2 = (margin - margin2) - finalValue;
        }
        if (finalValue2 > 0) {
            i2 = (int) ((f * ((float) finalValue2)) + 0.5f);
        } else {
            i2 = (int) (f * ((float) finalValue2));
        }
        i2 += margin;
        finalValue2 = i2 + finalValue;
        if (margin > margin2) {
            finalValue2 = i2 - finalValue;
        }
        constraintWidget.setFinalHorizontal(i2, finalValue2);
        horizontalSolvingPass$ar$class_merging(i + 1, constraintWidget, measurer, z);
    }

    private static void solveHorizontalMatchConstraint$ar$class_merging(int i, ConstraintWidget constraintWidget, Measurer measurer, ConstraintWidget constraintWidget2, boolean z) {
        float f = constraintWidget2.mHorizontalBiasPercent;
        int finalValue = constraintWidget2.mLeft.mTarget.getFinalValue() + constraintWidget2.mLeft.getMargin();
        int finalValue2 = constraintWidget2.mRight.mTarget.getFinalValue() - constraintWidget2.mRight.getMargin();
        if (finalValue2 >= finalValue) {
            int width = constraintWidget2.getWidth();
            if (constraintWidget2.mVisibility != 8) {
                int width2;
                int i2 = constraintWidget2.mMatchConstraintDefaultWidth;
                if (i2 == 2) {
                    if (constraintWidget instanceof ConstraintWidgetContainer) {
                        width2 = constraintWidget.getWidth();
                    } else {
                        width2 = constraintWidget.mParent.getWidth();
                    }
                    width = (int) ((constraintWidget2.mHorizontalBiasPercent * 0.5f) * ((float) width2));
                } else if (i2 == 0) {
                    width = finalValue2 - finalValue;
                }
                width = Math.max(constraintWidget2.mMatchConstraintMinWidth, width);
                width2 = constraintWidget2.mMatchConstraintMaxWidth;
                if (width2 > 0) {
                    width = Math.min(width2, width);
                }
            }
            finalValue += (int) ((f * ((float) ((finalValue2 - finalValue) - width))) + 0.5f);
            constraintWidget2.setFinalHorizontal(finalValue, width + finalValue);
            horizontalSolvingPass$ar$class_merging(i + 1, constraintWidget2, measurer, z);
        }
    }

    private static void solveVerticalCenterConstraints$ar$class_merging(int i, Measurer measurer, ConstraintWidget constraintWidget) {
        int i2;
        float f = constraintWidget.mVerticalBiasPercent;
        int finalValue = constraintWidget.mTop.mTarget.getFinalValue();
        int finalValue2 = constraintWidget.mBottom.mTarget.getFinalValue();
        int margin = constraintWidget.mTop.getMargin() + finalValue;
        int margin2 = finalValue2 - constraintWidget.mBottom.getMargin();
        if (finalValue == finalValue2) {
            margin2 = finalValue2;
        }
        if (finalValue == finalValue2) {
            margin = finalValue;
        }
        if (finalValue == finalValue2) {
            f = 0.5f;
        }
        finalValue = constraintWidget.getHeight();
        finalValue2 = (margin2 - margin) - finalValue;
        if (margin > margin2) {
            finalValue2 = (margin - margin2) - finalValue;
        }
        if (finalValue2 > 0) {
            i2 = (int) ((f * ((float) finalValue2)) + 0.5f);
        } else {
            i2 = (int) (f * ((float) finalValue2));
        }
        finalValue2 = margin + i2;
        int i3 = finalValue2 + finalValue;
        if (margin > margin2) {
            finalValue2 = margin - i2;
            i3 = finalValue2 - finalValue;
        }
        constraintWidget.setFinalVertical(finalValue2, i3);
        verticalSolvingPass$ar$class_merging(i + 1, constraintWidget, measurer);
    }

    private static void solveVerticalMatchConstraint$ar$class_merging(int i, ConstraintWidget constraintWidget, Measurer measurer, ConstraintWidget constraintWidget2) {
        float f = constraintWidget2.mVerticalBiasPercent;
        int finalValue = constraintWidget2.mTop.mTarget.getFinalValue() + constraintWidget2.mTop.getMargin();
        int finalValue2 = constraintWidget2.mBottom.mTarget.getFinalValue() - constraintWidget2.mBottom.getMargin();
        if (finalValue2 >= finalValue) {
            int height = constraintWidget2.getHeight();
            if (constraintWidget2.mVisibility != 8) {
                int height2;
                int i2 = constraintWidget2.mMatchConstraintDefaultHeight;
                if (i2 == 2) {
                    if (constraintWidget instanceof ConstraintWidgetContainer) {
                        height2 = constraintWidget.getHeight();
                    } else {
                        height2 = constraintWidget.mParent.getHeight();
                    }
                    height = (int) ((f * 0.5f) * ((float) height2));
                } else if (i2 == 0) {
                    height = finalValue2 - finalValue;
                }
                height = Math.max(constraintWidget2.mMatchConstraintMinHeight, height);
                height2 = constraintWidget2.mMatchConstraintMaxHeight;
                if (height2 > 0) {
                    height = Math.min(height2, height);
                }
            }
            finalValue += (int) ((f * ((float) ((finalValue2 - finalValue) - height))) + 0.5f);
            constraintWidget2.setFinalVertical(finalValue, height + finalValue);
            verticalSolvingPass$ar$class_merging(i + 1, constraintWidget2, measurer);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void verticalSolvingPass$ar$class_merging(int r16, androidx.constraintlayout.core.widgets.ConstraintWidget r17, androidx.constraintlayout.widget.ConstraintLayout.Measurer r18) {
        /*
        r0 = r17;
        r1 = r18;
        r2 = r0.verticalSolvingPass;
        if (r2 == 0) goto L_0x0009;
    L_0x0008:
        return;
    L_0x0009:
        r2 = vcount;
        r3 = 1;
        r2 = r2 + r3;
        vcount = r2;
        r2 = r0 instanceof androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
        if (r2 != 0) goto L_0x0027;
    L_0x0013:
        r2 = r17.isMeasureRequested();
        if (r2 == 0) goto L_0x0027;
    L_0x0019:
        r2 = canMeasure$ar$ds(r17);
        if (r2 == 0) goto L_0x0027;
    L_0x001f:
        r2 = new androidx.constraintlayout.core.widgets.analyzer.BasicMeasure$Measure;
        r2.<init>();
        androidx.constraintlayout.core.widgets.ConstraintWidgetContainer.measure$ar$class_merging$ar$ds(r0, r1, r2);
        r2 = 3;
        r4 = r0.getAnchor$ar$edu(r2);
        r5 = 5;
        r5 = r0.getAnchor$ar$edu(r5);
        r6 = r4.getFinalValue();
        r7 = r5.getFinalValue();
        r8 = r4.mDependents;
        r9 = 0;
        r10 = 8;
        if (r8 == 0) goto L_0x0109;
    L_0x0041:
        r4 = r4.mHasFinalValue;
        if (r4 == 0) goto L_0x0109;
    L_0x0045:
        r4 = r8.iterator();
    L_0x0049:
        r8 = r4.hasNext();
        if (r8 == 0) goto L_0x0109;
    L_0x004f:
        r8 = r4.next();
        r8 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r8;
        r11 = r8.mOwner;
        r12 = r16 + 1;
        r13 = canMeasure$ar$ds(r11);
        r14 = r11.isMeasureRequested();
        if (r14 == 0) goto L_0x006d;
    L_0x0063:
        if (r13 == 0) goto L_0x006d;
    L_0x0065:
        r14 = new androidx.constraintlayout.core.widgets.analyzer.BasicMeasure$Measure;
        r14.<init>();
        androidx.constraintlayout.core.widgets.ConstraintWidgetContainer.measure$ar$class_merging$ar$ds(r11, r1, r14);
    L_0x006d:
        r14 = r11.getVerticalDimensionBehaviour$ar$edu();
        if (r14 != r2) goto L_0x00bc;
    L_0x0073:
        if (r13 == 0) goto L_0x0076;
    L_0x0075:
        goto L_0x00bc;
    L_0x0076:
        r13 = r11.getVerticalDimensionBehaviour$ar$edu();
        if (r13 != r2) goto L_0x0049;
    L_0x007c:
        r13 = r11.mMatchConstraintMaxHeight;
        if (r13 < 0) goto L_0x0049;
    L_0x0080:
        r13 = r11.mMatchConstraintMinHeight;
        if (r13 < 0) goto L_0x0049;
    L_0x0084:
        r13 = r11.mVisibility;
        if (r13 == r10) goto L_0x0092;
    L_0x0088:
        r13 = r11.mMatchConstraintDefaultHeight;
        if (r13 != 0) goto L_0x0049;
    L_0x008c:
        r13 = r11.mDimensionRatio;
        r13 = (r13 > r9 ? 1 : (r13 == r9 ? 0 : -1));
        if (r13 != 0) goto L_0x0049;
    L_0x0092:
        r13 = r11.isInVerticalChain();
        if (r13 != 0) goto L_0x0049;
    L_0x0098:
        r13 = r11.mTop;
        if (r8 != r13) goto L_0x00a6;
    L_0x009c:
        r14 = r11.mBottom;
        r14 = r14.mTarget;
        if (r14 == 0) goto L_0x00a6;
    L_0x00a2:
        r14 = r14.mHasFinalValue;
        if (r14 != 0) goto L_0x00b2;
    L_0x00a6:
        r14 = r11.mBottom;
        if (r8 != r14) goto L_0x0049;
    L_0x00aa:
        r8 = r13.mTarget;
        if (r8 == 0) goto L_0x0049;
    L_0x00ae:
        r8 = r8.mHasFinalValue;
        if (r8 == 0) goto L_0x0049;
    L_0x00b2:
        r8 = r11.isInVerticalChain();
        if (r8 != 0) goto L_0x0049;
    L_0x00b8:
        solveVerticalMatchConstraint$ar$class_merging(r12, r0, r1, r11);
        goto L_0x0049;
    L_0x00bc:
        r13 = r11.isMeasureRequested();
        if (r13 != 0) goto L_0x0049;
    L_0x00c2:
        r13 = r11.mTop;
        if (r8 != r13) goto L_0x00de;
    L_0x00c6:
        r14 = r11.mBottom;
        r14 = r14.mTarget;
        if (r14 != 0) goto L_0x00de;
    L_0x00cc:
        r8 = r13.getMargin();
        r8 = r8 + r6;
        r13 = r11.getHeight();
        r13 = r13 + r8;
        r11.setFinalVertical(r8, r13);
        verticalSolvingPass$ar$class_merging(r12, r11, r1);
        goto L_0x0049;
    L_0x00de:
        r14 = r11.mBottom;
        if (r8 != r14) goto L_0x00fa;
    L_0x00e2:
        r15 = r14.mTarget;
        if (r15 != 0) goto L_0x00fa;
    L_0x00e6:
        r8 = r14.getMargin();
        r8 = r6 - r8;
        r13 = r11.getHeight();
        r13 = r8 - r13;
        r11.setFinalVertical(r13, r8);
        verticalSolvingPass$ar$class_merging(r12, r11, r1);
        goto L_0x0049;
    L_0x00fa:
        if (r8 != r13) goto L_0x0049;
    L_0x00fc:
        r8 = r14.mTarget;
        if (r8 == 0) goto L_0x0049;
    L_0x0100:
        r8 = r8.mHasFinalValue;
        if (r8 == 0) goto L_0x0049;
    L_0x0104:
        solveVerticalCenterConstraints$ar$class_merging(r12, r1, r11);
        goto L_0x0049;
    L_0x0109:
        r4 = r0 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r4 != 0) goto L_0x0256;
    L_0x010d:
        r4 = r5.mDependents;
        if (r4 == 0) goto L_0x01e0;
    L_0x0111:
        r5 = r5.mHasFinalValue;
        if (r5 == 0) goto L_0x01e0;
    L_0x0115:
        r4 = r4.iterator();
    L_0x0119:
        r5 = r4.hasNext();
        if (r5 == 0) goto L_0x01e0;
    L_0x011f:
        r5 = r4.next();
        r5 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r5;
        r6 = r5.mOwner;
        r8 = r16 + 1;
        r11 = canMeasure$ar$ds(r6);
        r12 = r6.isMeasureRequested();
        if (r12 == 0) goto L_0x013d;
    L_0x0133:
        if (r11 == 0) goto L_0x013d;
    L_0x0135:
        r12 = new androidx.constraintlayout.core.widgets.analyzer.BasicMeasure$Measure;
        r12.<init>();
        androidx.constraintlayout.core.widgets.ConstraintWidgetContainer.measure$ar$class_merging$ar$ds(r6, r1, r12);
    L_0x013d:
        r12 = r6.mTop;
        r13 = 0;
        if (r5 != r12) goto L_0x014f;
    L_0x0142:
        r14 = r6.mBottom;
        r14 = r14.mTarget;
        if (r14 == 0) goto L_0x014f;
    L_0x0148:
        r14 = r14.mHasFinalValue;
        if (r14 != 0) goto L_0x014d;
    L_0x014c:
        goto L_0x014f;
    L_0x014d:
        r13 = 1;
        goto L_0x015e;
    L_0x014f:
        r14 = r6.mBottom;
        if (r5 != r14) goto L_0x015d;
    L_0x0153:
        r12 = r12.mTarget;
        if (r12 == 0) goto L_0x015d;
    L_0x0157:
        r12 = r12.mHasFinalValue;
        if (r12 == 0) goto L_0x015d;
    L_0x015b:
        r13 = 1;
        goto L_0x015e;
    L_0x015e:
        r12 = r6.getVerticalDimensionBehaviour$ar$edu();
        if (r12 != r2) goto L_0x0195;
    L_0x0164:
        if (r11 == 0) goto L_0x0167;
    L_0x0166:
        goto L_0x0195;
    L_0x0167:
        r5 = r6.getVerticalDimensionBehaviour$ar$edu();
        if (r5 != r2) goto L_0x0119;
    L_0x016d:
        r5 = r6.mMatchConstraintMaxHeight;
        if (r5 < 0) goto L_0x0119;
    L_0x0171:
        r5 = r6.mMatchConstraintMinHeight;
        if (r5 < 0) goto L_0x0119;
    L_0x0175:
        r5 = r6.mVisibility;
        if (r5 == r10) goto L_0x0183;
    L_0x0179:
        r5 = r6.mMatchConstraintDefaultHeight;
        if (r5 != 0) goto L_0x0119;
    L_0x017d:
        r5 = r6.mDimensionRatio;
        r5 = (r5 > r9 ? 1 : (r5 == r9 ? 0 : -1));
        if (r5 != 0) goto L_0x0119;
    L_0x0183:
        r5 = r6.isInVerticalChain();
        if (r5 != 0) goto L_0x0119;
    L_0x0189:
        if (r13 == 0) goto L_0x0119;
    L_0x018b:
        r5 = r6.isInVerticalChain();
        if (r5 != 0) goto L_0x0119;
    L_0x0191:
        solveVerticalMatchConstraint$ar$class_merging(r8, r0, r1, r6);
        goto L_0x0119;
    L_0x0195:
        r11 = r6.isMeasureRequested();
        if (r11 != 0) goto L_0x0119;
    L_0x019b:
        r11 = r6.mTop;
        if (r5 != r11) goto L_0x01b7;
    L_0x019f:
        r12 = r6.mBottom;
        r12 = r12.mTarget;
        if (r12 != 0) goto L_0x01b7;
    L_0x01a5:
        r5 = r11.getMargin();
        r5 = r5 + r7;
        r11 = r6.getHeight();
        r11 = r11 + r5;
        r6.setFinalVertical(r5, r11);
        verticalSolvingPass$ar$class_merging(r8, r6, r1);
        goto L_0x0119;
    L_0x01b7:
        r12 = r6.mBottom;
        if (r5 != r12) goto L_0x01d3;
    L_0x01bb:
        r5 = r11.mTarget;
        if (r5 != 0) goto L_0x01d3;
    L_0x01bf:
        r5 = r12.getMargin();
        r5 = r7 - r5;
        r11 = r6.getHeight();
        r11 = r5 - r11;
        r6.setFinalVertical(r11, r5);
        verticalSolvingPass$ar$class_merging(r8, r6, r1);
        goto L_0x0119;
    L_0x01d3:
        if (r13 == 0) goto L_0x0119;
    L_0x01d5:
        r5 = r6.isInVerticalChain();
        if (r5 != 0) goto L_0x0119;
    L_0x01db:
        solveVerticalCenterConstraints$ar$class_merging(r8, r1, r6);
        goto L_0x0119;
    L_0x01e0:
        r4 = 6;
        r4 = r0.getAnchor$ar$edu(r4);
        r5 = r4.mDependents;
        if (r5 == 0) goto L_0x0254;
    L_0x01e9:
        r5 = r4.mHasFinalValue;
        if (r5 == 0) goto L_0x0254;
    L_0x01ed:
        r5 = r4.getFinalValue();
        r4 = r4.mDependents;
        r4 = r4.iterator();
    L_0x01f7:
        r6 = r4.hasNext();
        if (r6 == 0) goto L_0x0254;
    L_0x01fd:
        r6 = r4.next();
        r6 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r6;
        r7 = r6.mOwner;
        r8 = r16 + 1;
        r9 = canMeasure$ar$ds(r7);
        r10 = r7.isMeasureRequested();
        if (r10 == 0) goto L_0x021b;
    L_0x0211:
        if (r9 == 0) goto L_0x021b;
    L_0x0213:
        r10 = new androidx.constraintlayout.core.widgets.analyzer.BasicMeasure$Measure;
        r10.<init>();
        androidx.constraintlayout.core.widgets.ConstraintWidgetContainer.measure$ar$class_merging$ar$ds(r7, r1, r10);
    L_0x021b:
        r10 = r7.getVerticalDimensionBehaviour$ar$edu();
        if (r10 != r2) goto L_0x0223;
    L_0x0221:
        if (r9 == 0) goto L_0x01f7;
    L_0x0223:
        r9 = r7.isMeasureRequested();
        if (r9 != 0) goto L_0x01f7;
    L_0x0229:
        r9 = r7.mBaseline;
        if (r6 != r9) goto L_0x01f7;
    L_0x022d:
        r6 = r6.getMargin();
        r6 = r6 + r5;
        r9 = r7.hasBaseline;
        if (r9 == 0) goto L_0x0250;
    L_0x0236:
        r9 = r7.mBaselineDistance;
        r9 = r6 - r9;
        r10 = r7.mHeight;
        r7.f13mY = r9;
        r11 = r7.mTop;
        r11.setFinalValue(r9);
        r11 = r7.mBottom;
        r9 = r9 + r10;
        r11.setFinalValue(r9);
        r9 = r7.mBaseline;
        r9.setFinalValue(r6);
        r7.resolvedVertical = r3;
    L_0x0250:
        verticalSolvingPass$ar$class_merging(r8, r7, r1);	 Catch:{ all -> 0x0257 }
        goto L_0x01f7;
    L_0x0254:
        r0.verticalSolvingPass = r3;
    L_0x0256:
        return;
    L_0x0257:
        r0 = move-exception;
        r1 = r0;
        goto L_0x025b;
    L_0x025a:
        throw r1;
    L_0x025b:
        goto L_0x025a;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.core.widgets.analyzer.Direct.verticalSolvingPass$ar$class_merging(int, androidx.constraintlayout.core.widgets.ConstraintWidget, androidx.constraintlayout.widget.ConstraintLayout$Measurer):void");
    }
}
