package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.Guideline;
import androidx.constraintlayout.core.widgets.HelperWidget;
import java.util.ArrayList;

/* compiled from: PG */
public final class Grouping {
    public static WidgetGroup findDependents(ConstraintWidget constraintWidget, int i, ArrayList arrayList, WidgetGroup widgetGroup) {
        int i2;
        int i3;
        HelperWidget helperWidget;
        ConstraintWidget constraintWidget2;
        int i4;
        WidgetGroup widgetGroup2;
        Guideline guideline;
        ConstraintAnchor constraintAnchor;
        if (i == 0) {
            i2 = constraintWidget.horizontalGroup;
        } else {
            i2 = constraintWidget.verticalGroup;
        }
        if (i2 != -1) {
            if (widgetGroup == null) {
                i3 = 0;
            } else if (i2 != widgetGroup.f14id) {
                i3 = 0;
            }
            while (i3 < arrayList.size()) {
                WidgetGroup widgetGroup3 = (WidgetGroup) arrayList.get(i3);
                if (widgetGroup3.f14id == i2) {
                    if (widgetGroup != null) {
                        widgetGroup.moveTo(i, widgetGroup3);
                        arrayList.remove(widgetGroup);
                    }
                    widgetGroup = widgetGroup3;
                    if (widgetGroup == null) {
                        if (constraintWidget instanceof HelperWidget) {
                            helperWidget = (HelperWidget) constraintWidget;
                            for (i3 = 0; i3 < helperWidget.mWidgetsCount; i3++) {
                                constraintWidget2 = helperWidget.mWidgets[i3];
                                if (i != 0) {
                                    i4 = constraintWidget2.horizontalGroup;
                                    if (i4 == -1) {
                                        break;
                                    }
                                } else {
                                    i4 = constraintWidget2.verticalGroup;
                                    if (i4 == -1) {
                                        break;
                                    }
                                }
                            }
                            i4 = -1;
                            if (i4 != -1) {
                                for (i2 = 0; i2 < arrayList.size(); i2++) {
                                    widgetGroup2 = (WidgetGroup) arrayList.get(i2);
                                    if (widgetGroup2.f14id != i4) {
                                        widgetGroup = widgetGroup2;
                                        break;
                                    }
                                }
                            }
                        }
                        if (widgetGroup == null) {
                            widgetGroup = new WidgetGroup(i);
                        }
                        arrayList.add(widgetGroup);
                    }
                    if (widgetGroup.add(constraintWidget)) {
                        if (constraintWidget instanceof Guideline) {
                            guideline = (Guideline) constraintWidget;
                            constraintAnchor = guideline.mAnchor;
                            if (guideline.mOrientation == 0) {
                                i2 = 1;
                            } else {
                                i2 = 0;
                            }
                            constraintAnchor.findDependents(i2, arrayList, widgetGroup);
                        }
                        if (i == 0) {
                            constraintWidget.horizontalGroup = widgetGroup.f14id;
                            constraintWidget.mLeft.findDependents(0, arrayList, widgetGroup);
                            constraintWidget.mRight.findDependents(0, arrayList, widgetGroup);
                        } else {
                            constraintWidget.verticalGroup = widgetGroup.f14id;
                            constraintWidget.mTop.findDependents(1, arrayList, widgetGroup);
                            constraintWidget.mBaseline.findDependents(1, arrayList, widgetGroup);
                            constraintWidget.mBottom.findDependents(1, arrayList, widgetGroup);
                        }
                        constraintWidget.mCenter.findDependents(i, arrayList, widgetGroup);
                    }
                    return widgetGroup;
                }
                i3++;
            }
            if (widgetGroup == null) {
                if (constraintWidget instanceof HelperWidget) {
                    helperWidget = (HelperWidget) constraintWidget;
                    for (i3 = 0; i3 < helperWidget.mWidgetsCount; i3++) {
                        constraintWidget2 = helperWidget.mWidgets[i3];
                        if (i != 0) {
                            i4 = constraintWidget2.horizontalGroup;
                            if (i4 == -1) {
                                break;
                            }
                        } else {
                            i4 = constraintWidget2.verticalGroup;
                            if (i4 == -1) {
                                break;
                            }
                        }
                    }
                    i4 = -1;
                    if (i4 != -1) {
                        for (i2 = 0; i2 < arrayList.size(); i2++) {
                            widgetGroup2 = (WidgetGroup) arrayList.get(i2);
                            if (widgetGroup2.f14id != i4) {
                                widgetGroup = widgetGroup2;
                                break;
                            }
                        }
                    }
                }
                if (widgetGroup == null) {
                    widgetGroup = new WidgetGroup(i);
                }
                arrayList.add(widgetGroup);
            }
            if (widgetGroup.add(constraintWidget)) {
                if (constraintWidget instanceof Guideline) {
                    guideline = (Guideline) constraintWidget;
                    constraintAnchor = guideline.mAnchor;
                    if (guideline.mOrientation == 0) {
                        i2 = 0;
                    } else {
                        i2 = 1;
                    }
                    constraintAnchor.findDependents(i2, arrayList, widgetGroup);
                }
                if (i == 0) {
                    constraintWidget.verticalGroup = widgetGroup.f14id;
                    constraintWidget.mTop.findDependents(1, arrayList, widgetGroup);
                    constraintWidget.mBaseline.findDependents(1, arrayList, widgetGroup);
                    constraintWidget.mBottom.findDependents(1, arrayList, widgetGroup);
                } else {
                    constraintWidget.horizontalGroup = widgetGroup.f14id;
                    constraintWidget.mLeft.findDependents(0, arrayList, widgetGroup);
                    constraintWidget.mRight.findDependents(0, arrayList, widgetGroup);
                }
                constraintWidget.mCenter.findDependents(i, arrayList, widgetGroup);
            }
            return widgetGroup;
        }
        if (i2 != -1) {
            return widgetGroup;
        }
        if (widgetGroup == null) {
            if (constraintWidget instanceof HelperWidget) {
                helperWidget = (HelperWidget) constraintWidget;
                for (i3 = 0; i3 < helperWidget.mWidgetsCount; i3++) {
                    constraintWidget2 = helperWidget.mWidgets[i3];
                    if (i != 0) {
                        i4 = constraintWidget2.horizontalGroup;
                        if (i4 == -1) {
                            break;
                        }
                    } else {
                        i4 = constraintWidget2.verticalGroup;
                        if (i4 == -1) {
                            break;
                        }
                    }
                }
                i4 = -1;
                if (i4 != -1) {
                    for (i2 = 0; i2 < arrayList.size(); i2++) {
                        widgetGroup2 = (WidgetGroup) arrayList.get(i2);
                        if (widgetGroup2.f14id != i4) {
                            widgetGroup = widgetGroup2;
                            break;
                        }
                    }
                }
            }
            if (widgetGroup == null) {
                widgetGroup = new WidgetGroup(i);
            }
            arrayList.add(widgetGroup);
        }
        if (widgetGroup.add(constraintWidget)) {
            if (constraintWidget instanceof Guideline) {
                guideline = (Guideline) constraintWidget;
                constraintAnchor = guideline.mAnchor;
                if (guideline.mOrientation == 0) {
                    i2 = 1;
                } else {
                    i2 = 0;
                }
                constraintAnchor.findDependents(i2, arrayList, widgetGroup);
            }
            if (i == 0) {
                constraintWidget.horizontalGroup = widgetGroup.f14id;
                constraintWidget.mLeft.findDependents(0, arrayList, widgetGroup);
                constraintWidget.mRight.findDependents(0, arrayList, widgetGroup);
            } else {
                constraintWidget.verticalGroup = widgetGroup.f14id;
                constraintWidget.mTop.findDependents(1, arrayList, widgetGroup);
                constraintWidget.mBaseline.findDependents(1, arrayList, widgetGroup);
                constraintWidget.mBottom.findDependents(1, arrayList, widgetGroup);
            }
            constraintWidget.mCenter.findDependents(i, arrayList, widgetGroup);
        }
        return widgetGroup;
    }

    public static WidgetGroup findGroup(ArrayList arrayList, int i) {
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            WidgetGroup widgetGroup = (WidgetGroup) arrayList.get(i2);
            if (i == widgetGroup.f14id) {
                return widgetGroup;
            }
        }
        return null;
    }

    public static boolean validInGroup$ar$edu(int i, int i2, int i3, int i4) {
        Object obj;
        Object obj2;
        if (!(i3 == 1 || i3 == 2)) {
            if (i3 != 4 || i == 2) {
                obj = null;
                if (!(i4 == 1 || i4 == 2)) {
                    if (i4 == 4 || i2 == 2) {
                        obj2 = null;
                        if (obj == null) {
                            if (obj2 != null) {
                                return false;
                            }
                        }
                        return true;
                    }
                }
                obj2 = 1;
                if (obj == null) {
                    if (obj2 != null) {
                        return false;
                    }
                }
                return true;
            }
        }
        obj = 1;
        if (i4 == 4) {
        }
        obj2 = null;
        if (obj == null) {
            if (obj2 != null) {
                return false;
            }
        }
        return true;
    }
}
