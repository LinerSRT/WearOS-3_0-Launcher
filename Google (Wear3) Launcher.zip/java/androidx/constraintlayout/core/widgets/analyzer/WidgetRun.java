package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;

/* compiled from: PG */
public abstract class WidgetRun implements Dependency {
    public final DimensionDependency dimension = new DimensionDependency(this);
    protected int dimensionBehavior$ar$edu;
    public final DependencyNode end = new DependencyNode(this);
    protected int mRunType$ar$edu = 1;
    public int matchConstraintsType;
    public int orientation = 0;
    public boolean resolved = false;
    RunGroup runGroup;
    public final DependencyNode start = new DependencyNode(this);
    public ConstraintWidget widget;

    public WidgetRun(ConstraintWidget constraintWidget) {
        this.widget = constraintWidget;
    }

    protected static final void addTarget$ar$ds(DependencyNode dependencyNode, DependencyNode dependencyNode2, int i) {
        dependencyNode.targets.add(dependencyNode2);
        dependencyNode.margin = i;
        dependencyNode2.dependencies.add(dependencyNode);
    }

    protected static final DependencyNode getTarget$ar$ds(ConstraintAnchor constraintAnchor) {
        constraintAnchor = constraintAnchor.mTarget;
        if (constraintAnchor == null) {
            return null;
        }
        ConstraintWidget constraintWidget = constraintAnchor.mOwner;
        switch (constraintAnchor.mType$ar$edu$21f04e0f_0 - 1) {
            case 1:
                return constraintWidget.horizontalRun.start;
            case 2:
                return constraintWidget.verticalRun.start;
            case 3:
                return constraintWidget.horizontalRun.end;
            case 4:
                return constraintWidget.verticalRun.end;
            case 5:
                return constraintWidget.verticalRun.baseline;
            default:
                return null;
        }
    }

    protected static final DependencyNode getTarget$ar$ds$554e726e_0(ConstraintAnchor constraintAnchor, int i) {
        constraintAnchor = constraintAnchor.mTarget;
        if (constraintAnchor == null) {
            return null;
        }
        WidgetRun widgetRun;
        ConstraintWidget constraintWidget = constraintAnchor.mOwner;
        if (i == 0) {
            widgetRun = constraintWidget.horizontalRun;
        } else {
            widgetRun = constraintWidget.verticalRun;
        }
        switch (constraintAnchor.mType$ar$edu$21f04e0f_0 - 1) {
            case 1:
            case 2:
                return widgetRun.start;
            case 3:
            case 4:
                return widgetRun.end;
            default:
                return null;
        }
    }

    protected final void addTarget(DependencyNode dependencyNode, DependencyNode dependencyNode2, int i, DimensionDependency dimensionDependency) {
        dependencyNode.targets.add(dependencyNode2);
        dependencyNode.targets.add(this.dimension);
        dependencyNode.marginFactor = i;
        dependencyNode.marginDependency = dimensionDependency;
        dependencyNode2.dependencies.add(dependencyNode);
        dimensionDependency.dependencies.add(dependencyNode);
    }

    public abstract void apply();

    public abstract void applyToWidget();

    public abstract void clear();

    protected final int getLimitedDimension(int i, int i2) {
        ConstraintWidget constraintWidget;
        int i3;
        if (i2 == 0) {
            constraintWidget = this.widget;
            i3 = constraintWidget.mMatchConstraintMaxWidth;
            i2 = Math.max(constraintWidget.mMatchConstraintMinWidth, i);
            if (i3 > 0) {
                i2 = Math.min(i3, i);
            }
            if (i2 != i) {
                i = i2;
            }
        } else {
            constraintWidget = this.widget;
            i3 = constraintWidget.mMatchConstraintMaxHeight;
            i2 = Math.max(constraintWidget.mMatchConstraintMinHeight, i);
            if (i3 > 0) {
                i2 = Math.min(i3, i);
            }
            if (i2 == i) {
                return i;
            }
            return i2;
        }
        return i;
    }

    public long getWrapDimension() {
        DependencyNode dependencyNode = this.dimension;
        return dependencyNode.resolved ? (long) dependencyNode.value : 0;
    }

    public abstract boolean supportsWrapComputation();

    public void update$ar$ds$4cba2fec_0() {
        throw null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected final void updateRunCenter$ar$ds(androidx.constraintlayout.core.widgets.ConstraintAnchor r11, androidx.constraintlayout.core.widgets.ConstraintAnchor r12, int r13) {
        /*
        r10 = this;
        r0 = getTarget$ar$ds(r11);
        r1 = getTarget$ar$ds(r12);
        r2 = r0.resolved;
        if (r2 == 0) goto L_0x00f5;
    L_0x000c:
        r2 = r1.resolved;
        if (r2 != 0) goto L_0x0012;
    L_0x0010:
        goto L_0x00f5;
    L_0x0012:
        r2 = r0.value;
        r11 = r11.getMargin();
        r2 = r2 + r11;
        r11 = r1.value;
        r12 = r12.getMargin();
        r11 = r11 - r12;
        r12 = r11 - r2;
        r3 = r10.dimension;
        r4 = r3.resolved;
        r5 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        if (r4 != 0) goto L_0x00ad;
    L_0x002a:
        r4 = r10.dimensionBehavior$ar$edu;
        r6 = 3;
        if (r4 != r6) goto L_0x00ad;
    L_0x002f:
        r4 = r10.matchConstraintsType;
        switch(r4) {
            case 0: goto L_0x00a6;
            case 1: goto L_0x0096;
            case 2: goto L_0x006d;
            case 3: goto L_0x0036;
            default: goto L_0x0034;
        };
    L_0x0034:
        goto L_0x00ad;
    L_0x0036:
        r4 = r10.widget;
        r7 = r4.horizontalRun;
        r8 = r7.dimensionBehavior$ar$edu;
        if (r8 != r6) goto L_0x004c;
    L_0x003e:
        r8 = r7.matchConstraintsType;
        if (r8 != r6) goto L_0x004c;
    L_0x0042:
        r8 = r4.verticalRun;
        r9 = r8.dimensionBehavior$ar$edu;
        if (r9 != r6) goto L_0x004c;
    L_0x0048:
        r8 = r8.matchConstraintsType;
        if (r8 == r6) goto L_0x00ad;
    L_0x004c:
        if (r13 != 0) goto L_0x0050;
    L_0x004e:
        r7 = r4.verticalRun;
    L_0x0050:
        r6 = r7.dimension;
        r7 = r6.resolved;
        if (r7 == 0) goto L_0x00ad;
    L_0x0056:
        r4 = r4.mDimensionRatio;
        r7 = 1;
        if (r13 != r7) goto L_0x0062;
    L_0x005b:
        r6 = r6.value;
        r6 = (float) r6;
        r6 = r6 / r4;
        r6 = r6 + r5;
        r4 = (int) r6;
        goto L_0x0069;
    L_0x0062:
        r6 = r6.value;
        r6 = (float) r6;
        r4 = r4 * r6;
        r4 = r4 + r5;
        r4 = (int) r4;
    L_0x0069:
        r3.resolve(r4);
        goto L_0x00ad;
    L_0x006d:
        r4 = r10.widget;
        r6 = r4.mParent;
        if (r6 == 0) goto L_0x00ad;
    L_0x0073:
        if (r13 != 0) goto L_0x0078;
    L_0x0075:
        r6 = r6.horizontalRun;
        goto L_0x007a;
    L_0x0078:
        r6 = r6.verticalRun;
    L_0x007a:
        r6 = r6.dimension;
        r7 = r6.resolved;
        if (r7 == 0) goto L_0x00ad;
    L_0x0080:
        if (r13 != 0) goto L_0x0085;
    L_0x0082:
        r4 = r4.mMatchConstraintPercentWidth;
        goto L_0x0087;
    L_0x0085:
        r4 = r4.mMatchConstraintPercentHeight;
    L_0x0087:
        r6 = r6.value;
        r6 = (float) r6;
        r6 = r6 * r4;
        r6 = r6 + r5;
        r4 = (int) r6;
        r4 = r10.getLimitedDimension(r4, r13);
        r3.resolve(r4);
        goto L_0x00ad;
    L_0x0096:
        r3 = r3.wrapValue;
        r3 = r10.getLimitedDimension(r3, r13);
        r4 = r10.dimension;
        r3 = java.lang.Math.min(r3, r12);
        r4.resolve(r3);
        goto L_0x00ad;
    L_0x00a6:
        r4 = r10.getLimitedDimension(r12, r13);
        r3.resolve(r4);
    L_0x00ad:
        r3 = r10.dimension;
        r4 = r3.resolved;
        if (r4 != 0) goto L_0x00b4;
    L_0x00b3:
        return;
    L_0x00b4:
        r3 = r3.value;
        if (r3 != r12) goto L_0x00c3;
    L_0x00b8:
        r12 = r10.start;
        r12.resolve(r2);
        r12 = r10.end;
        r12.resolve(r11);
        return;
    L_0x00c3:
        if (r13 != 0) goto L_0x00ca;
    L_0x00c5:
        r12 = r10.widget;
        r12 = r12.mHorizontalBiasPercent;
        goto L_0x00ce;
    L_0x00ca:
        r12 = r10.widget;
        r12 = r12.mVerticalBiasPercent;
    L_0x00ce:
        if (r0 != r1) goto L_0x00d7;
    L_0x00d0:
        r2 = r0.value;
        r11 = r1.value;
        r12 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        goto L_0x00d8;
    L_0x00d8:
        r13 = r10.start;
        r0 = (float) r2;
        r0 = r0 + r5;
        r11 = r11 - r2;
        r11 = r11 - r3;
        r11 = (float) r11;
        r11 = r11 * r12;
        r0 = r0 + r11;
        r11 = (int) r0;
        r13.resolve(r11);
        r11 = r10.end;
        r12 = r10.start;
        r12 = r12.value;
        r13 = r10.dimension;
        r13 = r13.value;
        r12 = r12 + r13;
        r11.resolve(r12);
        return;
    L_0x00f5:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.core.widgets.analyzer.WidgetRun.updateRunCenter$ar$ds(androidx.constraintlayout.core.widgets.ConstraintAnchor, androidx.constraintlayout.core.widgets.ConstraintAnchor, int):void");
    }
}
