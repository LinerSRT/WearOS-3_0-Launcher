package androidx.constraintlayout.core.widgets.analyzer;

/* compiled from: PG */
public class DimensionDependency extends DependencyNode {
    public int wrapValue;

    public DimensionDependency(WidgetRun widgetRun) {
        super(widgetRun);
        this.type$ar$edu = widgetRun instanceof HorizontalWidgetRun ? 2 : 3;
    }

    public final void resolve(int i) {
        if (!this.resolved) {
            this.resolved = true;
            this.value = i;
            for (Dependency update$ar$ds$4cba2fec_0 : this.dependencies) {
                update$ar$ds$4cba2fec_0.update$ar$ds$4cba2fec_0();
            }
        }
    }
}
