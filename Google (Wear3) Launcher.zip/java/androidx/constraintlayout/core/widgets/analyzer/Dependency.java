package androidx.constraintlayout.core.widgets.analyzer;

/* compiled from: PG */
public interface Dependency {
    void update$ar$ds$4cba2fec_0();
}
