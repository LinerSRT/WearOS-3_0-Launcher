package androidx.constraintlayout.core.widgets.analyzer;

/* compiled from: PG */
final class BaselineDimensionDependency extends DimensionDependency {
    public BaselineDimensionDependency(WidgetRun widgetRun) {
        super(widgetRun);
    }
}
