package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.ArrayRow;
import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.SolverVariable;

/* compiled from: PG */
public final class Barrier extends HelperWidget {
    public boolean mAllowsGoneWidget = true;
    public int mBarrierType = 0;
    public int mMargin = 0;
    boolean resolved = false;

    public final void addToSolver(LinearSystem linearSystem, boolean z) {
        ConstraintAnchor[] constraintAnchorArr = this.mListAnchors;
        constraintAnchorArr[0] = this.mLeft;
        constraintAnchorArr[2] = this.mTop;
        constraintAnchorArr[1] = this.mRight;
        constraintAnchorArr[3] = this.mBottom;
        int i = 0;
        while (true) {
            ConstraintAnchor[] constraintAnchorArr2 = this.mListAnchors;
            int length = constraintAnchorArr2.length;
            if (i >= 6) {
                break;
            }
            ConstraintAnchor constraintAnchor = constraintAnchorArr2[i];
            constraintAnchor.mSolverVariable = linearSystem.createObjectVariable(constraintAnchor);
            i++;
        }
        i = this.mBarrierType;
        if (i >= 0 && i < 4) {
            ConstraintAnchor constraintAnchor2 = constraintAnchorArr2[i];
            if (!this.resolved) {
                allSolved();
            }
            if (this.resolved) {
                this.resolved = false;
                i = this.mBarrierType;
                if (i != 0) {
                    if (i != 1) {
                        if (i != 2) {
                            if (i != 3) {
                                return;
                            }
                        }
                        linearSystem.addEquality(this.mTop.mSolverVariable, this.f13mY);
                        linearSystem.addEquality(this.mBottom.mSolverVariable, this.f13mY);
                        return;
                    }
                }
                linearSystem.addEquality(this.mLeft.mSolverVariable, this.f12mX);
                linearSystem.addEquality(this.mRight.mSolverVariable, this.f12mX);
                return;
            }
            int i2;
            ConstraintWidget constraintWidget;
            Object obj;
            SolverVariable createObjectVariable;
            ConstraintAnchor[] constraintAnchorArr3;
            int i3;
            ConstraintAnchor constraintAnchor3;
            ConstraintAnchor constraintAnchor4;
            int i4;
            SolverVariable solverVariable;
            int i5;
            ArrayRow createRow;
            SolverVariable createSlackVariable;
            for (i2 = 0; i2 < this.mWidgetsCount; i2++) {
                constraintWidget = this.mWidgets[i2];
                if (this.mAllowsGoneWidget || constraintWidget.allowedInBarrier()) {
                    int i6 = this.mBarrierType;
                    if ((i6 != 0 && i6 != 1) || constraintWidget.getHorizontalDimensionBehaviour$ar$edu() != 3 || constraintWidget.mLeft.mTarget == null || constraintWidget.mRight.mTarget == null) {
                        i6 = this.mBarrierType;
                        if ((i6 == 2 || i6 == 3) && constraintWidget.getVerticalDimensionBehaviour$ar$edu() == 3 && constraintWidget.mTop.mTarget != null && constraintWidget.mBottom.mTarget != null) {
                            obj = 1;
                            break;
                        }
                    }
                    obj = 1;
                    break;
                }
            }
            obj = null;
            Object obj2 = !this.mLeft.hasCenteredDependents() ? this.mRight.hasCenteredDependents() ? 1 : null : 1;
            Object obj3 = !this.mTop.hasCenteredDependents() ? this.mBottom.hasCenteredDependents() ? 1 : null : 1;
            int i7 = 5;
            if (obj == null) {
                i2 = this.mBarrierType;
                if (i2 != 0) {
                    if (i2 == 2) {
                        if (obj3 == null) {
                            obj3 = null;
                        }
                    }
                    for (i2 = 0; i2 < this.mWidgetsCount; i2++) {
                        constraintWidget = this.mWidgets[i2];
                        if (!this.mAllowsGoneWidget) {
                        }
                        createObjectVariable = linearSystem.createObjectVariable(constraintWidget.mListAnchors[this.mBarrierType]);
                        constraintAnchorArr3 = constraintWidget.mListAnchors;
                        i3 = this.mBarrierType;
                        constraintAnchor3 = constraintAnchorArr3[i3];
                        constraintAnchor3.mSolverVariable = createObjectVariable;
                        constraintAnchor4 = constraintAnchor3.mTarget;
                        if (constraintAnchor4 == null) {
                        }
                        i4 = 0;
                        if (i3 != 0) {
                            if (i3 != 2) {
                                solverVariable = constraintAnchor2.mSolverVariable;
                                i5 = this.mMargin;
                                createRow = linearSystem.createRow();
                                createSlackVariable = linearSystem.createSlackVariable();
                                createSlackVariable.strength = 0;
                                createRow.createRowGreaterThan$ar$ds(solverVariable, createObjectVariable, createSlackVariable, i5 + i4);
                                linearSystem.addConstraint(createRow);
                                linearSystem.addEquality$ar$ds(constraintAnchor2.mSolverVariable, createObjectVariable, this.mMargin + i4, i7);
                            }
                        }
                        solverVariable = constraintAnchor2.mSolverVariable;
                        i5 = this.mMargin;
                        createRow = linearSystem.createRow();
                        createSlackVariable = linearSystem.createSlackVariable();
                        createSlackVariable.strength = 0;
                        createRow.createRowLowerThan$ar$ds(solverVariable, createObjectVariable, createSlackVariable, i5 - i4);
                        linearSystem.addConstraint(createRow);
                        linearSystem.addEquality$ar$ds(constraintAnchor2.mSolverVariable, createObjectVariable, this.mMargin + i4, i7);
                    }
                    i = this.mBarrierType;
                    if (i != 0) {
                        linearSystem.addEquality$ar$ds(this.mRight.mSolverVariable, this.mLeft.mSolverVariable, 0, 8);
                        linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 4);
                        linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 0);
                    } else if (i != 1) {
                        linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mRight.mSolverVariable, 0, 8);
                        linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 4);
                        linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 0);
                    } else if (i != 2) {
                        if (i == 3) {
                            linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mBottom.mSolverVariable, 0, 8);
                            linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 4);
                            linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 0);
                        }
                    } else {
                        linearSystem.addEquality$ar$ds(this.mBottom.mSolverVariable, this.mTop.mSolverVariable, 0, 8);
                        linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 4);
                        linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 0);
                    }
                } else if (obj2 == null) {
                    i2 = 0;
                    obj2 = null;
                    if (i2 == 2) {
                        if (obj3 == null) {
                            obj3 = null;
                        }
                    }
                    if (i2 != 1 || r6 == null) {
                        if (i2 == 3 && r7 != null) {
                            for (i2 = 0; i2 < this.mWidgetsCount; i2++) {
                                constraintWidget = this.mWidgets[i2];
                                if (this.mAllowsGoneWidget || constraintWidget.allowedInBarrier()) {
                                    createObjectVariable = linearSystem.createObjectVariable(constraintWidget.mListAnchors[this.mBarrierType]);
                                    constraintAnchorArr3 = constraintWidget.mListAnchors;
                                    i3 = this.mBarrierType;
                                    constraintAnchor3 = constraintAnchorArr3[i3];
                                    constraintAnchor3.mSolverVariable = createObjectVariable;
                                    constraintAnchor4 = constraintAnchor3.mTarget;
                                    if (constraintAnchor4 == null && constraintAnchor4.mOwner == this) {
                                        i4 = constraintAnchor3.mMargin;
                                    } else {
                                        i4 = 0;
                                    }
                                    if (i3 != 0) {
                                        if (i3 != 2) {
                                            solverVariable = constraintAnchor2.mSolverVariable;
                                            i5 = this.mMargin;
                                            createRow = linearSystem.createRow();
                                            createSlackVariable = linearSystem.createSlackVariable();
                                            createSlackVariable.strength = 0;
                                            createRow.createRowGreaterThan$ar$ds(solverVariable, createObjectVariable, createSlackVariable, i5 + i4);
                                            linearSystem.addConstraint(createRow);
                                            linearSystem.addEquality$ar$ds(constraintAnchor2.mSolverVariable, createObjectVariable, this.mMargin + i4, i7);
                                        }
                                    }
                                    solverVariable = constraintAnchor2.mSolverVariable;
                                    i5 = this.mMargin;
                                    createRow = linearSystem.createRow();
                                    createSlackVariable = linearSystem.createSlackVariable();
                                    createSlackVariable.strength = 0;
                                    createRow.createRowLowerThan$ar$ds(solverVariable, createObjectVariable, createSlackVariable, i5 - i4);
                                    linearSystem.addConstraint(createRow);
                                    linearSystem.addEquality$ar$ds(constraintAnchor2.mSolverVariable, createObjectVariable, this.mMargin + i4, i7);
                                }
                            }
                            i = this.mBarrierType;
                            if (i != 0) {
                                linearSystem.addEquality$ar$ds(this.mRight.mSolverVariable, this.mLeft.mSolverVariable, 0, 8);
                                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 4);
                                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 0);
                            } else if (i != 1) {
                                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mRight.mSolverVariable, 0, 8);
                                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 4);
                                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 0);
                            } else if (i != 2) {
                                linearSystem.addEquality$ar$ds(this.mBottom.mSolverVariable, this.mTop.mSolverVariable, 0, 8);
                                linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 4);
                                linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 0);
                            } else {
                                if (i == 3) {
                                    linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mBottom.mSolverVariable, 0, 8);
                                    linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 4);
                                    linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 0);
                                }
                            }
                        }
                    }
                }
                for (i2 = 0; i2 < this.mWidgetsCount; i2++) {
                    constraintWidget = this.mWidgets[i2];
                    if (this.mAllowsGoneWidget) {
                    }
                    createObjectVariable = linearSystem.createObjectVariable(constraintWidget.mListAnchors[this.mBarrierType]);
                    constraintAnchorArr3 = constraintWidget.mListAnchors;
                    i3 = this.mBarrierType;
                    constraintAnchor3 = constraintAnchorArr3[i3];
                    constraintAnchor3.mSolverVariable = createObjectVariable;
                    constraintAnchor4 = constraintAnchor3.mTarget;
                    if (constraintAnchor4 == null) {
                    }
                    i4 = 0;
                    if (i3 != 0) {
                        if (i3 != 2) {
                            solverVariable = constraintAnchor2.mSolverVariable;
                            i5 = this.mMargin;
                            createRow = linearSystem.createRow();
                            createSlackVariable = linearSystem.createSlackVariable();
                            createSlackVariable.strength = 0;
                            createRow.createRowGreaterThan$ar$ds(solverVariable, createObjectVariable, createSlackVariable, i5 + i4);
                            linearSystem.addConstraint(createRow);
                            linearSystem.addEquality$ar$ds(constraintAnchor2.mSolverVariable, createObjectVariable, this.mMargin + i4, i7);
                        }
                    }
                    solverVariable = constraintAnchor2.mSolverVariable;
                    i5 = this.mMargin;
                    createRow = linearSystem.createRow();
                    createSlackVariable = linearSystem.createSlackVariable();
                    createSlackVariable.strength = 0;
                    createRow.createRowLowerThan$ar$ds(solverVariable, createObjectVariable, createSlackVariable, i5 - i4);
                    linearSystem.addConstraint(createRow);
                    linearSystem.addEquality$ar$ds(constraintAnchor2.mSolverVariable, createObjectVariable, this.mMargin + i4, i7);
                }
                i = this.mBarrierType;
                if (i != 0) {
                    linearSystem.addEquality$ar$ds(this.mRight.mSolverVariable, this.mLeft.mSolverVariable, 0, 8);
                    linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 4);
                    linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 0);
                } else if (i != 1) {
                    linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mRight.mSolverVariable, 0, 8);
                    linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 4);
                    linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 0);
                } else if (i != 2) {
                    linearSystem.addEquality$ar$ds(this.mBottom.mSolverVariable, this.mTop.mSolverVariable, 0, 8);
                    linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 4);
                    linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 0);
                } else {
                    if (i == 3) {
                        linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mBottom.mSolverVariable, 0, 8);
                        linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 4);
                        linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 0);
                    }
                }
            }
            i7 = 4;
            for (i2 = 0; i2 < this.mWidgetsCount; i2++) {
                constraintWidget = this.mWidgets[i2];
                if (this.mAllowsGoneWidget) {
                }
                createObjectVariable = linearSystem.createObjectVariable(constraintWidget.mListAnchors[this.mBarrierType]);
                constraintAnchorArr3 = constraintWidget.mListAnchors;
                i3 = this.mBarrierType;
                constraintAnchor3 = constraintAnchorArr3[i3];
                constraintAnchor3.mSolverVariable = createObjectVariable;
                constraintAnchor4 = constraintAnchor3.mTarget;
                if (constraintAnchor4 == null) {
                }
                i4 = 0;
                if (i3 != 0) {
                    if (i3 != 2) {
                        solverVariable = constraintAnchor2.mSolverVariable;
                        i5 = this.mMargin;
                        createRow = linearSystem.createRow();
                        createSlackVariable = linearSystem.createSlackVariable();
                        createSlackVariable.strength = 0;
                        createRow.createRowGreaterThan$ar$ds(solverVariable, createObjectVariable, createSlackVariable, i5 + i4);
                        linearSystem.addConstraint(createRow);
                        linearSystem.addEquality$ar$ds(constraintAnchor2.mSolverVariable, createObjectVariable, this.mMargin + i4, i7);
                    }
                }
                solverVariable = constraintAnchor2.mSolverVariable;
                i5 = this.mMargin;
                createRow = linearSystem.createRow();
                createSlackVariable = linearSystem.createSlackVariable();
                createSlackVariable.strength = 0;
                createRow.createRowLowerThan$ar$ds(solverVariable, createObjectVariable, createSlackVariable, i5 - i4);
                linearSystem.addConstraint(createRow);
                linearSystem.addEquality$ar$ds(constraintAnchor2.mSolverVariable, createObjectVariable, this.mMargin + i4, i7);
            }
            i = this.mBarrierType;
            if (i != 0) {
                linearSystem.addEquality$ar$ds(this.mRight.mSolverVariable, this.mLeft.mSolverVariable, 0, 8);
                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 4);
                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 0);
            } else if (i != 1) {
                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mRight.mSolverVariable, 0, 8);
                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mLeft.mSolverVariable, 0, 4);
                linearSystem.addEquality$ar$ds(this.mLeft.mSolverVariable, this.mParent.mRight.mSolverVariable, 0, 0);
            } else if (i != 2) {
                if (i == 3) {
                    linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mBottom.mSolverVariable, 0, 8);
                    linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 4);
                    linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 0);
                }
            } else {
                linearSystem.addEquality$ar$ds(this.mBottom.mSolverVariable, this.mTop.mSolverVariable, 0, 8);
                linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mBottom.mSolverVariable, 0, 4);
                linearSystem.addEquality$ar$ds(this.mTop.mSolverVariable, this.mParent.mTop.mSolverVariable, 0, 0);
            }
        }
    }

    public final boolean allSolved() {
        int i = 0;
        int i2 = 0;
        Object obj = 1;
        while (true) {
            int i3 = this.mWidgetsCount;
            if (i2 >= i3) {
                break;
            }
            ConstraintWidget constraintWidget = this.mWidgets[i2];
            if (this.mAllowsGoneWidget || constraintWidget.allowedInBarrier()) {
                int i4 = this.mBarrierType;
                if ((i4 == 0 || i4 == 1) && !constraintWidget.isResolvedHorizontally()) {
                    obj = null;
                } else {
                    i4 = this.mBarrierType;
                    if ((i4 == 2 || i4 == 3) && !constraintWidget.isResolvedVertically()) {
                        obj = null;
                    }
                }
            }
            i2++;
        }
        if (obj == null || i3 <= 0) {
            return false;
        }
        i2 = 0;
        obj = null;
        while (i < this.mWidgetsCount) {
            constraintWidget = this.mWidgets[i];
            if (this.mAllowsGoneWidget || constraintWidget.allowedInBarrier()) {
                int i5;
                if (obj == null) {
                    i5 = this.mBarrierType;
                    if (i5 == 0) {
                        i2 = constraintWidget.getAnchor$ar$edu(2).getFinalValue();
                    } else if (i5 == 1) {
                        i2 = constraintWidget.getAnchor$ar$edu(4).getFinalValue();
                    } else if (i5 == 2) {
                        i2 = constraintWidget.getAnchor$ar$edu(3).getFinalValue();
                    } else if (i5 == 3) {
                        i2 = constraintWidget.getAnchor$ar$edu(5).getFinalValue();
                    }
                }
                i5 = this.mBarrierType;
                if (i5 == 0) {
                    i2 = Math.min(i2, constraintWidget.getAnchor$ar$edu(2).getFinalValue());
                    obj = 1;
                } else if (i5 == 1) {
                    i2 = Math.max(i2, constraintWidget.getAnchor$ar$edu(4).getFinalValue());
                    obj = 1;
                } else if (i5 == 2) {
                    i2 = Math.min(i2, constraintWidget.getAnchor$ar$edu(3).getFinalValue());
                    obj = 1;
                } else {
                    if (i5 == 3) {
                        i2 = Math.max(i2, constraintWidget.getAnchor$ar$edu(5).getFinalValue());
                    }
                    obj = 1;
                }
            }
            i++;
        }
        i2 += this.mMargin;
        i = this.mBarrierType;
        if (i != 0) {
            if (i != 1) {
                setFinalVertical(i2, i2);
                this.resolved = true;
                return true;
            }
        }
        setFinalHorizontal(i2, i2);
        this.resolved = true;
        return true;
    }

    public final boolean allowedInBarrier() {
        return true;
    }

    public final int getOrientation() {
        switch (this.mBarrierType) {
            case 0:
            case 1:
                return 0;
            case 2:
            case 3:
                return 1;
            default:
                return -1;
        }
    }

    public final boolean isResolvedHorizontally() {
        return this.resolved;
    }

    public final boolean isResolvedVertically() {
        return this.resolved;
    }

    public final String toString() {
        String str = this.mDebugName;
        StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 12);
        stringBuilder.append("[Barrier] ");
        stringBuilder.append(str);
        stringBuilder.append(" {");
        Object stringBuilder2 = stringBuilder.toString();
        for (int i = 0; i < this.mWidgetsCount; i++) {
            ConstraintWidget constraintWidget = this.mWidgets[i];
            if (i > 0) {
                stringBuilder2 = String.valueOf(stringBuilder2).concat(", ");
            }
            str = String.valueOf(stringBuilder2);
            String valueOf = String.valueOf(constraintWidget.mDebugName);
            stringBuilder2 = valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
        }
        return String.valueOf(stringBuilder2).concat("}");
    }
}
