package androidx.constraintlayout.core.widgets;

/* compiled from: PG */
public final class Chain {
    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void applyChainConstraints(androidx.constraintlayout.core.widgets.ConstraintWidgetContainer r36, androidx.constraintlayout.core.LinearSystem r37, java.util.ArrayList r38, int r39) {
        /*
        r0 = r36;
        r10 = r37;
        r11 = r38;
        r12 = 2;
        if (r39 != 0) goto L_0x0012;
    L_0x0009:
        r1 = r0.mHorizontalChainsSize;
        r2 = r0.mHorizontalChainsArray;
        r14 = r1;
        r15 = r2;
        r16 = 0;
        goto L_0x001a;
    L_0x0012:
        r1 = r0.mVerticalChainsSize;
        r2 = r0.mVerticalChainsArray;
        r14 = r1;
        r15 = r2;
        r16 = 2;
    L_0x001a:
        r9 = 0;
    L_0x001b:
        if (r9 >= r14) goto L_0x0793;
    L_0x001d:
        r1 = r15[r9];
        r2 = r1.mDefined;
        r3 = 3;
        r8 = 8;
        r17 = 0;
        r7 = 1;
        if (r2 != 0) goto L_0x0173;
    L_0x0029:
        r2 = r1.mOrientation;
        r2 = r2 + r2;
        r5 = r1.mFirst;
        r6 = r5;
        r18 = 0;
    L_0x0031:
        if (r18 != 0) goto L_0x012f;
    L_0x0033:
        r13 = r1.mWidgetsCount;
        r13 = r13 + r7;
        r1.mWidgetsCount = r13;
        r13 = r5.mNextChainWidget;
        r4 = r1.mOrientation;
        r13[r4] = r17;
        r13 = r5.mListNextMatchConstraintsWidget;
        r13[r4] = r17;
        r13 = r5.mVisibility;
        if (r13 == r8) goto L_0x00fb;
    L_0x0046:
        r13 = r1.mVisibleWidgets;
        r13 = r13 + r7;
        r1.mVisibleWidgets = r13;
        r4 = r5.getDimensionBehaviour$ar$edu(r4);
        if (r4 == r3) goto L_0x0063;
    L_0x0051:
        r4 = r1.mTotalSize;
        r13 = r1.mOrientation;
        if (r13 != 0) goto L_0x005c;
    L_0x0057:
        r13 = r5.getWidth();
        goto L_0x0060;
    L_0x005c:
        r13 = r5.getHeight();
    L_0x0060:
        r4 = r4 + r13;
        r1.mTotalSize = r4;
    L_0x0063:
        r4 = r1.mTotalSize;
        r13 = r5.mListAnchors;
        r13 = r13[r2];
        r13 = r13.getMargin();
        r4 = r4 + r13;
        r1.mTotalSize = r4;
        r13 = r2 + 1;
        r8 = r5.mListAnchors;
        r8 = r8[r13];
        r8 = r8.getMargin();
        r4 = r4 + r8;
        r1.mTotalSize = r4;
        r4 = r1.mTotalMargins;
        r8 = r5.mListAnchors;
        r8 = r8[r2];
        r8 = r8.getMargin();
        r4 = r4 + r8;
        r1.mTotalMargins = r4;
        r8 = r5.mListAnchors;
        r8 = r8[r13];
        r8 = r8.getMargin();
        r4 = r4 + r8;
        r1.mTotalMargins = r4;
        r4 = r1.mFirstVisibleWidget;
        if (r4 != 0) goto L_0x009b;
    L_0x0099:
        r1.mFirstVisibleWidget = r5;
    L_0x009b:
        r1.mLastVisibleWidget = r5;
        r4 = r5.mListDimensionBehaviors$ar$edu;
        r8 = r1.mOrientation;
        r4 = r4[r8];
        if (r4 != r3) goto L_0x00fb;
    L_0x00a5:
        r4 = r5.mResolvedMatchConstraintDefault;
        r4 = r4[r8];
        if (r4 == 0) goto L_0x00b0;
    L_0x00ab:
        if (r4 == r3) goto L_0x00b0;
    L_0x00ad:
        if (r4 != r12) goto L_0x00f9;
    L_0x00af:
        r4 = 2;
    L_0x00b0:
        r13 = r1.mWidgetsMatchCount;
        r13 = r13 + r7;
        r1.mWidgetsMatchCount = r13;
        r13 = r5.mWeight;
        r8 = r13[r8];
        r13 = 0;
        r21 = (r8 > r13 ? 1 : (r8 == r13 ? 0 : -1));
        if (r21 <= 0) goto L_0x00c3;
    L_0x00be:
        r13 = r1.mTotalWeight;
        r13 = r13 + r8;
        r1.mTotalWeight = r13;
    L_0x00c3:
        r13 = r5.mVisibility;
        r12 = 8;
        if (r13 == r12) goto L_0x00e7;
    L_0x00c9:
        if (r4 == 0) goto L_0x00cd;
    L_0x00cb:
        if (r4 != r3) goto L_0x00e7;
    L_0x00cd:
        r4 = 0;
        r8 = (r8 > r4 ? 1 : (r8 == r4 ? 0 : -1));
        if (r8 >= 0) goto L_0x00d5;
    L_0x00d2:
        r1.mHasUndefinedWeights = r7;
        goto L_0x00d7;
    L_0x00d5:
        r1.mHasDefinedWeights = r7;
    L_0x00d7:
        r4 = r1.mWeightedMatchConstraintsWidgets;
        if (r4 != 0) goto L_0x00e2;
    L_0x00db:
        r4 = new java.util.ArrayList;
        r4.<init>();
        r1.mWeightedMatchConstraintsWidgets = r4;
    L_0x00e2:
        r4 = r1.mWeightedMatchConstraintsWidgets;
        r4.add(r5);
    L_0x00e7:
        r4 = r1.mFirstMatchConstraintWidget;
        if (r4 != 0) goto L_0x00ed;
    L_0x00eb:
        r1.mFirstMatchConstraintWidget = r5;
    L_0x00ed:
        r4 = r1.mLastMatchConstraintWidget;
        if (r4 == 0) goto L_0x00f7;
    L_0x00f1:
        r4 = r4.mListNextMatchConstraintsWidget;
        r8 = r1.mOrientation;
        r4[r8] = r5;
    L_0x00f7:
        r1.mLastMatchConstraintWidget = r5;
    L_0x00f9:
        r4 = r1.mOrientation;
    L_0x00fb:
        if (r6 == r5) goto L_0x0103;
    L_0x00fd:
        r4 = r6.mNextChainWidget;
        r6 = r1.mOrientation;
        r4[r6] = r5;
    L_0x0103:
        r4 = r5.mListAnchors;
        r6 = r2 + 1;
        r4 = r4[r6];
        r4 = r4.mTarget;
        if (r4 == 0) goto L_0x011b;
    L_0x010d:
        r4 = r4.mOwner;
        r6 = r4.mListAnchors;
        r6 = r6[r2];
        r6 = r6.mTarget;
        if (r6 == 0) goto L_0x011b;
    L_0x0117:
        r6 = r6.mOwner;
        if (r6 == r5) goto L_0x011d;
    L_0x011b:
        r4 = r17;
    L_0x011d:
        if (r4 == 0) goto L_0x0121;
    L_0x011f:
        r6 = 0;
        goto L_0x0122;
    L_0x0121:
        r6 = 1;
    L_0x0122:
        if (r4 == 0) goto L_0x0125;
    L_0x0124:
        goto L_0x0126;
    L_0x0125:
        r4 = r5;
    L_0x0126:
        r18 = r6;
        r8 = 8;
        r12 = 2;
        r6 = r5;
        r5 = r4;
        goto L_0x0031;
    L_0x012f:
        r4 = r1.mFirstVisibleWidget;
        if (r4 == 0) goto L_0x0140;
    L_0x0133:
        r6 = r1.mTotalSize;
        r4 = r4.mListAnchors;
        r4 = r4[r2];
        r4 = r4.getMargin();
        r6 = r6 - r4;
        r1.mTotalSize = r6;
    L_0x0140:
        r4 = r1.mLastVisibleWidget;
        if (r4 == 0) goto L_0x0153;
    L_0x0144:
        r6 = r1.mTotalSize;
        r4 = r4.mListAnchors;
        r2 = r2 + 1;
        r2 = r4[r2];
        r2 = r2.getMargin();
        r6 = r6 - r2;
        r1.mTotalSize = r6;
    L_0x0153:
        r1.mLast = r5;
        r2 = r1.mOrientation;
        if (r2 != 0) goto L_0x0162;
    L_0x0159:
        r2 = r1.mIsRtl;
        if (r2 == 0) goto L_0x0162;
    L_0x015d:
        r2 = r1.mLast;
        r1.mHead = r2;
        goto L_0x0166;
    L_0x0162:
        r2 = r1.mFirst;
        r1.mHead = r2;
    L_0x0166:
        r2 = r1.mHasDefinedWeights;
        if (r2 == 0) goto L_0x0170;
    L_0x016a:
        r2 = r1.mHasUndefinedWeights;
        if (r2 == 0) goto L_0x0170;
    L_0x016e:
        r2 = 1;
        goto L_0x0171;
    L_0x0170:
        r2 = 0;
    L_0x0171:
        r1.mHasComplexMatchWeights = r2;
    L_0x0173:
        r1.mDefined = r7;
        if (r11 == 0) goto L_0x018a;
    L_0x0177:
        r2 = r1.mFirst;
        r2 = r11.contains(r2);
        if (r2 == 0) goto L_0x0180;
    L_0x017f:
        goto L_0x018a;
    L_0x0180:
        r26 = r9;
        r29 = r14;
        r30 = r15;
        r18 = 0;
        goto L_0x0786;
    L_0x018a:
        r12 = r1.mFirst;
        r13 = r1.mLast;
        r8 = r1.mFirstVisibleWidget;
        r6 = r1.mLastVisibleWidget;
        r2 = r1.mHead;
        r4 = r1.mTotalWeight;
        r5 = r1.mFirstMatchConstraintWidget;
        r5 = r1.mLastMatchConstraintWidget;
        r5 = r0.mListDimensionBehaviors$ar$edu;
        r5 = r5[r39];
        if (r39 != 0) goto L_0x01bf;
    L_0x01a0:
        r3 = r2.mHorizontalChainStyle;
        if (r3 != 0) goto L_0x01a7;
    L_0x01a4:
        r22 = 1;
        goto L_0x01a9;
    L_0x01a7:
        r22 = 0;
    L_0x01a9:
        if (r3 != r7) goto L_0x01ae;
    L_0x01ab:
        r23 = 1;
        goto L_0x01b0;
    L_0x01ae:
        r23 = 0;
    L_0x01b0:
        r7 = 2;
        if (r3 != r7) goto L_0x01b5;
    L_0x01b3:
        r3 = 1;
        goto L_0x01b6;
    L_0x01b5:
        r3 = 0;
    L_0x01b6:
        r7 = r12;
        r25 = r23;
        r23 = r22;
        r22 = r4;
        r4 = 0;
        goto L_0x01dc;
    L_0x01bf:
        r3 = r2.mVerticalChainStyle;
        if (r3 != 0) goto L_0x01c5;
    L_0x01c3:
        r7 = 1;
        goto L_0x01c6;
    L_0x01c5:
        r7 = 0;
    L_0x01c6:
        r22 = r4;
        r4 = 1;
        if (r3 != r4) goto L_0x01cd;
    L_0x01cb:
        r4 = 1;
        goto L_0x01ce;
    L_0x01cd:
        r4 = 0;
    L_0x01ce:
        r23 = r4;
        r4 = 2;
        if (r3 != r4) goto L_0x01d5;
    L_0x01d3:
        r3 = 1;
        goto L_0x01d6;
    L_0x01d5:
        r3 = 0;
    L_0x01d6:
        r25 = r23;
        r4 = 0;
        r23 = r7;
        r7 = r12;
    L_0x01dc:
        r26 = r9;
        if (r4 != 0) goto L_0x02ac;
    L_0x01e0:
        r4 = r7.mListAnchors;
        r4 = r4[r16];
        r9 = 1;
        if (r9 == r3) goto L_0x01ea;
    L_0x01e7:
        r28 = 4;
        goto L_0x01ec;
    L_0x01ea:
        r28 = 1;
    L_0x01ec:
        r9 = r4.getMargin();
        r11 = r7.mListDimensionBehaviors$ar$edu;
        r11 = r11[r39];
        r29 = r14;
        r14 = 3;
        if (r11 != r14) goto L_0x0201;
    L_0x01f9:
        r11 = r7.mResolvedMatchConstraintDefault;
        r11 = r11[r39];
        if (r11 != 0) goto L_0x0201;
    L_0x01ff:
        r11 = 1;
        goto L_0x0202;
    L_0x0201:
        r11 = 0;
    L_0x0202:
        r14 = r4.mTarget;
        if (r14 == 0) goto L_0x020d;
    L_0x0206:
        if (r7 == r12) goto L_0x020d;
    L_0x0208:
        r14 = r14.getMargin();
        r9 = r9 + r14;
    L_0x020d:
        if (r3 == 0) goto L_0x0215;
    L_0x020f:
        if (r7 == r12) goto L_0x0215;
    L_0x0211:
        if (r7 == r8) goto L_0x0215;
    L_0x0213:
        r28 = 8;
    L_0x0215:
        r14 = r4.mTarget;
        if (r14 == 0) goto L_0x0247;
    L_0x0219:
        if (r7 != r8) goto L_0x0228;
    L_0x021b:
        r30 = r15;
        r15 = r4.mSolverVariable;
        r14 = r14.mSolverVariable;
        r31 = r2;
        r2 = 6;
        r10.addGreaterThan(r15, r14, r9, r2);
        goto L_0x0235;
    L_0x0228:
        r31 = r2;
        r30 = r15;
        r2 = r4.mSolverVariable;
        r14 = r14.mSolverVariable;
        r15 = 8;
        r10.addGreaterThan(r2, r14, r9, r15);
    L_0x0235:
        if (r11 == 0) goto L_0x023b;
    L_0x0237:
        if (r3 != 0) goto L_0x023b;
    L_0x0239:
        r2 = 5;
        goto L_0x023d;
    L_0x023b:
        r2 = r28;
    L_0x023d:
        r11 = r4.mSolverVariable;
        r4 = r4.mTarget;
        r4 = r4.mSolverVariable;
        r10.addEquality$ar$ds(r11, r4, r9, r2);
        goto L_0x024b;
    L_0x0247:
        r31 = r2;
        r30 = r15;
    L_0x024b:
        r2 = 2;
        if (r5 != r2) goto L_0x027e;
    L_0x024e:
        r2 = r7.mVisibility;
        r4 = 8;
        if (r2 == r4) goto L_0x026c;
    L_0x0254:
        r2 = r7.mListDimensionBehaviors$ar$edu;
        r2 = r2[r39];
        r4 = 3;
        if (r2 != r4) goto L_0x026c;
    L_0x025b:
        r2 = r7.mListAnchors;
        r4 = r16 + 1;
        r4 = r2[r4];
        r4 = r4.mSolverVariable;
        r2 = r2[r16];
        r2 = r2.mSolverVariable;
        r9 = 5;
        r11 = 0;
        r10.addGreaterThan(r4, r2, r11, r9);
    L_0x026c:
        r2 = r7.mListAnchors;
        r2 = r2[r16];
        r2 = r2.mSolverVariable;
        r4 = r0.mListAnchors;
        r4 = r4[r16];
        r4 = r4.mSolverVariable;
        r9 = 8;
        r11 = 0;
        r10.addGreaterThan(r2, r4, r11, r9);
    L_0x027e:
        r2 = r7.mListAnchors;
        r4 = r16 + 1;
        r2 = r2[r4];
        r2 = r2.mTarget;
        if (r2 == 0) goto L_0x0296;
    L_0x0288:
        r2 = r2.mOwner;
        r4 = r2.mListAnchors;
        r4 = r4[r16];
        r4 = r4.mTarget;
        if (r4 == 0) goto L_0x0296;
    L_0x0292:
        r4 = r4.mOwner;
        if (r4 == r7) goto L_0x0298;
    L_0x0296:
        r2 = r17;
    L_0x0298:
        if (r2 == 0) goto L_0x029c;
    L_0x029a:
        r4 = 0;
        goto L_0x029d;
    L_0x029c:
        r4 = 1;
    L_0x029d:
        r11 = r38;
        if (r2 == 0) goto L_0x02a2;
    L_0x02a1:
        r7 = r2;
    L_0x02a2:
        r9 = r26;
        r14 = r29;
        r15 = r30;
        r2 = r31;
        goto L_0x01dc;
    L_0x02ac:
        r31 = r2;
        r29 = r14;
        r30 = r15;
        if (r6 == 0) goto L_0x0313;
    L_0x02b4:
        r2 = r16 + 1;
        r4 = r13.mListAnchors;
        r4 = r4[r2];
        r4 = r4.mTarget;
        if (r4 == 0) goto L_0x0311;
    L_0x02be:
        r4 = r6.mListAnchors;
        r4 = r4[r2];
        r7 = r6.mListDimensionBehaviors$ar$edu;
        r7 = r7[r39];
        r9 = 3;
        if (r7 != r9) goto L_0x02e7;
    L_0x02c9:
        r7 = r6.mResolvedMatchConstraintDefault;
        r7 = r7[r39];
        if (r7 != 0) goto L_0x02e7;
    L_0x02cf:
        if (r3 != 0) goto L_0x02e7;
    L_0x02d1:
        r7 = r4.mTarget;
        r9 = r7.mOwner;
        if (r9 != r0) goto L_0x02e5;
    L_0x02d7:
        r9 = r4.mSolverVariable;
        r7 = r7.mSolverVariable;
        r11 = r4.getMargin();
        r11 = -r11;
        r14 = 5;
        r10.addEquality$ar$ds(r9, r7, r11, r14);
        goto L_0x02fd;
    L_0x02e5:
        r14 = 5;
        goto L_0x02e8;
    L_0x02e7:
        r14 = 5;
    L_0x02e8:
        if (r3 == 0) goto L_0x02fd;
    L_0x02ea:
        r7 = r4.mTarget;
        r9 = r7.mOwner;
        if (r9 != r0) goto L_0x02fd;
    L_0x02f0:
        r9 = r4.mSolverVariable;
        r7 = r7.mSolverVariable;
        r11 = r4.getMargin();
        r11 = -r11;
        r15 = 4;
        r10.addEquality$ar$ds(r9, r7, r11, r15);
    L_0x02fd:
        r7 = r4.mSolverVariable;
        r9 = r13.mListAnchors;
        r2 = r9[r2];
        r2 = r2.mTarget;
        r2 = r2.mSolverVariable;
        r4 = r4.getMargin();
        r4 = -r4;
        r9 = 6;
        r10.addLowerThan(r7, r2, r4, r9);
        goto L_0x0314;
    L_0x0311:
        r14 = 5;
        goto L_0x0314;
    L_0x0313:
        r14 = 5;
    L_0x0314:
        r11 = 2;
        if (r5 != r11) goto L_0x032e;
    L_0x0317:
        r2 = r0.mListAnchors;
        r4 = r16 + 1;
        r2 = r2[r4];
        r2 = r2.mSolverVariable;
        r5 = r13.mListAnchors;
        r4 = r5[r4];
        r5 = r4.mSolverVariable;
        r4 = r4.getMargin();
        r7 = 8;
        r10.addGreaterThan(r2, r5, r4, r7);
    L_0x032e:
        r2 = r1.mWeightedMatchConstraintsWidgets;
        if (r2 == 0) goto L_0x0468;
    L_0x0332:
        r4 = r2.size();
        r5 = 1;
        if (r4 <= r5) goto L_0x045f;
    L_0x0339:
        r5 = r1.mHasUndefinedWeights;
        if (r5 == 0) goto L_0x0345;
    L_0x033d:
        r5 = r1.mHasComplexMatchWeights;
        if (r5 != 0) goto L_0x0345;
    L_0x0341:
        r5 = r1.mWidgetsMatchCount;
        r5 = (float) r5;
        goto L_0x0348;
        r5 = r22;
    L_0x0348:
        r15 = r17;
        r7 = 0;
        r9 = 0;
    L_0x034c:
        if (r7 >= r4) goto L_0x0456;
    L_0x034e:
        r21 = r2.get(r7);
        r11 = r21;
        r11 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r11;
        r14 = r11.mWeight;
        r14 = r14[r39];
        r19 = 0;
        r21 = (r14 > r19 ? 1 : (r14 == r19 ? 0 : -1));
        if (r21 >= 0) goto L_0x0383;
    L_0x0360:
        r14 = r1.mHasComplexMatchWeights;
        if (r14 == 0) goto L_0x037b;
    L_0x0364:
        r0 = r11.mListAnchors;
        r11 = r16 + 1;
        r11 = r0[r11];
        r11 = r11.mSolverVariable;
        r0 = r0[r16];
        r0 = r0.mSolverVariable;
        r21 = r2;
        r2 = 0;
        r14 = 4;
        r10.addEquality$ar$ds(r11, r0, r2, r14);
        r11 = 0;
        r22 = 4;
        goto L_0x039e;
    L_0x037b:
        r21 = r2;
        r14 = 4;
        r14 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r22 = 4;
        goto L_0x0387;
    L_0x0383:
        r21 = r2;
        r22 = 4;
    L_0x0387:
        r2 = 0;
        r27 = (r14 > r2 ? 1 : (r14 == r2 ? 0 : -1));
        if (r27 != 0) goto L_0x03a8;
    L_0x038c:
        r0 = r11.mListAnchors;
        r2 = r16 + 1;
        r2 = r0[r2];
        r2 = r2.mSolverVariable;
        r0 = r0[r16];
        r0 = r0.mSolverVariable;
        r11 = 0;
        r14 = 8;
        r10.addEquality$ar$ds(r2, r0, r11, r14);
    L_0x039e:
        r33 = r1;
        r32 = r4;
        r19 = r13;
        r18 = 0;
        goto L_0x0446;
    L_0x03a8:
        r18 = 0;
        if (r15 == 0) goto L_0x043b;
    L_0x03ac:
        r2 = r15.mListAnchors;
        r15 = r2[r16];
        r15 = r15.mSolverVariable;
        r27 = r16 + 1;
        r2 = r2[r27];
        r2 = r2.mSolverVariable;
        r0 = r11.mListAnchors;
        r32 = r4;
        r4 = r0[r16];
        r4 = r4.mSolverVariable;
        r0 = r0[r27];
        r0 = r0.mSolverVariable;
        r27 = r11;
        r11 = r37.createRow();
        r33 = r1;
        r1 = 0;
        r11.constantValue = r1;
        r19 = r13;
        r13 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r34 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1));
        if (r34 == 0) goto L_0x041f;
    L_0x03d7:
        r34 = (r9 > r14 ? 1 : (r9 == r14 ? 0 : -1));
        if (r34 != 0) goto L_0x03dc;
    L_0x03db:
        goto L_0x041f;
    L_0x03dc:
        r34 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1));
        if (r34 != 0) goto L_0x03ed;
    L_0x03e0:
        r0 = r11.variables$ar$class_merging;
        r4 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r0.put(r15, r4);
        r0 = r11.variables$ar$class_merging;
        r0.put(r2, r13);
        goto L_0x0437;
    L_0x03ed:
        r13 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r28 = (r14 > r1 ? 1 : (r14 == r1 ? 0 : -1));
        if (r28 != 0) goto L_0x0400;
    L_0x03f3:
        r2 = r11.variables$ar$class_merging;
        r2.put(r4, r13);
        r2 = r11.variables$ar$class_merging;
        r4 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r2.put(r0, r4);
        goto L_0x0437;
    L_0x0400:
        r1 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r9 = r9 / r5;
        r28 = r14 / r5;
        r9 = r9 / r28;
        r1 = r11.variables$ar$class_merging;
        r1.put(r15, r13);
        r1 = r11.variables$ar$class_merging;
        r13 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r1.put(r2, r13);
        r1 = r11.variables$ar$class_merging;
        r1.put(r0, r9);
        r0 = r11.variables$ar$class_merging;
        r1 = -r9;
        r0.put(r4, r1);
        goto L_0x0437;
    L_0x041f:
        r1 = r11.variables$ar$class_merging;
        r9 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r1.put(r15, r9);
        r1 = r11.variables$ar$class_merging;
        r13 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r1.put(r2, r13);
        r1 = r11.variables$ar$class_merging;
        r1.put(r0, r9);
        r0 = r11.variables$ar$class_merging;
        r0.put(r4, r13);
    L_0x0437:
        r10.addConstraint(r11);
        goto L_0x0443;
    L_0x043b:
        r33 = r1;
        r32 = r4;
        r27 = r11;
        r19 = r13;
    L_0x0443:
        r9 = r14;
        r15 = r27;
    L_0x0446:
        r7 = r7 + 1;
        r11 = 2;
        r14 = 5;
        r0 = r36;
        r13 = r19;
        r2 = r21;
        r4 = r32;
        r1 = r33;
        goto L_0x034c;
    L_0x0456:
        r33 = r1;
        r19 = r13;
        r18 = 0;
        r22 = 4;
        goto L_0x0470;
    L_0x045f:
        r33 = r1;
        r19 = r13;
        r18 = 0;
        r22 = 4;
        goto L_0x0470;
    L_0x0468:
        r33 = r1;
        r19 = r13;
        r18 = 0;
        r22 = 4;
    L_0x0470:
        if (r8 == 0) goto L_0x04df;
    L_0x0472:
        if (r8 == r6) goto L_0x047f;
    L_0x0474:
        if (r3 == 0) goto L_0x0477;
    L_0x0476:
        goto L_0x047f;
    L_0x0477:
        r14 = r6;
        r0 = r8;
        r11 = r19;
        r15 = r26;
        goto L_0x04e5;
    L_0x047f:
        r0 = r12.mListAnchors;
        r0 = r0[r16];
        r1 = r16 + 1;
        r11 = r19;
        r2 = r11.mListAnchors;
        r2 = r2[r1];
        r0 = r0.mTarget;
        if (r0 == 0) goto L_0x0493;
    L_0x048f:
        r0 = r0.mSolverVariable;
        r3 = r0;
        goto L_0x0495;
    L_0x0493:
        r3 = r17;
    L_0x0495:
        r0 = r2.mTarget;
        if (r0 == 0) goto L_0x049c;
    L_0x0499:
        r0 = r0.mSolverVariable;
        goto L_0x049e;
    L_0x049c:
        r0 = r17;
    L_0x049e:
        r4 = r8.mListAnchors;
        r4 = r4[r16];
        if (r6 == 0) goto L_0x04a9;
    L_0x04a4:
        r2 = r6.mListAnchors;
        r2 = r2[r1];
        goto L_0x04aa;
    L_0x04aa:
        if (r3 == 0) goto L_0x04d9;
    L_0x04ac:
        if (r0 == 0) goto L_0x04d9;
    L_0x04ae:
        if (r39 != 0) goto L_0x04b6;
    L_0x04b0:
        r1 = r31;
        r1 = r1.mHorizontalBiasPercent;
        r5 = r1;
        goto L_0x04bb;
    L_0x04b6:
        r1 = r31;
        r1 = r1.mVerticalBiasPercent;
        r5 = r1;
    L_0x04bb:
        r7 = r4.getMargin();
        r9 = r2.getMargin();
        r4 = r4.mSolverVariable;
        r12 = r2.mSolverVariable;
        r13 = 7;
        r1 = r37;
        r2 = r4;
        r4 = r7;
        r14 = r6;
        r6 = r0;
        r7 = r12;
        r0 = r8;
        r8 = r9;
        r15 = r26;
        r9 = r13;
        r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9);
        goto L_0x0727;
    L_0x04d9:
        r14 = r6;
        r0 = r8;
        r15 = r26;
        goto L_0x0727;
    L_0x04df:
        r14 = r6;
        r0 = r8;
        r11 = r19;
        r15 = r26;
    L_0x04e5:
        if (r23 == 0) goto L_0x05ee;
    L_0x04e7:
        if (r0 == 0) goto L_0x05ee;
    L_0x04e9:
        r1 = r33;
        r2 = r1.mWidgetsMatchCount;
        if (r2 <= 0) goto L_0x04f5;
    L_0x04ef:
        r1 = r1.mWidgetsCount;
        if (r1 != r2) goto L_0x04f5;
    L_0x04f3:
        r13 = 1;
        goto L_0x04f6;
    L_0x04f5:
        r13 = 0;
    L_0x04f6:
        r8 = r0;
        r9 = r8;
    L_0x04f8:
        if (r9 == 0) goto L_0x05ea;
    L_0x04fa:
        r1 = r9.mNextChainWidget;
        r1 = r1[r39];
        r7 = r1;
    L_0x04ff:
        if (r7 == 0) goto L_0x050c;
    L_0x0501:
        r1 = r7.mVisibility;
        r6 = 8;
        if (r1 != r6) goto L_0x050e;
    L_0x0507:
        r1 = r7.mNextChainWidget;
        r7 = r1[r39];
        goto L_0x04ff;
    L_0x050c:
        r6 = 8;
    L_0x050e:
        if (r7 != 0) goto L_0x051f;
    L_0x0510:
        if (r9 != r14) goto L_0x0513;
    L_0x0512:
        goto L_0x051f;
    L_0x0513:
        r19 = r7;
        r21 = r8;
        r20 = r13;
        r26 = r15;
        r15 = 5;
        r13 = r9;
        goto L_0x05d8;
    L_0x051f:
        r1 = r9.mListAnchors;
        r1 = r1[r16];
        r2 = r1.mSolverVariable;
        r3 = r1.mTarget;
        if (r3 == 0) goto L_0x052c;
    L_0x0529:
        r3 = r3.mSolverVariable;
        goto L_0x052e;
    L_0x052c:
        r3 = r17;
    L_0x052e:
        if (r8 == r9) goto L_0x0539;
    L_0x0530:
        r3 = r8.mListAnchors;
        r4 = r16 + 1;
        r3 = r3[r4];
        r3 = r3.mSolverVariable;
        goto L_0x0548;
    L_0x0539:
        if (r9 != r0) goto L_0x0548;
    L_0x053b:
        r3 = r12.mListAnchors;
        r3 = r3[r16];
        r3 = r3.mTarget;
        if (r3 == 0) goto L_0x0546;
    L_0x0543:
        r3 = r3.mSolverVariable;
        goto L_0x0548;
    L_0x0546:
        r3 = r17;
    L_0x0548:
        r1 = r1.getMargin();
        r4 = r16 + 1;
        r5 = r9.mListAnchors;
        r5 = r5[r4];
        r5 = r5.getMargin();
        if (r7 == 0) goto L_0x0561;
    L_0x0558:
        r6 = r7.mListAnchors;
        r6 = r6[r16];
        r19 = r7;
        r7 = r6.mSolverVariable;
        goto L_0x0570;
    L_0x0561:
        r19 = r7;
        r6 = r11.mListAnchors;
        r6 = r6[r4];
        r6 = r6.mTarget;
        if (r6 == 0) goto L_0x056e;
    L_0x056b:
        r7 = r6.mSolverVariable;
        goto L_0x0570;
    L_0x056e:
        r7 = r17;
    L_0x0570:
        r26 = r15;
        r15 = r9.mListAnchors;
        r15 = r15[r4];
        r15 = r15.mSolverVariable;
        if (r6 == 0) goto L_0x0580;
    L_0x057a:
        r6 = r6.getMargin();
        r5 = r5 + r6;
        goto L_0x0581;
    L_0x0581:
        r6 = r8.mListAnchors;
        r6 = r6[r4];
        r6 = r6.getMargin();
        r1 = r1 + r6;
        if (r2 == 0) goto L_0x05d2;
    L_0x058c:
        if (r3 == 0) goto L_0x05d2;
    L_0x058e:
        if (r7 == 0) goto L_0x05d2;
    L_0x0590:
        if (r15 == 0) goto L_0x05d2;
    L_0x0592:
        if (r9 != r0) goto L_0x059e;
    L_0x0594:
        r1 = r0.mListAnchors;
        r1 = r1[r16];
        r1 = r1.getMargin();
        r6 = r1;
        goto L_0x059f;
    L_0x059e:
        r6 = r1;
    L_0x059f:
        if (r9 != r14) goto L_0x05ac;
    L_0x05a1:
        r1 = r14.mListAnchors;
        r1 = r1[r4];
        r1 = r1.getMargin();
        r21 = r1;
        goto L_0x05ae;
    L_0x05ac:
        r21 = r5;
    L_0x05ae:
        r5 = 1;
        if (r5 == r13) goto L_0x05b4;
    L_0x05b1:
        r22 = 5;
        goto L_0x05b6;
    L_0x05b4:
        r22 = 8;
    L_0x05b6:
        r24 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r1 = r37;
        r4 = r6;
        r27 = 1;
        r5 = r24;
        r20 = 8;
        r6 = r7;
        r7 = r15;
        r15 = r8;
        r8 = r21;
        r20 = r13;
        r21 = r15;
        r15 = 5;
        r13 = r9;
        r9 = r22;
        r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9);
        goto L_0x05d8;
    L_0x05d2:
        r21 = r8;
        r20 = r13;
        r15 = 5;
        r13 = r9;
    L_0x05d8:
        r1 = r13.mVisibility;
        r9 = 8;
        if (r1 == r9) goto L_0x05e0;
    L_0x05de:
        r8 = r13;
        goto L_0x05e2;
    L_0x05e0:
        r8 = r21;
    L_0x05e2:
        r9 = r19;
        r13 = r20;
        r15 = r26;
        goto L_0x04f8;
    L_0x05ea:
        r26 = r15;
        goto L_0x0727;
    L_0x05ee:
        r26 = r15;
        r1 = r33;
        r9 = 8;
        r15 = 5;
        if (r25 == 0) goto L_0x0727;
    L_0x05f7:
        if (r0 == 0) goto L_0x0727;
    L_0x05f9:
        r2 = r1.mWidgetsMatchCount;
        if (r2 <= 0) goto L_0x0603;
    L_0x05fd:
        r1 = r1.mWidgetsCount;
        if (r1 != r2) goto L_0x0603;
    L_0x0601:
        r13 = 1;
        goto L_0x0604;
    L_0x0603:
        r13 = 0;
    L_0x0604:
        r7 = r0;
        r8 = r7;
    L_0x0606:
        if (r8 == 0) goto L_0x06cd;
    L_0x0608:
        r1 = r8.mNextChainWidget;
        r1 = r1[r39];
    L_0x060c:
        if (r1 == 0) goto L_0x0617;
    L_0x060e:
        r2 = r1.mVisibility;
        if (r2 != r9) goto L_0x0617;
    L_0x0612:
        r1 = r1.mNextChainWidget;
        r1 = r1[r39];
        goto L_0x060c;
    L_0x0617:
        if (r8 == r0) goto L_0x06b4;
    L_0x0619:
        if (r8 == r14) goto L_0x06b4;
    L_0x061b:
        if (r1 == 0) goto L_0x06b4;
    L_0x061d:
        if (r1 != r14) goto L_0x0622;
    L_0x061f:
        r6 = r17;
        goto L_0x0623;
    L_0x0622:
        r6 = r1;
    L_0x0623:
        r1 = r8.mListAnchors;
        r1 = r1[r16];
        r2 = r1.mSolverVariable;
        r3 = r1.mTarget;
        r3 = r16 + 1;
        r4 = r7.mListAnchors;
        r4 = r4[r3];
        r4 = r4.mSolverVariable;
        r1 = r1.getMargin();
        r5 = r8.mListAnchors;
        r5 = r5[r3];
        r5 = r5.getMargin();
        if (r6 == 0) goto L_0x0658;
    L_0x0641:
        r9 = r6.mListAnchors;
        r9 = r9[r16];
        r15 = r9.mSolverVariable;
        r19 = r6;
        r6 = r9.mTarget;
        if (r6 == 0) goto L_0x0650;
    L_0x064d:
        r6 = r6.mSolverVariable;
        goto L_0x0652;
    L_0x0650:
        r6 = r17;
    L_0x0652:
        r35 = r15;
        r15 = r6;
        r6 = r35;
        goto L_0x066b;
    L_0x0658:
        r19 = r6;
        r6 = r14.mListAnchors;
        r9 = r6[r16];
        if (r9 == 0) goto L_0x0663;
    L_0x0660:
        r6 = r9.mSolverVariable;
        goto L_0x0665;
    L_0x0663:
        r6 = r17;
    L_0x0665:
        r15 = r8.mListAnchors;
        r15 = r15[r3];
        r15 = r15.mSolverVariable;
    L_0x066b:
        if (r9 == 0) goto L_0x0674;
    L_0x066d:
        r9 = r9.getMargin();
        r5 = r5 + r9;
        r9 = r5;
        goto L_0x0675;
    L_0x0674:
        r9 = r5;
    L_0x0675:
        r5 = r7.mListAnchors;
        r3 = r5[r3];
        r3 = r3.getMargin();
        r5 = r1 + r3;
        r3 = 1;
        if (r3 == r13) goto L_0x0685;
    L_0x0682:
        r20 = 4;
        goto L_0x0687;
    L_0x0685:
        r20 = 8;
    L_0x0687:
        if (r2 == 0) goto L_0x06a8;
    L_0x0689:
        if (r4 == 0) goto L_0x06a8;
    L_0x068b:
        if (r6 == 0) goto L_0x06a8;
    L_0x068d:
        if (r15 == 0) goto L_0x06a8;
    L_0x068f:
        r21 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r1 = r37;
        r24 = 1;
        r3 = r4;
        r4 = r5;
        r5 = r21;
        r21 = r7;
        r7 = r15;
        r15 = r8;
        r8 = r9;
        r27 = r13;
        r13 = 8;
        r9 = r20;
        r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9);
        goto L_0x06b1;
    L_0x06a8:
        r21 = r7;
        r15 = r8;
        r27 = r13;
        r13 = 8;
        r24 = 1;
    L_0x06b1:
        r8 = r19;
        goto L_0x06be;
    L_0x06b4:
        r21 = r7;
        r15 = r8;
        r27 = r13;
        r13 = 8;
        r24 = 1;
        r8 = r1;
    L_0x06be:
        r1 = r15.mVisibility;
        if (r1 == r13) goto L_0x06c4;
    L_0x06c2:
        r7 = r15;
        goto L_0x06c6;
    L_0x06c4:
        r7 = r21;
    L_0x06c6:
        r13 = r27;
        r9 = 8;
        r15 = 5;
        goto L_0x0606;
    L_0x06cd:
        r1 = r0.mListAnchors;
        r1 = r1[r16];
        r2 = r12.mListAnchors;
        r2 = r2[r16];
        r2 = r2.mTarget;
        r3 = r16 + 1;
        r4 = r14.mListAnchors;
        r12 = r4[r3];
        r4 = r11.mListAnchors;
        r3 = r4[r3];
        r13 = r3.mTarget;
        if (r2 == 0) goto L_0x0716;
    L_0x06e5:
        if (r0 == r14) goto L_0x06f4;
    L_0x06e7:
        r3 = r1.mSolverVariable;
        r2 = r2.mSolverVariable;
        r1 = r1.getMargin();
        r4 = 5;
        r10.addEquality$ar$ds(r3, r2, r1, r4);
        goto L_0x0716;
    L_0x06f4:
        if (r13 == 0) goto L_0x0716;
    L_0x06f6:
        r3 = r1.mSolverVariable;
        r4 = r2.mSolverVariable;
        r5 = r1.getMargin();
        r6 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r7 = r12.mSolverVariable;
        r8 = r13.mSolverVariable;
        r9 = r12.getMargin();
        r15 = 5;
        r1 = r37;
        r2 = r3;
        r3 = r4;
        r4 = r5;
        r5 = r6;
        r6 = r7;
        r7 = r8;
        r8 = r9;
        r9 = r15;
        r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9);
    L_0x0716:
        if (r13 == 0) goto L_0x0727;
    L_0x0718:
        if (r0 == r14) goto L_0x0727;
    L_0x071a:
        r1 = r12.mSolverVariable;
        r2 = r13.mSolverVariable;
        r3 = r12.getMargin();
        r3 = -r3;
        r4 = 5;
        r10.addEquality$ar$ds(r1, r2, r3, r4);
    L_0x0727:
        if (r23 != 0) goto L_0x072b;
    L_0x0729:
        if (r25 == 0) goto L_0x0786;
    L_0x072b:
        if (r0 == 0) goto L_0x0786;
    L_0x072d:
        if (r0 == r14) goto L_0x0786;
    L_0x072f:
        r1 = r0.mListAnchors;
        r2 = r1[r16];
        if (r14 != 0) goto L_0x0737;
    L_0x0735:
        r8 = r0;
        goto L_0x0738;
    L_0x0737:
        r8 = r14;
    L_0x0738:
        r3 = r16 + 1;
        r4 = r8.mListAnchors;
        r4 = r4[r3];
        r5 = r2.mTarget;
        if (r5 == 0) goto L_0x0745;
    L_0x0742:
        r5 = r5.mSolverVariable;
        goto L_0x0747;
    L_0x0745:
        r5 = r17;
    L_0x0747:
        r6 = r4.mTarget;
        if (r6 == 0) goto L_0x074e;
    L_0x074b:
        r6 = r6.mSolverVariable;
        goto L_0x0750;
    L_0x074e:
        r6 = r17;
    L_0x0750:
        if (r11 == r8) goto L_0x075f;
    L_0x0752:
        r6 = r11.mListAnchors;
        r6 = r6[r3];
        r6 = r6.mTarget;
        if (r6 == 0) goto L_0x075d;
    L_0x075a:
        r6 = r6.mSolverVariable;
        goto L_0x075f;
    L_0x075d:
        r6 = r17;
    L_0x075f:
        if (r0 != r8) goto L_0x0764;
    L_0x0761:
        r4 = r1[r3];
        goto L_0x0765;
    L_0x0765:
        if (r5 == 0) goto L_0x0786;
    L_0x0767:
        if (r6 == 0) goto L_0x0786;
    L_0x0769:
        r0 = r2.getMargin();
        r1 = r8.mListAnchors;
        r1 = r1[r3];
        r8 = r1.getMargin();
        r2 = r2.mSolverVariable;
        r7 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r9 = r4.mSolverVariable;
        r11 = 5;
        r1 = r37;
        r3 = r5;
        r4 = r0;
        r5 = r7;
        r7 = r9;
        r9 = r11;
        r1.addCentering(r2, r3, r4, r5, r6, r7, r8, r9);
    L_0x0786:
        r9 = r26 + 1;
        r12 = 2;
        r0 = r36;
        r11 = r38;
        r14 = r29;
        r15 = r30;
        goto L_0x001b;
    L_0x0793:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.core.widgets.Chain.applyChainConstraints(androidx.constraintlayout.core.widgets.ConstraintWidgetContainer, androidx.constraintlayout.core.LinearSystem, java.util.ArrayList, int):void");
    }
}
