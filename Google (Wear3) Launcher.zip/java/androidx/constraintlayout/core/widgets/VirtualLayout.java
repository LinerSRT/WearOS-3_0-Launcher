package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure.Measure;

/* compiled from: PG */
public class VirtualLayout extends HelperWidget {
    public VirtualLayout() {
        Measure measure = new Measure();
    }
}
