package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;

/* compiled from: PG */
public final class Optimizer {
    static final boolean[] flags = new boolean[3];

    static void checkMatchParent(ConstraintWidgetContainer constraintWidgetContainer, LinearSystem linearSystem, ConstraintWidget constraintWidget) {
        int i;
        constraintWidget.mHorizontalResolution = -1;
        constraintWidget.mVerticalResolution = -1;
        if (constraintWidgetContainer.mListDimensionBehaviors$ar$edu[0] != 2 && constraintWidget.mListDimensionBehaviors$ar$edu[0] == 4) {
            i = constraintWidget.mLeft.mMargin;
            int width = constraintWidgetContainer.getWidth() - constraintWidget.mRight.mMargin;
            ConstraintAnchor constraintAnchor = constraintWidget.mLeft;
            constraintAnchor.mSolverVariable = linearSystem.createObjectVariable(constraintAnchor);
            constraintAnchor = constraintWidget.mRight;
            constraintAnchor.mSolverVariable = linearSystem.createObjectVariable(constraintAnchor);
            linearSystem.addEquality(constraintWidget.mLeft.mSolverVariable, i);
            linearSystem.addEquality(constraintWidget.mRight.mSolverVariable, width);
            constraintWidget.mHorizontalResolution = 2;
            constraintWidget.f12mX = i;
            width -= i;
            constraintWidget.mWidth = width;
            i = constraintWidget.mMinWidth;
            if (width < i) {
                constraintWidget.mWidth = i;
            }
        }
        if (constraintWidgetContainer.mListDimensionBehaviors$ar$edu[1] != 2 && constraintWidget.mListDimensionBehaviors$ar$edu[1] == 4) {
            i = constraintWidget.mTop.mMargin;
            int height = constraintWidgetContainer.getHeight() - constraintWidget.mBottom.mMargin;
            ConstraintAnchor constraintAnchor2 = constraintWidget.mTop;
            constraintAnchor2.mSolverVariable = linearSystem.createObjectVariable(constraintAnchor2);
            constraintAnchor2 = constraintWidget.mBottom;
            constraintAnchor2.mSolverVariable = linearSystem.createObjectVariable(constraintAnchor2);
            linearSystem.addEquality(constraintWidget.mTop.mSolverVariable, i);
            linearSystem.addEquality(constraintWidget.mBottom.mSolverVariable, height);
            if (constraintWidget.mBaselineDistance > 0 || constraintWidget.mVisibility == 8) {
                constraintAnchor2 = constraintWidget.mBaseline;
                constraintAnchor2.mSolverVariable = linearSystem.createObjectVariable(constraintAnchor2);
                linearSystem.addEquality(constraintWidget.mBaseline.mSolverVariable, constraintWidget.mBaselineDistance + i);
            }
            constraintWidget.mVerticalResolution = 2;
            constraintWidget.f13mY = i;
            height -= i;
            constraintWidget.mHeight = height;
            int i2 = constraintWidget.mMinHeight;
            if (height < i2) {
                constraintWidget.mHeight = i2;
            }
        }
    }

    public static final boolean enabled(int i, int i2) {
        return (i & i2) == i2;
    }
}
