package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.ArrayRow;
import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.SolverVariable;

/* compiled from: PG */
public final class Guideline extends ConstraintWidget {
    public ConstraintAnchor mAnchor = this.mTop;
    public int mOrientation;
    public int mRelativeBegin = -1;
    public int mRelativeEnd = -1;
    public float mRelativePercent = -1.0f;
    private boolean resolved;

    public Guideline() {
        int i = 0;
        this.mOrientation = 0;
        this.mAnchors.clear();
        this.mAnchors.add(this.mAnchor);
        int length = this.mListAnchors.length;
        while (i < 6) {
            this.mListAnchors[i] = this.mAnchor;
            i++;
        }
    }

    public final void addToSolver(LinearSystem linearSystem, boolean z) {
        ConstraintWidget constraintWidget = this.mParent;
        if (constraintWidget != null) {
            int i;
            SolverVariable createObjectVariable;
            SolverVariable createObjectVariable2;
            Object anchor$ar$edu = constraintWidget.getAnchor$ar$edu(2);
            Object anchor$ar$edu2 = constraintWidget.getAnchor$ar$edu(4);
            ConstraintWidget constraintWidget2 = this.mParent;
            int i2 = 1;
            if (constraintWidget2 == null || constraintWidget2.mListDimensionBehaviors$ar$edu[0] != 2) {
                i = 0;
            } else {
                i = 1;
            }
            if (this.mOrientation == 0) {
                anchor$ar$edu = constraintWidget.getAnchor$ar$edu(3);
                anchor$ar$edu2 = constraintWidget.getAnchor$ar$edu(5);
                constraintWidget = this.mParent;
                if (constraintWidget == null || constraintWidget.mListDimensionBehaviors$ar$edu[1] != 2) {
                    i2 = 0;
                }
                i = i2;
            }
            if (this.resolved) {
                ConstraintAnchor constraintAnchor = this.mAnchor;
                if (constraintAnchor.mHasFinalValue) {
                    createObjectVariable = linearSystem.createObjectVariable(constraintAnchor);
                    linearSystem.addEquality(createObjectVariable, this.mAnchor.getFinalValue());
                    if (this.mRelativeBegin != -1) {
                        if (i != 0) {
                            linearSystem.addGreaterThan(linearSystem.createObjectVariable(anchor$ar$edu2), createObjectVariable, 0, 5);
                        }
                    } else if (!(this.mRelativeEnd == -1 || i == 0)) {
                        createObjectVariable2 = linearSystem.createObjectVariable(anchor$ar$edu2);
                        linearSystem.addGreaterThan(createObjectVariable, linearSystem.createObjectVariable(anchor$ar$edu), 0, 5);
                        linearSystem.addGreaterThan(createObjectVariable2, createObjectVariable, 0, 5);
                    }
                    this.resolved = false;
                    return;
                }
            }
            if (this.mRelativeBegin != -1) {
                createObjectVariable = linearSystem.createObjectVariable(this.mAnchor);
                linearSystem.addEquality$ar$ds(createObjectVariable, linearSystem.createObjectVariable(anchor$ar$edu), this.mRelativeBegin, 8);
                if (i != 0) {
                    linearSystem.addGreaterThan(linearSystem.createObjectVariable(anchor$ar$edu2), createObjectVariable, 0, 5);
                }
            } else if (this.mRelativeEnd != -1) {
                createObjectVariable = linearSystem.createObjectVariable(this.mAnchor);
                createObjectVariable2 = linearSystem.createObjectVariable(anchor$ar$edu2);
                linearSystem.addEquality$ar$ds(createObjectVariable, createObjectVariable2, -this.mRelativeEnd, 8);
                if (i != 0) {
                    linearSystem.addGreaterThan(createObjectVariable, linearSystem.createObjectVariable(anchor$ar$edu), 0, 5);
                    linearSystem.addGreaterThan(createObjectVariable2, createObjectVariable, 0, 5);
                }
            } else if (this.mRelativePercent != -1.0f) {
                createObjectVariable = linearSystem.createObjectVariable(this.mAnchor);
                SolverVariable createObjectVariable3 = linearSystem.createObjectVariable(anchor$ar$edu2);
                float f = this.mRelativePercent;
                ArrayRow createRow = linearSystem.createRow();
                createRow.variables$ar$class_merging.put(createObjectVariable, -1.0f);
                createRow.variables$ar$class_merging.put(createObjectVariable3, f);
                linearSystem.addConstraint(createRow);
            }
        }
    }

    public final boolean allowedInBarrier() {
        return true;
    }

    public final ConstraintAnchor getAnchor$ar$edu(int i) {
        switch (i - 1) {
            case 1:
            case 3:
                if (this.mOrientation == 1) {
                    return this.mAnchor;
                }
                break;
            case 2:
            case 4:
                if (this.mOrientation == 0) {
                    return this.mAnchor;
                }
                break;
            default:
                return null;
        }
        return null;
    }

    public final boolean isResolvedHorizontally() {
        return this.resolved;
    }

    public final boolean isResolvedVertically() {
        return this.resolved;
    }

    public final void setFinalValue(int i) {
        this.mAnchor.setFinalValue(i);
        this.resolved = true;
    }

    public final void setOrientation(int i) {
        if (this.mOrientation != i) {
            this.mOrientation = i;
            this.mAnchors.clear();
            if (this.mOrientation == 1) {
                this.mAnchor = this.mLeft;
            } else {
                this.mAnchor = this.mTop;
            }
            this.mAnchors.add(this.mAnchor);
            i = this.mListAnchors.length;
            for (i = 0; i < 6; i++) {
                this.mListAnchors[i] = this.mAnchor;
            }
        }
    }

    public final void updateFromSolver$ar$ds(boolean z) {
        if (this.mParent != null) {
            int objectVariableValue$ar$ds = LinearSystem.getObjectVariableValue$ar$ds(this.mAnchor);
            if (this.mOrientation == 1) {
                this.f12mX = objectVariableValue$ar$ds;
                this.f13mY = 0;
                setHeight(this.mParent.getHeight());
                setWidth(0);
                return;
            }
            this.f12mX = 0;
            this.f13mY = objectVariableValue$ar$ds;
            setWidth(this.mParent.getWidth());
            setHeight(0);
        }
    }
}
