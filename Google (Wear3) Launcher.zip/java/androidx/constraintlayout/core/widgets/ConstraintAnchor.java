package androidx.constraintlayout.core.widgets;

import android.support.p002v7.widget.LinearLayoutManager;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.analyzer.Grouping;
import androidx.constraintlayout.core.widgets.analyzer.WidgetGroup;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/* compiled from: PG */
public final class ConstraintAnchor {
    public HashSet mDependents = null;
    public int mFinalValue;
    int mGoneMargin = LinearLayoutManager.INVALID_OFFSET;
    public boolean mHasFinalValue;
    public int mMargin = 0;
    public final ConstraintWidget mOwner;
    public SolverVariable mSolverVariable;
    public ConstraintAnchor mTarget;
    public final int mType$ar$edu$21f04e0f_0;

    public ConstraintAnchor(ConstraintWidget constraintWidget, int i) {
        this.mOwner = constraintWidget;
        this.mType$ar$edu$21f04e0f_0 = i;
    }

    public final void connect$ar$ds$404e5fa_0(ConstraintAnchor constraintAnchor, int i, int i2) {
        if (constraintAnchor == null) {
            reset();
            return;
        }
        this.mTarget = constraintAnchor;
        if (constraintAnchor.mDependents == null) {
            constraintAnchor.mDependents = new HashSet();
        }
        HashSet hashSet = this.mTarget.mDependents;
        if (hashSet != null) {
            hashSet.add(this);
        }
        this.mMargin = i;
        this.mGoneMargin = i2;
    }

    public final void findDependents(int i, ArrayList arrayList, WidgetGroup widgetGroup) {
        HashSet hashSet = this.mDependents;
        if (hashSet != null) {
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                Grouping.findDependents(((ConstraintAnchor) it.next()).mOwner, i, arrayList, widgetGroup);
            }
        }
    }

    public final int getFinalValue() {
        return !this.mHasFinalValue ? 0 : this.mFinalValue;
    }

    public final int getMargin() {
        if (this.mOwner.mVisibility == 8) {
            return 0;
        }
        int i = this.mGoneMargin;
        if (i != LinearLayoutManager.INVALID_OFFSET) {
            ConstraintAnchor constraintAnchor = this.mTarget;
            if (constraintAnchor != null && constraintAnchor.mOwner.mVisibility == 8) {
                return i;
            }
        }
        return this.mMargin;
    }

    public final boolean hasCenteredDependents() {
        HashSet hashSet = this.mDependents;
        if (hashSet == null) {
            return false;
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            ConstraintAnchor constraintAnchor = (ConstraintAnchor) it.next();
            switch (constraintAnchor.mType$ar$edu$21f04e0f_0 - 1) {
                case 1:
                    constraintAnchor = constraintAnchor.mOwner.mRight;
                    break;
                case 2:
                    constraintAnchor = constraintAnchor.mOwner.mBottom;
                    break;
                case 3:
                    constraintAnchor = constraintAnchor.mOwner.mLeft;
                    break;
                case 4:
                    constraintAnchor = constraintAnchor.mOwner.mTop;
                    break;
                default:
                    constraintAnchor = null;
                    break;
            }
            if (constraintAnchor.isConnected()) {
                return true;
            }
        }
        return false;
    }

    public final boolean hasDependents() {
        HashSet hashSet = this.mDependents;
        return hashSet != null && hashSet.size() > 0;
    }

    public final boolean isConnected() {
        return this.mTarget != null;
    }

    public final void reset() {
        ConstraintAnchor constraintAnchor = this.mTarget;
        if (constraintAnchor != null) {
            HashSet hashSet = constraintAnchor.mDependents;
            if (hashSet != null) {
                hashSet.remove(this);
                if (this.mTarget.mDependents.size() == 0) {
                    this.mTarget.mDependents = null;
                }
            }
        }
        this.mDependents = null;
        this.mTarget = null;
        this.mMargin = 0;
        this.mGoneMargin = LinearLayoutManager.INVALID_OFFSET;
        this.mHasFinalValue = false;
        this.mFinalValue = 0;
    }

    public final void resetSolverVariable$ar$ds() {
        SolverVariable solverVariable = this.mSolverVariable;
        if (solverVariable == null) {
            this.mSolverVariable = new SolverVariable(1);
        } else {
            solverVariable.reset();
        }
    }

    public final void setFinalValue(int i) {
        this.mFinalValue = i;
        this.mHasFinalValue = true;
    }

    public final String toString() {
        String str;
        String str2 = this.mOwner.mDebugName;
        switch (this.mType$ar$edu$21f04e0f_0) {
            case 2:
                str = "LEFT";
                break;
            case 3:
                str = "TOP";
                break;
            case 4:
                str = "RIGHT";
                break;
            case 5:
                str = "BOTTOM";
                break;
            case 6:
                str = "BASELINE";
                break;
            case 7:
                str = "CENTER";
                break;
            case 8:
                str = "CENTER_X";
                break;
            default:
                str = "CENTER_Y";
                break;
        }
        StringBuilder stringBuilder = new StringBuilder((String.valueOf(str2).length() + 1) + str.length());
        stringBuilder.append(str2);
        stringBuilder.append(":");
        stringBuilder.append(str);
        return stringBuilder.toString();
    }
}
