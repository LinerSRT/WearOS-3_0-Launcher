package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.ArrayList;

/* compiled from: PG */
public final class Flow extends VirtualLayout {
    public Flow() {
        ArrayList arrayList = new ArrayList();
    }

    public final void addToSolver(LinearSystem linearSystem, boolean z) {
        super.addToSolver(linearSystem, z);
        throw null;
    }
}
