package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import androidx.constraintlayout.core.SolverVariable;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure;
import androidx.constraintlayout.core.widgets.analyzer.BasicMeasure.Measure;
import androidx.constraintlayout.core.widgets.analyzer.ChainRun;
import androidx.constraintlayout.core.widgets.analyzer.DependencyGraph;
import androidx.constraintlayout.core.widgets.analyzer.WidgetRun;
import androidx.constraintlayout.widget.ConstraintLayout.Measurer;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/* compiled from: PG */
public final class ConstraintWidgetContainer extends WidgetContainer {
    public WeakReference horizontalWrapMax = null;
    public WeakReference horizontalWrapMin = null;
    public final BasicMeasure mBasicMeasureSolver = new BasicMeasure(this);
    public final DependencyGraph mDependencyGraph = new DependencyGraph(this);
    public boolean mHeightMeasuredTooSmall = false;
    ChainHead[] mHorizontalChainsArray = new ChainHead[4];
    public int mHorizontalChainsSize = 0;
    public boolean mIsRtl = false;
    public final Measure mMeasure = new Measure();
    public Measurer mMeasurer$ar$class_merging = null;
    public int mOptimizationLevel = 257;
    public int mPaddingLeft;
    public int mPaddingTop;
    public final LinearSystem mSystem = new LinearSystem();
    ChainHead[] mVerticalChainsArray = new ChainHead[4];
    public int mVerticalChainsSize = 0;
    public boolean mWidthMeasuredTooSmall = false;
    public int pass;
    public WeakReference verticalWrapMax = null;
    public WeakReference verticalWrapMin = null;
    final HashSet widgetsToAdd = new HashSet();

    private final void addMaxWrap(ConstraintAnchor constraintAnchor, SolverVariable solverVariable) {
        this.mSystem.addGreaterThan(solverVariable, this.mSystem.createObjectVariable(constraintAnchor), 0, 5);
    }

    private final void addMinWrap(ConstraintAnchor constraintAnchor, SolverVariable solverVariable) {
        this.mSystem.addGreaterThan(this.mSystem.createObjectVariable(constraintAnchor), solverVariable, 0, 5);
    }

    public static void measure$ar$class_merging$ar$ds(ConstraintWidget constraintWidget, Measurer measurer, Measure measure) {
        if (measurer != null) {
            if (!(constraintWidget.mVisibility == 8 || (constraintWidget instanceof Guideline))) {
                if (!(constraintWidget instanceof Barrier)) {
                    measure.horizontalBehavior$ar$edu = constraintWidget.getHorizontalDimensionBehaviour$ar$edu();
                    measure.verticalBehavior$ar$edu = constraintWidget.getVerticalDimensionBehaviour$ar$edu();
                    measure.horizontalDimension = constraintWidget.getWidth();
                    measure.verticalDimension = constraintWidget.getHeight();
                    measure.measuredNeedsSolverPass = false;
                    measure.measureStrategy = 0;
                    Object obj = measure.horizontalBehavior$ar$edu == 3 ? 1 : null;
                    Object obj2 = measure.verticalBehavior$ar$edu == 3 ? 1 : null;
                    Object obj3 = (obj == null || constraintWidget.mDimensionRatio <= 0.0f) ? null : 1;
                    Object obj4 = (obj2 == null || constraintWidget.mDimensionRatio <= 0.0f) ? null : 1;
                    if (obj != null && constraintWidget.hasDanglingDimension(0) && constraintWidget.mMatchConstraintDefaultWidth == 0 && obj3 == null) {
                        measure.horizontalBehavior$ar$edu = 2;
                        if (obj2 == null || constraintWidget.mMatchConstraintDefaultHeight != 0) {
                            obj = null;
                        } else {
                            measure.horizontalBehavior$ar$edu = 1;
                            obj = null;
                        }
                    }
                    if (obj2 != null && constraintWidget.hasDanglingDimension(1) && constraintWidget.mMatchConstraintDefaultHeight == 0 && obj4 == null) {
                        measure.verticalBehavior$ar$edu = 2;
                        if (obj == null || constraintWidget.mMatchConstraintDefaultWidth != 0) {
                            obj2 = null;
                        } else {
                            measure.verticalBehavior$ar$edu = 1;
                            obj2 = null;
                        }
                    }
                    if (constraintWidget.isResolvedHorizontally()) {
                        measure.horizontalBehavior$ar$edu = 1;
                        obj = null;
                    }
                    if (constraintWidget.isResolvedVertically()) {
                        measure.verticalBehavior$ar$edu = 1;
                        obj2 = null;
                    }
                    if (obj3 != null) {
                        if (constraintWidget.mResolvedMatchConstraintDefault[0] == 4) {
                            measure.horizontalBehavior$ar$edu = 1;
                        } else if (obj2 == null) {
                            int i;
                            if (measure.verticalBehavior$ar$edu == 1) {
                                i = measure.verticalDimension;
                            } else {
                                measure.horizontalBehavior$ar$edu = 2;
                                measurer.measure(constraintWidget, measure);
                                i = measure.measuredHeight;
                            }
                            measure.horizontalBehavior$ar$edu = 1;
                            measure.horizontalDimension = (int) (constraintWidget.mDimensionRatio * ((float) i));
                        }
                    }
                    if (obj4 != null) {
                        if (constraintWidget.mResolvedMatchConstraintDefault[1] == 4) {
                            measure.verticalBehavior$ar$edu = 1;
                        } else if (obj == null) {
                            int i2;
                            if (measure.horizontalBehavior$ar$edu == 1) {
                                i2 = measure.horizontalDimension;
                            } else {
                                measure.verticalBehavior$ar$edu = 2;
                                measurer.measure(constraintWidget, measure);
                                i2 = measure.measuredWidth;
                            }
                            measure.verticalBehavior$ar$edu = 1;
                            if (constraintWidget.mDimensionRatioSide == -1) {
                                measure.verticalDimension = (int) (((float) i2) / constraintWidget.mDimensionRatio);
                            } else {
                                measure.verticalDimension = (int) (constraintWidget.mDimensionRatio * ((float) i2));
                            }
                        }
                    }
                    measurer.measure(constraintWidget, measure);
                    constraintWidget.setWidth(measure.measuredWidth);
                    constraintWidget.setHeight(measure.measuredHeight);
                    constraintWidget.hasBaseline = measure.measuredHasBaseline;
                    constraintWidget.setBaselineDistance(measure.measuredBaseline);
                    measure.measureStrategy = 0;
                    boolean z = measure.measuredNeedsSolverPass;
                    return;
                }
            }
            measure.measuredWidth = 0;
            measure.measuredHeight = 0;
        }
    }

    private final void resetChains() {
        this.mHorizontalChainsSize = 0;
        this.mVerticalChainsSize = 0;
    }

    public final void invalidateGraph() {
        this.mDependencyGraph.mNeedBuildGraph = true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void layout() {
        /*
        r27 = this;
        r7 = r27;
        r8 = 0;
        r7.f12mX = r8;
        r7.f13mY = r8;
        r7.mWidthMeasuredTooSmall = r8;
        r7.mHeightMeasuredTooSmall = r8;
        r0 = r7.mChildren;
        r9 = r0.size();
        r0 = r27.getWidth();
        r0 = java.lang.Math.max(r8, r0);
        r1 = r27.getHeight();
        r1 = java.lang.Math.max(r8, r1);
        r2 = r7.mListDimensionBehaviors$ar$edu;
        r10 = 1;
        r3 = r2[r10];
        r2 = r2[r8];
        r4 = r7.pass;
        r12 = -1;
        if (r4 != 0) goto L_0x024c;
    L_0x002d:
        r4 = r7.mOptimizationLevel;
        r4 = androidx.constraintlayout.core.widgets.Optimizer.enabled(r4, r10);
        if (r4 == 0) goto L_0x024c;
    L_0x0035:
        r4 = r7.mMeasurer$ar$class_merging;
        r5 = r27.getHorizontalDimensionBehaviour$ar$edu();
        r6 = r27.getVerticalDimensionBehaviour$ar$edu();
        androidx.constraintlayout.core.widgets.analyzer.Direct.hcount = r8;
        androidx.constraintlayout.core.widgets.analyzer.Direct.vcount = r8;
        r27.resetFinalResolution();
        r13 = r7.mChildren;
        r14 = r13.size();
        r15 = 0;
    L_0x004d:
        if (r15 >= r14) goto L_0x005b;
    L_0x004f:
        r16 = r13.get(r15);
        r16 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r16;
        r16.resetFinalResolution();
        r15 = r15 + 1;
        goto L_0x004d;
    L_0x005b:
        r15 = r7.mIsRtl;
        if (r5 != r10) goto L_0x006c;
    L_0x005f:
        r5 = r27.getWidth();
        r7.setFinalHorizontal(r8, r5);
        r5 = 0;
        r16 = 0;
        r17 = 0;
        goto L_0x0078;
    L_0x006c:
        r5 = r7.mLeft;
        r5.setFinalValue(r8);
        r7.f12mX = r8;
        r5 = 0;
        r16 = 0;
        r17 = 0;
    L_0x0078:
        r18 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        if (r5 >= r14) goto L_0x00de;
    L_0x007c:
        r19 = r13.get(r5);
        r11 = r19;
        r11 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r11;
        r8 = r11 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r8 == 0) goto L_0x00c9;
    L_0x0088:
        r11 = (androidx.constraintlayout.core.widgets.Guideline) r11;
        r8 = r11.mOrientation;
        if (r8 != r10) goto L_0x00c8;
    L_0x008e:
        r8 = r11.mRelativeBegin;
        if (r8 == r12) goto L_0x0098;
    L_0x0092:
        r11.setFinalValue(r8);
        r16 = 1;
        goto L_0x00c8;
    L_0x0098:
        r8 = r11.mRelativeEnd;
        if (r8 == r12) goto L_0x00af;
    L_0x009c:
        r8 = r27.isResolvedHorizontally();
        if (r8 == 0) goto L_0x00af;
    L_0x00a2:
        r8 = r27.getWidth();
        r12 = r11.mRelativeEnd;
        r8 = r8 - r12;
        r11.setFinalValue(r8);
        r16 = 1;
        goto L_0x00c8;
    L_0x00af:
        r8 = r27.isResolvedHorizontally();
        if (r8 == 0) goto L_0x00c5;
    L_0x00b5:
        r8 = r11.mRelativePercent;
        r12 = r27.getWidth();
        r12 = (float) r12;
        r8 = r8 * r12;
        r8 = r8 + r18;
        r8 = (int) r8;
        r11.setFinalValue(r8);
        goto L_0x00c6;
    L_0x00c6:
        r16 = 1;
    L_0x00c8:
        goto L_0x00d9;
    L_0x00c9:
        r8 = r11 instanceof androidx.constraintlayout.core.widgets.Barrier;
        if (r8 == 0) goto L_0x00d8;
    L_0x00cd:
        r11 = (androidx.constraintlayout.core.widgets.Barrier) r11;
        r8 = r11.getOrientation();
        if (r8 != 0) goto L_0x00d8;
    L_0x00d5:
        r17 = 1;
        goto L_0x00d9;
    L_0x00d9:
        r5 = r5 + 1;
        r8 = 0;
        r12 = -1;
        goto L_0x0078;
    L_0x00de:
        if (r16 == 0) goto L_0x00fa;
    L_0x00e0:
        r5 = 0;
    L_0x00e1:
        if (r5 >= r14) goto L_0x00fa;
    L_0x00e3:
        r8 = r13.get(r5);
        r8 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r8;
        r11 = r8 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r11 == 0) goto L_0x00f7;
    L_0x00ed:
        r8 = (androidx.constraintlayout.core.widgets.Guideline) r8;
        r11 = r8.mOrientation;
        if (r11 != r10) goto L_0x00f7;
    L_0x00f3:
        r11 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Direct.horizontalSolvingPass$ar$class_merging(r11, r8, r4, r15);
    L_0x00f7:
        r5 = r5 + 1;
        goto L_0x00e1;
        r5 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Direct.horizontalSolvingPass$ar$class_merging(r5, r7, r4, r15);
        if (r17 == 0) goto L_0x011d;
    L_0x0101:
        r5 = 0;
    L_0x0102:
        if (r5 >= r14) goto L_0x011d;
    L_0x0104:
        r8 = r13.get(r5);
        r8 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r8;
        r11 = r8 instanceof androidx.constraintlayout.core.widgets.Barrier;
        if (r11 == 0) goto L_0x011a;
    L_0x010e:
        r8 = (androidx.constraintlayout.core.widgets.Barrier) r8;
        r11 = r8.getOrientation();
        if (r11 != 0) goto L_0x011a;
    L_0x0116:
        r11 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Direct.solveBarrier$ar$class_merging$ar$ds(r8, r4, r11, r15);
    L_0x011a:
        r5 = r5 + 1;
        goto L_0x0102;
    L_0x011d:
        if (r6 != r10) goto L_0x012a;
    L_0x011f:
        r5 = r27.getHeight();
        r6 = 0;
        r7.setFinalVertical(r6, r5);
        r5 = 0;
        r8 = 0;
        goto L_0x0135;
    L_0x012a:
        r6 = 0;
        r5 = r7.mTop;
        r5.setFinalValue(r6);
        r7.f13mY = r6;
        r5 = 0;
        r6 = 0;
        r8 = 0;
    L_0x0135:
        if (r6 >= r14) goto L_0x0192;
    L_0x0137:
        r11 = r13.get(r6);
        r11 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r11;
        r12 = r11 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r12 == 0) goto L_0x0180;
    L_0x0141:
        r11 = (androidx.constraintlayout.core.widgets.Guideline) r11;
        r12 = r11.mOrientation;
        if (r12 != 0) goto L_0x017f;
    L_0x0147:
        r5 = r11.mRelativeBegin;
        r12 = -1;
        if (r5 == r12) goto L_0x0151;
    L_0x014c:
        r11.setFinalValue(r5);
        r5 = 1;
        goto L_0x017f;
    L_0x0151:
        r5 = r11.mRelativeEnd;
        if (r5 == r12) goto L_0x0167;
    L_0x0155:
        r5 = r27.isResolvedVertically();
        if (r5 == 0) goto L_0x0167;
    L_0x015b:
        r5 = r27.getHeight();
        r12 = r11.mRelativeEnd;
        r5 = r5 - r12;
        r11.setFinalValue(r5);
        r5 = 1;
        goto L_0x017f;
    L_0x0167:
        r5 = r27.isResolvedVertically();
        if (r5 == 0) goto L_0x017d;
    L_0x016d:
        r5 = r11.mRelativePercent;
        r12 = r27.getHeight();
        r12 = (float) r12;
        r5 = r5 * r12;
        r5 = r5 + r18;
        r5 = (int) r5;
        r11.setFinalValue(r5);
        goto L_0x017e;
    L_0x017e:
        r5 = 1;
    L_0x017f:
        goto L_0x018f;
    L_0x0180:
        r12 = r11 instanceof androidx.constraintlayout.core.widgets.Barrier;
        if (r12 == 0) goto L_0x018e;
    L_0x0184:
        r11 = (androidx.constraintlayout.core.widgets.Barrier) r11;
        r11 = r11.getOrientation();
        if (r11 != r10) goto L_0x018e;
    L_0x018c:
        r8 = 1;
        goto L_0x018f;
    L_0x018f:
        r6 = r6 + 1;
        goto L_0x0135;
    L_0x0192:
        if (r5 == 0) goto L_0x01ad;
    L_0x0194:
        r5 = 0;
    L_0x0195:
        if (r5 >= r14) goto L_0x01ad;
    L_0x0197:
        r6 = r13.get(r5);
        r6 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r6;
        r11 = r6 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r11 == 0) goto L_0x01aa;
    L_0x01a1:
        r6 = (androidx.constraintlayout.core.widgets.Guideline) r6;
        r11 = r6.mOrientation;
        if (r11 != 0) goto L_0x01aa;
    L_0x01a7:
        androidx.constraintlayout.core.widgets.analyzer.Direct.verticalSolvingPass$ar$class_merging(r10, r6, r4);
    L_0x01aa:
        r5 = r5 + 1;
        goto L_0x0195;
        r5 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Direct.verticalSolvingPass$ar$class_merging(r5, r7, r4);
        if (r8 == 0) goto L_0x01d1;
    L_0x01b4:
        r5 = 0;
    L_0x01b5:
        if (r5 >= r14) goto L_0x01cf;
    L_0x01b7:
        r6 = r13.get(r5);
        r6 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r6;
        r8 = r6 instanceof androidx.constraintlayout.core.widgets.Barrier;
        if (r8 == 0) goto L_0x01cc;
    L_0x01c1:
        r6 = (androidx.constraintlayout.core.widgets.Barrier) r6;
        r8 = r6.getOrientation();
        if (r8 != r10) goto L_0x01cc;
    L_0x01c9:
        androidx.constraintlayout.core.widgets.analyzer.Direct.solveBarrier$ar$class_merging$ar$ds(r6, r4, r10, r15);
    L_0x01cc:
        r5 = r5 + 1;
        goto L_0x01b5;
    L_0x01cf:
        r5 = 0;
        goto L_0x01d2;
    L_0x01d1:
        r5 = 0;
    L_0x01d2:
        if (r5 >= r14) goto L_0x020a;
    L_0x01d4:
        r6 = r13.get(r5);
        r6 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r6;
        r8 = r6.isMeasureRequested();
        if (r8 == 0) goto L_0x0207;
    L_0x01e0:
        r8 = androidx.constraintlayout.core.widgets.analyzer.Direct.canMeasure$ar$ds(r6);
        if (r8 == 0) goto L_0x0207;
    L_0x01e6:
        r8 = androidx.constraintlayout.core.widgets.analyzer.Direct.measure;
        measure$ar$class_merging$ar$ds(r6, r4, r8);
        r8 = r6 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r8 == 0) goto L_0x0200;
    L_0x01ef:
        r8 = r6;
        r8 = (androidx.constraintlayout.core.widgets.Guideline) r8;
        r8 = r8.mOrientation;
        if (r8 != 0) goto L_0x01fb;
    L_0x01f6:
        r8 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Direct.verticalSolvingPass$ar$class_merging(r8, r6, r4);
        goto L_0x0207;
    L_0x01fb:
        r8 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Direct.horizontalSolvingPass$ar$class_merging(r8, r6, r4, r15);
        goto L_0x0207;
    L_0x0200:
        r8 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Direct.horizontalSolvingPass$ar$class_merging(r8, r6, r4, r15);
        androidx.constraintlayout.core.widgets.analyzer.Direct.verticalSolvingPass$ar$class_merging(r8, r6, r4);
    L_0x0207:
        r5 = r5 + 1;
        goto L_0x01d2;
    L_0x020a:
        r4 = 0;
    L_0x020b:
        if (r4 >= r9) goto L_0x024c;
    L_0x020d:
        r5 = r7.mChildren;
        r5 = r5.get(r4);
        r5 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r5;
        r6 = r5.isMeasureRequested();
        if (r6 == 0) goto L_0x0249;
    L_0x021b:
        r6 = r5 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r6 != 0) goto L_0x0249;
    L_0x021f:
        r6 = r5 instanceof androidx.constraintlayout.core.widgets.Barrier;
        if (r6 != 0) goto L_0x0249;
    L_0x0223:
        r6 = r5 instanceof androidx.constraintlayout.core.widgets.VirtualLayout;
        if (r6 != 0) goto L_0x0249;
    L_0x0227:
        r6 = r5.mInVirtualLayout;
        r6 = 0;
        r8 = r5.getDimensionBehaviour$ar$edu(r6);
        r6 = r5.getDimensionBehaviour$ar$edu(r10);
        r11 = 3;
        if (r8 != r11) goto L_0x023f;
    L_0x0235:
        r8 = r5.mMatchConstraintDefaultWidth;
        if (r8 == r10) goto L_0x023f;
    L_0x0239:
        if (r6 != r11) goto L_0x023f;
    L_0x023b:
        r6 = r5.mMatchConstraintDefaultHeight;
        if (r6 != r10) goto L_0x0249;
    L_0x023f:
        r6 = new androidx.constraintlayout.core.widgets.analyzer.BasicMeasure$Measure;
        r6.<init>();
        r8 = r7.mMeasurer$ar$class_merging;
        measure$ar$class_merging$ar$ds(r5, r8, r6);
    L_0x0249:
        r4 = r4 + 1;
        goto L_0x020b;
    L_0x024c:
        r11 = 2;
        if (r9 <= r11) goto L_0x0642;
    L_0x024f:
        if (r2 == r11) goto L_0x025e;
    L_0x0251:
        if (r3 != r11) goto L_0x0255;
    L_0x0253:
        r3 = 2;
        goto L_0x025f;
    L_0x0255:
        r8 = r0;
        r10 = r2;
        r11 = r3;
        r22 = r9;
        r0 = 0;
        r9 = r1;
        goto L_0x064c;
    L_0x025f:
        r4 = r7.mOptimizationLevel;
        r5 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r4 = androidx.constraintlayout.core.widgets.Optimizer.enabled(r4, r5);
        if (r4 == 0) goto L_0x0642;
    L_0x0269:
        r4 = r7.mMeasurer$ar$class_merging;
        r5 = r7.mChildren;
        r6 = r5.size();
        r12 = 0;
    L_0x0272:
        if (r12 >= r6) goto L_0x02aa;
    L_0x0274:
        r13 = r5.get(r12);
        r13 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r13;
        r14 = r27.getHorizontalDimensionBehaviour$ar$edu();
        r15 = r27.getVerticalDimensionBehaviour$ar$edu();
        r11 = r13.getHorizontalDimensionBehaviour$ar$edu();
        r8 = r13.getVerticalDimensionBehaviour$ar$edu();
        r8 = androidx.constraintlayout.core.widgets.analyzer.Grouping.validInGroup$ar$edu(r14, r15, r11, r8);
        if (r8 != 0) goto L_0x0299;
    L_0x0290:
        r8 = r0;
        r10 = r2;
        r11 = r3;
        r22 = r9;
        r0 = 0;
        r9 = r1;
        goto L_0x064c;
    L_0x0299:
        r8 = r13 instanceof androidx.constraintlayout.core.widgets.Flow;
        if (r8 == 0) goto L_0x02a6;
    L_0x029d:
        r8 = r0;
        r10 = r2;
        r11 = r3;
        r22 = r9;
        r0 = 0;
        r9 = r1;
        goto L_0x064c;
    L_0x02a6:
        r12 = r12 + 1;
        r11 = 2;
        goto L_0x0272;
    L_0x02aa:
        r8 = 0;
        r10 = 0;
        r11 = 0;
        r12 = 0;
        r13 = 0;
        r14 = 0;
        r15 = 0;
    L_0x02b1:
        if (r10 >= r6) goto L_0x03a8;
    L_0x02b3:
        r21 = r5.get(r10);
        r22 = r9;
        r9 = r21;
        r9 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r9;
        r21 = r1;
        r1 = r27.getHorizontalDimensionBehaviour$ar$edu();
        r23 = r3;
        r3 = r27.getVerticalDimensionBehaviour$ar$edu();
        r24 = r0;
        r0 = r9.getHorizontalDimensionBehaviour$ar$edu();
        r25 = r2;
        r2 = r9.getVerticalDimensionBehaviour$ar$edu();
        r0 = androidx.constraintlayout.core.widgets.analyzer.Grouping.validInGroup$ar$edu(r1, r3, r0, r2);
        if (r0 != 0) goto L_0x02e0;
    L_0x02db:
        r0 = r7.mMeasure;
        measure$ar$class_merging$ar$ds(r9, r4, r0);
    L_0x02e0:
        r0 = r9 instanceof androidx.constraintlayout.core.widgets.Guideline;
        if (r0 == 0) goto L_0x0305;
    L_0x02e4:
        r1 = r9;
        r1 = (androidx.constraintlayout.core.widgets.Guideline) r1;
        r2 = r1.mOrientation;
        if (r2 != 0) goto L_0x02f5;
    L_0x02eb:
        if (r12 != 0) goto L_0x02f2;
    L_0x02ed:
        r12 = new java.util.ArrayList;
        r12.<init>();
    L_0x02f2:
        r12.add(r1);
    L_0x02f5:
        r2 = r1.mOrientation;
        r3 = 1;
        if (r2 != r3) goto L_0x0305;
    L_0x02fa:
        if (r8 != 0) goto L_0x0301;
    L_0x02fc:
        r8 = new java.util.ArrayList;
        r8.<init>();
    L_0x0301:
        r8.add(r1);
        goto L_0x0306;
    L_0x0306:
        r1 = r9 instanceof androidx.constraintlayout.core.widgets.HelperWidget;
        if (r1 == 0) goto L_0x0357;
    L_0x030a:
        r1 = r9 instanceof androidx.constraintlayout.core.widgets.Barrier;
        if (r1 == 0) goto L_0x033b;
    L_0x030e:
        r1 = r9;
        r1 = (androidx.constraintlayout.core.widgets.Barrier) r1;
        r2 = r1.getOrientation();
        if (r2 != 0) goto L_0x0324;
    L_0x0317:
        if (r11 != 0) goto L_0x031f;
    L_0x0319:
        r11 = new java.util.ArrayList;
        r11.<init>();
        goto L_0x0320;
    L_0x0320:
        r11.add(r1);
        goto L_0x0325;
    L_0x0325:
        r2 = r1.getOrientation();
        r3 = 1;
        if (r2 != r3) goto L_0x0339;
    L_0x032c:
        if (r13 != 0) goto L_0x0334;
    L_0x032e:
        r13 = new java.util.ArrayList;
        r13.<init>();
        goto L_0x0335;
    L_0x0335:
        r13.add(r1);
        goto L_0x033a;
    L_0x033a:
        goto L_0x0358;
    L_0x033b:
        r1 = r9;
        r1 = (androidx.constraintlayout.core.widgets.HelperWidget) r1;
        if (r11 != 0) goto L_0x0346;
    L_0x0340:
        r11 = new java.util.ArrayList;
        r11.<init>();
        goto L_0x0347;
    L_0x0347:
        r11.add(r1);
        if (r13 != 0) goto L_0x0352;
    L_0x034c:
        r13 = new java.util.ArrayList;
        r13.<init>();
        goto L_0x0353;
    L_0x0353:
        r13.add(r1);
        goto L_0x0358;
    L_0x0358:
        r1 = r9.mLeft;
        r1 = r1.mTarget;
        if (r1 != 0) goto L_0x0376;
    L_0x035e:
        r1 = r9.mRight;
        r1 = r1.mTarget;
        if (r1 != 0) goto L_0x0376;
    L_0x0364:
        if (r0 != 0) goto L_0x0376;
    L_0x0366:
        r1 = r9 instanceof androidx.constraintlayout.core.widgets.Barrier;
        if (r1 != 0) goto L_0x0376;
    L_0x036a:
        if (r14 != 0) goto L_0x0372;
    L_0x036c:
        r14 = new java.util.ArrayList;
        r14.<init>();
        goto L_0x0373;
    L_0x0373:
        r14.add(r9);
    L_0x0376:
        r1 = r9.mTop;
        r1 = r1.mTarget;
        if (r1 != 0) goto L_0x039a;
    L_0x037c:
        r1 = r9.mBottom;
        r1 = r1.mTarget;
        if (r1 != 0) goto L_0x039a;
    L_0x0382:
        r1 = r9.mBaseline;
        r1 = r1.mTarget;
        if (r1 != 0) goto L_0x039a;
    L_0x0388:
        if (r0 != 0) goto L_0x039a;
    L_0x038a:
        r0 = r9 instanceof androidx.constraintlayout.core.widgets.Barrier;
        if (r0 != 0) goto L_0x039a;
    L_0x038e:
        if (r15 != 0) goto L_0x0396;
    L_0x0390:
        r15 = new java.util.ArrayList;
        r15.<init>();
        goto L_0x0397;
    L_0x0397:
        r15.add(r9);
    L_0x039a:
        r10 = r10 + 1;
        r1 = r21;
        r9 = r22;
        r3 = r23;
        r0 = r24;
        r2 = r25;
        goto L_0x02b1;
    L_0x03a8:
        r24 = r0;
        r21 = r1;
        r25 = r2;
        r23 = r3;
        r22 = r9;
        r0 = new java.util.ArrayList;
        r0.<init>();
        if (r8 == 0) goto L_0x03ce;
    L_0x03b9:
        r1 = r8.size();
        r2 = 0;
    L_0x03be:
        if (r2 >= r1) goto L_0x03ce;
    L_0x03c0:
        r3 = r8.get(r2);
        r3 = (androidx.constraintlayout.core.widgets.Guideline) r3;
        r4 = 0;
        r9 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r3, r9, r0, r4);
        r2 = r2 + 1;
        goto L_0x03be;
    L_0x03ce:
        if (r11 == 0) goto L_0x03ec;
    L_0x03d0:
        r1 = r11.size();
        r2 = 0;
    L_0x03d5:
        if (r2 >= r1) goto L_0x03ec;
    L_0x03d7:
        r3 = r11.get(r2);
        r3 = (androidx.constraintlayout.core.widgets.HelperWidget) r3;
        r4 = 0;
        r8 = 0;
        r9 = androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r3, r8, r0, r4);
        r3.addDependents(r0, r8, r9);
        r9.cleanup(r0);
        r2 = r2 + 1;
        goto L_0x03d5;
    L_0x03ec:
        r1 = 2;
        r2 = r7.getAnchor$ar$edu(r1);
        r1 = r2.mDependents;
        if (r1 == 0) goto L_0x040d;
    L_0x03f5:
        r1 = r1.iterator();
    L_0x03f9:
        r2 = r1.hasNext();
        if (r2 == 0) goto L_0x040d;
    L_0x03ff:
        r2 = r1.next();
        r2 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r2;
        r2 = r2.mOwner;
        r3 = 0;
        r4 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r2, r4, r0, r3);
        goto L_0x03f9;
    L_0x040d:
        r1 = 4;
        r1 = r7.getAnchor$ar$edu(r1);
        r1 = r1.mDependents;
        if (r1 == 0) goto L_0x042e;
    L_0x0416:
        r1 = r1.iterator();
    L_0x041a:
        r2 = r1.hasNext();
        if (r2 == 0) goto L_0x042e;
    L_0x0420:
        r2 = r1.next();
        r2 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r2;
        r2 = r2.mOwner;
        r3 = 0;
        r4 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r2, r4, r0, r3);
        goto L_0x041a;
    L_0x042e:
        r1 = 7;
        r2 = r7.getAnchor$ar$edu(r1);
        r2 = r2.mDependents;
        if (r2 == 0) goto L_0x044f;
    L_0x0437:
        r2 = r2.iterator();
    L_0x043b:
        r3 = r2.hasNext();
        if (r3 == 0) goto L_0x044f;
    L_0x0441:
        r3 = r2.next();
        r3 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r3;
        r3 = r3.mOwner;
        r4 = 0;
        r8 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r3, r8, r0, r4);
        goto L_0x043b;
    L_0x044f:
        if (r14 == 0) goto L_0x0466;
    L_0x0451:
        r2 = r14.size();
        r3 = 0;
    L_0x0456:
        if (r3 >= r2) goto L_0x0466;
    L_0x0458:
        r4 = r14.get(r3);
        r4 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r4;
        r8 = 0;
        r9 = 0;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r4, r9, r0, r8);
        r3 = r3 + 1;
        goto L_0x0456;
    L_0x0466:
        if (r12 == 0) goto L_0x047d;
    L_0x0468:
        r2 = r12.size();
        r3 = 0;
    L_0x046d:
        if (r3 >= r2) goto L_0x047d;
    L_0x046f:
        r4 = r12.get(r3);
        r4 = (androidx.constraintlayout.core.widgets.Guideline) r4;
        r8 = 0;
        r9 = 1;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r4, r9, r0, r8);
        r3 = r3 + 1;
        goto L_0x046d;
    L_0x047d:
        if (r13 == 0) goto L_0x049b;
    L_0x047f:
        r2 = r13.size();
        r3 = 0;
    L_0x0484:
        if (r3 >= r2) goto L_0x049b;
    L_0x0486:
        r4 = r13.get(r3);
        r4 = (androidx.constraintlayout.core.widgets.HelperWidget) r4;
        r8 = 0;
        r9 = 1;
        r10 = androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r4, r9, r0, r8);
        r4.addDependents(r0, r9, r10);
        r10.cleanup(r0);
        r3 = r3 + 1;
        goto L_0x0484;
    L_0x049b:
        r2 = 3;
        r3 = r7.getAnchor$ar$edu(r2);
        r2 = r3.mDependents;
        if (r2 == 0) goto L_0x04bc;
    L_0x04a4:
        r2 = r2.iterator();
    L_0x04a8:
        r3 = r2.hasNext();
        if (r3 == 0) goto L_0x04bc;
    L_0x04ae:
        r3 = r2.next();
        r3 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r3;
        r3 = r3.mOwner;
        r4 = 0;
        r8 = 1;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r3, r8, r0, r4);
        goto L_0x04a8;
    L_0x04bc:
        r2 = 6;
        r2 = r7.getAnchor$ar$edu(r2);
        r2 = r2.mDependents;
        if (r2 == 0) goto L_0x04dd;
    L_0x04c5:
        r2 = r2.iterator();
    L_0x04c9:
        r3 = r2.hasNext();
        if (r3 == 0) goto L_0x04dd;
    L_0x04cf:
        r3 = r2.next();
        r3 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r3;
        r3 = r3.mOwner;
        r4 = 0;
        r8 = 1;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r3, r8, r0, r4);
        goto L_0x04c9;
    L_0x04dd:
        r2 = 5;
        r2 = r7.getAnchor$ar$edu(r2);
        r2 = r2.mDependents;
        if (r2 == 0) goto L_0x04fe;
    L_0x04e6:
        r2 = r2.iterator();
    L_0x04ea:
        r3 = r2.hasNext();
        if (r3 == 0) goto L_0x04fe;
    L_0x04f0:
        r3 = r2.next();
        r3 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r3;
        r3 = r3.mOwner;
        r4 = 0;
        r8 = 1;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r3, r8, r0, r4);
        goto L_0x04ea;
    L_0x04fe:
        r1 = r7.getAnchor$ar$edu(r1);
        r1 = r1.mDependents;
        if (r1 == 0) goto L_0x051e;
    L_0x0506:
        r1 = r1.iterator();
    L_0x050a:
        r2 = r1.hasNext();
        if (r2 == 0) goto L_0x051e;
    L_0x0510:
        r2 = r1.next();
        r2 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r2;
        r2 = r2.mOwner;
        r3 = 0;
        r4 = 1;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r2, r4, r0, r3);
        goto L_0x050a;
    L_0x051e:
        if (r15 == 0) goto L_0x0537;
    L_0x0520:
        r1 = r15.size();
        r2 = 0;
    L_0x0525:
        if (r2 >= r1) goto L_0x0535;
    L_0x0527:
        r3 = r15.get(r2);
        r3 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r3;
        r4 = 0;
        r8 = 1;
        androidx.constraintlayout.core.widgets.analyzer.Grouping.findDependents(r3, r8, r0, r4);
        r2 = r2 + 1;
        goto L_0x0525;
    L_0x0535:
        r1 = 0;
        goto L_0x0538;
    L_0x0537:
        r1 = 0;
    L_0x0538:
        if (r1 >= r6) goto L_0x056a;
    L_0x053a:
        r2 = r5.get(r1);
        r2 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r2;
        r3 = r2.mListDimensionBehaviors$ar$edu;
        r4 = 0;
        r8 = r3[r4];
        r4 = 3;
        if (r8 != r4) goto L_0x0567;
    L_0x0548:
        r8 = 1;
        r3 = r3[r8];
        if (r3 != r4) goto L_0x0567;
    L_0x054d:
        r3 = r2.horizontalGroup;
        r3 = androidx.constraintlayout.core.widgets.analyzer.Grouping.findGroup(r0, r3);
        r2 = r2.verticalGroup;
        r2 = androidx.constraintlayout.core.widgets.analyzer.Grouping.findGroup(r0, r2);
        if (r3 == 0) goto L_0x0567;
    L_0x055b:
        if (r2 == 0) goto L_0x0567;
    L_0x055d:
        r4 = 0;
        r3.moveTo(r4, r2);
        r4 = 2;
        r2.orientation = r4;
        r0.remove(r3);
    L_0x0567:
        r1 = r1 + 1;
        goto L_0x0538;
    L_0x056a:
        r1 = r0.size();
        r2 = 1;
        if (r1 > r2) goto L_0x057c;
    L_0x0571:
        r9 = r21;
        r11 = r23;
        r8 = r24;
        r10 = r25;
        r0 = 0;
        goto L_0x064c;
    L_0x057c:
        r1 = r27.getHorizontalDimensionBehaviour$ar$edu();
        r2 = 2;
        if (r1 != r2) goto L_0x05b3;
    L_0x0583:
        r1 = r0.size();
        r2 = 0;
        r3 = 0;
        r4 = 0;
    L_0x058a:
        if (r3 >= r1) goto L_0x05a9;
    L_0x058c:
        r5 = r0.get(r3);
        r5 = (androidx.constraintlayout.core.widgets.analyzer.WidgetGroup) r5;
        r6 = r5.orientation;
        r8 = 1;
        if (r6 != r8) goto L_0x0598;
    L_0x0597:
        goto L_0x05a6;
    L_0x0598:
        r6 = r7.mSystem;
        r8 = 0;
        r6 = r5.measureWrap(r6, r8);
        if (r6 > r4) goto L_0x05a2;
    L_0x05a1:
        goto L_0x05a3;
    L_0x05a2:
        r2 = r5;
    L_0x05a3:
        if (r6 <= r4) goto L_0x05a6;
    L_0x05a5:
        r4 = r6;
    L_0x05a6:
        r3 = r3 + 1;
        goto L_0x058a;
    L_0x05a9:
        if (r2 == 0) goto L_0x05b3;
    L_0x05ab:
        r1 = 1;
        r7.setHorizontalDimensionBehaviour$ar$edu(r1);
        r7.setWidth(r4);
        goto L_0x05b4;
    L_0x05b3:
        r2 = 0;
    L_0x05b4:
        r1 = r27.getVerticalDimensionBehaviour$ar$edu();
        r3 = 2;
        if (r1 != r3) goto L_0x05ea;
    L_0x05bb:
        r1 = r0.size();
        r3 = 0;
        r4 = 0;
        r5 = 0;
    L_0x05c2:
        if (r4 >= r1) goto L_0x05e0;
    L_0x05c4:
        r6 = r0.get(r4);
        r6 = (androidx.constraintlayout.core.widgets.analyzer.WidgetGroup) r6;
        r8 = r6.orientation;
        if (r8 != 0) goto L_0x05cf;
    L_0x05ce:
        goto L_0x05dd;
    L_0x05cf:
        r8 = r7.mSystem;
        r9 = 1;
        r8 = r6.measureWrap(r8, r9);
        if (r8 > r5) goto L_0x05d9;
    L_0x05d8:
        goto L_0x05da;
    L_0x05d9:
        r3 = r6;
    L_0x05da:
        if (r8 <= r5) goto L_0x05dd;
    L_0x05dc:
        r5 = r8;
    L_0x05dd:
        r4 = r4 + 1;
        goto L_0x05c2;
    L_0x05e0:
        if (r3 == 0) goto L_0x05ea;
    L_0x05e2:
        r1 = 1;
        r7.setVerticalDimensionBehaviour$ar$edu(r1);
        r7.setHeight(r5);
        goto L_0x05eb;
    L_0x05ea:
        r3 = 0;
    L_0x05eb:
        if (r2 != 0) goto L_0x05fa;
    L_0x05ed:
        if (r3 == 0) goto L_0x05f0;
    L_0x05ef:
        goto L_0x05fa;
    L_0x05f0:
        r9 = r21;
        r11 = r23;
        r8 = r24;
        r10 = r25;
        goto L_0x064b;
    L_0x05fa:
        r0 = r25;
        r1 = 2;
        if (r0 != r1) goto L_0x0618;
    L_0x05ff:
        r0 = r27.getWidth();
        r1 = r24;
        if (r1 >= r0) goto L_0x0612;
    L_0x0607:
        if (r1 <= 0) goto L_0x0612;
    L_0x0609:
        r7.setWidth(r1);
        r2 = 1;
        r7.mWidthMeasuredTooSmall = r2;
        r0 = r1;
        r2 = 2;
        goto L_0x061c;
    L_0x0612:
        r0 = r27.getWidth();
        r2 = 2;
        goto L_0x061c;
    L_0x0618:
        r1 = r24;
        r2 = r0;
        r0 = r1;
    L_0x061c:
        r3 = r23;
        r1 = 2;
        if (r3 != r1) goto L_0x0639;
    L_0x0621:
        r1 = r27.getHeight();
        r4 = r21;
        if (r4 >= r1) goto L_0x0633;
    L_0x0629:
        if (r4 <= 0) goto L_0x0633;
    L_0x062b:
        r7.setHeight(r4);
        r1 = 1;
        r7.mHeightMeasuredTooSmall = r1;
        r1 = r4;
        goto L_0x0637;
    L_0x0633:
        r1 = r27.getHeight();
    L_0x0637:
        r3 = 2;
        goto L_0x063c;
    L_0x0639:
        r4 = r21;
        r1 = r4;
    L_0x063c:
        r8 = r0;
        r9 = r1;
        r10 = r2;
        r11 = r3;
        r0 = 1;
        goto L_0x064c;
    L_0x0642:
        r4 = r1;
        r22 = r9;
        r1 = r0;
        r0 = r2;
        r10 = r0;
        r8 = r1;
        r11 = r3;
        r9 = r4;
    L_0x064b:
        r0 = 0;
    L_0x064c:
        r12 = 64;
        r1 = r7.optimizeFor(r12);
        if (r1 != 0) goto L_0x0660;
    L_0x0654:
        r1 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r1 = r7.optimizeFor(r1);
        if (r1 == 0) goto L_0x065e;
    L_0x065c:
        r1 = 1;
        goto L_0x0661;
    L_0x065e:
        r1 = 0;
        goto L_0x0661;
    L_0x0660:
        r1 = 1;
    L_0x0661:
        r2 = r7.mSystem;
        r3 = 0;
        r2.graphOptimizer = r3;
        r2.newgraphOptimizer = r3;
        r3 = r7.mOptimizationLevel;
        if (r3 == 0) goto L_0x0671;
    L_0x066c:
        if (r1 == 0) goto L_0x0671;
    L_0x066e:
        r1 = 1;
        r2.newgraphOptimizer = r1;
    L_0x0671:
        r13 = r7.mChildren;
        r1 = r27.getHorizontalDimensionBehaviour$ar$edu();
        r2 = 2;
        if (r1 == r2) goto L_0x0684;
    L_0x067a:
        r1 = r27.getVerticalDimensionBehaviour$ar$edu();
        if (r1 != r2) goto L_0x0682;
    L_0x0680:
        r14 = 1;
        goto L_0x0685;
    L_0x0682:
        r14 = 0;
        goto L_0x0685;
    L_0x0684:
        r14 = 1;
    L_0x0685:
        r27.resetChains();
        r1 = 0;
    L_0x0689:
        r15 = r22;
        if (r1 >= r15) goto L_0x06a3;
    L_0x068d:
        r2 = r7.mChildren;
        r2 = r2.get(r1);
        r2 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r2;
        r3 = r2 instanceof androidx.constraintlayout.core.widgets.WidgetContainer;
        if (r3 == 0) goto L_0x069e;
    L_0x0699:
        r2 = (androidx.constraintlayout.core.widgets.WidgetContainer) r2;
        r2.layout();
    L_0x069e:
        r1 = r1 + 1;
        r22 = r15;
        goto L_0x0689;
    L_0x06a3:
        r21 = r0;
        r0 = 1;
        r1 = 0;
    L_0x06a7:
        if (r0 == 0) goto L_0x0ab3;
    L_0x06a9:
        r2 = 1;
        r6 = r1 + 1;
        r0 = r7.mSystem;	 Catch:{ Exception -> 0x0958 }
        r0.reset();	 Catch:{ Exception -> 0x0958 }
        r27.resetChains();	 Catch:{ Exception -> 0x0958 }
        r0 = r7.mSystem;	 Catch:{ Exception -> 0x0958 }
        r7.createObjectVariables(r0);	 Catch:{ Exception -> 0x0958 }
        r0 = 0;
    L_0x06ba:
        if (r0 >= r15) goto L_0x06cc;
    L_0x06bc:
        r1 = r7.mChildren;	 Catch:{ Exception -> 0x0958 }
        r1 = r1.get(r0);	 Catch:{ Exception -> 0x0958 }
        r1 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r1;	 Catch:{ Exception -> 0x0958 }
        r2 = r7.mSystem;	 Catch:{ Exception -> 0x0958 }
        r1.createObjectVariables(r2);	 Catch:{ Exception -> 0x0958 }
        r0 = r0 + 1;
        goto L_0x06ba;
    L_0x06cc:
        r0 = r7.mSystem;	 Catch:{ Exception -> 0x0958 }
        r5 = r7.optimizeFor(r12);	 Catch:{ Exception -> 0x0958 }
        r7.addToSolver(r0, r5);	 Catch:{ Exception -> 0x0958 }
        r1 = r7.mChildren;	 Catch:{ Exception -> 0x0958 }
        r1 = r1.size();	 Catch:{ Exception -> 0x0958 }
        r2 = 0;
        r3 = 0;
    L_0x06dd:
        if (r2 >= r1) goto L_0x06fb;
    L_0x06df:
        r4 = r7.mChildren;	 Catch:{ Exception -> 0x0958 }
        r4 = r4.get(r2);	 Catch:{ Exception -> 0x0958 }
        r4 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r4;	 Catch:{ Exception -> 0x0958 }
        r12 = 0;
        r4.setInBarrier(r12, r12);	 Catch:{ Exception -> 0x0958 }
        r23 = r6;
        r6 = 1;
        r4.setInBarrier(r6, r12);	 Catch:{ Exception -> 0x094d }
        r4 = r4 instanceof androidx.constraintlayout.core.widgets.Barrier;	 Catch:{ Exception -> 0x094d }
        r3 = r3 | r4;
        r2 = r2 + 1;
        r6 = r23;
        r12 = 64;
        goto L_0x06dd;
    L_0x06fb:
        r23 = r6;
        if (r3 == 0) goto L_0x074f;
    L_0x06ff:
        r2 = 0;
    L_0x0700:
        if (r2 >= r1) goto L_0x074f;
    L_0x0702:
        r3 = r7.mChildren;	 Catch:{ Exception -> 0x094d }
        r3 = r3.get(r2);	 Catch:{ Exception -> 0x094d }
        r3 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r3;	 Catch:{ Exception -> 0x094d }
        r4 = r3 instanceof androidx.constraintlayout.core.widgets.Barrier;	 Catch:{ Exception -> 0x094d }
        if (r4 == 0) goto L_0x074c;
    L_0x070e:
        r3 = (androidx.constraintlayout.core.widgets.Barrier) r3;	 Catch:{ Exception -> 0x094d }
        r4 = 0;
    L_0x0711:
        r6 = r3.mWidgetsCount;	 Catch:{ Exception -> 0x094d }
        if (r4 >= r6) goto L_0x074c;
    L_0x0715:
        r6 = r3.mWidgets;	 Catch:{ Exception -> 0x094d }
        r6 = r6[r4];	 Catch:{ Exception -> 0x094d }
        r12 = r3.mAllowsGoneWidget;	 Catch:{ Exception -> 0x094d }
        if (r12 != 0) goto L_0x0726;
    L_0x071d:
        r12 = r6.allowedInBarrier();	 Catch:{ Exception -> 0x094d }
        if (r12 != 0) goto L_0x0726;
    L_0x0723:
        r24 = r3;
        goto L_0x0747;
    L_0x0726:
        r12 = r3.mBarrierType;	 Catch:{ Exception -> 0x094d }
        if (r12 == 0) goto L_0x073f;
    L_0x072a:
        r24 = r3;
        r3 = 1;
        if (r12 != r3) goto L_0x0732;
    L_0x072f:
        r3 = 3;
        r12 = 1;
        goto L_0x0743;
    L_0x0732:
        r3 = 2;
        if (r12 == r3) goto L_0x0739;
    L_0x0735:
        r3 = 3;
        if (r12 != r3) goto L_0x0747;
    L_0x0738:
        goto L_0x073a;
    L_0x0739:
        r3 = 3;
    L_0x073a:
        r12 = 1;
        r6.setInBarrier(r12, r12);	 Catch:{ Exception -> 0x094d }
        goto L_0x0747;
    L_0x073f:
        r24 = r3;
        r3 = 3;
        r12 = 1;
    L_0x0743:
        r3 = 0;
        r6.setInBarrier(r3, r12);	 Catch:{ Exception -> 0x094d }
    L_0x0747:
        r4 = r4 + 1;
        r3 = r24;
        goto L_0x0711;
    L_0x074c:
        r2 = r2 + 1;
        goto L_0x0700;
    L_0x074f:
        r2 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r2.clear();	 Catch:{ Exception -> 0x094d }
        r2 = 0;
    L_0x0755:
        if (r2 < r1) goto L_0x091b;
    L_0x0757:
        r2 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r2 = r2.size();	 Catch:{ Exception -> 0x094d }
        if (r2 <= 0) goto L_0x07c1;
    L_0x075f:
        r2 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r2 = r2.size();	 Catch:{ Exception -> 0x094d }
        r3 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r3 = r3.iterator();	 Catch:{ Exception -> 0x094d }
    L_0x076b:
        r4 = r3.hasNext();	 Catch:{ Exception -> 0x094d }
        if (r4 == 0) goto L_0x079d;
    L_0x0771:
        r4 = r3.next();	 Catch:{ Exception -> 0x094d }
        r4 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r4;	 Catch:{ Exception -> 0x094d }
        r4 = (androidx.constraintlayout.core.widgets.VirtualLayout) r4;	 Catch:{ Exception -> 0x094d }
        r6 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r12 = 0;
    L_0x077c:
        r24 = r3;
        r3 = r4.mWidgetsCount;	 Catch:{ Exception -> 0x094d }
        if (r12 >= r3) goto L_0x079a;
    L_0x0782:
        r3 = r4.mWidgets;	 Catch:{ Exception -> 0x094d }
        r3 = r3[r12];	 Catch:{ Exception -> 0x094d }
        r3 = r6.contains(r3);	 Catch:{ Exception -> 0x094d }
        if (r3 == 0) goto L_0x0795;
    L_0x078c:
        r4.addToSolver(r0, r5);	 Catch:{ Exception -> 0x094d }
        r3 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r3.remove(r4);	 Catch:{ Exception -> 0x094d }
        goto L_0x079d;
    L_0x0795:
        r12 = r12 + 1;
        r3 = r24;
        goto L_0x077c;
    L_0x079a:
        r3 = r24;
        goto L_0x076b;
    L_0x079d:
        r3 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r3 = r3.size();	 Catch:{ Exception -> 0x094d }
        if (r2 != r3) goto L_0x0757;
    L_0x07a5:
        r2 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r2 = r2.iterator();	 Catch:{ Exception -> 0x094d }
    L_0x07ab:
        r3 = r2.hasNext();	 Catch:{ Exception -> 0x094d }
        if (r3 == 0) goto L_0x07bb;
    L_0x07b1:
        r3 = r2.next();	 Catch:{ Exception -> 0x094d }
        r3 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r3;	 Catch:{ Exception -> 0x094d }
        r3.addToSolver(r0, r5);	 Catch:{ Exception -> 0x094d }
        goto L_0x07ab;
    L_0x07bb:
        r2 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094d }
        r2.clear();	 Catch:{ Exception -> 0x094d }
        goto L_0x0757;
    L_0x07c1:
        r2 = androidx.constraintlayout.core.LinearSystem.USE_DEPENDENCY_ORDERING;	 Catch:{ Exception -> 0x094d }
        if (r2 == 0) goto L_0x0825;
    L_0x07c5:
        r12 = new java.util.HashSet;	 Catch:{ Exception -> 0x0819 }
        r12.<init>();	 Catch:{ Exception -> 0x0819 }
        r2 = 0;
    L_0x07cb:
        if (r2 >= r1) goto L_0x07e1;
    L_0x07cd:
        r3 = r7.mChildren;	 Catch:{ Exception -> 0x094d }
        r3 = r3.get(r2);	 Catch:{ Exception -> 0x094d }
        r3 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r3;	 Catch:{ Exception -> 0x094d }
        r4 = r3.addFirst();	 Catch:{ Exception -> 0x094d }
        if (r4 != 0) goto L_0x07de;
    L_0x07db:
        r12.add(r3);	 Catch:{ Exception -> 0x094d }
    L_0x07de:
        r2 = r2 + 1;
        goto L_0x07cb;
    L_0x07e1:
        r1 = r27.getHorizontalDimensionBehaviour$ar$edu();	 Catch:{ Exception -> 0x0819 }
        r2 = 2;
        if (r1 != r2) goto L_0x07ea;
    L_0x07e8:
        r6 = 0;
        goto L_0x07eb;
    L_0x07ea:
        r6 = 1;
    L_0x07eb:
        r24 = 0;
        r1 = r27;
        r2 = r27;
        r20 = 3;
        r3 = r0;
        r4 = r12;
        r25 = r13;
        r13 = r5;
        r5 = r6;
        r26 = r9;
        r9 = r23;
        r6 = r24;
        r1.addChildrenToSolverByDependency(r2, r3, r4, r5, r6);	 Catch:{ Exception -> 0x0918 }
        r1 = r12.iterator();	 Catch:{ Exception -> 0x0918 }
    L_0x0806:
        r2 = r1.hasNext();	 Catch:{ Exception -> 0x0918 }
        if (r2 == 0) goto L_0x0876;
    L_0x080c:
        r2 = r1.next();	 Catch:{ Exception -> 0x0918 }
        r2 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r2;	 Catch:{ Exception -> 0x0918 }
        androidx.constraintlayout.core.widgets.Optimizer.checkMatchParent(r7, r0, r2);	 Catch:{ Exception -> 0x0918 }
        r2.addToSolver(r0, r13);	 Catch:{ Exception -> 0x0918 }
        goto L_0x0806;
    L_0x0819:
        r0 = move-exception;
        r26 = r9;
        r25 = r13;
        r9 = r23;
        r20 = 3;
    L_0x0822:
        r3 = 0;
        goto L_0x0961;
    L_0x0825:
        r26 = r9;
        r25 = r13;
        r9 = r23;
        r20 = 3;
        r13 = r5;
        r2 = 0;
    L_0x082f:
        if (r2 >= r1) goto L_0x0876;
    L_0x0831:
        r3 = r7.mChildren;	 Catch:{ Exception -> 0x0918 }
        r3 = r3.get(r2);	 Catch:{ Exception -> 0x0918 }
        r3 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r3;	 Catch:{ Exception -> 0x0918 }
        r4 = r3 instanceof androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;	 Catch:{ Exception -> 0x0918 }
        if (r4 == 0) goto L_0x0867;
    L_0x083d:
        r4 = r3.mListDimensionBehaviors$ar$edu;	 Catch:{ Exception -> 0x0918 }
        r5 = 0;
        r6 = r4[r5];	 Catch:{ Exception -> 0x0918 }
        r5 = 1;
        r4 = r4[r5];	 Catch:{ Exception -> 0x0918 }
        r12 = 2;
        if (r6 != r12) goto L_0x084d;
    L_0x0848:
        r3.setHorizontalDimensionBehaviour$ar$edu(r5);	 Catch:{ Exception -> 0x0918 }
        r6 = 2;
        goto L_0x084e;
    L_0x084e:
        r5 = 2;
        if (r4 != r5) goto L_0x0857;
    L_0x0851:
        r4 = 1;
        r3.setVerticalDimensionBehaviour$ar$edu(r4);	 Catch:{ Exception -> 0x0918 }
        r4 = 2;
        goto L_0x0858;
    L_0x0858:
        r3.addToSolver(r0, r13);	 Catch:{ Exception -> 0x0918 }
        r5 = 2;
        if (r6 != r5) goto L_0x0861;
    L_0x085e:
        r3.setHorizontalDimensionBehaviour$ar$edu(r5);	 Catch:{ Exception -> 0x0918 }
    L_0x0861:
        if (r4 != r5) goto L_0x0873;
    L_0x0863:
        r3.setVerticalDimensionBehaviour$ar$edu(r5);	 Catch:{ Exception -> 0x0918 }
        goto L_0x0873;
    L_0x0867:
        androidx.constraintlayout.core.widgets.Optimizer.checkMatchParent(r7, r0, r3);	 Catch:{ Exception -> 0x0918 }
        r4 = r3.addFirst();	 Catch:{ Exception -> 0x0918 }
        if (r4 != 0) goto L_0x0873;
    L_0x0870:
        r3.addToSolver(r0, r13);	 Catch:{ Exception -> 0x0918 }
    L_0x0873:
        r2 = r2 + 1;
        goto L_0x082f;
    L_0x0876:
        r1 = r7.mHorizontalChainsSize;	 Catch:{ Exception -> 0x0918 }
        if (r1 <= 0) goto L_0x0884;
    L_0x087a:
        r1 = 0;
        r2 = 0;
        androidx.constraintlayout.core.widgets.Chain.applyChainConstraints(r7, r0, r1, r2);	 Catch:{ Exception -> 0x0880 }
        goto L_0x0884;
    L_0x0880:
        r0 = move-exception;
        r3 = r1;
        goto L_0x0961;
    L_0x0884:
        r1 = r7.mVerticalChainsSize;	 Catch:{ Exception -> 0x0918 }
        if (r1 <= 0) goto L_0x088d;
    L_0x0888:
        r1 = 0;
        r2 = 1;
        androidx.constraintlayout.core.widgets.Chain.applyChainConstraints(r7, r0, r1, r2);	 Catch:{ Exception -> 0x0880 }
    L_0x088d:
        r0 = r7.verticalWrapMin;	 Catch:{ Exception -> 0x0918 }
        if (r0 == 0) goto L_0x08ad;
    L_0x0891:
        r0 = r0.get();	 Catch:{ Exception -> 0x0918 }
        if (r0 == 0) goto L_0x08ad;
    L_0x0897:
        r0 = r7.verticalWrapMin;	 Catch:{ Exception -> 0x0918 }
        r0 = r0.get();	 Catch:{ Exception -> 0x0918 }
        r0 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r0;	 Catch:{ Exception -> 0x0918 }
        r1 = r7.mSystem;	 Catch:{ Exception -> 0x0918 }
        r2 = r7.mTop;	 Catch:{ Exception -> 0x0918 }
        r1 = r1.createObjectVariable(r2);	 Catch:{ Exception -> 0x0918 }
        r7.addMinWrap(r0, r1);	 Catch:{ Exception -> 0x0918 }
        r1 = 0;
        r7.verticalWrapMin = r1;	 Catch:{ Exception -> 0x0880 }
    L_0x08ad:
        r0 = r7.verticalWrapMax;	 Catch:{ Exception -> 0x0918 }
        if (r0 == 0) goto L_0x08cd;
    L_0x08b1:
        r0 = r0.get();	 Catch:{ Exception -> 0x0918 }
        if (r0 == 0) goto L_0x08cd;
    L_0x08b7:
        r0 = r7.verticalWrapMax;	 Catch:{ Exception -> 0x0918 }
        r0 = r0.get();	 Catch:{ Exception -> 0x0918 }
        r0 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r0;	 Catch:{ Exception -> 0x0918 }
        r1 = r7.mSystem;	 Catch:{ Exception -> 0x0918 }
        r2 = r7.mBottom;	 Catch:{ Exception -> 0x0918 }
        r1 = r1.createObjectVariable(r2);	 Catch:{ Exception -> 0x0918 }
        r7.addMaxWrap(r0, r1);	 Catch:{ Exception -> 0x0918 }
        r1 = 0;
        r7.verticalWrapMax = r1;	 Catch:{ Exception -> 0x0880 }
    L_0x08cd:
        r0 = r7.horizontalWrapMin;	 Catch:{ Exception -> 0x0918 }
        if (r0 == 0) goto L_0x08ed;
    L_0x08d1:
        r0 = r0.get();	 Catch:{ Exception -> 0x0918 }
        if (r0 == 0) goto L_0x08ed;
    L_0x08d7:
        r0 = r7.horizontalWrapMin;	 Catch:{ Exception -> 0x0918 }
        r0 = r0.get();	 Catch:{ Exception -> 0x0918 }
        r0 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r0;	 Catch:{ Exception -> 0x0918 }
        r1 = r7.mSystem;	 Catch:{ Exception -> 0x0918 }
        r2 = r7.mLeft;	 Catch:{ Exception -> 0x0918 }
        r1 = r1.createObjectVariable(r2);	 Catch:{ Exception -> 0x0918 }
        r7.addMinWrap(r0, r1);	 Catch:{ Exception -> 0x0918 }
        r1 = 0;
        r7.horizontalWrapMin = r1;	 Catch:{ Exception -> 0x0880 }
    L_0x08ed:
        r0 = r7.horizontalWrapMax;	 Catch:{ Exception -> 0x0918 }
        if (r0 == 0) goto L_0x0910;
    L_0x08f1:
        r0 = r0.get();	 Catch:{ Exception -> 0x0918 }
        if (r0 == 0) goto L_0x090e;
    L_0x08f7:
        r0 = r7.horizontalWrapMax;	 Catch:{ Exception -> 0x0918 }
        r0 = r0.get();	 Catch:{ Exception -> 0x0918 }
        r0 = (androidx.constraintlayout.core.widgets.ConstraintAnchor) r0;	 Catch:{ Exception -> 0x0918 }
        r1 = r7.mSystem;	 Catch:{ Exception -> 0x0918 }
        r2 = r7.mRight;	 Catch:{ Exception -> 0x0918 }
        r1 = r1.createObjectVariable(r2);	 Catch:{ Exception -> 0x0918 }
        r7.addMaxWrap(r0, r1);	 Catch:{ Exception -> 0x0918 }
        r3 = 0;
        r7.horizontalWrapMax = r3;	 Catch:{ Exception -> 0x094b }
        goto L_0x0911;
    L_0x090e:
        r3 = 0;
        goto L_0x0911;
    L_0x0910:
        r3 = 0;
    L_0x0911:
        r0 = r7.mSystem;	 Catch:{ Exception -> 0x094b }
        r0.minimize();	 Catch:{ Exception -> 0x094b }
        goto L_0x0988;
    L_0x0918:
        r0 = move-exception;
        goto L_0x0822;
    L_0x091b:
        r26 = r9;
        r25 = r13;
        r9 = r23;
        r3 = 0;
        r20 = 3;
        r13 = r5;
        r4 = r7.mChildren;	 Catch:{ Exception -> 0x094b }
        r4 = r4.get(r2);	 Catch:{ Exception -> 0x094b }
        r4 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r4;	 Catch:{ Exception -> 0x094b }
        r5 = r4.addFirst();	 Catch:{ Exception -> 0x094b }
        if (r5 == 0) goto L_0x0940;
    L_0x0933:
        r5 = r4 instanceof androidx.constraintlayout.core.widgets.VirtualLayout;	 Catch:{ Exception -> 0x094b }
        if (r5 == 0) goto L_0x093d;
    L_0x0937:
        r5 = r7.widgetsToAdd;	 Catch:{ Exception -> 0x094b }
        r5.add(r4);	 Catch:{ Exception -> 0x094b }
        goto L_0x0940;
    L_0x093d:
        r4.addToSolver(r0, r13);	 Catch:{ Exception -> 0x094b }
    L_0x0940:
        r2 = r2 + 1;
        r23 = r9;
        r5 = r13;
        r13 = r25;
        r9 = r26;
        goto L_0x0755;
    L_0x094b:
        r0 = move-exception;
        goto L_0x0961;
    L_0x094d:
        r0 = move-exception;
        r26 = r9;
        r25 = r13;
        r9 = r23;
        r3 = 0;
        r20 = 3;
        goto L_0x0961;
    L_0x0958:
        r0 = move-exception;
        r26 = r9;
        r25 = r13;
        r3 = 0;
        r20 = 3;
        r9 = r6;
    L_0x0961:
        r0.printStackTrace();
        r1 = java.lang.System.out;
        r0 = java.lang.String.valueOf(r0);
        r2 = java.lang.String.valueOf(r0);
        r2 = r2.length();
        r4 = new java.lang.StringBuilder;
        r2 = r2 + 12;
        r4.<init>(r2);
        r2 = "EXCEPTION : ";
        r4.append(r2);
        r4.append(r0);
        r0 = r4.toString();
        r1.println(r0);
    L_0x0988:
        r0 = androidx.constraintlayout.core.widgets.Optimizer.flags;
        r1 = 2;
        r2 = 0;
        r0[r1] = r2;
        r1 = 64;
        r0 = r7.optimizeFor(r1);
        r7.updateFromSolver$ar$ds(r0);
        r2 = r7.mChildren;
        r2 = r2.size();
        r4 = 0;
        r5 = 0;
    L_0x099f:
        if (r4 >= r2) goto L_0x09bd;
    L_0x09a1:
        r6 = r7.mChildren;
        r6 = r6.get(r4);
        r6 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r6;
        r6.updateFromSolver$ar$ds(r0);
        r12 = r6.mWidthOverride;
        r13 = -1;
        if (r12 != r13) goto L_0x09b8;
    L_0x09b1:
        r6 = r6.mHeightOverride;
        if (r6 == r13) goto L_0x09b6;
    L_0x09b5:
        goto L_0x09b8;
    L_0x09b6:
        r6 = 0;
        goto L_0x09b9;
    L_0x09b8:
        r6 = 1;
    L_0x09b9:
        r5 = r5 | r6;
        r4 = r4 + 1;
        goto L_0x099f;
    L_0x09bd:
        r13 = -1;
        if (r14 == 0) goto L_0x0a28;
    L_0x09c0:
        r0 = 8;
        if (r9 >= r0) goto L_0x0a28;
    L_0x09c4:
        r0 = androidx.constraintlayout.core.widgets.Optimizer.flags;
        r2 = 2;
        r0 = r0[r2];
        if (r0 == 0) goto L_0x0a28;
    L_0x09cb:
        r0 = 0;
        r2 = 0;
        r4 = 0;
    L_0x09ce:
        if (r0 >= r15) goto L_0x09f2;
    L_0x09d0:
        r6 = r7.mChildren;
        r6 = r6.get(r0);
        r6 = (androidx.constraintlayout.core.widgets.ConstraintWidget) r6;
        r12 = r6.f12mX;
        r17 = r6.getWidth();
        r12 = r12 + r17;
        r2 = java.lang.Math.max(r2, r12);
        r12 = r6.f13mY;
        r6 = r6.getHeight();
        r12 = r12 + r6;
        r4 = java.lang.Math.max(r4, r12);
        r0 = r0 + 1;
        goto L_0x09ce;
    L_0x09f2:
        r0 = r7.mMinWidth;
        r0 = java.lang.Math.max(r0, r2);
        r2 = r7.mMinHeight;
        r2 = java.lang.Math.max(r2, r4);
        r4 = 2;
        if (r10 != r4) goto L_0x0a13;
    L_0x0a01:
        r6 = r27.getWidth();
        if (r6 >= r0) goto L_0x0a13;
    L_0x0a07:
        r7.setWidth(r0);
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r5 = 0;
        r0[r5] = r4;
        r5 = 1;
        r21 = 1;
        goto L_0x0a14;
    L_0x0a14:
        if (r11 != r4) goto L_0x0a28;
    L_0x0a16:
        r0 = r27.getHeight();
        if (r0 >= r2) goto L_0x0a28;
    L_0x0a1c:
        r7.setHeight(r2);
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r2 = 1;
        r0[r2] = r4;
        r5 = 1;
        r21 = 1;
        goto L_0x0a29;
    L_0x0a29:
        r0 = r7.mMinWidth;
        r2 = r27.getWidth();
        r0 = java.lang.Math.max(r0, r2);
        r2 = r27.getWidth();
        if (r0 <= r2) goto L_0x0a46;
    L_0x0a39:
        r7.setWidth(r0);
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r2 = 0;
        r4 = 1;
        r0[r2] = r4;
        r5 = 1;
        r21 = 1;
        goto L_0x0a47;
    L_0x0a47:
        r0 = r7.mMinHeight;
        r2 = r27.getHeight();
        r0 = java.lang.Math.max(r0, r2);
        r2 = r27.getHeight();
        if (r0 <= r2) goto L_0x0a63;
    L_0x0a57:
        r7.setHeight(r0);
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r2 = 1;
        r0[r2] = r2;
        r5 = 1;
        r21 = 1;
        goto L_0x0a64;
    L_0x0a64:
        if (r21 != 0) goto L_0x0aa7;
    L_0x0a66:
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r2 = 0;
        r0 = r0[r2];
        r4 = 2;
        if (r0 != r4) goto L_0x0a84;
    L_0x0a6e:
        if (r8 <= 0) goto L_0x0a84;
    L_0x0a70:
        r0 = r27.getWidth();
        if (r0 <= r8) goto L_0x0a84;
    L_0x0a76:
        r4 = 1;
        r7.mWidthMeasuredTooSmall = r4;
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r0[r2] = r4;
        r7.setWidth(r8);
        r5 = 1;
        r21 = 1;
        goto L_0x0a85;
    L_0x0a85:
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r2 = 1;
        r0 = r0[r2];
        r4 = 2;
        if (r0 != r4) goto L_0x0aa4;
    L_0x0a8d:
        if (r26 <= 0) goto L_0x0aa4;
    L_0x0a8f:
        r0 = r27.getHeight();
        r6 = r26;
        if (r0 <= r6) goto L_0x0aaa;
    L_0x0a97:
        r7.mHeightMeasuredTooSmall = r2;
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r0[r2] = r2;
        r7.setHeight(r6);
        r0 = 1;
        r21 = 1;
        goto L_0x0aab;
    L_0x0aa4:
        r6 = r26;
        goto L_0x0aaa;
    L_0x0aa7:
        r6 = r26;
        r4 = 2;
    L_0x0aaa:
        r0 = r5;
    L_0x0aab:
        r1 = r9;
        r13 = r25;
        r12 = 64;
        r9 = r6;
        goto L_0x06a7;
    L_0x0ab3:
        r25 = r13;
        r1 = r25;
        r7.mChildren = r1;
        if (r21 == 0) goto L_0x0ac3;
    L_0x0abb:
        r0 = r7.mListDimensionBehaviors$ar$edu;
        r1 = 0;
        r0[r1] = r10;
        r1 = 1;
        r0[r1] = r11;
    L_0x0ac3:
        r0 = r7.mSystem;
        r0 = r0.mCache;
        r7.resetSolverVariables(r0);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.core.widgets.ConstraintWidgetContainer.layout():void");
    }

    public final boolean optimizeFor(int i) {
        return (this.mOptimizationLevel & i) == i;
    }

    public final void reset() {
        this.mSystem.reset();
        this.mPaddingLeft = 0;
        this.mPaddingTop = 0;
        super.reset();
    }

    public final void setOptimizationLevel(int i) {
        this.mOptimizationLevel = i;
        LinearSystem.USE_DEPENDENCY_ORDERING = optimizeFor(512);
    }

    public final void updateFromRuns(boolean z, boolean z2) {
        super.updateFromRuns(z, z2);
        int size = this.mChildren.size();
        for (int i = 0; i < size; i++) {
            ((ConstraintWidget) this.mChildren.get(i)).updateFromRuns(z, z2);
        }
    }

    public final boolean directMeasureWithOrientation(boolean z, int i) {
        int i2;
        Object obj;
        DependencyGraph dependencyGraph = this.mDependencyGraph;
        boolean z2 = false;
        int dimensionBehaviour$ar$edu = dependencyGraph.container.getDimensionBehaviour$ar$edu(0);
        int dimensionBehaviour$ar$edu2 = dependencyGraph.container.getDimensionBehaviour$ar$edu(1);
        int x = dependencyGraph.container.getX();
        int y = dependencyGraph.container.getY();
        if (z) {
            Object obj2;
            if (dimensionBehaviour$ar$edu != 2) {
                if (dimensionBehaviour$ar$edu2 == 2) {
                    dimensionBehaviour$ar$edu2 = 2;
                }
            }
            List list = dependencyGraph.mRuns;
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                WidgetRun widgetRun = (WidgetRun) list.get(i3);
                if (widgetRun.orientation == i && !widgetRun.supportsWrapComputation()) {
                    obj2 = null;
                    break;
                }
            }
            obj2 = 1;
            ConstraintWidget constraintWidget;
            if (i == 0) {
                if (obj2 != null && dimensionBehaviour$ar$edu == 2) {
                    dependencyGraph.container.setHorizontalDimensionBehaviour$ar$edu(1);
                    constraintWidget = dependencyGraph.container;
                    constraintWidget.setWidth(dependencyGraph.computeWrap(constraintWidget, 0));
                    constraintWidget = dependencyGraph.container;
                    constraintWidget.horizontalRun.dimension.resolve(constraintWidget.getWidth());
                }
            } else if (obj2 != null && dimensionBehaviour$ar$edu2 == 2) {
                dependencyGraph.container.setVerticalDimensionBehaviour$ar$edu(1);
                constraintWidget = dependencyGraph.container;
                constraintWidget.setHeight(dependencyGraph.computeWrap(constraintWidget, 1));
                constraintWidget = dependencyGraph.container;
                constraintWidget.verticalRun.dimension.resolve(constraintWidget.getHeight());
            }
        }
        int width;
        if (i == 0) {
            ConstraintWidget constraintWidget2 = dependencyGraph.container;
            i2 = constraintWidget2.mListDimensionBehaviors$ar$edu[0];
            if (i2 != 1) {
                if (i2 != 4) {
                    obj = null;
                }
            }
            width = constraintWidget2.getWidth() + x;
            dependencyGraph.container.horizontalRun.end.resolve(width);
            dependencyGraph.container.horizontalRun.dimension.resolve(width - x);
            obj = 1;
        } else {
            ConstraintWidget constraintWidget3 = dependencyGraph.container;
            i2 = constraintWidget3.mListDimensionBehaviors$ar$edu[1];
            if (i2 != 1) {
                if (i2 != 4) {
                    obj = null;
                }
            }
            width = constraintWidget3.getHeight() + y;
            dependencyGraph.container.verticalRun.end.resolve(width);
            dependencyGraph.container.verticalRun.dimension.resolve(width - y);
            obj = 1;
        }
        dependencyGraph.measureWidgets();
        List list2 = dependencyGraph.mRuns;
        y = list2.size();
        for (i2 = 0; i2 < y; i2++) {
            WidgetRun widgetRun2 = (WidgetRun) list2.get(i2);
            if (widgetRun2.orientation == i) {
                if (widgetRun2.widget != dependencyGraph.container || widgetRun2.resolved) {
                    widgetRun2.applyToWidget();
                }
            }
        }
        list2 = dependencyGraph.mRuns;
        y = list2.size();
        for (i2 = 0; i2 < y; i2++) {
            widgetRun2 = (WidgetRun) list2.get(i2);
            if (widgetRun2.orientation == i) {
                if (obj != null || widgetRun2.widget != dependencyGraph.container) {
                    if (widgetRun2.start.resolved) {
                        if (widgetRun2.end.resolved) {
                            if (!((widgetRun2 instanceof ChainRun) || widgetRun2.dimension.resolved)) {
                                break;
                            }
                        }
                        break;
                    }
                    break;
                }
            }
        }
        z2 = true;
        dependencyGraph.container.setHorizontalDimensionBehaviour$ar$edu(dimensionBehaviour$ar$edu);
        dependencyGraph.container.setVerticalDimensionBehaviour$ar$edu(dimensionBehaviour$ar$edu2);
        return z2;
    }

    final void addChain(ConstraintWidget constraintWidget, int i) {
        ChainHead[] chainHeadArr;
        int length;
        if (i == 0) {
            i = this.mHorizontalChainsSize;
            chainHeadArr = this.mHorizontalChainsArray;
            length = chainHeadArr.length;
            if (i + 1 >= length) {
                this.mHorizontalChainsArray = (ChainHead[]) Arrays.copyOf(chainHeadArr, length + length);
            }
            this.mHorizontalChainsArray[this.mHorizontalChainsSize] = new ChainHead(constraintWidget, 0, this.mIsRtl);
            this.mHorizontalChainsSize++;
            return;
        }
        i = this.mVerticalChainsSize;
        chainHeadArr = this.mVerticalChainsArray;
        length = chainHeadArr.length;
        if (i + 1 >= length) {
            this.mVerticalChainsArray = (ChainHead[]) Arrays.copyOf(chainHeadArr, length + length);
        }
        this.mVerticalChainsArray[this.mVerticalChainsSize] = new ChainHead(constraintWidget, 1, this.mIsRtl);
        this.mVerticalChainsSize++;
    }
}
