package androidx.constraintlayout.core;

/* compiled from: PG */
final class Pools$SimplePool {
    public final Object[] mPool = new Object[256];
    public int mPoolSize;

    public final Object acquire() {
        int i = this.mPoolSize;
        if (i <= 0) {
            return null;
        }
        i--;
        Object[] objArr = this.mPool;
        Object obj = objArr[i];
        objArr[i] = null;
        this.mPoolSize = i;
        return obj;
    }

    public final void release$ar$ds(Object obj) {
        int i = this.mPoolSize;
        if (i < 256) {
            this.mPool[i] = obj;
            this.mPoolSize = i + 1;
        }
    }
}
