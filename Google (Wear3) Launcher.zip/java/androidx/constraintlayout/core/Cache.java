package androidx.constraintlayout.core;

/* compiled from: PG */
public final class Cache {
    final Pools$SimplePool arrayRowPool$ar$class_merging = new Pools$SimplePool();
    SolverVariable[] mIndexedVariables = new SolverVariable[32];
    final Pools$SimplePool solverVariablePool$ar$class_merging = new Pools$SimplePool();

    public Cache() {
        Pools$SimplePool pools$SimplePool = new Pools$SimplePool();
    }
}
