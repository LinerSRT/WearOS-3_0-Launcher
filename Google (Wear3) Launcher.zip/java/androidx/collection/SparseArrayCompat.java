package androidx.collection;

/* compiled from: PG */
public final class SparseArrayCompat implements Cloneable {
    private static final Object DELETED = new Object();
    public int[] mKeys;
    public int mSize;
    public Object[] mValues;

    public final SparseArrayCompat clone() {
        try {
            SparseArrayCompat sparseArrayCompat = (SparseArrayCompat) super.clone();
            sparseArrayCompat.mKeys = (int[]) this.mKeys.clone();
            sparseArrayCompat.mValues = (Object[]) this.mValues.clone();
            return sparseArrayCompat;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public final int keyAt(int i) {
        return this.mKeys[i];
    }

    public final void put(int i, Object obj) {
        int binarySearch = ContainerHelpers.binarySearch(this.mKeys, this.mSize, i);
        if (binarySearch >= 0) {
            this.mValues[binarySearch] = obj;
            return;
        }
        binarySearch ^= -1;
        int i2 = this.mSize;
        if (binarySearch < i2) {
            Object[] objArr = this.mValues;
            if (objArr[binarySearch] == DELETED) {
                this.mKeys[binarySearch] = i;
                objArr[binarySearch] = obj;
                return;
            }
        }
        if (i2 >= this.mKeys.length) {
            i2 = ContainerHelpers.idealIntArraySize(i2 + 1);
            Object obj2 = new int[i2];
            Object obj3 = new Object[i2];
            Object obj4 = this.mKeys;
            System.arraycopy(obj4, 0, obj2, 0, obj4.length);
            obj4 = this.mValues;
            System.arraycopy(obj4, 0, obj3, 0, obj4.length);
            this.mKeys = obj2;
            this.mValues = obj3;
        }
        i2 = this.mSize - binarySearch;
        if (i2 != 0) {
            obj2 = this.mKeys;
            int i3 = binarySearch + 1;
            System.arraycopy(obj2, binarySearch, obj2, i3, i2);
            obj3 = this.mValues;
            System.arraycopy(obj3, binarySearch, obj3, i3, this.mSize - binarySearch);
        }
        this.mKeys[binarySearch] = i;
        this.mValues[binarySearch] = obj;
        this.mSize++;
    }

    public final String toString() {
        int i = this.mSize;
        if (i <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(i * 28);
        stringBuilder.append('{');
        for (i = 0; i < this.mSize; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(keyAt(i));
            stringBuilder.append('=');
            SparseArrayCompat valueAt = valueAt(i);
            if (valueAt != this) {
                stringBuilder.append(valueAt);
            } else {
                stringBuilder.append("(this Map)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public final Object valueAt(int i) {
        return this.mValues[i];
    }

    public SparseArrayCompat() {
        int idealIntArraySize = ContainerHelpers.idealIntArraySize(10);
        this.mKeys = new int[idealIntArraySize];
        this.mValues = new Object[idealIntArraySize];
    }

    public final Object get(int i) {
        i = ContainerHelpers.binarySearch(this.mKeys, this.mSize, i);
        if (i >= 0) {
            Object[] objArr = this.mValues;
            if (objArr[i] != DELETED) {
                return objArr[i];
            }
        }
        return null;
    }
}
