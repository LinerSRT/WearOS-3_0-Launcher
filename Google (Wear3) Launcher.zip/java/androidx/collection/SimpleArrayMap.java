package androidx.collection;

import java.util.ConcurrentModificationException;
import java.util.Map;

/* compiled from: PG */
public class SimpleArrayMap {
    static Object[] mBaseCache;
    static int mBaseCacheSize;
    static Object[] mTwiceBaseCache;
    static int mTwiceBaseCacheSize;
    Object[] mArray;
    int[] mHashes;
    public int mSize;

    public SimpleArrayMap() {
        this.mHashes = ContainerHelpers.EMPTY_INTS;
        this.mArray = ContainerHelpers.EMPTY_OBJECTS;
        this.mSize = 0;
    }

    private static int binarySearchHashes(int[] iArr, int i, int i2) {
        try {
            return ContainerHelpers.binarySearch(iArr, i, i2);
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new ConcurrentModificationException();
        }
    }

    public static void freeArrays(int[] iArr, Object[] objArr, int i) {
        Class cls = SimpleArrayMap.class;
        int length = iArr.length;
        if (length == 8) {
            synchronized (cls) {
                if (mTwiceBaseCacheSize < 10) {
                    objArr[0] = mTwiceBaseCache;
                    objArr[1] = iArr;
                    for (i = (i + i) - 1; i >= 2; i--) {
                        objArr[i] = null;
                    }
                    mTwiceBaseCache = objArr;
                    mTwiceBaseCacheSize++;
                }
            }
        } else if (length == 4) {
            synchronized (cls) {
                if (mBaseCacheSize < 10) {
                    objArr[0] = mBaseCache;
                    objArr[1] = iArr;
                    for (i = (i + i) - 1; i >= 2; i--) {
                        objArr[i] = null;
                    }
                    mBaseCache = objArr;
                    mBaseCacheSize++;
                }
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void allocArrays(int r7) {
        /*
        r6 = this;
        r0 = androidx.collection.SimpleArrayMap.class;
        r1 = 4;
        r2 = 0;
        r3 = 1;
        r4 = 0;
        r5 = 8;
        if (r7 != r5) goto L_0x002e;
    L_0x000a:
        monitor-enter(r0);
        r1 = mTwiceBaseCache;	 Catch:{ all -> 0x002b }
        if (r1 == 0) goto L_0x0029;
    L_0x000f:
        r6.mArray = r1;	 Catch:{ all -> 0x002b }
        r7 = r1[r4];	 Catch:{ all -> 0x002b }
        r7 = (java.lang.Object[]) r7;	 Catch:{ all -> 0x002b }
        mTwiceBaseCache = r7;	 Catch:{ all -> 0x002b }
        r7 = r1[r3];	 Catch:{ all -> 0x002b }
        r7 = (int[]) r7;	 Catch:{ all -> 0x002b }
        r6.mHashes = r7;	 Catch:{ all -> 0x002b }
        r1[r3] = r2;	 Catch:{ all -> 0x002b }
        r1[r4] = r2;	 Catch:{ all -> 0x002b }
        r7 = mTwiceBaseCacheSize;	 Catch:{ all -> 0x002b }
        r7 = r7 + -1;
        mTwiceBaseCacheSize = r7;	 Catch:{ all -> 0x002b }
        monitor-exit(r0);	 Catch:{ all -> 0x002b }
        return;
    L_0x0029:
        monitor-exit(r0);	 Catch:{ all -> 0x002b }
        goto L_0x0055;
    L_0x002b:
        r7 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x002b }
        throw r7;
    L_0x002e:
        if (r7 != r1) goto L_0x0055;
    L_0x0030:
        monitor-enter(r0);
        r7 = mBaseCache;	 Catch:{ all -> 0x0052 }
        if (r7 == 0) goto L_0x004f;
    L_0x0035:
        r6.mArray = r7;	 Catch:{ all -> 0x0052 }
        r1 = r7[r4];	 Catch:{ all -> 0x0052 }
        r1 = (java.lang.Object[]) r1;	 Catch:{ all -> 0x0052 }
        mBaseCache = r1;	 Catch:{ all -> 0x0052 }
        r1 = r7[r3];	 Catch:{ all -> 0x0052 }
        r1 = (int[]) r1;	 Catch:{ all -> 0x0052 }
        r6.mHashes = r1;	 Catch:{ all -> 0x0052 }
        r7[r3] = r2;	 Catch:{ all -> 0x0052 }
        r7[r4] = r2;	 Catch:{ all -> 0x0052 }
        r7 = mBaseCacheSize;	 Catch:{ all -> 0x0052 }
        r7 = r7 + -1;
        mBaseCacheSize = r7;	 Catch:{ all -> 0x0052 }
        monitor-exit(r0);	 Catch:{ all -> 0x0052 }
        return;
    L_0x004f:
        monitor-exit(r0);	 Catch:{ all -> 0x0052 }
        r7 = 4;
        goto L_0x0055;
    L_0x0052:
        r7 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x0052 }
        throw r7;
    L_0x0055:
        r0 = new int[r7];
        r6.mHashes = r0;
        r7 = r7 + r7;
        r7 = new java.lang.Object[r7];
        r6.mArray = r7;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.collection.SimpleArrayMap.allocArrays(int):void");
    }

    public final void clear() {
        int i = this.mSize;
        if (i > 0) {
            int[] iArr = this.mHashes;
            Object[] objArr = this.mArray;
            this.mHashes = ContainerHelpers.EMPTY_INTS;
            this.mArray = ContainerHelpers.EMPTY_OBJECTS;
            this.mSize = 0;
            freeArrays(iArr, objArr, i);
        }
        if (this.mSize > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public final boolean containsKey(Object obj) {
        return indexOfKey(obj) >= 0;
    }

    public final boolean containsValue(Object obj) {
        return indexOfValue(obj) >= 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        try {
            int i;
            Object keyAt;
            Object valueAt;
            Object obj2;
            if (obj instanceof SimpleArrayMap) {
                SimpleArrayMap simpleArrayMap = (SimpleArrayMap) obj;
                if (this.mSize != simpleArrayMap.mSize) {
                    return false;
                }
                for (i = 0; i < this.mSize; i++) {
                    keyAt = keyAt(i);
                    valueAt = valueAt(i);
                    obj2 = simpleArrayMap.get(keyAt);
                    if (valueAt == null) {
                        if (obj2 != null || !simpleArrayMap.containsKey(keyAt)) {
                            return false;
                        }
                    } else if (!valueAt.equals(obj2)) {
                        return false;
                    }
                }
                return true;
            }
            if (obj instanceof Map) {
                Map map = (Map) obj;
                if (this.mSize != map.size()) {
                    return false;
                }
                for (i = 0; i < this.mSize; i++) {
                    keyAt = keyAt(i);
                    valueAt = valueAt(i);
                    obj2 = map.get(keyAt);
                    if (valueAt == null) {
                        if (obj2 != null || !map.containsKey(keyAt)) {
                            return false;
                        }
                    } else if (!valueAt.equals(obj2)) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        } catch (NullPointerException e) {
        } catch (ClassCastException e2) {
        }
    }

    public final Object get(Object obj) {
        return getOrDefault(obj, null);
    }

    public final Object getOrDefault(Object obj, Object obj2) {
        int indexOfKey = indexOfKey(obj);
        return indexOfKey >= 0 ? this.mArray[(indexOfKey + indexOfKey) + 1] : obj2;
    }

    public final int hashCode() {
        int[] iArr = this.mHashes;
        Object[] objArr = this.mArray;
        int i = this.mSize;
        int i2 = 1;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            Object obj = objArr[i2];
            i4 += (obj == null ? 0 : obj.hashCode()) ^ iArr[i3];
            i3++;
            i2 += 2;
        }
        return i4;
    }

    final int indexOf(Object obj, int i) {
        int i2 = this.mSize;
        if (i2 == 0) {
            return -1;
        }
        int binarySearchHashes = binarySearchHashes(this.mHashes, i2, i);
        if (binarySearchHashes < 0 || obj.equals(this.mArray[binarySearchHashes + binarySearchHashes])) {
            return binarySearchHashes;
        }
        int i3 = binarySearchHashes + 1;
        while (i3 < i2 && this.mHashes[i3] == i) {
            if (obj.equals(this.mArray[i3 + i3])) {
                return i3;
            }
            i3++;
        }
        binarySearchHashes--;
        while (binarySearchHashes >= 0 && this.mHashes[binarySearchHashes] == i) {
            if (obj.equals(this.mArray[binarySearchHashes + binarySearchHashes])) {
                return binarySearchHashes;
            }
            binarySearchHashes--;
        }
        return i3 ^ -1;
    }

    public final int indexOfKey(Object obj) {
        return obj == null ? indexOfNull() : indexOf(obj, obj.hashCode());
    }

    final int indexOfNull() {
        int i = this.mSize;
        if (i == 0) {
            return -1;
        }
        int binarySearchHashes = binarySearchHashes(this.mHashes, i, 0);
        if (binarySearchHashes < 0 || this.mArray[binarySearchHashes + binarySearchHashes] == null) {
            return binarySearchHashes;
        }
        int i2 = binarySearchHashes + 1;
        while (i2 < i && this.mHashes[i2] == 0) {
            if (this.mArray[i2 + i2] == null) {
                return i2;
            }
            i2++;
        }
        binarySearchHashes--;
        while (binarySearchHashes >= 0 && this.mHashes[binarySearchHashes] == 0) {
            if (this.mArray[binarySearchHashes + binarySearchHashes] == null) {
                return binarySearchHashes;
            }
            binarySearchHashes--;
        }
        return i2 ^ -1;
    }

    public final boolean isEmpty() {
        return this.mSize <= 0;
    }

    public final Object keyAt(int i) {
        return this.mArray[i + i];
    }

    public final Object put(Object obj, Object obj2) {
        int indexOfNull;
        int i;
        int i2 = this.mSize;
        if (obj == null) {
            indexOfNull = indexOfNull();
            i = 0;
        } else {
            indexOfNull = obj.hashCode();
            i = indexOfNull;
            indexOfNull = indexOf(obj, indexOfNull);
        }
        if (indexOfNull >= 0) {
            indexOfNull = (indexOfNull + indexOfNull) + 1;
            Object[] objArr = this.mArray;
            Object obj3 = objArr[indexOfNull];
            objArr[indexOfNull] = obj2;
            return obj3;
        }
        indexOfNull ^= -1;
        Object obj4 = this.mHashes;
        int length = obj4.length;
        if (i2 >= length) {
            int i3 = 4;
            if (i2 >= 8) {
                i3 = (i2 >> 1) + i2;
            } else if (i2 >= 4) {
                i3 = 8;
            }
            Object obj5 = this.mArray;
            allocArrays(i3);
            if (i2 == this.mSize) {
                Object obj6 = this.mHashes;
                if (obj6.length > 0) {
                    System.arraycopy(obj4, 0, obj6, 0, length);
                    System.arraycopy(obj5, 0, this.mArray, 0, obj5.length);
                }
                freeArrays(obj4, obj5, i2);
            } else {
                throw new ConcurrentModificationException();
            }
        }
        if (indexOfNull < i2) {
            Object obj7 = this.mHashes;
            int i4 = indexOfNull + 1;
            System.arraycopy(obj7, indexOfNull, obj7, i4, i2 - indexOfNull);
            obj7 = this.mArray;
            length = this.mSize - indexOfNull;
            System.arraycopy(obj7, indexOfNull + indexOfNull, obj7, i4 + i4, length + length);
        }
        int i5 = this.mSize;
        if (i2 == i5) {
            int[] iArr = this.mHashes;
            if (indexOfNull < iArr.length) {
                iArr[indexOfNull] = i;
                Object[] objArr2 = this.mArray;
                indexOfNull += indexOfNull;
                objArr2[indexOfNull] = obj;
                objArr2[indexOfNull + 1] = obj2;
                this.mSize = i5 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public final Object putIfAbsent(Object obj, Object obj2) {
        Object obj3 = get(obj);
        return obj3 == null ? put(obj, obj2) : obj3;
    }

    public final Object remove(Object obj) {
        int indexOfKey = indexOfKey(obj);
        return indexOfKey >= 0 ? removeAt(indexOfKey) : null;
    }

    public final Object removeAt(int i) {
        Object obj = this.mArray;
        int i2 = i + i;
        Object obj2 = obj[i2 + 1];
        int i3 = this.mSize;
        if (i3 <= 1) {
            clear();
        } else {
            int i4 = i3 - 1;
            Object obj3 = this.mHashes;
            int length = obj3.length;
            int i5 = 8;
            if (length <= 8 || i3 >= length / 3) {
                int i6;
                if (i < i4) {
                    i6 = i + 1;
                    length = i4 - i;
                    System.arraycopy(obj3, i6, obj3, i, length);
                    Object obj4 = this.mArray;
                    System.arraycopy(obj4, i6 + i6, obj4, i2, length + length);
                }
                Object[] objArr = this.mArray;
                i6 = i4 + i4;
                objArr[i6] = null;
                objArr[i6 + 1] = null;
            } else {
                if (i3 > 8) {
                    i5 = i3 + (i3 >> 1);
                }
                allocArrays(i5);
                if (i3 == this.mSize) {
                    if (i > 0) {
                        System.arraycopy(obj3, 0, this.mHashes, 0, i);
                        System.arraycopy(obj, 0, this.mArray, 0, i2);
                    }
                    if (i < i4) {
                        int i7 = i + 1;
                        length = i4 - i;
                        System.arraycopy(obj3, i7, this.mHashes, i, length);
                        System.arraycopy(obj, i7 + i7, this.mArray, i2, length + length);
                    }
                } else {
                    throw new ConcurrentModificationException();
                }
            }
            if (i3 == this.mSize) {
                this.mSize = i4;
            } else {
                throw new ConcurrentModificationException();
            }
        }
        return obj2;
    }

    public final Object replace(Object obj, Object obj2) {
        int indexOfKey = indexOfKey(obj);
        return indexOfKey >= 0 ? setValueAt(indexOfKey, obj2) : null;
    }

    public final Object setValueAt(int i, Object obj) {
        i = (i + i) + 1;
        Object[] objArr = this.mArray;
        Object obj2 = objArr[i];
        objArr[i] = obj;
        return obj2;
    }

    public final int size() {
        return this.mSize;
    }

    public final String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.mSize * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.mSize; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            SimpleArrayMap keyAt = keyAt(i);
            String str = "(this Map)";
            if (keyAt != this) {
                stringBuilder.append(keyAt);
            } else {
                stringBuilder.append(str);
            }
            stringBuilder.append('=');
            keyAt = valueAt(i);
            if (keyAt != this) {
                stringBuilder.append(keyAt);
            } else {
                stringBuilder.append(str);
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public final Object valueAt(int i) {
        return this.mArray[(i + i) + 1];
    }

    public SimpleArrayMap(int i) {
        if (i == 0) {
            this.mHashes = ContainerHelpers.EMPTY_INTS;
            this.mArray = ContainerHelpers.EMPTY_OBJECTS;
        } else {
            allocArrays(i);
        }
        this.mSize = 0;
    }

    final int indexOfValue(Object obj) {
        int i = this.mSize;
        i += i;
        Object[] objArr = this.mArray;
        if (obj == null) {
            for (int i2 = 1; i2 < i; i2 += 2) {
                if (objArr[i2] == null) {
                    return i2 >> 1;
                }
            }
        } else {
            for (int i3 = 1; i3 < i; i3 += 2) {
                if (obj.equals(objArr[i3])) {
                    return i3 >> 1;
                }
            }
        }
        return -1;
    }

    public final boolean remove(Object obj, Object obj2) {
        int indexOfKey = indexOfKey(obj);
        if (indexOfKey >= 0) {
            Object valueAt = valueAt(indexOfKey);
            if (obj2 == valueAt || (obj2 != null && obj2.equals(valueAt))) {
                removeAt(indexOfKey);
                return true;
            }
        }
        return false;
    }

    public final boolean replace(Object obj, Object obj2, Object obj3) {
        int indexOfKey = indexOfKey(obj);
        if (indexOfKey >= 0) {
            Object valueAt = valueAt(indexOfKey);
            if (valueAt == obj2 || (obj2 != null && obj2.equals(valueAt))) {
                setValueAt(indexOfKey, obj3);
                return true;
            }
        }
        return false;
    }
}
