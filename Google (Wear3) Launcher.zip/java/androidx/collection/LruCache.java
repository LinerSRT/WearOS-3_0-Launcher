package androidx.collection;

import java.util.LinkedHashMap;
import java.util.Locale;

/* compiled from: PG */
public class LruCache {
    private int evictionCount;
    private int hitCount;
    public final LinkedHashMap map;
    private int maxSize;
    private int missCount;
    private int putCount;
    public int size;

    public LruCache(int i) {
        if (i > 0) {
            this.maxSize = i;
            this.map = new LinkedHashMap(0, 0.75f, true);
            return;
        }
        throw new IllegalArgumentException("maxSize <= 0");
    }

    public final Object get(Object obj) {
        if (obj != null) {
            synchronized (this) {
                obj = this.map.get(obj);
                if (obj != null) {
                    this.hitCount++;
                    return obj;
                }
                this.missCount++;
                return null;
            }
        }
        throw new NullPointerException("key == null");
    }

    public final synchronized int maxSize() {
        return this.maxSize;
    }

    public final Object put(Object obj, Object obj2) {
        if (obj == null || obj2 == null) {
            throw new NullPointerException("key == null || value == null");
        }
        synchronized (this) {
            this.putCount++;
            this.size += safeSizeOf(obj, obj2);
            obj2 = this.map.put(obj, obj2);
            if (obj2 != null) {
                this.size -= safeSizeOf(obj, obj2);
            }
        }
        trimToSize(this.maxSize);
        return obj2;
    }

    public final int safeSizeOf(Object obj, Object obj2) {
        int sizeOf$ar$ds = sizeOf$ar$ds(obj2);
        if (sizeOf$ar$ds >= 0) {
            return sizeOf$ar$ds;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Negative size: ");
        stringBuilder.append(obj);
        stringBuilder.append("=");
        stringBuilder.append(obj2);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final synchronized int size() {
        return this.size;
    }

    protected int sizeOf$ar$ds(Object obj) {
        return 1;
    }

    public final synchronized String toString() {
        int i;
        i = this.hitCount;
        int i2 = this.missCount + i;
        if (i2 != 0) {
            i = (i * 100) / i2;
        } else {
            i = 0;
        }
        return String.format(Locale.US, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", new Object[]{Integer.valueOf(this.maxSize), Integer.valueOf(this.hitCount), Integer.valueOf(this.missCount), Integer.valueOf(i)});
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void trimToSize(int r4) {
        /*
        r3 = this;
    L_0x0000:
        monitor-enter(r3);
        r0 = r3.size;	 Catch:{ all -> 0x006d }
        if (r0 < 0) goto L_0x004e;
    L_0x0005:
        r0 = r3.map;	 Catch:{ all -> 0x006d }
        r0 = r0.isEmpty();	 Catch:{ all -> 0x006d }
        if (r0 == 0) goto L_0x0011;
    L_0x000d:
        r0 = r3.size;	 Catch:{ all -> 0x006d }
        if (r0 != 0) goto L_0x004e;
    L_0x0011:
        r0 = r3.size;	 Catch:{ all -> 0x006d }
        if (r0 <= r4) goto L_0x004c;
    L_0x0015:
        r0 = r3.map;	 Catch:{ all -> 0x006d }
        r0 = r0.isEmpty();	 Catch:{ all -> 0x006d }
        if (r0 == 0) goto L_0x001e;
    L_0x001d:
        goto L_0x004c;
    L_0x001e:
        r0 = r3.map;	 Catch:{ all -> 0x006d }
        r0 = r0.entrySet();	 Catch:{ all -> 0x006d }
        r0 = r0.iterator();	 Catch:{ all -> 0x006d }
        r0 = r0.next();	 Catch:{ all -> 0x006d }
        r0 = (java.util.Map.Entry) r0;	 Catch:{ all -> 0x006d }
        r1 = r0.getKey();	 Catch:{ all -> 0x006d }
        r0 = r0.getValue();	 Catch:{ all -> 0x006d }
        r2 = r3.map;	 Catch:{ all -> 0x006d }
        r2.remove(r1);	 Catch:{ all -> 0x006d }
        r2 = r3.size;	 Catch:{ all -> 0x006d }
        r0 = r3.safeSizeOf(r1, r0);	 Catch:{ all -> 0x006d }
        r2 = r2 - r0;
        r3.size = r2;	 Catch:{ all -> 0x006d }
        r0 = r3.evictionCount;	 Catch:{ all -> 0x006d }
        r0 = r0 + 1;
        r3.evictionCount = r0;	 Catch:{ all -> 0x006d }
        monitor-exit(r3);	 Catch:{ all -> 0x006d }
        goto L_0x0000;
    L_0x004c:
        monitor-exit(r3);	 Catch:{ all -> 0x006d }
        return;
    L_0x004e:
        r4 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x006d }
        r0 = new java.lang.StringBuilder;	 Catch:{ all -> 0x006d }
        r0.<init>();	 Catch:{ all -> 0x006d }
        r1 = r3.getClass();	 Catch:{ all -> 0x006d }
        r1 = r1.getName();	 Catch:{ all -> 0x006d }
        r0.append(r1);	 Catch:{ all -> 0x006d }
        r1 = ".sizeOf() is reporting inconsistent results!";
        r0.append(r1);	 Catch:{ all -> 0x006d }
        r0 = r0.toString();	 Catch:{ all -> 0x006d }
        r4.<init>(r0);	 Catch:{ all -> 0x006d }
        throw r4;	 Catch:{ all -> 0x006d }
    L_0x006d:
        r4 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x006d }
        goto L_0x0071;
    L_0x0070:
        throw r4;
    L_0x0071:
        goto L_0x0070;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.collection.LruCache.trimToSize(int):void");
    }
}
