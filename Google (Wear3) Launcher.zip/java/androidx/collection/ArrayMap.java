package androidx.collection;

import java.lang.reflect.Array;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;
import p020j$.util.Iterator.-CC;
import p020j$.util.function.BiConsumer;
import p020j$.util.function.BiFunction;
import p020j$.util.function.Consumer;
import p020j$.util.function.Function;

/* compiled from: PG */
public final class ArrayMap extends SimpleArrayMap implements Map, p020j$.util.Map {
    EntrySet mEntrySet;
    KeySet mKeySet;
    ValueCollection mValues;

    /* compiled from: PG */
    final class EntrySet extends AbstractSet {
        public final Iterator iterator() {
            return new MapIterator();
        }

        public final int size() {
            return ArrayMap.this.mSize;
        }
    }

    /* compiled from: PG */
    final class KeyIterator extends IndexBasedArrayIterator {
        public KeyIterator() {
            super(ArrayMap.this.mSize);
        }

        protected final Object elementAt(int i) {
            return ArrayMap.this.keyAt(i);
        }

        protected final void removeAt(int i) {
            ArrayMap.this.removeAt(i);
        }
    }

    /* compiled from: PG */
    final class KeySet implements Set {
        public final boolean add(Object obj) {
            throw new UnsupportedOperationException();
        }

        public final boolean addAll(Collection collection) {
            throw new UnsupportedOperationException();
        }

        public final void clear() {
            ArrayMap.this.clear();
        }

        public final boolean contains(Object obj) {
            return ArrayMap.this.containsKey(obj);
        }

        public final int hashCode() {
            int i = 0;
            for (int i2 = ArrayMap.this.mSize - 1; i2 >= 0; i2--) {
                Object keyAt = ArrayMap.this.keyAt(i2);
                i += keyAt == null ? 0 : keyAt.hashCode();
            }
            return i;
        }

        public final boolean isEmpty() {
            return ArrayMap.this.isEmpty();
        }

        public final Iterator iterator() {
            return new KeyIterator();
        }

        public final boolean remove(Object obj) {
            int indexOfKey = ArrayMap.this.indexOfKey(obj);
            if (indexOfKey < 0) {
                return false;
            }
            ArrayMap.this.removeAt(indexOfKey);
            return true;
        }

        public final boolean retainAll(Collection collection) {
            return ArrayMap.this.retainAll(collection);
        }

        public final int size() {
            return ArrayMap.this.mSize;
        }

        public final Object[] toArray() {
            int i = ArrayMap.this.mSize;
            Object[] objArr = new Object[i];
            for (int i2 = 0; i2 < i; i2++) {
                objArr[i2] = ArrayMap.this.keyAt(i2);
            }
            return objArr;
        }

        public final boolean containsAll(Collection collection) {
            SimpleArrayMap simpleArrayMap = ArrayMap.this;
            for (Object containsKey : collection) {
                if (!simpleArrayMap.containsKey(containsKey)) {
                    return false;
                }
            }
            return true;
        }

        public final boolean equals(Object obj) {
            boolean z = true;
            if (this != obj) {
                if (obj instanceof Set) {
                    Set set = (Set) obj;
                    try {
                        if (size() == set.size()) {
                            if (containsAll(set)) {
                                return true;
                            }
                        }
                    } catch (NullPointerException e) {
                    } catch (ClassCastException e2) {
                    }
                }
                z = false;
            }
            return z;
        }

        public final boolean removeAll(Collection collection) {
            SimpleArrayMap simpleArrayMap = ArrayMap.this;
            int i = simpleArrayMap.mSize;
            for (Object remove : collection) {
                simpleArrayMap.remove(remove);
            }
            return i != simpleArrayMap.mSize;
        }

        public final Object[] toArray(Object[] objArr) {
            return ArrayMap.this.toArrayHelper(objArr, 0);
        }
    }

    /* compiled from: PG */
    final class MapIterator implements Iterator, Entry, p020j$.util.Iterator, p020j$.util.Map.Entry {
        int mEnd;
        boolean mEntryValid;
        int mIndex = -1;

        public MapIterator() {
            this.mEnd = ArrayMap.this.mSize - 1;
        }

        public final boolean equals(Object obj) {
            if (!this.mEntryValid) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            } else if (!(obj instanceof Entry)) {
                return false;
            } else {
                Entry entry = (Entry) obj;
                if (ContainerHelpers.equal(entry.getKey(), ArrayMap.this.keyAt(this.mIndex)) && ContainerHelpers.equal(entry.getValue(), ArrayMap.this.valueAt(this.mIndex))) {
                    return true;
                }
                return false;
            }
        }

        public final /* synthetic */ void forEachRemaining(Consumer consumer) {
            -CC.$default$forEachRemaining(this, consumer);
        }

        public final Object getKey() {
            if (this.mEntryValid) {
                return ArrayMap.this.keyAt(this.mIndex);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final Object getValue() {
            if (this.mEntryValid) {
                return ArrayMap.this.valueAt(this.mIndex);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final boolean hasNext() {
            return this.mIndex < this.mEnd;
        }

        public final int hashCode() {
            if (this.mEntryValid) {
                Object keyAt = ArrayMap.this.keyAt(this.mIndex);
                Object valueAt = ArrayMap.this.valueAt(this.mIndex);
                int i = 0;
                int hashCode = keyAt == null ? 0 : keyAt.hashCode();
                if (valueAt != null) {
                    i = valueAt.hashCode();
                }
                return hashCode ^ i;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final void remove() {
            if (this.mEntryValid) {
                ArrayMap.this.removeAt(this.mIndex);
                this.mIndex--;
                this.mEnd--;
                this.mEntryValid = false;
                return;
            }
            throw new IllegalStateException();
        }

        public final Object setValue(Object obj) {
            if (this.mEntryValid) {
                return ArrayMap.this.setValueAt(this.mIndex, obj);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(getKey());
            stringBuilder.append("=");
            stringBuilder.append(getValue());
            return stringBuilder.toString();
        }

        public final /* bridge */ /* synthetic */ Object next() {
            if (hasNext()) {
                this.mIndex++;
                this.mEntryValid = true;
                return this;
            }
            throw new NoSuchElementException();
        }
    }

    /* compiled from: PG */
    final class ValueCollection implements Collection {
        public final boolean add(Object obj) {
            throw new UnsupportedOperationException();
        }

        public final boolean addAll(Collection collection) {
            throw new UnsupportedOperationException();
        }

        public final void clear() {
            ArrayMap.this.clear();
        }

        public final boolean contains(Object obj) {
            return ArrayMap.this.indexOfValue(obj) >= 0;
        }

        public final boolean containsAll(Collection collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public final boolean isEmpty() {
            return ArrayMap.this.isEmpty();
        }

        public final Iterator iterator() {
            return new ValueIterator();
        }

        public final boolean remove(Object obj) {
            int indexOfValue = ArrayMap.this.indexOfValue(obj);
            if (indexOfValue < 0) {
                return false;
            }
            ArrayMap.this.removeAt(indexOfValue);
            return true;
        }

        public final boolean removeAll(Collection collection) {
            int i = ArrayMap.this.mSize;
            int i2 = 0;
            boolean z = false;
            while (i2 < i) {
                if (collection.contains(ArrayMap.this.valueAt(i2))) {
                    ArrayMap.this.removeAt(i2);
                    i2--;
                    i--;
                    z = true;
                }
                i2++;
            }
            return z;
        }

        public final boolean retainAll(Collection collection) {
            int i = ArrayMap.this.mSize;
            int i2 = 0;
            boolean z = false;
            while (i2 < i) {
                if (!collection.contains(ArrayMap.this.valueAt(i2))) {
                    ArrayMap.this.removeAt(i2);
                    i2--;
                    i--;
                    z = true;
                }
                i2++;
            }
            return z;
        }

        public final int size() {
            return ArrayMap.this.mSize;
        }

        public final Object[] toArray() {
            int i = ArrayMap.this.mSize;
            Object[] objArr = new Object[i];
            for (int i2 = 0; i2 < i; i2++) {
                objArr[i2] = ArrayMap.this.valueAt(i2);
            }
            return objArr;
        }

        public final Object[] toArray(Object[] objArr) {
            return ArrayMap.this.toArrayHelper(objArr, 1);
        }
    }

    /* compiled from: PG */
    final class ValueIterator extends IndexBasedArrayIterator {
        public ValueIterator() {
            super(ArrayMap.this.mSize);
        }

        protected final Object elementAt(int i) {
            return ArrayMap.this.valueAt(i);
        }

        protected final void removeAt(int i) {
            ArrayMap.this.removeAt(i);
        }
    }

    public final /* synthetic */ Object compute(Object obj, BiFunction biFunction) {
        return p020j$.util.Map.-CC.$default$compute(this, obj, biFunction);
    }

    public final /* synthetic */ Object computeIfAbsent(Object obj, Function function) {
        return p020j$.util.Map.-CC.$default$computeIfAbsent(this, obj, function);
    }

    public final /* synthetic */ Object computeIfPresent(Object obj, BiFunction biFunction) {
        return p020j$.util.Map.-CC.$default$computeIfPresent(this, obj, biFunction);
    }

    public final Set entrySet() {
        Set set = this.mEntrySet;
        if (set != null) {
            return set;
        }
        set = new EntrySet();
        this.mEntrySet = set;
        return set;
    }

    public final /* synthetic */ void forEach(BiConsumer biConsumer) {
        p020j$.util.Map.-CC.$default$forEach(this, biConsumer);
    }

    public final Set keySet() {
        Set set = this.mKeySet;
        if (set != null) {
            return set;
        }
        set = new KeySet();
        this.mKeySet = set;
        return set;
    }

    public final /* synthetic */ Object merge(Object obj, Object obj2, BiFunction biFunction) {
        return p020j$.util.Map.-CC.$default$merge(this, obj, obj2, biFunction);
    }

    public final void putAll(Map map) {
        int size = this.mSize + map.size();
        int i = this.mSize;
        Object obj = this.mHashes;
        if (obj.length < size) {
            Object obj2 = this.mArray;
            super.allocArrays(size);
            if (this.mSize > 0) {
                System.arraycopy(obj, 0, this.mHashes, 0, i);
                System.arraycopy(obj2, 0, this.mArray, 0, i + i);
            }
            SimpleArrayMap.freeArrays(obj, obj2, i);
        }
        if (this.mSize == i) {
            for (Entry entry : map.entrySet()) {
                put(entry.getKey(), entry.getValue());
            }
            return;
        }
        throw new ConcurrentModificationException();
    }

    public final /* synthetic */ void replaceAll(BiFunction biFunction) {
        p020j$.util.Map.-CC.$default$replaceAll(this, biFunction);
    }

    public final boolean retainAll(Collection collection) {
        int i = this.mSize;
        for (int i2 = i - 1; i2 >= 0; i2--) {
            if (!collection.contains(keyAt(i2))) {
                removeAt(i2);
            }
        }
        return i != this.mSize;
    }

    final Object[] toArrayHelper(Object[] objArr, int i) {
        int i2 = this.mSize;
        if (objArr.length < i2) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), i2);
        }
        for (int i3 = 0; i3 < i2; i3++) {
            objArr[i3] = this.mArray[(i3 + i3) + i];
        }
        if (objArr.length > i2) {
            objArr[i2] = null;
        }
        return objArr;
    }

    public final Collection values() {
        Collection collection = this.mValues;
        if (collection != null) {
            return collection;
        }
        collection = new ValueCollection();
        this.mValues = collection;
        return collection;
    }

    public ArrayMap(int i) {
        super(i);
    }
}
