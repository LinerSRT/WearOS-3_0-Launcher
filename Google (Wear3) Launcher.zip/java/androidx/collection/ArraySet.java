package androidx.collection;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Set;

/* compiled from: PG */
public final class ArraySet implements Collection, Set {
    private static Object[] sBaseCache;
    private static final Object sBaseCacheLock = new Object();
    private static int sBaseCacheSize;
    private static Object[] sTwiceBaseCache;
    private static final Object sTwiceBaseCacheLock = new Object();
    private static int sTwiceBaseCacheSize;
    Object[] mArray = ContainerHelpers.EMPTY_OBJECTS;
    private int[] mHashes = ContainerHelpers.EMPTY_INTS;
    int mSize = 0;

    /* compiled from: PG */
    final class ElementIterator extends IndexBasedArrayIterator {
        public ElementIterator() {
            super(ArraySet.this.mSize);
        }

        protected final Object elementAt(int i) {
            return ArraySet.this.valueAt(i);
        }

        protected final void removeAt(int i) {
            ArraySet.this.removeAt$ar$ds(i);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void allocArrays(int r9) {
        /*
        r8 = this;
        r0 = 4;
        r1 = 0;
        r2 = 1;
        r3 = 0;
        r4 = 8;
        if (r9 != r4) goto L_0x0057;
    L_0x0008:
        r4 = sTwiceBaseCacheLock;
        monitor-enter(r4);
        r0 = sTwiceBaseCache;	 Catch:{ all -> 0x0054 }
        if (r0 == 0) goto L_0x0052;
    L_0x000f:
        r8.mArray = r0;	 Catch:{ ClassCastException -> 0x002b }
        r5 = r0[r3];	 Catch:{ ClassCastException -> 0x002b }
        r5 = (java.lang.Object[]) r5;	 Catch:{ ClassCastException -> 0x002b }
        sTwiceBaseCache = r5;	 Catch:{ ClassCastException -> 0x002b }
        r5 = r0[r2];	 Catch:{ ClassCastException -> 0x002b }
        r5 = (int[]) r5;	 Catch:{ ClassCastException -> 0x002b }
        r8.mHashes = r5;	 Catch:{ ClassCastException -> 0x002b }
        if (r5 == 0) goto L_0x002c;
    L_0x001f:
        r0[r2] = r1;	 Catch:{ ClassCastException -> 0x002b }
        r0[r3] = r1;	 Catch:{ ClassCastException -> 0x002b }
        r5 = sTwiceBaseCacheSize;	 Catch:{ ClassCastException -> 0x002b }
        r5 = r5 + -1;
        sTwiceBaseCacheSize = r5;	 Catch:{ ClassCastException -> 0x002b }
        monitor-exit(r4);	 Catch:{ all -> 0x0054 }
        return;
    L_0x002b:
        r5 = move-exception;
    L_0x002c:
        r5 = java.lang.System.out;	 Catch:{ all -> 0x0054 }
        r6 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0054 }
        r6.<init>();	 Catch:{ all -> 0x0054 }
        r7 = "ArraySet Found corrupt ArraySet cache: [0]=";
        r6.append(r7);	 Catch:{ all -> 0x0054 }
        r7 = r0[r3];	 Catch:{ all -> 0x0054 }
        r6.append(r7);	 Catch:{ all -> 0x0054 }
        r7 = " [1]=";
        r6.append(r7);	 Catch:{ all -> 0x0054 }
        r0 = r0[r2];	 Catch:{ all -> 0x0054 }
        r6.append(r0);	 Catch:{ all -> 0x0054 }
        r0 = r6.toString();	 Catch:{ all -> 0x0054 }
        r5.println(r0);	 Catch:{ all -> 0x0054 }
        sTwiceBaseCache = r1;	 Catch:{ all -> 0x0054 }
        sTwiceBaseCacheSize = r3;	 Catch:{ all -> 0x0054 }
    L_0x0052:
        monitor-exit(r4);	 Catch:{ all -> 0x0054 }
        goto L_0x00a9;
    L_0x0054:
        r9 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x0054 }
        throw r9;
    L_0x0057:
        if (r9 != r0) goto L_0x00a9;
    L_0x0059:
        r4 = sBaseCacheLock;
        monitor-enter(r4);
        r9 = sBaseCache;	 Catch:{ all -> 0x00a6 }
        if (r9 == 0) goto L_0x00a3;
    L_0x0060:
        r8.mArray = r9;	 Catch:{ ClassCastException -> 0x007c }
        r5 = r9[r3];	 Catch:{ ClassCastException -> 0x007c }
        r5 = (java.lang.Object[]) r5;	 Catch:{ ClassCastException -> 0x007c }
        sBaseCache = r5;	 Catch:{ ClassCastException -> 0x007c }
        r5 = r9[r2];	 Catch:{ ClassCastException -> 0x007c }
        r5 = (int[]) r5;	 Catch:{ ClassCastException -> 0x007c }
        r8.mHashes = r5;	 Catch:{ ClassCastException -> 0x007c }
        if (r5 == 0) goto L_0x007d;
    L_0x0070:
        r9[r2] = r1;	 Catch:{ ClassCastException -> 0x007c }
        r9[r3] = r1;	 Catch:{ ClassCastException -> 0x007c }
        r5 = sBaseCacheSize;	 Catch:{ ClassCastException -> 0x007c }
        r5 = r5 + -1;
        sBaseCacheSize = r5;	 Catch:{ ClassCastException -> 0x007c }
        monitor-exit(r4);	 Catch:{ all -> 0x00a6 }
        return;
    L_0x007c:
        r5 = move-exception;
    L_0x007d:
        r5 = java.lang.System.out;	 Catch:{ all -> 0x00a6 }
        r6 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00a6 }
        r6.<init>();	 Catch:{ all -> 0x00a6 }
        r7 = "ArraySet Found corrupt ArraySet cache: [0]=";
        r6.append(r7);	 Catch:{ all -> 0x00a6 }
        r7 = r9[r3];	 Catch:{ all -> 0x00a6 }
        r6.append(r7);	 Catch:{ all -> 0x00a6 }
        r7 = " [1]=";
        r6.append(r7);	 Catch:{ all -> 0x00a6 }
        r9 = r9[r2];	 Catch:{ all -> 0x00a6 }
        r6.append(r9);	 Catch:{ all -> 0x00a6 }
        r9 = r6.toString();	 Catch:{ all -> 0x00a6 }
        r5.println(r9);	 Catch:{ all -> 0x00a6 }
        sBaseCache = r1;	 Catch:{ all -> 0x00a6 }
        sBaseCacheSize = r3;	 Catch:{ all -> 0x00a6 }
    L_0x00a3:
        monitor-exit(r4);	 Catch:{ all -> 0x00a6 }
        r9 = 4;
        goto L_0x00a9;
    L_0x00a6:
        r9 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x00a6 }
        throw r9;
    L_0x00a9:
        r0 = new int[r9];
        r8.mHashes = r0;
        r9 = new java.lang.Object[r9];
        r8.mArray = r9;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.collection.ArraySet.allocArrays(int):void");
    }

    private final int binarySearch(int i) {
        try {
            return ContainerHelpers.binarySearch(this.mHashes, this.mSize, i);
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new ConcurrentModificationException();
        }
    }

    private static void freeArrays(int[] iArr, Object[] objArr, int i) {
        int length = iArr.length;
        if (length == 8) {
            synchronized (sTwiceBaseCacheLock) {
                if (sTwiceBaseCacheSize < 10) {
                    objArr[0] = sTwiceBaseCache;
                    objArr[1] = iArr;
                    for (i--; i >= 2; i--) {
                        objArr[i] = null;
                    }
                    sTwiceBaseCache = objArr;
                    sTwiceBaseCacheSize++;
                }
            }
        } else if (length == 4) {
            synchronized (sBaseCacheLock) {
                if (sBaseCacheSize < 10) {
                    objArr[0] = sBaseCache;
                    objArr[1] = iArr;
                    for (i--; i >= 2; i--) {
                        objArr[i] = null;
                    }
                    sBaseCache = objArr;
                    sBaseCacheSize++;
                }
            }
        }
    }

    private final int indexOf(Object obj, int i) {
        int i2 = this.mSize;
        if (i2 == 0) {
            return -1;
        }
        int binarySearch = binarySearch(i);
        if (binarySearch < 0 || obj.equals(this.mArray[binarySearch])) {
            return binarySearch;
        }
        int i3 = binarySearch + 1;
        while (i3 < i2 && this.mHashes[i3] == i) {
            if (obj.equals(this.mArray[i3])) {
                return i3;
            }
            i3++;
        }
        binarySearch--;
        while (binarySearch >= 0 && this.mHashes[binarySearch] == i) {
            if (obj.equals(this.mArray[binarySearch])) {
                return binarySearch;
            }
            binarySearch--;
        }
        return i3 ^ -1;
    }

    private final int indexOfNull() {
        int i = this.mSize;
        if (i == 0) {
            return -1;
        }
        int binarySearch = binarySearch(0);
        if (binarySearch < 0 || this.mArray[binarySearch] == null) {
            return binarySearch;
        }
        int i2 = binarySearch + 1;
        while (i2 < i && this.mHashes[i2] == 0) {
            if (this.mArray[i2] == null) {
                return i2;
            }
            i2++;
        }
        binarySearch--;
        while (binarySearch >= 0 && this.mHashes[binarySearch] == 0) {
            if (this.mArray[binarySearch] == null) {
                return binarySearch;
            }
            binarySearch--;
        }
        return i2 ^ -1;
    }

    public final boolean add(Object obj) {
        int indexOfNull;
        int i;
        int i2 = this.mSize;
        if (obj == null) {
            indexOfNull = indexOfNull();
            i = 0;
        } else {
            indexOfNull = obj.hashCode();
            i = indexOfNull;
            indexOfNull = indexOf(obj, indexOfNull);
        }
        if (indexOfNull >= 0) {
            return false;
        }
        indexOfNull ^= -1;
        Object obj2 = this.mHashes;
        int length = obj2.length;
        if (i2 >= length) {
            int i3 = 4;
            if (i2 >= 8) {
                i3 = (i2 >> 1) + i2;
            } else if (i2 >= 4) {
                i3 = 8;
            }
            Object obj3 = this.mArray;
            allocArrays(i3);
            if (i2 == this.mSize) {
                Object obj4 = this.mHashes;
                if (obj4.length > 0) {
                    System.arraycopy(obj2, 0, obj4, 0, length);
                    System.arraycopy(obj3, 0, this.mArray, 0, obj3.length);
                }
                freeArrays(obj2, obj3, i2);
            } else {
                throw new ConcurrentModificationException();
            }
        }
        if (indexOfNull < i2) {
            Object obj5 = this.mHashes;
            int i4 = indexOfNull + 1;
            length = i2 - indexOfNull;
            System.arraycopy(obj5, indexOfNull, obj5, i4, length);
            obj5 = this.mArray;
            System.arraycopy(obj5, indexOfNull, obj5, i4, length);
        }
        int i5 = this.mSize;
        if (i2 == i5) {
            int[] iArr = this.mHashes;
            if (indexOfNull < iArr.length) {
                iArr[indexOfNull] = i;
                this.mArray[indexOfNull] = obj;
                this.mSize = i5 + 1;
                return true;
            }
        }
        throw new ConcurrentModificationException();
    }

    public final boolean addAll(Collection collection) {
        int size = this.mSize + collection.size();
        int i = this.mSize;
        Object obj = this.mHashes;
        boolean z = false;
        if (obj.length < size) {
            Object obj2 = this.mArray;
            allocArrays(size);
            size = this.mSize;
            if (size > 0) {
                System.arraycopy(obj, 0, this.mHashes, 0, size);
                System.arraycopy(obj2, 0, this.mArray, 0, this.mSize);
            }
            freeArrays(obj, obj2, this.mSize);
        }
        if (this.mSize == i) {
            for (Object add : collection) {
                z |= add(add);
            }
            return z;
        }
        throw new ConcurrentModificationException();
    }

    public final void clear() {
        int i = this.mSize;
        if (i != 0) {
            int[] iArr = this.mHashes;
            Object[] objArr = this.mArray;
            this.mHashes = ContainerHelpers.EMPTY_INTS;
            this.mArray = ContainerHelpers.EMPTY_OBJECTS;
            this.mSize = 0;
            freeArrays(iArr, objArr, i);
        }
        if (this.mSize != 0) {
            throw new ConcurrentModificationException();
        }
    }

    public final boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    public final boolean containsAll(Collection collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            if (this.mSize == set.size()) {
                int i = 0;
                while (i < this.mSize) {
                    try {
                        if (!set.contains(valueAt(i))) {
                            return false;
                        }
                        i++;
                    } catch (NullPointerException e) {
                    } catch (ClassCastException e2) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int[] iArr = this.mHashes;
        int i = 0;
        for (int i2 = 0; i2 < this.mSize; i2++) {
            i += iArr[i2];
        }
        return i;
    }

    public final boolean isEmpty() {
        return this.mSize <= 0;
    }

    public final Iterator iterator() {
        return new ElementIterator();
    }

    public final boolean remove(Object obj) {
        int indexOf = indexOf(obj);
        if (indexOf < 0) {
            return false;
        }
        removeAt$ar$ds(indexOf);
        return true;
    }

    public final boolean removeAll(Collection collection) {
        boolean z = false;
        for (Object remove : collection) {
            z |= remove(remove);
        }
        return z;
    }

    public final void removeAt$ar$ds(int i) {
        int i2 = this.mSize;
        Object obj = this.mArray;
        Object obj2 = obj[i];
        if (i2 <= 1) {
            clear();
            return;
        }
        int i3 = i2 - 1;
        Object obj3 = this.mHashes;
        int length = obj3.length;
        int i4 = 8;
        if (length <= 8 || i2 >= length / 3) {
            if (i < i3) {
                int i5 = i + 1;
                length = i3 - i;
                System.arraycopy(obj3, i5, obj3, i, length);
                obj3 = this.mArray;
                System.arraycopy(obj3, i5, obj3, i, length);
            }
            this.mArray[i3] = null;
        } else {
            if (i2 > 8) {
                i4 = i2 + (i2 >> 1);
            }
            allocArrays(i4);
            if (i > 0) {
                System.arraycopy(obj3, 0, this.mHashes, 0, i);
                System.arraycopy(obj, 0, this.mArray, 0, i);
            }
            if (i < i3) {
                length = i + 1;
                i4 = i3 - i;
                System.arraycopy(obj3, length, this.mHashes, i, i4);
                System.arraycopy(obj, length, this.mArray, i, i4);
            }
        }
        if (i2 == this.mSize) {
            this.mSize = i3;
            return;
        }
        throw new ConcurrentModificationException();
    }

    public final boolean retainAll(Collection collection) {
        boolean z = false;
        for (int i = this.mSize - 1; i >= 0; i--) {
            if (!collection.contains(this.mArray[i])) {
                removeAt$ar$ds(i);
                z = true;
            }
        }
        return z;
    }

    public final int size() {
        return this.mSize;
    }

    public final Object[] toArray() {
        int i = this.mSize;
        Object obj = new Object[i];
        System.arraycopy(this.mArray, 0, obj, 0, i);
        return obj;
    }

    public final String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.mSize * 14);
        stringBuilder.append('{');
        for (int i = 0; i < this.mSize; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            ArraySet valueAt = valueAt(i);
            if (valueAt != this) {
                stringBuilder.append(valueAt);
            } else {
                stringBuilder.append("(this Set)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public final Object valueAt(int i) {
        return this.mArray[i];
    }

    public final Object[] toArray(Object[] objArr) {
        Object objArr2;
        if (objArr2.length < this.mSize) {
            objArr2 = (Object[]) Array.newInstance(objArr2.getClass().getComponentType(), this.mSize);
        }
        System.arraycopy(this.mArray, 0, objArr2, 0, this.mSize);
        int length = objArr2.length;
        int i = this.mSize;
        if (length > i) {
            objArr2[i] = null;
        }
        return objArr2;
    }

    public final int indexOf(Object obj) {
        return obj == null ? indexOfNull() : indexOf(obj, obj.hashCode());
    }
}
