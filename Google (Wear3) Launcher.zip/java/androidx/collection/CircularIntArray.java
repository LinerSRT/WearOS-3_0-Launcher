package androidx.collection;

/* compiled from: PG */
public final class CircularIntArray {
    private int mCapacityBitmask;
    private int[] mElements;
    private int mTail;

    public CircularIntArray() {
        this(null);
    }

    public final void addLast(int i) {
        Object obj = this.mElements;
        int i2 = this.mTail;
        obj[i2] = i;
        i = this.mCapacityBitmask & (i2 + 1);
        this.mTail = i;
        if (i == 0) {
            i = obj.length;
            i2 = i + i;
            if (i2 >= 0) {
                Object obj2 = new int[i2];
                System.arraycopy(obj, 0, obj2, 0, i);
                System.arraycopy(this.mElements, 0, obj2, i, 0);
                this.mElements = obj2;
                this.mTail = i;
                this.mCapacityBitmask = i2 - 1;
                return;
            }
            throw new RuntimeException("Max array capacity exceeded");
        }
    }

    public final void clear() {
        this.mTail = 0;
    }

    public final int get(int i) {
        if (i >= 0 && i < size()) {
            return this.mElements[i & this.mCapacityBitmask];
        }
        throw new ArrayIndexOutOfBoundsException();
    }

    public final int size() {
        return this.mTail & this.mCapacityBitmask;
    }

    public CircularIntArray(byte[] bArr) {
        int i = 10;
        if (Integer.bitCount(10) != 1) {
            i = Integer.highestOneBit(9);
            i += i;
        }
        this.mCapacityBitmask = i - 1;
        this.mElements = new int[i];
    }
}
