package androidx.collection;

/* compiled from: PG */
public final class CircularArray {
    public int mCapacityBitmask;
    public Object[] mElements;
    public int mHead;
    public int mTail;

    public final int size() {
        return (this.mTail - this.mHead) & this.mCapacityBitmask;
    }

    public CircularArray() {
        int i = 8;
        if (Integer.bitCount(8) != 1) {
            i = Integer.highestOneBit(7);
            i += i;
        }
        this.mCapacityBitmask = i - 1;
        this.mElements = new Object[i];
    }
}
