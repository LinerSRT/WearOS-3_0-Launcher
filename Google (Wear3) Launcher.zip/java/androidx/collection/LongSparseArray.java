package androidx.collection;

/* compiled from: PG */
public final class LongSparseArray implements Cloneable {
    public static final Object DELETED = new Object();
    public boolean mGarbage;
    public long[] mKeys;
    public int mSize;
    public Object[] mValues;

    public LongSparseArray() {
        this(10);
    }

    public final void clear() {
        int i = this.mSize;
        Object[] objArr = this.mValues;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.mSize = 0;
        this.mGarbage = false;
    }

    public final LongSparseArray clone() {
        try {
            LongSparseArray longSparseArray = (LongSparseArray) super.clone();
            longSparseArray.mKeys = (long[]) this.mKeys.clone();
            longSparseArray.mValues = (Object[]) this.mValues.clone();
            return longSparseArray;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    /* renamed from: gc */
    public final void m3gc() {
        int i = this.mSize;
        long[] jArr = this.mKeys;
        Object[] objArr = this.mValues;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != DELETED) {
                if (i3 != i2) {
                    jArr[i2] = jArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.mGarbage = false;
        this.mSize = i2;
    }

    public final long keyAt(int i) {
        if (this.mGarbage) {
            m3gc();
        }
        return this.mKeys[i];
    }

    public final void put(long j, Object obj) {
        int binarySearch = ContainerHelpers.binarySearch(this.mKeys, this.mSize, j);
        if (binarySearch >= 0) {
            this.mValues[binarySearch] = obj;
            return;
        }
        binarySearch ^= -1;
        int i = this.mSize;
        if (binarySearch < i) {
            Object[] objArr = this.mValues;
            if (objArr[binarySearch] == DELETED) {
                this.mKeys[binarySearch] = j;
                objArr[binarySearch] = obj;
                return;
            }
        }
        if (this.mGarbage && i >= this.mKeys.length) {
            m3gc();
            binarySearch = ContainerHelpers.binarySearch(this.mKeys, this.mSize, j) ^ -1;
        }
        i = this.mSize;
        if (i >= this.mKeys.length) {
            i = ContainerHelpers.idealLongArraySize(i + 1);
            Object obj2 = new long[i];
            Object obj3 = new Object[i];
            Object obj4 = this.mKeys;
            System.arraycopy(obj4, 0, obj2, 0, obj4.length);
            obj4 = this.mValues;
            System.arraycopy(obj4, 0, obj3, 0, obj4.length);
            this.mKeys = obj2;
            this.mValues = obj3;
        }
        i = this.mSize - binarySearch;
        if (i != 0) {
            obj2 = this.mKeys;
            int i2 = binarySearch + 1;
            System.arraycopy(obj2, binarySearch, obj2, i2, i);
            obj3 = this.mValues;
            System.arraycopy(obj3, binarySearch, obj3, i2, this.mSize - binarySearch);
        }
        this.mKeys[binarySearch] = j;
        this.mValues[binarySearch] = obj;
        this.mSize++;
    }

    public final int size() {
        if (this.mGarbage) {
            m3gc();
        }
        return this.mSize;
    }

    public final String toString() {
        if (size() <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.mSize * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.mSize; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(keyAt(i));
            stringBuilder.append('=');
            LongSparseArray valueAt = valueAt(i);
            if (valueAt != this) {
                stringBuilder.append(valueAt);
            } else {
                stringBuilder.append("(this Map)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public final Object valueAt(int i) {
        if (this.mGarbage) {
            m3gc();
        }
        return this.mValues[i];
    }

    public LongSparseArray(int i) {
        this.mGarbage = false;
        if (i == 0) {
            this.mKeys = ContainerHelpers.EMPTY_LONGS;
            this.mValues = ContainerHelpers.EMPTY_OBJECTS;
            return;
        }
        i = ContainerHelpers.idealLongArraySize(i);
        this.mKeys = new long[i];
        this.mValues = new Object[i];
    }

    public final Object get(long j) {
        int binarySearch = ContainerHelpers.binarySearch(this.mKeys, this.mSize, j);
        if (binarySearch >= 0) {
            Object[] objArr = this.mValues;
            if (objArr[binarySearch] != DELETED) {
                return objArr[binarySearch];
            }
        }
        return null;
    }
}
