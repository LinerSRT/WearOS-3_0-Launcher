package androidx.collection;

import java.util.Iterator;
import java.util.NoSuchElementException;
import p020j$.util.Iterator.-CC;
import p020j$.util.function.Consumer;

/* compiled from: PG */
abstract class IndexBasedArrayIterator implements Iterator, p020j$.util.Iterator {
    private boolean mCanRemove;
    private int mIndex;
    private int mSize;

    public IndexBasedArrayIterator(int i) {
        this.mSize = i;
    }

    protected abstract Object elementAt(int i);

    public final /* synthetic */ void forEachRemaining(Consumer consumer) {
        -CC.$default$forEachRemaining(this, consumer);
    }

    public final boolean hasNext() {
        return this.mIndex < this.mSize;
    }

    public final Object next() {
        if (hasNext()) {
            Object elementAt = elementAt(this.mIndex);
            this.mIndex++;
            this.mCanRemove = true;
            return elementAt;
        }
        throw new NoSuchElementException();
    }

    public final void remove() {
        if (this.mCanRemove) {
            int i = this.mIndex - 1;
            this.mIndex = i;
            removeAt(i);
            this.mSize--;
            this.mCanRemove = false;
            return;
        }
        throw new IllegalStateException();
    }

    protected abstract void removeAt(int i);
}
