package androidx.core.provider;

/* compiled from: PG */
public class FontsContractCompat$FontRequestCallback {
}
