package androidx.core.provider;

import android.os.Handler;
import android.os.Process;
import android.support.p000v4.util.Consumer;
import androidx.core.provider.FontRequestWorker.C01413;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* compiled from: PG */
public final class RequestExecutor {

    /* compiled from: PG */
    final class DefaultThreadFactory implements ThreadFactory {

        /* compiled from: PG */
        final class ProcessPriorityThread extends Thread {
            private final int mPriority = 10;

            public ProcessPriorityThread(Runnable runnable) {
                super(runnable, "fonts-androidx");
            }

            public final void run() {
                Process.setThreadPriority(this.mPriority);
                super.run();
            }
        }

        public final Thread newThread(Runnable runnable) {
            return new ProcessPriorityThread(runnable);
        }
    }

    /* compiled from: PG */
    public final class ReplyRunnable implements Runnable {
        private final Callable mCallable;
        private final Consumer mConsumer;
        private final Handler mHandler;

        /* renamed from: androidx.core.provider.RequestExecutor$ReplyRunnable$1 */
        final class PG implements Runnable {
            final /* synthetic */ Consumer val$consumer;
            final /* synthetic */ Object val$result;

            public PG(Consumer consumer, Object obj) {
                this.val$consumer = consumer;
                this.val$result = obj;
            }

            public final void run() {
                this.val$consumer.accept(this.val$result);
            }
        }

        public ReplyRunnable(Handler handler, Callable callable, Consumer consumer) {
            this.mCallable = callable;
            this.mConsumer = consumer;
            this.mHandler = handler;
        }

        public final void run() {
            Object call;
            try {
                call = ((C01413) this.mCallable).call();
            } catch (Exception e) {
                call = null;
            }
            this.mHandler.post(new PG(this.mConsumer, call));
        }
    }

    public static Object submit(ExecutorService executorService, Callable callable, int i) {
        try {
            return executorService.submit(callable).get((long) i, TimeUnit.MILLISECONDS);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e2) {
            throw e2;
        } catch (TimeoutException e3) {
            throw new InterruptedException("timeout");
        }
    }
}
