package androidx.core.provider;

import android.graphics.Typeface;
import android.os.Handler;
import android.support.p000v4.graphics.TypefaceCompat.ResourcesCallbackAdapter;
import androidx.core.provider.FontRequestWorker.TypefaceResult;

/* compiled from: PG */
public final class CallbackWithHandler {
    private final FontsContractCompat$FontRequestCallback mCallback;
    private final Handler mCallbackHandler;

    /* renamed from: androidx.core.provider.CallbackWithHandler$1 */
    final class PG implements Runnable {
        final /* synthetic */ FontsContractCompat$FontRequestCallback val$callback;
        final /* synthetic */ Typeface val$typeface;

        public PG(FontsContractCompat$FontRequestCallback fontsContractCompat$FontRequestCallback, Typeface typeface) {
            this.val$callback = fontsContractCompat$FontRequestCallback;
            this.val$typeface = typeface;
        }

        public final void run() {
            FontsContractCompat$FontRequestCallback fontsContractCompat$FontRequestCallback = this.val$callback;
            ((ResourcesCallbackAdapter) fontsContractCompat$FontRequestCallback).mFontCallback.onFontRetrieved(this.val$typeface);
        }
    }

    /* renamed from: androidx.core.provider.CallbackWithHandler$2 */
    final class C01392 implements Runnable {
        public final void run() {
        }
    }

    public CallbackWithHandler(FontsContractCompat$FontRequestCallback fontsContractCompat$FontRequestCallback, Handler handler) {
        this.mCallback = fontsContractCompat$FontRequestCallback;
        this.mCallbackHandler = handler;
    }

    public final void onTypefaceResult(TypefaceResult typefaceResult) {
        if (typefaceResult.mResult == 0) {
            Typeface typeface = typefaceResult.mTypeface;
            this.mCallbackHandler.post(new PG(this.mCallback, typeface));
            return;
        }
        this.mCallbackHandler.post(new C01392());
    }
}
