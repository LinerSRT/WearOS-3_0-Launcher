package androidx.core.provider;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.Typeface.CustomFallbackBuilder;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.fonts.FontStyle;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.ParcelFileDescriptor;
import android.support.p000v4.graphics.TypefaceCompat;
import android.support.p000v4.util.Consumer;
import androidx.collection.LruCache;
import androidx.collection.SimpleArrayMap;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* compiled from: PG */
public final class FontRequestWorker {
    public static final ExecutorService DEFAULT_EXECUTOR_SERVICE;
    public static final Object LOCK = new Object();
    public static final SimpleArrayMap PENDING_REPLIES = new SimpleArrayMap();
    public static final LruCache sTypefaceCache = new LruCache(16);

    /* renamed from: androidx.core.provider.FontRequestWorker$1 */
    public final class PG implements Callable {
        final /* synthetic */ Context val$context;
        final /* synthetic */ String val$id;
        final /* synthetic */ FontRequest val$request;
        final /* synthetic */ int val$style;

        public PG(String str, Context context, FontRequest fontRequest, int i) {
            this.val$id = str;
            this.val$context = context;
            this.val$request = fontRequest;
            this.val$style = i;
        }

        public final /* bridge */ /* synthetic */ Object call() {
            return FontRequestWorker.getFontSync(this.val$id, this.val$context, this.val$request, this.val$style);
        }
    }

    /* renamed from: androidx.core.provider.FontRequestWorker$2 */
    public final class C01402 implements Consumer {
        final /* synthetic */ CallbackWithHandler val$callback;

        public C01402(CallbackWithHandler callbackWithHandler) {
            this.val$callback = callbackWithHandler;
        }

        public final /* bridge */ /* synthetic */ void accept(Object obj) {
            TypefaceResult typefaceResult = (TypefaceResult) obj;
            if (typefaceResult == null) {
                typefaceResult = new TypefaceResult(-3);
            }
            this.val$callback.onTypefaceResult(typefaceResult);
        }
    }

    /* renamed from: androidx.core.provider.FontRequestWorker$3 */
    public final class C01413 implements Callable {
        final /* synthetic */ Context val$context;
        final /* synthetic */ String val$id;
        final /* synthetic */ FontRequest val$request;
        final /* synthetic */ int val$style;

        public C01413(String str, Context context, FontRequest fontRequest, int i) {
            this.val$id = str;
            this.val$context = context;
            this.val$request = fontRequest;
            this.val$style = i;
        }

        public final TypefaceResult call() {
            try {
                return FontRequestWorker.getFontSync(this.val$id, this.val$context, this.val$request, this.val$style);
            } catch (Throwable th) {
                return new TypefaceResult(-3);
            }
        }
    }

    /* renamed from: androidx.core.provider.FontRequestWorker$4 */
    public final class C01424 implements Consumer {
        final /* synthetic */ String val$id;

        public C01424(String str) {
            this.val$id = str;
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final /* bridge */ /* synthetic */ void accept(java.lang.Object r5) {
            /*
            r4 = this;
            r5 = (androidx.core.provider.FontRequestWorker.TypefaceResult) r5;
            r0 = androidx.core.provider.FontRequestWorker.LOCK;
            monitor-enter(r0);
            r1 = androidx.core.provider.FontRequestWorker.PENDING_REPLIES;	 Catch:{ all -> 0x002f }
            r2 = r4.val$id;	 Catch:{ all -> 0x002f }
            r1 = r1.get(r2);	 Catch:{ all -> 0x002f }
            r1 = (java.util.ArrayList) r1;	 Catch:{ all -> 0x002f }
            if (r1 != 0) goto L_0x0013;
        L_0x0011:
            monitor-exit(r0);	 Catch:{ all -> 0x002f }
            return;
        L_0x0013:
            r2 = androidx.core.provider.FontRequestWorker.PENDING_REPLIES;	 Catch:{ all -> 0x002f }
            r3 = r4.val$id;	 Catch:{ all -> 0x002f }
            r2.remove(r3);	 Catch:{ all -> 0x002f }
            monitor-exit(r0);	 Catch:{ all -> 0x002f }
            r0 = 0;
        L_0x001c:
            r2 = r1.size();
            if (r0 >= r2) goto L_0x002e;
        L_0x0022:
            r2 = r1.get(r0);
            r2 = (android.support.p000v4.util.Consumer) r2;
            r2.accept(r5);
            r0 = r0 + 1;
            goto L_0x001c;
        L_0x002e:
            return;
        L_0x002f:
            r5 = move-exception;
            monitor-exit(r0);	 Catch:{ all -> 0x002f }
            goto L_0x0033;
        L_0x0032:
            throw r5;
        L_0x0033:
            goto L_0x0032;
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.core.provider.FontRequestWorker.4.accept(java.lang.Object):void");
        }
    }

    /* compiled from: PG */
    public final class TypefaceResult {
        final int mResult;
        public final Typeface mTypeface;

        public TypefaceResult(int i) {
            this.mTypeface = null;
            this.mResult = i;
        }

        public TypefaceResult(Typeface typeface) {
            this.mTypeface = typeface;
            this.mResult = 0;
        }
    }

    static {
        ExecutorService threadPoolExecutor = new ThreadPoolExecutor(0, 1, 10000, TimeUnit.MILLISECONDS, new LinkedBlockingDeque(), new DefaultThreadFactory());
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        DEFAULT_EXECUTOR_SERVICE = threadPoolExecutor;
    }

    public static String createCacheId(FontRequest fontRequest, int i) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(fontRequest.mIdentifier);
        stringBuilder.append("-");
        stringBuilder.append(i);
        return stringBuilder.toString();
    }

    public static TypefaceResult getFontSync(String str, Context context, FontRequest fontRequest, int i) {
        Throwable th;
        Cursor cursor;
        Typeface typeface;
        String str2 = str;
        FontRequest fontRequest2 = fontRequest;
        String str3 = "result_code";
        String str4 = "font_italic";
        String str5 = "font_weight";
        String str6 = "font_ttc_index";
        String str7 = "file_id";
        String str8 = "_id";
        String str9 = "content";
        Typeface typeface2 = (Typeface) sTypefaceCache.get(str2);
        if (typeface2 != null) {
            return new TypefaceResult(typeface2);
        }
        try {
            PackageManager packageManager = context.getPackageManager();
            context.getResources();
            String str10 = fontRequest2.mProviderAuthority;
            ProviderInfo resolveContentProvider = packageManager.resolveContentProvider(str10, 0);
            if (resolveContentProvider == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("No package found for authority: ");
                stringBuilder.append(str10);
                throw new NameNotFoundException(stringBuilder.toString());
            } else if (resolveContentProvider.packageName.equals(fontRequest2.mProviderPackage)) {
                Object obj;
                FontsContractCompat$FontInfo[] fontsContractCompat$FontInfoArr;
                int columnIndex;
                int columnIndex2;
                int columnIndex3;
                Signature[] signatureArr = packageManager.getPackageInfo(resolveContentProvider.packageName, 64).signatures;
                List arrayList = new ArrayList();
                for (Signature toByteArray : signatureArr) {
                    arrayList.add(toByteArray.toByteArray());
                }
                Collections.sort(arrayList, FontProvider.sByteArrayComparator);
                List list = fontRequest2.mCertificates;
                int i2 = 0;
                loop1:
                while (i2 < list.size()) {
                    List list2;
                    List arrayList2 = new ArrayList((Collection) list.get(i2));
                    Collections.sort(arrayList2, FontProvider.sByteArrayComparator);
                    if (arrayList.size() == arrayList2.size()) {
                        int i3 = 0;
                        while (i3 < arrayList.size()) {
                            list2 = list;
                            if (Arrays.equals((byte[]) arrayList.get(i3), (byte[]) arrayList2.get(i3))) {
                                i3++;
                                list = list2;
                            }
                        }
                        break loop1;
                    }
                    list2 = list;
                    i2++;
                    list = list2;
                }
                resolveContentProvider = null;
                if (resolveContentProvider == null) {
                    obj = 1;
                    fontsContractCompat$FontInfoArr = null;
                } else {
                    String str11 = resolveContentProvider.authority;
                    ArrayList arrayList3 = new ArrayList();
                    Uri build = new Builder().scheme(str9).authority(str11).build();
                    Uri build2 = new Builder().scheme(str9).authority(str11).appendPath("file").build();
                    try {
                        Cursor query = context.getContentResolver().query(build, new String[]{str8, str7, str6, "font_variation_settings", str5, str4, str3}, "query = ?", new String[]{fontRequest2.mQuery}, null, null);
                        if (query != null) {
                            try {
                                if (query.getCount() > 0) {
                                    columnIndex = query.getColumnIndex(str3);
                                    arrayList3 = new ArrayList();
                                    int columnIndex4 = query.getColumnIndex(str8);
                                    columnIndex2 = query.getColumnIndex(str7);
                                    columnIndex3 = query.getColumnIndex(str6);
                                    int columnIndex5 = query.getColumnIndex(str5);
                                    int columnIndex6 = query.getColumnIndex(str4);
                                    while (query.moveToNext()) {
                                        int i4;
                                        int i5;
                                        Uri withAppendedId;
                                        int i6;
                                        boolean z;
                                        if (columnIndex != -1) {
                                            i4 = query.getInt(columnIndex);
                                        } else {
                                            i4 = 0;
                                        }
                                        if (columnIndex3 != -1) {
                                            i5 = query.getInt(columnIndex3);
                                        } else {
                                            i5 = 0;
                                        }
                                        if (columnIndex2 == -1) {
                                            withAppendedId = ContentUris.withAppendedId(build, query.getLong(columnIndex4));
                                        } else {
                                            withAppendedId = ContentUris.withAppendedId(build2, query.getLong(columnIndex2));
                                        }
                                        if (columnIndex5 != -1) {
                                            i6 = query.getInt(columnIndex5);
                                        } else {
                                            i6 = 400;
                                        }
                                        if (columnIndex6 == -1 || query.getInt(columnIndex6) != 1) {
                                            z = false;
                                        } else {
                                            z = true;
                                        }
                                        arrayList3.add(new FontsContractCompat$FontInfo(withAppendedId, i5, i6, z, i4));
                                    }
                                    if (query != null) {
                                        query.close();
                                    }
                                    fontsContractCompat$FontInfoArr = (FontsContractCompat$FontInfo[]) arrayList3.toArray(new FontsContractCompat$FontInfo[0]);
                                    obj = null;
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                cursor = query;
                                if (cursor != null) {
                                    cursor.close();
                                }
                                throw th;
                            }
                        }
                        if (query != null) {
                            query.close();
                        }
                        fontsContractCompat$FontInfoArr = (FontsContractCompat$FontInfo[]) arrayList3.toArray(new FontsContractCompat$FontInfo[0]);
                        obj = null;
                    } catch (Throwable th3) {
                        th = th3;
                        cursor = null;
                        if (cursor != null) {
                            cursor.close();
                        }
                        throw th;
                    }
                }
                if (obj != null) {
                    columnIndex = -2;
                } else if (fontsContractCompat$FontInfoArr != null) {
                    columnIndex = fontsContractCompat$FontInfoArr.length;
                    if (columnIndex == 0) {
                        columnIndex = 1;
                    } else {
                        columnIndex3 = 0;
                        while (columnIndex3 < columnIndex) {
                            columnIndex2 = fontsContractCompat$FontInfoArr[columnIndex3].mResultCode;
                            if (columnIndex2 != 0) {
                                columnIndex = columnIndex2 < 0 ? -3 : columnIndex2;
                            } else {
                                columnIndex3++;
                            }
                        }
                        columnIndex = 0;
                    }
                } else {
                    columnIndex = 1;
                }
                if (columnIndex != 0) {
                    return new TypefaceResult(columnIndex);
                }
                LruCache lruCache = TypefaceCompat.sTypefaceCache;
                ContentResolver contentResolver = context.getContentResolver();
                try {
                    FontFamily.Builder builder = null;
                    for (FontsContractCompat$FontInfo fontsContractCompat$FontInfo : fontsContractCompat$FontInfoArr) {
                        try {
                            ParcelFileDescriptor openFileDescriptor;
                            try {
                                openFileDescriptor = contentResolver.openFileDescriptor(fontsContractCompat$FontInfo.mUri, "r", null);
                                if (openFileDescriptor != null) {
                                    Font build3 = new Font.Builder(openFileDescriptor).setWeight(fontsContractCompat$FontInfo.mWeight).setSlant(fontsContractCompat$FontInfo.mItalic).setTtcIndex(fontsContractCompat$FontInfo.mTtcIndex).build();
                                    if (builder == null) {
                                        builder = new FontFamily.Builder(build3);
                                    } else {
                                        builder.addFont(build3);
                                    }
                                    try {
                                        openFileDescriptor.close();
                                    } catch (IOException e) {
                                    }
                                }
                            } catch (IOException e2) {
                            } catch (Throwable th4) {
                            }
                        } catch (IOException e3) {
                        }
                    }
                    typeface = null;
                    if (builder == null) {
                        typeface2 = null;
                    } else {
                        try {
                            int i7;
                            int i8;
                            if (1 != (i & 1)) {
                                i7 = 400;
                            } else {
                                i7 = 700;
                            }
                            if ((i & 2) != 0) {
                                i8 = 1;
                            } else {
                                i8 = 0;
                            }
                            typeface2 = new CustomFallbackBuilder(builder.build()).setStyle(new FontStyle(i7, i8)).build();
                        } catch (Exception e4) {
                            typeface2 = typeface;
                            if (typeface2 != null) {
                                return new TypefaceResult(-3);
                            }
                            sTypefaceCache.put(str2, typeface2);
                            return new TypefaceResult(typeface2);
                        }
                    }
                } catch (Exception e5) {
                    typeface = null;
                    typeface2 = typeface;
                    if (typeface2 != null) {
                        return new TypefaceResult(-3);
                    }
                    sTypefaceCache.put(str2, typeface2);
                    return new TypefaceResult(typeface2);
                }
                if (typeface2 != null) {
                    return new TypefaceResult(-3);
                }
                sTypefaceCache.put(str2, typeface2);
                return new TypefaceResult(typeface2);
            } else {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Found content provider ");
                stringBuilder2.append(str10);
                stringBuilder2.append(", but package was not ");
                stringBuilder2.append(fontRequest2.mProviderPackage);
                throw new NameNotFoundException(stringBuilder2.toString());
            }
        } catch (NameNotFoundException e6) {
            return new TypefaceResult(-1);
        }
    }
}
