package androidx.core.math;

/* compiled from: PG */
public final class MathUtils {
    public static int clamp(int i, int i2, int i3) {
        return i < i2 ? i2 : i > i3 ? i3 : i;
    }

    public static float clamp$ar$ds(float f, float f2) {
        return f < 0.0f ? 0.0f : f > f2 ? f2 : f;
    }
}
