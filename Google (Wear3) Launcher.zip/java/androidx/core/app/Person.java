package androidx.core.app;

import android.support.p000v4.graphics.drawable.IconCompat;

/* compiled from: PG */
public final class Person {
    final IconCompat mIcon;
    final boolean mIsBot;
    final boolean mIsImportant;
    public final String mKey;
    public final CharSequence mName;
    final String mUri;

    /* compiled from: PG */
    public final class Builder {
        public IconCompat mIcon;
        public boolean mIsBot;
        public boolean mIsImportant;
        public String mKey;
        public CharSequence mName;
        public String mUri;

        public final Person build() {
            return new Person(this);
        }
    }

    public Person(Builder builder) {
        this.mName = builder.mName;
        this.mIcon = builder.mIcon;
        this.mUri = builder.mUri;
        this.mKey = builder.mKey;
        this.mIsBot = builder.mIsBot;
        this.mIsImportant = builder.mIsImportant;
    }

    public final android.app.Person toAndroidPerson() {
        android.app.Person.Builder name = new android.app.Person.Builder().setName(this.mName);
        IconCompat iconCompat = this.mIcon;
        return name.setIcon(iconCompat != null ? iconCompat.toIcon() : null).setUri(this.mUri).setKey(this.mKey).setBot(this.mIsBot).setImportant(this.mIsImportant).build();
    }
}
