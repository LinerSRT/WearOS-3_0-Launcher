package androidx.core.app;

import android.app.Activity;
import android.text.TextUtils;
import androidx.core.content.ContextCompat;
import java.util.Arrays;

/* compiled from: PG */
public final class ActivityCompat extends ContextCompat {

    /* compiled from: PG */
    public interface RequestPermissionsRequestCodeValidator {
    }

    public static void requestPermissions(Activity activity, String[] strArr, int i) {
        for (CharSequence isEmpty : strArr) {
            if (TextUtils.isEmpty(isEmpty)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Permission request for permissions ");
                stringBuilder.append(Arrays.toString(strArr));
                stringBuilder.append(" must not contain null or empty values");
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        if (activity instanceof RequestPermissionsRequestCodeValidator) {
            RequestPermissionsRequestCodeValidator requestPermissionsRequestCodeValidator = (RequestPermissionsRequestCodeValidator) activity;
        }
        activity.requestPermissions(strArr, i);
    }
}
