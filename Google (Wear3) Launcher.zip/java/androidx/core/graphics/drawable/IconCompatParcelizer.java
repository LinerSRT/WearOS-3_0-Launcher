package androidx.core.graphics.drawable;

import android.os.Parcelable;
import android.support.p000v4.graphics.drawable.IconCompat;
import androidx.versionedparcelable.VersionedParcel;
import java.nio.charset.Charset;

/* compiled from: PG */
public class IconCompatParcelizer {
    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.support.p000v4.graphics.drawable.IconCompat read(androidx.versionedparcelable.VersionedParcel r5) {
        /*
        r0 = new android.support.v4.graphics.drawable.IconCompat;
        r0.<init>();
        r1 = r0.mType;
        r2 = 1;
        r1 = r5.readInt(r1, r2);
        r0.mType = r1;
        r1 = r0.mData;
        r2 = 2;
        r1 = r5.readByteArray(r1, r2);
        r0.mData = r1;
        r1 = r0.mParcelable;
        r3 = 3;
        r1 = r5.readParcelable(r1, r3);
        r0.mParcelable = r1;
        r1 = r0.mInt1;
        r4 = 4;
        r1 = r5.readInt(r1, r4);
        r0.mInt1 = r1;
        r1 = r0.mInt2;
        r4 = 5;
        r1 = r5.readInt(r1, r4);
        r0.mInt2 = r1;
        r1 = r0.mTintList;
        r4 = 6;
        r1 = r5.readParcelable(r1, r4);
        r1 = (android.content.res.ColorStateList) r1;
        r0.mTintList = r1;
        r1 = r0.mTintModeStr;
        r4 = 7;
        r1 = r5.readString(r1, r4);
        r0.mTintModeStr = r1;
        r1 = r0.mString1;
        r4 = 8;
        r5 = r5.readString(r1, r4);
        r0.mString1 = r5;
        r5 = r0.mTintModeStr;
        r5 = android.graphics.PorterDuff.Mode.valueOf(r5);
        r0.mTintMode = r5;
        r5 = r0.mType;
        r1 = 0;
        switch(r5) {
            case -1: goto L_0x009c;
            case 0: goto L_0x005e;
            case 1: goto L_0x008b;
            case 2: goto L_0x0064;
            case 3: goto L_0x005f;
            case 4: goto L_0x0064;
            case 5: goto L_0x008b;
            case 6: goto L_0x0064;
            default: goto L_0x005e;
        };
    L_0x005e:
        goto L_0x00ab;
    L_0x005f:
        r5 = r0.mData;
        r0.mObj1 = r5;
        goto L_0x00ab;
    L_0x0064:
        r5 = new java.lang.String;
        r3 = r0.mData;
        r4 = "UTF-16";
        r4 = java.nio.charset.Charset.forName(r4);
        r5.<init>(r3, r4);
        r0.mObj1 = r5;
        r5 = r0.mType;
        if (r5 != r2) goto L_0x00ab;
    L_0x0077:
        r5 = r0.mString1;
        if (r5 != 0) goto L_0x00ab;
    L_0x007b:
        r5 = r0.mObj1;
        r5 = (java.lang.String) r5;
        r2 = -1;
        r3 = ":";
        r5 = r5.split(r3, r2);
        r5 = r5[r1];
        r0.mString1 = r5;
        goto L_0x00ab;
    L_0x008b:
        r5 = r0.mParcelable;
        if (r5 == 0) goto L_0x0090;
    L_0x008f:
        goto L_0x00a0;
    L_0x0090:
        r5 = r0.mData;
        r0.mObj1 = r5;
        r0.mType = r3;
        r0.mInt1 = r1;
        r5 = r5.length;
        r0.mInt2 = r5;
        goto L_0x00ab;
    L_0x009c:
        r5 = r0.mParcelable;
        if (r5 == 0) goto L_0x00a3;
    L_0x00a0:
        r0.mObj1 = r5;
        goto L_0x00ab;
    L_0x00a3:
        r5 = new java.lang.IllegalArgumentException;
        r0 = "Invalid icon";
        r5.<init>(r0);
        throw r5;
    L_0x00ab:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompatParcelizer.read(androidx.versionedparcelable.VersionedParcel):android.support.v4.graphics.drawable.IconCompat");
    }

    public static void write(IconCompat iconCompat, VersionedParcel versionedParcel) {
        iconCompat.mTintModeStr = iconCompat.mTintMode.name();
        String str = "UTF-16";
        switch (iconCompat.mType) {
            case -1:
                iconCompat.mParcelable = (Parcelable) iconCompat.mObj1;
                break;
            case 1:
            case 5:
                iconCompat.mParcelable = (Parcelable) iconCompat.mObj1;
                break;
            case 2:
                iconCompat.mData = ((String) iconCompat.mObj1).getBytes(Charset.forName(str));
                break;
            case 3:
                iconCompat.mData = (byte[]) iconCompat.mObj1;
                break;
            case 4:
            case 6:
                iconCompat.mData = iconCompat.mObj1.toString().getBytes(Charset.forName(str));
                break;
            default:
                break;
        }
        int i = iconCompat.mType;
        if (i != -1) {
            versionedParcel.writeInt(i, 1);
        }
        byte[] bArr = iconCompat.mData;
        if (bArr != null) {
            versionedParcel.writeByteArray(bArr, 2);
        }
        Parcelable parcelable = iconCompat.mParcelable;
        if (parcelable != null) {
            versionedParcel.writeParcelable(parcelable, 3);
        }
        i = iconCompat.mInt1;
        if (i != 0) {
            versionedParcel.writeInt(i, 4);
        }
        i = iconCompat.mInt2;
        if (i != 0) {
            versionedParcel.writeInt(i, 5);
        }
        parcelable = iconCompat.mTintList;
        if (parcelable != null) {
            versionedParcel.writeParcelable(parcelable, 6);
        }
        String str2 = iconCompat.mTintModeStr;
        if (str2 != null) {
            versionedParcel.writeString(str2, 7);
        }
        String str3 = iconCompat.mString1;
        if (str3 != null) {
            versionedParcel.writeString(str3, 8);
        }
    }
}
