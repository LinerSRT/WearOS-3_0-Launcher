package androidx.core.content;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Process;
import android.support.p000v4.util.ObjectsCompat;
import java.io.File;
import java.util.concurrent.Executor;

/* compiled from: PG */
public class ContextCompat {

    /* compiled from: PG */
    public final class Api16Impl {
        public static void startActivities(Context context, Intent[] intentArr, Bundle bundle) {
            context.startActivities(intentArr, null);
        }
    }

    /* compiled from: PG */
    public final class Api19Impl {
        public static File[] getExternalCacheDirs(Context context) {
            return context.getExternalCacheDirs();
        }

        public static File[] getExternalFilesDirs(Context context, String str) {
            return context.getExternalFilesDirs(null);
        }
    }

    /* compiled from: PG */
    public final class Api21Impl {
        public static Drawable getDrawable(Context context, int i) {
            return context.getDrawable(i);
        }
    }

    /* compiled from: PG */
    public final class Api23Impl {
        public static int getColor(Context context, int i) {
            return context.getColor(i);
        }
    }

    /* compiled from: PG */
    public final class Api24Impl {
        public static Context createDeviceProtectedStorageContext(Context context) {
            return context.createDeviceProtectedStorageContext();
        }

        public static File getDataDir(Context context) {
            return context.getDataDir();
        }
    }

    /* compiled from: PG */
    public final class Api28Impl {
        public static Executor getMainExecutor(Context context) {
            return context.getMainExecutor();
        }
    }

    public static int checkSelfPermission(Context context, String str) {
        ObjectsCompat.requireNonNull$ar$ds(str, "permission must be non-null");
        return context.checkPermission(str, Process.myPid(), Process.myUid());
    }
}
