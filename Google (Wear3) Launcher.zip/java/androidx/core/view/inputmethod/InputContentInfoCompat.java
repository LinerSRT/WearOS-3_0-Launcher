package androidx.core.view.inputmethod;

import android.view.inputmethod.InputContentInfo;

/* compiled from: PG */
public final class InputContentInfoCompat {
    public final InputContentInfoCompatApi25Impl mImpl$ar$class_merging$9962a48d_0;

    /* compiled from: PG */
    public final class InputContentInfoCompatApi25Impl {
        final InputContentInfo mObject;

        public InputContentInfoCompatApi25Impl(Object obj) {
            this.mObject = (InputContentInfo) obj;
        }
    }

    public InputContentInfoCompat(InputContentInfoCompatApi25Impl inputContentInfoCompatApi25Impl) {
        this.mImpl$ar$class_merging$9962a48d_0 = inputContentInfoCompatApi25Impl;
    }
}
