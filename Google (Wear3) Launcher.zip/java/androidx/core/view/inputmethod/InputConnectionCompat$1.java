package androidx.core.view.inputmethod;

import android.content.ClipData;
import android.content.ClipData.Item;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.p000v4.view.ContentInfoCompat.Builder;
import android.support.p000v4.view.ContentInfoCompat.BuilderCompat;
import android.support.p000v4.view.ContentInfoCompat.BuilderCompat31Impl;
import android.support.p000v4.view.ContentInfoCompat.BuilderCompatImpl;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.widget.AppCompatReceiveContentHelper$1;
import android.util.Log;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputContentInfo;
import androidx.core.view.inputmethod.InputContentInfoCompat.InputContentInfoCompatApi25Impl;

/* compiled from: PG */
public final class InputConnectionCompat$1 extends InputConnectionWrapper {
    final /* synthetic */ AppCompatReceiveContentHelper$1 val$listener$ar$class_merging$6b08f865_0;

    public InputConnectionCompat$1(InputConnection inputConnection, AppCompatReceiveContentHelper$1 appCompatReceiveContentHelper$1) {
        this.val$listener$ar$class_merging$6b08f865_0 = appCompatReceiveContentHelper$1;
        super(inputConnection, false);
    }

    public final boolean commitContent(InputContentInfo inputContentInfo, int i, Bundle bundle) {
        InputContentInfoCompat inputContentInfoCompat;
        Bundle bundle2;
        BuilderCompat builderCompat31Impl;
        AppCompatReceiveContentHelper$1 appCompatReceiveContentHelper$1 = this.val$listener$ar$class_merging$6b08f865_0;
        if (inputContentInfo == null) {
            inputContentInfoCompat = null;
        } else {
            inputContentInfoCompat = new InputContentInfoCompat(new InputContentInfoCompatApi25Impl(inputContentInfo));
        }
        if ((i & 1) != 0) {
            try {
                inputContentInfoCompat.mImpl$ar$class_merging$9962a48d_0.mObject.requestPermission();
                InputContentInfo inputContentInfo2 = inputContentInfoCompat.mImpl$ar$class_merging$9962a48d_0.mObject;
                bundle2 = bundle == null ? new Bundle() : new Bundle(bundle);
                bundle2.putParcelable("android.support.v4.view.extra.INPUT_CONTENT_INFO", inputContentInfo2);
            } catch (Throwable e) {
                Log.w("ReceiveContent", "Can't insert content from IME; requestPermission() failed", e);
            }
        } else {
            bundle2 = bundle;
        }
        ClipData clipData = new ClipData(inputContentInfoCompat.mImpl$ar$class_merging$9962a48d_0.mObject.getDescription(), new Item(inputContentInfoCompat.mImpl$ar$class_merging$9962a48d_0.mObject.getContentUri()));
        if (VERSION.SDK_INT >= 31) {
            builderCompat31Impl = new BuilderCompat31Impl(clipData, 2);
        } else {
            builderCompat31Impl = new BuilderCompatImpl(clipData, 2);
        }
        builderCompat31Impl.setLinkUri(inputContentInfoCompat.mImpl$ar$class_merging$9962a48d_0.mObject.getLinkUri());
        builderCompat31Impl.setExtras(bundle2);
        if (ViewCompat.performReceiveContent(appCompatReceiveContentHelper$1.val$view, Builder.build$ar$objectUnboxing$9e7ca98a_0(builderCompat31Impl)) == null) {
            return true;
        }
        return super.commitContent(inputContentInfo, i, bundle);
    }
}
