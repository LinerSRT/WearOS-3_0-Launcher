package androidx.core.p003os;

import android.os.Build.VERSION;

/* compiled from: PG */
/* renamed from: androidx.core.os.BuildCompat */
public final class BuildCompat {
    public static boolean isAtLeastS() {
        if (VERSION.SDK_INT < 31) {
            String str = VERSION.CODENAME;
            if (!"REL".equals(str)) {
                if (str.compareTo("S") >= 0) {
                }
            }
            return false;
        }
        return true;
    }
}
