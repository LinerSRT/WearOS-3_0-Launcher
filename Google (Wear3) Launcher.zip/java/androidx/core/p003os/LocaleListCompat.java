package androidx.core.p003os;

import android.os.LocaleList;
import java.util.Locale;

/* compiled from: PG */
/* renamed from: androidx.core.os.LocaleListCompat */
public final class LocaleListCompat {
    public final LocaleListPlatformWrapper mImpl$ar$class_merging$681fc2a2_0;

    public LocaleListCompat(LocaleListPlatformWrapper localeListPlatformWrapper) {
        this.mImpl$ar$class_merging$681fc2a2_0 = localeListPlatformWrapper;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof LocaleListCompat) && this.mImpl$ar$class_merging$681fc2a2_0.equals(((LocaleListCompat) obj).mImpl$ar$class_merging$681fc2a2_0);
    }

    public final int hashCode() {
        return this.mImpl$ar$class_merging$681fc2a2_0.hashCode();
    }

    public final String toString() {
        return this.mImpl$ar$class_merging$681fc2a2_0.toString();
    }

    static {
        LocaleList localeList = new LocaleList(new Locale[0]);
    }
}
