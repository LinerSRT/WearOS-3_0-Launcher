package androidx.core.p003os;

import android.os.LocaleList;

/* compiled from: PG */
/* renamed from: androidx.core.os.LocaleListPlatformWrapper */
public final class LocaleListPlatformWrapper {
    public final LocaleList mLocaleList;

    public LocaleListPlatformWrapper(LocaleList localeList) {
        this.mLocaleList = localeList;
    }

    public final boolean equals(Object obj) {
        return this.mLocaleList.equals(((LocaleListPlatformWrapper) obj).mLocaleList);
    }

    public final int hashCode() {
        return this.mLocaleList.hashCode();
    }

    public final String toString() {
        return this.mLocaleList.toString();
    }
}
