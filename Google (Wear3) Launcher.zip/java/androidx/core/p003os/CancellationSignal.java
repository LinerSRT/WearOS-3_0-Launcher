package androidx.core.p003os;

/* compiled from: PG */
/* renamed from: androidx.core.os.CancellationSignal */
public final class CancellationSignal {
    public boolean mCancelInProgress;
    public boolean mIsCanceled;
    public OnCancelListener mOnCancelListener;

    /* compiled from: PG */
    /* renamed from: androidx.core.os.CancellationSignal$OnCancelListener */
    public interface OnCancelListener {
        void onCancel();
    }

    public final void setOnCancelListener(OnCancelListener onCancelListener) {
        synchronized (this) {
            while (this.mCancelInProgress) {
                try {
                    wait();
                } catch (InterruptedException e) {
                }
            }
            if (this.mOnCancelListener == onCancelListener) {
                return;
            }
            this.mOnCancelListener = onCancelListener;
            if (this.mIsCanceled) {
                if (onCancelListener != null) {
                    onCancelListener.onCancel();
                    return;
                }
            }
        }
    }
}
