package androidx.interpolator.view.animation;

/* compiled from: PG */
final class LookupTableInterpolator {
    static float interpolate$ar$ds(float[] fArr, float f) {
        if (f >= 1.0f) {
            return 1.0f;
        }
        if (f <= 0.0f) {
            return 0.0f;
        }
        int min = Math.min((int) (200.0f * f), 199);
        float f2 = fArr[min];
        return f2 + (((f - (((float) min) * 0.005f)) / 0.005f) * (fArr[min + 1] - f2));
    }
}
