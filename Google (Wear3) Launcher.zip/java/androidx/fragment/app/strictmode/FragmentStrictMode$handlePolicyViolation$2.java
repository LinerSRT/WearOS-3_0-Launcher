package androidx.fragment.app.strictmode;

import android.util.Log;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PG */
final class FragmentStrictMode$handlePolicyViolation$2 implements Runnable {
    final /* synthetic */ String $fragmentName;
    final /* synthetic */ Violation $violation;

    public FragmentStrictMode$handlePolicyViolation$2(String str, Violation violation) {
        this.$fragmentName = str;
        this.$violation = violation;
    }

    public final void run() {
        String str = "FragmentStrictMode";
        Log.e(str, Intrinsics.stringPlus("Policy violation with PENALTY_DEATH in ", this.$fragmentName), this.$violation);
        throw this.$violation;
    }
}
