package androidx.fragment.app.strictmode;

import android.support.p000v4.app.Fragment;

/* compiled from: PG */
public final class SetTargetFragmentUsageViolation extends TargetFragmentUsageViolation {
    public SetTargetFragmentUsageViolation(Fragment fragment, Fragment fragment2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attempting to set target fragment ");
        stringBuilder.append(fragment2);
        stringBuilder.append(" with request code 0 for fragment ");
        stringBuilder.append(fragment);
        super(fragment, stringBuilder.toString());
    }
}
