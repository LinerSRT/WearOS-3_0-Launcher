package androidx.fragment.app.strictmode;

import android.support.p000v4.app.Fragment;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PG */
public final class GetTargetFragmentUsageViolation extends TargetFragmentUsageViolation {
    public GetTargetFragmentUsageViolation(Fragment fragment) {
        super(fragment, Intrinsics.stringPlus("Attempting to get target fragment from fragment ", fragment));
    }
}
