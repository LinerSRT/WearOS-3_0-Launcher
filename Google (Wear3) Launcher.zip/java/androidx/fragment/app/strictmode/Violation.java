package androidx.fragment.app.strictmode;

import android.support.p000v4.app.Fragment;

/* compiled from: PG */
public class Violation extends RuntimeException {
    public final Fragment fragment;

    public Violation(Fragment fragment, String str) {
        super(str);
        this.fragment = fragment;
    }
}
