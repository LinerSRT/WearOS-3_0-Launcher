package androidx.fragment.app.strictmode;

import android.support.p000v4.app.Fragment;
import android.view.ViewGroup;

/* compiled from: PG */
public final class WrongFragmentContainerViolation extends Violation {
    public WrongFragmentContainerViolation(Fragment fragment, ViewGroup viewGroup) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attempting to add fragment ");
        stringBuilder.append(fragment);
        stringBuilder.append(" to container ");
        stringBuilder.append(viewGroup);
        stringBuilder.append(" which is not a FragmentContainerView");
        super(fragment, stringBuilder.toString());
    }
}
