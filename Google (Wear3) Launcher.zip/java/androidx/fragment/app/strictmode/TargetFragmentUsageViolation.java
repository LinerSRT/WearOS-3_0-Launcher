package androidx.fragment.app.strictmode;

import android.support.p000v4.app.Fragment;

/* compiled from: PG */
public class TargetFragmentUsageViolation extends Violation {
    public TargetFragmentUsageViolation(Fragment fragment, String str) {
        super(fragment, str);
    }
}
