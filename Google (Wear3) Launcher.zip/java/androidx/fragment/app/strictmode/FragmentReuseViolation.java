package androidx.fragment.app.strictmode;

import android.support.p000v4.app.Fragment;

/* compiled from: PG */
public final class FragmentReuseViolation extends Violation {
    public FragmentReuseViolation(Fragment fragment, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attempting to reuse fragment ");
        stringBuilder.append(fragment);
        stringBuilder.append(" with previous ID ");
        stringBuilder.append(str);
        super(fragment, stringBuilder.toString());
    }
}
