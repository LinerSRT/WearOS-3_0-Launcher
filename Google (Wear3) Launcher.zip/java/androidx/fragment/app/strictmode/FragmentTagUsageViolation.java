package androidx.fragment.app.strictmode;

import android.support.p000v4.app.Fragment;
import android.view.ViewGroup;

/* compiled from: PG */
public final class FragmentTagUsageViolation extends Violation {
    public FragmentTagUsageViolation(Fragment fragment, ViewGroup viewGroup) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attempting to use <fragment> tag to add fragment ");
        stringBuilder.append(fragment);
        stringBuilder.append(" to container ");
        stringBuilder.append(viewGroup);
        super(fragment, stringBuilder.toString());
    }
}
