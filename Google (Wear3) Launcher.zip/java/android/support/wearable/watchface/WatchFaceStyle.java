package android.support.wearable.watchface;

import android.content.ComponentName;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PG */
public class WatchFaceStyle implements Parcelable {
    public static final Creator CREATOR = new WatchFaceStyle$Companion$CREATOR$1();
    public final int accentColor;
    public final boolean acceptsTapEvents;
    public final Bundle compatBundle;
    public final ComponentName component;
    public final boolean hideNotificationIndicator;
    public final boolean showUnreadCountIndicator;
    public final int statusBarGravity;
    public final int viewProtectionMode;

    public WatchFaceStyle(ComponentName componentName, int i, int i2, int i3, boolean z, boolean z2, boolean z3, Bundle bundle) {
        this.component = componentName;
        this.viewProtectionMode = i;
        this.statusBarGravity = i2;
        this.accentColor = i3;
        this.showUnreadCountIndicator = z;
        this.hideNotificationIndicator = z2;
        this.acceptsTapEvents = z3;
        this.compatBundle = bundle;
    }

    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        Object obj2;
        Class cls = getClass();
        if (obj == null) {
            obj2 = null;
        } else {
            obj2 = obj.getClass();
        }
        if (!Intrinsics.areEqual(cls, obj2)) {
            return false;
        }
        if (obj != null) {
            WatchFaceStyle watchFaceStyle = (WatchFaceStyle) obj;
            return Intrinsics.areEqual(this.component, watchFaceStyle.component) && this.viewProtectionMode == watchFaceStyle.viewProtectionMode && this.statusBarGravity == watchFaceStyle.statusBarGravity && this.accentColor == watchFaceStyle.accentColor && this.showUnreadCountIndicator == watchFaceStyle.showUnreadCountIndicator && this.hideNotificationIndicator == watchFaceStyle.hideNotificationIndicator && this.acceptsTapEvents == watchFaceStyle.acceptsTapEvents;
        } else {
            throw new NullPointerException("null cannot be cast to non-null type android.support.wearable.watchface.WatchFaceStyle");
        }
    }

    public final int hashCode() {
        return (((((((((((this.component.hashCode() * 31) + this.viewProtectionMode) * 31) + this.statusBarGravity) * 31) + this.accentColor) * 31) + WatchFaceStyle$$ExternalSyntheticBackport0.m2m(this.showUnreadCountIndicator)) * 31) + WatchFaceStyle$$ExternalSyntheticBackport0.m2m(this.hideNotificationIndicator)) * 31) + WatchFaceStyle$$ExternalSyntheticBackport0.m2m(this.acceptsTapEvents);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.getClass();
        Bundle bundle = new Bundle();
        bundle.putParcelable("component", this.component);
        bundle.putInt("viewProtectionMode", this.viewProtectionMode);
        bundle.putInt("statusBarGravity", this.statusBarGravity);
        bundle.putInt("accentColor", this.accentColor);
        bundle.putBoolean("showUnreadIndicator", this.showUnreadCountIndicator);
        bundle.putBoolean("hideNotificationIndicator", this.hideNotificationIndicator);
        bundle.putBoolean("acceptsTapEvents", this.acceptsTapEvents);
        Bundle bundle2 = this.compatBundle;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        parcel.writeBundle(bundle);
    }
}
