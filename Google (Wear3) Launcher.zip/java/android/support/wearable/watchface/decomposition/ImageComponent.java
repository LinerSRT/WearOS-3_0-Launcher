package android.support.wearable.watchface.decomposition;

import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.wearable.watchface.decomposition.BaseComponent.ComponentFactory;
import android.support.wearable.watchface.decomposition.BaseDrawnComponent.BaseDrawnBuilder;
import android.support.wearable.watchface.decomposition.WatchFaceDecomposition.Component;

/* compiled from: PG */
public class ImageComponent extends BaseDrawnComponent implements Parcelable {
    public static final Creator CREATOR = new PG();

    /* renamed from: android.support.wearable.watchface.decomposition.ImageComponent$1 */
    class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ImageComponent[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ImageComponent(parcel);
        }
    }

    /* compiled from: PG */
    public class Builder extends BaseDrawnBuilder {

        /* renamed from: android.support.wearable.watchface.decomposition.ImageComponent$Builder$1 */
        class PG implements ComponentFactory {
            public final /* bridge */ /* synthetic */ Component buildComponent(Bundle bundle) {
                return new ImageComponent(bundle);
            }
        }

        public Builder() {
            super(new PG());
        }

        public final void validate() {
            String str = "component_id";
            String str2 = "Component id must be provided";
            if (!this.fields.containsKey(str)) {
                throw new IllegalStateException(str2);
            } else if (this.fields.getInt(str) <= 100000) {
                String str3 = "display_modes";
                if (!this.fields.containsKey(str3)) {
                    this.fields.putInt(str3, 3);
                }
                int i = this.fields.getInt(str3);
                if (!(i == 1 || i == 2)) {
                    if (i != 3) {
                        throw new IllegalStateException("Display modes must be ambient, interactive, or both");
                    }
                }
                if (!this.fields.containsKey(str)) {
                    throw new IllegalStateException(str2);
                } else if (this.fields.getParcelable("image") != null) {
                    str = "bounds";
                    if (!this.fields.containsKey(str)) {
                        this.fields.putParcelable(str, new RectF(0.0f, 0.0f, 1.0f, 1.0f));
                    }
                    if (this.fields.getFloat("degreesPerDay") > 0.0f) {
                        str = "pivot";
                        if (this.fields.getParcelable(str) == null) {
                            this.fields.putParcelable(str, new PointF(0.5f, 0.5f));
                        }
                    }
                } else {
                    throw new IllegalStateException("Image must be provided");
                }
            } else {
                throw new IllegalStateException("Component id greater than maximum");
            }
        }
    }

    public ImageComponent(Bundle bundle) {
        super(bundle);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeBundle(this.fields);
    }

    public ImageComponent(Parcel parcel) {
        super(parcel.readBundle());
        this.fields.setClassLoader(getClass().getClassLoader());
    }
}
