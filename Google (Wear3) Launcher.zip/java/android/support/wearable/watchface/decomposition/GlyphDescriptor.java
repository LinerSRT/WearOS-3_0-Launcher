package android.support.wearable.watchface.decomposition;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

/* compiled from: PG */
public class GlyphDescriptor implements Parcelable {
    public static final Creator CREATOR = new PG();
    public char glyphCode;
    public short width;

    /* renamed from: android.support.wearable.watchface.decomposition.GlyphDescriptor$1 */
    class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new GlyphDescriptor[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new GlyphDescriptor(parcel);
        }
    }

    protected GlyphDescriptor(Parcel parcel) {
        this.width = (short) parcel.readInt();
        this.glyphCode = (char) parcel.readInt();
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.width);
        parcel.writeInt(this.glyphCode);
    }
}
