package android.support.wearable.watchface.decomposition;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.wearable.watchface.decomposition.BaseComponent.ComponentFactory;
import android.support.wearable.watchface.decomposition.BaseDrawnComponent.BaseDrawnBuilder;
import android.support.wearable.watchface.decomposition.WatchFaceDecomposition.Component;

/* compiled from: PG */
public class ColorStringComponent extends BaseDrawnComponent implements Parcelable {
    public static final Creator CREATOR = new PG();

    /* renamed from: android.support.wearable.watchface.decomposition.ColorStringComponent$1 */
    class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ColorStringComponent[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ColorStringComponent(parcel);
        }
    }

    /* compiled from: PG */
    public class Builder extends BaseDrawnBuilder {

        /* renamed from: android.support.wearable.watchface.decomposition.ColorStringComponent$Builder$1 */
        class PG implements ComponentFactory {
            public final /* bridge */ /* synthetic */ Component buildComponent(Bundle bundle) {
                return new ColorStringComponent(bundle);
            }
        }

        public Builder() {
            super(new PG());
        }
    }

    public ColorStringComponent(Bundle bundle) {
        super(bundle);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeBundle(this.fields);
    }

    public ColorStringComponent(Parcel parcel) {
        super(parcel.readBundle());
        this.fields.setClassLoader(getClass().getClassLoader());
    }
}
