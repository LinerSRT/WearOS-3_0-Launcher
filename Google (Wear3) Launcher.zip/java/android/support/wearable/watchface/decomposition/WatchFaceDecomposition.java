package android.support.wearable.watchface.decomposition;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
public class WatchFaceDecomposition implements Parcelable {
    public static final Creator CREATOR = new PG();
    public final int colorFormat;
    public final List colorNumbers;
    private final List colorStrings;
    public final List complications;
    private final boolean convertUnits;
    public final List customFonts;
    public final List dateTimes;
    public final List fonts;
    public final List images;
    public final List numbers;

    /* renamed from: android.support.wearable.watchface.decomposition.WatchFaceDecomposition$1 */
    class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new WatchFaceDecomposition[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new WatchFaceDecomposition(parcel);
        }
    }

    /* compiled from: PG */
    public class Builder {
        public Builder() {
            ArrayList arrayList = new ArrayList();
            arrayList = new ArrayList();
            arrayList = new ArrayList();
            arrayList = new ArrayList();
            arrayList = new ArrayList();
            arrayList = new ArrayList();
            arrayList = new ArrayList();
            arrayList = new ArrayList();
        }
    }

    @Retention(RetentionPolicy.SOURCE)
    /* compiled from: PG */
    public @interface ColorFormat {
    }

    /* compiled from: PG */
    public interface Component {
    }

    /* compiled from: PG */
    public interface DrawnComponent extends Component {
    }

    public WatchFaceDecomposition(Parcel parcel) {
        Bundle readBundle = parcel.readBundle(getClass().getClassLoader());
        List parcelableArrayList = readBundle.getParcelableArrayList("images");
        List parcelableArrayList2 = readBundle.getParcelableArrayList("numbers");
        List parcelableArrayList3 = readBundle.getParcelableArrayList("color_numbers");
        List parcelableArrayList4 = readBundle.getParcelableArrayList("color_strings");
        List parcelableArrayList5 = readBundle.getParcelableArrayList("date_times");
        List parcelableArrayList6 = readBundle.getParcelableArrayList("fonts");
        List parcelableArrayList7 = readBundle.getParcelableArrayList("custom_fonts");
        List parcelableArrayList8 = readBundle.getParcelableArrayList("complications");
        if (parcelableArrayList == null) {
            parcelableArrayList = Collections.emptyList();
        }
        this.images = parcelableArrayList;
        if (parcelableArrayList2 == null) {
            parcelableArrayList2 = Collections.emptyList();
        }
        this.numbers = parcelableArrayList2;
        if (parcelableArrayList3 == null) {
            parcelableArrayList3 = Collections.emptyList();
        }
        this.colorNumbers = parcelableArrayList3;
        if (parcelableArrayList4 == null) {
            parcelableArrayList4 = Collections.emptyList();
        }
        this.colorStrings = parcelableArrayList4;
        if (parcelableArrayList5 == null) {
            parcelableArrayList5 = Collections.emptyList();
        }
        this.dateTimes = parcelableArrayList5;
        if (parcelableArrayList6 == null) {
            parcelableArrayList6 = Collections.emptyList();
        }
        this.fonts = parcelableArrayList6;
        if (parcelableArrayList7 == null) {
            parcelableArrayList7 = Collections.emptyList();
        }
        this.customFonts = parcelableArrayList7;
        if (parcelableArrayList8 == null) {
            parcelableArrayList8 = Collections.emptyList();
        }
        this.complications = parcelableArrayList8;
        this.convertUnits = readBundle.getBoolean("convert_units");
        this.colorFormat = readBundle.getInt("color_format");
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("images", new ArrayList(this.images));
        bundle.putParcelableArrayList("numbers", new ArrayList(this.numbers));
        bundle.putParcelableArrayList("color_numbers", new ArrayList(this.colorNumbers));
        bundle.putParcelableArrayList("color_strings", new ArrayList(this.colorStrings));
        bundle.putParcelableArrayList("date_times", new ArrayList(this.dateTimes));
        bundle.putParcelableArrayList("fonts", new ArrayList(this.fonts));
        bundle.putParcelableArrayList("custom_fonts", new ArrayList(this.customFonts));
        bundle.putParcelableArrayList("complications", new ArrayList(this.complications));
        bundle.putBoolean("convert_units", this.convertUnits);
        bundle.putInt("color_format", this.colorFormat);
        parcel.writeBundle(bundle);
    }
}
