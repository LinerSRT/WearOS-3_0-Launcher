package android.support.wearable.watchface.decomposition;

import android.os.Bundle;
import android.support.wearable.watchface.decomposition.WatchFaceDecomposition.Component;

/* compiled from: PG */
abstract class BaseComponent implements Component {
    public final Bundle fields;

    /* compiled from: PG */
    public abstract class BaseBuilder {
        public final ComponentFactory factory;
        public final Bundle fields = new Bundle();

        public BaseBuilder(ComponentFactory componentFactory) {
            this.factory = componentFactory;
        }

        public void validate() {
            throw null;
        }
    }

    /* compiled from: PG */
    public interface ComponentFactory {
        Component buildComponent(Bundle bundle);
    }

    public BaseComponent(Bundle bundle) {
        this.fields = bundle;
    }

    public final int getComponentId() {
        return this.fields.getInt("component_id");
    }

    public final boolean isAmbient() {
        return (this.fields.getInt("display_modes") & 1) != 0;
    }
}
