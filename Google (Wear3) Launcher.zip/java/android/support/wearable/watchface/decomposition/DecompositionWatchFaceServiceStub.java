package android.support.wearable.watchface.decomposition;

import android.content.ComponentName;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.support.wearable.watchface.IWatchFaceService.Stub;
import android.support.wearable.watchface.IWatchFaceUpdateDecompositionCallback$Stub$Proxy;
import android.support.wearable.watchface.WatchFaceStyle;
import android.support.wearable.watchface.accessibility.ContentDescriptionLabel;
import com.google.android.aidl.Codecs;

/* compiled from: PG */
public abstract class DecompositionWatchFaceServiceStub extends Stub {
    public void updateDecomposition(WatchFaceDecomposition watchFaceDecomposition) {
    }

    protected final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (i == 6) {
            updateDecomposition((WatchFaceDecomposition) Codecs.createParcelable(parcel, WatchFaceDecomposition.CREATOR));
            parcel2.writeNoException();
            return true;
        } else if (i == 9) {
            WatchFaceDecomposition watchFaceDecomposition = (WatchFaceDecomposition) Codecs.createParcelable(parcel, WatchFaceDecomposition.CREATOR);
            IBinder readStrongBinder = parcel.readStrongBinder();
            if (readStrongBinder != null) {
                IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("android.support.wearable.watchface.IWatchFaceUpdateDecompositionCallback");
                IWatchFaceUpdateDecompositionCallback$Stub$Proxy iWatchFaceUpdateDecompositionCallback$Stub$Proxy;
                if (queryLocalInterface instanceof IWatchFaceUpdateDecompositionCallback$Stub$Proxy) {
                    iWatchFaceUpdateDecompositionCallback$Stub$Proxy = (IWatchFaceUpdateDecompositionCallback$Stub$Proxy) queryLocalInterface;
                } else {
                    iWatchFaceUpdateDecompositionCallback$Stub$Proxy = new IWatchFaceUpdateDecompositionCallback$Stub$Proxy(readStrongBinder);
                }
            }
            parcel2.writeNoException();
            return true;
        } else {
            switch (i) {
                case 1:
                    setStyle((WatchFaceStyle) Codecs.createParcelable(parcel, WatchFaceStyle.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 2:
                    setActiveComplications(parcel.createIntArray(), Codecs.createBoolean(parcel));
                    parcel2.writeNoException();
                    return true;
                case 3:
                    setDefaultComplicationProvider(parcel.readInt(), (ComponentName) Codecs.createParcelable(parcel, ComponentName.CREATOR), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 4:
                    setDefaultSystemComplicationProvider(parcel.readInt(), parcel.readInt(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 5:
                    setContentDescriptionLabels((ContentDescriptionLabel[]) parcel.createTypedArray(ContentDescriptionLabel.CREATOR));
                    parcel2.writeNoException();
                    return true;
                case 6:
                    parcel2.writeNoException();
                    return true;
                case 7:
                    setDefaultComplicationProviderWithFallbacks(parcel.readInt(), parcel.createTypedArrayList(ComponentName.CREATOR), parcel.readInt(), parcel.readInt());
                    parcel2.writeNoException();
                    return true;
                case 8:
                    parcel2.writeNoException();
                    parcel2.writeInt(4);
                    return true;
                case 9:
                    parcel2.writeNoException();
                    return true;
                default:
                    return false;
            }
        }
    }
}
