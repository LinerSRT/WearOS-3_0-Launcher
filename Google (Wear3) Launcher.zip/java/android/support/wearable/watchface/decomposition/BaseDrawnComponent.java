package android.support.wearable.watchface.decomposition;

import android.os.Bundle;
import android.support.wearable.watchface.decomposition.BaseComponent.BaseBuilder;
import android.support.wearable.watchface.decomposition.BaseComponent.ComponentFactory;
import android.support.wearable.watchface.decomposition.WatchFaceDecomposition.DrawnComponent;

/* compiled from: PG */
abstract class BaseDrawnComponent extends BaseComponent implements DrawnComponent {

    /* compiled from: PG */
    public abstract class BaseDrawnBuilder extends BaseBuilder {
        public BaseDrawnBuilder(ComponentFactory componentFactory) {
            super(componentFactory);
        }
    }

    public BaseDrawnComponent(Bundle bundle) {
        super(bundle);
    }

    public final int getZOrder() {
        return this.fields.getInt("zOrder");
    }
}
