package android.support.wearable.watchface.decomposition;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

/* compiled from: PG */
public class KerningPair implements Parcelable {
    public static final Creator CREATOR = new PG();
    public int adjustment;
    public char glyph1;
    public char glyph2;

    /* renamed from: android.support.wearable.watchface.decomposition.KerningPair$1 */
    class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new KerningPair[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new KerningPair(parcel);
        }
    }

    protected KerningPair(Parcel parcel) {
        this.adjustment = parcel.readInt();
        this.glyph1 = (char) parcel.readInt();
        this.glyph2 = (char) parcel.readInt();
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.adjustment);
        parcel.writeInt(this.glyph1);
        parcel.writeInt(this.glyph2);
    }
}
