package android.support.wearable.watchface.decomposition;

import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.wearable.watchface.decomposition.BaseComponent.ComponentFactory;
import android.support.wearable.watchface.decomposition.BaseDrawnComponent.BaseDrawnBuilder;
import android.support.wearable.watchface.decomposition.WatchFaceDecomposition.Component;

/* compiled from: PG */
public class ComplicationComponent extends BaseDrawnComponent implements Parcelable {
    public static final Creator CREATOR = new PG();

    /* renamed from: android.support.wearable.watchface.decomposition.ComplicationComponent$1 */
    class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ComplicationComponent[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ComplicationComponent(parcel);
        }
    }

    /* compiled from: PG */
    public class Builder extends BaseDrawnBuilder {

        /* renamed from: android.support.wearable.watchface.decomposition.ComplicationComponent$Builder$1 */
        class PG implements ComponentFactory {
            public final /* bridge */ /* synthetic */ Component buildComponent(Bundle bundle) {
                return new ComplicationComponent(bundle);
            }
        }

        public Builder() {
            super(new PG());
        }
    }

    public ComplicationComponent(Bundle bundle) {
        super(bundle);
    }

    public final int describeContents() {
        return 0;
    }

    public final RectF getBounds() {
        return new RectF((RectF) this.fields.getParcelable("bounds"));
    }

    public final int getWatchFaceComplicationId() {
        return this.fields.getInt("wf_complication_id");
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeBundle(this.fields);
    }

    public ComplicationComponent(Parcel parcel) {
        super(parcel.readBundle());
        this.fields.setClassLoader(getClass().getClassLoader());
    }
}
