package android.support.wearable.watchface.decomposition;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.wearable.watchface.decomposition.BaseComponent.BaseBuilder;
import android.support.wearable.watchface.decomposition.BaseComponent.ComponentFactory;
import android.support.wearable.watchface.decomposition.WatchFaceDecomposition.Component;

/* compiled from: PG */
public class CustomFontComponent extends BaseComponent implements Parcelable {
    public static final Creator CREATOR = new PG();

    /* renamed from: android.support.wearable.watchface.decomposition.CustomFontComponent$1 */
    class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new CustomFontComponent[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new CustomFontComponent(parcel);
        }
    }

    /* compiled from: PG */
    public class Builder extends BaseBuilder {

        /* renamed from: android.support.wearable.watchface.decomposition.CustomFontComponent$Builder$1 */
        class PG implements ComponentFactory {
            public final /* bridge */ /* synthetic */ Component buildComponent(Bundle bundle) {
                return new CustomFontComponent(bundle);
            }
        }

        public Builder() {
            super(new PG());
        }
    }

    public CustomFontComponent(Bundle bundle) {
        super(bundle);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeBundle(this.fields);
    }

    public CustomFontComponent(Parcel parcel) {
        super(parcel.readBundle());
        this.fields.setClassLoader(getClass().getClassLoader());
    }
}
