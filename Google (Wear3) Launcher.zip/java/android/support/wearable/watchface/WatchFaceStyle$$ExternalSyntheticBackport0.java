package android.support.wearable.watchface;

/* compiled from: PG */
public final /* synthetic */ class WatchFaceStyle$$ExternalSyntheticBackport0 {
    /* renamed from: m */
    public static /* synthetic */ int m2m(boolean z) {
        return z ? 1231 : 1237;
    }
}
