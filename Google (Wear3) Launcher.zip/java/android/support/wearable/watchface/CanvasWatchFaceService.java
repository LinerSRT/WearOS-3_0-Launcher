package android.support.wearable.watchface;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Choreographer;
import android.view.Choreographer.FrameCallback;
import android.view.SurfaceHolder;

/* compiled from: PG */
public class CanvasWatchFaceService extends WatchFaceService {

    /* compiled from: PG */
    public class Engine extends android.support.wearable.watchface.WatchFaceService.Engine {
        private final Choreographer mChoreographer = Choreographer.getInstance();
        public boolean mDestroyed;
        private final FrameCallback mFrameCallback = new PG();
        public boolean mFrameCallbackPending;
        private final Handler mHandler = new C01322();

        /* renamed from: android.support.wearable.watchface.CanvasWatchFaceService$Engine$1 */
        final class PG implements FrameCallback {
            public final void doFrame(long j) {
                Engine engine = Engine.this;
                if (!engine.mDestroyed) {
                    engine.mFrameCallbackPending = false;
                    engine.draw(engine.getSurfaceHolder());
                }
            }
        }

        /* renamed from: android.support.wearable.watchface.CanvasWatchFaceService$Engine$2 */
        final class C01322 extends Handler {
            public final void handleMessage(Message message) {
                switch (message.what) {
                    case 0:
                        Engine.this.invalidate();
                        return;
                    default:
                        return;
                }
            }
        }

        public final void invalidate() {
            if (!this.mFrameCallbackPending) {
                this.mFrameCallbackPending = true;
                this.mChoreographer.postFrameCallback(this.mFrameCallback);
            }
        }

        public final void onDestroy() {
            this.mDestroyed = true;
            this.mHandler.removeMessages(0);
            this.mChoreographer.removeFrameCallback(this.mFrameCallback);
            super.onDestroy();
        }

        public void onDraw(Canvas canvas, Rect rect) {
        }

        public final void onSurfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
            String str = "CanvasWatchFaceService";
            if (Log.isLoggable(str, 3)) {
                Log.d(str, "onSurfaceChanged");
            }
            super.onSurfaceChanged(surfaceHolder, i, i2, i3);
            invalidate();
        }

        public final void onSurfaceCreated(SurfaceHolder surfaceHolder) {
            String str = "CanvasWatchFaceService";
            if (Log.isLoggable(str, 3)) {
                Log.d(str, "onSurfaceCreated");
            }
            super.onSurfaceCreated(surfaceHolder);
            invalidate();
        }

        public final void onSurfaceRedrawNeeded(SurfaceHolder surfaceHolder) {
            String str = "CanvasWatchFaceService";
            if (Log.isLoggable(str, 3)) {
                Log.d(str, "onSurfaceRedrawNeeded");
            }
            super.onSurfaceRedrawNeeded(surfaceHolder);
            draw(surfaceHolder);
        }

        public void onVisibilityChanged(boolean z) {
            super.onVisibilityChanged(z);
            if (!z) {
                invalidate();
            }
        }

        public Engine(CanvasWatchFaceService canvasWatchFaceService) {
            super();
        }

        public final void draw(SurfaceHolder surfaceHolder) {
            Canvas lockCanvas = surfaceHolder.lockCanvas();
            if (lockCanvas != null) {
                try {
                    if (isVisible()) {
                        onDraw(lockCanvas, surfaceHolder.getSurfaceFrame());
                    } else {
                        lockCanvas.drawColor(-16777216);
                    }
                    surfaceHolder.unlockCanvasAndPost(lockCanvas);
                } catch (Throwable th) {
                    surfaceHolder.unlockCanvasAndPost(lockCanvas);
                }
            }
        }
    }

    public Engine onCreateEngine() {
        throw null;
    }
}
