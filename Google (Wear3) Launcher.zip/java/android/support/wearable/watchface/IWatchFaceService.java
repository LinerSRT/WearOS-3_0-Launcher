package android.support.wearable.watchface;

import android.content.ComponentName;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.support.wearable.watchface.accessibility.ContentDescriptionLabel;
import com.google.android.aidl.BaseProxy;
import com.google.android.aidl.BaseStub;
import com.google.android.aidl.Codecs;
import java.util.List;

/* compiled from: PG */
public interface IWatchFaceService extends IInterface {

    /* compiled from: PG */
    public abstract class Stub extends BaseStub implements IWatchFaceService {

        /* compiled from: PG */
        public final class Proxy extends BaseProxy implements IWatchFaceService {
            public Proxy(IBinder iBinder) {
                super(iBinder, "android.support.wearable.watchface.IWatchFaceService");
            }

            public final int getApiVersion() {
                Parcel transactAndReadException = transactAndReadException(8, obtainAndWriteInterfaceToken());
                int readInt = transactAndReadException.readInt();
                transactAndReadException.recycle();
                return readInt;
            }

            public final void setActiveComplications(int[] iArr, boolean z) {
                throw null;
            }

            public final void setContentDescriptionLabels(ContentDescriptionLabel[] contentDescriptionLabelArr) {
                throw null;
            }

            public final void setDefaultComplicationProvider(int i, ComponentName componentName, int i2) {
                throw null;
            }

            public final void setDefaultComplicationProviderWithFallbacks(int i, List list, int i2, int i3) {
                Parcel obtainAndWriteInterfaceToken = obtainAndWriteInterfaceToken();
                obtainAndWriteInterfaceToken.writeInt(i);
                obtainAndWriteInterfaceToken.writeTypedList(null);
                obtainAndWriteInterfaceToken.writeInt(0);
                obtainAndWriteInterfaceToken.writeInt(0);
                transactAndReadExceptionReturnVoid(7, obtainAndWriteInterfaceToken);
            }

            public final void setDefaultSystemComplicationProvider(int i, int i2, int i3) {
                Parcel obtainAndWriteInterfaceToken = obtainAndWriteInterfaceToken();
                obtainAndWriteInterfaceToken.writeInt(i);
                obtainAndWriteInterfaceToken.writeInt(0);
                obtainAndWriteInterfaceToken.writeInt(0);
                transactAndReadExceptionReturnVoid(4, obtainAndWriteInterfaceToken);
            }

            public final void setStyle(WatchFaceStyle watchFaceStyle) {
                Parcel obtainAndWriteInterfaceToken = obtainAndWriteInterfaceToken();
                Codecs.writeParcelable(obtainAndWriteInterfaceToken, watchFaceStyle);
                transactAndReadExceptionReturnVoid(1, obtainAndWriteInterfaceToken);
            }
        }

        public Stub() {
            super("android.support.wearable.watchface.IWatchFaceService");
        }

        protected boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) {
            switch (i) {
                case 1:
                    setStyle((WatchFaceStyle) Codecs.createParcelable(parcel, WatchFaceStyle.CREATOR));
                    parcel2.writeNoException();
                    break;
                case 2:
                    setActiveComplications(parcel.createIntArray(), Codecs.createBoolean(parcel));
                    parcel2.writeNoException();
                    break;
                case 3:
                    setDefaultComplicationProvider(parcel.readInt(), (ComponentName) Codecs.createParcelable(parcel, ComponentName.CREATOR), parcel.readInt());
                    parcel2.writeNoException();
                    break;
                case 4:
                    setDefaultSystemComplicationProvider(parcel.readInt(), parcel.readInt(), parcel.readInt());
                    parcel2.writeNoException();
                    break;
                case 5:
                    setContentDescriptionLabels((ContentDescriptionLabel[]) parcel.createTypedArray(ContentDescriptionLabel.CREATOR));
                    parcel2.writeNoException();
                    break;
                case 6:
                    parcel2.writeNoException();
                    break;
                case 7:
                    setDefaultComplicationProviderWithFallbacks(parcel.readInt(), parcel.createTypedArrayList(ComponentName.CREATOR), parcel.readInt(), parcel.readInt());
                    parcel2.writeNoException();
                    break;
                case 8:
                    parcel2.writeNoException();
                    parcel2.writeInt(4);
                    break;
                case 9:
                    parcel2.writeNoException();
                    break;
                default:
                    return false;
            }
            return true;
        }
    }

    int getApiVersion();

    void setActiveComplications(int[] iArr, boolean z);

    void setContentDescriptionLabels(ContentDescriptionLabel[] contentDescriptionLabelArr);

    void setDefaultComplicationProvider(int i, ComponentName componentName, int i2);

    void setDefaultComplicationProviderWithFallbacks(int i, List list, int i2, int i3);

    void setDefaultSystemComplicationProvider(int i, int i2, int i3);

    void setStyle(WatchFaceStyle watchFaceStyle);
}
