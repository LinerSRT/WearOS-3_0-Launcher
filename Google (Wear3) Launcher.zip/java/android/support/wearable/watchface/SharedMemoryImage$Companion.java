package android.support.wearable.watchface;

/* compiled from: PG */
public final class SharedMemoryImage$Companion {
    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final android.graphics.Bitmap ashmemReadImageBundle$ar$ds(android.os.Bundle r9) {
        /*
        r0 = new androidx.wear.utility.TraceEvent;
        r1 = "SharedMemoryImage.ashmemReadImageBundle";
        r0.<init>(r1);
        r0 = android.os.SharedMemory.class;
        r0 = r0.getClassLoader();	 Catch:{ all -> 0x006f }
        r9.setClassLoader(r0);	 Catch:{ all -> 0x006f }
        r0 = "KEY_SCREENSHOT";
        r0 = r9.getParcelable(r0);	 Catch:{ all -> 0x006f }
        r0 = (android.os.SharedMemory) r0;	 Catch:{ all -> 0x006f }
        if (r0 == 0) goto L_0x0067;
    L_0x001a:
        r1 = "KEY_BITMAP_WIDTH_PX";
        r1 = r9.getInt(r1);	 Catch:{ all -> 0x006f }
        r2 = "KEY_BITMAP_HEIGHT_PX";
        r2 = r9.getInt(r2);	 Catch:{ all -> 0x006f }
        r3 = "KEY_BITMAP_CONFIG_ORDINAL";
        r9 = r9.getInt(r3);	 Catch:{ all -> 0x006f }
        r3 = 0;
        r4 = android.graphics.Bitmap.Config.values();	 Catch:{ all -> 0x0060 }
        r5 = r4.length;	 Catch:{ all -> 0x0060 }
        r6 = 0;
    L_0x0033:
        if (r6 >= r5) goto L_0x0041;
    L_0x0035:
        r7 = r4[r6];	 Catch:{ all -> 0x0060 }
        r8 = r7.ordinal();	 Catch:{ all -> 0x0060 }
        if (r8 != r9) goto L_0x003e;
    L_0x003d:
        goto L_0x0042;
    L_0x003e:
        r6 = r6 + 1;
        goto L_0x0033;
    L_0x0041:
        r7 = r3;
    L_0x0042:
        r7.getClass();	 Catch:{ all -> 0x0060 }
        r9 = android.graphics.Bitmap.createBitmap(r1, r2, r7);	 Catch:{ all -> 0x0060 }
        r0 = r0.mapReadOnly();	 Catch:{ all -> 0x0060 }
        r9.copyPixelsFromBuffer(r0);	 Catch:{ all -> 0x005d }
        r9.getClass();	 Catch:{ all -> 0x005d }
        if (r0 == 0) goto L_0x0058;
    L_0x0055:
        android.os.SharedMemory.unmap(r0);	 Catch:{ all -> 0x006f }
        kotlin.p018io.CloseableKt.closeFinally$ar$ds(r3);
        return r9;
    L_0x005d:
        r9 = move-exception;
        r3 = r0;
        goto L_0x0061;
    L_0x0060:
        r9 = move-exception;
    L_0x0061:
        if (r3 == 0) goto L_0x0066;
    L_0x0063:
        android.os.SharedMemory.unmap(r3);	 Catch:{ all -> 0x006f }
    L_0x0066:
        throw r9;	 Catch:{ all -> 0x006f }
    L_0x0067:
        r9 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x006f }
        r0 = "Bundle did not contain KEY_SCREENSHOT";
        r9.<init>(r0);	 Catch:{ all -> 0x006f }
        throw r9;	 Catch:{ all -> 0x006f }
    L_0x006f:
        r9 = move-exception;
        throw r9;	 Catch:{ all -> 0x0071 }
    L_0x0071:
        r0 = move-exception;
        kotlin.p018io.CloseableKt.closeFinally$ar$ds(r9);
        goto L_0x0077;
    L_0x0076:
        throw r0;
    L_0x0077:
        goto L_0x0076;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.wearable.watchface.SharedMemoryImage$Companion.ashmemReadImageBundle$ar$ds(android.os.Bundle):android.graphics.Bitmap");
    }
}
