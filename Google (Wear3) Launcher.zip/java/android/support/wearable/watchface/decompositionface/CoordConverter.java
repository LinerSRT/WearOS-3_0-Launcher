package android.support.wearable.watchface.decompositionface;

import android.graphics.Rect;
import android.graphics.RectF;

/* compiled from: PG */
public final class CoordConverter {
    public final Rect mPixelBounds = new Rect();

    public final void getPixelRectFromProportional(RectF rectF, Rect rect) {
        rect.set(getPixelX(rectF.left), getPixelY(rectF.top), getPixelX(rectF.right), getPixelY(rectF.bottom));
    }

    public final int getPixelX(float f) {
        return Math.round((f * ((float) this.mPixelBounds.width())) + ((float) this.mPixelBounds.left));
    }

    public final int getPixelY(float f) {
        return Math.round((f * ((float) this.mPixelBounds.height())) + ((float) this.mPixelBounds.top));
    }
}
