package android.support.wearable.watchface.decompositionface;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.widget.ImageView;

/* compiled from: PG */
public class DecompositionConfigView extends ImageView {
    private final GestureDetector gestureDetector;
    private final SimpleOnGestureListener gestureListener;

    /* renamed from: android.support.wearable.watchface.decompositionface.DecompositionConfigView$1 */
    final class PG extends SimpleOnGestureListener {
        public final boolean onDown(MotionEvent motionEvent) {
            return true;
        }

        public final boolean onSingleTapUp(MotionEvent motionEvent) {
            return false;
        }
    }

    public DecompositionConfigView(Context context) {
        super(context);
        getContext();
        DecompositionDrawable decompositionDrawable = new DecompositionDrawable();
        CoordConverter coordConverter = new CoordConverter();
        OnGestureListener pg = new PG();
        this.gestureListener = pg;
        this.gestureDetector = new GestureDetector(getContext(), pg);
        Rect rect = new Rect();
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        return this.gestureDetector.onTouchEvent(motionEvent);
    }

    public DecompositionConfigView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        getContext();
        DecompositionDrawable decompositionDrawable = new DecompositionDrawable();
        CoordConverter coordConverter = new CoordConverter();
        OnGestureListener pg = new PG();
        this.gestureListener = pg;
        this.gestureDetector = new GestureDetector(getContext(), pg);
        Rect rect = new Rect();
    }
}
