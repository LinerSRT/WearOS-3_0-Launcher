package android.support.wearable.watchface.decompositionface;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.os.Handler;
import android.os.Looper;

/* compiled from: PG */
public final class DecompositionDrawable extends Drawable {
    private final Path roundPath = new Path();

    /* renamed from: android.support.wearable.watchface.decompositionface.DecompositionDrawable$1 */
    final class PG implements Callback {
        public final void invalidateDrawable(Drawable drawable) {
            DecompositionDrawable.this.invalidateSelf();
        }

        public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        }

        public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        }
    }

    public DecompositionDrawable() {
        Handler handler = new Handler(Looper.getMainLooper());
        CoordConverter coordConverter = new CoordConverter();
        Rect rect = new Rect();
        PG pg = new PG();
    }

    public final void draw(Canvas canvas) {
    }

    public final int getOpacity() {
        return -3;
    }

    protected final void onBoundsChange(Rect rect) {
        this.roundPath.reset();
        this.roundPath.addOval((float) rect.left, (float) rect.top, (float) rect.right, (float) rect.bottom, Direction.CW);
    }

    public final void setAlpha(int i) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }
}
