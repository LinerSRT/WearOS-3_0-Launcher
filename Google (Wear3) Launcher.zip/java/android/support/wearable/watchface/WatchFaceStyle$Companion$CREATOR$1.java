package android.support.wearable.watchface;

import android.content.ComponentName;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;

/* compiled from: PG */
public final class WatchFaceStyle$Companion$CREATOR$1 implements Creator {
    public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
        return new WatchFaceStyle[i];
    }

    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        parcel.getClass();
        Bundle readBundle = parcel.readBundle(getClass().getClassLoader());
        readBundle.getClass();
        ComponentName componentName = (ComponentName) readBundle.getParcelable("component");
        componentName.getClass();
        return new WatchFaceStyle(componentName, readBundle.getInt("viewProtectionMode"), readBundle.getInt("statusBarGravity"), readBundle.getInt("accentColor", -1), readBundle.getBoolean("showUnreadIndicator"), readBundle.getBoolean("hideNotificationIndicator"), readBundle.getBoolean("acceptsTapEvents"), readBundle);
    }
}
