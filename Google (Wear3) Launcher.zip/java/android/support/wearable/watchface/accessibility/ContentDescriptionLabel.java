package android.support.wearable.watchface.accessibility;

import android.app.PendingIntent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.wearable.complications.TimeDependentText;
import p020j$.util.Objects;

/* compiled from: PG */
public final class ContentDescriptionLabel implements Parcelable {
    public static final Creator CREATOR = new PG();
    public final Rect mBounds;
    public PendingIntent mTapAction;
    public final TimeDependentText mText;

    /* renamed from: android.support.wearable.watchface.accessibility.ContentDescriptionLabel$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ContentDescriptionLabel[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ContentDescriptionLabel(parcel);
        }
    }

    protected ContentDescriptionLabel(Parcel parcel) {
        Bundle readBundle = parcel.readBundle(getClass().getClassLoader());
        this.mText = (TimeDependentText) readBundle.getParcelable("KEY_TEXT");
        this.mBounds = (Rect) readBundle.getParcelable("KEY_BOUNDS");
        this.mTapAction = (PendingIntent) readBundle.getParcelable("KEY_TAP_ACTION");
    }

    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (getClass() == obj.getClass()) {
                ContentDescriptionLabel contentDescriptionLabel = (ContentDescriptionLabel) obj;
                return Objects.equals(this.mText, contentDescriptionLabel.mText) && Objects.equals(this.mBounds, contentDescriptionLabel.mBounds) && Objects.equals(this.mTapAction, contentDescriptionLabel.mTapAction);
            }
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(new Object[]{this.mText, this.mBounds, this.mTapAction});
    }

    public final String toString() {
        String valueOf = String.valueOf(this.mText);
        String valueOf2 = String.valueOf(this.mBounds);
        String valueOf3 = String.valueOf(this.mTapAction);
        int length = String.valueOf(valueOf).length();
        StringBuilder stringBuilder = new StringBuilder(((length + 51) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length());
        stringBuilder.append("ContentDescriptionLabel{text=");
        stringBuilder.append(valueOf);
        stringBuilder.append(", bounds=");
        stringBuilder.append(valueOf2);
        stringBuilder.append(", tapAction=");
        stringBuilder.append(valueOf3);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("KEY_TEXT", this.mText);
        bundle.putParcelable("KEY_BOUNDS", this.mBounds);
        bundle.putParcelable("KEY_TAP_ACTION", this.mTapAction);
        parcel.writeBundle(bundle);
    }
}
