package android.support.wearable.watchface;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.service.wallpaper.WallpaperService;
import android.support.wearable.complications.ComplicationData;
import android.support.wearable.watchface.IWatchFaceService.Stub.Proxy;
import android.util.Log;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import java.util.List;
import p020j$.util.Objects;

/* compiled from: PG */
public abstract class WatchFaceService extends WallpaperService {
    public static final String[] STATUS_KEYS = new String[]{"charging", "airplane_mode", "connected", "theater_mode", "gps_active", "keyguard_locked", "interruption_filter"};

    /* compiled from: PG */
    public class Engine extends android.service.wallpaper.WallpaperService.Engine {
        private final IntentFilter mAmbientTimeTickFilter;
        private WakeLock mAmbientUpdateWakelock;
        private final SparseArray mDefaultProviderConfigsPending = new SparseArray();
        public boolean mInAmbientMode;
        private final IntentFilter mInteractiveTimeTickFilter;
        private int mInterruptionFilter;
        private Bundle mLastStatusBundle;
        private int mNotificationCount;
        private final Rect mPeekCardPosition = new Rect(0, 0, 0, 0);
        private final BroadcastReceiver mTimeTickReceiver = new PG();
        private boolean mTimeTickRegistered = false;
        private int mUnreadCount;
        private IWatchFaceService mWatchFaceService;
        private WatchFaceStyle mWatchFaceStyle;
        private int systemApiVersion;

        /* renamed from: android.support.wearable.watchface.WatchFaceService$Engine$1 */
        final class PG extends BroadcastReceiver {
            public final void onReceive(Context context, Intent intent) {
                String str = "WatchFaceService";
                if (Log.isLoggable(str, 3)) {
                    String valueOf = String.valueOf(intent);
                    StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 46);
                    stringBuilder.append("Received intent that triggers onTimeTick for: ");
                    stringBuilder.append(valueOf);
                    Log.d(str, stringBuilder.toString());
                }
                Engine.this.onTimeTick();
            }
        }

        public Engine() {
            super(WatchFaceService.this);
            IntentFilter intentFilter = new IntentFilter();
            this.mAmbientTimeTickFilter = intentFilter;
            intentFilter.addAction("android.intent.action.DATE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            IntentFilter intentFilter2 = new IntentFilter(intentFilter);
            this.mInteractiveTimeTickFilter = intentFilter2;
            intentFilter2.addAction("android.intent.action.TIME_TICK");
        }

        private final void updateTimeTickReceiver() {
            String str = "WatchFaceService";
            if (Log.isLoggable(str, 3)) {
                boolean z = this.mTimeTickRegistered;
                boolean isVisible = isVisible();
                boolean z2 = this.mInAmbientMode;
                StringBuilder stringBuilder = new StringBuilder(47);
                stringBuilder.append("updateTimeTickReceiver: ");
                stringBuilder.append(z);
                stringBuilder.append(" -> (");
                stringBuilder.append(isVisible);
                stringBuilder.append(", ");
                stringBuilder.append(z2);
                stringBuilder.append(")");
                Log.d(str, stringBuilder.toString());
            }
            if (this.mTimeTickRegistered) {
                WatchFaceService.this.unregisterReceiver(this.mTimeTickReceiver);
                this.mTimeTickRegistered = false;
            }
            if (isVisible()) {
                if (this.mInAmbientMode) {
                    WatchFaceService.this.registerReceiver(this.mTimeTickReceiver, this.mAmbientTimeTickFilter);
                } else {
                    WatchFaceService.this.registerReceiver(this.mTimeTickReceiver, this.mInteractiveTimeTickFilter);
                }
                this.mTimeTickRegistered = true;
                onTimeTick();
            }
        }

        public final boolean isInAmbientMode() {
            return this.mInAmbientMode;
        }

        public void onAmbientModeChanged$ar$ds() {
        }

        public final Bundle onCommand(String str, int i, int i2, int i3, Bundle bundle, boolean z) {
            String valueOf;
            String str2 = "WatchFaceService";
            if (Log.isLoggable(str2, 3)) {
                valueOf = String.valueOf(str);
                String str3 = "received command: ";
                if (valueOf.length() != 0) {
                    valueOf = str3.concat(valueOf);
                } else {
                    valueOf = new String(str3);
                }
                Log.d(str2, valueOf);
            }
            int i4 = 0;
            int i5;
            if ("com.google.android.wearable.action.BACKGROUND_ACTION".equals(str)) {
                str = "ambient_mode";
                if (bundle.containsKey(str)) {
                    boolean z2 = bundle.getBoolean(str, false);
                    if (this.mInAmbientMode != z2) {
                        this.mInAmbientMode = z2;
                        if (Log.isLoggable(str2, 3)) {
                            z2 = this.mInAmbientMode;
                            StringBuilder stringBuilder = new StringBuilder(33);
                            stringBuilder.append("dispatchAmbientModeChanged: ");
                            stringBuilder.append(z2);
                            Log.d(str2, stringBuilder.toString());
                        }
                        onAmbientModeChanged$ar$ds();
                        updateTimeTickReceiver();
                    }
                }
                str = "interruption_filter";
                if (bundle.containsKey(str)) {
                    i5 = bundle.getInt(str, 1);
                    if (i5 != this.mInterruptionFilter) {
                        this.mInterruptionFilter = i5;
                    }
                }
                str = "card_location";
                if (bundle.containsKey(str)) {
                    Rect unflattenFromString = Rect.unflattenFromString(bundle.getString(str));
                    if (!unflattenFromString.equals(this.mPeekCardPosition)) {
                        this.mPeekCardPosition.set(unflattenFromString);
                    }
                }
                str = "unread_count";
                if (bundle.containsKey(str)) {
                    i5 = bundle.getInt(str, 0);
                    if (i5 != this.mUnreadCount) {
                        this.mUnreadCount = i5;
                    }
                }
                str = "notification_count";
                if (bundle.containsKey(str)) {
                    i5 = bundle.getInt(str, 0);
                    if (i5 != this.mNotificationCount) {
                        this.mNotificationCount = i5;
                    }
                }
                Bundle bundle2 = bundle.getBundle("indicator_status");
                if (bundle2 != null) {
                    Bundle bundle3 = this.mLastStatusBundle;
                    if (bundle3 != null) {
                        String[] strArr = WatchFaceService.STATUS_KEYS;
                        i3 = strArr.length;
                        while (i4 < 7) {
                            valueOf = strArr[i4];
                            if (Objects.equals(bundle2.get(valueOf), bundle3.get(valueOf))) {
                                i4++;
                            }
                        }
                    }
                    this.mLastStatusBundle = new Bundle(bundle2);
                    break;
                }
            } else if ("com.google.android.wearable.action.AMBIENT_UPDATE".equals(str)) {
                if (this.mInAmbientMode) {
                    if (Log.isLoggable(str2, 3)) {
                        Log.d(str2, "ambient mode update");
                    }
                    this.mAmbientUpdateWakelock.acquire();
                    onTimeTick();
                    this.mAmbientUpdateWakelock.acquire(100);
                }
            } else if (!"com.google.android.wearable.action.SET_PROPERTIES".equals(str)) {
                if ("com.google.android.wearable.action.SET_BINDER".equals(str)) {
                    IBinder binder = bundle.getBinder("binder");
                    if (binder != null) {
                        IWatchFaceService iWatchFaceService;
                        IInterface queryLocalInterface = binder.queryLocalInterface("android.support.wearable.watchface.IWatchFaceService");
                        if (queryLocalInterface instanceof IWatchFaceService) {
                            iWatchFaceService = (IWatchFaceService) queryLocalInterface;
                        } else {
                            iWatchFaceService = new Proxy(binder);
                        }
                        this.mWatchFaceService = iWatchFaceService;
                        try {
                            this.systemApiVersion = iWatchFaceService.getApiVersion();
                        } catch (Throwable e) {
                            Log.w(str2, "Failed to getVersion: ", e);
                        }
                        WatchFaceStyle watchFaceStyle = this.mWatchFaceStyle;
                        if (watchFaceStyle != null) {
                            try {
                                this.mWatchFaceService.setStyle(watchFaceStyle);
                                this.mWatchFaceStyle = null;
                            } catch (Throwable e2) {
                                Log.w(str2, "Failed to set WatchFaceStyle", e2);
                            }
                        }
                        if (Log.isLoggable(str2, 3)) {
                            Log.d(str2, "doSetPendingDefaultComplicationProviders");
                            i5 = 0;
                        } else {
                            i5 = 0;
                        }
                        while (i5 < this.mDefaultProviderConfigsPending.size()) {
                            try {
                                i2 = this.mDefaultProviderConfigsPending.keyAt(i5);
                                ProviderConfig providerConfig = (ProviderConfig) this.mDefaultProviderConfigsPending.valueAt(i5);
                                IWatchFaceService iWatchFaceService2;
                                int i6;
                                if (this.systemApiVersion >= 2) {
                                    iWatchFaceService2 = this.mWatchFaceService;
                                    List list = providerConfig.providers;
                                    i6 = providerConfig.fallbackSystemProvider;
                                    i3 = providerConfig.type;
                                    iWatchFaceService2.setDefaultComplicationProviderWithFallbacks(i2, null, 0, 0);
                                } else {
                                    int i7 = providerConfig.fallbackSystemProvider;
                                    iWatchFaceService2 = this.mWatchFaceService;
                                    i6 = providerConfig.type;
                                    iWatchFaceService2.setDefaultSystemComplicationProvider(i2, 0, 0);
                                    List list2 = providerConfig.providers;
                                }
                                i5++;
                            } catch (Throwable e22) {
                                Log.e(str2, "Failed to set default complication providers: ", e22);
                            }
                        }
                        this.mDefaultProviderConfigsPending.clear();
                    } else {
                        Log.w(str2, "Binder is null.");
                    }
                } else if ("com.google.android.wearable.action.REQUEST_STYLE".equals(str)) {
                    if (Log.isLoggable(str2, 3)) {
                        Log.d(str2, "Last watch face style is null.");
                    }
                } else if (!"com.google.android.wearable.action.REQUEST_DECOMPOSITION".equals(str)) {
                    String str4 = "android.wallpaper.tap";
                    valueOf = "android.wallpaper.touch_cancel";
                    if (!("android.wallpaper.touch".equals(str) || valueOf.equals(str))) {
                        if (!str4.equals(str)) {
                            if ("com.google.android.wearable.action.COMPLICATION_DATA".equals(str)) {
                                bundle.setClassLoader(ComplicationData.class.getClassLoader());
                                bundle.getInt("complication_id");
                                ComplicationData complicationData = (ComplicationData) bundle.getParcelable("complication_data");
                            }
                        }
                    }
                    bundle.getLong("tap_time");
                    if (!valueOf.equals(str)) {
                        str4.equals(str);
                    }
                }
            }
            return null;
        }

        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            Context context = WatchFaceService.this;
            this.mWatchFaceStyle = new WatchFaceStyle(new ComponentName(context, context.getClass()), 0, 0, -1, false, false, false, null);
            WakeLock newWakeLock = ((PowerManager) WatchFaceService.this.getSystemService("power")).newWakeLock(1, "WatchFaceService[AmbientUpdate]");
            this.mAmbientUpdateWakelock = newWakeLock;
            newWakeLock.setReferenceCounted(false);
        }

        public void onDestroy() {
            if (this.mTimeTickRegistered) {
                this.mTimeTickRegistered = false;
                WatchFaceService.this.unregisterReceiver(this.mTimeTickReceiver);
            }
            super.onDestroy();
        }

        public void onTimeTick() {
        }

        public void onVisibilityChanged(boolean z) {
            super.onVisibilityChanged(z);
            String str = "WatchFaceService";
            if (Log.isLoggable(str, 3)) {
                StringBuilder stringBuilder = new StringBuilder(26);
                stringBuilder.append("onVisibilityChanged: ");
                stringBuilder.append(z);
                Log.d(str, stringBuilder.toString());
            }
            Intent intent = new Intent("com.google.android.wearable.watchfaces.action.REQUEST_STATE");
            intent.putExtra("watch_face_visible", z);
            WatchFaceService.this.sendBroadcast(intent);
            updateTimeTickReceiver();
        }
    }

    /* compiled from: PG */
    final class ProviderConfig {
        public final int fallbackSystemProvider;
        public final List providers;
        public final int type;
    }

    public abstract Engine onCreateEngine();
}
