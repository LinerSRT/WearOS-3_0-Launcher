package android.support.wearable.provider;

import android.net.Uri;

/* compiled from: PG */
public final class WearableCalendarContract {
    public static final Uri CONTENT_URI = Uri.parse("content://com.google.android.wearable.provider.calendar");

    /* compiled from: PG */
    public final class Attendees {
        public static final Uri CONTENT_URI = Uri.withAppendedPath(WearableCalendarContract.CONTENT_URI, "attendees");
    }

    /* compiled from: PG */
    public final class Instances {
        public static final Uri CONTENT_URI = Uri.withAppendedPath(WearableCalendarContract.CONTENT_URI, "instances/when");
    }

    /* compiled from: PG */
    public final class Reminders {
        public static final Uri CONTENT_URI = Uri.withAppendedPath(WearableCalendarContract.CONTENT_URI, "reminders");
    }
}
