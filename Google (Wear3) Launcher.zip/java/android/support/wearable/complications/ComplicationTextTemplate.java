package android.support.wearable.complications;

import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.List;

/* compiled from: PG */
public final class ComplicationTextTemplate implements Parcelable, TimeDependentText {
    public static final Creator CREATOR = new PG();
    private final ComplicationText[] mComplicationTexts;
    private final CharSequence mSurroundingText;

    /* renamed from: android.support.wearable.complications.ComplicationTextTemplate$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ComplicationTextTemplate[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ComplicationTextTemplate(parcel);
        }
    }

    /* compiled from: PG */
    public final class Builder {
        public static final void addComplicationText$ar$ds$ar$objectUnboxing(ComplicationText complicationText, List list) {
            list.add(complicationText);
        }
    }

    public ComplicationTextTemplate(Parcel parcel) {
        Bundle readBundle = parcel.readBundle(ComplicationTextTemplate.class.getClassLoader());
        this.mSurroundingText = readBundle.getCharSequence("KEY_SURROUNDING_STRING");
        Parcelable[] parcelableArray = readBundle.getParcelableArray("KEY_TIME_DEPENDENT_TEXTS");
        this.mComplicationTexts = new ComplicationText[parcelableArray.length];
        for (int i = 0; i < parcelableArray.length; i++) {
            this.mComplicationTexts[i] = (ComplicationText) parcelableArray[i];
        }
        checkFields();
    }

    private final void checkFields() {
        if (this.mSurroundingText != null) {
            return;
        }
        if (this.mComplicationTexts.length == 0) {
            throw new IllegalStateException("One of mSurroundingText and mTimeDependentText must be non-null");
        }
    }

    public final int describeContents() {
        return 0;
    }

    public final long getNextChangeTime(long j) {
        long j2 = Long.MAX_VALUE;
        for (TimeDependentText nextChangeTime : this.mComplicationTexts) {
            j2 = Math.min(j2, nextChangeTime.getNextChangeTime(j));
        }
        return j2;
    }

    public final CharSequence getTextAt(Resources resources, long j) {
        int length = this.mComplicationTexts.length;
        if (length == 0) {
            return this.mSurroundingText;
        }
        CharSequence[] charSequenceArr = new CharSequence[length];
        for (int i = 0; i < length; i++) {
            charSequenceArr[i] = this.mComplicationTexts[i].getTextAt(resources, j);
        }
        CharSequence charSequence = this.mSurroundingText;
        if (charSequence == null) {
            return TextUtils.join(" ", charSequenceArr);
        }
        return TextUtils.expandTemplate(charSequence, charSequenceArr);
    }

    public final boolean returnsSameText(long j, long j2) {
        for (TimeDependentText returnsSameText : this.mComplicationTexts) {
            if (!returnsSameText.returnsSameText(j, j2)) {
                return false;
            }
        }
        return true;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        Bundle bundle = new Bundle();
        bundle.putCharSequence("KEY_SURROUNDING_STRING", this.mSurroundingText);
        bundle.putParcelableArray("KEY_TIME_DEPENDENT_TEXTS", this.mComplicationTexts);
        parcel.writeBundle(bundle);
    }

    public ComplicationTextTemplate(ComplicationText[] complicationTextArr) {
        this.mSurroundingText = null;
        this.mComplicationTexts = complicationTextArr;
        checkFields();
    }
}
