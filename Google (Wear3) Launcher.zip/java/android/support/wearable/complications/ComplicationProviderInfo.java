package android.support.wearable.complications;

import android.content.ComponentName;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

/* compiled from: PG */
public final class ComplicationProviderInfo implements Parcelable {
    public static final Creator CREATOR = new PG();
    private String mAppName;
    private int mComplicationType;
    private ComponentName mProviderComponentName;
    private Icon mProviderIcon;
    private String mProviderName;

    /* renamed from: android.support.wearable.complications.ComplicationProviderInfo$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ComplicationProviderInfo[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ComplicationProviderInfo(parcel);
        }
    }

    public ComplicationProviderInfo(Parcel parcel) {
        Bundle readBundle = parcel.readBundle(getClass().getClassLoader());
        this.mAppName = readBundle.getString("app_name");
        this.mProviderName = readBundle.getString("provider_name");
        this.mProviderIcon = (Icon) readBundle.getParcelable("provider_icon");
        this.mComplicationType = readBundle.getInt("complication_type");
        this.mProviderComponentName = (ComponentName) readBundle.getParcelable("provider_component");
    }

    public ComplicationProviderInfo(String str, String str2, Icon icon, int i, ComponentName componentName) {
        this.mAppName = str;
        this.mProviderName = str2;
        this.mProviderIcon = icon;
        this.mComplicationType = i;
        this.mProviderComponentName = componentName;
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        String str = this.mAppName;
        String str2 = this.mProviderName;
        String valueOf = String.valueOf(this.mProviderIcon);
        int i = this.mComplicationType;
        String valueOf2 = String.valueOf(this.mProviderComponentName);
        int length = String.valueOf(str).length();
        int length2 = String.valueOf(str2).length();
        StringBuilder stringBuilder = new StringBuilder((((length + 122) + length2) + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length());
        stringBuilder.append("ComplicationProviderInfo{appName='");
        stringBuilder.append(str);
        stringBuilder.append("', providerName='");
        stringBuilder.append(str2);
        stringBuilder.append("', providerIcon=");
        stringBuilder.append(valueOf);
        stringBuilder.append(", complicationType=");
        stringBuilder.append(i);
        stringBuilder.append(", providerComponentName=");
        stringBuilder.append(valueOf2);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("app_name", this.mAppName);
        bundle.putString("provider_name", this.mProviderName);
        bundle.putParcelable("provider_icon", this.mProviderIcon);
        bundle.putInt("complication_type", this.mComplicationType);
        bundle.putParcelable("provider_component", this.mProviderComponentName);
        parcel.writeBundle(bundle);
    }
}
