package android.support.wearable.complications;

import android.content.res.Resources;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.wearable.sysui.R;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/* compiled from: PG */
public final class TimeDifferenceText implements TimeDependentText {
    public static final Creator CREATOR = new PG();
    public final TimeUnit mMinimumUnit;
    public final long mReferencePeriodEnd;
    public final long mReferencePeriodStart;
    public final boolean mShowNowText;
    public final int mStyle;

    /* renamed from: android.support.wearable.complications.TimeDifferenceText$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new TimeDifferenceText[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new TimeDifferenceText(parcel);
        }
    }

    /* renamed from: android.support.wearable.complications.TimeDifferenceText$2 */
    final /* synthetic */ class C01192 {
        static final /* synthetic */ int[] $SwitchMap$java$util$concurrent$TimeUnit;

        static {
            int[] iArr = new int[TimeUnit.values().length];
            $SwitchMap$java$util$concurrent$TimeUnit = iArr;
            try {
                iArr[TimeUnit.MILLISECONDS.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.SECONDS.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.MINUTES.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.HOURS.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$java$util$concurrent$TimeUnit[TimeUnit.DAYS.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
        }
    }

    public TimeDifferenceText(long j, long j2, int i, boolean z, TimeUnit timeUnit) {
        this.mReferencePeriodStart = j;
        this.mReferencePeriodEnd = j2;
        this.mStyle = i;
        this.mShowNowText = z;
        this.mMinimumUnit = timeUnit;
    }

    private static String buildShortDaysText(int i, Resources resources) {
        return resources.getQuantityString(R.plurals.time_difference_short_days, i, new Object[]{Integer.valueOf(i)});
    }

    private final String buildShortDualUnitText(long j, Resources resources) {
        long roundUpToUnit = roundUpToUnit(j, TimeUnit.HOURS);
        if (!isGreaterOrEqual(this.mMinimumUnit, TimeUnit.DAYS)) {
            if (days(roundUpToUnit) < 10) {
                j = roundUpToUnit(j, TimeUnit.MINUTES);
                if (days(j) > 0) {
                    if (hours(roundUpToUnit) <= 0) {
                        return buildShortDaysText(days(roundUpToUnit), resources);
                    }
                    int days = days(roundUpToUnit);
                    return resources.getString(R.string.time_difference_short_days_and_hours, new Object[]{buildShortDaysText(days, resources), buildShortHoursText(r8, resources)});
                } else if (isGreaterOrEqual(this.mMinimumUnit, TimeUnit.HOURS)) {
                    return buildShortHoursText(hours(roundUpToUnit), resources);
                } else {
                    int hours = hours(j);
                    int minutes = minutes(j);
                    if (hours <= 0) {
                        return buildShortMinsText(minutes(j), resources);
                    }
                    if (minutes <= 0) {
                        return buildShortHoursText(hours, resources);
                    }
                    return resources.getString(R.string.time_difference_short_hours_and_minutes, new Object[]{buildShortHoursText(hours, resources), buildShortMinsText(minutes, resources)});
                }
            }
        }
        return buildShortDaysText(days(roundUpToUnit(j, TimeUnit.DAYS)), resources);
    }

    private static String buildShortHoursText(int i, Resources resources) {
        return resources.getQuantityString(R.plurals.time_difference_short_hours, i, new Object[]{Integer.valueOf(i)});
    }

    private static String buildShortMinsText(int i, Resources resources) {
        return resources.getQuantityString(R.plurals.time_difference_short_minutes, i, new Object[]{Integer.valueOf(i)});
    }

    private final String buildShortSingleUnitText(long j, Resources resources) {
        long roundUpToUnit = roundUpToUnit(j, TimeUnit.HOURS);
        if (!isGreaterOrEqual(this.mMinimumUnit, TimeUnit.DAYS)) {
            if (days(roundUpToUnit) <= 0) {
                j = roundUpToUnit(j, TimeUnit.MINUTES);
                if (!isGreaterOrEqual(this.mMinimumUnit, TimeUnit.HOURS)) {
                    if (hours(j) <= 0) {
                        return buildShortMinsText(minutes(j), resources);
                    }
                }
                return buildShortHoursText(hours(roundUpToUnit), resources);
            }
        }
        return buildShortDaysText(days(roundUpToUnit(j, TimeUnit.DAYS)), resources);
    }

    private final String buildWordsSingleUnitText(long j, Resources resources) {
        long roundUpToUnit = roundUpToUnit(j, TimeUnit.HOURS);
        if (!isGreaterOrEqual(this.mMinimumUnit, TimeUnit.DAYS)) {
            if (days(roundUpToUnit) <= 0) {
                j = roundUpToUnit(j, TimeUnit.MINUTES);
                if (!isGreaterOrEqual(this.mMinimumUnit, TimeUnit.HOURS)) {
                    if (hours(j) <= 0) {
                        return resources.getQuantityString(R.plurals.time_difference_words_minutes, minutes(j), new Object[]{Integer.valueOf(minutes(j))});
                    }
                }
                return resources.getQuantityString(R.plurals.time_difference_words_hours, hours(roundUpToUnit), new Object[]{Integer.valueOf(hours(roundUpToUnit))});
            }
        }
        return resources.getQuantityString(R.plurals.time_difference_words_days, days(roundUpToUnit(j, TimeUnit.DAYS)), new Object[]{Integer.valueOf(days(roundUpToUnit(j, TimeUnit.DAYS)))});
    }

    private static int days(long j) {
        return modToUnit(j, TimeUnit.DAYS);
    }

    private static long divRoundingUp(long j, long j2) {
        return (j / j2) + ((long) (j % j2 == 0 ? 0 : 1));
    }

    private final long getTimeDifference(long j) {
        long j2 = this.mReferencePeriodStart;
        if (j < j2) {
            j2 -= j;
        } else {
            j2 = this.mReferencePeriodEnd;
            if (j > j2) {
                return j - j2;
            }
            j2 = 0;
        }
        return j2;
    }

    private static int hours(long j) {
        return modToUnit(j, TimeUnit.HOURS);
    }

    private static boolean isGreaterOrEqual(TimeUnit timeUnit, TimeUnit timeUnit2) {
        return timeUnit != null && timeUnit.toMillis(1) >= timeUnit2.toMillis(1);
    }

    private static int minutes(long j) {
        return modToUnit(j, TimeUnit.MINUTES);
    }

    private static int modToUnit(long j, TimeUnit timeUnit) {
        int i;
        j /= timeUnit.toMillis(1);
        switch (C01192.$SwitchMap$java$util$concurrent$TimeUnit[timeUnit.ordinal()]) {
            case 1:
                i = 1000;
                break;
            case 2:
            case 3:
                i = 60;
                break;
            case 4:
                i = 24;
                break;
            case 5:
                i = Integer.MAX_VALUE;
                break;
            default:
                String valueOf = String.valueOf(timeUnit);
                StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 20);
                stringBuilder.append("Unit not supported: ");
                stringBuilder.append(valueOf);
                throw new IllegalArgumentException(stringBuilder.toString());
        }
        return (int) (j % ((long) i));
    }

    private static long roundUpToUnit(long j, TimeUnit timeUnit) {
        long toMillis = timeUnit.toMillis(1);
        return divRoundingUp(j, toMillis) * toMillis;
    }

    public final int describeContents() {
        return 0;
    }

    public final long getNextChangeTime(long j) {
        long precision = getPrecision();
        return (divRoundingUp(j, precision) * precision) + 1;
    }

    public final boolean returnsSameText(long j, long j2) {
        long precision = getPrecision();
        return divRoundingUp(getTimeDifference(j), precision) == divRoundingUp(getTimeDifference(j2), precision);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(this.mReferencePeriodStart);
        parcel.writeLong(this.mReferencePeriodEnd);
        parcel.writeInt(this.mStyle);
        parcel.writeByte(this.mShowNowText);
        TimeUnit timeUnit = this.mMinimumUnit;
        if (timeUnit == null) {
            i = -1;
        } else {
            i = timeUnit.ordinal();
        }
        parcel.writeInt(i);
    }

    protected TimeDifferenceText(Parcel parcel) {
        boolean z;
        TimeUnit timeUnit;
        this.mReferencePeriodStart = parcel.readLong();
        this.mReferencePeriodEnd = parcel.readLong();
        this.mStyle = parcel.readInt();
        if (parcel.readByte() != (byte) 0) {
            z = true;
        } else {
            z = false;
        }
        this.mShowNowText = z;
        int readInt = parcel.readInt();
        if (readInt == -1) {
            timeUnit = null;
        } else {
            timeUnit = TimeUnit.values()[readInt];
        }
        this.mMinimumUnit = timeUnit;
    }

    public final long getPrecision() {
        long toMillis;
        switch (this.mStyle) {
            case 1:
                toMillis = TimeUnit.SECONDS.toMillis(1);
                break;
            default:
                toMillis = TimeUnit.MINUTES.toMillis(1);
                break;
        }
        TimeUnit timeUnit = this.mMinimumUnit;
        if (timeUnit == null) {
            return toMillis;
        }
        return Math.max(toMillis, timeUnit.toMillis(1));
    }

    public final CharSequence getTextAt(Resources resources, long j) {
        j = getTimeDifference(j);
        if (j == 0) {
            if (this.mShowNowText) {
                return resources.getString(R.string.time_difference_now);
            }
        }
        CharSequence buildShortDualUnitText;
        switch (this.mStyle) {
            case 1:
                CharSequence buildShortDaysText;
                if (isGreaterOrEqual(this.mMinimumUnit, TimeUnit.DAYS)) {
                    buildShortDaysText = buildShortDaysText(days(roundUpToUnit(j, TimeUnit.DAYS)), resources);
                } else {
                    long roundUpToUnit = roundUpToUnit(j, TimeUnit.MINUTES);
                    if (!isGreaterOrEqual(this.mMinimumUnit, TimeUnit.HOURS)) {
                        if (days(roundUpToUnit) <= 0) {
                            long roundUpToUnit2 = roundUpToUnit(j, TimeUnit.SECONDS);
                            if (!isGreaterOrEqual(this.mMinimumUnit, TimeUnit.MINUTES)) {
                                if (hours(roundUpToUnit2) <= 0) {
                                    buildShortDaysText = String.format(Locale.US, "%02d:%02d", new Object[]{Integer.valueOf(minutes(roundUpToUnit2)), Integer.valueOf(modToUnit(roundUpToUnit2, TimeUnit.SECONDS))});
                                }
                            }
                            buildShortDaysText = String.format(Locale.US, "%d:%02d", new Object[]{Integer.valueOf(hours(roundUpToUnit)), Integer.valueOf(minutes(roundUpToUnit))});
                        }
                    }
                    buildShortDaysText = buildShortDualUnitText(j, resources);
                }
                return buildShortDaysText;
            case 2:
                return buildShortSingleUnitText(j, resources);
            case 3:
                buildShortDualUnitText = buildShortDualUnitText(j, resources);
                if (buildShortDualUnitText.length() <= 7) {
                    return buildShortDualUnitText;
                }
                return buildShortSingleUnitText(j, resources);
            case 4:
                return buildWordsSingleUnitText(j, resources);
            case 5:
                buildShortDualUnitText = buildWordsSingleUnitText(j, resources);
                if (buildShortDualUnitText.length() <= 7) {
                    return buildShortDualUnitText;
                }
                return buildShortSingleUnitText(j, resources);
            default:
                return buildShortSingleUnitText(j, resources);
        }
    }
}
