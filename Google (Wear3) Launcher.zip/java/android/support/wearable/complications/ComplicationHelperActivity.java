package android.support.wearable.complications;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Parcelable;
import androidx.core.content.ContextCompat;
import com.google.android.libraries.wear.wcs.baseclient.Constants;

/* compiled from: PG */
public final class ComplicationHelperActivity extends Activity {
    private int[] mTypes;
    private ComponentName mWatchFace;
    private int mWfComplicationId;

    private final boolean checkPermission() {
        if (ContextCompat.checkSelfPermission(this, "com.google.android.wearable.permission.RECEIVE_COMPLICATION_DATA_PRIVILEGED") != 0) {
            if (ContextCompat.checkSelfPermission(this, "com.google.android.wearable.permission.RECEIVE_COMPLICATION_DATA") != 0) {
                return false;
            }
        }
        return true;
    }

    protected final void onActivityResult(int i, int i2, Intent intent) {
        if (i == 1) {
            setResult(i2, intent);
            finish();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected final void onCreate(android.os.Bundle r6) {
        /*
        r5 = this;
        r0 = 16973840; // 0x1030010 float:2.4060945E-38 double:8.386191E-317;
        r5.setTheme(r0);
        super.onCreate(r6);
        r6 = r5.getIntent();
        r0 = r6.getAction();
        r1 = r0.hashCode();
        r2 = 1;
        r3 = 0;
        switch(r1) {
            case -121457581: goto L_0x0026;
            case 1414879715: goto L_0x001b;
            default: goto L_0x001a;
        };
    L_0x001a:
        goto L_0x0031;
        r1 = "android.support.wearable.complications.ACTION_START_PROVIDER_CHOOSER";
        r0 = r0.equals(r1);
        if (r0 == 0) goto L_0x001a;
    L_0x0024:
        r0 = 0;
        goto L_0x0032;
    L_0x0026:
        r1 = "android.support.wearable.complications.ACTION_PERMISSION_REQUEST_ONLY";
        r0 = r0.equals(r1);
        if (r0 == 0) goto L_0x001a;
        r0 = 1;
        goto L_0x0032;
    L_0x0031:
        r0 = -1;
    L_0x0032:
        r1 = "com.google.android.wearable.permission.RECEIVE_COMPLICATION_DATA";
        r4 = "android.support.wearable.complications.EXTRA_WATCH_FACE_COMPONENT_NAME";
        switch(r0) {
            case 0: goto L_0x005c;
            case 1: goto L_0x0041;
            default: goto L_0x0039;
        };
    L_0x0039:
        r6 = new java.lang.IllegalStateException;
        r0 = "Unrecognised intent action.";
        r6.<init>(r0);
        throw r6;
    L_0x0041:
        r6 = r6.getParcelableExtra(r4);
        r6 = (android.content.ComponentName) r6;
        r5.mWatchFace = r6;
        r6 = r5.checkPermission();
        if (r6 == 0) goto L_0x0053;
    L_0x004f:
        r5.finish();
        return;
    L_0x0053:
        r6 = new java.lang.String[r2];
        r6[r3] = r1;
        r0 = 2;
        androidx.core.app.ActivityCompat.requestPermissions(r5, r6, r0);
        return;
        r0 = r6.getParcelableExtra(r4);
        r0 = (android.content.ComponentName) r0;
        r5.mWatchFace = r0;
        r0 = "android.support.wearable.complications.EXTRA_COMPLICATION_ID";
        r0 = r6.getIntExtra(r0, r3);
        r5.mWfComplicationId = r0;
        r0 = "android.support.wearable.complications.EXTRA_SUPPORTED_TYPES";
        r6 = r6.getIntArrayExtra(r0);
        r5.mTypes = r6;
        r6 = r5.checkPermission();
        if (r6 == 0) goto L_0x007f;
    L_0x007b:
        r5.startProviderChooser();
        return;
    L_0x007f:
        r6 = new java.lang.String[r2];
        r6[r3] = r1;
        androidx.core.app.ActivityCompat.requestPermissions(r5, r6, r2);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.wearable.complications.ComplicationHelperActivity.onCreate(android.os.Bundle):void");
    }

    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (iArr.length != 0) {
            if (iArr[0] == 0) {
                if (i == 1) {
                    startProviderChooser();
                } else {
                    finish();
                }
                Parcelable parcelable = this.mWatchFace;
                Intent intent = new Intent("android.support.wearable.complications.ACTION_REQUEST_UPDATE_ALL_ACTIVE");
                intent.setPackage(Constants.WCS_PACKAGE_NAME);
                intent.putExtra("android.support.wearable.complications.EXTRA_WATCH_FACE_COMPONENT", parcelable);
                intent.putExtra("android.support.wearable.complications.EXTRA_PENDING_INTENT", PendingIntent.getActivity(this, 0, new Intent(""), 0));
                sendBroadcast(intent);
                return;
            }
            finish();
        }
    }

    private final void startProviderChooser() {
        Parcelable parcelable = this.mWatchFace;
        int i = this.mWfComplicationId;
        int[] iArr = this.mTypes;
        Intent intent = new Intent("com.google.android.clockwork.home.complications.ACTION_CHOOSE_PROVIDER");
        intent.putExtra("android.support.wearable.complications.EXTRA_WATCH_FACE_COMPONENT_NAME", parcelable);
        intent.putExtra("android.support.wearable.complications.EXTRA_COMPLICATION_ID", i);
        intent.putExtra("android.support.wearable.complications.EXTRA_SUPPORTED_TYPES", iArr);
        startActivityForResult(intent, 1);
    }
}
