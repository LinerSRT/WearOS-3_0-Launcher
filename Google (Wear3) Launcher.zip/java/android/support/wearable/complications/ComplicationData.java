package android.support.wearable.complications;

import android.app.PendingIntent;
import android.graphics.drawable.Icon;
import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Log;

/* compiled from: PG */
public final class ComplicationData implements Parcelable {
    public static final Creator CREATOR = new PG();
    private static final String[][] OPTIONAL_FIELDS;
    public static final String[][] REQUIRED_FIELDS;
    public final Bundle mFields;
    public final int mType;

    /* renamed from: android.support.wearable.complications.ComplicationData$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ComplicationData[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ComplicationData(parcel);
        }
    }

    /* compiled from: PG */
    public final class Builder {
        public final Bundle mFields;
        final int mType;

        public Builder(int i) {
            this.mType = i;
            this.mFields = new Bundle();
            if (i != 7) {
                if (i != 4) {
                    return;
                }
            }
            setSmallImageStyle$ar$ds(1);
        }

        public final ComplicationData build() {
            String[] strArr = ComplicationData.REQUIRED_FIELDS[this.mType];
            int length = strArr.length;
            int i = 0;
            while (i < length) {
                String str = strArr[i];
                if (this.mFields.containsKey(str)) {
                    if (this.mFields.containsKey("ICON_BURN_IN_PROTECTION")) {
                        if (!this.mFields.containsKey("ICON")) {
                            throw new IllegalStateException("Field ICON must be provided when field ICON_BURN_IN_PROTECTION is provided.");
                        }
                    }
                    if (this.mFields.containsKey("SMALL_IMAGE_BURN_IN_PROTECTION")) {
                        if (!this.mFields.containsKey("SMALL_IMAGE")) {
                            throw new IllegalStateException("Field SMALL_IMAGE must be provided when field SMALL_IMAGE_BURN_IN_PROTECTION is provided.");
                        }
                    }
                    i++;
                } else {
                    length = this.mType;
                    StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 39);
                    stringBuilder.append("Field ");
                    stringBuilder.append(str);
                    stringBuilder.append(" is required for type ");
                    stringBuilder.append(length);
                    throw new IllegalStateException(stringBuilder.toString());
                }
            }
            return new ComplicationData(this);
        }

        public final void setContentDescription$ar$ds$c96836d_0(ComplicationText complicationText) {
            putOrRemoveField("IMAGE_CONTENT_DESCRIPTION", complicationText);
        }

        public final void setShortText$ar$ds(ComplicationText complicationText) {
            putOrRemoveField("SHORT_TEXT", complicationText);
        }

        public final void setShortTitle$ar$ds(ComplicationText complicationText) {
            putOrRemoveField("SHORT_TITLE", complicationText);
        }

        public final void setTapAction$ar$ds(PendingIntent pendingIntent) {
            putOrRemoveField("TAP_ACTION", pendingIntent);
        }

        public final void putFloatField(String str, float f) {
            ComplicationData.checkFieldValidForType(str, this.mType);
            this.mFields.putFloat(str, f);
        }

        public final void putOrRemoveField(String str, Object obj) {
            ComplicationData.checkFieldValidForType(str, this.mType);
            if (obj == null) {
                this.mFields.remove(str);
            } else if (obj instanceof String) {
                this.mFields.putString(str, (String) obj);
            } else if (obj instanceof Parcelable) {
                this.mFields.putParcelable(str, (Parcelable) obj);
            } else {
                String valueOf = String.valueOf(obj.getClass());
                StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 24);
                stringBuilder.append("Unexpected object type: ");
                stringBuilder.append(valueOf);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }

        public final void setSmallImageStyle$ar$ds(int i) {
            String str = "IMAGE_STYLE";
            ComplicationData.checkFieldValidForType(str, this.mType);
            this.mFields.putInt(str, i);
        }

        public Builder(ComplicationData complicationData) {
            this.mType = complicationData.mType;
            this.mFields = (Bundle) complicationData.mFields.clone();
        }
    }

    static {
        String[][] strArr = new String[11][];
        strArr[0] = null;
        strArr[1] = new String[0];
        strArr[2] = new String[0];
        String[] strArr2 = new String[1];
        strArr2[0] = "SHORT_TEXT";
        strArr[3] = strArr2;
        strArr[4] = new String[]{"LONG_TEXT"};
        strArr[5] = new String[]{"VALUE", "MIN_VALUE", "MAX_VALUE"};
        strArr2 = new String[1];
        String str = "ICON";
        strArr2[0] = str;
        strArr[6] = strArr2;
        strArr2 = new String[2];
        strArr2[0] = "SMALL_IMAGE";
        String str2 = "IMAGE_STYLE";
        strArr2[1] = str2;
        strArr[7] = strArr2;
        strArr[8] = new String[]{"LARGE_IMAGE"};
        strArr[9] = new String[0];
        strArr[10] = new String[0];
        REQUIRED_FIELDS = strArr;
        r0 = new String[11][];
        r1 = new String[5];
        r1[0] = "SHORT_TITLE";
        r1[1] = str;
        r1[2] = "ICON_BURN_IN_PROTECTION";
        String str3 = "TAP_ACTION";
        r1[3] = str3;
        String str4 = "IMAGE_CONTENT_DESCRIPTION";
        r1[4] = str4;
        r0[3] = r1;
        r1 = new String[8];
        r1[4] = "SMALL_IMAGE_BURN_IN_PROTECTION";
        r1[5] = str2;
        r1[6] = str3;
        r1[7] = str4;
        r0[4] = r1;
        r0[5] = new String[]{"SHORT_TEXT", "SHORT_TITLE", str, "ICON_BURN_IN_PROTECTION", str3, str4};
        r0[6] = new String[]{str3, "ICON_BURN_IN_PROTECTION", str4};
        r0[7] = new String[]{str3, "SMALL_IMAGE_BURN_IN_PROTECTION", str4};
        r0[8] = new String[]{str3, str4};
        r0[9] = new String[]{"SHORT_TEXT", "SHORT_TITLE", str, "ICON_BURN_IN_PROTECTION", str4};
        r0[10] = new String[0];
        OPTIONAL_FIELDS = r0;
    }

    public ComplicationData(Parcel parcel) {
        this.mType = parcel.readInt();
        this.mFields = parcel.readBundle(getClass().getClassLoader());
    }

    public ComplicationData(Builder builder) {
        this.mType = builder.mType;
        this.mFields = builder.mFields;
    }

    public static void checkFieldValidForType(String str, int i) {
        if (!isTypeSupported(i)) {
            StringBuilder stringBuilder = new StringBuilder(38);
            stringBuilder.append("Type ");
            stringBuilder.append(i);
            stringBuilder.append(" can not be recognized");
            throw new IllegalStateException(stringBuilder.toString());
        } else if (!isFieldValidForType(str, i)) {
            StringBuilder stringBuilder2 = new StringBuilder(str.length() + 44);
            stringBuilder2.append("Field ");
            stringBuilder2.append(str);
            stringBuilder2.append(" is not supported for type ");
            stringBuilder2.append(i);
            throw new IllegalStateException(stringBuilder2.toString());
        }
    }

    private static void checkFieldValidForTypeWithoutThrowingException(String str, int i) {
        String str2 = "ComplicationData";
        if (isTypeSupported(i)) {
            if (!isFieldValidForType(str, i) && Log.isLoggable(str2, 3)) {
                StringBuilder stringBuilder = new StringBuilder(str.length() + 44);
                stringBuilder.append("Field ");
                stringBuilder.append(str);
                stringBuilder.append(" is not supported for type ");
                stringBuilder.append(i);
                Log.d(str2, stringBuilder.toString());
            }
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder(38);
        stringBuilder2.append("Type ");
        stringBuilder2.append(i);
        stringBuilder2.append(" can not be recognized");
        Log.w(str2, stringBuilder2.toString());
    }

    private final Parcelable getParcelableField(String str) {
        try {
            return this.mFields.getParcelable(str);
        } catch (Throwable e) {
            Log.w("ComplicationData", "Could not unparcel ComplicationData. Provider apps must exclude wearable support complication classes from proguard.", e);
            return null;
        }
    }

    private static boolean isFieldValidForType(String str, int i) {
        for (String equals : REQUIRED_FIELDS[i]) {
            if (equals.equals(str)) {
                return true;
            }
        }
        for (String equals2 : OPTIONAL_FIELDS[i]) {
            if (equals2.equals(str)) {
                return true;
            }
        }
        return false;
    }

    private final boolean isTimeDependentField(String str) {
        ComplicationText complicationText = (ComplicationText) getParcelableField(str);
        return (complicationText == null || complicationText.mTimeDependentText == null) ? false : true;
    }

    private static boolean isTypeSupported(int i) {
        return i > 0 && i <= 11;
    }

    public final int describeContents() {
        return 0;
    }

    public final Icon getBurnInProtectionIcon() {
        String str = "ICON_BURN_IN_PROTECTION";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (Icon) getParcelableField(str);
    }

    public final Icon getBurnInProtectionSmallImage() {
        String str = "SMALL_IMAGE_BURN_IN_PROTECTION";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (Icon) getParcelableField(str);
    }

    public final ComplicationText getContentDescription() {
        String str = "IMAGE_CONTENT_DESCRIPTION";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (ComplicationText) getParcelableField(str);
    }

    public final long getEndDateTimeMillis() {
        return this.mFields.getLong("END_TIME", Long.MAX_VALUE);
    }

    public final Icon getIcon() {
        String str = "ICON";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (Icon) getParcelableField(str);
    }

    public final Icon getLargeImage() {
        String str = "LARGE_IMAGE";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (Icon) getParcelableField(str);
    }

    public final ComplicationText getLongText() {
        String str = "LONG_TEXT";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (ComplicationText) getParcelableField(str);
    }

    public final ComplicationText getLongTitle() {
        String str = "LONG_TITLE";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (ComplicationText) getParcelableField(str);
    }

    public final float getRangedMaxValue() {
        String str = "MAX_VALUE";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return this.mFields.getFloat(str);
    }

    public final float getRangedMinValue() {
        String str = "MIN_VALUE";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return this.mFields.getFloat(str);
    }

    public final float getRangedValue() {
        String str = "VALUE";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return this.mFields.getFloat(str);
    }

    public final ComplicationText getShortText() {
        String str = "SHORT_TEXT";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (ComplicationText) getParcelableField(str);
    }

    public final ComplicationText getShortTitle() {
        String str = "SHORT_TITLE";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (ComplicationText) getParcelableField(str);
    }

    public final Icon getSmallImage() {
        String str = "SMALL_IMAGE";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (Icon) getParcelableField(str);
    }

    public final int getSmallImageStyle() {
        String str = "IMAGE_STYLE";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return this.mFields.getInt(str);
    }

    public final long getStartDateTimeMillis() {
        return this.mFields.getLong("START_TIME", 0);
    }

    public final PendingIntent getTapAction() {
        String str = "TAP_ACTION";
        checkFieldValidForTypeWithoutThrowingException(str, this.mType);
        return (PendingIntent) getParcelableField(str);
    }

    public final boolean hasContentDescription() {
        String str = "IMAGE_CONTENT_DESCRIPTION";
        try {
            return isFieldValidForType(str, this.mType) && this.mFields.getParcelable(str) != null;
        } catch (BadParcelableException e) {
            return false;
        }
    }

    public final boolean hasShortText() {
        String str = "SHORT_TEXT";
        try {
            return isFieldValidForType(str, this.mType) && this.mFields.getParcelable(str) != null;
        } catch (BadParcelableException e) {
            return false;
        }
    }

    public final boolean hasShortTitle() {
        String str = "SHORT_TITLE";
        try {
            return isFieldValidForType(str, this.mType) && this.mFields.getParcelable(str) != null;
        } catch (BadParcelableException e) {
            return false;
        }
    }

    public final boolean isActiveAt(long j) {
        return j >= this.mFields.getLong("START_TIME", 0) && j <= this.mFields.getLong("END_TIME", Long.MAX_VALUE);
    }

    public final boolean isTimeDependent() {
        if (!(isTimeDependentField("SHORT_TEXT") || isTimeDependentField("SHORT_TITLE") || isTimeDependentField("LONG_TEXT"))) {
            if (!isTimeDependentField("LONG_TITLE")) {
                return false;
            }
        }
        return true;
    }

    public final String toString() {
        int i = this.mType;
        String valueOf = String.valueOf(this.mFields);
        StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf).length() + 45);
        stringBuilder.append("ComplicationData{mType=");
        stringBuilder.append(i);
        stringBuilder.append(", mFields=");
        stringBuilder.append(valueOf);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.mType);
        parcel.writeBundle(this.mFields);
    }
}
