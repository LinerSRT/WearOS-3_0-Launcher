package android.support.wearable.complications;

import android.content.res.Resources;
import android.os.Parcelable;

/* compiled from: PG */
public interface TimeDependentText extends Parcelable {
    long getNextChangeTime(long j);

    CharSequence getTextAt(Resources resources, long j);

    boolean returnsSameText(long j, long j2);
}
