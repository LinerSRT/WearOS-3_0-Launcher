package android.support.wearable.complications;

import android.os.IBinder;
import android.os.IInterface;
import com.google.android.aidl.BaseProxy;

/* compiled from: PG */
public final class IComplicationManager$Stub$Proxy extends BaseProxy implements IInterface {
    public IComplicationManager$Stub$Proxy(IBinder iBinder) {
        super(iBinder, "android.support.wearable.complications.IComplicationManager");
    }
}
