package android.support.wearable.complications.rendering;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import p020j$.util.Objects;

/* compiled from: PG */
final class RoundedDrawable extends Drawable {
    private Drawable mDrawable;
    final Paint mPaint;
    public int mRadius;
    private final RectF mTmpBounds = new RectF();

    public RoundedDrawable() {
        Paint paint = new Paint();
        this.mPaint = paint;
        paint.setAntiAlias(true);
    }

    private final void updateBitmapShader() {
        if (this.mDrawable != null) {
            Rect bounds = getBounds();
            if (!bounds.isEmpty()) {
                Drawable drawable = this.mDrawable;
                int width = bounds.width();
                int height = bounds.height();
                Bitmap createBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
                Canvas canvas = new Canvas(createBitmap);
                int intrinsicWidth = drawable.getIntrinsicWidth();
                int intrinsicHeight = drawable.getIntrinsicHeight();
                if (intrinsicWidth > intrinsicHeight) {
                    intrinsicWidth = (((int) (((float) width) * (((float) intrinsicWidth) / ((float) intrinsicHeight)))) - width) / 2;
                    drawable.setBounds(-intrinsicWidth, 0, width + intrinsicWidth, height);
                } else {
                    intrinsicWidth = (((int) (((float) height) * (((float) intrinsicHeight) / ((float) intrinsicWidth)))) - height) / 2;
                    drawable.setBounds(0, -intrinsicWidth, width, height + intrinsicWidth);
                }
                drawable.draw(canvas);
                this.mPaint.setShader(new BitmapShader(createBitmap, TileMode.CLAMP, TileMode.CLAMP));
            }
        }
    }

    public final void draw(Canvas canvas) {
        Rect bounds = getBounds();
        if (this.mDrawable != null) {
            if (!bounds.isEmpty()) {
                canvas.save();
                canvas.translate((float) bounds.left, (float) bounds.top);
                float f = (float) this.mRadius;
                canvas.drawRoundRect(this.mTmpBounds, f, f, this.mPaint);
                canvas.restore();
            }
        }
    }

    public final int getOpacity() {
        return -3;
    }

    protected final void onBoundsChange(Rect rect) {
        this.mTmpBounds.right = (float) rect.width();
        this.mTmpBounds.bottom = (float) rect.height();
        updateBitmapShader();
    }

    public final void setAlpha(int i) {
        this.mPaint.setAlpha(i);
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        this.mPaint.setColorFilter(colorFilter);
    }

    public final void setDrawable(Drawable drawable) {
        if (!Objects.equals(this.mDrawable, drawable)) {
            this.mDrawable = drawable;
            updateBitmapShader();
        }
    }
}
