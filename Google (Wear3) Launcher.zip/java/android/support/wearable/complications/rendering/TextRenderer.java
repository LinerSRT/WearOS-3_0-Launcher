package android.support.wearable.complications.rendering;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.text.Layout.Alignment;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.StaticLayout.Builder;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.text.style.ForegroundColorSpan;
import android.text.style.LocaleSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.SubscriptSpan;
import android.text.style.SuperscriptSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import android.view.Gravity;
import p020j$.util.Objects;

/* compiled from: PG */
public final class TextRenderer {
    private static final Class[] SPAN_WHITELIST = new Class[]{ForegroundColorSpan.class, LocaleSpan.class, SubscriptSpan.class, SuperscriptSpan.class, StrikethroughSpan.class, StyleSpan.class, TypefaceSpan.class, UnderlineSpan.class};
    private Alignment mAlignment = Alignment.ALIGN_CENTER;
    private String mAmbientModeText;
    private final Rect mBounds = new Rect();
    private final TruncateAt mEllipsize = TruncateAt.END;
    private int mGravity = 17;
    private boolean mInAmbientMode = false;
    private int mMaxLines = 1;
    private boolean mNeedCalculateBounds;
    private boolean mNeedUpdateLayout;
    private CharSequence mOriginalText;
    private final Rect mOutputRect = new Rect();
    private TextPaint mPaint;
    private float mRelativePaddingStart;
    private StaticLayout mStaticLayout;
    private CharSequence mText;
    private final Rect mWorkingRect = new Rect();

    public final void draw(Canvas canvas, Rect rect) {
        if (!TextUtils.isEmpty(this.mText)) {
            if (!(!this.mNeedUpdateLayout && this.mBounds.width() == rect.width() && this.mBounds.height() == rect.height())) {
                int i;
                int width = rect.width();
                int height = rect.height();
                if (this.mPaint == null) {
                    setPaint(new TextPaint());
                }
                width = (int) (((float) width) * ((1.0f - this.mRelativePaddingStart) + 0.0f));
                TextPaint textPaint = new TextPaint(this.mPaint);
                textPaint.setTextSize(Math.min((float) (height / this.mMaxLines), textPaint.getTextSize()));
                CharSequence charSequence = this.mText;
                float f = (float) width;
                if (textPaint.measureText(charSequence, 0, charSequence.length()) > f) {
                    TruncateAt truncateAt = this.mEllipsize;
                    i = 7;
                    if (truncateAt != null && truncateAt != TruncateAt.MARQUEE) {
                        i = 8;
                    }
                    charSequence = this.mText.subSequence(0, Math.min(i, this.mText.length()));
                    for (float measureText = textPaint.measureText(charSequence, 0, charSequence.length()); measureText > f; measureText = textPaint.measureText(charSequence, 0, charSequence.length())) {
                        textPaint.setTextSize(textPaint.getTextSize() - 4.0f);
                    }
                }
                charSequence = this.mText;
                if (this.mInAmbientMode) {
                    int i2 = EmojiHelper.EmojiHelper$ar$NoOp;
                    if (charSequence == null) {
                        charSequence = null;
                    } else {
                        StringBuilder stringBuilder = new StringBuilder(charSequence.length());
                        i = charSequence.length();
                        int i3 = 0;
                        boolean z = false;
                        while (i3 < i) {
                            int codePointAt = Character.codePointAt(charSequence, i3);
                            if (!EmojiHelper.isEmoji(codePointAt)) {
                                stringBuilder.appendCodePoint(codePointAt);
                            } else if (!z) {
                                stringBuilder.appendCodePoint(32);
                            }
                            z = EmojiHelper.isEmoji(codePointAt);
                            i3 += Character.charCount(codePointAt);
                        }
                        charSequence = stringBuilder.toString();
                    }
                    this.mAmbientModeText = charSequence;
                }
                Builder obtain = Builder.obtain(charSequence, 0, charSequence.length(), textPaint, width);
                obtain.setBreakStrategy(1);
                obtain.setEllipsize(this.mEllipsize);
                obtain.setHyphenationFrequency(2);
                obtain.setMaxLines(this.mMaxLines);
                obtain.setAlignment(this.mAlignment);
                this.mStaticLayout = obtain.build();
                this.mNeedUpdateLayout = false;
                this.mNeedCalculateBounds = true;
            }
            if (this.mNeedCalculateBounds || !this.mBounds.equals(rect)) {
                float f2;
                float f3;
                this.mBounds.set(rect);
                int isLtr = isLtr() ^ 1;
                float width2 = (float) this.mBounds.width();
                if (isLtr()) {
                    f2 = this.mRelativePaddingStart;
                } else {
                    f2 = 0.0f;
                }
                int i4 = (int) (width2 * f2);
                f2 = (float) this.mBounds.width();
                if (isLtr()) {
                    f3 = 0.0f;
                } else {
                    f3 = this.mRelativePaddingStart;
                }
                this.mWorkingRect.set(this.mBounds.left + i4, this.mBounds.top + ((int) (((float) this.mBounds.height()) * 0.0f)), this.mBounds.right - ((int) (f2 * f3)), this.mBounds.bottom - ((int) (((float) this.mBounds.height()) * 0.0f)));
                Gravity.apply(this.mGravity, this.mStaticLayout.getWidth(), this.mStaticLayout.getHeight(), this.mWorkingRect, this.mOutputRect, isLtr);
                this.mNeedCalculateBounds = false;
            }
            canvas.save();
            canvas.translate((float) this.mOutputRect.left, (float) this.mOutputRect.top);
            this.mStaticLayout.draw(canvas);
            canvas.restore();
        }
    }

    public final boolean isLtr() {
        return this.mStaticLayout.getParagraphDirection(0) == 1;
    }

    public final void setAlignment(Alignment alignment) {
        if (this.mAlignment != alignment) {
            this.mAlignment = alignment;
            this.mNeedUpdateLayout = true;
        }
    }

    public final void setGravity(int i) {
        if (this.mGravity != i) {
            this.mGravity = i;
            this.mNeedCalculateBounds = true;
        }
    }

    public final void setInAmbientMode(boolean z) {
        if (this.mInAmbientMode != z) {
            this.mInAmbientMode = z;
            if (!TextUtils.equals(this.mAmbientModeText, this.mText)) {
                this.mNeedUpdateLayout = true;
            }
        }
    }

    public final void setMaxLines(int i) {
        if (this.mMaxLines != i) {
            this.mMaxLines = i;
            this.mNeedUpdateLayout = true;
        }
    }

    public final void setPaint(TextPaint textPaint) {
        this.mPaint = textPaint;
        this.mNeedUpdateLayout = true;
    }

    public final void setRelativePadding$ar$ds(float f) {
        if (this.mRelativePaddingStart != f) {
            this.mRelativePaddingStart = f;
            this.mNeedUpdateLayout = true;
        }
    }

    public final void setText(CharSequence charSequence) {
        if (!Objects.equals(this.mOriginalText, charSequence)) {
            this.mOriginalText = charSequence;
            if (charSequence instanceof Spanned) {
                SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(charSequence);
                for (Object obj : spannableStringBuilder.getSpans(0, charSequence.length(), Object.class)) {
                    Class[] clsArr = SPAN_WHITELIST;
                    for (int i = 0; i < 8; i++) {
                        if (clsArr[i].isInstance(obj)) {
                            break;
                        }
                    }
                    spannableStringBuilder.removeSpan(obj);
                }
                charSequence = spannableStringBuilder;
            }
            this.mText = charSequence;
            this.mNeedUpdateLayout = true;
        }
    }
}
