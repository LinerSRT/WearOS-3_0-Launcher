package android.support.wearable.complications.rendering;

import android.content.Context;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.graphics.drawable.Icon.OnDrawableLoadedListener;
import android.os.Handler;
import android.os.Looper;
import android.support.wearable.complications.ComplicationData;
import android.support.wearable.complications.ComplicationText;
import android.support.wearable.complications.rendering.ComplicationStyle.Builder;
import android.support.wearable.complications.rendering.utils.IconLayoutHelper;
import android.support.wearable.complications.rendering.utils.LargeImageLayoutHelper;
import android.support.wearable.complications.rendering.utils.LayoutHelper;
import android.support.wearable.complications.rendering.utils.LayoutUtils;
import android.support.wearable.complications.rendering.utils.LongTextLayoutHelper;
import android.support.wearable.complications.rendering.utils.RangedValueLayoutHelper;
import android.support.wearable.complications.rendering.utils.ShortTextLayoutHelper;
import android.support.wearable.complications.rendering.utils.SmallImageLayoutHelper;
import android.text.Layout.Alignment;
import android.text.TextPaint;
import p020j$.util.Objects;

/* compiled from: PG */
final class ComplicationRenderer {
    PaintSet mActivePaintSet = null;
    private ComplicationStyle mActiveStyle;
    PaintSet mAmbientPaintSet = null;
    public ComplicationStyle mAmbientStyle;
    public final Rect mBackgroundBounds = new Rect();
    public final RectF mBackgroundBoundsF = new RectF();
    public final Rect mBounds = new Rect();
    public Drawable mBurnInProtectionIcon;
    public Drawable mBurnInProtectionSmallImage;
    public ComplicationData mComplicationData;
    public final Context mContext;
    private boolean mHasNoData;
    public Drawable mIcon;
    public final Rect mIconBounds = new Rect();
    public OnInvalidateListener mInvalidateListener;
    public Drawable mLargeImage;
    public final Rect mLargeImageBounds = new Rect();
    public final Rect mMainTextBounds = new Rect();
    public TextPaint mMainTextPaint = null;
    public final TextRenderer mMainTextRenderer = new TextRenderer();
    private CharSequence mNoDataText = "";
    private final Rect mRangedValueBounds = new Rect();
    public final RectF mRangedValueBoundsF = new RectF();
    private boolean mRangedValueProgressHidden;
    public final RoundedDrawable mRoundedBackgroundDrawable = new RoundedDrawable();
    public final RoundedDrawable mRoundedLargeImage = new RoundedDrawable();
    public final RoundedDrawable mRoundedSmallImage = new RoundedDrawable();
    public Drawable mSmallImage;
    public final Rect mSmallImageBounds = new Rect();
    public final Rect mSubTextBounds = new Rect();
    public TextPaint mSubTextPaint = null;
    public final TextRenderer mSubTextRenderer = new TextRenderer();

    /* renamed from: android.support.wearable.complications.rendering.ComplicationRenderer$1 */
    final class PG implements OnDrawableLoadedListener {
        public final void onDrawableLoaded(Drawable drawable) {
            if (drawable != null) {
                ComplicationRenderer complicationRenderer = ComplicationRenderer.this;
                complicationRenderer.mIcon = drawable;
                complicationRenderer.mIcon.mutate();
                ComplicationRenderer.this.invalidate();
            }
        }
    }

    /* renamed from: android.support.wearable.complications.rendering.ComplicationRenderer$2 */
    final class C01222 implements OnDrawableLoadedListener {
        public final void onDrawableLoaded(Drawable drawable) {
            if (drawable != null) {
                ComplicationRenderer complicationRenderer = ComplicationRenderer.this;
                complicationRenderer.mBurnInProtectionIcon = drawable;
                complicationRenderer.mBurnInProtectionIcon.mutate();
                ComplicationRenderer.this.invalidate();
            }
        }
    }

    /* renamed from: android.support.wearable.complications.rendering.ComplicationRenderer$3 */
    final class C01233 implements OnDrawableLoadedListener {
        public final void onDrawableLoaded(Drawable drawable) {
            if (drawable != null) {
                ComplicationRenderer complicationRenderer = ComplicationRenderer.this;
                complicationRenderer.mSmallImage = drawable;
                complicationRenderer.invalidate();
            }
        }
    }

    /* renamed from: android.support.wearable.complications.rendering.ComplicationRenderer$4 */
    final class C01244 implements OnDrawableLoadedListener {
        public final void onDrawableLoaded(Drawable drawable) {
            if (drawable != null) {
                ComplicationRenderer complicationRenderer = ComplicationRenderer.this;
                complicationRenderer.mBurnInProtectionSmallImage = drawable;
                complicationRenderer.invalidate();
            }
        }
    }

    /* renamed from: android.support.wearable.complications.rendering.ComplicationRenderer$5 */
    final class C01255 implements OnDrawableLoadedListener {
        public final void onDrawableLoaded(Drawable drawable) {
            if (drawable != null) {
                ComplicationRenderer complicationRenderer = ComplicationRenderer.this;
                complicationRenderer.mLargeImage = drawable;
                complicationRenderer.invalidate();
            }
        }
    }

    /* compiled from: PG */
    interface OnInvalidateListener {
        void onInvalidate();
    }

    /* compiled from: PG */
    final class PaintSet {
        final Paint backgroundPaint;
        final Paint borderPaint;
        final boolean burnInProtection;
        final Paint highlightPaint;
        final ColorFilter iconColorFilter;
        final Paint inProgressPaint;
        final boolean isAmbientStyle;
        final boolean lowBitAmbient;
        final TextPaint primaryTextPaint;
        final Paint remainingPaint;
        final TextPaint secondaryTextPaint;
        final ComplicationStyle style;

        final boolean isInBurnInProtectionMode() {
            return this.isAmbientStyle && this.burnInProtection;
        }

        public PaintSet(ComplicationStyle complicationStyle, boolean z, boolean z2, boolean z3) {
            int i;
            ColorFilter porterDuffColorFilter;
            this.style = complicationStyle;
            this.isAmbientStyle = z;
            this.lowBitAmbient = z2;
            this.burnInProtection = z3;
            z = z ? !z2 : true;
            if (z2) {
                Builder builder = new Builder(complicationStyle);
                if (complicationStyle.mBackgroundColor != -16777216) {
                    builder.backgroundColor = 0;
                }
                builder.textColor = -1;
                builder.titleColor = -1;
                builder.iconColor = -1;
                i = complicationStyle.mBorderColor;
                if (!(i == -16777216 || i == 0)) {
                    builder.borderColor = -1;
                }
                builder.rangedValuePrimaryColor = -1;
                if (complicationStyle.mRangedValueSecondaryColor != -16777216) {
                    builder.rangedValueSecondaryColor = 0;
                }
                complicationStyle = builder.build();
            }
            TextPaint textPaint = new TextPaint();
            this.primaryTextPaint = textPaint;
            textPaint.setColor(complicationStyle.mTextColor);
            textPaint.setAntiAlias(z);
            textPaint.setTypeface(complicationStyle.mTextTypeface);
            textPaint.setTextSize((float) complicationStyle.mTextSize);
            textPaint.setAntiAlias(z);
            if (z) {
                porterDuffColorFilter = new PorterDuffColorFilter(complicationStyle.mIconColor, Mode.SRC_IN);
            } else {
                i = complicationStyle.mIconColor;
                porterDuffColorFilter = new ColorMatrixColorFilter(new ColorMatrix(new float[]{0.0f, 0.0f, 0.0f, 0.0f, (float) Color.red(i), 0.0f, 0.0f, 0.0f, 0.0f, (float) Color.green(i), 0.0f, 0.0f, 0.0f, 0.0f, (float) Color.blue(i), 0.0f, 0.0f, 0.0f, 255.0f, -32385.0f}));
            }
            this.iconColorFilter = porterDuffColorFilter;
            TextPaint textPaint2 = new TextPaint();
            this.secondaryTextPaint = textPaint2;
            textPaint2.setColor(complicationStyle.mTitleColor);
            textPaint2.setAntiAlias(z);
            textPaint2.setTypeface(complicationStyle.mTitleTypeface);
            textPaint2.setTextSize((float) complicationStyle.mTitleSize);
            textPaint2.setAntiAlias(z);
            Paint paint = new Paint();
            this.inProgressPaint = paint;
            paint.setColor(complicationStyle.mRangedValuePrimaryColor);
            paint.setStyle(Style.STROKE);
            paint.setAntiAlias(z);
            paint.setStrokeWidth((float) complicationStyle.mRangedValueRingWidth);
            paint = new Paint();
            this.remainingPaint = paint;
            paint.setColor(complicationStyle.mRangedValueSecondaryColor);
            paint.setStyle(Style.STROKE);
            paint.setAntiAlias(z);
            paint.setStrokeWidth((float) complicationStyle.mRangedValueRingWidth);
            paint = new Paint();
            this.borderPaint = paint;
            paint.setStyle(Style.STROKE);
            paint.setColor(complicationStyle.mBorderColor);
            if (complicationStyle.mBorderStyle == 2) {
                paint.setPathEffect(new DashPathEffect(new float[]{(float) complicationStyle.mBorderDashWidth, (float) complicationStyle.mBorderDashGap}, 0.0f));
            }
            if (complicationStyle.mBorderStyle == 0) {
                paint.setAlpha(0);
            }
            paint.setStrokeWidth((float) complicationStyle.mBorderWidth);
            paint.setAntiAlias(z);
            Paint paint2 = new Paint();
            this.backgroundPaint = paint2;
            paint2.setColor(complicationStyle.mBackgroundColor);
            paint2.setAntiAlias(z);
            paint2 = new Paint();
            this.highlightPaint = paint2;
            paint2.setColor(complicationStyle.mHighlightColor);
            paint2.setAntiAlias(z);
        }
    }

    public ComplicationRenderer(Context context, ComplicationStyle complicationStyle, ComplicationStyle complicationStyle2) {
        this.mContext = context;
        updateStyle(complicationStyle, complicationStyle2);
    }

    private final void calculateBounds() {
        if (this.mComplicationData != null) {
            if (!this.mBounds.isEmpty()) {
                LayoutHelper shortTextLayoutHelper;
                Alignment longTextAlignment;
                this.mBackgroundBounds.set(0, 0, this.mBounds.width(), this.mBounds.height());
                this.mBackgroundBoundsF.set(0.0f, 0.0f, (float) this.mBounds.width(), (float) this.mBounds.height());
                ComplicationData complicationData = this.mComplicationData;
                switch (complicationData.mType) {
                    case 3:
                    case 9:
                        shortTextLayoutHelper = new ShortTextLayoutHelper();
                        break;
                    case 4:
                        shortTextLayoutHelper = new LongTextLayoutHelper();
                        break;
                    case 5:
                        if (this.mRangedValueProgressHidden) {
                            if (complicationData.getShortText() != null) {
                                shortTextLayoutHelper = new ShortTextLayoutHelper();
                                break;
                            } else {
                                shortTextLayoutHelper = new IconLayoutHelper();
                                break;
                            }
                        }
                        shortTextLayoutHelper = new RangedValueLayoutHelper();
                        break;
                    case 6:
                        shortTextLayoutHelper = new IconLayoutHelper();
                        break;
                    case 7:
                        shortTextLayoutHelper = new SmallImageLayoutHelper();
                        break;
                    case 8:
                        shortTextLayoutHelper = new LargeImageLayoutHelper();
                        break;
                    default:
                        shortTextLayoutHelper = new LayoutHelper();
                        break;
                }
                shortTextLayoutHelper.update(this.mBounds.width(), this.mBounds.height(), this.mComplicationData);
                shortTextLayoutHelper.getRangedValueBounds(this.mRangedValueBounds);
                this.mRangedValueBoundsF.set(this.mRangedValueBounds);
                shortTextLayoutHelper.getIconBounds(this.mIconBounds);
                shortTextLayoutHelper.getSmallImageBounds(this.mSmallImageBounds);
                shortTextLayoutHelper.getLargeImageBounds(this.mLargeImageBounds);
                if (this.mComplicationData.mType == 4) {
                    longTextAlignment = shortTextLayoutHelper.getLongTextAlignment();
                    shortTextLayoutHelper.getLongTextBounds(this.mMainTextBounds);
                    this.mMainTextRenderer.setAlignment(longTextAlignment);
                    this.mMainTextRenderer.setGravity(shortTextLayoutHelper.getLongTextGravity());
                    shortTextLayoutHelper.getLongTitleBounds(this.mSubTextBounds);
                    this.mSubTextRenderer.setAlignment(shortTextLayoutHelper.getLongTitleAlignment());
                    this.mSubTextRenderer.setGravity(shortTextLayoutHelper.getLongTitleGravity());
                } else {
                    longTextAlignment = shortTextLayoutHelper.getShortTextAlignment();
                    shortTextLayoutHelper.getShortTextBounds(this.mMainTextBounds);
                    this.mMainTextRenderer.setAlignment(longTextAlignment);
                    this.mMainTextRenderer.setGravity(shortTextLayoutHelper.getShortTextGravity());
                    shortTextLayoutHelper.getShortTitleBounds(this.mSubTextBounds);
                    this.mSubTextRenderer.setAlignment(shortTextLayoutHelper.getShortTitleAlignment());
                    this.mSubTextRenderer.setGravity(shortTextLayoutHelper.getShortTitleGravity());
                }
                if (longTextAlignment != Alignment.ALIGN_CENTER) {
                    float height = ((float) this.mBounds.height()) * 0.1f;
                    this.mMainTextRenderer.setRelativePadding$ar$ds(height / ((float) this.mMainTextBounds.width()));
                    this.mSubTextRenderer.setRelativePadding$ar$ds(height / ((float) this.mMainTextBounds.width()));
                } else {
                    this.mMainTextRenderer.setRelativePadding$ar$ds(0.0f);
                    this.mSubTextRenderer.setRelativePadding$ar$ds(0.0f);
                }
                Rect rect = new Rect();
                Rect rect2 = this.mBackgroundBounds;
                int max = Math.max(getBorderRadius(this.mActiveStyle), getBorderRadius(this.mAmbientStyle));
                rect.set(rect2);
                double sqrt = Math.sqrt(2.0d) - 4.0d;
                double d = (double) ((float) max);
                Double.isNaN(d);
                int ceil = (int) Math.ceil(sqrt * d);
                rect.inset(ceil, ceil);
                if (!this.mMainTextBounds.intersect(rect)) {
                    this.mMainTextBounds.setEmpty();
                }
                if (!this.mSubTextBounds.intersect(rect)) {
                    this.mSubTextBounds.setEmpty();
                }
                if (!this.mIconBounds.isEmpty()) {
                    rect2 = this.mIconBounds;
                    LayoutUtils.scaledAroundCenter(rect2, rect2, 1.0f);
                    LayoutUtils.fitSquareToBounds(this.mIconBounds, rect);
                }
                if (!this.mSmallImageBounds.isEmpty()) {
                    rect2 = this.mSmallImageBounds;
                    LayoutUtils.scaledAroundCenter(rect2, rect2, 0.95f);
                    if (this.mComplicationData.getSmallImageStyle() == 2) {
                        LayoutUtils.fitSquareToBounds(this.mSmallImageBounds, rect);
                    }
                }
                if (!this.mLargeImageBounds.isEmpty()) {
                    rect = this.mLargeImageBounds;
                    LayoutUtils.scaledAroundCenter(rect, rect, 1.0f);
                }
            }
        }
    }

    public final int getBorderRadius(ComplicationStyle complicationStyle) {
        if (this.mBounds.isEmpty()) {
            return 0;
        }
        return Math.min(Math.min(this.mBounds.height(), this.mBounds.width()) / 2, complicationStyle.mBorderRadius);
    }

    final int getImageBorderRadius(ComplicationStyle complicationStyle, Rect rect) {
        if (this.mBounds.isEmpty()) {
            return 0;
        }
        return Math.max(getBorderRadius(complicationStyle) - Math.min(Math.min(rect.left, this.mBounds.width() - rect.right), Math.min(rect.top, this.mBounds.height() - rect.bottom)), 0);
    }

    public final void invalidate() {
        OnInvalidateListener onInvalidateListener = this.mInvalidateListener;
        if (onInvalidateListener != null) {
            onInvalidateListener.onInvalidate();
        }
    }

    public final void setBounds$ar$ds(Rect rect) {
        Object obj = 1;
        if (this.mBounds.width() == rect.width() && this.mBounds.height() == rect.height()) {
            obj = null;
        }
        this.mBounds.set(rect);
        if (obj != null) {
            calculateBounds();
        }
    }

    public final void setComplicationData(ComplicationData complicationData) {
        if (!Objects.equals(this.mComplicationData, complicationData)) {
            Icon icon = null;
            if (complicationData == null) {
                this.mComplicationData = null;
                return;
            }
            Icon burnInProtectionIcon;
            Icon burnInProtectionSmallImage;
            Icon smallImage;
            Icon largeImage;
            boolean z = false;
            boolean z2 = true;
            if (complicationData.mType != 10) {
                this.mComplicationData = complicationData;
                this.mHasNoData = false;
            } else if (!this.mHasNoData) {
                this.mHasNoData = true;
                ComplicationData.Builder builder = new ComplicationData.Builder(3);
                builder.setShortText$ar$ds(ComplicationText.plainText(this.mNoDataText));
                this.mComplicationData = builder.build();
            } else {
                return;
            }
            Handler handler = new Handler(Looper.getMainLooper());
            this.mIcon = null;
            this.mSmallImage = null;
            this.mBurnInProtectionSmallImage = null;
            this.mLargeImage = null;
            this.mBurnInProtectionIcon = null;
            ComplicationData complicationData2 = this.mComplicationData;
            if (complicationData2 != null) {
                icon = complicationData2.getIcon();
                burnInProtectionIcon = this.mComplicationData.getBurnInProtectionIcon();
                burnInProtectionSmallImage = this.mComplicationData.getBurnInProtectionSmallImage();
                smallImage = this.mComplicationData.getSmallImage();
                largeImage = this.mComplicationData.getLargeImage();
            } else {
                burnInProtectionIcon = null;
                burnInProtectionSmallImage = burnInProtectionIcon;
                smallImage = burnInProtectionSmallImage;
                largeImage = smallImage;
            }
            if (icon != null) {
                icon.loadDrawableAsync(this.mContext, new PG(), handler);
                z = true;
            }
            if (burnInProtectionIcon != null) {
                burnInProtectionIcon.loadDrawableAsync(this.mContext, new C01222(), handler);
                z = true;
            }
            if (smallImage != null) {
                smallImage.loadDrawableAsync(this.mContext, new C01233(), handler);
                z = true;
            }
            if (burnInProtectionSmallImage != null) {
                burnInProtectionSmallImage.loadDrawableAsync(this.mContext, new C01244(), handler);
            } else {
                z2 = z;
            }
            if (largeImage != null) {
                largeImage.loadDrawableAsync(this.mContext, new C01255(), handler);
            } else if (!z2) {
                invalidate();
            }
            calculateBounds();
        }
    }

    public final void setNoDataText(CharSequence charSequence) {
        if (charSequence == null) {
            charSequence = "";
        }
        this.mNoDataText = charSequence.subSequence(0, charSequence.length());
        if (this.mHasNoData) {
            this.mHasNoData = false;
            setComplicationData(new ComplicationData.Builder(10).build());
        }
    }

    public final void setRangedValueProgressHidden(boolean z) {
        if (this.mRangedValueProgressHidden != z) {
            this.mRangedValueProgressHidden = z;
            calculateBounds();
        }
    }

    public final void updateStyle(ComplicationStyle complicationStyle, ComplicationStyle complicationStyle2) {
        this.mActiveStyle = complicationStyle;
        this.mAmbientStyle = complicationStyle2;
        this.mActivePaintSet = new PaintSet(complicationStyle, false, false, false);
        this.mAmbientPaintSet = new PaintSet(complicationStyle2, true, false, false);
        calculateBounds();
    }
}
