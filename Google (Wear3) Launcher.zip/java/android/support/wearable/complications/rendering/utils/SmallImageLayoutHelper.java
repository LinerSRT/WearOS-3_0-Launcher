package android.support.wearable.complications.rendering.utils;

import android.graphics.Rect;

/* compiled from: PG */
public final class SmallImageLayoutHelper extends LayoutHelper {
    public final void getSmallImageBounds(Rect rect) {
        getBounds(rect);
        LayoutUtils.getCentralSquare(rect, rect);
    }
}
