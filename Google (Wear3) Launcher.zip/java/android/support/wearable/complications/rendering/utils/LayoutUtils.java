package android.support.wearable.complications.rendering.utils;

import android.graphics.Rect;

/* compiled from: PG */
public final class LayoutUtils {
    public static void fitSquareToBounds(Rect rect, Rect rect2) {
        if (!rect.isEmpty()) {
            int centerX = rect.centerX();
            int centerY = rect.centerY();
            if (rect.intersect(rect2)) {
                getCentralSquare(rect, rect);
                centerX -= rect.centerX();
                centerY -= rect.centerY();
                rect.offset(centerX, centerY);
                if (!rect2.contains(rect)) {
                    rect.offset(-centerX, -centerY);
                }
                return;
            }
            rect.setEmpty();
        }
    }

    public static void getBottomHalf(Rect rect, Rect rect2) {
        rect.set(rect2.left, (rect2.top + rect2.bottom) / 2, rect2.right, rect2.bottom);
    }

    public static void getCentralSquare(Rect rect, Rect rect2) {
        int min = Math.min(rect2.width(), rect2.height()) / 2;
        rect.set(rect2.centerX() - min, rect2.centerY() - min, rect2.centerX() + min, rect2.centerY() + min);
    }

    public static void getLeftPart(Rect rect, Rect rect2) {
        if (rect2.width() < rect2.height()) {
            rect.setEmpty();
        } else {
            rect.set(rect2.left, rect2.top, rect2.left + rect2.height(), rect2.bottom);
        }
    }

    public static void getRightPart(Rect rect, Rect rect2) {
        if (rect2.width() < rect2.height()) {
            rect.set(rect2);
        } else {
            rect.set(rect2.left + rect2.height(), rect2.top, rect2.right, rect2.bottom);
        }
    }

    public static void getTopHalf(Rect rect, Rect rect2) {
        rect.set(rect2.left, rect2.top, rect2.right, (rect2.top + rect2.bottom) / 2);
    }

    public static boolean isWideRectangle(Rect rect) {
        int width = rect.width();
        float height = (float) rect.height();
        return ((float) width) > height + height;
    }

    public static void scaledAroundCenter(Rect rect, Rect rect2, float f) {
        rect.set(rect2);
        float f2 = 0.5f - (f / 2.0f);
        rect.inset((int) (((float) rect.width()) * f2), (int) (((float) rect.height()) * f2));
    }
}
