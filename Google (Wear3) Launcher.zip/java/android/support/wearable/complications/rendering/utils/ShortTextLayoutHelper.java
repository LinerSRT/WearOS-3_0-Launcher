package android.support.wearable.complications.rendering.utils;

import android.graphics.Rect;
import android.support.wearable.complications.ComplicationData;
import android.text.Layout.Alignment;

/* compiled from: PG */
public final class ShortTextLayoutHelper extends LayoutHelper {
    private final Rect mBounds = new Rect();

    public final void getIconBounds(Rect rect) {
        if (this.mComplicationData.getIcon() == null) {
            rect.setEmpty();
            return;
        }
        getBounds(rect);
        if (LayoutUtils.isWideRectangle(rect)) {
            LayoutUtils.getLeftPart(rect, rect);
            return;
        }
        LayoutUtils.getCentralSquare(rect, rect);
        LayoutUtils.getTopHalf(rect, rect);
        LayoutUtils.getCentralSquare(rect, rect);
    }

    public final Alignment getShortTextAlignment() {
        ComplicationData complicationData = this.mComplicationData;
        getBounds(this.mBounds);
        return (!LayoutUtils.isWideRectangle(this.mBounds) || complicationData.getIcon() == null) ? Alignment.ALIGN_CENTER : Alignment.ALIGN_NORMAL;
    }

    public final void getShortTextBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        getBounds(rect);
        if (complicationData.getIcon() == null) {
            if (complicationData.getShortTitle() != null) {
                LayoutUtils.getTopHalf(rect, rect);
            }
        } else if (LayoutUtils.isWideRectangle(rect)) {
            LayoutUtils.getRightPart(rect, rect);
        } else {
            LayoutUtils.getCentralSquare(rect, rect);
            LayoutUtils.getBottomHalf(rect, rect);
        }
    }

    public final int getShortTextGravity() {
        ComplicationData complicationData = this.mComplicationData;
        return (complicationData.getShortTitle() == null || complicationData.getIcon() != null) ? 16 : 80;
    }

    public final Alignment getShortTitleAlignment() {
        return getShortTextAlignment();
    }

    public final void getShortTitleBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        if (complicationData.getIcon() == null) {
            if (complicationData.getShortTitle() != null) {
                getBounds(rect);
                LayoutUtils.getBottomHalf(rect, rect);
                return;
            }
        }
        rect.setEmpty();
    }

    public final int getShortTitleGravity() {
        return 48;
    }
}
