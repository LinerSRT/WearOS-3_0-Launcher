package android.support.wearable.complications.rendering.utils;

import android.graphics.Rect;
import android.support.wearable.complications.ComplicationData;
import android.text.Layout.Alignment;

/* compiled from: PG */
public class LayoutHelper {
    private final Rect mBounds = new Rect();
    public ComplicationData mComplicationData;

    public final void getBounds(Rect rect) {
        rect.set(this.mBounds);
    }

    public void getIconBounds(Rect rect) {
        rect.setEmpty();
    }

    public void getLargeImageBounds(Rect rect) {
        rect.setEmpty();
    }

    public Alignment getLongTextAlignment() {
        return Alignment.ALIGN_CENTER;
    }

    public void getLongTextBounds(Rect rect) {
        rect.setEmpty();
    }

    public int getLongTextGravity() {
        return 17;
    }

    public Alignment getLongTitleAlignment() {
        return Alignment.ALIGN_CENTER;
    }

    public void getLongTitleBounds(Rect rect) {
        rect.setEmpty();
    }

    public int getLongTitleGravity() {
        return 17;
    }

    public void getRangedValueBounds(Rect rect) {
        rect.setEmpty();
    }

    public Alignment getShortTextAlignment() {
        return Alignment.ALIGN_CENTER;
    }

    public void getShortTextBounds(Rect rect) {
        rect.setEmpty();
    }

    public int getShortTextGravity() {
        return 17;
    }

    public Alignment getShortTitleAlignment() {
        return Alignment.ALIGN_CENTER;
    }

    public void getShortTitleBounds(Rect rect) {
        rect.setEmpty();
    }

    public int getShortTitleGravity() {
        return 17;
    }

    public void getSmallImageBounds(Rect rect) {
        rect.setEmpty();
    }

    public void setComplicationData(ComplicationData complicationData) {
        this.mComplicationData = complicationData;
    }

    public void setHeight(int i) {
        this.mBounds.bottom = i;
    }

    public void setWidth(int i) {
        this.mBounds.right = i;
    }

    public final void update(int i, int i2, ComplicationData complicationData) {
        setWidth(i);
        setHeight(i2);
        setComplicationData(complicationData);
    }
}
