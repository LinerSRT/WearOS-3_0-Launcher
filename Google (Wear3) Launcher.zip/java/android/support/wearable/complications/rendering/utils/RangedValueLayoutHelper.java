package android.support.wearable.complications.rendering.utils;

import android.graphics.Rect;
import android.support.wearable.complications.ComplicationData;
import android.text.Layout.Alignment;

/* compiled from: PG */
public final class RangedValueLayoutHelper extends LayoutHelper {
    private static final float INNER_SQUARE_SIZE_FRACTION = ((float) (1.0d / Math.sqrt(2.0d)));
    private final Rect mBounds = new Rect();
    private final Rect mRangedValueInnerSquare = new Rect();
    private final ShortTextLayoutHelper mShortTextLayoutHelper = new ShortTextLayoutHelper();

    private final void updateShortTextLayoutHelper() {
        if (this.mComplicationData != null) {
            getRangedValueBounds(this.mRangedValueInnerSquare);
            Rect rect = this.mRangedValueInnerSquare;
            LayoutUtils.scaledAroundCenter(rect, rect, INNER_SQUARE_SIZE_FRACTION * 0.7f);
            this.mShortTextLayoutHelper.update(this.mRangedValueInnerSquare.width(), this.mRangedValueInnerSquare.height(), this.mComplicationData);
        }
    }

    public final void getIconBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        if (complicationData.getIcon() == null) {
            rect.setEmpty();
            return;
        }
        getBounds(rect);
        if (complicationData.getShortText() != null) {
            if (!LayoutUtils.isWideRectangle(rect)) {
                this.mShortTextLayoutHelper.getIconBounds(rect);
                rect.offset(this.mRangedValueInnerSquare.left, this.mRangedValueInnerSquare.top);
                return;
            }
        }
        LayoutUtils.scaledAroundCenter(rect, this.mRangedValueInnerSquare, 0.7f);
    }

    public final void getRangedValueBounds(Rect rect) {
        getBounds(rect);
        if (this.mComplicationData.getShortText() != null) {
            if (LayoutUtils.isWideRectangle(rect)) {
                LayoutUtils.getLeftPart(rect, rect);
                LayoutUtils.scaledAroundCenter(rect, rect, 0.95f);
                return;
            }
        }
        LayoutUtils.getCentralSquare(rect, rect);
        LayoutUtils.scaledAroundCenter(rect, rect, 0.95f);
    }

    public final Alignment getShortTextAlignment() {
        getBounds(this.mBounds);
        if (LayoutUtils.isWideRectangle(this.mBounds)) {
            return Alignment.ALIGN_NORMAL;
        }
        return this.mShortTextLayoutHelper.getShortTextAlignment();
    }

    public final void getShortTextBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        if (complicationData.getShortText() == null) {
            rect.setEmpty();
            return;
        }
        getBounds(rect);
        if (LayoutUtils.isWideRectangle(rect)) {
            if (complicationData.getShortTitle() != null) {
                if (complicationData.getIcon() == null) {
                    LayoutUtils.getRightPart(rect, rect);
                    LayoutUtils.getTopHalf(rect, rect);
                    return;
                }
            }
            LayoutUtils.getRightPart(rect, rect);
            return;
        }
        this.mShortTextLayoutHelper.getShortTextBounds(rect);
        rect.offset(this.mRangedValueInnerSquare.left, this.mRangedValueInnerSquare.top);
    }

    public final int getShortTextGravity() {
        ComplicationData complicationData = this.mComplicationData;
        getBounds(this.mBounds);
        if (LayoutUtils.isWideRectangle(this.mBounds)) {
            return complicationData.getShortTitle() != null ? 80 : 16;
        } else {
            return this.mShortTextLayoutHelper.getShortTextGravity();
        }
    }

    public final Alignment getShortTitleAlignment() {
        return getShortTextAlignment();
    }

    public final void getShortTitleBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        if (complicationData.getShortTitle() != null) {
            if (complicationData.getShortText() != null) {
                getBounds(rect);
                if (LayoutUtils.isWideRectangle(rect)) {
                    LayoutUtils.getRightPart(rect, rect);
                    LayoutUtils.getBottomHalf(rect, rect);
                    return;
                }
                this.mShortTextLayoutHelper.getShortTitleBounds(rect);
                rect.offset(this.mRangedValueInnerSquare.left, this.mRangedValueInnerSquare.top);
                return;
            }
        }
        rect.setEmpty();
    }

    public final int getShortTitleGravity() {
        return 48;
    }

    public final void setComplicationData(ComplicationData complicationData) {
        this.mComplicationData = complicationData;
        updateShortTextLayoutHelper();
    }

    public final void setHeight(int i) {
        super.setHeight(i);
        updateShortTextLayoutHelper();
    }

    public final void setWidth(int i) {
        super.setWidth(i);
        updateShortTextLayoutHelper();
    }
}
