package android.support.wearable.complications.rendering.utils;

import android.graphics.Rect;
import android.support.wearable.complications.ComplicationData;
import android.text.Layout.Alignment;

/* compiled from: PG */
public final class LongTextLayoutHelper extends LayoutHelper {
    private final Rect mBounds = new Rect();

    private final boolean shouldShowTextOnly(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        return (complicationData.getIcon() == null && complicationData.getSmallImage() == null) || !LayoutUtils.isWideRectangle(rect);
    }

    public final void getIconBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        getBounds(rect);
        if (complicationData.getIcon() != null && complicationData.getSmallImage() == null) {
            if (!shouldShowTextOnly(rect)) {
                LayoutUtils.getLeftPart(rect, rect);
                return;
            }
        }
        rect.setEmpty();
    }

    public final Alignment getLongTextAlignment() {
        getBounds(this.mBounds);
        return shouldShowTextOnly(this.mBounds) ? Alignment.ALIGN_CENTER : Alignment.ALIGN_NORMAL;
    }

    public final void getLongTextBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        getBounds(rect);
        if (shouldShowTextOnly(rect)) {
            if (complicationData.getLongTitle() != null) {
                LayoutUtils.getTopHalf(rect, rect);
            }
        } else if (complicationData.getLongTitle() == null) {
            LayoutUtils.getRightPart(rect, rect);
        } else {
            LayoutUtils.getRightPart(rect, rect);
            LayoutUtils.getTopHalf(rect, rect);
        }
    }

    public final int getLongTextGravity() {
        return this.mComplicationData.getLongTitle() == null ? 16 : 80;
    }

    public final Alignment getLongTitleAlignment() {
        return getLongTextAlignment();
    }

    public final void getLongTitleBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        getBounds(rect);
        if (complicationData.getLongTitle() == null) {
            rect.setEmpty();
        } else if (shouldShowTextOnly(rect)) {
            LayoutUtils.getBottomHalf(rect, rect);
        } else {
            LayoutUtils.getRightPart(rect, rect);
            LayoutUtils.getBottomHalf(rect, rect);
        }
    }

    public final int getLongTitleGravity() {
        return 48;
    }

    public final void getSmallImageBounds(Rect rect) {
        ComplicationData complicationData = this.mComplicationData;
        getBounds(rect);
        if (complicationData.getSmallImage() != null) {
            if (!shouldShowTextOnly(rect)) {
                LayoutUtils.getLeftPart(rect, rect);
                return;
            }
        }
        rect.setEmpty();
    }
}
