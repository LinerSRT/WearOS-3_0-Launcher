package android.support.wearable.complications.rendering;

import android.app.PendingIntent.CanceledException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.wearable.R$styleable;
import android.support.wearable.complications.ComplicationData;
import android.support.wearable.complications.ComplicationHelperActivity;
import android.support.wearable.complications.rendering.ComplicationStyle.Builder;
import android.support.wearable.watchface.WatchFaceService;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import com.google.android.wearable.sysui.R;
import org.xmlpull.v1.XmlPullParser;
import p020j$.util.Objects;

/* compiled from: PG */
public class ComplicationDrawable extends Drawable implements Parcelable {
    public static final int BORDER_STYLE_DASHED = 2;
    public static final int BORDER_STYLE_NONE = 0;
    public static final int BORDER_STYLE_SOLID = 1;
    public static final Creator CREATOR = new PG();
    private static final String FIELD_ACTIVE_STYLE_BUILDER = "active_style_builder";
    private static final String FIELD_AMBIENT_STYLE_BUILDER = "ambient_style_builder";
    private static final String FIELD_BOUNDS = "bounds";
    private static final String FIELD_HIGHLIGHT_DURATION = "highlight_duration";
    private static final String FIELD_NO_DATA_TEXT = "no_data_text";
    private static final String FIELD_RANGED_VALUE_PROGRESS_HIDDEN = "ranged_value_progress_hidden";
    private static final String TAG = "ComplicationDrawable";
    private final Builder mActiveStyleBuilder;
    private boolean mAlreadyStyled;
    private final Builder mAmbientStyleBuilder;
    private boolean mBurnInProtection;
    private ComplicationRenderer mComplicationRenderer;
    private Context mContext;
    private long mCurrentTimeMillis;
    private long mHighlightDuration;
    private boolean mInAmbientMode;
    private boolean mIsHighlighted;
    private boolean mIsInflatedFromXml;
    private boolean mIsStyleUpToDate;
    private boolean mLowBitAmbient;
    private final Handler mMainThreadHandler;
    private CharSequence mNoDataText;
    private boolean mRangedValueProgressHidden;
    private final OnInvalidateListener mRendererInvalidateListener;
    private final Runnable mUnhighlightRunnable;

    /* renamed from: android.support.wearable.complications.rendering.ComplicationDrawable$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ComplicationDrawable[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ComplicationDrawable(parcel);
        }
    }

    /* renamed from: android.support.wearable.complications.rendering.ComplicationDrawable$2 */
    final class C01202 implements Runnable {
        public final void run() {
            ComplicationDrawable.this.setIsHighlighted(false);
            ComplicationDrawable.this.invalidateSelf();
        }
    }

    /* renamed from: android.support.wearable.complications.rendering.ComplicationDrawable$3 */
    final class C01213 implements OnInvalidateListener {
        public final void onInvalidate() {
            ComplicationDrawable.this.invalidateSelf();
        }
    }

    public ComplicationDrawable() {
        this.mMainThreadHandler = new Handler(Looper.getMainLooper());
        this.mUnhighlightRunnable = new C01202();
        this.mRendererInvalidateListener = new C01213();
        this.mActiveStyleBuilder = new Builder();
        this.mAmbientStyleBuilder = new Builder();
    }

    private void assertInitialized() {
        if (this.mContext == null) {
            throw new IllegalStateException("ComplicationDrawable does not have a context. Use setContext(Context) to set it first.");
        }
    }

    private Builder getComplicationStyleBuilder(boolean z) {
        return z ? this.mAmbientStyleBuilder : this.mActiveStyleBuilder;
    }

    private void inflateAttributes(Resources resources, XmlPullParser xmlPullParser) {
        TypedArray obtainAttributes = resources.obtainAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.ComplicationDrawable);
        setRangedValueProgressHidden(obtainAttributes.getBoolean(11, false));
        obtainAttributes.recycle();
    }

    private void inflateStyle(boolean z, Resources resources, XmlPullParser xmlPullParser) {
        TypedArray obtainAttributes = resources.obtainAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.ComplicationDrawable);
        Builder complicationStyleBuilder = getComplicationStyleBuilder(z);
        if (obtainAttributes.hasValue(0)) {
            complicationStyleBuilder.backgroundColor = obtainAttributes.getColor(0, resources.getColor(R.color.complicationDrawable_backgroundColor, null));
        }
        if (obtainAttributes.hasValue(1)) {
            complicationStyleBuilder.backgroundDrawable = obtainAttributes.getDrawable(1);
        }
        if (obtainAttributes.hasValue(14)) {
            complicationStyleBuilder.textColor = obtainAttributes.getColor(14, resources.getColor(R.color.complicationDrawable_textColor, null));
        }
        if (obtainAttributes.hasValue(17)) {
            complicationStyleBuilder.titleColor = obtainAttributes.getColor(17, resources.getColor(R.color.complicationDrawable_titleColor, null));
        }
        if (obtainAttributes.hasValue(16)) {
            complicationStyleBuilder.textTypeface = Typeface.create(obtainAttributes.getString(16), 0);
        }
        if (obtainAttributes.hasValue(19)) {
            complicationStyleBuilder.titleTypeface = Typeface.create(obtainAttributes.getString(19), 0);
        }
        if (obtainAttributes.hasValue(15)) {
            complicationStyleBuilder.textSize = obtainAttributes.getDimensionPixelSize(15, resources.getDimensionPixelSize(R.dimen.complicationDrawable_textSize));
        }
        if (obtainAttributes.hasValue(18)) {
            complicationStyleBuilder.titleSize = obtainAttributes.getDimensionPixelSize(18, resources.getDimensionPixelSize(R.dimen.complicationDrawable_titleSize));
        }
        if (obtainAttributes.hasValue(9)) {
            complicationStyleBuilder.iconColor = obtainAttributes.getColor(9, resources.getColor(R.color.complicationDrawable_iconColor, null));
        }
        if (obtainAttributes.hasValue(2)) {
            complicationStyleBuilder.borderColor = obtainAttributes.getColor(2, resources.getColor(R.color.complicationDrawable_borderColor, null));
        }
        if (obtainAttributes.hasValue(5)) {
            complicationStyleBuilder.borderRadius = obtainAttributes.getDimensionPixelSize(5, resources.getDimensionPixelSize(R.dimen.complicationDrawable_borderRadius));
        }
        if (obtainAttributes.hasValue(6)) {
            complicationStyleBuilder.setBorderStyle$ar$ds(obtainAttributes.getInt(6, resources.getInteger(R.integer.complicationDrawable_borderStyle)));
        }
        if (obtainAttributes.hasValue(4)) {
            complicationStyleBuilder.borderDashWidth = obtainAttributes.getDimensionPixelSize(4, resources.getDimensionPixelSize(R.dimen.complicationDrawable_borderDashWidth));
        }
        if (obtainAttributes.hasValue(3)) {
            complicationStyleBuilder.borderDashGap = obtainAttributes.getDimensionPixelSize(3, resources.getDimensionPixelSize(R.dimen.complicationDrawable_borderDashGap));
        }
        if (obtainAttributes.hasValue(7)) {
            complicationStyleBuilder.borderWidth = obtainAttributes.getDimensionPixelSize(7, resources.getDimensionPixelSize(R.dimen.complicationDrawable_borderWidth));
        }
        if (obtainAttributes.hasValue(12)) {
            complicationStyleBuilder.rangedValueRingWidth = obtainAttributes.getDimensionPixelSize(12, resources.getDimensionPixelSize(R.dimen.complicationDrawable_rangedValueRingWidth));
        }
        if (obtainAttributes.hasValue(10)) {
            complicationStyleBuilder.rangedValuePrimaryColor = obtainAttributes.getColor(10, resources.getColor(R.color.complicationDrawable_rangedValuePrimaryColor, null));
        }
        if (obtainAttributes.hasValue(13)) {
            complicationStyleBuilder.rangedValueSecondaryColor = obtainAttributes.getColor(13, resources.getColor(R.color.complicationDrawable_rangedValueSecondaryColor, null));
        }
        if (obtainAttributes.hasValue(8)) {
            complicationStyleBuilder.highlightColor = obtainAttributes.getColor(8, resources.getColor(R.color.complicationDrawable_highlightColor, null));
        }
        obtainAttributes.recycle();
    }

    private static void setStyleToDefaultValues(Builder builder, Resources resources) {
        builder.backgroundColor = resources.getColor(R.color.complicationDrawable_backgroundColor, null);
        builder.textColor = resources.getColor(R.color.complicationDrawable_textColor, null);
        builder.titleColor = resources.getColor(R.color.complicationDrawable_titleColor, null);
        builder.textTypeface = Typeface.create(resources.getString(R.string.complicationDrawable_textTypeface), 0);
        builder.titleTypeface = Typeface.create(resources.getString(R.string.complicationDrawable_titleTypeface), 0);
        builder.textSize = resources.getDimensionPixelSize(R.dimen.complicationDrawable_textSize);
        builder.titleSize = resources.getDimensionPixelSize(R.dimen.complicationDrawable_titleSize);
        builder.iconColor = resources.getColor(R.color.complicationDrawable_iconColor, null);
        builder.borderColor = resources.getColor(R.color.complicationDrawable_borderColor, null);
        builder.borderWidth = resources.getDimensionPixelSize(R.dimen.complicationDrawable_borderWidth);
        builder.borderRadius = resources.getDimensionPixelSize(R.dimen.complicationDrawable_borderRadius);
        builder.setBorderStyle$ar$ds(resources.getInteger(R.integer.complicationDrawable_borderStyle));
        builder.borderDashWidth = resources.getDimensionPixelSize(R.dimen.complicationDrawable_borderDashWidth);
        builder.borderDashGap = resources.getDimensionPixelSize(R.dimen.complicationDrawable_borderDashGap);
        builder.rangedValueRingWidth = resources.getDimensionPixelSize(R.dimen.complicationDrawable_rangedValueRingWidth);
        builder.rangedValuePrimaryColor = resources.getColor(R.color.complicationDrawable_rangedValuePrimaryColor, null);
        builder.rangedValueSecondaryColor = resources.getColor(R.color.complicationDrawable_rangedValueSecondaryColor, null);
        builder.highlightColor = resources.getColor(R.color.complicationDrawable_highlightColor, null);
    }

    private void updateStyleIfRequired() {
        if (!this.mIsStyleUpToDate) {
            this.mComplicationRenderer.updateStyle(this.mActiveStyleBuilder.build(), this.mAmbientStyleBuilder.build());
            this.mIsStyleUpToDate = true;
        }
    }

    public int describeContents() {
        return 0;
    }

    public void draw(Canvas canvas) {
        assertInitialized();
        updateStyleIfRequired();
        ComplicationRenderer complicationRenderer = this.mComplicationRenderer;
        long j = this.mCurrentTimeMillis;
        boolean z = this.mInAmbientMode;
        boolean z2 = this.mLowBitAmbient;
        boolean z3 = this.mBurnInProtection;
        boolean z4 = this.mIsHighlighted;
        ComplicationData complicationData = complicationRenderer.mComplicationData;
        if (complicationData != null) {
            int i = complicationData.mType;
            if (!(i == 2 || i == 1)) {
                if (complicationData.isActiveAt(j)) {
                    if (!complicationRenderer.mBounds.isEmpty()) {
                        PaintSet paintSet;
                        float rangedMaxValue;
                        TextPaint textPaint;
                        TextPaint textPaint2;
                        if (z) {
                            PaintSet paintSet2 = complicationRenderer.mAmbientPaintSet;
                            if (!(paintSet2.lowBitAmbient == z2 && paintSet2.burnInProtection == z3)) {
                                complicationRenderer.mAmbientPaintSet = new PaintSet(complicationRenderer.mAmbientStyle, true, z2, z3);
                            }
                            paintSet = complicationRenderer.mAmbientPaintSet;
                        } else {
                            paintSet = complicationRenderer.mActivePaintSet;
                        }
                        CharSequence charSequence = "";
                        if (complicationRenderer.mComplicationData.getShortText() != null) {
                            complicationRenderer.mMainTextRenderer.setMaxLines(1);
                            complicationRenderer.mMainTextRenderer.setText(complicationRenderer.mComplicationData.getShortText().getTextAt(complicationRenderer.mContext.getResources(), j));
                            if (complicationRenderer.mComplicationData.getShortTitle() != null) {
                                complicationRenderer.mSubTextRenderer.setText(complicationRenderer.mComplicationData.getShortTitle().getTextAt(complicationRenderer.mContext.getResources(), j));
                            } else {
                                complicationRenderer.mSubTextRenderer.setText(charSequence);
                            }
                        }
                        if (complicationRenderer.mComplicationData.getLongText() != null) {
                            complicationRenderer.mMainTextRenderer.setText(complicationRenderer.mComplicationData.getLongText().getTextAt(complicationRenderer.mContext.getResources(), j));
                            if (complicationRenderer.mComplicationData.getLongTitle() != null) {
                                complicationRenderer.mSubTextRenderer.setText(complicationRenderer.mComplicationData.getLongTitle().getTextAt(complicationRenderer.mContext.getResources(), j));
                                complicationRenderer.mMainTextRenderer.setMaxLines(1);
                            } else {
                                complicationRenderer.mSubTextRenderer.setText(charSequence);
                                complicationRenderer.mMainTextRenderer.setMaxLines(2);
                            }
                        }
                        canvas.save();
                        canvas.translate((float) complicationRenderer.mBounds.left, (float) complicationRenderer.mBounds.top);
                        int borderRadius = complicationRenderer.getBorderRadius(paintSet.style);
                        float f = (float) borderRadius;
                        canvas.drawRoundRect(complicationRenderer.mBackgroundBoundsF, f, f, paintSet.backgroundPaint);
                        if (!(paintSet.style.mBackgroundDrawable == null || paintSet.isInBurnInProtectionMode())) {
                            complicationRenderer.mRoundedBackgroundDrawable.setDrawable(paintSet.style.mBackgroundDrawable);
                            Drawable drawable = complicationRenderer.mRoundedBackgroundDrawable;
                            drawable.mRadius = borderRadius;
                            drawable.setBounds(complicationRenderer.mBackgroundBounds);
                            complicationRenderer.mRoundedBackgroundDrawable.draw(canvas);
                        }
                        if (!complicationRenderer.mIconBounds.isEmpty()) {
                            Drawable drawable2 = complicationRenderer.mIcon;
                            if (drawable2 != null) {
                                if (paintSet.isInBurnInProtectionMode()) {
                                    Drawable drawable3 = complicationRenderer.mBurnInProtectionIcon;
                                    if (drawable3 != null) {
                                        drawable2 = drawable3;
                                    }
                                }
                                drawable2.setColorFilter(paintSet.iconColorFilter);
                                Rect rect = complicationRenderer.mIconBounds;
                                drawable2.setBounds(0, 0, rect.width(), rect.height());
                                canvas.save();
                                canvas.translate((float) rect.left, (float) rect.top);
                                drawable2.draw(canvas);
                                canvas.restore();
                            }
                        }
                        if (!complicationRenderer.mSmallImageBounds.isEmpty()) {
                            if (paintSet.isInBurnInProtectionMode()) {
                                complicationRenderer.mRoundedSmallImage.setDrawable(complicationRenderer.mBurnInProtectionSmallImage);
                                if (complicationRenderer.mBurnInProtectionSmallImage == null) {
                                }
                            } else {
                                complicationRenderer.mRoundedSmallImage.setDrawable(complicationRenderer.mSmallImage);
                                if (complicationRenderer.mSmallImage != null) {
                                }
                            }
                            if (complicationRenderer.mComplicationData.getSmallImageStyle() == 2) {
                                complicationRenderer.mRoundedSmallImage.setColorFilter(null);
                                complicationRenderer.mRoundedSmallImage.mRadius = 0;
                            } else {
                                complicationRenderer.mRoundedSmallImage.setColorFilter(paintSet.style.mColorFilter);
                                complicationRenderer.mRoundedSmallImage.mRadius = complicationRenderer.getImageBorderRadius(paintSet.style, complicationRenderer.mSmallImageBounds);
                            }
                            complicationRenderer.mRoundedSmallImage.setBounds(complicationRenderer.mSmallImageBounds);
                            complicationRenderer.mRoundedSmallImage.draw(canvas);
                        }
                        if (!complicationRenderer.mLargeImageBounds.isEmpty()) {
                            if (!paintSet.isInBurnInProtectionMode()) {
                                complicationRenderer.mRoundedLargeImage.setDrawable(complicationRenderer.mLargeImage);
                                complicationRenderer.mRoundedLargeImage.mRadius = complicationRenderer.getImageBorderRadius(paintSet.style, complicationRenderer.mLargeImageBounds);
                                complicationRenderer.mRoundedLargeImage.setBounds(complicationRenderer.mLargeImageBounds);
                                complicationRenderer.mRoundedLargeImage.setColorFilter(paintSet.style.mColorFilter);
                                complicationRenderer.mRoundedLargeImage.draw(canvas);
                            }
                        }
                        if (!complicationRenderer.mRangedValueBoundsF.isEmpty()) {
                            rangedMaxValue = complicationRenderer.mComplicationData.getRangedMaxValue() - complicationRenderer.mComplicationData.getRangedMinValue();
                            f = 0.0f;
                            if (rangedMaxValue > 0.0f) {
                                f = complicationRenderer.mComplicationData.getRangedValue() / rangedMaxValue;
                            }
                            float f2 = f * 352.0f;
                            int ceil = (int) Math.ceil((double) paintSet.inProgressPaint.getStrokeWidth());
                            rangedMaxValue = (float) ceil;
                            complicationRenderer.mRangedValueBoundsF.inset(rangedMaxValue, rangedMaxValue);
                            canvas.drawArc(complicationRenderer.mRangedValueBoundsF, -88.0f, f2, false, paintSet.inProgressPaint);
                            canvas.drawArc(complicationRenderer.mRangedValueBoundsF, 4.0f + (-88.0f + f2), 352.0f - f2, false, paintSet.remainingPaint);
                            rangedMaxValue = (float) (-ceil);
                            complicationRenderer.mRangedValueBoundsF.inset(rangedMaxValue, rangedMaxValue);
                        }
                        if (!complicationRenderer.mMainTextBounds.isEmpty()) {
                            textPaint = complicationRenderer.mMainTextPaint;
                            textPaint2 = paintSet.primaryTextPaint;
                            if (textPaint != textPaint2) {
                                complicationRenderer.mMainTextPaint = textPaint2;
                                complicationRenderer.mMainTextRenderer.setPaint(complicationRenderer.mMainTextPaint);
                                complicationRenderer.mMainTextRenderer.setInAmbientMode(paintSet.isAmbientStyle);
                            }
                            complicationRenderer.mMainTextRenderer.draw(canvas, complicationRenderer.mMainTextBounds);
                        }
                        if (!complicationRenderer.mSubTextBounds.isEmpty()) {
                            textPaint = complicationRenderer.mSubTextPaint;
                            textPaint2 = paintSet.secondaryTextPaint;
                            if (textPaint != textPaint2) {
                                complicationRenderer.mSubTextPaint = textPaint2;
                                complicationRenderer.mSubTextRenderer.setPaint(complicationRenderer.mSubTextPaint);
                                complicationRenderer.mSubTextRenderer.setInAmbientMode(paintSet.isAmbientStyle);
                            }
                            complicationRenderer.mSubTextRenderer.draw(canvas, complicationRenderer.mSubTextBounds);
                        }
                        if (z4 && !paintSet.isAmbientStyle) {
                            rangedMaxValue = (float) complicationRenderer.getBorderRadius(paintSet.style);
                            canvas.drawRoundRect(complicationRenderer.mBackgroundBoundsF, rangedMaxValue, rangedMaxValue, paintSet.highlightPaint);
                        }
                        ComplicationStyle complicationStyle = paintSet.style;
                        if (complicationStyle.mBorderStyle != 0) {
                            rangedMaxValue = (float) complicationRenderer.getBorderRadius(complicationStyle);
                            canvas.drawRoundRect(complicationRenderer.mBackgroundBoundsF, rangedMaxValue, rangedMaxValue, paintSet.borderPaint);
                        }
                        canvas.restore();
                    }
                }
            }
        }
    }

    ComplicationStyle getActiveStyle() {
        return this.mActiveStyleBuilder.build();
    }

    ComplicationStyle getAmbientStyle() {
        return this.mAmbientStyleBuilder.build();
    }

    ComplicationRenderer getComplicationRenderer() {
        return this.mComplicationRenderer;
    }

    public long getHighlightDuration() {
        return this.mHighlightDuration;
    }

    public boolean getLowBitAmbient() {
        return this.mLowBitAmbient;
    }

    CharSequence getNoDataText() {
        return this.mNoDataText;
    }

    public int getOpacity() {
        return -3;
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        this.mIsInflatedFromXml = true;
        int depth = xmlPullParser.getDepth();
        inflateAttributes(resources, xmlPullParser);
        setStyleToDefaultValues(this.mActiveStyleBuilder, resources);
        setStyleToDefaultValues(this.mAmbientStyleBuilder, resources);
        inflateStyle(false, resources, xmlPullParser);
        inflateStyle(true, resources, xmlPullParser);
        while (true) {
            int next = xmlPullParser.next();
            if (next == 1) {
                break;
            } else if (next == 3) {
                if (xmlPullParser.getDepth() <= depth) {
                    break;
                }
            } else if (next == 2) {
                Object name = xmlPullParser.getName();
                if (TextUtils.equals(name, "ambient")) {
                    inflateStyle(true, resources, xmlPullParser);
                } else {
                    String valueOf = String.valueOf(this);
                    StringBuilder stringBuilder = new StringBuilder((String.valueOf(name).length() + 43) + String.valueOf(valueOf).length());
                    stringBuilder.append("Unknown element: ");
                    stringBuilder.append(name);
                    stringBuilder.append(" for ComplicationDrawable ");
                    stringBuilder.append(valueOf);
                    Log.w(TAG, stringBuilder.toString());
                }
            }
        }
        this.mIsStyleUpToDate = false;
    }

    public boolean isHighlighted() {
        return this.mIsHighlighted;
    }

    public boolean isRangedValueProgressHidden() {
        return this.mRangedValueProgressHidden;
    }

    protected void onBoundsChange(Rect rect) {
        ComplicationRenderer complicationRenderer = this.mComplicationRenderer;
        if (complicationRenderer != null) {
            complicationRenderer.setBounds$ar$ds(rect);
        }
    }

    public boolean onTap(int i, int i2) {
        ComplicationRenderer complicationRenderer = this.mComplicationRenderer;
        if (complicationRenderer == null) {
            return false;
        }
        ComplicationData complicationData = complicationRenderer.mComplicationData;
        if (complicationData != null && (complicationData.getTapAction() != null || complicationData.mType == 9)) {
            if (getBounds().contains(i, i2)) {
                if (complicationData.mType == 9) {
                    Context context = this.mContext;
                    if (!(context instanceof WatchFaceService)) {
                        return false;
                    }
                    Parcelable componentName = new ComponentName(context, context.getClass());
                    Intent intent = new Intent(context, ComplicationHelperActivity.class);
                    intent.setAction("android.support.wearable.complications.ACTION_PERMISSION_REQUEST_ONLY");
                    intent.putExtra("android.support.wearable.complications.EXTRA_WATCH_FACE_COMPONENT_NAME", componentName);
                    context.startActivity(intent.addFlags(268435456));
                } else {
                    try {
                        complicationData.getTapAction().send();
                    } catch (CanceledException e) {
                        return false;
                    }
                }
                if (getHighlightDuration() > 0) {
                    setIsHighlighted(true);
                    invalidateSelf();
                    this.mMainThreadHandler.removeCallbacks(this.mUnhighlightRunnable);
                    this.mMainThreadHandler.postDelayed(this.mUnhighlightRunnable, getHighlightDuration());
                }
                return true;
            }
        }
        return false;
    }

    public void setAlpha(int i) {
    }

    public void setBackgroundColorActive(int i) {
        getComplicationStyleBuilder(false).backgroundColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBackgroundColorAmbient(int i) {
        getComplicationStyleBuilder(true).backgroundColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBackgroundDrawableActive(Drawable drawable) {
        getComplicationStyleBuilder(false).backgroundDrawable = drawable;
        this.mIsStyleUpToDate = false;
    }

    public void setBackgroundDrawableAmbient(Drawable drawable) {
        getComplicationStyleBuilder(true).backgroundDrawable = drawable;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderColorActive(int i) {
        getComplicationStyleBuilder(false).borderColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderColorAmbient(int i) {
        getComplicationStyleBuilder(true).borderColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderDashGapActive(int i) {
        getComplicationStyleBuilder(false).borderDashGap = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderDashGapAmbient(int i) {
        getComplicationStyleBuilder(true).borderDashGap = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderDashWidthActive(int i) {
        getComplicationStyleBuilder(false).borderDashWidth = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderDashWidthAmbient(int i) {
        getComplicationStyleBuilder(true).borderDashWidth = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderRadiusActive(int i) {
        getComplicationStyleBuilder(false).borderRadius = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderRadiusAmbient(int i) {
        getComplicationStyleBuilder(true).borderRadius = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderStyleActive(int i) {
        getComplicationStyleBuilder(false).setBorderStyle$ar$ds(i);
        this.mIsStyleUpToDate = false;
    }

    public void setBorderStyleAmbient(int i) {
        getComplicationStyleBuilder(true).setBorderStyle$ar$ds(i);
        this.mIsStyleUpToDate = false;
    }

    public void setBorderWidthActive(int i) {
        getComplicationStyleBuilder(false).borderWidth = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBorderWidthAmbient(int i) {
        getComplicationStyleBuilder(true).borderWidth = i;
        this.mIsStyleUpToDate = false;
    }

    public void setBurnInProtection(boolean z) {
        this.mBurnInProtection = z;
    }

    public void setColorFilter(ColorFilter colorFilter) {
    }

    public void setComplicationData(ComplicationData complicationData) {
        assertInitialized();
        this.mComplicationRenderer.setComplicationData(complicationData);
    }

    public void setContext(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Argument \"context\" should not be null.");
        } else if (!Objects.equals(context, this.mContext)) {
            this.mContext = context;
            if (!(this.mIsInflatedFromXml || this.mAlreadyStyled)) {
                setStyleToDefaultValues(this.mActiveStyleBuilder, context.getResources());
                setStyleToDefaultValues(this.mAmbientStyleBuilder, context.getResources());
            }
            if (!this.mAlreadyStyled) {
                this.mHighlightDuration = (long) context.getResources().getInteger(R.integer.complicationDrawable_highlightDurationMs);
            }
            ComplicationRenderer complicationRenderer = new ComplicationRenderer(this.mContext, this.mActiveStyleBuilder.build(), this.mAmbientStyleBuilder.build());
            this.mComplicationRenderer = complicationRenderer;
            complicationRenderer.mInvalidateListener = this.mRendererInvalidateListener;
            CharSequence charSequence = this.mNoDataText;
            if (charSequence == null) {
                setNoDataText(context.getString(R.string.complicationDrawable_noDataText));
            } else {
                complicationRenderer.setNoDataText(charSequence);
            }
            this.mComplicationRenderer.setRangedValueProgressHidden(this.mRangedValueProgressHidden);
            this.mComplicationRenderer.setBounds$ar$ds(getBounds());
            this.mIsStyleUpToDate = true;
        }
    }

    public void setCurrentTimeMillis(long j) {
        this.mCurrentTimeMillis = j;
    }

    public void setHighlightColorActive(int i) {
        getComplicationStyleBuilder(false).highlightColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setHighlightColorAmbient(int i) {
        getComplicationStyleBuilder(true).highlightColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setHighlightDuration(long j) {
        if (j >= 0) {
            this.mHighlightDuration = j;
            return;
        }
        throw new IllegalArgumentException("Highlight duration should be non-negative.");
    }

    public void setIconColorActive(int i) {
        getComplicationStyleBuilder(false).iconColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setIconColorAmbient(int i) {
        getComplicationStyleBuilder(true).iconColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setImageColorFilterActive(ColorFilter colorFilter) {
        getComplicationStyleBuilder(false).colorFilter = colorFilter;
        this.mIsStyleUpToDate = false;
    }

    public void setImageColorFilterAmbient(ColorFilter colorFilter) {
        getComplicationStyleBuilder(true).colorFilter = colorFilter;
        this.mIsStyleUpToDate = false;
    }

    public void setInAmbientMode(boolean z) {
        this.mInAmbientMode = z;
    }

    public void setIsHighlighted(boolean z) {
        this.mIsHighlighted = z;
    }

    public void setLowBitAmbient(boolean z) {
        this.mLowBitAmbient = z;
    }

    public void setRangedValuePrimaryColorActive(int i) {
        getComplicationStyleBuilder(false).rangedValuePrimaryColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setRangedValuePrimaryColorAmbient(int i) {
        getComplicationStyleBuilder(true).rangedValuePrimaryColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setRangedValueProgressHidden(boolean z) {
        this.mRangedValueProgressHidden = z;
        ComplicationRenderer complicationRenderer = this.mComplicationRenderer;
        if (complicationRenderer != null) {
            complicationRenderer.setRangedValueProgressHidden(z);
        }
    }

    public void setRangedValueRingWidthActive(int i) {
        getComplicationStyleBuilder(false).rangedValueRingWidth = i;
        this.mIsStyleUpToDate = false;
    }

    public void setRangedValueRingWidthAmbient(int i) {
        getComplicationStyleBuilder(true).rangedValueRingWidth = i;
        this.mIsStyleUpToDate = false;
    }

    public void setRangedValueSecondaryColorActive(int i) {
        getComplicationStyleBuilder(false).rangedValueSecondaryColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setRangedValueSecondaryColorAmbient(int i) {
        getComplicationStyleBuilder(true).rangedValueSecondaryColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTextColorActive(int i) {
        getComplicationStyleBuilder(false).textColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTextColorAmbient(int i) {
        getComplicationStyleBuilder(true).textColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTextSizeActive(int i) {
        getComplicationStyleBuilder(false).textSize = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTextSizeAmbient(int i) {
        getComplicationStyleBuilder(true).textSize = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTextTypefaceActive(Typeface typeface) {
        getComplicationStyleBuilder(false).textTypeface = typeface;
        this.mIsStyleUpToDate = false;
    }

    public void setTextTypefaceAmbient(Typeface typeface) {
        getComplicationStyleBuilder(true).textTypeface = typeface;
        this.mIsStyleUpToDate = false;
    }

    public void setTitleColorActive(int i) {
        getComplicationStyleBuilder(false).titleColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTitleColorAmbient(int i) {
        getComplicationStyleBuilder(true).titleColor = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTitleSizeActive(int i) {
        getComplicationStyleBuilder(false).titleSize = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTitleSizeAmbient(int i) {
        getComplicationStyleBuilder(true).titleSize = i;
        this.mIsStyleUpToDate = false;
    }

    public void setTitleTypefaceActive(Typeface typeface) {
        getComplicationStyleBuilder(false).titleTypeface = typeface;
        this.mIsStyleUpToDate = false;
    }

    public void setTitleTypefaceAmbient(Typeface typeface) {
        getComplicationStyleBuilder(true).titleTypeface = typeface;
        this.mIsStyleUpToDate = false;
    }

    public void writeToParcel(Parcel parcel, int i) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(FIELD_ACTIVE_STYLE_BUILDER, this.mActiveStyleBuilder);
        bundle.putParcelable(FIELD_AMBIENT_STYLE_BUILDER, this.mAmbientStyleBuilder);
        bundle.putCharSequence(FIELD_NO_DATA_TEXT, this.mNoDataText);
        bundle.putLong(FIELD_HIGHLIGHT_DURATION, this.mHighlightDuration);
        bundle.putBoolean(FIELD_RANGED_VALUE_PROGRESS_HIDDEN, this.mRangedValueProgressHidden);
        bundle.putParcelable(FIELD_BOUNDS, getBounds());
        parcel.writeBundle(bundle);
    }

    public void setNoDataText(CharSequence charSequence) {
        if (charSequence == null) {
            this.mNoDataText = "";
        } else {
            this.mNoDataText = charSequence.subSequence(0, charSequence.length());
        }
        ComplicationRenderer complicationRenderer = this.mComplicationRenderer;
        if (complicationRenderer != null) {
            complicationRenderer.setNoDataText(this.mNoDataText);
        }
    }

    public ComplicationDrawable(Context context) {
        this();
        setContext(context);
    }

    private ComplicationDrawable(Parcel parcel) {
        this.mMainThreadHandler = new Handler(Looper.getMainLooper());
        this.mUnhighlightRunnable = new C01202();
        this.mRendererInvalidateListener = new C01213();
        Bundle readBundle = parcel.readBundle(getClass().getClassLoader());
        this.mActiveStyleBuilder = (Builder) readBundle.getParcelable(FIELD_ACTIVE_STYLE_BUILDER);
        this.mAmbientStyleBuilder = (Builder) readBundle.getParcelable(FIELD_AMBIENT_STYLE_BUILDER);
        this.mNoDataText = readBundle.getCharSequence(FIELD_NO_DATA_TEXT);
        this.mHighlightDuration = readBundle.getLong(FIELD_HIGHLIGHT_DURATION);
        this.mRangedValueProgressHidden = readBundle.getBoolean(FIELD_RANGED_VALUE_PROGRESS_HIDDEN);
        setBounds((Rect) readBundle.getParcelable(FIELD_BOUNDS));
        this.mAlreadyStyled = true;
    }

    @Deprecated
    public boolean onTap(int i, int i2, long j) {
        return onTap(i, i2);
    }

    public ComplicationDrawable(ComplicationDrawable complicationDrawable) {
        this.mMainThreadHandler = new Handler(Looper.getMainLooper());
        this.mUnhighlightRunnable = new C01202();
        this.mRendererInvalidateListener = new C01213();
        this.mActiveStyleBuilder = new Builder(complicationDrawable.mActiveStyleBuilder);
        this.mAmbientStyleBuilder = new Builder(complicationDrawable.mAmbientStyleBuilder);
        CharSequence charSequence = complicationDrawable.mNoDataText;
        this.mNoDataText = charSequence.subSequence(0, charSequence.length());
        this.mHighlightDuration = complicationDrawable.mHighlightDuration;
        this.mRangedValueProgressHidden = complicationDrawable.mRangedValueProgressHidden;
        setBounds(complicationDrawable.getBounds());
        this.mAlreadyStyled = true;
    }

    public void draw(Canvas canvas, long j) {
        assertInitialized();
        setCurrentTimeMillis(j);
        draw(canvas);
    }
}
