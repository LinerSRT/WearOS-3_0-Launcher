package android.support.wearable.complications.rendering;

import android.graphics.ColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

/* compiled from: PG */
final class ComplicationStyle {
    public static final Typeface TYPEFACE_DEFAULT = Typeface.create("sans-serif-condensed", 0);
    public final int mBackgroundColor;
    public final Drawable mBackgroundDrawable;
    public final int mBorderColor;
    public final int mBorderDashGap;
    public final int mBorderDashWidth;
    public final int mBorderRadius;
    public final int mBorderStyle;
    public final int mBorderWidth;
    public final ColorFilter mColorFilter;
    public final int mHighlightColor;
    public final int mIconColor;
    public final int mRangedValuePrimaryColor;
    public final int mRangedValueRingWidth;
    public final int mRangedValueSecondaryColor;
    public final int mTextColor;
    public final int mTextSize;
    public final Typeface mTextTypeface;
    public final int mTitleColor;
    public final int mTitleSize;
    public final Typeface mTitleTypeface;

    /* compiled from: PG */
    public class Builder implements Parcelable {
        public static final Creator CREATOR = new PG();
        public int backgroundColor = -16777216;
        public Drawable backgroundDrawable = null;
        public int borderColor = -1;
        public int borderDashGap = 3;
        public int borderDashWidth = 3;
        public int borderRadius = Integer.MAX_VALUE;
        private int borderStyle = 1;
        public int borderWidth = 1;
        public ColorFilter colorFilter = null;
        public int highlightColor = -3355444;
        public int iconColor = -1;
        public int rangedValuePrimaryColor = -1;
        public int rangedValueRingWidth = 2;
        public int rangedValueSecondaryColor = -3355444;
        public int textColor = -1;
        public int textSize = Integer.MAX_VALUE;
        public Typeface textTypeface = ComplicationStyle.TYPEFACE_DEFAULT;
        public int titleColor = -3355444;
        public int titleSize = Integer.MAX_VALUE;
        public Typeface titleTypeface = ComplicationStyle.TYPEFACE_DEFAULT;

        /* renamed from: android.support.wearable.complications.rendering.ComplicationStyle$Builder$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new Builder[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new Builder(parcel);
            }
        }

        public final ComplicationStyle build() {
            return new ComplicationStyle(this.backgroundColor, this.backgroundDrawable, this.textColor, this.titleColor, this.textTypeface, this.titleTypeface, this.textSize, this.titleSize, this.colorFilter, this.iconColor, this.borderColor, this.borderStyle, this.borderRadius, this.borderWidth, this.borderDashWidth, this.borderDashGap, this.rangedValueRingWidth, this.rangedValuePrimaryColor, this.rangedValueSecondaryColor, this.highlightColor);
        }

        public final int describeContents() {
            return 0;
        }

        public final void setBorderStyle$ar$ds(int i) {
            if (i == 1) {
                this.borderStyle = 1;
            } else if (i == 2) {
                this.borderStyle = 2;
            } else {
                this.borderStyle = 0;
            }
        }

        public final void writeToParcel(Parcel parcel, int i) {
            Bundle bundle = new Bundle();
            bundle.putInt("background_color", this.backgroundColor);
            bundle.putInt("text_color", this.textColor);
            bundle.putInt("title_color", this.titleColor);
            bundle.putInt("text_style", this.textTypeface.getStyle());
            bundle.putInt("title_style", this.titleTypeface.getStyle());
            bundle.putInt("text_size", this.textSize);
            bundle.putInt("title_size", this.titleSize);
            bundle.putInt("icon_color", this.iconColor);
            bundle.putInt("border_color", this.borderColor);
            bundle.putInt("border_style", this.borderStyle);
            bundle.putInt("border_dash_width", this.borderDashWidth);
            bundle.putInt("border_dash_gap", this.borderDashGap);
            bundle.putInt("border_radius", this.borderRadius);
            bundle.putInt("border_width", this.borderWidth);
            bundle.putInt("ranged_value_ring_width", this.rangedValueRingWidth);
            bundle.putInt("ranged_value_primary_color", this.rangedValuePrimaryColor);
            bundle.putInt("ranged_value_secondary_color", this.rangedValueSecondaryColor);
            bundle.putInt("highlight_color", this.highlightColor);
            parcel.writeBundle(bundle);
        }

        public Builder(Parcel parcel) {
            Bundle readBundle = parcel.readBundle(getClass().getClassLoader());
            this.backgroundColor = readBundle.getInt("background_color");
            this.textColor = readBundle.getInt("text_color");
            this.titleColor = readBundle.getInt("title_color");
            this.textTypeface = Typeface.defaultFromStyle(readBundle.getInt("text_style", 0));
            this.titleTypeface = Typeface.defaultFromStyle(readBundle.getInt("title_style", 0));
            this.textSize = readBundle.getInt("text_size");
            this.titleSize = readBundle.getInt("title_size");
            this.iconColor = readBundle.getInt("icon_color");
            this.borderColor = readBundle.getInt("border_color");
            this.borderStyle = readBundle.getInt("border_style");
            this.borderDashWidth = readBundle.getInt("border_dash_width");
            this.borderDashGap = readBundle.getInt("border_dash_gap");
            this.borderRadius = readBundle.getInt("border_radius");
            this.borderWidth = readBundle.getInt("border_width");
            this.rangedValueRingWidth = readBundle.getInt("ranged_value_ring_width");
            this.rangedValuePrimaryColor = readBundle.getInt("ranged_value_primary_color");
            this.rangedValueSecondaryColor = readBundle.getInt("ranged_value_secondary_color");
            this.highlightColor = readBundle.getInt("highlight_color");
        }

        public Builder(Builder builder) {
            this.backgroundColor = builder.backgroundColor;
            this.backgroundDrawable = builder.backgroundDrawable;
            this.textColor = builder.textColor;
            this.titleColor = builder.titleColor;
            this.textTypeface = builder.textTypeface;
            this.titleTypeface = builder.titleTypeface;
            this.textSize = builder.textSize;
            this.titleSize = builder.titleSize;
            this.colorFilter = builder.colorFilter;
            this.iconColor = builder.iconColor;
            this.borderColor = builder.borderColor;
            this.borderStyle = builder.borderStyle;
            this.borderDashWidth = builder.borderDashWidth;
            this.borderDashGap = builder.borderDashGap;
            this.borderRadius = builder.borderRadius;
            this.borderWidth = builder.borderWidth;
            this.rangedValueRingWidth = builder.rangedValueRingWidth;
            this.rangedValuePrimaryColor = builder.rangedValuePrimaryColor;
            this.rangedValueSecondaryColor = builder.rangedValueSecondaryColor;
            this.highlightColor = builder.highlightColor;
        }

        public Builder(ComplicationStyle complicationStyle) {
            this.backgroundColor = complicationStyle.mBackgroundColor;
            this.backgroundDrawable = complicationStyle.mBackgroundDrawable;
            this.textColor = complicationStyle.mTextColor;
            this.titleColor = complicationStyle.mTitleColor;
            this.textTypeface = complicationStyle.mTextTypeface;
            this.titleTypeface = complicationStyle.mTitleTypeface;
            this.textSize = complicationStyle.mTextSize;
            this.titleSize = complicationStyle.mTitleSize;
            this.colorFilter = complicationStyle.mColorFilter;
            this.iconColor = complicationStyle.mIconColor;
            this.borderColor = complicationStyle.mBorderColor;
            this.borderStyle = complicationStyle.mBorderStyle;
            this.borderDashWidth = complicationStyle.mBorderDashWidth;
            this.borderDashGap = complicationStyle.mBorderDashGap;
            this.borderRadius = complicationStyle.mBorderRadius;
            this.borderWidth = complicationStyle.mBorderWidth;
            this.rangedValueRingWidth = complicationStyle.mRangedValueRingWidth;
            this.rangedValuePrimaryColor = complicationStyle.mRangedValuePrimaryColor;
            this.rangedValueSecondaryColor = complicationStyle.mRangedValueSecondaryColor;
            this.highlightColor = complicationStyle.mHighlightColor;
        }
    }

    public ComplicationStyle(int i, Drawable drawable, int i2, int i3, Typeface typeface, Typeface typeface2, int i4, int i5, ColorFilter colorFilter, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16) {
        this.mBackgroundColor = i;
        this.mBackgroundDrawable = drawable;
        this.mTextColor = i2;
        this.mTitleColor = i3;
        this.mTextTypeface = typeface;
        this.mTitleTypeface = typeface2;
        this.mTextSize = i4;
        this.mTitleSize = i5;
        this.mColorFilter = colorFilter;
        this.mIconColor = i6;
        this.mBorderColor = i7;
        this.mBorderStyle = i8;
        this.mBorderDashWidth = i11;
        this.mBorderDashGap = i12;
        this.mBorderRadius = i9;
        this.mBorderWidth = i10;
        this.mRangedValueRingWidth = i13;
        this.mRangedValuePrimaryColor = i14;
        this.mRangedValueSecondaryColor = i15;
        this.mHighlightColor = i16;
    }
}
