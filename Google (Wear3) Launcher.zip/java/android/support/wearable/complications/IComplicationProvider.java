package android.support.wearable.complications;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.aidl.BaseStub;
import com.google.android.aidl.Codecs;

/* compiled from: PG */
public interface IComplicationProvider extends IInterface {

    /* compiled from: PG */
    public abstract class Stub extends BaseStub implements IComplicationProvider {
        public Stub() {
            super("android.support.wearable.complications.IComplicationProvider");
        }

        protected final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) {
            switch (i) {
                case 1:
                    onUpdate(parcel.readInt(), parcel.readInt(), parcel.readStrongBinder());
                    parcel2.writeNoException();
                    break;
                case 2:
                    parcel.readInt();
                    onComplicationDeactivated$ar$ds();
                    parcel2.writeNoException();
                    break;
                case 3:
                    parcel.readInt();
                    onComplicationActivated$ar$ds$207b05de_0(parcel.readInt(), parcel.readStrongBinder());
                    parcel2.writeNoException();
                    break;
                case 4:
                    parcel2.writeNoException();
                    parcel2.writeInt(1);
                    break;
                case 5:
                    Parcelable complicationPreviewData = getComplicationPreviewData(parcel.readInt());
                    parcel2.writeNoException();
                    Codecs.writeParcelableAsReturnValue(parcel2, complicationPreviewData);
                    break;
                default:
                    return false;
            }
            return true;
        }
    }

    ComplicationData getComplicationPreviewData(int i);

    void onComplicationActivated$ar$ds$207b05de_0(int i, IBinder iBinder);

    void onComplicationDeactivated$ar$ds();

    void onUpdate(int i, int i2, IBinder iBinder);
}
