package android.support.wearable.complications;

import android.content.res.Resources;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/* compiled from: PG */
public final class TimeFormatText implements TimeDependentText {
    public static final Creator CREATOR = new PG();
    private static final DateTimeFormat[] DATE_TIME_FORMATS;
    private final Date mDate;
    public final SimpleDateFormat mDateFormat;
    public final int mStyle;
    private long mTimePrecision;
    public final TimeZone mTimeZone;

    /* renamed from: android.support.wearable.complications.TimeFormatText$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new TimeFormatText[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new TimeFormatText(parcel);
        }
    }

    /* compiled from: PG */
    final class DateTimeFormat {
        final String[] mFormatSymbols;
        final long mPrecision;

        public DateTimeFormat(String[] strArr, long j) {
            this.mFormatSymbols = strArr;
            this.mPrecision = j;
        }
    }

    static {
        r1 = new DateTimeFormat[4];
        r1[0] = new DateTimeFormat(new String[]{"S", "s"}, TimeUnit.SECONDS.toMillis(1));
        r1[1] = new DateTimeFormat(new String[]{"m"}, TimeUnit.MINUTES.toMillis(1));
        r1[2] = new DateTimeFormat(new String[]{"H", "K", "h", "k", "j", "J", "C"}, TimeUnit.HOURS.toMillis(1));
        r1[3] = new DateTimeFormat(new String[]{"a", "b", "B"}, TimeUnit.HOURS.toMillis(12));
        DATE_TIME_FORMATS = r1;
    }

    protected TimeFormatText(Parcel parcel) {
        this.mDateFormat = (SimpleDateFormat) parcel.readSerializable();
        this.mStyle = parcel.readInt();
        this.mTimeZone = (TimeZone) parcel.readSerializable();
        this.mTimePrecision = -1;
        this.mDate = new Date();
    }

    private final long getOffset(long j) {
        this.mDate.setTime(j);
        if (this.mTimeZone.inDaylightTime(this.mDate)) {
            return ((long) this.mTimeZone.getRawOffset()) + ((long) this.mTimeZone.getDSTSavings());
        }
        return (long) this.mTimeZone.getRawOffset();
    }

    public final int describeContents() {
        return 0;
    }

    public final long getNextChangeTime(long j) {
        long precision = getPrecision();
        long offset = getOffset(j);
        return ((((j + offset) / precision) + 1) * precision) - offset;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final long getPrecision() {
        /*
        r10 = this;
        r0 = r10.mTimePrecision;
        r2 = -1;
        r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r4 != 0) goto L_0x008b;
    L_0x0008:
        r0 = r10.mDateFormat;
        r0 = r0.toPattern();
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r4 = 0;
        r5 = 0;
        r6 = 0;
    L_0x0016:
        r7 = r0.length();
        if (r5 >= r7) goto L_0x0045;
    L_0x001c:
        r7 = r0.charAt(r5);
        r8 = 39;
        if (r7 != r8) goto L_0x0039;
    L_0x0024:
        r7 = r5 + 1;
        r9 = r0.length();
        if (r7 >= r9) goto L_0x0035;
    L_0x002c:
        r9 = r0.charAt(r7);
        if (r9 != r8) goto L_0x0035;
    L_0x0032:
        r5 = r5 + 2;
        goto L_0x0016;
    L_0x0035:
        r6 = r6 ^ 1;
        r5 = r7;
        goto L_0x0016;
    L_0x0039:
        if (r6 != 0) goto L_0x0042;
    L_0x003b:
        r7 = r0.charAt(r5);
        r1.append(r7);
    L_0x0042:
        r5 = r5 + 1;
        goto L_0x0016;
    L_0x0045:
        r0 = r1.toString();
        r1 = 0;
    L_0x004a:
        r5 = DATE_TIME_FORMATS;
        r5 = r5.length;
        r5 = 4;
        if (r1 >= r5) goto L_0x0079;
    L_0x0050:
        r5 = r10.mTimePrecision;
        r7 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1));
        if (r7 != 0) goto L_0x0079;
    L_0x0056:
        r5 = 0;
    L_0x0057:
        r6 = DATE_TIME_FORMATS;
        r7 = r6[r1];
        r7 = r7.mFormatSymbols;
        r7 = r7.length;
        if (r5 >= r7) goto L_0x0076;
    L_0x0060:
        r7 = r6[r1];
        r7 = r7.mFormatSymbols;
        r7 = r7[r5];
        r7 = r0.contains(r7);
        if (r7 == 0) goto L_0x0073;
    L_0x006c:
        r5 = r6[r1];
        r5 = r5.mPrecision;
        r10.mTimePrecision = r5;
        goto L_0x0076;
    L_0x0073:
        r5 = r5 + 1;
        goto L_0x0057;
    L_0x0076:
        r1 = r1 + 1;
        goto L_0x004a;
    L_0x0079:
        r0 = r10.mTimePrecision;
        r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r4 == 0) goto L_0x0080;
    L_0x007f:
        goto L_0x008c;
    L_0x0080:
        r0 = java.util.concurrent.TimeUnit.DAYS;
        r1 = 1;
        r0 = r0.toMillis(r1);
        r10.mTimePrecision = r0;
        return r0;
    L_0x008c:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.wearable.complications.TimeFormatText.getPrecision():long");
    }

    public final CharSequence getTextAt(Resources resources, long j) {
        String format = this.mDateFormat.format(new Date(j));
        switch (this.mStyle) {
            case 2:
                return format.toUpperCase();
            case 3:
                return format.toLowerCase();
            default:
                return format;
        }
    }

    public final boolean returnsSameText(long j, long j2) {
        long precision = getPrecision();
        return (j + getOffset(j)) / precision == (j2 + getOffset(j2)) / precision;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeSerializable(this.mDateFormat);
        parcel.writeInt(this.mStyle);
        parcel.writeSerializable(this.mTimeZone);
    }

    public TimeFormatText(String str, int i, TimeZone timeZone) {
        if (str != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);
            this.mDateFormat = simpleDateFormat;
            this.mStyle = i;
            this.mTimePrecision = -1;
            if (timeZone != null) {
                simpleDateFormat.setTimeZone(timeZone);
                this.mTimeZone = timeZone;
            } else {
                this.mTimeZone = simpleDateFormat.getTimeZone();
            }
            this.mDate = new Date();
            return;
        }
        throw new IllegalArgumentException("Format must be specified.");
    }
}
