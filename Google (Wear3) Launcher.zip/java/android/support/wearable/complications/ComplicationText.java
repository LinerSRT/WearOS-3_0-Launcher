package android.support.wearable.complications;

import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import p020j$.util.DesugarTimeZone;

/* compiled from: PG */
public final class ComplicationText implements Parcelable, TimeDependentText {
    public static final Creator CREATOR = new PG();
    private CharSequence mDependentTextCache;
    private long mDependentTextCacheTime;
    private final CharSequence mSurroundingText;
    private final CharSequence[] mTemplateValues;
    public final TimeDependentText mTimeDependentText;

    /* renamed from: android.support.wearable.complications.ComplicationText$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ComplicationText[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ComplicationText(parcel);
        }
    }

    /* compiled from: PG */
    public final class TimeDifferenceBuilder {
        private long mReferencePeriodEndMillis = Long.MAX_VALUE;
        private long mReferencePeriodStartMillis = 0;
        private int mStyle = 3;
        public CharSequence mSurroundingText;

        public final ComplicationText build() {
            long j = this.mReferencePeriodEndMillis;
            long j2 = this.mReferencePeriodStartMillis;
            if (j >= j2) {
                boolean z;
                int i = this.mStyle;
                if (i != 1) {
                    z = true;
                } else {
                    z = false;
                }
                return new ComplicationText(this.mSurroundingText, new TimeDifferenceText(j2, j, i, z, null));
            }
            throw new IllegalStateException("Reference period end must not be before start.");
        }

        public final void setReferencePeriodEndMillis$ar$ds(long j) {
            if (j >= 0) {
                this.mReferencePeriodEndMillis = j;
                return;
            }
            throw new IllegalArgumentException("Reference period end cannot be negative");
        }

        public final void setReferencePeriodStartMillis$ar$ds(long j) {
            if (j >= 0) {
                this.mReferencePeriodStartMillis = j;
                return;
            }
            throw new IllegalArgumentException("Reference period start cannot be negative");
        }

        public final void setStyle$ar$ds$f1da1ed9_0() {
            this.mStyle = 3;
        }
    }

    /* compiled from: PG */
    public final class TimeFormatBuilder {
        public String mFormat;

        public final ComplicationText build() {
            return new ComplicationText(null, new TimeFormatText(this.mFormat, 1, null));
        }
    }

    public ComplicationText(Parcel parcel) {
        String str;
        this.mTemplateValues = new CharSequence[]{"", "^2", "^3", "^4", "^5", "^6", "^7", "^8", "^9"};
        Bundle readBundle = parcel.readBundle(getClass().getClassLoader());
        this.mSurroundingText = readBundle.getCharSequence("surrounding_string");
        String str2 = "difference_style";
        TimeZone timeZone = null;
        if (readBundle.containsKey(str2)) {
            str = "difference_period_start";
            if (readBundle.containsKey(str)) {
                String str3 = "difference_period_end";
                if (readBundle.containsKey(str3)) {
                    TimeUnit timeUnit;
                    long j = readBundle.getLong(str);
                    long j2 = readBundle.getLong(str3);
                    int i = readBundle.getInt(str2);
                    boolean z = readBundle.getBoolean("show_now_text", true);
                    String string = readBundle.getString("minimum_unit");
                    if (string == null) {
                        timeUnit = null;
                    } else {
                        try {
                            timeZone = TimeUnit.valueOf(string);
                            timeUnit = timeZone;
                        } catch (IllegalArgumentException e) {
                            timeUnit = timeZone;
                        }
                    }
                    this.mTimeDependentText = new TimeDifferenceText(j, j2, i, z, timeUnit);
                    checkFields();
                }
            }
        }
        str2 = "format_format_string";
        if (readBundle.containsKey(str2)) {
            str = "format_style";
            if (readBundle.containsKey(str)) {
                String str4 = "format_time_zone";
                if (readBundle.containsKey(str4)) {
                    timeZone = DesugarTimeZone.getTimeZone(readBundle.getString(str4));
                }
                this.mTimeDependentText = new TimeFormatText(readBundle.getString(str2), readBundle.getInt(str), timeZone);
                checkFields();
            }
        }
        this.mTimeDependentText = null;
        checkFields();
    }

    private final void checkFields() {
        if (this.mSurroundingText != null) {
            return;
        }
        if (this.mTimeDependentText == null) {
            throw new IllegalStateException("One of mSurroundingText and mTimeDependentText must be non-null");
        }
    }

    public static ComplicationText plainText(CharSequence charSequence) {
        return new ComplicationText(charSequence, null);
    }

    public final int describeContents() {
        return 0;
    }

    public final long getNextChangeTime(long j) {
        TimeDependentText timeDependentText = this.mTimeDependentText;
        return timeDependentText == null ? Long.MAX_VALUE : timeDependentText.getNextChangeTime(j);
    }

    public final CharSequence getTextAt(Resources resources, long j) {
        TimeDependentText timeDependentText = this.mTimeDependentText;
        if (timeDependentText == null) {
            return this.mSurroundingText;
        }
        CharSequence textAt;
        if (this.mDependentTextCache == null || !timeDependentText.returnsSameText(this.mDependentTextCacheTime, j)) {
            textAt = this.mTimeDependentText.getTextAt(resources, j);
            this.mDependentTextCacheTime = j;
            this.mDependentTextCache = textAt;
        } else {
            textAt = this.mDependentTextCache;
        }
        CharSequence charSequence = this.mSurroundingText;
        if (charSequence == null) {
            return textAt;
        }
        CharSequence[] charSequenceArr = this.mTemplateValues;
        charSequenceArr[0] = textAt;
        return TextUtils.expandTemplate(charSequence, charSequenceArr);
    }

    public final boolean isAlwaysEmpty() {
        return this.mTimeDependentText == null && TextUtils.isEmpty(this.mSurroundingText);
    }

    public final boolean returnsSameText(long j, long j2) {
        TimeDependentText timeDependentText = this.mTimeDependentText;
        return timeDependentText == null ? true : timeDependentText.returnsSameText(j, j2);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        Bundle bundle = new Bundle();
        bundle.putCharSequence("surrounding_string", this.mSurroundingText);
        TimeDependentText timeDependentText = this.mTimeDependentText;
        if (timeDependentText instanceof TimeDifferenceText) {
            TimeDifferenceText timeDifferenceText = (TimeDifferenceText) timeDependentText;
            bundle.putLong("difference_period_start", timeDifferenceText.mReferencePeriodStart);
            bundle.putLong("difference_period_end", timeDifferenceText.mReferencePeriodEnd);
            bundle.putInt("difference_style", timeDifferenceText.mStyle);
            bundle.putBoolean("show_now_text", timeDifferenceText.mShowNowText);
            TimeUnit timeUnit = timeDifferenceText.mMinimumUnit;
            if (timeUnit != null) {
                bundle.putString("minimum_unit", timeUnit.name());
            }
        } else if (timeDependentText instanceof TimeFormatText) {
            TimeFormatText timeFormatText = (TimeFormatText) timeDependentText;
            bundle.putString("format_format_string", timeFormatText.mDateFormat.toPattern());
            bundle.putInt("format_style", timeFormatText.mStyle);
            TimeZone timeZone = timeFormatText.mTimeZone;
            if (timeZone != null) {
                bundle.putString("format_time_zone", timeZone.getID());
            }
        }
        parcel.writeBundle(bundle);
    }

    public ComplicationText(CharSequence charSequence, TimeDependentText timeDependentText) {
        this.mTemplateValues = new CharSequence[]{"", "^2", "^3", "^4", "^5", "^6", "^7", "^8", "^9"};
        this.mSurroundingText = charSequence;
        this.mTimeDependentText = timeDependentText;
        checkFields();
    }
}
