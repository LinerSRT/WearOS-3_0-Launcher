package android.support.wearable.phone;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.net.Uri.Builder;

/* compiled from: PG */
public final class PhoneDeviceType {
    private static final Uri BLUETOOTH_MODE_URI = new Builder().scheme("content").authority("com.google.android.wearable.settings").path("bluetooth_mode").build();

    public static int getPhoneDeviceType(Context context) {
        Cursor query = context.getContentResolver().query(BLUETOOTH_MODE_URI, null, null, null, null);
        if (query == null) {
            return 0;
        }
        do {
            try {
                if (!query.moveToNext()) {
                    break;
                }
            } catch (Throwable th) {
                query.close();
            }
        } while (!"bluetooth_mode".equals(query.getString(0)));
        switch (query.getInt(1)) {
            case 1:
                query.close();
                return 1;
            case 2:
                query.close();
                return 2;
        }
        query.close();
        return 0;
    }
}
