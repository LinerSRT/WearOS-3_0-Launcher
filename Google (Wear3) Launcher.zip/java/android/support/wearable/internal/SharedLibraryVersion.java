package android.support.wearable.internal;

import com.google.android.wearable.WearableSharedLib;

/* compiled from: PG */
public final class SharedLibraryVersion {

    /* compiled from: PG */
    final class PresenceHolder {
        static final boolean PRESENT;

        static {
            boolean z;
            try {
                Class.forName("com.google.android.wearable.compat.WearableActivityController");
                z = true;
            } catch (ClassNotFoundException e) {
                z = false;
            }
            PRESENT = z;
        }
    }

    /* compiled from: PG */
    final class VersionHolder {
        static final int VERSION = WearableSharedLib.version();
    }

    public static void verifySharedLibraryPresent() {
        if (!PresenceHolder.PRESENT) {
            throw new IllegalStateException("Could not find wearable shared library classes. Please add <uses-library android:name=\"com.google.android.wearable\" android:required=\"false\" /> to the application manifest");
        }
    }

    public static int version() {
        verifySharedLibraryPresent();
        return VersionHolder.VERSION;
    }
}
