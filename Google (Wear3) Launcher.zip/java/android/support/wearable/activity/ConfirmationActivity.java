package android.support.wearable.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.wearable.view.ConfirmationOverlay;
import android.support.wearable.view.ConfirmationOverlay.FinishedAnimationListener;
import android.support.wearable.view.ResourcesUtil;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.content.ContextCompat.Api21Impl;
import com.google.android.wearable.sysui.R;
import java.util.Locale;

/* compiled from: PG */
public final class ConfirmationActivity extends Activity implements FinishedAnimationListener {
    private static final SparseIntArray CONFIRMATION_OVERLAY_TYPES;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        CONFIRMATION_OVERLAY_TYPES = sparseIntArray;
        sparseIntArray.append(1, 0);
        sparseIntArray.append(2, 2);
        sparseIntArray.append(3, 1);
    }

    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setTheme(R.style.ConfirmationActivity);
        Intent intent = getIntent();
        int intExtra = intent.getIntExtra("android.support.wearable.activity.extra.ANIMATION_TYPE", 1);
        SparseIntArray sparseIntArray = CONFIRMATION_OVERLAY_TYPES;
        if (sparseIntArray.indexOfKey(intExtra) >= 0) {
            intExtra = sparseIntArray.get(intExtra);
            String stringExtra = intent.getStringExtra("android.support.wearable.activity.extra.MESSAGE");
            ConfirmationOverlay confirmationOverlay = new ConfirmationOverlay();
            confirmationOverlay.mType = intExtra;
            confirmationOverlay.mMessage = stringExtra;
            confirmationOverlay.mListener = this;
            if (!confirmationOverlay.mIsShowing) {
                confirmationOverlay.mIsShowing = true;
                if (confirmationOverlay.mOverlayView == null) {
                    confirmationOverlay.mOverlayView = LayoutInflater.from(this).inflate(R.layout.overlay_confirmation, null);
                }
                confirmationOverlay.mOverlayView.setOnTouchListener(confirmationOverlay);
                confirmationOverlay.mOverlayView.setLayoutParams(new LayoutParams(-1, -1));
                View view = confirmationOverlay.mOverlayView;
                switch (confirmationOverlay.mType) {
                    case 0:
                        confirmationOverlay.mOverlayDrawable = Api21Impl.getDrawable(this, R.drawable.generic_confirmation_animation);
                        break;
                    case 1:
                        confirmationOverlay.mOverlayDrawable = Api21Impl.getDrawable(this, R.drawable.ic_full_sad);
                        break;
                    case 2:
                        confirmationOverlay.mOverlayDrawable = Api21Impl.getDrawable(this, R.drawable.open_on_phone_animation);
                        break;
                    default:
                        throw new IllegalStateException(String.format(Locale.US, "Invalid ConfirmationOverlay type [%d]", new Object[]{Integer.valueOf(confirmationOverlay.mType)}));
                }
                ((ImageView) view.findViewById(R.id.wearable_support_confirmation_overlay_image)).setImageDrawable(confirmationOverlay.mOverlayDrawable);
                TextView textView = (TextView) confirmationOverlay.mOverlayView.findViewById(R.id.wearable_support_confirmation_overlay_message);
                if (confirmationOverlay.mMessage != null) {
                    intExtra = getResources().getDisplayMetrics().widthPixels;
                    int fractionOfScreenPx = ResourcesUtil.getFractionOfScreenPx(this, intExtra, R.fraction.confirmation_overlay_margin_above_text);
                    intExtra = ResourcesUtil.getFractionOfScreenPx(this, intExtra, R.fraction.confirmation_overlay_margin_side);
                    MarginLayoutParams marginLayoutParams = (MarginLayoutParams) textView.getLayoutParams();
                    marginLayoutParams.topMargin = fractionOfScreenPx;
                    marginLayoutParams.leftMargin = intExtra;
                    marginLayoutParams.rightMargin = intExtra;
                    textView.setLayoutParams(marginLayoutParams);
                    textView.setText(confirmationOverlay.mMessage);
                    textView.setVisibility(0);
                } else {
                    textView.setVisibility(8);
                }
                Window window = getWindow();
                View view2 = confirmationOverlay.mOverlayView;
                window.addContentView(view2, view2.getLayoutParams());
                Drawable drawable = confirmationOverlay.mOverlayDrawable;
                if (drawable instanceof Animatable) {
                    ((Animatable) drawable).start();
                }
                confirmationOverlay.mMainThreadHandler.postDelayed(confirmationOverlay.mHideRunnable, 1000);
                return;
            }
            return;
        }
        StringBuilder stringBuilder = new StringBuilder(38);
        stringBuilder.append("Unknown type of animation: ");
        stringBuilder.append(intExtra);
        throw new IllegalArgumentException(stringBuilder.toString());
    }
}
