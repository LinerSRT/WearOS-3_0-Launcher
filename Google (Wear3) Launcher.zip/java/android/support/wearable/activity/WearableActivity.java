package android.support.wearable.activity;

import android.app.Activity;
import android.os.Bundle;
import android.support.wearable.internal.SharedLibraryVersion;
import com.google.android.wearable.compat.WearableActivityController;
import com.google.android.wearable.compat.WearableActivityController.AmbientCallback;
import java.io.FileDescriptor;
import java.io.PrintWriter;

@Deprecated
/* compiled from: PG */
public class WearableActivity extends Activity {
    private final PG callback$ar$class_merging;
    private final WearableActivityDelegate mDelegate;

    /* renamed from: android.support.wearable.activity.WearableActivity$1 */
    final class PG {
    }

    public WearableActivity() {
        PG pg = new PG();
        this.callback$ar$class_merging = pg;
        this.mDelegate = new WearableActivityDelegate(pg);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        WearableActivityDelegate wearableActivityDelegate = this.mDelegate;
        SharedLibraryVersion.verifySharedLibraryPresent();
        android.support.wearable.activity.WearableActivityDelegate.PG pg = new android.support.wearable.activity.WearableActivityDelegate.PG();
        String valueOf = String.valueOf(wearableActivityDelegate.getClass().getSimpleName());
        String str = "WearActivity[";
        valueOf = valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
        wearableActivityDelegate.mWearableController = new WearableActivityController(String.valueOf(valueOf.substring(0, Math.min(valueOf.length(), 22))).concat("]"), this, pg);
        if (!WearableActivityDelegate.sAmbientCallbacksVerifiedPresent) {
            try {
                String str2 = ".onEnterAmbient";
                str = ".";
                valueOf = String.valueOf(AmbientCallback.class.getDeclaredMethod("onEnterAmbient", new Class[]{Bundle.class}).getName());
                if (str2.equals(valueOf.length() != 0 ? str.concat(valueOf) : new String(str))) {
                    WearableActivityDelegate.sAmbientCallbacksVerifiedPresent = true;
                } else {
                    throw new NoSuchMethodException();
                }
            } catch (Throwable e) {
                throw new IllegalStateException("Could not find a required method for ambient support, likely due to proguard optimization. Please add com.google.android.wearable:wearable jar to the list of library jars for your project", e);
            }
        }
        WearableActivityController wearableActivityController = wearableActivityDelegate.mWearableController;
        if (wearableActivityController != null) {
            wearableActivityController.onCreate();
        }
    }

    protected final void onResume() {
        super.onResume();
        WearableActivityController wearableActivityController = this.mDelegate.mWearableController;
        if (wearableActivityController != null) {
            wearableActivityController.onResume();
        }
    }

    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        WearableActivityController wearableActivityController = this.mDelegate.mWearableController;
        if (wearableActivityController != null) {
            wearableActivityController.dump(str, fileDescriptor, printWriter, strArr);
        }
    }

    protected void onDestroy() {
        WearableActivityController wearableActivityController = this.mDelegate.mWearableController;
        if (wearableActivityController != null) {
            wearableActivityController.onDestroy();
        }
        super.onDestroy();
    }

    protected final void onPause() {
        WearableActivityController wearableActivityController = this.mDelegate.mWearableController;
        if (wearableActivityController != null) {
            wearableActivityController.onPause();
        }
        super.onPause();
    }

    protected final void onStop() {
        WearableActivityController wearableActivityController = this.mDelegate.mWearableController;
        if (wearableActivityController != null) {
            wearableActivityController.onStop();
        }
        super.onStop();
    }
}
