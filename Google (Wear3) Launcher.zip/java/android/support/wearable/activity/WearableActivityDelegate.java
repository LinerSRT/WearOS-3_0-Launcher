package android.support.wearable.activity;

import android.os.Bundle;
import com.google.android.wearable.compat.WearableActivityController;
import com.google.android.wearable.compat.WearableActivityController.AmbientCallback;

@Deprecated
/* compiled from: PG */
public final class WearableActivityDelegate {
    public static volatile boolean sAmbientCallbacksVerifiedPresent;
    public final android.support.wearable.activity.WearableActivity.PG mCallback$ar$class_merging$967934dc_0;
    public WearableActivityController mWearableController;

    /* renamed from: android.support.wearable.activity.WearableActivityDelegate$1 */
    final class PG extends AmbientCallback {
        public final void onEnterAmbient(Bundle bundle) {
            WearableActivity wearableActivity = WearableActivityDelegate.this.mCallback$ar$class_merging$967934dc_0.this$0;
        }

        public final void onExitAmbient() {
            WearableActivity wearableActivity = WearableActivityDelegate.this.mCallback$ar$class_merging$967934dc_0.this$0;
        }

        public final void onInvalidateAmbientOffload() {
            android.support.wearable.activity.WearableActivity.PG pg = WearableActivityDelegate.this.mCallback$ar$class_merging$967934dc_0;
            if (pg instanceof android.support.wearable.activity.WearableActivity.PG) {
                WearableActivity wearableActivity = pg.this$0;
            }
        }

        public final void onUpdateAmbient() {
            WearableActivity wearableActivity = WearableActivityDelegate.this.mCallback$ar$class_merging$967934dc_0.this$0;
        }
    }

    public WearableActivityDelegate(android.support.wearable.activity.WearableActivity.PG pg) {
        this.mCallback$ar$class_merging$967934dc_0 = pg;
    }
}
