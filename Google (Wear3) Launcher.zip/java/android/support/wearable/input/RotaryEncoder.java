package android.support.wearable.input;

import android.content.Context;
import android.support.wearable.internal.SharedLibraryVersion;
import android.view.MotionEvent;
import com.google.android.wearable.input.RotaryEncoderHelper;

@Deprecated
/* compiled from: PG */
public final class RotaryEncoder {
    @Deprecated
    public static float getRotaryAxisValue(MotionEvent motionEvent) {
        return isLibAvailable() ? RotaryEncoderHelper.getRotaryAxisValue(motionEvent) : 0.0f;
    }

    @Deprecated
    public static float getScaledScrollFactor(Context context) {
        return isLibAvailable() ? RotaryEncoderHelper.getScaledScrollFactor(context) : 64.0f;
    }

    @Deprecated
    public static boolean isFromRotaryEncoder(MotionEvent motionEvent) {
        return isLibAvailable() && RotaryEncoderHelper.isFromRotaryEncoder(motionEvent);
    }

    private static boolean isLibAvailable() {
        return SharedLibraryVersion.version() > 0;
    }
}
