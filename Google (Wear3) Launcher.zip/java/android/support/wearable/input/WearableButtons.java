package android.support.wearable.input;

import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.provider.Settings.System;
import android.support.wearable.internal.SharedLibraryVersion;
import android.view.WindowManager;
import com.google.android.wearable.input.WearableInputDevice;

/* compiled from: PG */
public final class WearableButtons {
    private static volatile int sButtonCount = -1;

    /* compiled from: PG */
    public final class ButtonInfo {
        public final int keycode;
        /* renamed from: x */
        public final float f9x;
        /* renamed from: y */
        public final float f10y;

        public ButtonInfo(int i, float f, float f2) {
            this.keycode = i;
            this.f9x = f;
            this.f10y = f2;
        }
    }

    private WearableButtons() {
        throw new RuntimeException("WearableButtons should not be instantiated");
    }

    public static int getButtonCount(Context context) {
        if (!isApiAvailable()) {
            return -1;
        }
        int i = sButtonCount;
        if (i == -1) {
            synchronized (WearableButtons.class) {
                i = WearableInputDevice.getAvailableButtonKeyCodes(context).length;
                sButtonCount = i;
            }
        }
        return i;
    }

    public static final ButtonInfo getButtonInfo(Context context, int i) {
        if (!isApiAvailable()) {
            return null;
        }
        Bundle buttonInfo = WearableInputDevice.getButtonInfo(context, i);
        String str = "x_key";
        if (buttonInfo.containsKey(str)) {
            String str2 = "y_key";
            if (buttonInfo.containsKey(str2)) {
                float f;
                float f2 = buttonInfo.getFloat(str);
                float f3 = buttonInfo.getFloat(str2);
                WindowManager windowManager = (WindowManager) context.getSystemService("window");
                Point point = new Point();
                windowManager.getDefaultDisplay().getSize(point);
                if (System.getInt(context.getContentResolver(), "user_rotation", 0) == 2) {
                    f = ((float) point.x) - f2;
                    f2 = ((float) point.y) - f3;
                    str = "x_key_rotated";
                    if (buttonInfo.containsKey(str)) {
                        String str3 = "y_key_rotated";
                        if (buttonInfo.containsKey(str3)) {
                            f2 = buttonInfo.getFloat(str);
                            f3 = buttonInfo.getFloat(str3);
                        }
                    }
                    f3 = f2;
                    f2 = f;
                }
                boolean isScreenRound = context.getResources().getConfiguration().isScreenRound();
                if (f2 != Float.MAX_VALUE) {
                    if (f3 != Float.MAX_VALUE) {
                        if (isScreenRound) {
                            double atan2 = Math.atan2((double) (((float) (point.y / 2)) - f3), (double) (f2 - ((float) (point.x / 2))));
                            if (atan2 < 0.0d) {
                                atan2 += 6.283185307179586d;
                            }
                            Math.round((float) (atan2 / 0.39269908169872414d));
                        } else {
                            float f4 = ((float) point.x) - f2;
                            f = Math.min(f2, Math.min(f4, Math.min(f3, ((float) point.y) - f3)));
                            int i2;
                            if (f == f2) {
                                i2 = point.y;
                            } else if (f == f4) {
                                i2 = point.y;
                            } else if (f == f3) {
                                i2 = point.x;
                            } else {
                                i2 = point.x;
                            }
                        }
                    }
                }
                return new ButtonInfo(i, f2, f3);
            }
        }
        return null;
    }

    private static boolean isApiAvailable() {
        return SharedLibraryVersion.version() > 0;
    }
}
