package android.support.wearable.view;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.support.wearable.R$styleable;
import android.text.Layout;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.view.View;
import p020j$.util.Objects;

@Deprecated
/* compiled from: PG */
public final class ActionLabel extends View {
    private int mCurTextColor;
    private float mCurrentTextSize;
    private int mDrawMaxLines;
    private int mGravity = 8388659;
    public Layout mLayout;
    private final float mLineSpacingAdd;
    private final float mLineSpacingMult;
    private int mMaxLines = Integer.MAX_VALUE;
    public float mMaxTextSize;
    public float mMinTextSize;
    public float mSpacingAdd = 0.0f;
    public float mSpacingMult = 1.0f;
    public CharSequence mText;
    public ColorStateList mTextColor;
    private final TextPaint mTextPaint;

    private final android.text.Layout makeNewLayout(int r12, int r13, android.text.Layout.Alignment r14) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Unknown predecessor block by arg (r0_5 android.text.Layout) in PHI: PHI: (r0_6 android.text.Layout) = (r0_5 android.text.Layout), (r0_7 android.text.Layout) binds: {(r0_5 android.text.Layout)=B:16:0x005f, (r0_7 android.text.Layout)=B:41:0x0062}
	at jadx.core.dex.instructions.PhiInsn.replaceArg(PhiInsn.java:79)
	at jadx.core.dex.visitors.ModVisitor.processInvoke(ModVisitor.java:222)
	at jadx.core.dex.visitors.ModVisitor.replaceStep(ModVisitor.java:83)
	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:68)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
*/
        /*
        r11 = this;
        if (r13 <= 0) goto L_0x00bd;
    L_0x0002:
        if (r12 > 0) goto L_0x0006;
    L_0x0004:
        goto L_0x00bd;
    L_0x0006:
        r0 = r11.getPaddingTop();
        r1 = r11.getPaddingBottom();
        r0 = r0 + r1;
        r13 = r13 - r0;
        r0 = r11.getPaddingLeft();
        r1 = r11.getPaddingRight();
        r0 = r0 + r1;
        r12 = r12 - r0;
        r0 = r11.mMaxTextSize;
        r11.mCurrentTextSize = r0;
        r1 = r11.mTextPaint;
        r1.setTextSize(r0);
        r0 = new android.text.StaticLayout;
        r2 = r11.mText;
        r3 = r11.mTextPaint;
        r6 = r11.mSpacingMult;
        r7 = r11.mSpacingAdd;
        r8 = 1;
        r1 = r0;
        r4 = r12;
        r5 = r14;
        r1.<init>(r2, r3, r4, r5, r6, r7, r8);
        r1 = r0.getLineCount();
        r2 = r11.mMaxLines;
        r9 = 1;
        r10 = 0;
        if (r1 <= r2) goto L_0x0040;
    L_0x003e:
        r1 = 1;
        goto L_0x0041;
    L_0x0040:
        r1 = 0;
    L_0x0041:
        r2 = r0.getLineCount();
        r2 = r0.getLineTop(r2);
        if (r2 <= r13) goto L_0x004d;
    L_0x004b:
        r2 = 1;
        goto L_0x004e;
    L_0x004d:
        r2 = 0;
    L_0x004e:
        r3 = r11.mTextPaint;
        r3 = r3.getTextSize();
        r4 = r11.mMinTextSize;
        r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1));
        if (r3 <= 0) goto L_0x005c;
    L_0x005a:
        r3 = 1;
        goto L_0x005d;
    L_0x005c:
        r3 = 0;
    L_0x005d:
        if (r1 != 0) goto L_0x0063;
    L_0x005f:
        if (r2 == 0) goto L_0x0062;
    L_0x0061:
        goto L_0x0064;
    L_0x0062:
        goto L_0x00b0;
    L_0x0064:
        if (r1 != 0) goto L_0x0068;
    L_0x0066:
        if (r2 == 0) goto L_0x0062;
    L_0x0068:
        if (r3 == 0) goto L_0x00af;
    L_0x006a:
        r0 = r11.mCurrentTextSize;
        r1 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r0 = r0 + r1;
        r11.mCurrentTextSize = r0;
        r1 = r11.mTextPaint;
        r1.setTextSize(r0);
        r0 = new android.text.StaticLayout;
        r2 = r11.mText;
        r3 = r11.mTextPaint;
        r6 = r11.mSpacingMult;
        r7 = r11.mSpacingAdd;
        r8 = 1;
        r1 = r0;
        r4 = r12;
        r5 = r14;
        r1.<init>(r2, r3, r4, r5, r6, r7, r8);
        r1 = r0.getLineCount();
        r1 = r0.getLineTop(r1);
        if (r1 <= r13) goto L_0x0093;
    L_0x0091:
        r2 = 1;
        goto L_0x0094;
    L_0x0093:
        r2 = 0;
    L_0x0094:
        r1 = r0.getLineCount();
        r3 = r11.mMaxLines;
        if (r1 <= r3) goto L_0x009e;
    L_0x009c:
        r1 = 1;
        goto L_0x009f;
    L_0x009e:
        r1 = 0;
    L_0x009f:
        r3 = r11.mTextPaint;
        r3 = r3.getTextSize();
        r4 = r11.mMinTextSize;
        r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1));
        if (r3 <= 0) goto L_0x00ad;
    L_0x00ab:
        r3 = 1;
        goto L_0x0064;
    L_0x00ad:
        r3 = 0;
        goto L_0x0064;
    L_0x00b0:
        r12 = r11.mMaxLines;
        r13 = r0.getLineCount();
        r12 = java.lang.Math.min(r12, r13);
        r11.mDrawMaxLines = r12;
        return r0;
    L_0x00bd:
        r12 = 0;
        return r12;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.wearable.view.ActionLabel.makeNewLayout(int, int, android.text.Layout$Alignment):android.text.Layout");
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        ColorStateList colorStateList = this.mTextColor;
        if (colorStateList != null && colorStateList.isStateful()) {
            updateTextColors();
        }
    }

    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.mLayout != null) {
            canvas.save();
            this.mTextPaint.setColor(this.mCurTextColor);
            this.mTextPaint.drawableState = getDrawableState();
            float paddingLeft = (float) getPaddingLeft();
            int paddingTop = getPaddingTop();
            int height = getHeight() - (getPaddingTop() + getPaddingBottom());
            int lineTop = this.mLayout.getLineTop(this.mDrawMaxLines);
            switch (this.mGravity & 112) {
                case 16:
                    height = (height - lineTop) / 2;
                    break;
                case 48:
                    height = 0;
                    break;
                case 80:
                    height -= lineTop;
                    break;
                default:
                    height = 0;
                    break;
            }
            canvas.translate(paddingLeft, (float) (paddingTop + height));
            canvas.clipRect(0, 0, getWidth() - getPaddingRight(), this.mLayout.getLineTop(this.mDrawMaxLines));
            this.mLayout.draw(canvas);
            canvas.restore();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected final void onMeasure(int r9, int r10) {
        /*
        r8 = this;
        r0 = android.view.View.MeasureSpec.getMode(r9);
        r1 = android.view.View.MeasureSpec.getMode(r10);
        r9 = android.view.View.MeasureSpec.getSize(r9);
        r10 = android.view.View.MeasureSpec.getSize(r10);
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r3 = -1;
        if (r0 != r2) goto L_0x0017;
    L_0x0015:
        r4 = r9;
        goto L_0x0018;
    L_0x0017:
        r4 = -1;
    L_0x0018:
        if (r1 != r2) goto L_0x001c;
    L_0x001a:
        r5 = r10;
        goto L_0x001d;
    L_0x001c:
        r5 = -1;
    L_0x001d:
        if (r4 != r3) goto L_0x003b;
    L_0x001f:
        r4 = r8.mTextPaint;
        r6 = r8.mMaxTextSize;
        r4.setTextSize(r6);
        r4 = r8.mText;
        r6 = r8.mTextPaint;
        r4 = android.text.Layout.getDesiredWidth(r4, r6);
        r6 = (double) r4;
        r6 = java.lang.Math.ceil(r6);
        r4 = (int) r6;
        r6 = r8.mTextPaint;
        r7 = r8.mCurrentTextSize;
        r6.setTextSize(r7);
    L_0x003b:
        r6 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        if (r0 != r6) goto L_0x0043;
    L_0x003f:
        r4 = java.lang.Math.min(r4, r9);
    L_0x0043:
        r9 = r8.getTextAlignment();
        switch(r9) {
            case 1: goto L_0x0056;
            case 2: goto L_0x0053;
            case 3: goto L_0x0050;
            case 4: goto L_0x004d;
            default: goto L_0x004a;
        };
    L_0x004a:
        r9 = android.text.Layout.Alignment.ALIGN_NORMAL;
        goto L_0x0060;
    L_0x004d:
        r9 = android.text.Layout.Alignment.ALIGN_CENTER;
        goto L_0x0060;
    L_0x0050:
        r9 = android.text.Layout.Alignment.ALIGN_OPPOSITE;
        goto L_0x0060;
    L_0x0053:
        r9 = android.text.Layout.Alignment.ALIGN_NORMAL;
        goto L_0x0060;
    L_0x0056:
        r9 = r8.mGravity;
        r0 = 8388615; // 0x800007 float:1.1754953E-38 double:4.1445265E-317;
        r9 = r9 & r0;
        switch(r9) {
            case 1: goto L_0x004d;
            case 3: goto L_0x0053;
            case 5: goto L_0x0050;
            case 8388611: goto L_0x0053;
            case 8388613: goto L_0x0050;
            default: goto L_0x005f;
        };
    L_0x005f:
        goto L_0x0053;
    L_0x0060:
        if (r5 != r3) goto L_0x0069;
    L_0x0062:
        if (r1 != r6) goto L_0x0066;
    L_0x0064:
        r5 = r10;
        goto L_0x0069;
    L_0x0066:
        r5 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
    L_0x0069:
        r0 = r8.mLayout;
        if (r0 != 0) goto L_0x0074;
    L_0x006d:
        r9 = r8.makeNewLayout(r4, r5, r9);
        r8.mLayout = r9;
        goto L_0x0088;
    L_0x0074:
        r0 = r0.getWidth();
        r3 = r8.mLayout;
        r3 = r3.getHeight();
        if (r0 != r4) goto L_0x0082;
    L_0x0080:
        if (r3 == r5) goto L_0x0088;
    L_0x0082:
        r9 = r8.makeNewLayout(r4, r5, r9);
        r8.mLayout = r9;
    L_0x0088:
        r9 = r8.mLayout;
        if (r9 != 0) goto L_0x0091;
    L_0x008c:
        r9 = 0;
        r8.setMeasuredDimension(r9, r9);
        return;
    L_0x0091:
        if (r1 == r2) goto L_0x009b;
    L_0x0093:
        r0 = r9.getLineCount();
        r5 = r9.getLineTop(r0);
    L_0x009b:
        if (r1 != r6) goto L_0x00a1;
    L_0x009d:
        r5 = java.lang.Math.min(r5, r10);
    L_0x00a1:
        r8.setMeasuredDimension(r4, r5);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.wearable.view.ActionLabel.onMeasure(int, int):void");
    }

    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        this.mLayout = null;
        requestLayout();
        invalidate();
    }

    public final void setGravity(int i) {
        if (this.mGravity != i) {
            this.mGravity = i;
            invalidate();
        }
    }

    public final void setMaxLines(int i) {
        if (this.mMaxLines != i) {
            this.mMaxLines = i;
            this.mLayout = null;
            requestLayout();
            invalidate();
        }
    }

    public final void setTypeface(Typeface typeface) {
        if (!Objects.equals(this.mTextPaint.getTypeface(), typeface)) {
            this.mTextPaint.setTypeface(typeface);
            if (this.mLayout != null) {
                requestLayout();
                invalidate();
            }
        }
    }

    final void setTypefaceFromAttrs(String str, int i, int i2) {
        Typeface create;
        if (str != null) {
            create = Typeface.create(str, i2);
            if (create != null) {
                setTypeface(create);
                return;
            }
        } else {
            create = null;
        }
        switch (i) {
            case 1:
                create = Typeface.SANS_SERIF;
                break;
            case 2:
                create = Typeface.SERIF;
                break;
            case 3:
                create = Typeface.MONOSPACE;
                break;
            default:
                break;
        }
        float f = 0.0f;
        boolean z = false;
        if (i2 > 0) {
            int style;
            if (create == null) {
                create = Typeface.defaultFromStyle(i2);
            } else {
                create = Typeface.create(create, i2);
            }
            setTypeface(create);
            if (create != null) {
                style = create.getStyle();
            } else {
                style = 0;
            }
            style = (style ^ -1) & i2;
            TextPaint textPaint = this.mTextPaint;
            if (1 == (style & 1)) {
                z = true;
            }
            textPaint.setFakeBoldText(z);
            textPaint = this.mTextPaint;
            if ((style & 2) != 0) {
                f = -0.25f;
            }
            textPaint.setTextSkewX(f);
            return;
        }
        this.mTextPaint.setFakeBoldText(false);
        this.mTextPaint.setTextSkewX(0.0f);
        setTypeface(create);
    }

    public final void updateTextColors() {
        int colorForState = this.mTextColor.getColorForState(getDrawableState(), 0);
        if (colorForState != this.mCurTextColor) {
            this.mCurTextColor = colorForState;
            invalidate();
        }
    }

    public ActionLabel(Context context) {
        super(context, null, 0, 0);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        float f = displayMetrics.density;
        float f2 = displayMetrics.scaledDensity;
        this.mMinTextSize = 10.0f * f2;
        this.mMaxTextSize = f2 * 60.0f;
        TextPaint textPaint = new TextPaint(1);
        this.mTextPaint = textPaint;
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, R$styleable.ActionLabel, 0, 0);
        this.mText = obtainStyledAttributes.getText(4);
        this.mMinTextSize = obtainStyledAttributes.getDimension(10, this.mMinTextSize);
        this.mMaxTextSize = obtainStyledAttributes.getDimension(9, this.mMaxTextSize);
        this.mTextColor = obtainStyledAttributes.getColorStateList(2);
        this.mMaxLines = obtainStyledAttributes.getInt(5, 2);
        if (this.mTextColor != null) {
            updateTextColors();
        }
        textPaint.setTextSize(this.mMaxTextSize);
        setTypefaceFromAttrs(obtainStyledAttributes.getString(8), obtainStyledAttributes.getInt(0, -1), obtainStyledAttributes.getInt(1, -1));
        this.mGravity = obtainStyledAttributes.getInt(3, this.mGravity);
        this.mLineSpacingAdd = (float) obtainStyledAttributes.getDimensionPixelSize(6, (int) this.mLineSpacingAdd);
        this.mLineSpacingMult = obtainStyledAttributes.getFloat(7, this.mLineSpacingMult);
        obtainStyledAttributes.recycle();
        if (this.mText == null) {
            this.mText = "";
        }
    }
}
