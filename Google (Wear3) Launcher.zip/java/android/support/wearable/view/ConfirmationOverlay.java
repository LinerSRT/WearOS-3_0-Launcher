package android.support.wearable.view;

import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.support.wearable.activity.ConfirmationActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;

/* compiled from: PG */
public final class ConfirmationOverlay implements OnTouchListener {
    public final Runnable mHideRunnable = new PG();
    public boolean mIsShowing = false;
    public FinishedAnimationListener mListener;
    public final Handler mMainThreadHandler = new Handler(Looper.getMainLooper());
    public String mMessage;
    public Drawable mOverlayDrawable;
    public View mOverlayView;
    public int mType = 0;

    /* renamed from: android.support.wearable.view.ConfirmationOverlay$1 */
    final class PG implements Runnable {
        public final void run() {
            ConfirmationOverlay confirmationOverlay = ConfirmationOverlay.this;
            Animation loadAnimation = AnimationUtils.loadAnimation(confirmationOverlay.mOverlayView.getContext(), 17432577);
            loadAnimation.setAnimationListener(new C01272());
            confirmationOverlay.mOverlayView.startAnimation(loadAnimation);
        }
    }

    /* renamed from: android.support.wearable.view.ConfirmationOverlay$2 */
    final class C01272 implements AnimationListener {
        public final void onAnimationEnd(Animation animation) {
            ((ViewGroup) ConfirmationOverlay.this.mOverlayView.getParent()).removeView(ConfirmationOverlay.this.mOverlayView);
            ConfirmationOverlay confirmationOverlay = ConfirmationOverlay.this;
            confirmationOverlay.mIsShowing = false;
            FinishedAnimationListener finishedAnimationListener = confirmationOverlay.mListener;
            if (finishedAnimationListener != null) {
                ((ConfirmationActivity) finishedAnimationListener).finish();
            }
        }

        public final void onAnimationRepeat(Animation animation) {
        }

        public final void onAnimationStart(Animation animation) {
        }
    }

    /* compiled from: PG */
    public interface FinishedAnimationListener {
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return true;
    }
}
