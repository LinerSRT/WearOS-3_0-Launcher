package android.support.wearable.view;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;

/* compiled from: PG */
public class SimpleAnimatorListener implements AnimatorListener {
    public boolean mWasCanceled;

    public final void onAnimationCancel(Animator animator) {
        this.mWasCanceled = true;
    }

    public void onAnimationComplete$ar$ds() {
    }

    public void onAnimationEnd(Animator animator) {
        if (!this.mWasCanceled) {
            onAnimationComplete$ar$ds();
        }
    }

    public final void onAnimationRepeat(Animator animator) {
    }

    public final void onAnimationStart(Animator animator) {
        this.mWasCanceled = false;
    }
}
