package android.support.wearable.view;

@Deprecated
/* compiled from: PG */
public class CurvedChildLayoutManager extends WearableRecyclerView$ChildLayoutManager {
}
