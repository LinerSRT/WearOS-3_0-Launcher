package android.support.wearable.view;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.wearable.R$styleable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.RemoteViews.RemoteView;
import java.util.ArrayList;

@RemoteView
@Deprecated
/* compiled from: PG */
public class WearableFrameLayout extends ViewGroup {
    @ExportedProperty(category = "drawing")
    private Drawable mForeground;
    boolean mForegroundBoundsChanged;
    @ExportedProperty(category = "drawing")
    private int mForegroundGravity;
    @ExportedProperty(category = "drawing")
    private boolean mForegroundInPadding;
    @ExportedProperty(category = "padding")
    private int mForegroundPaddingBottom;
    @ExportedProperty(category = "padding")
    private int mForegroundPaddingLeft;
    @ExportedProperty(category = "padding")
    private int mForegroundPaddingRight;
    @ExportedProperty(category = "padding")
    private int mForegroundPaddingTop;
    private ColorStateList mForegroundTintList;
    private Mode mForegroundTintMode;
    private boolean mHasForegroundTint;
    private boolean mHasForegroundTintMode;
    private final ArrayList mMatchParentChildren;
    @ExportedProperty(category = "measurement")
    boolean mMeasureAllChildren;
    private final Rect mOverlayBounds;
    private boolean mRound;
    private final Rect mSelfBounds;

    /* compiled from: PG */
    public final class LayoutParams extends android.widget.FrameLayout.LayoutParams {
        public int bottomMarginRound;
        public int gravityRound;
        public final int heightRound;
        public int leftMarginRound;
        public int rightMarginRound;
        public int topMarginRound;
        public final int widthRound;

        public LayoutParams() {
            super(-1, -1);
            this.gravityRound = -1;
            this.widthRound = -1;
            this.heightRound = -1;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.gravityRound = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.WearableFrameLayout);
            this.gravityRound = obtainStyledAttributes.getInt(4, this.gravity);
            this.widthRound = obtainStyledAttributes.getLayoutDimension(11, this.width);
            this.heightRound = obtainStyledAttributes.getLayoutDimension(5, this.height);
            int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(9, -1);
            if (dimensionPixelSize >= 0) {
                this.bottomMarginRound = dimensionPixelSize;
                this.topMarginRound = dimensionPixelSize;
                this.rightMarginRound = dimensionPixelSize;
                this.leftMarginRound = dimensionPixelSize;
            } else {
                this.leftMarginRound = obtainStyledAttributes.getDimensionPixelSize(7, this.leftMargin);
                this.topMarginRound = obtainStyledAttributes.getDimensionPixelSize(10, this.topMargin);
                this.rightMarginRound = obtainStyledAttributes.getDimensionPixelSize(8, this.rightMargin);
                this.bottomMarginRound = obtainStyledAttributes.getDimensionPixelSize(6, this.bottomMargin);
            }
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.gravityRound = -1;
            this.widthRound = layoutParams.widthRound;
            this.heightRound = layoutParams.heightRound;
            this.gravityRound = layoutParams.gravityRound;
            this.leftMarginRound = layoutParams.leftMarginRound;
            this.topMarginRound = layoutParams.topMarginRound;
            this.rightMarginRound = layoutParams.rightMarginRound;
            this.bottomMarginRound = layoutParams.bottomMarginRound;
        }
    }

    public WearableFrameLayout(Context context) {
        super(context);
        this.mMeasureAllChildren = false;
        this.mForegroundTintList = null;
        this.mForegroundTintMode = null;
        this.mHasForegroundTint = false;
        this.mHasForegroundTintMode = false;
        this.mForegroundPaddingLeft = 0;
        this.mForegroundPaddingTop = 0;
        this.mForegroundPaddingRight = 0;
        this.mForegroundPaddingBottom = 0;
        this.mSelfBounds = new Rect();
        this.mOverlayBounds = new Rect();
        this.mForegroundGravity = 119;
        this.mForegroundInPadding = true;
        this.mForegroundBoundsChanged = false;
        this.mMatchParentChildren = new ArrayList(1);
        this.mRound = false;
    }

    private final void applyForegroundTint() {
        Drawable drawable = this.mForeground;
        if (drawable == null) {
            return;
        }
        if (this.mHasForegroundTint || this.mHasForegroundTintMode) {
            drawable = drawable.mutate();
            this.mForeground = drawable;
            if (this.mHasForegroundTint) {
                drawable.setTintList(this.mForegroundTintList);
            }
            if (this.mHasForegroundTintMode) {
                this.mForeground.setTintMode(this.mForegroundTintMode);
            }
            if (this.mForeground.isStateful()) {
                this.mForeground.setState(getDrawableState());
            }
        }
    }

    private final int getPaddingBottomWithForeground() {
        return this.mForegroundInPadding ? Math.max(getPaddingBottom(), this.mForegroundPaddingBottom) : getPaddingBottom() + this.mForegroundPaddingBottom;
    }

    private final int getPaddingTopWithForeground() {
        return this.mForegroundInPadding ? Math.max(getPaddingTop(), this.mForegroundPaddingTop) : getPaddingTop() + this.mForegroundPaddingTop;
    }

    private final int getParamsBottomMargin(LayoutParams layoutParams) {
        return this.mRound ? layoutParams.bottomMarginRound : layoutParams.bottomMargin;
    }

    private final int getParamsHeight(LayoutParams layoutParams) {
        return this.mRound ? layoutParams.heightRound : layoutParams.height;
    }

    private final int getParamsLeftMargin(LayoutParams layoutParams) {
        return this.mRound ? layoutParams.leftMarginRound : layoutParams.leftMargin;
    }

    private final int getParamsRightMargin(LayoutParams layoutParams) {
        return this.mRound ? layoutParams.rightMarginRound : layoutParams.rightMargin;
    }

    private final int getParamsTopMargin(LayoutParams layoutParams) {
        return this.mRound ? layoutParams.topMarginRound : layoutParams.topMargin;
    }

    private final int getParamsWidth(LayoutParams layoutParams) {
        return this.mRound ? layoutParams.widthRound : layoutParams.width;
    }

    protected final boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public final void draw(Canvas canvas) {
        super.draw(canvas);
        Drawable drawable = this.mForeground;
        if (drawable != null) {
            if (this.mForegroundBoundsChanged) {
                this.mForegroundBoundsChanged = false;
                Rect rect = this.mSelfBounds;
                Rect rect2 = this.mOverlayBounds;
                int right = getRight() - getLeft();
                int bottom = getBottom() - getTop();
                if (this.mForegroundInPadding) {
                    rect.set(0, 0, right, bottom);
                } else {
                    rect.set(getPaddingLeft(), getPaddingTop(), right - getPaddingRight(), bottom - getPaddingBottom());
                }
                Gravity.apply(this.mForegroundGravity, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), rect, rect2, getLayoutDirection());
                drawable.setBounds(rect2);
            }
            drawable.draw(canvas);
        }
    }

    public final void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.mForeground;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.mForeground;
        if (drawable != null && drawable.isStateful()) {
            this.mForeground.setState(getDrawableState());
        }
    }

    public final Drawable getForeground() {
        return this.mForeground;
    }

    public final int getForegroundGravity() {
        return this.mForegroundGravity;
    }

    public final ColorStateList getForegroundTintList() {
        return this.mForegroundTintList;
    }

    public final Mode getForegroundTintMode() {
        return this.mForegroundTintMode;
    }

    final int getPaddingLeftWithForeground() {
        return this.mForegroundInPadding ? Math.max(getPaddingLeft(), this.mForegroundPaddingLeft) : getPaddingLeft() + this.mForegroundPaddingLeft;
    }

    final int getPaddingRightWithForeground() {
        return this.mForegroundInPadding ? Math.max(getPaddingRight(), this.mForegroundPaddingRight) : getPaddingRight() + this.mForegroundPaddingRight;
    }

    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.mForeground;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    protected final void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, (((getPaddingLeft() + getPaddingRight()) + getParamsLeftMargin(layoutParams)) + getParamsRightMargin(layoutParams)) + i2, getParamsWidth(layoutParams)), ViewGroup.getChildMeasureSpec(i3, (((getPaddingTop() + getPaddingBottom()) + getParamsTopMargin(layoutParams)) + getParamsBottomMargin(layoutParams)) + i4, getParamsHeight(layoutParams)));
    }

    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        boolean z = this.mRound;
        boolean isRound = windowInsets.isRound();
        this.mRound = windowInsets.isRound();
        if (z != isRound) {
            requestLayout();
        }
        return super.onApplyWindowInsets(windowInsets);
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        requestApplyInsets();
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(WearableFrameLayout.class.getName());
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(WearableFrameLayout.class.getName());
    }

    protected final void onMeasure(int i, int i2) {
        int i3;
        int i4;
        ViewGroup viewGroup = this;
        int i5 = i;
        int i6 = i2;
        int childCount = getChildCount();
        Object obj = MeasureSpec.getMode(i) == 1073741824 ? MeasureSpec.getMode(i2) != 1073741824 ? 1 : null : 1;
        viewGroup.mMatchParentChildren.clear();
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (!viewGroup.mMeasureAllChildren) {
                if (childAt.getVisibility() != 8) {
                }
            }
            View view = childAt;
            i3 = i7;
            i4 = i8;
            measureChildWithMargins(childAt, i, 0, i2, 0);
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            i8 = Math.max(i4, (view.getMeasuredWidth() + getParamsLeftMargin(layoutParams)) + getParamsRightMargin(layoutParams));
            i9 = Math.max(i9, (view.getMeasuredHeight() + getParamsTopMargin(layoutParams)) + getParamsBottomMargin(layoutParams));
            i7 = combineMeasuredStates(i3, view.getMeasuredState());
            if (obj != null && (getParamsWidth(layoutParams) == -1 || getParamsHeight(layoutParams) == -1)) {
                viewGroup.mMatchParentChildren.add(view);
            }
        }
        i3 = i7;
        i4 = i8;
        int paddingLeftWithForeground = getPaddingLeftWithForeground();
        int paddingRightWithForeground = getPaddingRightWithForeground();
        int max = Math.max(i9 + (getPaddingTopWithForeground() + getPaddingBottomWithForeground()), getSuggestedMinimumHeight());
        paddingLeftWithForeground = Math.max(i4 + (paddingLeftWithForeground + paddingRightWithForeground), getSuggestedMinimumWidth());
        Drawable drawable = viewGroup.mForeground;
        if (drawable != null) {
            max = Math.max(max, drawable.getMinimumHeight());
            paddingLeftWithForeground = Math.max(paddingLeftWithForeground, drawable.getMinimumWidth());
        }
        setMeasuredDimension(resolveSizeAndState(paddingLeftWithForeground, i5, i3), resolveSizeAndState(max, i6, i3 << 16));
        paddingLeftWithForeground = viewGroup.mMatchParentChildren.size();
        if (paddingLeftWithForeground > 1) {
            for (paddingRightWithForeground = 0; paddingRightWithForeground < paddingLeftWithForeground; paddingRightWithForeground++) {
                int makeMeasureSpec;
                childAt = (View) viewGroup.mMatchParentChildren.get(paddingRightWithForeground);
                LayoutParams layoutParams2 = (LayoutParams) childAt.getLayoutParams();
                if (getParamsWidth(layoutParams2) == -1) {
                    i7 = MeasureSpec.makeMeasureSpec((((getMeasuredWidth() - getPaddingLeftWithForeground()) - getPaddingRightWithForeground()) - getParamsLeftMargin(layoutParams2)) - getParamsRightMargin(layoutParams2), 1073741824);
                } else {
                    i7 = ViewGroup.getChildMeasureSpec(i5, ((getPaddingLeftWithForeground() + getPaddingRightWithForeground()) + getParamsLeftMargin(layoutParams2)) + getParamsRightMargin(layoutParams2), getParamsWidth(layoutParams2));
                }
                if (getParamsHeight(layoutParams2) == -1) {
                    makeMeasureSpec = MeasureSpec.makeMeasureSpec((((getMeasuredHeight() - getPaddingTopWithForeground()) - getPaddingBottomWithForeground()) - getParamsTopMargin(layoutParams2)) - getParamsBottomMargin(layoutParams2), 1073741824);
                } else {
                    makeMeasureSpec = ViewGroup.getChildMeasureSpec(i6, ((getPaddingTopWithForeground() + getPaddingBottomWithForeground()) + getParamsTopMargin(layoutParams2)) + getParamsBottomMargin(layoutParams2), getParamsHeight(layoutParams2));
                }
                childAt.measure(i7, makeMeasureSpec);
            }
        }
    }

    protected final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.mForegroundBoundsChanged = true;
    }

    public final void setForeground(Drawable drawable) {
        Drawable drawable2 = this.mForeground;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
                unscheduleDrawable(this.mForeground);
            }
            this.mForeground = drawable;
            this.mForegroundPaddingLeft = 0;
            this.mForegroundPaddingTop = 0;
            this.mForegroundPaddingRight = 0;
            this.mForegroundPaddingBottom = 0;
            if (drawable != null) {
                setWillNotDraw(false);
                drawable.setCallback(this);
                if (drawable.isStateful()) {
                    drawable.setState(getDrawableState());
                }
                applyForegroundTint();
                if (this.mForegroundGravity == 119) {
                    Rect rect = new Rect();
                    if (drawable.getPadding(rect)) {
                        this.mForegroundPaddingLeft = rect.left;
                        this.mForegroundPaddingTop = rect.top;
                        this.mForegroundPaddingRight = rect.right;
                        this.mForegroundPaddingBottom = rect.bottom;
                    }
                }
            } else {
                setWillNotDraw(true);
            }
            requestLayout();
            invalidate();
        }
    }

    public final void setForegroundGravity(int i) {
        if (this.mForegroundGravity != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.mForegroundGravity = i;
            if (i != 119 || this.mForeground == null) {
                this.mForegroundPaddingLeft = 0;
                this.mForegroundPaddingTop = 0;
                this.mForegroundPaddingRight = 0;
                this.mForegroundPaddingBottom = 0;
            } else {
                Rect rect = new Rect();
                if (this.mForeground.getPadding(rect)) {
                    this.mForegroundPaddingLeft = rect.left;
                    this.mForegroundPaddingTop = rect.top;
                    this.mForegroundPaddingRight = rect.right;
                    this.mForegroundPaddingBottom = rect.bottom;
                }
            }
            requestLayout();
        }
    }

    public final void setForegroundTintList(ColorStateList colorStateList) {
        this.mForegroundTintList = colorStateList;
        this.mHasForegroundTint = true;
        applyForegroundTint();
    }

    public final void setForegroundTintMode(Mode mode) {
        this.mForegroundTintMode = mode;
        this.mHasForegroundTintMode = true;
        applyForegroundTint();
    }

    public final void setVisibility(int i) {
        super.setVisibility(i);
        Drawable drawable = this.mForeground;
        if (drawable != null) {
            boolean z;
            if (i == 0) {
                z = true;
            } else {
                z = false;
            }
            drawable.setVisible(z, false);
        }
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    protected final boolean verifyDrawable(Drawable drawable) {
        if (!super.verifyDrawable(drawable)) {
            if (drawable != this.mForeground) {
                return false;
            }
        }
        return true;
    }

    protected final /* bridge */ /* synthetic */ android.view.ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams();
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeftWithForeground = getPaddingLeftWithForeground();
        i3 = (i3 - i) - getPaddingRightWithForeground();
        i = getPaddingTopWithForeground();
        i4 = (i4 - i2) - getPaddingBottomWithForeground();
        this.mForegroundBoundsChanged = true;
        for (i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i5 = this.mRound ? layoutParams.gravityRound : layoutParams.gravity;
                if (i5 == -1) {
                    i5 = 8388659;
                }
                int i6 = i5 & 112;
                switch (Gravity.getAbsoluteGravity(i5, getLayoutDirection()) & 7) {
                    case 1:
                        i5 = (((((i3 - paddingLeftWithForeground) - measuredWidth) / 2) + paddingLeftWithForeground) + getParamsLeftMargin(layoutParams)) - getParamsRightMargin(layoutParams);
                        break;
                    case 5:
                        i5 = (i3 - measuredWidth) - getParamsRightMargin(layoutParams);
                        break;
                    default:
                        i5 = getParamsLeftMargin(layoutParams) + paddingLeftWithForeground;
                        break;
                }
                switch (i6) {
                    case 16:
                        i6 = (((((i4 - i) - measuredHeight) / 2) + i) + getParamsTopMargin(layoutParams)) - getParamsBottomMargin(layoutParams);
                        break;
                    case 48:
                        i6 = i + getParamsTopMargin(layoutParams);
                        break;
                    case 80:
                        i6 = (i4 - measuredHeight) - getParamsBottomMargin(layoutParams);
                        break;
                    default:
                        i6 = i + getParamsTopMargin(layoutParams);
                        break;
                }
                childAt.layout(i5, i6, measuredWidth + i5, measuredHeight + i6);
            }
        }
    }

    protected final android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams((LayoutParams) layoutParams);
    }

    public WearableFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public WearableFrameLayout(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public WearableFrameLayout(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.mMeasureAllChildren = false;
        this.mForegroundTintList = null;
        this.mForegroundTintMode = null;
        this.mHasForegroundTint = false;
        this.mHasForegroundTintMode = false;
        this.mForegroundPaddingLeft = 0;
        this.mForegroundPaddingTop = 0;
        this.mForegroundPaddingRight = 0;
        this.mForegroundPaddingBottom = 0;
        this.mSelfBounds = new Rect();
        this.mOverlayBounds = new Rect();
        this.mForegroundGravity = 119;
        this.mForegroundInPadding = true;
        this.mForegroundBoundsChanged = false;
        this.mMatchParentChildren = new ArrayList(1);
        this.mRound = false;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.WearableFrameLayout, i, i2);
        this.mForegroundGravity = obtainStyledAttributes.getInt(2, this.mForegroundGravity);
        Drawable drawable = obtainStyledAttributes.getDrawable(0);
        if (drawable != null) {
            setForeground(drawable);
        }
        if (obtainStyledAttributes.getBoolean(1, false)) {
            this.mMeasureAllChildren = true;
        }
        if (obtainStyledAttributes.hasValue(3)) {
            this.mForegroundTintList = obtainStyledAttributes.getColorStateList(3);
            this.mHasForegroundTint = true;
        }
        obtainStyledAttributes.recycle();
        applyForegroundTint();
    }
}
