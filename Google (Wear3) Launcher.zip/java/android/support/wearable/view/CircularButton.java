package android.support.wearable.view;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.support.p002v7.widget.LinearLayoutManager;
import android.support.wearable.R$styleable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;

@Deprecated
/* compiled from: PG */
public class CircularButton extends View {
    private static final double SQRT_2 = Math.sqrt(2.0d);
    public ColorStateList mColors;
    public int mDiameter;
    public Drawable mImage;
    private final Interpolator mInterpolator;
    private RippleDrawable mRippleDrawable;
    public int mScaleMode;
    public final ShapeDrawable mShapeDrawable;

    /* compiled from: PG */
    final class CircleOutlineProvider extends ViewOutlineProvider {
        public final void getOutline(View view, Outline outline) {
            int i = CircularButton.this.mDiameter;
            outline.setOval(0, 0, i, i);
        }
    }

    public CircularButton(Context context) {
        this(context, null);
    }

    private static boolean hasIntrinsicSize(Drawable drawable) {
        return drawable != null && drawable.getIntrinsicHeight() > 0 && drawable.getIntrinsicWidth() > 0;
    }

    private final void setupAnimator$ar$ds(Animator animator) {
        animator.setInterpolator(this.mInterpolator);
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        ColorStateList colorStateList = this.mColors;
        if (colorStateList != null && colorStateList.isStateful()) {
            this.mShapeDrawable.getPaint().setColor(this.mColors.getColorForState(getDrawableState(), this.mColors.getDefaultColor()));
            this.mShapeDrawable.invalidateSelf();
        }
    }

    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Drawable drawable = this.mImage;
        if (drawable != null) {
            drawable.draw(canvas);
        }
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        i3 -= i;
        i4 -= i2;
        Drawable drawable = this.mImage;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            i = this.mImage.getIntrinsicHeight();
            if (this.mScaleMode != 0) {
                if (hasIntrinsicSize(this.mImage)) {
                    i2 = (int) (((float) (i3 - intrinsicWidth)) / 2.0f);
                    i3 = (int) (((float) (i4 - i)) / 2.0f);
                    this.mImage.setBounds(i2, i3, intrinsicWidth + i2, i + i3);
                    return;
                }
            }
            double d = (double) (this.mDiameter / 2);
            double d2 = SQRT_2;
            Double.isNaN(d);
            i2 = (int) Math.floor(d * d2);
            i3 = (this.mDiameter - i2) / 2;
            if (hasIntrinsicSize(this.mImage)) {
                if (intrinsicWidth == i) {
                    intrinsicWidth = i2;
                    i = i3;
                } else {
                    float f = ((float) intrinsicWidth) / ((float) i);
                    if (intrinsicWidth > i) {
                        intrinsicWidth = (int) (((float) i2) / f);
                        i = (int) (((float) (i2 - intrinsicWidth)) / 2.0f);
                    } else {
                        intrinsicWidth = (int) (((float) i2) * f);
                        int i5 = i2;
                        i2 = intrinsicWidth;
                        intrinsicWidth = i5;
                        int i6 = i3;
                        i3 = (int) (((float) (i2 - intrinsicWidth)) / 2.0f);
                        i = i6;
                    }
                }
                this.mImage.setBounds(i3, i, i2 + i3, intrinsicWidth + i);
                return;
            }
            i2 += i3;
            this.mImage.setBounds(i3, i3, i2, i2);
        }
    }

    protected final void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        i = MeasureSpec.getSize(i);
        int mode2 = MeasureSpec.getMode(i2);
        i2 = MeasureSpec.getSize(i2);
        if (mode == 1073741824) {
            if (mode2 == 1073741824) {
                i = Math.min(i, i2);
                this.mDiameter = i;
                setMeasuredDimension(i, i);
            }
            mode = 1073741824;
        }
        if (mode == 1073741824) {
            this.mDiameter = i;
        } else if (mode2 == 1073741824) {
            this.mDiameter = i2;
            i = i2;
        } else {
            int max;
            if (hasIntrinsicSize(this.mImage)) {
                max = Math.max(this.mImage.getIntrinsicHeight(), this.mImage.getIntrinsicWidth());
            } else {
                max = (int) Math.ceil((double) TypedValue.applyDimension(1, 48.0f, getResources().getDisplayMetrics()));
            }
            if (mode != LinearLayoutManager.INVALID_OFFSET) {
                if (mode2 != LinearLayoutManager.INVALID_OFFSET) {
                    this.mDiameter = max;
                    i = max;
                }
            }
            if (mode != LinearLayoutManager.INVALID_OFFSET) {
                i = i2;
            } else if (mode2 == LinearLayoutManager.INVALID_OFFSET) {
                i = Math.min(i, i2);
            }
            double d = (double) max;
            double d2 = SQRT_2;
            Double.isNaN(d);
            i2 = (int) Math.floor(d / d2);
            i = Math.min(i, i2 + i2);
            this.mDiameter = i;
        }
        setMeasuredDimension(i, i);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean onTouchEvent = super.onTouchEvent(motionEvent);
        if (onTouchEvent) {
            switch (motionEvent.getAction() & 255) {
                case 0:
                    getBackground().setHotspot(motionEvent.getX(), motionEvent.getY());
                    return true;
                default:
                    break;
            }
        }
        return onTouchEvent;
    }

    public final void setBackgroundDrawable(Drawable drawable) {
    }

    public final void setColor(int i) {
        this.mColors = ColorStateList.valueOf(i);
        this.mShapeDrawable.getPaint().setColor(this.mColors.getDefaultColor());
    }

    public final void setPressedTranslationZ(float f) {
        StateListAnimator stateListAnimator = new StateListAnimator();
        int[] iArr = PRESSED_ENABLED_STATE_SET;
        String str = "translationZ";
        Animator ofFloat = ObjectAnimator.ofFloat(this, str, new float[]{f});
        setupAnimator$ar$ds(ofFloat);
        stateListAnimator.addState(iArr, ofFloat);
        iArr = ENABLED_FOCUSED_STATE_SET;
        Animator ofFloat2 = ObjectAnimator.ofFloat(this, str, new float[]{f});
        setupAnimator$ar$ds(ofFloat2);
        stateListAnimator.addState(iArr, ofFloat2);
        int[] iArr2 = EMPTY_STATE_SET;
        Animator ofFloat3 = ObjectAnimator.ofFloat(this, str, new float[]{getElevation()});
        setupAnimator$ar$ds(ofFloat3);
        stateListAnimator.addState(iArr2, ofFloat3);
        setStateListAnimator(stateListAnimator);
    }

    public final void setRippleColor(int i) {
        RippleDrawable rippleDrawable = this.mRippleDrawable;
        if (rippleDrawable != null) {
            rippleDrawable.setColor(ColorStateList.valueOf(i));
        } else if (i == -1 || isInEditMode()) {
            this.mRippleDrawable = null;
            super.setBackgroundDrawable(this.mShapeDrawable);
        } else {
            ColorStateList valueOf = ColorStateList.valueOf(i);
            Drawable drawable = this.mShapeDrawable;
            Drawable rippleDrawable2 = new RippleDrawable(valueOf, drawable, drawable);
            this.mRippleDrawable = rippleDrawable2;
            super.setBackgroundDrawable(rippleDrawable2);
        }
    }

    protected final boolean verifyDrawable(Drawable drawable) {
        if (this.mImage != drawable) {
            if (!super.verifyDrawable(drawable)) {
                return false;
            }
        }
        return true;
    }

    public CircularButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CircularButton(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public CircularButton(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        Drawable shapeDrawable = new ShapeDrawable(new OvalShape());
        this.mShapeDrawable = shapeDrawable;
        shapeDrawable.getPaint().setColor(-3355444);
        super.setBackgroundDrawable(shapeDrawable);
        setOutlineProvider(new CircleOutlineProvider());
        this.mInterpolator = new AccelerateInterpolator(2.0f);
        this.mScaleMode = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.CircularButton, i, i2);
        boolean z = true;
        for (i = 0; i < obtainStyledAttributes.getIndexCount(); i++) {
            int index = obtainStyledAttributes.getIndex(i);
            if (index == 2) {
                this.mColors = obtainStyledAttributes.getColorStateList(2);
                this.mShapeDrawable.getPaint().setColor(this.mColors.getDefaultColor());
            } else if (index == 1) {
                this.mImage = obtainStyledAttributes.getDrawable(1);
            } else if (index == 5) {
                setRippleColor(obtainStyledAttributes.getColor(5, -1));
            } else if (index == 7) {
                setPressedTranslationZ(obtainStyledAttributes.getDimension(7, 0.0f));
            } else if (index == 6) {
                this.mScaleMode = obtainStyledAttributes.getInt(6, this.mScaleMode);
            } else if (index == 0) {
                z = obtainStyledAttributes.getBoolean(0, z);
            }
        }
        obtainStyledAttributes.recycle();
        setClickable(z);
    }
}
