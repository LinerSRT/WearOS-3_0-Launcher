package android.support.wearable.view;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.PointF;
import android.os.Handler;
import android.support.p002v7.widget.LinearLayoutManager;
import android.support.p002v7.widget.LinearSmoothScroller;
import android.support.p002v7.widget.RecyclerView;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.AdapterDataObserver;
import android.support.p002v7.widget.RecyclerView.LayoutParams;
import android.support.p002v7.widget.RecyclerView.Recycler;
import android.support.p002v7.widget.RecyclerView.State;
import android.support.wearable.input.RotaryEncoder;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Property;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.Scroller;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

@Deprecated
/* compiled from: PG */
public class WearableListView extends RecyclerView {
    public static final /* synthetic */ int WearableListView$ar$NoOp = 0;
    public boolean mCanClick;
    private boolean mGestureDirectionLocked;
    private boolean mGestureNavigationEnabled;
    public int mLastScrollChange;
    private final int[] mLocation;
    private final int mMaxFlingVelocity;
    private final int mMinFlingVelocity;
    public final Runnable mNotifyChildrenPostLayoutRunnable;
    private final OnChangeObserver mObserver;
    private final List mOnCentralPositionChangedListeners;
    public final List mOnScrollListeners;
    private final Runnable mPressedRunnable;
    public View mPressedView;
    private int mPreviousBaseline;
    private int mPreviousCentral;
    private final Runnable mReleasedRunnable;
    private Animator mScrollAnimator;
    private Scroller mScroller;
    private final SetScrollVerticallyProperty mSetScrollVerticallyProperty;
    private int mTapPositionX;
    private int mTapPositionY;
    private final float[] mTapRegions;
    private final int mTouchSlop;

    /* renamed from: android.support.wearable.view.WearableListView$1 */
    final class PG implements Runnable {
        public final void run() {
            if (WearableListView.this.getChildCount() > 0) {
                ViewGroup viewGroup = WearableListView.this;
                viewGroup.mPressedView = viewGroup.getChildAt(viewGroup.findCenterViewIndex());
                WearableListView.this.mPressedView.setPressed(true);
                return;
            }
            Log.w("WearableListView", "mPressedRunnable: the children were removed, skipping.");
        }
    }

    /* renamed from: android.support.wearable.view.WearableListView$2 */
    final class C01282 implements Runnable {
        public final void run() {
            WearableListView.this.releasePressedItem();
        }
    }

    /* renamed from: android.support.wearable.view.WearableListView$3 */
    final class C01293 implements Runnable {
        public final void run() {
            WearableListView.this.notifyChildrenAboutProximity$ar$ds();
        }
    }

    /* renamed from: android.support.wearable.view.WearableListView$4 */
    final class C01304 extends android.support.p002v7.widget.RecyclerView.OnScrollListener {
        public final void onScrollStateChanged(RecyclerView recyclerView, int i) {
            if (i == 0 && WearableListView.this.getChildCount() > 0) {
                WearableListView.this.handleTouchUp(null, 0);
            }
            for (OnScrollListener onScrollStateChanged$ar$ds : WearableListView.this.mOnScrollListeners) {
                onScrollStateChanged$ar$ds.onScrollStateChanged$ar$ds();
            }
        }

        public final void onScrolled(RecyclerView recyclerView, int i, int i2) {
            WearableListView wearableListView = WearableListView.this;
            for (OnScrollListener onScroll$ar$ds : wearableListView.mOnScrollListeners) {
                onScroll$ar$ds.onScroll$ar$ds();
            }
            wearableListView.notifyChildrenAboutProximity$ar$ds();
        }
    }

    /* renamed from: android.support.wearable.view.WearableListView$5 */
    final class C01315 extends SimpleAnimatorListener {
        public final void onAnimationEnd(Animator animator) {
            if (!this.mWasCanceled) {
                WearableListView.this.mCanClick = true;
            }
        }
    }

    /* compiled from: PG */
    final class LayoutManager extends android.support.p002v7.widget.RecyclerView.LayoutManager {
        private int mAbsoluteScroll;
        private android.support.p002v7.widget.RecyclerView.SmoothScroller mDefaultSmoothScroller;
        public int mFirstPosition;
        private boolean mPushFirstHigher;
        private boolean mUseOldViewTop = true;

        private final void setAbsoluteScroll(int i) {
            this.mAbsoluteScroll = i;
            for (OnScrollListener onAbsoluteScrollChange$ar$ds : WearableListView.this.mOnScrollListeners) {
                onAbsoluteScrollChange$ar$ds.onAbsoluteScrollChange$ar$ds();
            }
        }

        public final boolean canScrollVertically() {
            getItemCount();
            return true;
        }

        public final int findCenterViewIndex() {
            int childCount = getChildCount();
            int centerYPos = WearableListView.getCenterYPos(WearableListView.this);
            int i = Integer.MAX_VALUE;
            int i2 = 0;
            int i3 = -1;
            while (i2 < childCount) {
                int abs = Math.abs(centerYPos - (WearableListView.this.getTop() + WearableListView.getCenterYPos(WearableListView.this.mLayout.getChildAt(i2))));
                int i4 = abs < i ? abs : i;
                if (abs < i) {
                    i3 = i2;
                }
                i2++;
                i = i4;
            }
            if (i3 != -1) {
                return i3;
            }
            throw new IllegalStateException("Can't find central view.");
        }

        public final LayoutParams generateDefaultLayoutParams() {
            return new LayoutParams(-1, -2);
        }

        public final void onAdapterChanged(Adapter adapter, Adapter adapter2) {
            removeAllViews();
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void onLayoutChildren(android.support.p002v7.widget.RecyclerView.Recycler r10, android.support.p002v7.widget.RecyclerView.State r11) {
            /*
            r9 = this;
            r0 = r9.getHeight();
            r1 = r9.getPaddingBottom();
            r0 = r0 - r1;
            r1 = android.support.wearable.view.WearableListView.this;
            r1 = r1.getCentralViewTop();
            r2 = r9.mUseOldViewTop;
            r3 = 0;
            if (r2 == 0) goto L_0x009f;
        L_0x0014:
            r2 = r9.getChildCount();
            if (r2 <= 0) goto L_0x009f;
        L_0x001a:
            r1 = r9.findCenterViewIndex();
            r2 = r9.getChildAt(r1);
            r2 = r9.getPosition(r2);
            r4 = -1;
            if (r2 != r4) goto L_0x0058;
        L_0x0029:
            r5 = r9.getChildCount();
            r2 = -1;
            r6 = 0;
        L_0x002f:
            r7 = r1 + r6;
            if (r7 < r5) goto L_0x0037;
        L_0x0033:
            r8 = r1 - r6;
            if (r8 < 0) goto L_0x0058;
        L_0x0037:
            r8 = r9.getChildAt(r7);
            if (r8 == 0) goto L_0x0045;
        L_0x003d:
            r2 = r9.getPosition(r8);
            if (r2 == r4) goto L_0x0045;
        L_0x0043:
            r1 = r7;
            goto L_0x0059;
        L_0x0045:
            r7 = r1 - r6;
            r8 = r9.getChildAt(r7);
            if (r8 == 0) goto L_0x0055;
        L_0x004d:
            r2 = r9.getPosition(r8);
            if (r2 == r4) goto L_0x0055;
        L_0x0053:
            r1 = r7;
            goto L_0x0059;
        L_0x0055:
            r6 = r6 + 1;
            goto L_0x002f;
        L_0x0059:
            if (r2 != r4) goto L_0x0072;
        L_0x005b:
            r1 = r9.getChildAt(r3);
            r1 = r1.getTop();
            r2 = r11.getItemCount();
        L_0x0067:
            r4 = r9.mFirstPosition;
            if (r4 < r2) goto L_0x00b0;
        L_0x006b:
            if (r4 <= 0) goto L_0x00b0;
        L_0x006d:
            r4 = r4 + -1;
            r9.mFirstPosition = r4;
            goto L_0x0067;
        L_0x0072:
            r1 = r9.getChildAt(r1);
            r1 = r1.getTop();
        L_0x007a:
            r4 = r9.getPaddingTop();
            if (r1 <= r4) goto L_0x008c;
        L_0x0080:
            if (r2 <= 0) goto L_0x008c;
        L_0x0082:
            r2 = r2 + -1;
            r4 = android.support.wearable.view.WearableListView.this;
            r4 = r4.getItemHeight();
            r1 = r1 - r4;
            goto L_0x007a;
        L_0x008c:
            if (r2 != 0) goto L_0x009c;
        L_0x008e:
            r4 = android.support.wearable.view.WearableListView.this;
            r4 = r4.getCentralViewTop();
            if (r1 <= r4) goto L_0x009c;
        L_0x0096:
            r1 = android.support.wearable.view.WearableListView.this;
            r1 = r1.getCentralViewTop();
        L_0x009c:
            r9.mFirstPosition = r2;
            goto L_0x00b0;
        L_0x009f:
            r2 = r9.mPushFirstHigher;
            if (r2 == 0) goto L_0x00b0;
        L_0x00a3:
            r1 = android.support.wearable.view.WearableListView.this;
            r1 = r1.getCentralViewTop();
            r2 = android.support.wearable.view.WearableListView.this;
            r2 = r2.getItemHeight();
            r1 = r1 - r2;
        L_0x00b0:
            r9.detachAndScrapAttachedViews(r10);
            r2 = r9.getPaddingLeft();
            r4 = r9.getWidth();
            r5 = r9.getPaddingRight();
            r4 = r4 - r5;
            r11 = r11.getItemCount();
            r5 = 0;
        L_0x00c5:
            r6 = r9.mFirstPosition;
            r6 = r6 + r5;
            if (r6 >= r11) goto L_0x00e5;
        L_0x00ca:
            if (r1 < r0) goto L_0x00cd;
        L_0x00cc:
            goto L_0x00e5;
        L_0x00cd:
            r6 = r10.getViewForPosition(r6);
            r9.addView(r6, r5);
            r9.measureThirdView(r6);
            r7 = android.support.wearable.view.WearableListView.this;
            r7 = r7.getItemHeight();
            r7 = r7 + r1;
            r6.layout(r2, r1, r4, r7);
            r5 = r5 + 1;
            r1 = r7;
            goto L_0x00c5;
        L_0x00e5:
            r10 = r9.getChildCount();
            if (r10 <= 0) goto L_0x00f2;
        L_0x00eb:
            r10 = android.support.wearable.view.WearableListView.this;
            r11 = r10.mNotifyChildrenPostLayoutRunnable;
            r10.post(r11);
        L_0x00f2:
            r10 = r9.getChildCount();
            if (r10 != 0) goto L_0x00fc;
        L_0x00f8:
            r9.setAbsoluteScroll(r3);
            goto L_0x011f;
        L_0x00fc:
            r10 = r9.findCenterViewIndex();
            r10 = r9.getChildAt(r10);
            r11 = r10.getTop();
            r0 = android.support.wearable.view.WearableListView.this;
            r0 = r0.getCentralViewTop();
            r11 = r11 - r0;
            r10 = r9.getPosition(r10);
            r0 = android.support.wearable.view.WearableListView.this;
            r0 = r0.getItemHeight();
            r10 = r10 * r0;
            r11 = r11 + r10;
            r9.setAbsoluteScroll(r11);
        L_0x011f:
            r10 = 1;
            r9.mUseOldViewTop = r10;
            r9.mPushFirstHigher = r3;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.wearable.view.WearableListView.LayoutManager.onLayoutChildren(android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State):void");
        }

        public final void scrollToPosition(int i) {
            this.mUseOldViewTop = false;
            if (i > 0) {
                this.mFirstPosition = i - 1;
                this.mPushFirstHigher = true;
            } else {
                this.mFirstPosition = i;
                this.mPushFirstHigher = false;
            }
            requestLayout();
        }

        public final int scrollVerticallyBy(int i, Recycler recycler, State state) {
            if (getChildCount() == 0) {
                return 0;
            }
            int i2;
            int min;
            int top;
            int i3;
            int paddingLeft = getPaddingLeft();
            int width = getWidth() - getPaddingRight();
            if (i < 0) {
                i2 = 0;
                while (i2 > i) {
                    View childAt = getChildAt(0);
                    if (this.mFirstPosition <= 0) {
                        this.mPushFirstHigher = false;
                        i = Math.min((-i) + i2, WearableListView.this.getTopViewMaxTop() - childAt.getTop());
                        i2 -= i;
                        offsetChildrenVertical(i);
                        break;
                    }
                    min = Math.min(i2 - i, Math.max(-childAt.getTop(), 0));
                    i2 -= min;
                    offsetChildrenVertical(min);
                    min = this.mFirstPosition;
                    if (min > 0) {
                        if (i2 <= i) {
                            break;
                        }
                        min--;
                        this.mFirstPosition = min;
                        View viewForPosition = recycler.getViewForPosition(min);
                        addView(viewForPosition, 0);
                        measureThirdView(viewForPosition);
                        top = childAt.getTop();
                        viewForPosition.layout(paddingLeft, top - WearableListView.this.getItemHeight(), width, top);
                    } else {
                        break;
                    }
                }
            } else if (i > 0) {
                top = getHeight();
                min = 0;
                while (min < i) {
                    View childAt2 = getChildAt(getChildCount() - 1);
                    if (state.getItemCount() <= this.mFirstPosition + getChildCount()) {
                        i = Math.max((-i) + min, (getHeight() / 2) - childAt2.getBottom());
                        i2 = min - i;
                        offsetChildrenVertical(i);
                        break;
                    }
                    i3 = -Math.min(i - min, Math.max(childAt2.getBottom() - top, 0));
                    min -= i3;
                    offsetChildrenVertical(i3);
                    if (min >= i) {
                        i2 = min;
                        break;
                    }
                    childAt2 = recycler.getViewForPosition(this.mFirstPosition + getChildCount());
                    int bottom = getChildAt(getChildCount() - 1).getBottom();
                    addView(childAt2);
                    measureThirdView(childAt2);
                    childAt2.layout(paddingLeft, bottom, width, WearableListView.this.getItemHeight() + bottom);
                }
                i2 = min;
            } else {
                i2 = 0;
            }
            i = getChildCount();
            paddingLeft = getWidth();
            width = getHeight();
            min = 0;
            i3 = 0;
            Object obj = null;
            for (top = 0; top < i; top++) {
                View childAt3 = getChildAt(top);
                if (!childAt3.hasFocus()) {
                    if (childAt3.getRight() < 0 || childAt3.getLeft() > paddingLeft || childAt3.getBottom() < 0 || childAt3.getTop() > width) {
                    }
                }
                if (1 != obj) {
                    min = top;
                }
                i3 = top;
                obj = 1;
            }
            for (i--; i > i3; i--) {
                removeAndRecycleViewAt(i, recycler);
            }
            for (i = min - 1; i >= 0; i--) {
                removeAndRecycleViewAt(i, recycler);
            }
            if (getChildCount() == 0) {
                this.mFirstPosition = 0;
            } else if (min > 0) {
                this.mPushFirstHigher = true;
                this.mFirstPosition += min;
            }
            setAbsoluteScroll(this.mAbsoluteScroll + i2);
            return i2;
        }

        private final void measureThirdView(View view) {
            int height = getHeight();
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            int width = getWidth();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int i = layoutParams.leftMargin;
            width = android.support.p002v7.widget.RecyclerView.LayoutManager.getChildMeasureSpec(width, ((paddingLeft + paddingRight) + i) + layoutParams.rightMargin, layoutParams.width, false);
            paddingLeft = getHeight();
            paddingRight = getPaddingTop();
            i = getPaddingBottom();
            int i2 = layoutParams.topMargin;
            int i3 = layoutParams.bottomMargin;
            canScrollVertically();
            view.measure(width, android.support.p002v7.widget.RecyclerView.LayoutManager.getChildMeasureSpec(paddingLeft, ((paddingRight + i) + i2) + i3, (height / 3) + 1, true));
        }

        public final void smoothScrollToPosition(RecyclerView recyclerView, State state, int i) {
            if (this.mDefaultSmoothScroller == null) {
                this.mDefaultSmoothScroller = new SmoothScroller(recyclerView.getContext(), this);
            }
            android.support.p002v7.widget.RecyclerView.SmoothScroller smoothScroller = this.mDefaultSmoothScroller;
            smoothScroller.mTargetPosition = i;
            startSmoothScroll(smoothScroller);
        }
    }

    /* compiled from: PG */
    public interface OnCenterProximityListener {
    }

    /* compiled from: PG */
    public interface OnCentralPositionChangedListener {
        void onCentralPositionChanged$ar$ds();
    }

    /* compiled from: PG */
    final class OnChangeObserver extends AdapterDataObserver implements OnLayoutChangeListener {
        public Adapter mAdapter;
        private boolean mIsListeningToLayoutChange;
        public boolean mIsObservingAdapter;
        private WeakReference mListView;

        public final void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            WearableListView wearableListView = (WearableListView) this.mListView.get();
            if (wearableListView != null) {
                stopOnLayoutChangeListening();
                if (wearableListView.getChildCount() > 0) {
                    wearableListView.animateToCenter();
                }
            }
        }

        public final void setListView(WearableListView wearableListView) {
            stopOnLayoutChangeListening();
            this.mListView = new WeakReference(wearableListView);
        }

        public final void stopOnLayoutChangeListening() {
            if (this.mIsListeningToLayoutChange) {
                WearableListView wearableListView;
                WeakReference weakReference = this.mListView;
                if (weakReference == null) {
                    wearableListView = null;
                } else {
                    wearableListView = (WearableListView) weakReference.get();
                }
                if (wearableListView != null) {
                    wearableListView.removeOnLayoutChangeListener(this);
                }
                this.mIsListeningToLayoutChange = false;
            }
        }

        public final void onChanged() {
            WearableListView wearableListView;
            WeakReference weakReference = this.mListView;
            if (weakReference == null) {
                wearableListView = null;
            } else {
                wearableListView = (WearableListView) weakReference.get();
            }
            if (!this.mIsListeningToLayoutChange && wearableListView != null) {
                wearableListView.addOnLayoutChangeListener(this);
                this.mIsListeningToLayoutChange = true;
            }
        }
    }

    /* compiled from: PG */
    public interface OnScrollListener {
        @Deprecated
        void onAbsoluteScrollChange$ar$ds();

        void onCentralPositionChanged$ar$ds$c28c3bea_0();

        void onScroll$ar$ds();

        void onScrollStateChanged$ar$ds();
    }

    /* compiled from: PG */
    final class SetScrollVerticallyProperty extends Property {
        public SetScrollVerticallyProperty() {
            super(Integer.class, "scrollVertically");
        }

        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            WearableListView wearableListView = (WearableListView) obj;
            int i = WearableListView.WearableListView$ar$NoOp;
            return Integer.valueOf(wearableListView.mLastScrollChange);
        }

        public final /* bridge */ /* synthetic */ void set(Object obj, Object obj2) {
            WearableListView wearableListView = (WearableListView) obj;
            int intValue = ((Integer) obj2).intValue();
            int i = WearableListView.WearableListView$ar$NoOp;
            wearableListView.scrollBy(0, intValue - wearableListView.mLastScrollChange);
            wearableListView.mLastScrollChange = intValue;
        }
    }

    /* compiled from: PG */
    final class SmoothScroller extends LinearSmoothScroller {
        private final LayoutManager mLayoutManager;

        public SmoothScroller(Context context, LayoutManager layoutManager) {
            super(context);
            this.mLayoutManager = layoutManager;
        }

        public final int calculateDtToFit(int i, int i2, int i3, int i4, int i5) {
            return ((i3 + i4) / 2) - ((i + i2) / 2);
        }

        protected final float calculateSpeedPerPixel(DisplayMetrics displayMetrics) {
            return 100.0f / ((float) displayMetrics.densityDpi);
        }

        public final PointF computeScrollVectorForPosition(int i) {
            if (i < this.mLayoutManager.mFirstPosition) {
                return new PointF(0.0f, -1.0f);
            }
            return new PointF(0.0f, 1.0f);
        }
    }

    /* compiled from: PG */
    public final class ViewHolder extends android.support.p002v7.widget.RecyclerView.ViewHolder {
    }

    public WearableListView(Context context) {
        this(context, null);
    }

    private final void computeTapRegions(float[] fArr) {
        int[] iArr = this.mLocation;
        iArr[1] = 0;
        iArr[0] = 0;
        getLocationOnScreen(iArr);
        float f = (float) this.mLocation[1];
        float height = (float) getHeight();
        fArr[0] = (0.33f * height) + f;
        fArr[1] = f + (height * 0.66999996f);
    }

    private static int getAdjustedHeight(View view) {
        return (view.getHeight() - view.getPaddingBottom()) - view.getPaddingTop();
    }

    public static int getCenterYPos(View view) {
        return (view.getTop() + view.getPaddingTop()) + (getAdjustedHeight(view) / 2);
    }

    public final void animateToCenter() {
        if (getChildCount() != 0) {
            int centralViewTop = getCentralViewTop() - getChildAt(findCenterViewIndex()).getTop();
            AnimatorListener c01315 = new C01315();
            Animator animator = this.mScrollAnimator;
            if (animator != null) {
                animator.cancel();
            }
            this.mLastScrollChange = 0;
            Animator ofInt = ObjectAnimator.ofInt(this, this.mSetScrollVerticallyProperty, new int[]{0, -centralViewTop});
            this.mScrollAnimator = ofInt;
            ofInt.setDuration(150);
            this.mScrollAnimator.addListener(c01315);
            this.mScrollAnimator.start();
        }
    }

    public final int findCenterViewIndex() {
        int childCount = getChildCount();
        int centerYPos = getCenterYPos(this);
        int i = Integer.MAX_VALUE;
        int i2 = 0;
        int i3 = -1;
        while (i2 < childCount) {
            int abs = Math.abs(centerYPos - (getTop() + getCenterYPos(getChildAt(i2))));
            int i4 = abs < i ? abs : i;
            if (abs < i) {
                i3 = i2;
            }
            i2++;
            i = i4;
        }
        if (i3 != -1) {
            return i3;
        }
        throw new IllegalStateException("Can't find central view.");
    }

    public final boolean fling(int i, int i2) {
        if (getChildCount() == 0) {
            return false;
        }
        int childAdapterPosition = getChildAdapterPosition(getChildAt(findCenterViewIndex()));
        if (childAdapterPosition == 0) {
            if (i2 >= 0) {
                childAdapterPosition = 0;
            }
            return super.fling(i, i2);
        }
        if (childAdapterPosition == this.mAdapter.getItemCount() - 1) {
            if (i2 <= 0) {
            }
            return super.fling(i, i2);
        }
        if (Math.abs(i2) < this.mMinFlingVelocity) {
            return false;
        }
        i = Math.max(Math.min(i2, this.mMaxFlingVelocity), -this.mMaxFlingVelocity);
        if (this.mScroller == null) {
            this.mScroller = new Scroller(getContext(), null, true);
        }
        this.mScroller.fling(0, 0, 0, i, LinearLayoutManager.INVALID_OFFSET, Integer.MAX_VALUE, LinearLayoutManager.INVALID_OFFSET, Integer.MAX_VALUE);
        i2 = this.mScroller.getFinalY() / (getPaddingTop() + (getAdjustedHeight(this) / 2));
        if (i2 == 0) {
            i2 = i > 0 ? 1 : -1;
        }
        smoothScrollToPosition(Math.max(0, Math.min(this.mAdapter.getItemCount() - 1, childAdapterPosition + i2)));
        return true;
    }

    public final int getBaseline() {
        if (getChildCount() == 0) {
            return super.getBaseline();
        }
        int baseline = getChildAt(findCenterViewIndex()).getBaseline();
        if (baseline == -1) {
            return super.getBaseline();
        }
        return getCentralViewTop() + baseline;
    }

    public final int getCentralViewTop() {
        return getPaddingTop() + getItemHeight();
    }

    public final int getTopViewMaxTop() {
        return getHeight() / 2;
    }

    public final void notifyChildrenAboutProximity$ar$ds() {
        LayoutManager layoutManager = (LayoutManager) this.mLayout;
        int childCount = layoutManager.getChildCount();
        if (childCount != 0) {
            int findCenterViewIndex = layoutManager.findCenterViewIndex();
            if (childCount <= 0) {
                android.support.p002v7.widget.RecyclerView.ViewHolder childViewHolder = getChildViewHolder(getChildAt(findCenterViewIndex));
                childCount = childViewHolder.mPreLayoutPosition;
                if (childCount == -1) {
                    childCount = childViewHolder.mPosition;
                }
                if (childCount != this.mPreviousCentral) {
                    int baseline = getBaseline();
                    if (this.mPreviousBaseline != baseline) {
                        this.mPreviousBaseline = baseline;
                        requestLayout();
                    }
                    for (OnScrollListener onCentralPositionChanged$ar$ds$c28c3bea_0 : this.mOnScrollListeners) {
                        onCentralPositionChanged$ar$ds$c28c3bea_0.onCentralPositionChanged$ar$ds$c28c3bea_0();
                    }
                    for (OnCentralPositionChangedListener onCentralPositionChanged$ar$ds : this.mOnCentralPositionChangedListeners) {
                        onCentralPositionChanged$ar$ds.onCentralPositionChanged$ar$ds();
                    }
                    this.mPreviousCentral = childCount;
                }
                return;
            }
            getChildViewHolder(layoutManager.getChildAt(0));
            throw null;
        }
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mObserver.setListView(this);
    }

    protected final void onDetachedFromWindow() {
        this.mObserver.setListView(null);
        super.onDetachedFromWindow();
    }

    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (RotaryEncoder.isFromRotaryEncoder(motionEvent) && motionEvent.getAction() == 8) {
            scrollBy(0, Math.round((-RotaryEncoder.getRotaryAxisValue(motionEvent)) * RotaryEncoder.getScaledScrollFactor(getContext())));
            return true;
        }
        super.onGenericMotionEvent(motionEvent);
        return false;
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (isEnabled()) {
            return super.onInterceptTouchEvent(motionEvent);
        }
        return false;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (!isEnabled()) {
            return false;
        }
        int i = this.mScrollState;
        boolean onTouchEvent = super.onTouchEvent(motionEvent);
        if (getChildCount() > 0) {
            int actionMasked = motionEvent.getActionMasked();
            float rawY;
            if (actionMasked == 0) {
                if (this.mCanClick) {
                    this.mTapPositionX = (int) motionEvent.getX();
                    this.mTapPositionY = (int) motionEvent.getY();
                    rawY = motionEvent.getRawY();
                    computeTapRegions(this.mTapRegions);
                    float[] fArr = this.mTapRegions;
                    if (rawY > fArr[0] && rawY < fArr[1] && (getChildAt(findCenterViewIndex()) instanceof OnCenterProximityListener)) {
                        Handler handler = getHandler();
                        if (handler != null) {
                            handler.removeCallbacks(this.mReleasedRunnable);
                            handler.postDelayed(this.mPressedRunnable, (long) ViewConfiguration.getTapTimeout());
                            return onTouchEvent;
                        }
                    }
                }
            } else if (actionMasked == 1) {
                handleTouchUp(motionEvent, i);
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return onTouchEvent;
                }
            } else if (actionMasked == 2) {
                if (Math.abs(this.mTapPositionX - ((int) motionEvent.getX())) >= this.mTouchSlop || Math.abs(this.mTapPositionY - ((int) motionEvent.getY())) >= this.mTouchSlop) {
                    releasePressedItem();
                    this.mCanClick = false;
                }
                if (!this.mGestureDirectionLocked) {
                    float abs = Math.abs(-motionEvent.getX());
                    rawY = Math.abs(-motionEvent.getY());
                    actionMasked = this.mTouchSlop;
                    if ((abs * abs) + (rawY * rawY) > ((float) (actionMasked * actionMasked))) {
                        this.mGestureDirectionLocked = true;
                    }
                }
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return onTouchEvent;
                }
            } else if (actionMasked == 3) {
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                this.mCanClick = true;
            }
        }
        return onTouchEvent;
    }

    public final void releasePressedItem() {
        View view = this.mPressedView;
        if (view != null) {
            view.setPressed(false);
            this.mPressedView = null;
        }
        Handler handler = getHandler();
        if (handler != null) {
            handler.removeCallbacks(this.mPressedRunnable);
        }
    }

    public final void setAdapter(Adapter adapter) {
        AdapterDataObserver adapterDataObserver = this.mObserver;
        adapterDataObserver.stopOnLayoutChangeListening();
        if (adapterDataObserver.mIsObservingAdapter) {
            adapterDataObserver.mAdapter.unregisterAdapterDataObserver(adapterDataObserver);
            adapterDataObserver.mIsObservingAdapter = false;
        }
        adapterDataObserver.mAdapter = adapter;
        Adapter adapter2 = adapterDataObserver.mAdapter;
        if (adapter2 != null) {
            adapter2.registerAdapterDataObserver(adapterDataObserver);
            adapterDataObserver.mIsObservingAdapter = true;
        }
        super.setAdapter(adapter);
    }

    public WearableListView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public final ViewHolder getChildViewHolder(View view) {
        return (ViewHolder) super.getChildViewHolder(view);
    }

    public final int getItemHeight() {
        return (getAdjustedHeight(this) / 3) + 1;
    }

    public final void handleTouchUp(MotionEvent motionEvent, int i) {
        if (this.mCanClick && motionEvent != null) {
            if (isEnabled()) {
                float x = motionEvent.getX();
                float y = motionEvent.getY();
                int findCenterViewIndex = findCenterViewIndex();
                View findChildViewUnder = findChildViewUnder(x, y);
                if (findChildViewUnder != null) {
                    getChildViewHolder(findChildViewUnder);
                    computeTapRegions(this.mTapRegions);
                    if (findCenterViewIndex == 0) {
                        motionEvent.getRawY();
                        float f = this.mTapRegions[0];
                    }
                    Handler handler = getHandler();
                    if (handler != null) {
                        handler.postDelayed(this.mReleasedRunnable, (long) ViewConfiguration.getTapTimeout());
                    }
                    return;
                }
            }
        }
        if (i == 0) {
            if (getChildCount() > 0 && ((float) getCentralViewTop()) >= 0.0f) {
                getChildAt(0).getTop();
                getTopViewMaxTop();
            }
            animateToCenter();
        }
    }

    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (this.mGestureNavigationEnabled) {
            boolean z = true;
            switch (i) {
                case 260:
                    fling(0, -this.mMinFlingVelocity);
                    return true;
                case 261:
                    fling(0, this.mMinFlingVelocity);
                    return true;
                case 262:
                    if (!isEnabled() || getVisibility() != 0) {
                        z = false;
                    } else if (getChildCount() <= 0) {
                        z = false;
                    } else {
                        View childAt = getChildAt(findCenterViewIndex());
                        getChildViewHolder(childAt);
                        if (!childAt.performClick()) {
                            return false;
                        }
                    }
                    return z;
                case 263:
                    return false;
                default:
                    break;
            }
        }
        return super.onKeyDown(i, keyEvent);
    }

    public WearableListView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mCanClick = true;
        this.mGestureNavigationEnabled = true;
        this.mSetScrollVerticallyProperty = new SetScrollVerticallyProperty();
        this.mOnScrollListeners = new ArrayList();
        this.mOnCentralPositionChangedListeners = new ArrayList();
        this.mTapRegions = new float[2];
        this.mPreviousCentral = -1;
        this.mPreviousBaseline = -1;
        this.mLocation = new int[2];
        this.mPressedView = null;
        this.mPressedRunnable = new PG();
        this.mReleasedRunnable = new C01282();
        this.mNotifyChildrenPostLayoutRunnable = new C01293();
        this.mObserver = new OnChangeObserver();
        setHasFixedSize$ar$ds();
        setOverScrollMode(2);
        setLayoutManager(new LayoutManager());
        this.mScrollListener = new C01304();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.mMinFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
        this.mMaxFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
    }
}
