package android.support.wearable.view;

import android.content.Context;

/* compiled from: PG */
public final class ResourcesUtil {
    public static int getFractionOfScreenPx(Context context, int i, int i2) {
        return (int) (context.getResources().getFraction(i2, 1, 1) * ((float) i));
    }
}
