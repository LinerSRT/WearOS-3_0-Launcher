package android.support.wearable.view;

import android.support.p002v7.widget.LinearLayoutManager;
import android.support.p002v7.widget.RecyclerView.Recycler;
import android.support.p002v7.widget.RecyclerView.State;

/* compiled from: PG */
public abstract class WearableRecyclerView$ChildLayoutManager extends LinearLayoutManager {
    public final void onLayoutChildren(Recycler recycler, State state) {
        throw null;
    }

    public final int scrollVerticallyBy(int i, Recycler recycler, State state) {
        throw null;
    }
}
