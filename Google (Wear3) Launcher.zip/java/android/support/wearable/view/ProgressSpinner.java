package android.support.wearable.view;

import android.animation.ArgbEvaluator;
import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.support.wearable.R$styleable;
import android.util.AttributeSet;
import android.util.Property;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.ProgressBar;
import com.google.android.wearable.sysui.R;

@Deprecated
/* compiled from: PG */
public class ProgressSpinner extends ProgressBar {
    public static final /* synthetic */ int ProgressSpinner$ar$NoOp = 0;
    public int[] mColors = null;
    public final ArgbEvaluator mEvaluator = new ArgbEvaluator();
    public Interpolator mInterpolator;
    public float mShowingness;

    /* renamed from: android.support.wearable.view.ProgressSpinner$1 */
    final class PG extends Property {
        public PG(Class cls) {
            super(cls, "showingness");
        }

        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            ProgressSpinner progressSpinner = (ProgressSpinner) obj;
            int i = ProgressSpinner.ProgressSpinner$ar$NoOp;
            return Float.valueOf(progressSpinner.mShowingness);
        }

        public final /* bridge */ /* synthetic */ void set(Object obj, Object obj2) {
            ProgressSpinner progressSpinner = (ProgressSpinner) obj;
            float floatValue = ((Float) obj2).floatValue();
            int i = ProgressSpinner.ProgressSpinner$ar$NoOp;
            progressSpinner.setShowingness(floatValue);
        }
    }

    /* compiled from: PG */
    final class ProgressDrawable extends Drawable {
        final Paint mForegroundPaint;
        final RectF mInnerCircleBounds = new RectF();

        public ProgressDrawable() {
            Paint paint = new Paint();
            this.mForegroundPaint = paint;
            paint.setAntiAlias(true);
            paint.setColor(-1);
            paint.setStyle(Style.STROKE);
            paint.setStrokeCap(Cap.ROUND);
        }

        public final void draw(Canvas canvas) {
            float width = (float) (getBounds().width() / 2);
            int i = 0;
            if (ProgressSpinner.this.isInEditMode()) {
                RectF rectF = new RectF(getBounds());
                rectF.inset(10.0f, 10.0f);
                r0.mForegroundPaint.setColor(ProgressSpinner.this.mColors[0]);
                r0.mForegroundPaint.setStrokeWidth(7.0f);
                canvas.drawArc(rectF, 0.0f, 270.0f, false, r0.mForegroundPaint);
                return;
            }
            float interpolation;
            float f;
            ProgressSpinner progressSpinner = ProgressSpinner.this;
            float f2 = progressSpinner.mShowingness;
            if (f2 < 1.0f) {
                interpolation = progressSpinner.mInterpolator.getInterpolation(ProgressSpinner.lerpInvSat(0.2f, 0.8f, f2));
                ProgressSpinner progressSpinner2 = ProgressSpinner.this;
                interpolation = (interpolation * 0.78571427f) * width;
                f2 = interpolation - ((progressSpinner2.mInterpolator.getInterpolation(ProgressSpinner.lerpInvSat(0.4f, 1.0f, progressSpinner2.mShowingness)) * 0.64285713f) * width);
                width = (width - interpolation) + (f2 / 2.0f);
            } else {
                width = (float) (getBounds().width() / 7);
                f2 = (float) (getBounds().width() / 14);
            }
            r0.mInnerCircleBounds.set(getBounds());
            r0.mInnerCircleBounds.inset(width, width);
            r0.mForegroundPaint.setStrokeWidth(f2);
            int level = (getLevel() + 10000) % 10000;
            ProgressSpinner progressSpinner3 = ProgressSpinner.this;
            int[] iArr = progressSpinner3.mColors;
            int i2 = iArr[0];
            if (progressSpinner3.mShowingness < 1.0f) {
                interpolation = 360.0f;
                f = 0.0f;
            } else {
                int length = iArr.length;
                int max = 10000 / Math.max(4, length);
                int i3 = 0;
                while (i3 < Math.max(4, length)) {
                    int i4 = i3 + 1;
                    if (level <= i4 * max) {
                        float f3 = ((float) (level - (i3 * max))) / ((float) max);
                        if (f3 < 0.5f) {
                            i = 1;
                        }
                        f = 54.0f * f3;
                        ProgressSpinner progressSpinner4;
                        if (i != 0) {
                            progressSpinner4 = ProgressSpinner.this;
                            int[] iArr2 = progressSpinner4.mColors;
                            int length2 = iArr2.length;
                            i2 = ((Integer) progressSpinner4.mEvaluator.evaluate(ProgressSpinner.lerpInv(0.0f, 0.5f, f3), Integer.valueOf(iArr2[i3 % length2]), Integer.valueOf(iArr2[i4 % length2]))).intValue();
                            interpolation = ProgressSpinner.this.mInterpolator.getInterpolation(ProgressSpinner.lerpInv(0.0f, 0.5f, f3)) * 306.0f;
                        } else {
                            progressSpinner4 = ProgressSpinner.this;
                            int[] iArr3 = progressSpinner4.mColors;
                            interpolation = (1.0f - progressSpinner4.mInterpolator.getInterpolation(ProgressSpinner.lerpInv(0.5f, 1.0f, f3))) * 306.0f;
                            i2 = iArr3[i4 % iArr3.length];
                        }
                    } else {
                        i3 = i4;
                    }
                }
                interpolation = 360.0f;
                f = 0.0f;
            }
            r0.mForegroundPaint.setColor(i2);
            float f4 = interpolation < 1.0f ? 1.0f : interpolation;
            if (((double) f2) > 0.1d) {
                float f5;
                width = ((float) level) * 1.0E-4f;
                canvas.rotate((((width + width) * 360.0f) - 0.049804688f) + f, r0.mInnerCircleBounds.centerX(), r0.mInnerCircleBounds.centerY());
                RectF rectF2 = r0.mInnerCircleBounds;
                if (i != 0) {
                    f5 = 0.0f;
                } else {
                    f5 = 306.0f - f4;
                }
                canvas.drawArc(rectF2, f5, f4, false, r0.mForegroundPaint);
            }
        }

        public final int getOpacity() {
            return -3;
        }

        public final void setAlpha(int i) {
        }

        public final void setColorFilter(ColorFilter colorFilter) {
        }
    }

    static {
        PG pg = new PG(Float.class);
    }

    public ProgressSpinner(Context context) {
        super(context);
        init(context, null, 0);
    }

    private final int[] getColorsFromAttributes(Context context, AttributeSet attributeSet, int i) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ProgressSpinner, i, 0);
        int[] iArr = null;
        if (obtainStyledAttributes.hasValue(0)) {
            try {
                iArr = getResources().getIntArray(obtainStyledAttributes.getResourceId(0, 0));
            } catch (NotFoundException e) {
            }
            if (iArr == null || iArr.length <= 0) {
                iArr = new int[]{Integer.valueOf(obtainStyledAttributes.getColor(0, getResources().getColor(17170445))).intValue()};
                obtainStyledAttributes.recycle();
                return iArr;
            }
        }
        obtainStyledAttributes.recycle();
        return iArr;
    }

    private final void init(Context context, AttributeSet attributeSet, int i) {
        if (!isInEditMode()) {
            this.mInterpolator = AnimationUtils.loadInterpolator(context, 17563654);
        }
        setIndeterminateDrawable(new ProgressDrawable());
        if (getVisibility() == 0) {
            this.mShowingness = 1.0f;
        }
        int[] iArr = this.mColors;
        if (attributeSet != null) {
            iArr = getColorsFromAttributes(context, attributeSet, i);
        }
        if (iArr == null) {
            if (isInEditMode()) {
                iArr = new int[]{context.getResources().getColor(17170456)};
            } else {
                TypedArray obtainTypedArray = getResources().obtainTypedArray(R.array.progress_spinner_sequence);
                iArr = new int[obtainTypedArray.length()];
                for (int i2 = 0; i2 < obtainTypedArray.length(); i2++) {
                    iArr[i2] = obtainTypedArray.getColor(i2, 0);
                }
                obtainTypedArray.recycle();
            }
        }
        if (iArr.length > 0) {
            this.mColors = iArr;
        }
    }

    public static float lerpInv(float f, float f2, float f3) {
        return f != f2 ? (f3 - f) / (f2 - f) : 0.0f;
    }

    public static float lerpInvSat(float f, float f2, float f3) {
        f = lerpInv(f, f2, f3);
        f2 = 1.0f;
        if (f >= 0.0f) {
            return f > 1.0f ? f2 : f;
        } else {
            f2 = 0.0f;
        }
    }

    public final void setShowingness(float f) {
        this.mShowingness = f;
        invalidate();
    }

    public final void setVisibility(int i) {
        if (getVisibility() != i) {
            super.setVisibility(i);
            switch (i) {
                case 0:
                    setShowingness(1.0f);
                    break;
                case 4:
                case 8:
                    setShowingness(0.0f);
                    return;
                default:
                    throw new IllegalArgumentException("Visibility only supports View.VISIBLE, View.INVISIBLE, or View.GONE");
            }
        }
    }

    public ProgressSpinner(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context, attributeSet, 0);
    }

    public ProgressSpinner(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context, attributeSet, i);
    }
}
