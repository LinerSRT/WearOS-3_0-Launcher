package android.support.wearable.view;

import android.animation.AnimatorInflater;
import android.animation.StateListAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.support.wearable.R$styleable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowInsets;
import com.google.android.wearable.sysui.R;
import p020j$.util.Objects;

@Deprecated
/* compiled from: PG */
public class ActionPage extends ViewGroup {
    private int mBottomInset;
    private final Point mButtonCenter;
    private float mButtonRadius;
    private int mButtonSize;
    private CircularButton mCircularButton;
    private boolean mInsetsApplied;
    private boolean mIsRound;
    private final ActionLabel mLabel;
    private int mTextHeight;
    private int mTextWidth;

    public ActionPage(Context context) {
        this(context, null);
    }

    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        this.mInsetsApplied = true;
        if (this.mIsRound != windowInsets.isRound()) {
            this.mIsRound = windowInsets.isRound();
            requestLayout();
        }
        int systemWindowInsetBottom = windowInsets.getSystemWindowInsetBottom();
        if (this.mBottomInset != systemWindowInsetBottom) {
            this.mBottomInset = systemWindowInsetBottom;
            requestLayout();
        }
        if (this.mIsRound) {
            this.mBottomInset = (int) Math.max((float) this.mBottomInset, ((float) getMeasuredHeight()) * 0.09375f);
        }
        return windowInsets;
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!this.mInsetsApplied) {
            requestApplyInsets();
        }
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.mCircularButton.layout((int) (((float) this.mButtonCenter.x) - this.mButtonRadius), (int) (((float) this.mButtonCenter.y) - this.mButtonRadius), (int) (((float) this.mButtonCenter.x) + this.mButtonRadius), (int) (((float) this.mButtonCenter.y) + this.mButtonRadius));
        int i5 = (int) (((float) ((i3 - i) - this.mTextWidth)) / 2.0f);
        this.mLabel.layout(i5, this.mCircularButton.getBottom(), this.mTextWidth + i5, this.mCircularButton.getBottom() + this.mTextHeight);
    }

    protected final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        i = getMeasuredHeight();
        i2 = getMeasuredWidth();
        View view = this.mCircularButton;
        int min;
        if (view.mScaleMode != 1 || view.mImage == null) {
            min = (int) (((float) Math.min(i2, i)) * 0.45f);
            this.mButtonSize = min;
            this.mButtonRadius = ((float) min) / 2.0f;
            this.mCircularButton.measure(MeasureSpec.makeMeasureSpec(min, 1073741824), MeasureSpec.makeMeasureSpec(this.mButtonSize, 1073741824));
        } else {
            view.measure(0, 0);
            min = Math.min(this.mCircularButton.getMeasuredWidth(), this.mCircularButton.getMeasuredHeight());
            this.mButtonSize = min;
            this.mButtonRadius = ((float) min) / 2.0f;
        }
        if (this.mIsRound) {
            this.mButtonCenter.set(i2 / 2, i / 2);
            this.mTextWidth = (int) (((float) i2) * 0.625f);
            this.mBottomInset = (int) (((float) i) * 0.09375f);
        } else {
            this.mButtonCenter.set(i2 / 2, (int) (((float) i) * 0.43f));
            this.mTextWidth = (int) (((float) i2) * 0.892f);
        }
        this.mTextHeight = (int) ((((float) i) - (((float) this.mButtonCenter.y) + this.mButtonRadius)) - ((float) this.mBottomInset));
        this.mLabel.measure(MeasureSpec.makeMeasureSpec(this.mTextWidth, 1073741824), MeasureSpec.makeMeasureSpec(this.mTextHeight, 1073741824));
    }

    public final void setEnabled(boolean z) {
        super.setEnabled(z);
        View view = this.mCircularButton;
        if (view != null) {
            view.setEnabled(z);
        }
    }

    public final void setOnClickListener(OnClickListener onClickListener) {
        View view = this.mCircularButton;
        if (view != null) {
            view.setOnClickListener(onClickListener);
        }
    }

    public final void setStateListAnimator(StateListAnimator stateListAnimator) {
        CircularButton circularButton = this.mCircularButton;
        if (circularButton != null) {
            circularButton.setStateListAnimator(stateListAnimator);
        }
    }

    public ActionPage(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionPage(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, R.style.Widget.ActionPage);
    }

    public ActionPage(Context context, AttributeSet attributeSet, int i, int i2) {
        Context context2 = context;
        super(context, attributeSet, i, i2);
        this.mButtonCenter = new Point();
        this.mCircularButton = new CircularButton(context2);
        ActionLabel actionLabel = new ActionLabel(context2);
        this.mLabel = actionLabel;
        actionLabel.setGravity(17);
        actionLabel.setMaxLines(2);
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, R$styleable.ActionPage, i, i2);
        float f = 1.0f;
        String str = null;
        float f2 = 0.0f;
        int i3 = 1;
        int i4 = 0;
        for (int i5 = 0; i5 < obtainStyledAttributes.getIndexCount(); i5++) {
            int index = obtainStyledAttributes.getIndex(i5);
            if (index == 7) {
                CircularButton circularButton = r0.mCircularButton;
                circularButton.mColors = obtainStyledAttributes.getColorStateList(7);
                circularButton.mShapeDrawable.getPaint().setColor(circularButton.mColors.getDefaultColor());
            } else if (index == 4) {
                Callback callback = r0.mCircularButton;
                Drawable drawable = obtainStyledAttributes.getDrawable(4);
                Drawable drawable2 = callback.mImage;
                if (drawable2 != null) {
                    drawable2.setCallback(null);
                }
                if (callback.mImage != drawable) {
                    callback.mImage = drawable;
                    callback.requestLayout();
                    callback.invalidate();
                }
                drawable2 = callback.mImage;
                if (drawable2 != null) {
                    drawable2.setCallback(callback);
                }
            } else if (index == 14) {
                r6 = r0.mCircularButton;
                r6.mScaleMode = obtainStyledAttributes.getInt(14, 0);
                if (r6.mImage != null) {
                    r6.invalidate();
                    r6.requestLayout();
                }
            } else if (index == 13) {
                r0.mCircularButton.setRippleColor(obtainStyledAttributes.getColor(13, -1));
            } else if (index == 17) {
                r0.mCircularButton.setPressedTranslationZ(obtainStyledAttributes.getDimension(17, 0.0f));
            } else if (index == 5) {
                r6 = r0.mLabel;
                CharSequence text = obtainStyledAttributes.getText(5);
                if (text == null) {
                    throw new RuntimeException("Can not set ActionLabel text to null");
                } else if (!Objects.equals(r6.mText, text)) {
                    r6.mLayout = null;
                    r6.mText = text;
                    r6.requestLayout();
                    r6.invalidate();
                }
            } else if (index == 16) {
                r6 = r0.mLabel;
                r4 = TypedValue.applyDimension(0, obtainStyledAttributes.getDimension(16, 10.0f), r6.getContext().getResources().getDisplayMetrics());
                if (r4 != r6.mMinTextSize) {
                    r6.mLayout = null;
                    r6.mMinTextSize = r4;
                    r6.requestLayout();
                    r6.invalidate();
                }
            } else if (index == 15) {
                r6 = r0.mLabel;
                r4 = TypedValue.applyDimension(0, obtainStyledAttributes.getDimension(15, 60.0f), r6.getContext().getResources().getDisplayMetrics());
                if (r4 != r6.mMaxTextSize) {
                    r6.mLayout = null;
                    r6.mMaxTextSize = r4;
                    r6.requestLayout();
                    r6.invalidate();
                }
            } else if (index == 2) {
                ActionLabel actionLabel2 = r0.mLabel;
                ColorStateList colorStateList = obtainStyledAttributes.getColorStateList(2);
                if (colorStateList != null) {
                    actionLabel2.mTextColor = colorStateList;
                    actionLabel2.updateTextColors();
                } else {
                    throw null;
                }
            } else if (index == 6) {
                r0.mLabel.setMaxLines(obtainStyledAttributes.getInt(6, 2));
            } else if (index == 10) {
                str = obtainStyledAttributes.getString(10);
            } else if (index == 0) {
                i3 = obtainStyledAttributes.getInt(0, i3);
            } else if (index == 1) {
                i4 = obtainStyledAttributes.getInt(1, i4);
            } else if (index == 3) {
                r0.mLabel.setGravity(obtainStyledAttributes.getInt(3, 17));
            } else if (index == 8) {
                f2 = obtainStyledAttributes.getDimension(8, f2);
            } else if (index == 9) {
                f = obtainStyledAttributes.getDimension(9, f);
            } else if (index == 12) {
                r0.mCircularButton.setStateListAnimator(AnimatorInflater.loadStateListAnimator(context2, obtainStyledAttributes.getResourceId(12, 0)));
            }
        }
        obtainStyledAttributes.recycle();
        View view = r0.mLabel;
        if (!(view.mSpacingAdd == f2 && view.mSpacingMult == f)) {
            view.mSpacingAdd = f2;
            view.mSpacingMult = f;
            if (view.mLayout != null) {
                view.mLayout = null;
                view.requestLayout();
                view.invalidate();
            }
        }
        r0.mLabel.setTypefaceFromAttrs(str, i3, i4);
        addView(r0.mLabel);
        addView(r0.mCircularButton);
    }
}
