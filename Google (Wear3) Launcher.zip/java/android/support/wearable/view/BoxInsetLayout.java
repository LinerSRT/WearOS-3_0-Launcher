package android.support.wearable.view;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.wearable.R$styleable;
import android.util.AttributeSet;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;

@Deprecated
/* compiled from: PG */
public class BoxInsetLayout extends FrameLayout {
    private Rect mForegroundPadding;
    private Rect mInsets;
    private boolean mLastKnownRound;
    private final int mScreenHeight;
    private final int mScreenWidth;

    /* compiled from: PG */
    public final class LayoutParams extends android.widget.FrameLayout.LayoutParams {
        public int boxedEdges = 0;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.BoxInsetLayout_Layout, 0, 0);
            this.boxedEdges = obtainStyledAttributes.getInt(1, 0);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public BoxInsetLayout(Context context) {
        this(context, null);
    }

    private final int calculateChildBottomMargin(LayoutParams layoutParams, int i, int i2) {
        if (this.mLastKnownRound && (layoutParams.boxedEdges & 8) != 0 && (layoutParams.height == -1 || i == 80)) {
            return layoutParams.bottomMargin + i2;
        }
        return layoutParams.bottomMargin;
    }

    private final int calculateChildLeftMargin(LayoutParams layoutParams, int i, int i2) {
        if (this.mLastKnownRound && (layoutParams.boxedEdges & 1) != 0 && (layoutParams.width == -1 || i == 3)) {
            return layoutParams.leftMargin + i2;
        }
        return layoutParams.leftMargin;
    }

    private final int calculateChildRightMargin(LayoutParams layoutParams, int i, int i2) {
        if (this.mLastKnownRound && (layoutParams.boxedEdges & 4) != 0 && (layoutParams.width == -1 || i == 5)) {
            return layoutParams.rightMargin + i2;
        }
        return layoutParams.rightMargin;
    }

    private final int calculateChildTopMargin(LayoutParams layoutParams, int i, int i2) {
        if (this.mLastKnownRound && (layoutParams.boxedEdges & 2) != 0 && (layoutParams.height == -1 || i == 48)) {
            return layoutParams.topMargin + i2;
        }
        return layoutParams.topMargin;
    }

    private final int calculateInset() {
        return (int) (((float) Math.max(Math.min(getMeasuredWidth(), this.mScreenWidth), Math.min(getMeasuredHeight(), this.mScreenHeight))) * 0.146467f);
    }

    protected final boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public final LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mLastKnownRound = getResources().getConfiguration().isScreenRound();
        WindowInsets rootWindowInsets = getRootWindowInsets();
        this.mInsets.set(rootWindowInsets.getSystemWindowInsetLeft(), rootWindowInsets.getSystemWindowInsetTop(), rootWindowInsets.getSystemWindowInsetRight(), rootWindowInsets.getSystemWindowInsetBottom());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected final void onLayout(boolean r18, int r19, int r20, int r21, int r22) {
        /*
        r17 = this;
        r0 = r17;
        r1 = r17.getChildCount();
        r2 = r17.getPaddingLeft();
        r3 = r0.mForegroundPadding;
        r3 = r3.left;
        r2 = r2 + r3;
        r3 = r21 - r19;
        r4 = r17.getPaddingRight();
        r3 = r3 - r4;
        r4 = r0.mForegroundPadding;
        r4 = r4.right;
        r3 = r3 - r4;
        r4 = r17.getPaddingTop();
        r5 = r0.mForegroundPadding;
        r5 = r5.top;
        r4 = r4 + r5;
        r5 = r22 - r20;
        r6 = r17.getPaddingBottom();
        r5 = r5 - r6;
        r6 = r0.mForegroundPadding;
        r6 = r6.bottom;
        r5 = r5 - r6;
        r6 = 0;
    L_0x0031:
        if (r6 >= r1) goto L_0x00bc;
    L_0x0033:
        r7 = r0.getChildAt(r6);
        r8 = r7.getVisibility();
        r9 = 8;
        if (r8 == r9) goto L_0x00b4;
    L_0x003f:
        r8 = r7.getLayoutParams();
        r8 = (android.support.wearable.view.BoxInsetLayout.LayoutParams) r8;
        r9 = r7.getMeasuredWidth();
        r10 = r7.getMeasuredHeight();
        r11 = r8.gravity;
        r12 = -1;
        if (r11 != r12) goto L_0x0055;
    L_0x0052:
        r11 = 8388659; // 0x800033 float:1.1755015E-38 double:4.144548E-317;
    L_0x0055:
        r13 = r17.getLayoutDirection();
        r13 = android.view.Gravity.getAbsoluteGravity(r11, r13);
        r14 = r11 & 112;
        r11 = r11 & 7;
        r15 = r17.calculateInset();
        r16 = r0.calculateChildLeftMargin(r8, r11, r15);
        r11 = r0.calculateChildRightMargin(r8, r11, r15);
        r18 = r1;
        r1 = r8.width;
        if (r1 != r12) goto L_0x0078;
    L_0x0073:
        r16 = r2 + r16;
        r1 = r16;
        goto L_0x008f;
    L_0x0078:
        r1 = r13 & 7;
        switch(r1) {
            case 1: goto L_0x0083;
            case 5: goto L_0x0080;
            default: goto L_0x007d;
        };
    L_0x007d:
        r16 = r2 + r16;
        goto L_0x008d;
    L_0x0080:
        r1 = r3 - r9;
        goto L_0x008b;
    L_0x0083:
        r1 = r3 - r2;
        r1 = r1 - r9;
        r1 = r1 / 2;
        r1 = r1 + r2;
        r1 = r1 + r16;
    L_0x008b:
        r16 = r1 - r11;
    L_0x008d:
        r1 = r16;
    L_0x008f:
        r11 = r0.calculateChildTopMargin(r8, r14, r15);
        r13 = r0.calculateChildBottomMargin(r8, r14, r15);
        r8 = r8.height;
        if (r8 != r12) goto L_0x009d;
    L_0x009b:
        r11 = r11 + r4;
        goto L_0x00ae;
    L_0x009d:
        switch(r14) {
            case 16: goto L_0x00a5;
            case 80: goto L_0x00a2;
            default: goto L_0x00a0;
        };
    L_0x00a0:
        r11 = r11 + r4;
        goto L_0x00ae;
    L_0x00a2:
        r8 = r5 - r10;
        goto L_0x00ac;
    L_0x00a5:
        r8 = r5 - r4;
        r8 = r8 - r10;
        r8 = r8 / 2;
        r8 = r8 + r4;
        r8 = r8 + r11;
    L_0x00ac:
        r11 = r8 - r13;
    L_0x00ae:
        r9 = r9 + r1;
        r10 = r10 + r11;
        r7.layout(r1, r11, r9, r10);
        goto L_0x00b6;
    L_0x00b4:
        r18 = r1;
    L_0x00b6:
        r6 = r6 + 1;
        r1 = r18;
        goto L_0x0031;
    L_0x00bc:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.wearable.view.BoxInsetLayout.onLayout(boolean, int, int, int, int):void");
    }

    protected final void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        FrameLayout frameLayout = this;
        int i7 = i;
        int i8 = i2;
        int childCount = getChildCount();
        int i9 = 0;
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        for (i3 = 0; i3 < childCount; i3++) {
            int i13;
            int i14;
            int i15;
            int i16;
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (frameLayout.mLastKnownRound) {
                    if ((layoutParams.boxedEdges & 1) == 0) {
                        i4 = layoutParams.leftMargin;
                    } else {
                        i4 = 0;
                    }
                    if ((layoutParams.boxedEdges & 4) == 0) {
                        i5 = layoutParams.rightMargin;
                    } else {
                        i5 = 0;
                    }
                    if ((layoutParams.boxedEdges & 2) == 0) {
                        i6 = layoutParams.topMargin;
                    } else {
                        i6 = 0;
                    }
                    if ((8 & layoutParams.boxedEdges) == 0) {
                        i13 = layoutParams.bottomMargin;
                        i14 = i4;
                        i15 = i5;
                        i16 = i6;
                    } else {
                        i14 = i4;
                        i15 = i5;
                        i16 = i6;
                        i13 = 0;
                    }
                } else {
                    i4 = layoutParams.leftMargin;
                    i6 = layoutParams.topMargin;
                    i5 = layoutParams.rightMargin;
                    i13 = layoutParams.bottomMargin;
                    i14 = i4;
                    i15 = i5;
                    i16 = i6;
                }
                measureChildWithMargins(childAt, i, 0, i2, 0);
                i11 = Math.max(i11, (childAt.getMeasuredWidth() + i14) + i15);
                i10 = Math.max(i10, (childAt.getMeasuredHeight() + i16) + i13);
                i12 = combineMeasuredStates(i12, childAt.getMeasuredState());
            }
        }
        int paddingLeft = getPaddingLeft();
        int i17 = frameLayout.mForegroundPadding.left;
        i4 = getPaddingRight();
        i5 = frameLayout.mForegroundPadding.right;
        i6 = Math.max(i10 + (((getPaddingTop() + frameLayout.mForegroundPadding.top) + getPaddingBottom()) + frameLayout.mForegroundPadding.bottom), getSuggestedMinimumHeight());
        paddingLeft = Math.max(i11 + (((paddingLeft + i17) + i4) + i5), getSuggestedMinimumWidth());
        Drawable foreground = getForeground();
        if (foreground != null) {
            i6 = Math.max(i6, foreground.getMinimumHeight());
            paddingLeft = Math.max(paddingLeft, foreground.getMinimumWidth());
        }
        setMeasuredDimension(resolveSizeAndState(paddingLeft, i7, i12), resolveSizeAndState(i6, i8, i12 << 16));
        paddingLeft = calculateInset();
        while (i9 < childCount) {
            View childAt2 = getChildAt(i9);
            LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
            i5 = layoutParams2.gravity;
            if (i5 == -1) {
                i5 = 8388659;
            }
            i6 = i5 & 112;
            i5 &= 7;
            int paddingLeft2 = getPaddingLeft();
            i3 = frameLayout.mForegroundPadding.left;
            i10 = getPaddingRight();
            i11 = frameLayout.mForegroundPadding.right;
            i12 = getPaddingTop();
            int i18 = frameLayout.mForegroundPadding.top;
            i13 = getPaddingBottom();
            i14 = childCount;
            childCount = frameLayout.mForegroundPadding.bottom;
            i15 = calculateChildLeftMargin(layoutParams2, i5, paddingLeft);
            i5 = calculateChildRightMargin(layoutParams2, i5, paddingLeft);
            i16 = calculateChildTopMargin(layoutParams2, i6, paddingLeft);
            childAt2.measure(getChildMeasureSpec(i7, (((paddingLeft2 + i3) + (i10 + i11)) + i15) + i5, layoutParams2.width), getChildMeasureSpec(i8, (((i12 + i18) + (i13 + childCount)) + i16) + calculateChildBottomMargin(layoutParams2, i6, paddingLeft), layoutParams2.height));
            i9++;
            childCount = i14;
        }
    }

    public final void setForeground(Drawable drawable) {
        super.setForeground(drawable);
        if (this.mForegroundPadding == null) {
            this.mForegroundPadding = new Rect();
        }
        drawable.getPadding(this.mForegroundPadding);
    }

    public BoxInsetLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public BoxInsetLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (this.mForegroundPadding == null) {
            this.mForegroundPadding = new Rect();
        }
        if (this.mInsets == null) {
            this.mInsets = new Rect();
        }
        this.mScreenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;
        this.mScreenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    protected final android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }
}
