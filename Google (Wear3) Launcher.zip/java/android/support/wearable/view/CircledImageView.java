package android.support.wearable.view;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.support.p002v7.widget.LinearLayoutManager;
import android.support.wearable.R$styleable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;

@Deprecated
/* compiled from: PG */
public class CircledImageView extends View {
    private Cap mCircleBorderCap;
    private int mCircleBorderColor;
    private float mCircleBorderWidth;
    private ColorStateList mCircleColor;
    private float mCircleRadius;
    private float mCircleRadiusPercent;
    private float mCircleRadiusPressed;
    private float mCircleRadiusPressedPercent;
    public int mCurrentColor;
    private Drawable mDrawable;
    private final Callback mDrawableCallback;
    private float mImageCirclePercentage;
    private float mImageHorizontalOffcenterPercentage;
    private Integer mImageTint;
    private final ProgressDrawable mIndeterminateDrawable;
    final RectF mOval;
    private final Paint mPaint;
    private boolean mPressed;
    private float mProgress;
    private float mRadiusInset;
    private final OvalShadowPainter mShadowPainter;
    private Integer mSquareDimen;

    /* renamed from: android.support.wearable.view.CircledImageView$1 */
    final class PG implements Callback {
        public final void invalidateDrawable(Drawable drawable) {
            CircledImageView.this.invalidate();
        }

        public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        }

        public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        }
    }

    /* renamed from: android.support.wearable.view.CircledImageView$2 */
    final class C01262 implements AnimatorUpdateListener {
        public final void onAnimationUpdate(ValueAnimator valueAnimator) {
            int intValue = ((Integer) valueAnimator.getAnimatedValue()).intValue();
            View view = CircledImageView.this;
            if (intValue != view.mCurrentColor) {
                view.mCurrentColor = intValue;
                view.invalidate();
            }
        }
    }

    /* compiled from: PG */
    final class OvalShadowPainter {
        private final RectF mBounds = new RectF();
        private final float mInnerCircleBorderWidth;
        public float mInnerCircleRadius;
        private final int[] mShaderColors = new int[]{-16777216, 0};
        private final float[] mShaderStops = new float[]{0.6f, 1.0f};
        private final Paint mShadowPaint;
        private float mShadowRadius;
        public final float mShadowVisibility;
        public final float mShadowWidth;

        public OvalShadowPainter(float f, float f2, float f3) {
            Paint paint = new Paint();
            this.mShadowPaint = paint;
            this.mShadowWidth = f;
            this.mShadowVisibility = 0.0f;
            this.mInnerCircleRadius = f2;
            this.mInnerCircleBorderWidth = f3;
            this.mShadowRadius = (f2 + f3) + (f * 0.0f);
            paint.setColor(-16777216);
            paint.setStyle(Style.FILL);
            paint.setAntiAlias(true);
            updateRadialGradient();
        }

        final void setBounds(int i, int i2, int i3, int i4) {
            this.mBounds.set((float) i, (float) i2, (float) i3, (float) i4);
            updateRadialGradient();
        }

        public final void updateRadialGradient() {
            float f = (this.mInnerCircleRadius + this.mInnerCircleBorderWidth) + (this.mShadowWidth * 0.0f);
            this.mShadowRadius = f;
            if (f > 0.0f) {
                this.mShadowPaint.setShader(new RadialGradient(this.mBounds.centerX(), this.mBounds.centerY(), this.mShadowRadius, this.mShaderColors, this.mShaderStops, TileMode.MIRROR));
            }
        }
    }

    static {
        ArgbEvaluator argbEvaluator = new ArgbEvaluator();
    }

    public CircledImageView(Context context) {
        this(context, null);
    }

    private final void setColorForCurrentState() {
        int colorForState = this.mCircleColor.getColorForState(getDrawableState(), this.mCircleColor.getDefaultColor());
        if (colorForState != this.mCurrentColor) {
            this.mCurrentColor = colorForState;
            invalidate();
        }
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        setColorForCurrentState();
    }

    public final float getCircleRadius() {
        float f = this.mCircleRadius;
        if (f <= 0.0f && this.mCircleRadiusPercent > 0.0f) {
            f = ((float) Math.max(getMeasuredHeight(), getMeasuredWidth())) * this.mCircleRadiusPercent;
        }
        return f - this.mRadiusInset;
    }

    public final float getCircleRadiusPressed() {
        float f = this.mCircleRadiusPressed;
        if (f <= 0.0f && this.mCircleRadiusPressedPercent > 0.0f) {
            f = ((float) Math.max(getMeasuredHeight(), getMeasuredWidth())) * this.mCircleRadiusPressedPercent;
        }
        return f - this.mRadiusInset;
    }

    protected final void onDraw(Canvas canvas) {
        Paint paint;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        float circleRadiusPressed = this.mPressed ? getCircleRadiusPressed() : getCircleRadius();
        getAlpha();
        this.mOval.set((float) paddingLeft, (float) paddingTop, (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()));
        RectF rectF = this.mOval;
        rectF.set(rectF.centerX() - circleRadiusPressed, this.mOval.centerY() - circleRadiusPressed, this.mOval.centerX() + circleRadiusPressed, this.mOval.centerY() + circleRadiusPressed);
        if (this.mCircleBorderWidth > 0.0f) {
            this.mPaint.setColor(this.mCircleBorderColor);
            paint = this.mPaint;
            paint.setAlpha(Math.round(((float) paint.getAlpha()) * getAlpha()));
            this.mPaint.setStyle(Style.STROKE);
            this.mPaint.setStrokeWidth(this.mCircleBorderWidth);
            this.mPaint.setStrokeCap(this.mCircleBorderCap);
            canvas.drawArc(this.mOval, -90.0f, this.mProgress * 360.0f, false, this.mPaint);
        }
        this.mPaint.setColor(this.mCurrentColor);
        paint = this.mPaint;
        paint.setAlpha(Math.round(((float) paint.getAlpha()) * getAlpha()));
        this.mPaint.setStyle(Style.FILL);
        canvas.drawCircle(this.mOval.centerX(), this.mOval.centerY(), circleRadiusPressed, this.mPaint);
        Drawable drawable = this.mDrawable;
        if (drawable != null) {
            drawable.setAlpha(Math.round(getAlpha() * 255.0f));
            Integer num = this.mImageTint;
            if (num != null) {
                this.mDrawable.setTint(num.intValue());
            }
            this.mDrawable.draw(canvas);
        }
        super.onDraw(canvas);
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Drawable drawable = this.mDrawable;
        if (drawable != null) {
            float f;
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = this.mDrawable.getIntrinsicHeight();
            int measuredWidth = getMeasuredWidth();
            int measuredHeight = getMeasuredHeight();
            float f2 = this.mImageCirclePercentage;
            if (f2 <= 0.0f) {
                f2 = 1.0f;
            }
            float f3 = (float) intrinsicWidth;
            if (f3 != 0.0f) {
                f = (((float) measuredWidth) * f2) / f3;
            } else {
                f = 1.0f;
            }
            float f4 = (float) intrinsicHeight;
            if (f4 != 0.0f) {
                f2 = (f2 * ((float) measuredHeight)) / f4;
            } else {
                f2 = 1.0f;
            }
            f2 = Math.min(1.0f, Math.min(f, f2));
            intrinsicWidth = Math.round(f3 * f2);
            intrinsicHeight = Math.round(f2 * f4);
            measuredWidth = ((measuredWidth - intrinsicWidth) / 2) + Math.round(this.mImageHorizontalOffcenterPercentage * ((float) intrinsicWidth));
            measuredHeight = (measuredHeight - intrinsicHeight) / 2;
            this.mDrawable.setBounds(measuredWidth, measuredHeight, intrinsicWidth + measuredWidth, intrinsicHeight + measuredHeight);
        }
        super.onLayout(z, i, i2, i3, i4);
    }

    protected final void onMeasure(int i, int i2) {
        float circleRadius = getCircleRadius();
        float f = this.mCircleBorderWidth;
        OvalShadowPainter ovalShadowPainter = this.mShadowPainter;
        float f2 = ovalShadowPainter.mShadowWidth;
        float f3 = ovalShadowPainter.mShadowVisibility;
        circleRadius = (circleRadius + f) + (f2 * 0.0f);
        circleRadius += circleRadius;
        int mode = MeasureSpec.getMode(i);
        i = MeasureSpec.getSize(i);
        int mode2 = MeasureSpec.getMode(i2);
        i2 = MeasureSpec.getSize(i2);
        if (mode != 1073741824) {
            i = mode == LinearLayoutManager.INVALID_OFFSET ? (int) Math.min(circleRadius, (float) i) : (int) circleRadius;
        }
        if (mode2 != 1073741824) {
            i2 = mode2 == LinearLayoutManager.INVALID_OFFSET ? (int) Math.min(circleRadius, (float) i2) : (int) circleRadius;
        }
        Integer num = this.mSquareDimen;
        if (num != null) {
            switch (num.intValue()) {
                case 1:
                    i = i2;
                    break;
                case 2:
                    i2 = i;
                    break;
                default:
                    break;
            }
        }
        super.onMeasure(MeasureSpec.makeMeasureSpec(i, 1073741824), MeasureSpec.makeMeasureSpec(i2, 1073741824));
    }

    protected final boolean onSetAlpha(int i) {
        return true;
    }

    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        if (i == i3) {
            if (i2 == i4) {
                return;
            }
        }
        this.mShadowPainter.setBounds(getPaddingLeft(), getPaddingTop(), i - getPaddingRight(), i2 - getPaddingBottom());
    }

    protected final void onVisibilityChanged(View view, int i) {
        super.onVisibilityChanged(view, i);
        showIndeterminateProgress$ar$ds();
    }

    protected final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        showIndeterminateProgress$ar$ds();
    }

    public final void setPadding(int i, int i2, int i3, int i4) {
        if (!(i == getPaddingLeft() && i2 == getPaddingTop() && i3 == getPaddingRight() && i4 == getPaddingBottom())) {
            this.mShadowPainter.setBounds(i, i2, getWidth() - i3, getHeight() - i4);
        }
        super.setPadding(i, i2, i3, i4);
    }

    public final void setPressed(boolean z) {
        super.setPressed(z);
        if (z != this.mPressed) {
            this.mPressed = z;
            OvalShadowPainter ovalShadowPainter = this.mShadowPainter;
            ovalShadowPainter.mInnerCircleRadius = z ? getCircleRadiusPressed() : getCircleRadius();
            ovalShadowPainter.updateRadialGradient();
            invalidate();
        }
    }

    public final void showIndeterminateProgress$ar$ds() {
        ProgressDrawable progressDrawable = this.mIndeterminateDrawable;
        if (progressDrawable != null) {
            progressDrawable.mAnimator.cancel();
        }
    }

    public CircledImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CircledImageView(Context context, AttributeSet attributeSet, int i) {
        Drawable newDrawable;
        super(context, attributeSet, i);
        Rect rect = new Rect();
        this.mProgress = 1.0f;
        this.mPressed = false;
        this.mImageCirclePercentage = 1.0f;
        this.mImageHorizontalOffcenterPercentage = 0.0f;
        Callback pg = new PG();
        this.mDrawableCallback = pg;
        C01262 c01262 = new C01262();
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.CircledImageView);
        Drawable drawable = obtainStyledAttributes.getDrawable(0);
        this.mDrawable = drawable;
        if (!(drawable == null || drawable.getConstantState() == null)) {
            newDrawable = this.mDrawable.getConstantState().newDrawable(context.getResources(), context.getTheme());
            this.mDrawable = newDrawable;
            this.mDrawable = newDrawable.mutate();
        }
        ColorStateList colorStateList = obtainStyledAttributes.getColorStateList(13);
        this.mCircleColor = colorStateList;
        if (colorStateList == null) {
            this.mCircleColor = ColorStateList.valueOf(17170432);
        }
        float dimension = obtainStyledAttributes.getDimension(15, 0.0f);
        this.mCircleRadius = dimension;
        this.mCircleRadiusPressed = obtainStyledAttributes.getDimension(17, dimension);
        this.mCircleBorderColor = obtainStyledAttributes.getColor(11, -16777216);
        this.mCircleBorderCap = Cap.values()[obtainStyledAttributes.getInt(10, 0)];
        dimension = obtainStyledAttributes.getDimension(12, 0.0f);
        this.mCircleBorderWidth = dimension;
        if (dimension > 0.0f) {
            this.mRadiusInset += dimension / 2.0f;
        }
        dimension = obtainStyledAttributes.getDimension(14, 0.0f);
        if (dimension > 0.0f) {
            this.mRadiusInset += dimension;
        }
        this.mImageCirclePercentage = obtainStyledAttributes.getFloat(20, 0.0f);
        this.mImageHorizontalOffcenterPercentage = obtainStyledAttributes.getFloat(21, 0.0f);
        if (obtainStyledAttributes.hasValue(22)) {
            this.mImageTint = Integer.valueOf(obtainStyledAttributes.getColor(22, 0));
        }
        if (obtainStyledAttributes.hasValue(28)) {
            this.mSquareDimen = Integer.valueOf(obtainStyledAttributes.getInt(28, 0));
        }
        dimension = obtainStyledAttributes.getFraction(16, 1, 1, 0.0f);
        this.mCircleRadiusPercent = dimension;
        this.mCircleRadiusPressedPercent = obtainStyledAttributes.getFraction(18, 1, 1, dimension);
        dimension = obtainStyledAttributes.getDimension(27, 0.0f);
        obtainStyledAttributes.recycle();
        this.mOval = new RectF();
        Paint paint = new Paint();
        this.mPaint = paint;
        paint.setAntiAlias(true);
        this.mShadowPainter = new OvalShadowPainter(dimension, getCircleRadius(), this.mCircleBorderWidth);
        newDrawable = new ProgressDrawable();
        this.mIndeterminateDrawable = newDrawable;
        newDrawable.setCallback(pg);
        setWillNotDraw(false);
        setColorForCurrentState();
    }
}
