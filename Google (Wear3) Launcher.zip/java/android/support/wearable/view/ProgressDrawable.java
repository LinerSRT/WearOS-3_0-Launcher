package android.support.wearable.view;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.Property;
import android.view.animation.LinearInterpolator;

/* compiled from: PG */
final class ProgressDrawable extends Drawable {
    private static final Property LEVEL = new PG(Integer.class);
    private static final TimeInterpolator mInterpolator = Gusterpolator.INSTANCE;
    public final ObjectAnimator mAnimator;
    private final RectF mInnerCircleBounds = new RectF();
    private final Paint mPaint;

    /* renamed from: android.support.wearable.view.ProgressDrawable$1 */
    final class PG extends Property {
        public PG(Class cls) {
            super(cls, "level");
        }

        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            return Integer.valueOf(((ProgressDrawable) obj).getLevel());
        }

        public final /* bridge */ /* synthetic */ void set(Object obj, Object obj2) {
            ProgressDrawable progressDrawable = (ProgressDrawable) obj;
            progressDrawable.setLevel(((Integer) obj2).intValue());
            progressDrawable.invalidateSelf();
        }
    }

    public ProgressDrawable() {
        Paint paint = new Paint();
        this.mPaint = paint;
        paint.setAntiAlias(true);
        paint.setStyle(Style.STROKE);
        ObjectAnimator ofInt = ObjectAnimator.ofInt(this, LEVEL, new int[]{0, 10000});
        this.mAnimator = ofInt;
        ofInt.setRepeatCount(-1);
        ofInt.setRepeatMode(1);
        ofInt.setDuration(6000);
        ofInt.setInterpolator(new LinearInterpolator());
    }

    private static float lerpInv(float f, float f2, float f3) {
        return f != f2 ? (f3 - f) / (f2 - f) : 0.0f;
    }

    public final void draw(Canvas canvas) {
        float interpolation;
        float f;
        canvas.save();
        this.mInnerCircleBounds.set(getBounds());
        this.mInnerCircleBounds.inset(0.0f, 0.0f);
        this.mPaint.setStrokeWidth(0.0f);
        this.mPaint.setColor(0);
        int level = getLevel();
        float f2 = ((float) (level - ((level / 2000) * 2000))) / 2000.0f;
        float f3 = 54.0f * f2;
        if (f2 < 0.5f) {
            interpolation = mInterpolator.getInterpolation(lerpInv(0.0f, 0.5f, f2)) * 306.0f;
        } else {
            interpolation = (1.0f - mInterpolator.getInterpolation(lerpInv(0.5f, 1.0f, f2))) * 306.0f;
        }
        float max = Math.max(1.0f, interpolation);
        float f4 = ((float) level) * 1.0E-4f;
        canvas.rotate((((f4 + f4) * 360.0f) - 0.049804688f) + f3, this.mInnerCircleBounds.centerX(), this.mInnerCircleBounds.centerY());
        RectF rectF = this.mInnerCircleBounds;
        if (f2 < 0.5f) {
            f = 0.0f;
        } else {
            f = 306.0f - max;
        }
        canvas.drawArc(rectF, f, max, false, this.mPaint);
        canvas.restore();
    }

    public final int getOpacity() {
        return -1;
    }

    protected final boolean onLevelChange(int i) {
        return true;
    }

    public final void setAlpha(int i) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }
}
