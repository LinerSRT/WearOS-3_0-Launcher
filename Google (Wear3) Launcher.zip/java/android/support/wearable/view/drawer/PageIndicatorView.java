package android.support.wearable.view.drawer;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RadialGradient;
import android.graphics.Shader.TileMode;
import android.support.wearable.R$styleable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import com.google.android.wearable.sysui.R;

@Deprecated
/* compiled from: PG */
public class PageIndicatorView extends View {
    private int mDotColor;
    private int mDotColorSelected;
    private int mDotFadeOutDuration;
    private boolean mDotFadeWhenIdle;
    private final Paint mDotPaint;
    private final Paint mDotPaintSelected;
    private final Paint mDotPaintShadow;
    private final Paint mDotPaintShadowSelected;
    private float mDotRadius;
    private float mDotRadiusSelected;
    private int mDotShadowColor;
    private float mDotShadowDx;
    private float mDotShadowDy;
    private float mDotShadowRadius;
    private int mDotSpacing;
    private int mNumberOfPositions;
    private int mSelectedPosition;

    public PageIndicatorView(Context context) {
        this(context, null);
    }

    private static final void updateDotPaint$ar$ds(Paint paint, Paint paint2, float f, float f2, int i, int i2) {
        paint2.setShader(new RadialGradient(0.0f, 0.0f, f + f2, new int[]{i2, i2, 0}, new float[]{0.0f, f / (f + f2), 1.0f}, TileMode.CLAMP));
        paint.setColor(i);
        paint.setStyle(Style.FILL);
    }

    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.mNumberOfPositions > 1) {
            int paddingLeft = getPaddingLeft();
            int i = this.mDotSpacing;
            int height = getHeight();
            canvas.save();
            canvas.translate(((float) paddingLeft) + (((float) i) / 2.0f), ((float) height) / 2.0f);
            for (paddingLeft = 0; paddingLeft < this.mNumberOfPositions; paddingLeft++) {
                if (paddingLeft == this.mSelectedPosition) {
                    canvas.drawCircle(this.mDotShadowDx, this.mDotShadowDy, this.mDotRadiusSelected + this.mDotShadowRadius, this.mDotPaintShadowSelected);
                    canvas.drawCircle(0.0f, 0.0f, this.mDotRadiusSelected, this.mDotPaintSelected);
                } else {
                    canvas.drawCircle(this.mDotShadowDx, this.mDotShadowDy, this.mDotRadius + this.mDotShadowRadius, this.mDotPaintShadow);
                    canvas.drawCircle(0.0f, 0.0f, this.mDotRadius, this.mDotPaint);
                }
                canvas.translate((float) this.mDotSpacing, 0.0f);
            }
            canvas.restore();
        }
    }

    protected final void onMeasure(int i, int i2) {
        int size;
        int size2;
        if (MeasureSpec.getMode(i) == 1073741824) {
            size = MeasureSpec.getSize(i);
        } else {
            size = ((this.mNumberOfPositions * this.mDotSpacing) + getPaddingLeft()) + getPaddingRight();
        }
        if (MeasureSpec.getMode(i2) == 1073741824) {
            size2 = MeasureSpec.getSize(i2);
        } else {
            float f = this.mDotRadius;
            float f2 = this.mDotShadowRadius;
            f = Math.max(f + f2, this.mDotRadiusSelected + f2);
            size2 = (((int) (((float) ((int) Math.ceil((double) (f + f)))) + this.mDotShadowDy)) + getPaddingTop()) + getPaddingBottom();
        }
        setMeasuredDimension(View.resolveSizeAndState(size, i, 0), View.resolveSizeAndState(size2, i2, 0));
    }

    public PageIndicatorView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PageIndicatorView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.PageIndicatorView, i, R.style.PageIndicatorViewStyle);
        this.mDotSpacing = obtainStyledAttributes.getDimensionPixelOffset(12, 0);
        this.mDotRadius = obtainStyledAttributes.getDimension(6, 0.0f);
        this.mDotRadiusSelected = obtainStyledAttributes.getDimension(7, 0.0f);
        this.mDotColor = obtainStyledAttributes.getColor(0, 0);
        this.mDotColorSelected = obtainStyledAttributes.getColor(1, 0);
        obtainStyledAttributes.getInt(3, 0);
        this.mDotFadeOutDuration = obtainStyledAttributes.getInt(4, 0);
        obtainStyledAttributes.getInt(2, 0);
        this.mDotFadeWhenIdle = obtainStyledAttributes.getBoolean(5, false);
        this.mDotShadowDx = obtainStyledAttributes.getDimension(9, 0.0f);
        this.mDotShadowDy = obtainStyledAttributes.getDimension(10, 0.0f);
        this.mDotShadowRadius = obtainStyledAttributes.getDimension(11, 0.0f);
        this.mDotShadowColor = obtainStyledAttributes.getColor(8, 0);
        obtainStyledAttributes.recycle();
        Paint paint = new Paint(1);
        this.mDotPaint = paint;
        paint.setColor(this.mDotColor);
        paint.setStyle(Style.FILL);
        Paint paint2 = new Paint(1);
        this.mDotPaintSelected = paint2;
        paint2.setColor(this.mDotColorSelected);
        paint2.setStyle(Style.FILL);
        Paint paint3 = new Paint(1);
        this.mDotPaintShadow = paint3;
        Paint paint4 = new Paint(1);
        this.mDotPaintShadowSelected = paint4;
        if (isInEditMode()) {
            this.mNumberOfPositions = 5;
            this.mSelectedPosition = 2;
            this.mDotFadeWhenIdle = false;
        }
        if (this.mDotFadeWhenIdle) {
            animate().alpha(0.0f).setStartDelay(2000).setDuration((long) this.mDotFadeOutDuration).start();
        } else {
            animate().cancel();
            setAlpha(1.0f);
        }
        updateDotPaint$ar$ds(paint, paint3, this.mDotRadius, this.mDotShadowRadius, this.mDotColor, this.mDotShadowColor);
        updateDotPaint$ar$ds(paint2, paint4, this.mDotRadiusSelected, this.mDotShadowRadius, this.mDotColorSelected, this.mDotShadowColor);
    }
}
