package android.support.fragment;

/* compiled from: PG */
public final class R$styleable {
    public static final int[] Fragment = new int[]{16842755, 16842960, 16842961};
    public static final int[] FragmentContainerView = new int[]{16842755, 16842961};
}
