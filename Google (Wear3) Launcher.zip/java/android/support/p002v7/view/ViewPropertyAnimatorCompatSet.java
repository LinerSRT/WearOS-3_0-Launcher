package android.support.p002v7.view;

import android.animation.TimeInterpolator;
import android.support.p000v4.view.ViewPropertyAnimatorCompat;
import android.support.p000v4.view.ViewPropertyAnimatorListener;
import android.support.p000v4.view.ViewPropertyAnimatorListenerAdapter;
import android.view.View;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.view.ViewPropertyAnimatorCompatSet */
public final class ViewPropertyAnimatorCompatSet {
    public final ArrayList mAnimators = new ArrayList();
    private long mDuration = -1;
    private Interpolator mInterpolator;
    public boolean mIsStarted;
    ViewPropertyAnimatorListener mListener;
    private final ViewPropertyAnimatorListenerAdapter mProxyListener = new PG();

    /* renamed from: android.support.v7.view.ViewPropertyAnimatorCompatSet$1 */
    final class PG extends ViewPropertyAnimatorListenerAdapter {
        private int mProxyEndCount = 0;
        private boolean mProxyStarted = false;

        public final void onAnimationEnd$ar$ds() {
            int i = this.mProxyEndCount + 1;
            this.mProxyEndCount = i;
            if (i == ViewPropertyAnimatorCompatSet.this.mAnimators.size()) {
                ViewPropertyAnimatorListener viewPropertyAnimatorListener = ViewPropertyAnimatorCompatSet.this.mListener;
                if (viewPropertyAnimatorListener != null) {
                    viewPropertyAnimatorListener.onAnimationEnd$ar$ds();
                }
                this.mProxyEndCount = 0;
                this.mProxyStarted = false;
                ViewPropertyAnimatorCompatSet.this.mIsStarted = false;
            }
        }

        public final void onAnimationStart$ar$ds() {
            if (!this.mProxyStarted) {
                this.mProxyStarted = true;
                ViewPropertyAnimatorListener viewPropertyAnimatorListener = ViewPropertyAnimatorCompatSet.this.mListener;
                if (viewPropertyAnimatorListener != null) {
                    viewPropertyAnimatorListener.onAnimationStart$ar$ds();
                }
            }
        }
    }

    public final void cancel() {
        if (this.mIsStarted) {
            List list = this.mAnimators;
            int size = list.size();
            for (int i = 0; i < size; i++) {
                ((ViewPropertyAnimatorCompat) list.get(i)).cancel();
            }
            this.mIsStarted = false;
        }
    }

    public final void play$ar$ds(ViewPropertyAnimatorCompat viewPropertyAnimatorCompat) {
        if (!this.mIsStarted) {
            this.mAnimators.add(viewPropertyAnimatorCompat);
        }
    }

    public final void setDuration$ar$ds$382ef02f_0() {
        if (!this.mIsStarted) {
            this.mDuration = 250;
        }
    }

    public final void setInterpolator$ar$ds(Interpolator interpolator) {
        if (!this.mIsStarted) {
            this.mInterpolator = interpolator;
        }
    }

    public final void setListener$ar$ds$2e30dec0_0(ViewPropertyAnimatorListener viewPropertyAnimatorListener) {
        if (!this.mIsStarted) {
            this.mListener = viewPropertyAnimatorListener;
        }
    }

    public final void start() {
        if (!this.mIsStarted) {
            List list = this.mAnimators;
            int size = list.size();
            for (int i = 0; i < size; i++) {
                ViewPropertyAnimatorCompat viewPropertyAnimatorCompat = (ViewPropertyAnimatorCompat) list.get(i);
                long j = this.mDuration;
                if (j >= 0) {
                    viewPropertyAnimatorCompat.setDuration$ar$ds(j);
                }
                TimeInterpolator timeInterpolator = this.mInterpolator;
                if (timeInterpolator != null) {
                    View view = (View) viewPropertyAnimatorCompat.mView.get();
                    if (view != null) {
                        view.animate().setInterpolator(timeInterpolator);
                    }
                }
                if (this.mListener != null) {
                    viewPropertyAnimatorCompat.setListener$ar$ds(this.mProxyListener);
                }
                View view2 = (View) viewPropertyAnimatorCompat.mView.get();
                if (view2 != null) {
                    view2.animate().start();
                }
            }
            this.mIsStarted = true;
        }
    }
}
