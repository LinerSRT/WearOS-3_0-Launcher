package android.support.p002v7.view;

import android.content.Context;
import android.support.p002v7.view.ActionMode.Callback;
import android.support.p002v7.view.menu.MenuWrapperICS;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.collection.SimpleArrayMap;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v7.view.SupportActionModeWrapper */
public final class SupportActionModeWrapper extends ActionMode {
    final Context mContext;
    final ActionMode mWrappedObject;

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.SupportActionModeWrapper$CallbackWrapper */
    public final class CallbackWrapper implements Callback {
        final ArrayList mActionModes = new ArrayList();
        public final Context mContext;
        final SimpleArrayMap mMenus = new SimpleArrayMap();
        public final ActionMode.Callback mWrappedCallback;

        public CallbackWrapper(Context context, ActionMode.Callback callback) {
            this.mContext = context;
            this.mWrappedCallback = callback;
        }

        public final ActionMode getActionModeWrapper(ActionMode actionMode) {
            int size = this.mActionModes.size();
            for (int i = 0; i < size; i++) {
                SupportActionModeWrapper supportActionModeWrapper = (SupportActionModeWrapper) this.mActionModes.get(i);
                if (supportActionModeWrapper != null) {
                    if (supportActionModeWrapper.mWrappedObject == actionMode) {
                        return supportActionModeWrapper;
                    }
                }
            }
            ActionMode supportActionModeWrapper2 = new SupportActionModeWrapper(this.mContext, actionMode);
            this.mActionModes.add(supportActionModeWrapper2);
            return supportActionModeWrapper2;
        }

        public final Menu getMenuWrapper(Menu menu) {
            Menu menu2 = (Menu) this.mMenus.get(menu);
            if (menu2 != null) {
                return menu2;
            }
            menu2 = new MenuWrapperICS(this.mContext, menu);
            this.mMenus.put(menu, menu2);
            return menu2;
        }

        public final boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            throw null;
        }

        public final boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            throw null;
        }

        public final void onDestroyActionMode(ActionMode actionMode) {
            throw null;
        }

        public final void onPrepareActionMode$ar$ds(ActionMode actionMode, Menu menu) {
            throw null;
        }
    }

    public SupportActionModeWrapper(Context context, ActionMode actionMode) {
        this.mContext = context;
        this.mWrappedObject = actionMode;
    }

    public final void finish() {
        this.mWrappedObject.finish();
    }

    public final View getCustomView() {
        return this.mWrappedObject.getCustomView();
    }

    public final Menu getMenu() {
        return new MenuWrapperICS(this.mContext, this.mWrappedObject.getMenu());
    }

    public final MenuInflater getMenuInflater() {
        return this.mWrappedObject.getMenuInflater();
    }

    public final CharSequence getSubtitle() {
        return this.mWrappedObject.getSubtitle();
    }

    public final Object getTag() {
        return this.mWrappedObject.mTag;
    }

    public final CharSequence getTitle() {
        return this.mWrappedObject.getTitle();
    }

    public final boolean getTitleOptionalHint() {
        return this.mWrappedObject.mTitleOptionalHint;
    }

    public final void invalidate() {
        this.mWrappedObject.invalidate();
    }

    public final boolean isTitleOptional() {
        return this.mWrappedObject.isTitleOptional();
    }

    public final void setCustomView(View view) {
        this.mWrappedObject.setCustomView(view);
    }

    public final void setSubtitle(int i) {
        this.mWrappedObject.setSubtitle(i);
    }

    public final void setTag(Object obj) {
        this.mWrappedObject.mTag = obj;
    }

    public final void setTitle(int i) {
        this.mWrappedObject.setTitle(i);
    }

    public final void setTitleOptionalHint(boolean z) {
        this.mWrappedObject.setTitleOptionalHint(z);
    }

    public final void setSubtitle(CharSequence charSequence) {
        this.mWrappedObject.setSubtitle(charSequence);
    }

    public final void setTitle(CharSequence charSequence) {
        this.mWrappedObject.setTitle(charSequence);
    }
}
