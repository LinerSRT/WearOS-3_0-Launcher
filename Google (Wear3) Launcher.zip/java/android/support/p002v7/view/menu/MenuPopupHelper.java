package android.support.p002v7.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.view.Gravity;
import android.view.View;
import android.widget.PopupWindow.OnDismissListener;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.MenuPopupHelper */
public class MenuPopupHelper {
    public View mAnchorView;
    private final Context mContext;
    public int mDropDownGravity = 8388613;
    private boolean mForceShowIcon;
    private final OnDismissListener mInternalOnDismissListener;
    private final MenuBuilder mMenu;
    public OnDismissListener mOnDismissListener;
    private final boolean mOverflowOnly;
    private MenuPopup mPopup;
    private final int mPopupStyleAttr;
    private Callback mPresenterCallback;

    /* renamed from: android.support.v7.view.menu.MenuPopupHelper$1 */
    final class PG implements OnDismissListener {
        public final void onDismiss() {
            MenuPopupHelper.this.onDismiss();
        }
    }

    public MenuPopupHelper(Context context, MenuBuilder menuBuilder, View view, boolean z) {
        this(context, menuBuilder, view, z, R.attr.actionOverflowMenuStyle);
    }

    public final void dismiss() {
        if (isShowing()) {
            this.mPopup.dismiss();
        }
    }

    public final boolean isShowing() {
        MenuPopup menuPopup = this.mPopup;
        return menuPopup != null && menuPopup.isShowing();
    }

    protected void onDismiss() {
        this.mPopup = null;
        OnDismissListener onDismissListener = this.mOnDismissListener;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public final void setForceShowIcon(boolean z) {
        this.mForceShowIcon = z;
        MenuPopup menuPopup = this.mPopup;
        if (menuPopup != null) {
            menuPopup.setForceShowIcon(z);
        }
    }

    public final void setPresenterCallback(Callback callback) {
        this.mPresenterCallback = callback;
        MenuPopup menuPopup = this.mPopup;
        if (menuPopup != null) {
            menuPopup.setCallback(callback);
        }
    }

    public final void showPopup(int i, int i2, boolean z, boolean z2) {
        MenuPopup popup = getPopup();
        popup.setShowTitle(z2);
        if (z) {
            if ((Gravity.getAbsoluteGravity(this.mDropDownGravity, ViewCompat.getLayoutDirection(this.mAnchorView)) & 7) == 5) {
                i -= this.mAnchorView.getWidth();
            }
            popup.setHorizontalOffset(i);
            popup.setVerticalOffset(i2);
            int i3 = (int) ((this.mContext.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            popup.mEpicenterBounds = new Rect(i - i3, i2 - i3, i + i3, i2 + i3);
        }
        popup.show();
    }

    public final boolean tryShow() {
        if (isShowing()) {
            return true;
        }
        if (this.mAnchorView == null) {
            return false;
        }
        showPopup(0, 0, false, false);
        return true;
    }

    public MenuPopupHelper(Context context, MenuBuilder menuBuilder, View view, boolean z, int i) {
        this.mDropDownGravity = 8388611;
        this.mInternalOnDismissListener = new PG();
        this.mContext = context;
        this.mMenu = menuBuilder;
        this.mAnchorView = view;
        this.mOverflowOnly = z;
        this.mPopupStyleAttr = i;
    }

    public final android.support.p002v7.view.menu.MenuPopup getPopup() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Unknown predecessor block by arg (r0_8 android.support.v7.view.menu.MenuPopup) in PHI: PHI: (r0_9 android.support.v7.view.menu.MenuPopup) = (r0_7 android.support.v7.view.menu.MenuPopup), (r0_8 android.support.v7.view.menu.MenuPopup) binds: {(r0_7 android.support.v7.view.menu.MenuPopup)=B:4:0x0031, (r0_8 android.support.v7.view.menu.MenuPopup)=B:5:0x003f}
	at jadx.core.dex.instructions.PhiInsn.replaceArg(PhiInsn.java:79)
	at jadx.core.dex.visitors.ModVisitor.processInvoke(ModVisitor.java:222)
	at jadx.core.dex.visitors.ModVisitor.replaceStep(ModVisitor.java:83)
	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:68)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:60)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
*/
        /*
        r11 = this;
        r0 = r11.mPopup;
        if (r0 != 0) goto L_0x006f;
    L_0x0004:
        r0 = r11.mContext;
        r1 = "window";
        r0 = r0.getSystemService(r1);
        r0 = (android.view.WindowManager) r0;
        r0 = r0.getDefaultDisplay();
        r1 = new android.graphics.Point;
        r1.<init>();
        r0.getRealSize(r1);
        r0 = r1.x;
        r1 = r1.y;
        r0 = java.lang.Math.min(r0, r1);
        r1 = r11.mContext;
        r1 = r1.getResources();
        r2 = 2131165206; // 0x7f070016 float:1.7944623E38 double:1.052935514E-314;
        r1 = r1.getDimensionPixelSize(r2);
        if (r0 < r1) goto L_0x003f;
    L_0x0031:
        r0 = new android.support.v7.view.menu.CascadingMenuPopup;
        r1 = r11.mContext;
        r2 = r11.mAnchorView;
        r3 = r11.mPopupStyleAttr;
        r4 = r11.mOverflowOnly;
        r0.<init>(r1, r2, r3, r4);
        goto L_0x004f;
    L_0x003f:
        r0 = new android.support.v7.view.menu.StandardMenuPopup;
        r6 = r11.mContext;
        r7 = r11.mMenu;
        r8 = r11.mAnchorView;
        r9 = r11.mPopupStyleAttr;
        r10 = r11.mOverflowOnly;
        r5 = r0;
        r5.<init>(r6, r7, r8, r9, r10);
    L_0x004f:
        r1 = r11.mMenu;
        r0.addMenu(r1);
        r1 = r11.mInternalOnDismissListener;
        r0.setOnDismissListener(r1);
        r1 = r11.mAnchorView;
        r0.setAnchorView(r1);
        r1 = r11.mPresenterCallback;
        r0.setCallback(r1);
        r1 = r11.mForceShowIcon;
        r0.setForceShowIcon(r1);
        r1 = r11.mDropDownGravity;
        r0.setGravity(r1);
        r11.mPopup = r0;
    L_0x006f:
        r0 = r11.mPopup;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.view.menu.MenuPopupHelper.getPopup():android.support.v7.view.menu.MenuPopup");
    }
}
