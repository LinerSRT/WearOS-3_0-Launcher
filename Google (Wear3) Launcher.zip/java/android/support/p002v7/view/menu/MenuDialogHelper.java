package android.support.p002v7.view.menu;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.support.p002v7.app.AlertDialog;
import android.support.p002v7.app.AppCompatDialog;
import android.support.p002v7.view.menu.ListMenuPresenter.MenuAdapter;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.View;
import android.view.Window;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.MenuDialogHelper */
final class MenuDialogHelper implements OnKeyListener, OnClickListener, OnDismissListener, Callback {
    public AlertDialog mDialog;
    public final MenuBuilder mMenu;
    ListMenuPresenter mPresenter;

    public MenuDialogHelper(MenuBuilder menuBuilder) {
        this.mMenu = menuBuilder;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.mMenu.performItemAction(((MenuAdapter) this.mPresenter.getAdapter()).getItem(i), 0);
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        this.mPresenter.onCloseMenu(this.mMenu, true);
    }

    public final boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        if (i != 82) {
            if (i == 4) {
                i = 4;
            }
            return this.mMenu.performShortcut(i, keyEvent, 0);
        }
        if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
            Window window = this.mDialog.getWindow();
            if (window != null) {
                View decorView = window.getDecorView();
                if (decorView != null) {
                    DispatcherState keyDispatcherState = decorView.getKeyDispatcherState();
                    if (keyDispatcherState == null) {
                        return this.mMenu.performShortcut(i, keyEvent, 0);
                    }
                    keyDispatcherState.startTracking(keyEvent, this);
                    return true;
                }
            }
            return this.mMenu.performShortcut(i, keyEvent, 0);
        }
        if (keyEvent.getAction() == 1 && !keyEvent.isCanceled()) {
            Window window2 = this.mDialog.getWindow();
            if (window2 != null) {
                View decorView2 = window2.getDecorView();
                if (decorView2 != null) {
                    DispatcherState keyDispatcherState2 = decorView2.getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        if (!keyDispatcherState2.isTracking(keyEvent)) {
                            return this.mMenu.performShortcut(i, keyEvent, 0);
                        }
                        this.mMenu.close(true);
                        dialogInterface.dismiss();
                        return true;
                    }
                }
            }
        }
        return this.mMenu.performShortcut(i, keyEvent, 0);
    }

    public final boolean onOpenSubMenu(MenuBuilder menuBuilder) {
        return false;
    }

    public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        if (z || menuBuilder == this.mMenu) {
            AppCompatDialog appCompatDialog = this.mDialog;
            if (appCompatDialog != null) {
                appCompatDialog.dismiss();
            }
        }
    }
}
