package android.support.p002v7.view.menu;

import android.content.Context;
import android.support.p002v7.app.AlertController.AlertParams;
import android.support.p002v7.app.AlertDialog.Builder;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.support.p002v7.view.menu.MenuView.ItemView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.ListMenuPresenter */
public final class ListMenuPresenter implements MenuPresenter, OnItemClickListener {
    public MenuAdapter mAdapter;
    public Callback mCallback;
    Context mContext;
    public LayoutInflater mInflater;
    MenuBuilder mMenu;
    public ExpandedMenuView mMenuView;

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.ListMenuPresenter$MenuAdapter */
    public final class MenuAdapter extends BaseAdapter {
        private int mExpandedIndex = -1;

        public MenuAdapter() {
            findExpandedIndex();
        }

        final void findExpandedIndex() {
            MenuBuilder menuBuilder = ListMenuPresenter.this.mMenu;
            MenuItemImpl menuItemImpl = menuBuilder.mExpandedItem;
            if (menuItemImpl != null) {
                ArrayList nonActionItems = menuBuilder.getNonActionItems();
                int size = nonActionItems.size();
                for (int i = 0; i < size; i++) {
                    if (((MenuItemImpl) nonActionItems.get(i)) == menuItemImpl) {
                        this.mExpandedIndex = i;
                        return;
                    }
                }
            }
            this.mExpandedIndex = -1;
        }

        public final int getCount() {
            int size = ListMenuPresenter.this.mMenu.getNonActionItems().size();
            return this.mExpandedIndex < 0 ? size : size - 1;
        }

        public final MenuItemImpl getItem(int i) {
            ArrayList nonActionItems = ListMenuPresenter.this.mMenu.getNonActionItems();
            int i2 = this.mExpandedIndex;
            if (i2 >= 0 && i >= i2) {
                i++;
            }
            return (MenuItemImpl) nonActionItems.get(i);
        }

        public final long getItemId(int i) {
            return (long) i;
        }

        public final View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = ListMenuPresenter.this.mInflater.inflate(R.layout.abc_list_menu_item_layout, viewGroup, false);
            }
            ((ItemView) view).initialize$ar$ds(getItem(i));
            return view;
        }

        public final void notifyDataSetChanged() {
            findExpandedIndex();
            super.notifyDataSetChanged();
        }
    }

    public ListMenuPresenter(Context context) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
    }

    public final boolean collapseItemActionView$ar$ds(MenuItemImpl menuItemImpl) {
        return false;
    }

    public final boolean expandItemActionView$ar$ds(MenuItemImpl menuItemImpl) {
        return false;
    }

    public final boolean flagActionItems() {
        return false;
    }

    public final ListAdapter getAdapter() {
        if (this.mAdapter == null) {
            this.mAdapter = new MenuAdapter();
        }
        return this.mAdapter;
    }

    public final void initForMenu(Context context, MenuBuilder menuBuilder) {
        if (this.mContext != null) {
            this.mContext = context;
            if (this.mInflater == null) {
                this.mInflater = LayoutInflater.from(context);
            }
        }
        this.mMenu = menuBuilder;
        MenuAdapter menuAdapter = this.mAdapter;
        if (menuAdapter != null) {
            menuAdapter.notifyDataSetChanged();
        }
    }

    public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        Callback callback = this.mCallback;
        if (callback != null) {
            callback.onCloseMenu(menuBuilder, z);
        }
    }

    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        this.mMenu.performItemAction(this.mAdapter.getItem(i), this, 0);
    }

    public final boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
        if (!subMenuBuilder.hasVisibleItems()) {
            return false;
        }
        MenuDialogHelper menuDialogHelper = new MenuDialogHelper(subMenuBuilder);
        MenuBuilder menuBuilder = menuDialogHelper.mMenu;
        Builder builder = new Builder(menuBuilder.mContext);
        menuDialogHelper.mPresenter = new ListMenuPresenter(builder.f4P.mContext);
        MenuPresenter menuPresenter = menuDialogHelper.mPresenter;
        menuPresenter.mCallback = menuDialogHelper;
        menuDialogHelper.mMenu.addMenuPresenter(menuPresenter);
        ListAdapter adapter = menuDialogHelper.mPresenter.getAdapter();
        AlertParams alertParams = builder.f4P;
        alertParams.mAdapter = adapter;
        alertParams.mOnClickListener = menuDialogHelper;
        View view = menuBuilder.mHeaderView;
        if (view != null) {
            alertParams.mCustomTitleView = view;
        } else {
            builder.setIcon$ar$ds(menuBuilder.mHeaderIcon);
            builder.setTitle$ar$ds(menuBuilder.mHeaderTitle);
        }
        builder.f4P.mOnKeyListener = menuDialogHelper;
        menuDialogHelper.mDialog = builder.create();
        menuDialogHelper.mDialog.setOnDismissListener(menuDialogHelper);
        LayoutParams attributes = menuDialogHelper.mDialog.getWindow().getAttributes();
        attributes.type = 1003;
        attributes.flags |= 131072;
        menuDialogHelper.mDialog.show();
        Callback callback = this.mCallback;
        if (callback != null) {
            callback.onOpenSubMenu(subMenuBuilder);
        }
        return true;
    }

    public final void setCallback(Callback callback) {
        throw null;
    }

    public final void updateMenuView$ar$ds() {
        MenuAdapter menuAdapter = this.mAdapter;
        if (menuAdapter != null) {
            menuAdapter.notifyDataSetChanged();
        }
    }
}
