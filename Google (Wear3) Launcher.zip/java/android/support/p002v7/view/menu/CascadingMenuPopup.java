package android.support.p002v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Handler;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.support.p002v7.widget.ListPopupWindow;
import android.support.p002v7.widget.MenuItemHoverListener;
import android.support.p002v7.widget.MenuPopupWindow;
import android.support.v7.view.menu.CascadingMenuPopup.C00862;
import android.support.v7.view.menu.CascadingMenuPopup.C00873;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.CascadingMenuPopup */
public final class CascadingMenuPopup extends MenuPopup implements MenuPresenter, OnKeyListener, OnDismissListener {
    private View mAnchorView;
    private final OnAttachStateChangeListener mAttachStateChangeListener = new C00862();
    private final Context mContext;
    private int mDropDownGravity = 0;
    private boolean mForceShowIcon;
    final OnGlobalLayoutListener mGlobalLayoutListener = new PG();
    private boolean mHasXOffset;
    private boolean mHasYOffset;
    private int mLastPosition;
    private final MenuItemHoverListener mMenuItemHoverListener = new C00873();
    private final int mMenuMaxWidth;
    private OnDismissListener mOnDismissListener;
    private final boolean mOverflowOnly;
    private final List mPendingMenus = new ArrayList();
    private final int mPopupStyleAttr;
    private Callback mPresenterCallback;
    private int mRawDropDownGravity = 0;
    boolean mShouldCloseImmediately;
    private boolean mShowTitle;
    public final List mShowingMenus = new ArrayList();
    View mShownAnchorView;
    public final Handler mSubMenuHoverHandler;
    ViewTreeObserver mTreeObserver;
    private int mXOffset;
    private int mYOffset;

    /* renamed from: android.support.v7.view.menu.CascadingMenuPopup$1 */
    final class PG implements OnGlobalLayoutListener {
        public final void onGlobalLayout() {
            if (CascadingMenuPopup.this.isShowing() && CascadingMenuPopup.this.mShowingMenus.size() > 0 && !((CascadingMenuInfo) CascadingMenuPopup.this.mShowingMenus.get(0)).window.mModal) {
                View view = CascadingMenuPopup.this.mShownAnchorView;
                if (view != null) {
                    if (view.isShown()) {
                        for (CascadingMenuInfo cascadingMenuInfo : CascadingMenuPopup.this.mShowingMenus) {
                            cascadingMenuInfo.window.show();
                        }
                    }
                }
                CascadingMenuPopup.this.dismiss();
            }
        }
    }

    /* renamed from: android.support.v7.view.menu.CascadingMenuPopup$2 */
    final class C00862 implements OnAttachStateChangeListener {
        public final void onViewAttachedToWindow(View view) {
        }

        public final void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = android.support.p002v7.view.menu.CascadingMenuPopup.this.mTreeObserver;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    android.support.p002v7.view.menu.CascadingMenuPopup.this.mTreeObserver = view.getViewTreeObserver();
                }
                android.support.p002v7.view.menu.CascadingMenuPopup cascadingMenuPopup = android.support.p002v7.view.menu.CascadingMenuPopup.this;
                cascadingMenuPopup.mTreeObserver.removeGlobalOnLayoutListener(cascadingMenuPopup.mGlobalLayoutListener);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    /* renamed from: android.support.v7.view.menu.CascadingMenuPopup$3 */
    public final class C00873 implements MenuItemHoverListener {

        /* renamed from: android.support.v7.view.menu.CascadingMenuPopup$3$1 */
        public final class PG implements Runnable {
            final /* synthetic */ MenuItem val$item;
            final /* synthetic */ MenuBuilder val$menu;
            final /* synthetic */ CascadingMenuInfo val$nextInfo;

            public PG(CascadingMenuInfo cascadingMenuInfo, MenuItem menuItem, MenuBuilder menuBuilder) {
                this.val$nextInfo = cascadingMenuInfo;
                this.val$item = menuItem;
                this.val$menu = menuBuilder;
            }

            public final void run() {
                CascadingMenuInfo cascadingMenuInfo = this.val$nextInfo;
                if (cascadingMenuInfo != null) {
                    CascadingMenuPopup.this.mShouldCloseImmediately = true;
                    cascadingMenuInfo.menu.close(false);
                    CascadingMenuPopup.this.mShouldCloseImmediately = false;
                }
                if (this.val$item.isEnabled() && this.val$item.hasSubMenu()) {
                    this.val$menu.performItemAction(this.val$item, 4);
                }
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.CascadingMenuPopup$CascadingMenuInfo */
    public final class CascadingMenuInfo {
        public final MenuBuilder menu;
        public final int position;
        public final MenuPopupWindow window;

        public CascadingMenuInfo(MenuPopupWindow menuPopupWindow, MenuBuilder menuBuilder, int i) {
            this.window = menuPopupWindow;
            this.menu = menuBuilder;
            this.position = i;
        }

        public final ListView getListView() {
            return this.window.mDropDownList;
        }
    }

    public CascadingMenuPopup(Context context, View view, int i, boolean z) {
        this.mContext = context;
        this.mAnchorView = view;
        this.mPopupStyleAttr = i;
        this.mOverflowOnly = z;
        this.mForceShowIcon = false;
        this.mLastPosition = getInitialMenuPosition();
        Resources resources = context.getResources();
        this.mMenuMaxWidth = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.mSubMenuHoverHandler = new Handler();
    }

    private final int getInitialMenuPosition() {
        return ViewCompat.getLayoutDirection(this.mAnchorView) == 1 ? 0 : 1;
    }

    private final void showMenu(MenuBuilder menuBuilder) {
        CascadingMenuInfo cascadingMenuInfo;
        View view;
        MenuBuilder menuBuilder2 = menuBuilder;
        LayoutInflater from = LayoutInflater.from(this.mContext);
        ListAdapter menuAdapter = new MenuAdapter(menuBuilder2, from, this.mOverflowOnly, R.layout.abc_cascading_menu_item_layout);
        if (!isShowing() && r0.mForceShowIcon) {
            menuAdapter.mForceShowIcon = true;
        } else if (isShowing()) {
            menuAdapter.mForceShowIcon = MenuPopup.shouldPreserveIconSpacing(menuBuilder);
        }
        int measureIndividualMenuWidth$ar$ds = MenuPopup.measureIndividualMenuWidth$ar$ds(menuAdapter, r0.mContext, r0.mMenuMaxWidth);
        ListPopupWindow menuPopupWindow = new MenuPopupWindow(r0.mContext, r0.mPopupStyleAttr);
        menuPopupWindow.mHoverListener = r0.mMenuItemHoverListener;
        menuPopupWindow.mItemClickListener = r0;
        menuPopupWindow.setOnDismissListener(r0);
        menuPopupWindow.mDropDownAnchorView = r0.mAnchorView;
        menuPopupWindow.mDropDownGravity = r0.mDropDownGravity;
        menuPopupWindow.setModal$ar$ds();
        menuPopupWindow.setInputMethodMode$ar$ds();
        menuPopupWindow.setAdapter(menuAdapter);
        menuPopupWindow.setContentWidth(measureIndividualMenuWidth$ar$ds);
        menuPopupWindow.mDropDownGravity = r0.mDropDownGravity;
        if (r0.mShowingMenus.size() > 0) {
            int i;
            MenuItem item;
            List list = r0.mShowingMenus;
            cascadingMenuInfo = (CascadingMenuInfo) list.get(list.size() - 1);
            MenuBuilder menuBuilder3 = cascadingMenuInfo.menu;
            int size = menuBuilder3.size();
            for (i = 0; i < size; i++) {
                item = menuBuilder3.getItem(i);
                if (item.hasSubMenu() && menuBuilder2 == item.getSubMenu()) {
                    break;
                }
            }
            item = null;
            if (item == null) {
                view = null;
            } else {
                MenuAdapter menuAdapter2;
                ListView listView = cascadingMenuInfo.getListView();
                ListAdapter adapter = listView.getAdapter();
                if (adapter instanceof HeaderViewListAdapter) {
                    HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                    i = headerViewListAdapter.getHeadersCount();
                    menuAdapter2 = (MenuAdapter) headerViewListAdapter.getWrappedAdapter();
                } else {
                    menuAdapter2 = (MenuAdapter) adapter;
                    i = 0;
                }
                int count = menuAdapter2.getCount();
                int i2 = 0;
                while (i2 < count) {
                    if (item == menuAdapter2.getItem(i2)) {
                        break;
                    }
                    i2++;
                }
                i2 = -1;
                if (i2 == -1) {
                    view = null;
                } else {
                    i2 = (i2 + i) - listView.getFirstVisiblePosition();
                    view = i2 >= 0 ? i2 >= listView.getChildCount() ? null : listView.getChildAt(i2) : null;
                }
            }
        } else {
            cascadingMenuInfo = null;
            view = cascadingMenuInfo;
        }
        if (view != null) {
            int i3;
            menuPopupWindow.mPopup.setTouchModal(false);
            menuPopupWindow.mPopup.setEnterTransition(null);
            List list2 = r0.mShowingMenus;
            ListView listView2 = ((CascadingMenuInfo) list2.get(list2.size() - 1)).getListView();
            int[] iArr = new int[2];
            listView2.getLocationOnScreen(iArr);
            Rect rect = new Rect();
            r0.mShownAnchorView.getWindowVisibleDisplayFrame(rect);
            if (r0.mLastPosition == 1) {
                if ((iArr[0] + listView2.getWidth()) + measureIndividualMenuWidth$ar$ds > rect.right) {
                    i3 = 0;
                    r0.mLastPosition = i3;
                    menuPopupWindow.mDropDownAnchorView = view;
                    if ((r0.mDropDownGravity & 5) != 5) {
                        measureIndividualMenuWidth$ar$ds = i3 != 0 ? view.getWidth() : -measureIndividualMenuWidth$ar$ds;
                    } else if (i3 != 0) {
                        measureIndividualMenuWidth$ar$ds = -view.getWidth();
                    }
                    menuPopupWindow.mDropDownHorizontalOffset = measureIndividualMenuWidth$ar$ds;
                    menuPopupWindow.mOverlapAnchorSet = true;
                    menuPopupWindow.mOverlapAnchor = true;
                    menuPopupWindow.setVerticalOffset(0);
                }
            } else if (iArr[0] - measureIndividualMenuWidth$ar$ds >= 0) {
                i3 = 0;
                r0.mLastPosition = i3;
                menuPopupWindow.mDropDownAnchorView = view;
                if ((r0.mDropDownGravity & 5) != 5) {
                    if (i3 != 0) {
                    }
                } else if (i3 != 0) {
                    measureIndividualMenuWidth$ar$ds = -view.getWidth();
                }
                menuPopupWindow.mDropDownHorizontalOffset = measureIndividualMenuWidth$ar$ds;
                menuPopupWindow.mOverlapAnchorSet = true;
                menuPopupWindow.mOverlapAnchor = true;
                menuPopupWindow.setVerticalOffset(0);
            }
            i3 = 1;
            r0.mLastPosition = i3;
            menuPopupWindow.mDropDownAnchorView = view;
            if ((r0.mDropDownGravity & 5) != 5) {
                if (i3 != 0) {
                    measureIndividualMenuWidth$ar$ds = -view.getWidth();
                }
            } else if (i3 != 0) {
            }
            menuPopupWindow.mDropDownHorizontalOffset = measureIndividualMenuWidth$ar$ds;
            menuPopupWindow.mOverlapAnchorSet = true;
            menuPopupWindow.mOverlapAnchor = true;
            menuPopupWindow.setVerticalOffset(0);
        } else {
            if (r0.mHasXOffset) {
                menuPopupWindow.mDropDownHorizontalOffset = r0.mXOffset;
            }
            if (r0.mHasYOffset) {
                menuPopupWindow.setVerticalOffset(r0.mYOffset);
            }
            menuPopupWindow.setEpicenterBounds(r0.mEpicenterBounds);
        }
        r0.mShowingMenus.add(new CascadingMenuInfo(menuPopupWindow, menuBuilder2, r0.mLastPosition));
        menuPopupWindow.show();
        ViewGroup viewGroup = menuPopupWindow.mDropDownList;
        viewGroup.setOnKeyListener(r0);
        if (cascadingMenuInfo == null && r0.mShowTitle && menuBuilder2.mHeaderTitle != null) {
            FrameLayout frameLayout = (FrameLayout) from.inflate(R.layout.abc_popup_menu_header_item_layout, viewGroup, false);
            TextView textView = (TextView) frameLayout.findViewById(16908310);
            frameLayout.setEnabled(false);
            textView.setText(menuBuilder2.mHeaderTitle);
            viewGroup.addHeaderView(frameLayout, null, false);
            menuPopupWindow.show();
        }
    }

    public final void addMenu(MenuBuilder menuBuilder) {
        menuBuilder.addMenuPresenter(this, this.mContext);
        if (isShowing()) {
            showMenu(menuBuilder);
        } else {
            this.mPendingMenus.add(menuBuilder);
        }
    }

    protected final boolean closeMenuOnSubMenuOpened() {
        return false;
    }

    public final void dismiss() {
        int size = this.mShowingMenus.size();
        if (size > 0) {
            CascadingMenuInfo[] cascadingMenuInfoArr = (CascadingMenuInfo[]) this.mShowingMenus.toArray(new CascadingMenuInfo[size]);
            for (size--; size >= 0; size--) {
                CascadingMenuInfo cascadingMenuInfo = cascadingMenuInfoArr[size];
                if (cascadingMenuInfo.window.isShowing()) {
                    cascadingMenuInfo.window.dismiss();
                }
            }
        }
    }

    public final boolean flagActionItems() {
        return false;
    }

    public final ListView getListView() {
        if (this.mShowingMenus.isEmpty()) {
            return null;
        }
        List list = this.mShowingMenus;
        return ((CascadingMenuInfo) list.get(list.size() - 1)).getListView();
    }

    public final boolean isShowing() {
        return this.mShowingMenus.size() > 0 && ((CascadingMenuInfo) this.mShowingMenus.get(0)).window.isShowing();
    }

    public final void onDismiss() {
        CascadingMenuInfo cascadingMenuInfo;
        int size = this.mShowingMenus.size();
        for (int i = 0; i < size; i++) {
            cascadingMenuInfo = (CascadingMenuInfo) this.mShowingMenus.get(i);
            if (!cascadingMenuInfo.window.isShowing()) {
                break;
            }
        }
        cascadingMenuInfo = null;
        if (cascadingMenuInfo != null) {
            cascadingMenuInfo.menu.close(false);
        }
    }

    public final boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    public final boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
        for (CascadingMenuInfo cascadingMenuInfo : this.mShowingMenus) {
            if (subMenuBuilder == cascadingMenuInfo.menu) {
                cascadingMenuInfo.getListView().requestFocus();
                return true;
            }
        }
        if (!subMenuBuilder.hasVisibleItems()) {
            return false;
        }
        addMenu(subMenuBuilder);
        Callback callback = this.mPresenterCallback;
        if (callback != null) {
            callback.onOpenSubMenu(subMenuBuilder);
        }
        return true;
    }

    public final void setAnchorView(View view) {
        if (this.mAnchorView != view) {
            this.mAnchorView = view;
            this.mDropDownGravity = Gravity.getAbsoluteGravity(this.mRawDropDownGravity, ViewCompat.getLayoutDirection(view));
        }
    }

    public final void setCallback(Callback callback) {
        this.mPresenterCallback = callback;
    }

    public final void setForceShowIcon(boolean z) {
        this.mForceShowIcon = z;
    }

    public final void setGravity(int i) {
        if (this.mRawDropDownGravity != i) {
            this.mRawDropDownGravity = i;
            this.mDropDownGravity = Gravity.getAbsoluteGravity(i, ViewCompat.getLayoutDirection(this.mAnchorView));
        }
    }

    public final void setHorizontalOffset(int i) {
        this.mHasXOffset = true;
        this.mXOffset = i;
    }

    public final void setOnDismissListener(OnDismissListener onDismissListener) {
        this.mOnDismissListener = onDismissListener;
    }

    public final void setShowTitle(boolean z) {
        this.mShowTitle = z;
    }

    public final void setVerticalOffset(int i) {
        this.mHasYOffset = true;
        this.mYOffset = i;
    }

    public final void show() {
        if (!isShowing()) {
            for (MenuBuilder showMenu : this.mPendingMenus) {
                showMenu(showMenu);
            }
            this.mPendingMenus.clear();
            View view = this.mAnchorView;
            this.mShownAnchorView = view;
            if (view != null) {
                ViewTreeObserver viewTreeObserver = this.mTreeObserver;
                ViewTreeObserver viewTreeObserver2 = view.getViewTreeObserver();
                this.mTreeObserver = viewTreeObserver2;
                if (viewTreeObserver == null) {
                    viewTreeObserver2.addOnGlobalLayoutListener(this.mGlobalLayoutListener);
                }
                this.mShownAnchorView.addOnAttachStateChangeListener(this.mAttachStateChangeListener);
            }
        }
    }

    public final void updateMenuView$ar$ds() {
        for (CascadingMenuInfo listView : this.mShowingMenus) {
            MenuPopup.toMenuAdapter(listView.getListView().getAdapter()).notifyDataSetChanged();
        }
    }

    public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        int size = this.mShowingMenus.size();
        int i = 0;
        while (i < size) {
            if (menuBuilder == ((CascadingMenuInfo) this.mShowingMenus.get(i)).menu) {
                break;
            }
            i++;
        }
        i = -1;
        if (i >= 0) {
            size = i + 1;
            if (size < this.mShowingMenus.size()) {
                ((CascadingMenuInfo) this.mShowingMenus.get(size)).menu.close(false);
            }
            CascadingMenuInfo cascadingMenuInfo = (CascadingMenuInfo) this.mShowingMenus.remove(i);
            cascadingMenuInfo.menu.removeMenuPresenter(this);
            if (this.mShouldCloseImmediately) {
                cascadingMenuInfo.window.mPopup.setExitTransition(null);
                cascadingMenuInfo.window.mPopup.setAnimationStyle(0);
            }
            cascadingMenuInfo.window.dismiss();
            size = this.mShowingMenus.size();
            if (size > 0) {
                this.mLastPosition = ((CascadingMenuInfo) this.mShowingMenus.get(size - 1)).position;
            } else {
                this.mLastPosition = getInitialMenuPosition();
            }
            if (size == 0) {
                dismiss();
                Callback callback = this.mPresenterCallback;
                if (callback != null) {
                    callback.onCloseMenu(menuBuilder, true);
                }
                ViewTreeObserver viewTreeObserver = this.mTreeObserver;
                if (viewTreeObserver != null) {
                    if (viewTreeObserver.isAlive()) {
                        this.mTreeObserver.removeGlobalOnLayoutListener(this.mGlobalLayoutListener);
                    }
                    this.mTreeObserver = null;
                }
                this.mShownAnchorView.removeOnAttachStateChangeListener(this.mAttachStateChangeListener);
                this.mOnDismissListener.onDismiss();
                return;
            }
            if (z) {
                ((CascadingMenuInfo) this.mShowingMenus.get(0)).menu.close(false);
            }
        }
    }
}
