package android.support.p002v7.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow.OnDismissListener;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.MenuPopup */
abstract class MenuPopup implements ShowableListMenu, MenuPresenter, OnItemClickListener {
    public Rect mEpicenterBounds;

    protected static int measureIndividualMenuWidth$ar$ds(ListAdapter listAdapter, Context context, int i) {
        int i2 = 0;
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
        int makeMeasureSpec2 = MeasureSpec.makeMeasureSpec(0, 0);
        int count = listAdapter.getCount();
        ViewGroup viewGroup = null;
        View view = viewGroup;
        int i3 = 0;
        int i4 = 0;
        while (i2 < count) {
            int i5;
            int itemViewType = listAdapter.getItemViewType(i2);
            if (itemViewType != i4) {
                i5 = itemViewType;
            } else {
                i5 = i4;
            }
            if (itemViewType != i4) {
                view = null;
            }
            if (viewGroup == null) {
                viewGroup = new FrameLayout(context);
            }
            view = listAdapter.getView(i2, view, viewGroup);
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i4 = view.getMeasuredWidth();
            if (i4 >= i) {
                return i;
            }
            if (i4 > i3) {
                i3 = i4;
            }
            i2++;
            i4 = i5;
        }
        return i3;
    }

    protected static boolean shouldPreserveIconSpacing(MenuBuilder menuBuilder) {
        int size = menuBuilder.size();
        for (int i = 0; i < size; i++) {
            MenuItem item = menuBuilder.getItem(i);
            if (item.isVisible() && item.getIcon() != null) {
                return true;
            }
        }
        return false;
    }

    protected static MenuAdapter toMenuAdapter(ListAdapter listAdapter) {
        if (listAdapter instanceof HeaderViewListAdapter) {
            return (MenuAdapter) ((HeaderViewListAdapter) listAdapter).getWrappedAdapter();
        }
        return (MenuAdapter) listAdapter;
    }

    public abstract void addMenu(MenuBuilder menuBuilder);

    protected boolean closeMenuOnSubMenuOpened() {
        return true;
    }

    public final boolean collapseItemActionView$ar$ds(MenuItemImpl menuItemImpl) {
        return false;
    }

    public final boolean expandItemActionView$ar$ds(MenuItemImpl menuItemImpl) {
        return false;
    }

    public final void initForMenu(Context context, MenuBuilder menuBuilder) {
    }

    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        ListAdapter listAdapter = (ListAdapter) adapterView.getAdapter();
        MenuPopup.toMenuAdapter(listAdapter).mAdapterMenu.performItemAction((MenuItem) listAdapter.getItem(i), this, true != closeMenuOnSubMenuOpened() ? 4 : 0);
    }

    public abstract void setAnchorView(View view);

    public abstract void setForceShowIcon(boolean z);

    public abstract void setGravity(int i);

    public abstract void setHorizontalOffset(int i);

    public abstract void setOnDismissListener(OnDismissListener onDismissListener);

    public abstract void setShowTitle(boolean z);

    public abstract void setVerticalOffset(int i);
}
