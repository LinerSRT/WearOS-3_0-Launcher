package android.support.p002v7.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p000v4.internal.view.SupportMenuItem;
import android.support.p000v4.view.ActionProvider;
import android.support.p002v7.view.menu.MenuItemImpl.PG;
import android.view.ActionProvider.VisibilityListener;
import android.view.CollapsibleActionView;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import java.lang.reflect.Method;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.MenuItemWrapperICS */
public final class MenuItemWrapperICS extends BaseMenuWrapper implements MenuItem {
    public Method mSetExclusiveCheckableMethod;
    public final SupportMenuItem mWrappedObject;

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$ActionProviderWrapper */
    class ActionProviderWrapper extends ActionProvider {
        final android.view.ActionProvider mInner;

        public ActionProviderWrapper(android.view.ActionProvider actionProvider) {
            this.mInner = actionProvider;
        }

        public final boolean hasSubMenu() {
            return this.mInner.hasSubMenu();
        }

        public final View onCreateActionView() {
            return this.mInner.onCreateActionView();
        }

        public final boolean onPerformDefaultAction() {
            return this.mInner.onPerformDefaultAction();
        }

        public final void onPrepareSubMenu(SubMenu subMenu) {
            this.mInner.onPrepareSubMenu(subMenu);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$ActionProviderWrapperJB */
    final class ActionProviderWrapperJB extends ActionProviderWrapper implements VisibilityListener {
        private PG mListener$ar$class_merging;

        public ActionProviderWrapperJB(android.view.ActionProvider actionProvider) {
            super(actionProvider);
        }

        public final boolean isVisible() {
            return this.mInner.isVisible();
        }

        public final View onCreateActionView(MenuItem menuItem) {
            return this.mInner.onCreateActionView(menuItem);
        }

        public final boolean overridesItemVisibility() {
            return this.mInner.overridesItemVisibility();
        }

        public final void setVisibilityListener$ar$class_merging(PG pg) {
            this.mListener$ar$class_merging = pg;
            this.mInner.setVisibilityListener(this);
        }

        public final void onActionProviderVisibilityChanged(boolean z) {
            PG pg = this.mListener$ar$class_merging;
            if (pg != null) {
                pg.this$0.mMenu.onItemVisibleChanged$ar$ds();
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$CollapsibleActionViewWrapper */
    public final class CollapsibleActionViewWrapper extends FrameLayout {
        public final CollapsibleActionView mWrappedView;

        public CollapsibleActionViewWrapper(View view) {
            super(view.getContext());
            this.mWrappedView = (CollapsibleActionView) view;
            addView(view);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$OnActionExpandListenerWrapper */
    final class OnActionExpandListenerWrapper implements OnActionExpandListener {
        private final OnActionExpandListener mObject;

        public OnActionExpandListenerWrapper(OnActionExpandListener onActionExpandListener) {
            this.mObject = onActionExpandListener;
        }

        public final boolean onMenuItemActionCollapse(MenuItem menuItem) {
            return this.mObject.onMenuItemActionCollapse(MenuItemWrapperICS.this.getMenuItemWrapper(menuItem));
        }

        public final boolean onMenuItemActionExpand(MenuItem menuItem) {
            return this.mObject.onMenuItemActionExpand(MenuItemWrapperICS.this.getMenuItemWrapper(menuItem));
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$OnMenuItemClickListenerWrapper */
    final class OnMenuItemClickListenerWrapper implements OnMenuItemClickListener {
        private final OnMenuItemClickListener mObject;

        public OnMenuItemClickListenerWrapper(OnMenuItemClickListener onMenuItemClickListener) {
            this.mObject = onMenuItemClickListener;
        }

        public final boolean onMenuItemClick(MenuItem menuItem) {
            return this.mObject.onMenuItemClick(MenuItemWrapperICS.this.getMenuItemWrapper(menuItem));
        }
    }

    public MenuItemWrapperICS(Context context, SupportMenuItem supportMenuItem) {
        super(context);
        if (supportMenuItem != null) {
            this.mWrappedObject = supportMenuItem;
            return;
        }
        throw new IllegalArgumentException("Wrapped Object can not be null.");
    }

    public final boolean collapseActionView() {
        return this.mWrappedObject.collapseActionView();
    }

    public final boolean expandActionView() {
        return this.mWrappedObject.expandActionView();
    }

    public final android.view.ActionProvider getActionProvider() {
        ActionProvider supportActionProvider = this.mWrappedObject.getSupportActionProvider();
        return supportActionProvider instanceof ActionProviderWrapper ? ((ActionProviderWrapper) supportActionProvider).mInner : null;
    }

    public final View getActionView() {
        View actionView = this.mWrappedObject.getActionView();
        return actionView instanceof CollapsibleActionViewWrapper ? (View) ((CollapsibleActionViewWrapper) actionView).mWrappedView : actionView;
    }

    public final int getAlphabeticModifiers() {
        return this.mWrappedObject.getAlphabeticModifiers();
    }

    public final char getAlphabeticShortcut() {
        return this.mWrappedObject.getAlphabeticShortcut();
    }

    public final CharSequence getContentDescription() {
        return this.mWrappedObject.getContentDescription();
    }

    public final int getGroupId() {
        return this.mWrappedObject.getGroupId();
    }

    public final Drawable getIcon() {
        return this.mWrappedObject.getIcon();
    }

    public final ColorStateList getIconTintList() {
        return this.mWrappedObject.getIconTintList();
    }

    public final Mode getIconTintMode() {
        return this.mWrappedObject.getIconTintMode();
    }

    public final Intent getIntent() {
        return this.mWrappedObject.getIntent();
    }

    public final int getItemId() {
        return this.mWrappedObject.getItemId();
    }

    public final ContextMenuInfo getMenuInfo() {
        return null;
    }

    public final int getNumericModifiers() {
        return this.mWrappedObject.getNumericModifiers();
    }

    public final char getNumericShortcut() {
        return this.mWrappedObject.getNumericShortcut();
    }

    public final int getOrder() {
        return this.mWrappedObject.getOrder();
    }

    public final SubMenu getSubMenu() {
        return this.mWrappedObject.getSubMenu();
    }

    public final CharSequence getTitle() {
        return this.mWrappedObject.getTitle();
    }

    public final CharSequence getTitleCondensed() {
        return this.mWrappedObject.getTitleCondensed();
    }

    public final CharSequence getTooltipText() {
        return this.mWrappedObject.getTooltipText();
    }

    public final boolean hasSubMenu() {
        return this.mWrappedObject.hasSubMenu();
    }

    public final boolean isActionViewExpanded() {
        return this.mWrappedObject.isActionViewExpanded();
    }

    public final boolean isCheckable() {
        return this.mWrappedObject.isCheckable();
    }

    public final boolean isChecked() {
        return this.mWrappedObject.isChecked();
    }

    public final boolean isEnabled() {
        return this.mWrappedObject.isEnabled();
    }

    public final boolean isVisible() {
        return this.mWrappedObject.isVisible();
    }

    public final MenuItem setActionProvider(android.view.ActionProvider actionProvider) {
        ActionProvider actionProviderWrapperJB = new ActionProviderWrapperJB(actionProvider);
        SupportMenuItem supportMenuItem = this.mWrappedObject;
        if (actionProvider == null) {
            actionProviderWrapperJB = null;
        }
        supportMenuItem.setSupportActionProvider$ar$ds(actionProviderWrapperJB);
        return this;
    }

    public final MenuItem setActionView(int i) {
        this.mWrappedObject.setActionView(i);
        View actionView = this.mWrappedObject.getActionView();
        if (actionView instanceof CollapsibleActionView) {
            this.mWrappedObject.setActionView(new CollapsibleActionViewWrapper(actionView));
        }
        return this;
    }

    public final MenuItem setAlphabeticShortcut(char c) {
        this.mWrappedObject.setAlphabeticShortcut(c);
        return this;
    }

    public final MenuItem setCheckable(boolean z) {
        this.mWrappedObject.setCheckable(z);
        return this;
    }

    public final MenuItem setChecked(boolean z) {
        this.mWrappedObject.setChecked(z);
        return this;
    }

    public final MenuItem setContentDescription(CharSequence charSequence) {
        this.mWrappedObject.setContentDescription$ar$ds(charSequence);
        return this;
    }

    public final MenuItem setEnabled(boolean z) {
        this.mWrappedObject.setEnabled(z);
        return this;
    }

    public final MenuItem setIcon(int i) {
        this.mWrappedObject.setIcon(i);
        return this;
    }

    public final MenuItem setIconTintList(ColorStateList colorStateList) {
        this.mWrappedObject.setIconTintList(colorStateList);
        return this;
    }

    public final MenuItem setIconTintMode(Mode mode) {
        this.mWrappedObject.setIconTintMode(mode);
        return this;
    }

    public final MenuItem setIntent(Intent intent) {
        this.mWrappedObject.setIntent(intent);
        return this;
    }

    public final MenuItem setNumericShortcut(char c) {
        this.mWrappedObject.setNumericShortcut(c);
        return this;
    }

    public final MenuItem setOnActionExpandListener(OnActionExpandListener onActionExpandListener) {
        OnActionExpandListener onActionExpandListenerWrapper;
        SupportMenuItem supportMenuItem = this.mWrappedObject;
        if (onActionExpandListener != null) {
            onActionExpandListenerWrapper = new OnActionExpandListenerWrapper(onActionExpandListener);
        } else {
            onActionExpandListenerWrapper = null;
        }
        supportMenuItem.setOnActionExpandListener(onActionExpandListenerWrapper);
        return this;
    }

    public final MenuItem setOnMenuItemClickListener(OnMenuItemClickListener onMenuItemClickListener) {
        OnMenuItemClickListener onMenuItemClickListenerWrapper;
        SupportMenuItem supportMenuItem = this.mWrappedObject;
        if (onMenuItemClickListener != null) {
            onMenuItemClickListenerWrapper = new OnMenuItemClickListenerWrapper(onMenuItemClickListener);
        } else {
            onMenuItemClickListenerWrapper = null;
        }
        supportMenuItem.setOnMenuItemClickListener(onMenuItemClickListenerWrapper);
        return this;
    }

    public final MenuItem setShortcut(char c, char c2) {
        this.mWrappedObject.setShortcut(c, c2);
        return this;
    }

    public final void setShowAsAction(int i) {
        this.mWrappedObject.setShowAsAction(i);
    }

    public final MenuItem setShowAsActionFlags(int i) {
        this.mWrappedObject.setShowAsActionFlags(i);
        return this;
    }

    public final MenuItem setTitle(int i) {
        this.mWrappedObject.setTitle(i);
        return this;
    }

    public final MenuItem setTitleCondensed(CharSequence charSequence) {
        this.mWrappedObject.setTitleCondensed(charSequence);
        return this;
    }

    public final MenuItem setTooltipText(CharSequence charSequence) {
        this.mWrappedObject.setTooltipText$ar$ds(charSequence);
        return this;
    }

    public final MenuItem setVisible(boolean z) {
        MenuItem menuItem = this.mWrappedObject;
        menuItem.setVisible(z);
        return menuItem;
    }

    public final MenuItem setAlphabeticShortcut(char c, int i) {
        this.mWrappedObject.setAlphabeticShortcut(c, i);
        return this;
    }

    public final MenuItem setIcon(Drawable drawable) {
        this.mWrappedObject.setIcon(drawable);
        return this;
    }

    public final MenuItem setNumericShortcut(char c, int i) {
        this.mWrappedObject.setNumericShortcut(c, i);
        return this;
    }

    public final MenuItem setShortcut(char c, char c2, int i, int i2) {
        this.mWrappedObject.setShortcut(c, c2, i, i2);
        return this;
    }

    public final MenuItem setTitle(CharSequence charSequence) {
        this.mWrappedObject.setTitle(charSequence);
        return this;
    }

    public final MenuItem setActionView(View view) {
        if (view instanceof CollapsibleActionView) {
            view = new CollapsibleActionViewWrapper(view);
        }
        this.mWrappedObject.setActionView(view);
        return this;
    }
}
