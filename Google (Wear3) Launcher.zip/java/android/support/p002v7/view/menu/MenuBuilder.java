package android.support.p002v7.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.p000v4.internal.view.SupportMenu;
import android.support.p000v4.view.ActionProvider;
import android.util.SparseArray;
import android.view.KeyCharacterMap.KeyData;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.core.content.ContextCompat.Api21Impl;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.MenuBuilder */
public class MenuBuilder implements SupportMenu {
    private static final int[] sCategoryToOrder = new int[]{1, 4, 5, 3, 2, 0};
    public final ArrayList mActionItems;
    public Callback mCallback = this;
    public final Context mContext;
    private int mDefaultShowAsAction = 0;
    public MenuItemImpl mExpandedItem;
    private boolean mGroupDividerEnabled = false;
    Drawable mHeaderIcon;
    CharSequence mHeaderTitle;
    View mHeaderView;
    private boolean mIsActionItemsStale;
    private boolean mIsClosing = false;
    private boolean mIsVisibleItemsStale;
    public final ArrayList mItems;
    private boolean mItemsChangedWhileDispatchPrevented = false;
    private final ArrayList mNonActionItems;
    public boolean mOverrideVisibleItems;
    private final CopyOnWriteArrayList mPresenters = new CopyOnWriteArrayList();
    private boolean mPreventDispatchingItemsChanged = false;
    private boolean mQwertyMode;
    private final Resources mResources;
    private final boolean mShortcutsVisible;
    private boolean mStructureChangedWhileDispatchPrevented = false;
    private final ArrayList mTempShortcutItemList = new ArrayList();
    private final ArrayList mVisibleItems;

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuBuilder$Callback */
    public interface Callback {
        boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem);

        void onMenuModeChange$ar$ds();
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuBuilder$ItemInvoker */
    public interface ItemInvoker {
        boolean invokeItem(MenuItemImpl menuItemImpl);
    }

    public MenuBuilder(Context context) {
        boolean z = false;
        this.mContext = context;
        Resources resources = context.getResources();
        this.mResources = resources;
        this.mItems = new ArrayList();
        this.mVisibleItems = new ArrayList();
        this.mIsVisibleItemsStale = true;
        this.mActionItems = new ArrayList();
        this.mNonActionItems = new ArrayList();
        this.mIsActionItemsStale = true;
        if (resources.getConfiguration().keyboard != 1 && ViewConfiguration.get(context).shouldShowMenuShortcutsWhenKeyboardPresent()) {
            z = true;
        }
        this.mShortcutsVisible = z;
    }

    private final void removeItemAtInt(int i, boolean z) {
        if (i >= 0) {
            if (i < this.mItems.size()) {
                this.mItems.remove(i);
                if (z) {
                    onItemsChanged(true);
                }
            }
        }
    }

    public final MenuItem add(int i) {
        return addInternal(0, 0, 0, this.mResources.getString(i));
    }

    public final int addIntentOptions(int i, int i2, int i3, ComponentName componentName, Intent[] intentArr, Intent intent, int i4, MenuItem[] menuItemArr) {
        int size;
        PackageManager packageManager = this.mContext.getPackageManager();
        int i5 = 0;
        List queryIntentActivityOptions = packageManager.queryIntentActivityOptions(componentName, intentArr, intent, 0);
        if (queryIntentActivityOptions != null) {
            size = queryIntentActivityOptions.size();
        } else {
            size = 0;
        }
        if ((i4 & 1) == 0) {
            removeGroup(i);
        }
        while (i5 < size) {
            ResolveInfo resolveInfo = (ResolveInfo) queryIntentActivityOptions.get(i5);
            Intent intent2 = new Intent(resolveInfo.specificIndex < 0 ? intent : intentArr[resolveInfo.specificIndex]);
            intent2.setComponent(new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name));
            MenuItem addInternal = addInternal(i, i2, i3, resolveInfo.loadLabel(packageManager));
            addInternal.setIcon(resolveInfo.loadIcon(packageManager));
            ((MenuItemImpl) addInternal).mIntent = intent2;
            if (menuItemArr != null && resolveInfo.specificIndex >= 0) {
                menuItemArr[resolveInfo.specificIndex] = addInternal;
            }
            i5++;
        }
        return size;
    }

    public final void addMenuPresenter(MenuPresenter menuPresenter) {
        addMenuPresenter(menuPresenter, this.mContext);
    }

    public final SubMenu addSubMenu(int i) {
        return addSubMenu(0, 0, 0, this.mResources.getString(i));
    }

    public final void clear() {
        MenuItemImpl menuItemImpl = this.mExpandedItem;
        if (menuItemImpl != null) {
            collapseItemActionView(menuItemImpl);
        }
        this.mItems.clear();
        onItemsChanged(true);
    }

    public final void clearHeader() {
        this.mHeaderIcon = null;
        this.mHeaderTitle = null;
        this.mHeaderView = null;
        onItemsChanged(false);
    }

    public final void close() {
        close(true);
    }

    public boolean collapseItemActionView(MenuItemImpl menuItemImpl) {
        boolean z = false;
        if (!this.mPresenters.isEmpty()) {
            if (this.mExpandedItem == menuItemImpl) {
                stopDispatchingItemsChanged();
                Iterator it = this.mPresenters.iterator();
                while (it.hasNext()) {
                    WeakReference weakReference = (WeakReference) it.next();
                    MenuPresenter menuPresenter = (MenuPresenter) weakReference.get();
                    if (menuPresenter == null) {
                        this.mPresenters.remove(weakReference);
                    } else {
                        z = menuPresenter.collapseItemActionView$ar$ds(menuItemImpl);
                        if (z) {
                            break;
                        }
                    }
                }
                startDispatchingItemsChanged();
                if (z) {
                    this.mExpandedItem = null;
                }
                return z;
            }
        }
        return false;
    }

    public boolean dispatchMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
        Callback callback = this.mCallback;
        return callback != null && callback.onMenuItemSelected(menuBuilder, menuItem);
    }

    public boolean expandItemActionView(MenuItemImpl menuItemImpl) {
        boolean z = false;
        if (this.mPresenters.isEmpty()) {
            return false;
        }
        stopDispatchingItemsChanged();
        Iterator it = this.mPresenters.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            MenuPresenter menuPresenter = (MenuPresenter) weakReference.get();
            if (menuPresenter == null) {
                this.mPresenters.remove(weakReference);
            } else {
                z = menuPresenter.expandItemActionView$ar$ds(menuItemImpl);
                if (z) {
                    break;
                }
            }
        }
        startDispatchingItemsChanged();
        if (z) {
            this.mExpandedItem = menuItemImpl;
        }
        return z;
    }

    public final MenuItem findItem(int i) {
        int size = size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItemImpl menuItemImpl = (MenuItemImpl) this.mItems.get(i2);
            if (menuItemImpl.mId == i) {
                return menuItemImpl;
            }
            if (menuItemImpl.hasSubMenu()) {
                MenuItem findItem = menuItemImpl.mSubMenu.findItem(i);
                if (findItem != null) {
                    return findItem;
                }
            }
        }
        return null;
    }

    final MenuItemImpl findItemWithShortcutForKey(int i, KeyEvent keyEvent) {
        ArrayList arrayList = this.mTempShortcutItemList;
        arrayList.clear();
        findItemsWithShortcutForKey(arrayList, i, keyEvent);
        if (arrayList.isEmpty()) {
            return null;
        }
        int metaState = keyEvent.getMetaState();
        KeyData keyData = new KeyData();
        keyEvent.getKeyData(keyData);
        int size = arrayList.size();
        if (size == 1) {
            return (MenuItemImpl) arrayList.get(0);
        }
        boolean isQwertyMode = isQwertyMode();
        int i2 = 0;
        while (i2 < size) {
            char c;
            MenuItemImpl menuItemImpl = (MenuItemImpl) arrayList.get(i2);
            if (isQwertyMode) {
                c = menuItemImpl.mShortcutAlphabeticChar;
            } else {
                c = menuItemImpl.mShortcutNumericChar;
            }
            if (!(c == keyData.meta[0] && (metaState & 2) == 0) && (c != keyData.meta[2] || (metaState & 2) == 0)) {
                if (isQwertyMode && c == '\b') {
                    if (i != 67) {
                    }
                }
                i2++;
            }
            return menuItemImpl;
        }
        return null;
    }

    final void findItemsWithShortcutForKey(List list, int i, KeyEvent keyEvent) {
        boolean isQwertyMode = isQwertyMode();
        int modifiers = keyEvent.getModifiers();
        KeyData keyData = new KeyData();
        if (!keyEvent.getKeyData(keyData)) {
            if (i != 67) {
                return;
            }
        }
        int size = this.mItems.size();
        for (int i2 = 0; i2 < size; i2++) {
            int i3;
            MenuItemImpl menuItemImpl = (MenuItemImpl) this.mItems.get(i2);
            if (menuItemImpl.hasSubMenu()) {
                menuItemImpl.mSubMenu.findItemsWithShortcutForKey(list, i, keyEvent);
            }
            char c;
            if (isQwertyMode) {
                c = menuItemImpl.mShortcutAlphabeticChar;
            } else {
                c = menuItemImpl.mShortcutNumericChar;
            }
            if (isQwertyMode) {
                i3 = menuItemImpl.mShortcutAlphabeticModifiers;
            } else {
                i3 = menuItemImpl.mShortcutNumericModifiers;
            }
            if ((modifiers & 69647) == (i3 & 69647) && c != '\u0000' && ((c == keyData.meta[0] || c == keyData.meta[2] || (isQwertyMode && c == '\b' && i == 67)) && menuItemImpl.isEnabled())) {
                list.add(menuItemImpl);
            }
        }
    }

    public final void flagActionItems() {
        ArrayList visibleItems = getVisibleItems();
        if (this.mIsActionItemsStale) {
            Iterator it = this.mPresenters.iterator();
            int i = 0;
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                MenuPresenter menuPresenter = (MenuPresenter) weakReference.get();
                if (menuPresenter == null) {
                    this.mPresenters.remove(weakReference);
                } else {
                    i |= menuPresenter.flagActionItems();
                }
            }
            if (i != 0) {
                this.mActionItems.clear();
                this.mNonActionItems.clear();
                int size = visibleItems.size();
                for (i = 0; i < size; i++) {
                    MenuItemImpl menuItemImpl = (MenuItemImpl) visibleItems.get(i);
                    if (menuItemImpl.isActionButton()) {
                        this.mActionItems.add(menuItemImpl);
                    } else {
                        this.mNonActionItems.add(menuItemImpl);
                    }
                }
            } else {
                this.mActionItems.clear();
                this.mNonActionItems.clear();
                this.mNonActionItems.addAll(getVisibleItems());
            }
            this.mIsActionItemsStale = false;
        }
    }

    protected String getActionViewStatesKey() {
        return "android:menu:actionviewstates";
    }

    public final MenuItem getItem(int i) {
        return (MenuItem) this.mItems.get(i);
    }

    public final ArrayList getNonActionItems() {
        flagActionItems();
        return this.mNonActionItems;
    }

    public MenuBuilder getRootMenu() {
        return this;
    }

    public final ArrayList getVisibleItems() {
        if (!this.mIsVisibleItemsStale) {
            return this.mVisibleItems;
        }
        this.mVisibleItems.clear();
        int size = this.mItems.size();
        for (int i = 0; i < size; i++) {
            MenuItemImpl menuItemImpl = (MenuItemImpl) this.mItems.get(i);
            if (menuItemImpl.isVisible()) {
                this.mVisibleItems.add(menuItemImpl);
            }
        }
        this.mIsVisibleItemsStale = false;
        this.mIsActionItemsStale = true;
        return this.mVisibleItems;
    }

    public final boolean hasVisibleItems() {
        if (this.mOverrideVisibleItems) {
            return true;
        }
        int size = size();
        for (int i = 0; i < size; i++) {
            if (((MenuItemImpl) this.mItems.get(i)).isVisible()) {
                return true;
            }
        }
        return false;
    }

    public boolean isGroupDividerEnabled() {
        return this.mGroupDividerEnabled;
    }

    public boolean isQwertyMode() {
        return this.mQwertyMode;
    }

    public final boolean isShortcutKey(int i, KeyEvent keyEvent) {
        return findItemWithShortcutForKey(i, keyEvent) != null;
    }

    public boolean isShortcutsVisible() {
        return this.mShortcutsVisible;
    }

    final void onItemActionRequestChanged$ar$ds() {
        this.mIsActionItemsStale = true;
        onItemsChanged(true);
    }

    final void onItemVisibleChanged$ar$ds() {
        this.mIsVisibleItemsStale = true;
        onItemsChanged(true);
    }

    public final boolean performIdentifierAction(int i, int i2) {
        return performItemAction(findItem(i), i2);
    }

    public final boolean performItemAction(MenuItem menuItem, int i) {
        return performItemAction(menuItem, null, i);
    }

    public final boolean performShortcut(int i, KeyEvent keyEvent, int i2) {
        boolean performItemAction;
        MenuItem findItemWithShortcutForKey = findItemWithShortcutForKey(i, keyEvent);
        if (findItemWithShortcutForKey != null) {
            performItemAction = performItemAction(findItemWithShortcutForKey, i2);
        } else {
            performItemAction = false;
        }
        if ((i2 & 2) != 0) {
            close(true);
        }
        return performItemAction;
    }

    public final void removeMenuPresenter(MenuPresenter menuPresenter) {
        Iterator it = this.mPresenters.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            MenuPresenter menuPresenter2 = (MenuPresenter) weakReference.get();
            if (menuPresenter2 == null || menuPresenter2 == menuPresenter) {
                this.mPresenters.remove(weakReference);
            }
        }
    }

    public final void restoreActionViewStates(Bundle bundle) {
        SparseArray sparseParcelableArray = bundle.getSparseParcelableArray(getActionViewStatesKey());
        int size = size();
        for (int i = 0; i < size; i++) {
            MenuItem item = getItem(i);
            View actionView = item.getActionView();
            if (!(actionView == null || actionView.getId() == -1)) {
                actionView.restoreHierarchyState(sparseParcelableArray);
            }
            if (item.hasSubMenu()) {
                ((SubMenuBuilder) item.getSubMenu()).restoreActionViewStates(bundle);
            }
        }
        int i2 = bundle.getInt("android:menu:expandedactionview");
        if (i2 > 0) {
            MenuItem findItem = findItem(i2);
            if (findItem != null) {
                findItem.expandActionView();
            }
        }
    }

    public final void saveActionViewStates(Bundle bundle) {
        int size = size();
        SparseArray sparseArray = null;
        for (int i = 0; i < size; i++) {
            MenuItem item = getItem(i);
            View actionView = item.getActionView();
            if (!(actionView == null || actionView.getId() == -1)) {
                if (sparseArray == null) {
                    sparseArray = new SparseArray();
                }
                actionView.saveHierarchyState(sparseArray);
                if (item.isActionViewExpanded()) {
                    bundle.putInt("android:menu:expandedactionview", item.getItemId());
                }
            }
            if (item.hasSubMenu()) {
                ((SubMenuBuilder) item.getSubMenu()).saveActionViewStates(bundle);
            }
        }
        if (sparseArray != null) {
            bundle.putSparseParcelableArray(getActionViewStatesKey(), sparseArray);
        }
    }

    public void setCallback(Callback callback) {
        this.mCallback = callback;
    }

    public final void setDefaultShowAsAction$ar$ds() {
        this.mDefaultShowAsAction = 1;
    }

    public final void setGroupCheckable(int i, boolean z, boolean z2) {
        int size = this.mItems.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItemImpl menuItemImpl = (MenuItemImpl) this.mItems.get(i2);
            if (menuItemImpl.mGroup == i) {
                menuItemImpl.setExclusiveCheckable(z2);
                menuItemImpl.setCheckable(z);
            }
        }
    }

    public void setGroupDividerEnabled(boolean z) {
        this.mGroupDividerEnabled = z;
    }

    public final void setGroupEnabled(int i, boolean z) {
        int size = this.mItems.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItemImpl menuItemImpl = (MenuItemImpl) this.mItems.get(i2);
            if (menuItemImpl.mGroup == i) {
                menuItemImpl.setEnabled(z);
            }
        }
    }

    public final void setGroupVisible(int i, boolean z) {
        int size = this.mItems.size();
        Object obj = null;
        for (int i2 = 0; i2 < size; i2++) {
            MenuItemImpl menuItemImpl = (MenuItemImpl) this.mItems.get(i2);
            if (menuItemImpl.mGroup == i && menuItemImpl.setVisibleInt(z)) {
                obj = 1;
            }
        }
        if (obj != null) {
            onItemsChanged(true);
        }
    }

    public void setQwertyMode(boolean z) {
        this.mQwertyMode = z;
        onItemsChanged(false);
    }

    public final int size() {
        return this.mItems.size();
    }

    public final void startDispatchingItemsChanged() {
        this.mPreventDispatchingItemsChanged = false;
        if (this.mItemsChangedWhileDispatchPrevented) {
            this.mItemsChangedWhileDispatchPrevented = false;
            onItemsChanged(this.mStructureChangedWhileDispatchPrevented);
        }
    }

    public final void stopDispatchingItemsChanged() {
        if (!this.mPreventDispatchingItemsChanged) {
            this.mPreventDispatchingItemsChanged = true;
            this.mItemsChangedWhileDispatchPrevented = false;
            this.mStructureChangedWhileDispatchPrevented = false;
        }
    }

    public final MenuItem add(int i, int i2, int i3, int i4) {
        return addInternal(i, i2, i3, this.mResources.getString(i4));
    }

    protected final MenuItem addInternal(int i, int i2, int i3, CharSequence charSequence) {
        int i4 = i3 >> 16;
        if (i4 < 0 || i4 >= 6) {
            throw new IllegalArgumentException("order does not contain a valid category.");
        }
        i4 = (sCategoryToOrder[i4] << 16) | ((char) i3);
        MenuItem menuItemImpl = new MenuItemImpl(this, i, i2, i3, i4, charSequence, this.mDefaultShowAsAction);
        ArrayList arrayList = this.mItems;
        for (i2 = arrayList.size() - 1; i2 >= 0; i2--) {
            if (((MenuItemImpl) arrayList.get(i2)).mOrdering <= i4) {
                i2++;
                break;
            }
        }
        i2 = 0;
        arrayList.add(i2, menuItemImpl);
        onItemsChanged(true);
        return menuItemImpl;
    }

    public final void addMenuPresenter(MenuPresenter menuPresenter, Context context) {
        this.mPresenters.add(new WeakReference(menuPresenter));
        menuPresenter.initForMenu(context, this);
        this.mIsActionItemsStale = true;
    }

    public final SubMenu addSubMenu(int i, int i2, int i3, int i4) {
        return addSubMenu(i, i2, i3, this.mResources.getString(i4));
    }

    public final void close(boolean z) {
        if (!this.mIsClosing) {
            this.mIsClosing = true;
            Iterator it = this.mPresenters.iterator();
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                MenuPresenter menuPresenter = (MenuPresenter) weakReference.get();
                if (menuPresenter == null) {
                    this.mPresenters.remove(weakReference);
                } else {
                    menuPresenter.onCloseMenu(this, z);
                }
            }
            this.mIsClosing = false;
        }
    }

    public final void onItemsChanged(boolean z) {
        if (this.mPreventDispatchingItemsChanged) {
            this.mItemsChangedWhileDispatchPrevented = true;
            if (z) {
                this.mStructureChangedWhileDispatchPrevented = true;
                return;
            }
        }
        if (z) {
            this.mIsVisibleItemsStale = true;
            this.mIsActionItemsStale = true;
        }
        if (!this.mPresenters.isEmpty()) {
            stopDispatchingItemsChanged();
            Iterator it = this.mPresenters.iterator();
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                MenuPresenter menuPresenter = (MenuPresenter) weakReference.get();
                if (menuPresenter == null) {
                    this.mPresenters.remove(weakReference);
                } else {
                    menuPresenter.updateMenuView$ar$ds();
                }
            }
            startDispatchingItemsChanged();
        }
    }

    public final boolean performItemAction(MenuItem menuItem, MenuPresenter menuPresenter, int i) {
        MenuItemImpl menuItemImpl = (MenuItemImpl) menuItem;
        if (menuItemImpl != null) {
            if (menuItemImpl.isEnabled()) {
                boolean invoke = menuItemImpl.invoke();
                ActionProvider actionProvider = menuItemImpl.mActionProvider;
                Object obj = (actionProvider == null || !actionProvider.hasSubMenu()) ? null : 1;
                if (menuItemImpl.hasCollapsibleActionView()) {
                    invoke |= menuItemImpl.expandActionView();
                    if (invoke) {
                        close(true);
                        return true;
                    }
                } else {
                    int i2;
                    if (!menuItemImpl.hasSubMenu()) {
                        if (obj == null) {
                            if ((i & 1) == 0) {
                                close(true);
                                return invoke;
                            }
                        }
                    }
                    if ((i & 4) == 0) {
                        close(false);
                    }
                    if (!menuItemImpl.hasSubMenu()) {
                        menuItemImpl.setSubMenu(new SubMenuBuilder(this.mContext, this, menuItemImpl));
                    }
                    SubMenuBuilder subMenuBuilder = menuItemImpl.mSubMenu;
                    if (obj != null) {
                        actionProvider.onPrepareSubMenu(subMenuBuilder);
                    }
                    if (this.mPresenters.isEmpty()) {
                        i2 = 0;
                    } else {
                        if (menuPresenter != null) {
                            i2 = menuPresenter.onSubMenuSelected(subMenuBuilder);
                        } else {
                            i2 = false;
                        }
                        Iterator it = this.mPresenters.iterator();
                        while (it.hasNext()) {
                            WeakReference weakReference = (WeakReference) it.next();
                            MenuPresenter menuPresenter2 = (MenuPresenter) weakReference.get();
                            if (menuPresenter2 == null) {
                                this.mPresenters.remove(weakReference);
                            } else if (i2 == 0) {
                                i2 = menuPresenter2.onSubMenuSelected(subMenuBuilder);
                            }
                        }
                    }
                    invoke |= i2;
                    if (!invoke) {
                        close(true);
                        return false;
                    }
                }
                return invoke;
            }
        }
        return false;
    }

    public final void removeGroup(int i) {
        int size = size();
        int i2 = 0;
        while (i2 < size) {
            if (((MenuItemImpl) this.mItems.get(i2)).mGroup == i) {
                break;
            }
            i2++;
        }
        i2 = -1;
        if (i2 >= 0) {
            size = this.mItems.size() - i2;
            int i3 = 0;
            while (true) {
                int i4 = i3 + 1;
                if (i3 >= size || ((MenuItemImpl) this.mItems.get(i2)).mGroup != i) {
                    onItemsChanged(true);
                } else {
                    removeItemAtInt(i2, false);
                    i3 = i4;
                }
            }
            onItemsChanged(true);
        }
    }

    public final void removeItem(int i) {
        int size = size();
        int i2 = 0;
        while (i2 < size) {
            if (((MenuItemImpl) this.mItems.get(i2)).mId == i) {
                break;
            }
            i2++;
        }
        i2 = -1;
        removeItemAtInt(i2, true);
    }

    public final MenuItem add(int i, int i2, int i3, CharSequence charSequence) {
        return addInternal(i, i2, i3, charSequence);
    }

    public final SubMenu addSubMenu(int i, int i2, int i3, CharSequence charSequence) {
        MenuItemImpl menuItemImpl = (MenuItemImpl) addInternal(i, i2, i3, charSequence);
        SubMenu subMenuBuilder = new SubMenuBuilder(this.mContext, this, menuItemImpl);
        menuItemImpl.setSubMenu(subMenuBuilder);
        return subMenuBuilder;
    }

    public final void setHeaderInternal(int i, CharSequence charSequence, int i2, Drawable drawable, View view) {
        Resources resources = this.mResources;
        if (view != null) {
            this.mHeaderView = view;
            this.mHeaderTitle = null;
            this.mHeaderIcon = null;
        } else {
            if (i > 0) {
                this.mHeaderTitle = resources.getText(i);
            } else if (charSequence != null) {
                this.mHeaderTitle = charSequence;
            }
            if (i2 > 0) {
                this.mHeaderIcon = Api21Impl.getDrawable(this.mContext, i2);
            } else if (drawable != null) {
                this.mHeaderIcon = drawable;
            }
            this.mHeaderView = null;
        }
        onItemsChanged(false);
    }

    public final MenuItem add(CharSequence charSequence) {
        return addInternal(0, 0, 0, charSequence);
    }

    public final SubMenu addSubMenu(CharSequence charSequence) {
        return addSubMenu(0, 0, 0, charSequence);
    }
}
