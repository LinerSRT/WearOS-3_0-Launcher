package android.support.p002v7.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.view.menu.MenuBuilder.ItemInvoker;
import android.support.p002v7.view.menu.MenuView.ItemView;
import android.support.p002v7.widget.ActionMenuPresenter.ActionMenuPopupCallback;
import android.support.p002v7.widget.ActionMenuView.ActionMenuChildView;
import android.support.p002v7.widget.AppCompatTextView;
import android.support.p002v7.widget.ForwardingListener;
import android.support.p002v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.ActionMenuItemView */
public class ActionMenuItemView extends AppCompatTextView implements ItemView, OnClickListener, ActionMenuChildView {
    private boolean mAllowTextWithIcon;
    private ForwardingListener mForwardingListener;
    private Drawable mIcon;
    MenuItemImpl mItemData;
    public ItemInvoker mItemInvoker;
    private int mMaxIconSize;
    private int mMinWidth;
    public PopupCallback mPopupCallback;
    private int mSavedPaddingLeft;
    private CharSequence mTitle;

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.ActionMenuItemView$ActionMenuItemForwardingListener */
    final class ActionMenuItemForwardingListener extends ForwardingListener {
        public ActionMenuItemForwardingListener() {
            super(ActionMenuItemView.this);
        }

        protected final boolean onForwardingStarted() {
            ActionMenuItemView actionMenuItemView = ActionMenuItemView.this;
            ItemInvoker itemInvoker = actionMenuItemView.mItemInvoker;
            if (itemInvoker != null && itemInvoker.invokeItem(actionMenuItemView.mItemData)) {
                ShowableListMenu popup = getPopup();
                if (popup != null && popup.isShowing()) {
                    return true;
                }
            }
            return false;
        }

        public final ShowableListMenu getPopup() {
            PopupCallback popupCallback = ActionMenuItemView.this.mPopupCallback;
            if (popupCallback != null) {
                MenuPopupHelper menuPopupHelper = ((ActionMenuPopupCallback) popupCallback).this$0.mActionButtonPopup;
                if (menuPopupHelper != null) {
                    return menuPopupHelper.getPopup();
                }
            }
            return null;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.ActionMenuItemView$PopupCallback */
    public class PopupCallback {
    }

    public ActionMenuItemView(Context context) {
        this(context, null);
    }

    private final boolean shouldAllowTextWithIcon() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        int i2 = configuration.screenHeightDp;
        if (i < 480) {
            if (configuration.orientation != 2) {
                return false;
            }
        }
        return true;
    }

    private final void updateTextButtonVisibility() {
        CharSequence charSequence;
        CharSequence charSequence2;
        int i = 1;
        int isEmpty = TextUtils.isEmpty(this.mTitle) ^ 1;
        if (this.mIcon != null) {
            if ((this.mItemData.mShowAsAction & 4) != 4) {
                i = 0;
            } else if (!this.mAllowTextWithIcon) {
                i = 0;
            }
            isEmpty &= i;
            charSequence = null;
            if (isEmpty == 0) {
                charSequence2 = this.mTitle;
            } else {
                charSequence2 = null;
            }
            setText(charSequence2);
            charSequence2 = this.mItemData.mContentDescription;
            if (TextUtils.isEmpty(charSequence2)) {
                setContentDescription(charSequence2);
            } else {
                if (isEmpty == 0) {
                    charSequence2 = null;
                } else {
                    charSequence2 = this.mItemData.mTitle;
                }
                setContentDescription(charSequence2);
            }
            charSequence2 = this.mItemData.mTooltipText;
            if (TextUtils.isEmpty(charSequence2)) {
                setTooltipText(charSequence2);
                return;
            }
            if (isEmpty != 0) {
                charSequence = this.mItemData.mTitle;
            }
            setTooltipText(charSequence);
        }
        isEmpty &= i;
        charSequence = null;
        if (isEmpty == 0) {
            charSequence2 = null;
        } else {
            charSequence2 = this.mTitle;
        }
        setText(charSequence2);
        charSequence2 = this.mItemData.mContentDescription;
        if (TextUtils.isEmpty(charSequence2)) {
            setContentDescription(charSequence2);
        } else {
            if (isEmpty == 0) {
                charSequence2 = this.mItemData.mTitle;
            } else {
                charSequence2 = null;
            }
            setContentDescription(charSequence2);
        }
        charSequence2 = this.mItemData.mTooltipText;
        if (TextUtils.isEmpty(charSequence2)) {
            setTooltipText(charSequence2);
            return;
        }
        if (isEmpty != 0) {
            charSequence = this.mItemData.mTitle;
        }
        setTooltipText(charSequence);
    }

    public final MenuItemImpl getItemData() {
        return this.mItemData;
    }

    public final boolean hasText() {
        return !TextUtils.isEmpty(getText());
    }

    public final void initialize$ar$ds(MenuItemImpl menuItemImpl) {
        this.mItemData = menuItemImpl;
        Drawable icon = menuItemImpl.getIcon();
        this.mIcon = icon;
        int i = 0;
        if (icon != null) {
            int intrinsicWidth = icon.getIntrinsicWidth();
            int intrinsicHeight = icon.getIntrinsicHeight();
            int i2 = this.mMaxIconSize;
            if (intrinsicWidth > i2) {
                intrinsicHeight = (int) (((float) intrinsicHeight) * (((float) i2) / ((float) intrinsicWidth)));
                intrinsicWidth = i2;
            }
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (((float) intrinsicWidth) * (((float) i2) / ((float) intrinsicHeight)));
            } else {
                i2 = intrinsicHeight;
            }
            icon.setBounds(0, 0, intrinsicWidth, i2);
        }
        setCompoundDrawables(icon, null, null, null);
        updateTextButtonVisibility();
        this.mTitle = menuItemImpl.getTitleForItemView(this);
        updateTextButtonVisibility();
        setId(menuItemImpl.mId);
        if (true != menuItemImpl.isVisible()) {
            i = 8;
        }
        setVisibility(i);
        setEnabled(menuItemImpl.isEnabled());
        if (menuItemImpl.hasSubMenu() && this.mForwardingListener == null) {
            this.mForwardingListener = new ActionMenuItemForwardingListener();
        }
    }

    public final boolean needsDividerAfter() {
        return hasText();
    }

    public final boolean needsDividerBefore() {
        return hasText() && this.mItemData.getIcon() == null;
    }

    public final void onClick(View view) {
        ItemInvoker itemInvoker = this.mItemInvoker;
        if (itemInvoker != null) {
            itemInvoker.invokeItem(this.mItemData);
        }
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.mAllowTextWithIcon = shouldAllowTextWithIcon();
        updateTextButtonVisibility();
    }

    protected final void onMeasure(int i, int i2) {
        int i3;
        boolean hasText = hasText();
        if (hasText) {
            i3 = this.mSavedPaddingLeft;
            if (i3 >= 0) {
                super.setPadding(i3, getPaddingTop(), getPaddingRight(), getPaddingBottom());
            }
        }
        super.onMeasure(i, i2);
        i3 = MeasureSpec.getMode(i);
        i = MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        if (i3 == LinearLayoutManager.INVALID_OFFSET) {
            i = Math.min(i, this.mMinWidth);
        } else {
            i = this.mMinWidth;
        }
        if (i3 != 1073741824 && this.mMinWidth > 0 && measuredWidth < i) {
            super.onMeasure(MeasureSpec.makeMeasureSpec(i, 1073741824), i2);
        }
        if (!hasText && this.mIcon != null) {
            super.setPadding((getMeasuredWidth() - this.mIcon.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.mItemData.hasSubMenu()) {
            ForwardingListener forwardingListener = this.mForwardingListener;
            if (forwardingListener != null && forwardingListener.onTouch(this, motionEvent)) {
                return true;
            }
        }
        return super.onTouchEvent(motionEvent);
    }

    public final boolean prefersCondensedTitle() {
        return true;
    }

    public final void setPadding(int i, int i2, int i3, int i4) {
        this.mSavedPaddingLeft = i;
        super.setPadding(i, i2, i3, i4);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources = context.getResources();
        this.mAllowTextWithIcon = shouldAllowTextWithIcon();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ActionMenuItemView, i, 0);
        this.mMinWidth = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
        this.mMaxIconSize = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.mSavedPaddingLeft = -1;
        setSaveEnabled(false);
    }
}
