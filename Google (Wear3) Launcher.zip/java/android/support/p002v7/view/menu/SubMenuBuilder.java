package android.support.p002v7.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p002v7.view.menu.MenuBuilder.Callback;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.SubMenuBuilder */
public final class SubMenuBuilder extends MenuBuilder implements SubMenu {
    public final MenuItemImpl mItem;
    public final MenuBuilder mParentMenu;

    public SubMenuBuilder(Context context, MenuBuilder menuBuilder, MenuItemImpl menuItemImpl) {
        super(context);
        this.mParentMenu = menuBuilder;
        this.mItem = menuItemImpl;
    }

    public final boolean collapseItemActionView(MenuItemImpl menuItemImpl) {
        return this.mParentMenu.collapseItemActionView(menuItemImpl);
    }

    public final boolean dispatchMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
        if (!super.dispatchMenuItemSelected(menuBuilder, menuItem)) {
            if (!this.mParentMenu.dispatchMenuItemSelected(menuBuilder, menuItem)) {
                return false;
            }
        }
        return true;
    }

    public final boolean expandItemActionView(MenuItemImpl menuItemImpl) {
        return this.mParentMenu.expandItemActionView(menuItemImpl);
    }

    public final String getActionViewStatesKey() {
        int i = this.mItem.mId;
        if (i == 0) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("android:menu:actionviewstates:");
        stringBuilder.append(i);
        return stringBuilder.toString();
    }

    public final MenuItem getItem() {
        return this.mItem;
    }

    public final MenuBuilder getRootMenu() {
        return this.mParentMenu.getRootMenu();
    }

    public final boolean isGroupDividerEnabled() {
        return this.mParentMenu.isGroupDividerEnabled();
    }

    public final boolean isQwertyMode() {
        return this.mParentMenu.isQwertyMode();
    }

    public final boolean isShortcutsVisible() {
        return this.mParentMenu.isShortcutsVisible();
    }

    public final void setCallback(Callback callback) {
        this.mParentMenu.setCallback(callback);
    }

    public final void setGroupDividerEnabled(boolean z) {
        this.mParentMenu.setGroupDividerEnabled(z);
    }

    public final SubMenu setIcon(int i) {
        this.mItem.setIcon(i);
        return this;
    }

    public final void setQwertyMode(boolean z) {
        this.mParentMenu.setQwertyMode(z);
    }

    public final SubMenu setHeaderIcon(int i) {
        super.setHeaderInternal(0, null, i, null, null);
        return this;
    }

    public final SubMenu setHeaderTitle(int i) {
        super.setHeaderInternal(i, null, 0, null, null);
        return this;
    }

    public final SubMenu setHeaderView(View view) {
        super.setHeaderInternal(0, null, 0, null, view);
        return this;
    }

    public final SubMenu setIcon(Drawable drawable) {
        this.mItem.setIcon(drawable);
        return this;
    }

    public final SubMenu setHeaderIcon(Drawable drawable) {
        super.setHeaderInternal(0, null, 0, drawable, null);
        return this;
    }

    public final SubMenu setHeaderTitle(CharSequence charSequence) {
        super.setHeaderInternal(0, charSequence, 0, null, null);
        return this;
    }
}
