package android.support.p002v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.view.menu.MenuView.ItemView;
import android.support.p002v7.widget.TintTypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView.SelectionBoundsAdjuster;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RadioButton;
import android.widget.TextView;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.ListMenuItemView */
public class ListMenuItemView extends LinearLayout implements ItemView, SelectionBoundsAdjuster {
    private Drawable mBackground;
    private CheckBox mCheckBox;
    private LinearLayout mContent;
    public boolean mForceShowIcon;
    public ImageView mGroupDivider;
    public boolean mHasListDivider;
    private ImageView mIconView;
    private LayoutInflater mInflater;
    public MenuItemImpl mItemData;
    public boolean mPreserveIconSpacing;
    private RadioButton mRadioButton;
    private TextView mShortcutView;
    private Drawable mSubMenuArrow;
    private ImageView mSubMenuArrowView;
    private int mTextAppearance;
    private Context mTextAppearanceContext;
    private TextView mTitleView;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listMenuViewStyle);
    }

    private final void addContentView(View view) {
        addContentView(view, -1);
    }

    private final LayoutInflater getInflater() {
        if (this.mInflater == null) {
            this.mInflater = LayoutInflater.from(getContext());
        }
        return this.mInflater;
    }

    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.mGroupDivider;
        if (imageView != null && imageView.getVisibility() == 0) {
            LayoutParams layoutParams = (LayoutParams) this.mGroupDivider.getLayoutParams();
            rect.top += (this.mGroupDivider.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin;
        }
    }

    public final MenuItemImpl getItemData() {
        return this.mItemData;
    }

    public final void initialize$ar$ds(MenuItemImpl menuItemImpl) {
        int i;
        this.mItemData = menuItemImpl;
        int i2 = 0;
        if (true != menuItemImpl.isVisible()) {
            i = 8;
        } else {
            i = 0;
        }
        setVisibility(i);
        CharSequence titleForItemView = menuItemImpl.getTitleForItemView(this);
        if (titleForItemView != null) {
            this.mTitleView.setText(titleForItemView);
            if (this.mTitleView.getVisibility() != 0) {
                this.mTitleView.setVisibility(0);
            }
        } else if (this.mTitleView.getVisibility() != 8) {
            this.mTitleView.setVisibility(8);
        }
        boolean isCheckable = menuItemImpl.isCheckable();
        if (isCheckable || this.mRadioButton != null || this.mCheckBox != null) {
            CompoundButton compoundButton;
            CheckBox checkBox;
            CompoundButton compoundButton2;
            if (this.mItemData.isExclusiveCheckable()) {
                if (this.mRadioButton == null) {
                    RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, this, false);
                    this.mRadioButton = radioButton;
                    addContentView(radioButton);
                }
                compoundButton = this.mRadioButton;
                checkBox = this.mCheckBox;
                compoundButton2 = checkBox;
            } else {
                if (this.mCheckBox == null) {
                    CheckBox checkBox2 = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, this, false);
                    this.mCheckBox = checkBox2;
                    addContentView(checkBox2);
                }
                compoundButton = this.mCheckBox;
                compoundButton2 = this.mRadioButton;
                checkBox = compoundButton;
            }
            if (isCheckable) {
                compoundButton.setChecked(this.mItemData.isChecked());
                if (compoundButton.getVisibility() != 0) {
                    compoundButton.setVisibility(0);
                }
                if (!(compoundButton2 == null || compoundButton2.getVisibility() == 8)) {
                    compoundButton2.setVisibility(8);
                }
            } else {
                if (checkBox != null) {
                    checkBox.setVisibility(8);
                }
                RadioButton radioButton2 = this.mRadioButton;
                if (radioButton2 != null) {
                    radioButton2.setVisibility(8);
                }
            }
        }
        isCheckable = menuItemImpl.shouldShowShortcut();
        menuItemImpl.getShortcut();
        i = (isCheckable && this.mItemData.shouldShowShortcut()) ? 0 : 8;
        if (i == 0) {
            CharSequence charSequence;
            TextView textView = this.mShortcutView;
            MenuItemImpl menuItemImpl2 = this.mItemData;
            char shortcut = menuItemImpl2.getShortcut();
            if (shortcut == '\u0000') {
                charSequence = "";
            } else {
                Resources resources = menuItemImpl2.mMenu.mContext.getResources();
                StringBuilder stringBuilder = new StringBuilder();
                if (ViewConfiguration.get(menuItemImpl2.mMenu.mContext).hasPermanentMenuKey()) {
                    stringBuilder.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i3 = menuItemImpl2.mMenu.isQwertyMode() ? menuItemImpl2.mShortcutAlphabeticModifiers : menuItemImpl2.mShortcutNumericModifiers;
                MenuItemImpl.appendModifier(stringBuilder, i3, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label));
                MenuItemImpl.appendModifier(stringBuilder, i3, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label));
                MenuItemImpl.appendModifier(stringBuilder, i3, 2, resources.getString(R.string.abc_menu_alt_shortcut_label));
                MenuItemImpl.appendModifier(stringBuilder, i3, 1, resources.getString(R.string.abc_menu_shift_shortcut_label));
                MenuItemImpl.appendModifier(stringBuilder, i3, 4, resources.getString(R.string.abc_menu_sym_shortcut_label));
                MenuItemImpl.appendModifier(stringBuilder, i3, 8, resources.getString(R.string.abc_menu_function_shortcut_label));
                switch (shortcut) {
                    case '\b':
                        stringBuilder.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                        break;
                    case '\n':
                        stringBuilder.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                        break;
                    case ' ':
                        stringBuilder.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                        break;
                    default:
                        stringBuilder.append(shortcut);
                        break;
                }
                charSequence = stringBuilder.toString();
            }
            textView.setText(charSequence);
        }
        if (this.mShortcutView.getVisibility() != i) {
            this.mShortcutView.setVisibility(i);
        }
        Drawable icon = menuItemImpl.getIcon();
        MenuBuilder menuBuilder = this.mItemData.mMenu;
        boolean z = this.mForceShowIcon;
        if (z || this.mPreserveIconSpacing) {
            ImageView imageView = this.mIconView;
            if (!(imageView == null && icon == null && !this.mPreserveIconSpacing)) {
                if (imageView == null) {
                    imageView = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, this, false);
                    this.mIconView = imageView;
                    addContentView(imageView, 0);
                }
                if (icon == null) {
                    if (!this.mPreserveIconSpacing) {
                        this.mIconView.setVisibility(8);
                    }
                }
                imageView = this.mIconView;
                if (true != z) {
                    icon = null;
                }
                imageView.setImageDrawable(icon);
                if (this.mIconView.getVisibility() != 0) {
                    this.mIconView.setVisibility(0);
                }
            }
        }
        setEnabled(menuItemImpl.isEnabled());
        isCheckable = menuItemImpl.hasSubMenu();
        ImageView imageView2 = this.mSubMenuArrowView;
        if (imageView2 != null) {
            if (true != isCheckable) {
                i2 = 8;
            }
            imageView2.setVisibility(i2);
        }
        setContentDescription(menuItemImpl.mContentDescription);
    }

    protected final void onFinishInflate() {
        super.onFinishInflate();
        ViewCompat.setBackground(this, this.mBackground);
        TextView textView = (TextView) findViewById(R.id.title);
        this.mTitleView = textView;
        int i = this.mTextAppearance;
        if (i != -1) {
            textView.setTextAppearance(this.mTextAppearanceContext, i);
        }
        this.mShortcutView = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.mSubMenuArrowView = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.mSubMenuArrow);
        }
        this.mGroupDivider = (ImageView) findViewById(R.id.group_divider);
        this.mContent = (LinearLayout) findViewById(R.id.content);
    }

    protected final void onMeasure(int i, int i2) {
        if (this.mIconView != null && this.mPreserveIconSpacing) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LayoutParams layoutParams2 = (LayoutParams) this.mIconView.getLayoutParams();
            if (layoutParams.height > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = layoutParams.height;
            }
        }
        super.onMeasure(i, i2);
    }

    public final boolean prefersCondensedTitle() {
        return false;
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(getContext(), attributeSet, R$styleable.MenuView, i);
        this.mBackground = obtainStyledAttributes$ar$ds.getDrawable(5);
        this.mTextAppearance = obtainStyledAttributes$ar$ds.getResourceId(1, -1);
        this.mPreserveIconSpacing = obtainStyledAttributes$ar$ds.getBoolean(7, false);
        this.mTextAppearanceContext = context;
        this.mSubMenuArrow = obtainStyledAttributes$ar$ds.getDrawable(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{16843049}, R.attr.dropDownListViewStyle, 0);
        this.mHasListDivider = obtainStyledAttributes.hasValue(0);
        obtainStyledAttributes$ar$ds.recycle();
        obtainStyledAttributes.recycle();
    }

    private final void addContentView(View view, int i) {
        LinearLayout linearLayout = this.mContent;
        if (linearLayout != null) {
            linearLayout.addView(view, i);
        } else {
            addView(view, i);
        }
    }
}
