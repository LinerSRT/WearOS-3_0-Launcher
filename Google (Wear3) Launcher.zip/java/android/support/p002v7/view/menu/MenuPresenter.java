package android.support.p002v7.view.menu;

import android.content.Context;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.MenuPresenter */
public interface MenuPresenter {

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuPresenter$Callback */
    public interface Callback {
        void onCloseMenu(MenuBuilder menuBuilder, boolean z);

        boolean onOpenSubMenu(MenuBuilder menuBuilder);
    }

    boolean collapseItemActionView$ar$ds(MenuItemImpl menuItemImpl);

    boolean expandItemActionView$ar$ds(MenuItemImpl menuItemImpl);

    boolean flagActionItems();

    void initForMenu(Context context, MenuBuilder menuBuilder);

    void onCloseMenu(MenuBuilder menuBuilder, boolean z);

    boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder);

    void setCallback(Callback callback);

    void updateMenuView$ar$ds();
}
