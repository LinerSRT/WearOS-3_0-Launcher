package android.support.p002v7.view.menu;

import android.content.Context;
import android.support.p000v4.internal.view.SupportMenuItem;
import android.view.MenuItem;
import androidx.collection.SimpleArrayMap;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.BaseMenuWrapper */
class BaseMenuWrapper {
    final Context mContext;
    public SimpleArrayMap mMenuItems;

    public BaseMenuWrapper(Context context) {
        this.mContext = context;
    }

    final MenuItem getMenuItemWrapper(MenuItem menuItem) {
        if (!(menuItem instanceof SupportMenuItem)) {
            return menuItem;
        }
        SupportMenuItem supportMenuItem = (SupportMenuItem) menuItem;
        if (this.mMenuItems == null) {
            this.mMenuItems = new SimpleArrayMap();
        }
        menuItem = (MenuItem) this.mMenuItems.get(menuItem);
        if (menuItem != null) {
            return menuItem;
        }
        menuItem = new MenuItemWrapperICS(this.mContext, supportMenuItem);
        this.mMenuItems.put(supportMenuItem, menuItem);
        return menuItem;
    }
}
