package android.support.p002v7.view.menu;

import android.content.Context;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.BaseMenuPresenter */
public class BaseMenuPresenter implements MenuPresenter {
    public Callback mCallback;
    public Context mContext;
    public MenuBuilder mMenu;
    public MenuView mMenuView;
    protected final Context mSystemContext;
    public final LayoutInflater mSystemInflater;

    public BaseMenuPresenter(Context context) {
        this.mSystemContext = context;
        this.mSystemInflater = LayoutInflater.from(context);
    }

    public final boolean collapseItemActionView$ar$ds(MenuItemImpl menuItemImpl) {
        return false;
    }

    public final boolean expandItemActionView$ar$ds(MenuItemImpl menuItemImpl) {
        return false;
    }

    public boolean flagActionItems() {
        throw null;
    }

    public View getItemView(MenuItemImpl menuItemImpl, View view, ViewGroup viewGroup) {
        throw null;
    }

    public void initForMenu(Context context, MenuBuilder menuBuilder) {
        throw null;
    }

    public void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        throw null;
    }

    public boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
        throw null;
    }

    public final void setCallback(Callback callback) {
        throw null;
    }

    public void updateMenuView$ar$ds() {
        throw null;
    }
}
