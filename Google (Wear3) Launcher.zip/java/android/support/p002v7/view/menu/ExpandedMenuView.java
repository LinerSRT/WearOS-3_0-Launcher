package android.support.p002v7.view.menu;

import android.content.Context;
import android.support.p002v7.view.menu.MenuBuilder.ItemInvoker;
import android.support.p002v7.widget.TintTypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.ExpandedMenuView */
public final class ExpandedMenuView extends ListView implements ItemInvoker, MenuView, OnItemClickListener {
    private static final int[] TINT_ATTRS = new int[]{16842964, 16843049};
    private MenuBuilder mMenu;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842868);
    }

    public final void initialize(MenuBuilder menuBuilder) {
        this.mMenu = menuBuilder;
    }

    public final boolean invokeItem(MenuItemImpl menuItemImpl) {
        throw null;
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        this.mMenu.performItemAction((MenuItemImpl) getAdapter().getItem(i), 0);
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(context, attributeSet, TINT_ATTRS, i);
        if (obtainStyledAttributes$ar$ds.hasValue(0)) {
            setBackgroundDrawable(obtainStyledAttributes$ar$ds.getDrawable(0));
        }
        if (obtainStyledAttributes$ar$ds.hasValue(1)) {
            setDivider(obtainStyledAttributes$ar$ds.getDrawable(1));
        }
        obtainStyledAttributes$ar$ds.recycle();
    }
}
