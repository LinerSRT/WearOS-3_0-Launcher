package android.support.p002v7.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.support.p000v4.internal.view.SupportMenu;
import android.support.p000v4.internal.view.SupportMenuItem;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import androidx.collection.SimpleArrayMap;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.MenuWrapperICS */
public final class MenuWrapperICS extends BaseMenuWrapper implements Menu {
    private final SupportMenu mWrappedObject;

    public MenuWrapperICS(Context context, SupportMenu supportMenu) {
        super(context);
        this.mWrappedObject = supportMenu;
    }

    public final MenuItem add(int i) {
        return getMenuItemWrapper(this.mWrappedObject.add(i));
    }

    public final int addIntentOptions(int i, int i2, int i3, ComponentName componentName, Intent[] intentArr, Intent intent, int i4, MenuItem[] menuItemArr) {
        MenuItem[] menuItemArr2;
        MenuWrapperICS menuWrapperICS = this;
        MenuItem[] menuItemArr3 = menuItemArr;
        if (menuItemArr3 != null) {
            menuItemArr2 = new MenuItem[menuItemArr3.length];
        } else {
            menuItemArr2 = null;
        }
        int addIntentOptions = menuWrapperICS.mWrappedObject.addIntentOptions(i, i2, i3, componentName, intentArr, intent, i4, menuItemArr2);
        if (menuItemArr2 != null) {
            int length = menuItemArr2.length;
            for (int i5 = 0; i5 < length; i5++) {
                menuItemArr3[i5] = getMenuItemWrapper(menuItemArr2[i5]);
            }
        }
        return addIntentOptions;
    }

    public final SubMenu addSubMenu(int i) {
        return this.mWrappedObject.addSubMenu(i);
    }

    public final void close() {
        this.mWrappedObject.close();
    }

    public final MenuItem findItem(int i) {
        return getMenuItemWrapper(this.mWrappedObject.findItem(i));
    }

    public final MenuItem getItem(int i) {
        return getMenuItemWrapper(this.mWrappedObject.getItem(i));
    }

    public final boolean hasVisibleItems() {
        return this.mWrappedObject.hasVisibleItems();
    }

    public final boolean isShortcutKey(int i, KeyEvent keyEvent) {
        return this.mWrappedObject.isShortcutKey(i, keyEvent);
    }

    public final boolean performIdentifierAction(int i, int i2) {
        return this.mWrappedObject.performIdentifierAction(i, i2);
    }

    public final boolean performShortcut(int i, KeyEvent keyEvent, int i2) {
        return this.mWrappedObject.performShortcut(i, keyEvent, i2);
    }

    public final void setGroupCheckable(int i, boolean z, boolean z2) {
        this.mWrappedObject.setGroupCheckable(i, z, z2);
    }

    public final void setGroupEnabled(int i, boolean z) {
        this.mWrappedObject.setGroupEnabled(i, z);
    }

    public final void setGroupVisible(int i, boolean z) {
        this.mWrappedObject.setGroupVisible(i, z);
    }

    public final void setQwertyMode(boolean z) {
        this.mWrappedObject.setQwertyMode(z);
    }

    public final int size() {
        return this.mWrappedObject.size();
    }

    public final MenuItem add(int i, int i2, int i3, int i4) {
        return getMenuItemWrapper(this.mWrappedObject.add(i, i2, i3, i4));
    }

    public final SubMenu addSubMenu(int i, int i2, int i3, int i4) {
        return this.mWrappedObject.addSubMenu(i, i2, i3, i4);
    }

    public final void clear() {
        SimpleArrayMap simpleArrayMap = this.mMenuItems;
        if (simpleArrayMap != null) {
            simpleArrayMap.clear();
        }
        this.mWrappedObject.clear();
    }

    public final void removeGroup(int i) {
        if (this.mMenuItems != null) {
            int i2 = 0;
            while (true) {
                SimpleArrayMap simpleArrayMap = this.mMenuItems;
                if (i2 >= simpleArrayMap.mSize) {
                    break;
                }
                if (((SupportMenuItem) simpleArrayMap.keyAt(i2)).getGroupId() == i) {
                    this.mMenuItems.removeAt(i2);
                    i2--;
                }
                i2++;
            }
        }
        this.mWrappedObject.removeGroup(i);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void removeItem(int r4) {
        /*
        r3 = this;
        r0 = r3.mMenuItems;
        if (r0 == 0) goto L_0x0020;
    L_0x0004:
        r0 = 0;
    L_0x0005:
        r1 = r3.mMenuItems;
        r2 = r1.mSize;
        if (r0 >= r2) goto L_0x0020;
    L_0x000b:
        r1 = r1.keyAt(r0);
        r1 = (android.support.p000v4.internal.view.SupportMenuItem) r1;
        r1 = r1.getItemId();
        if (r1 != r4) goto L_0x001d;
    L_0x0017:
        r1 = r3.mMenuItems;
        r1.removeAt(r0);
        goto L_0x0020;
    L_0x001d:
        r0 = r0 + 1;
        goto L_0x0005;
    L_0x0020:
        r0 = r3.mWrappedObject;
        r0.removeItem(r4);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.view.menu.MenuWrapperICS.removeItem(int):void");
    }

    public final SubMenu addSubMenu(int i, int i2, int i3, CharSequence charSequence) {
        return this.mWrappedObject.addSubMenu(i, i2, i3, charSequence);
    }

    public final MenuItem add(int i, int i2, int i3, CharSequence charSequence) {
        return getMenuItemWrapper(((MenuBuilder) this.mWrappedObject).addInternal(i, i2, i3, charSequence));
    }

    public final SubMenu addSubMenu(CharSequence charSequence) {
        return this.mWrappedObject.addSubMenu(charSequence);
    }

    public final MenuItem add(CharSequence charSequence) {
        return getMenuItemWrapper(this.mWrappedObject.add(charSequence));
    }
}
