package android.support.p002v7.view.menu;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.MenuView */
public interface MenuView {

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.menu.MenuView$ItemView */
    public interface ItemView {
        MenuItemImpl getItemData();

        void initialize$ar$ds(MenuItemImpl menuItemImpl);

        boolean prefersCondensedTitle();
    }

    void initialize(MenuBuilder menuBuilder);
}
