package android.support.p002v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.support.p002v7.widget.ListPopupWindow;
import android.support.p002v7.widget.MenuPopupWindow;
import android.support.v7.view.menu.StandardMenuPopup.C00882;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.view.menu.StandardMenuPopup */
final class StandardMenuPopup extends MenuPopup implements OnDismissListener, OnItemClickListener, MenuPresenter, OnKeyListener {
    private final MenuAdapter mAdapter;
    private View mAnchorView;
    private final OnAttachStateChangeListener mAttachStateChangeListener = new C00882();
    private int mContentWidth;
    private final Context mContext;
    private int mDropDownGravity = 0;
    final OnGlobalLayoutListener mGlobalLayoutListener = new PG();
    private boolean mHasContentWidth;
    private final MenuBuilder mMenu;
    private OnDismissListener mOnDismissListener;
    private final boolean mOverflowOnly;
    final MenuPopupWindow mPopup;
    private final int mPopupMaxWidth;
    private final int mPopupStyleAttr;
    private Callback mPresenterCallback;
    private boolean mShowTitle;
    View mShownAnchorView;
    ViewTreeObserver mTreeObserver;
    private boolean mWasDismissed;

    /* renamed from: android.support.v7.view.menu.StandardMenuPopup$1 */
    final class PG implements OnGlobalLayoutListener {
        public final void onGlobalLayout() {
            if (StandardMenuPopup.this.isShowing()) {
                StandardMenuPopup standardMenuPopup = StandardMenuPopup.this;
                if (!standardMenuPopup.mPopup.mModal) {
                    View view = standardMenuPopup.mShownAnchorView;
                    if (view != null) {
                        if (view.isShown()) {
                            StandardMenuPopup.this.mPopup.show();
                            return;
                        }
                    }
                    StandardMenuPopup.this.dismiss();
                }
            }
        }
    }

    /* renamed from: android.support.v7.view.menu.StandardMenuPopup$2 */
    final class C00882 implements OnAttachStateChangeListener {
        public final void onViewAttachedToWindow(View view) {
        }

        public final void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = android.support.p002v7.view.menu.StandardMenuPopup.this.mTreeObserver;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    android.support.p002v7.view.menu.StandardMenuPopup.this.mTreeObserver = view.getViewTreeObserver();
                }
                android.support.p002v7.view.menu.StandardMenuPopup standardMenuPopup = android.support.p002v7.view.menu.StandardMenuPopup.this;
                standardMenuPopup.mTreeObserver.removeGlobalOnLayoutListener(standardMenuPopup.mGlobalLayoutListener);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public StandardMenuPopup(Context context, MenuBuilder menuBuilder, View view, int i, boolean z) {
        this.mContext = context;
        this.mMenu = menuBuilder;
        this.mOverflowOnly = z;
        this.mAdapter = new MenuAdapter(menuBuilder, LayoutInflater.from(context), z, R.layout.abc_popup_menu_item_layout);
        this.mPopupStyleAttr = i;
        Resources resources = context.getResources();
        this.mPopupMaxWidth = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.mAnchorView = view;
        this.mPopup = new MenuPopupWindow(context, i);
        menuBuilder.addMenuPresenter(this, context);
    }

    public final void addMenu(MenuBuilder menuBuilder) {
    }

    public final void dismiss() {
        if (isShowing()) {
            this.mPopup.dismiss();
        }
    }

    public final boolean flagActionItems() {
        return false;
    }

    public final ListView getListView() {
        return this.mPopup.mDropDownList;
    }

    public final boolean isShowing() {
        return !this.mWasDismissed && this.mPopup.isShowing();
    }

    public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        if (menuBuilder == this.mMenu) {
            dismiss();
            Callback callback = this.mPresenterCallback;
            if (callback != null) {
                callback.onCloseMenu(menuBuilder, z);
            }
        }
    }

    public final void onDismiss() {
        this.mWasDismissed = true;
        this.mMenu.close();
        ViewTreeObserver viewTreeObserver = this.mTreeObserver;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.mTreeObserver = this.mShownAnchorView.getViewTreeObserver();
            }
            this.mTreeObserver.removeGlobalOnLayoutListener(this.mGlobalLayoutListener);
            this.mTreeObserver = null;
        }
        this.mShownAnchorView.removeOnAttachStateChangeListener(this.mAttachStateChangeListener);
        OnDismissListener onDismissListener = this.mOnDismissListener;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public final boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    public final boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
        if (subMenuBuilder.hasVisibleItems()) {
            MenuPopupHelper menuPopupHelper = new MenuPopupHelper(this.mContext, subMenuBuilder, this.mShownAnchorView, this.mOverflowOnly, this.mPopupStyleAttr);
            menuPopupHelper.setPresenterCallback(this.mPresenterCallback);
            menuPopupHelper.setForceShowIcon(MenuPopup.shouldPreserveIconSpacing(subMenuBuilder));
            menuPopupHelper.mOnDismissListener = this.mOnDismissListener;
            this.mOnDismissListener = null;
            this.mMenu.close(false);
            ListPopupWindow listPopupWindow = this.mPopup;
            int i = listPopupWindow.mDropDownHorizontalOffset;
            int verticalOffset = listPopupWindow.getVerticalOffset();
            if ((Gravity.getAbsoluteGravity(this.mDropDownGravity, ViewCompat.getLayoutDirection(this.mAnchorView)) & 7) == 5) {
                i += this.mAnchorView.getWidth();
            }
            if (!menuPopupHelper.isShowing()) {
                if (menuPopupHelper.mAnchorView != null) {
                    menuPopupHelper.showPopup(i, verticalOffset, true, true);
                }
            }
            Callback callback = this.mPresenterCallback;
            if (callback != null) {
                callback.onOpenSubMenu(subMenuBuilder);
            }
            return true;
        }
        return false;
    }

    public final void setAnchorView(View view) {
        this.mAnchorView = view;
    }

    public final void setCallback(Callback callback) {
        this.mPresenterCallback = callback;
    }

    public final void setForceShowIcon(boolean z) {
        this.mAdapter.mForceShowIcon = z;
    }

    public final void setGravity(int i) {
        this.mDropDownGravity = i;
    }

    public final void setHorizontalOffset(int i) {
        this.mPopup.mDropDownHorizontalOffset = i;
    }

    public final void setOnDismissListener(OnDismissListener onDismissListener) {
        this.mOnDismissListener = onDismissListener;
    }

    public final void setShowTitle(boolean z) {
        this.mShowTitle = z;
    }

    public final void setVerticalOffset(int i) {
        this.mPopup.setVerticalOffset(i);
    }

    public final void updateMenuView$ar$ds() {
        this.mHasContentWidth = false;
        MenuAdapter menuAdapter = this.mAdapter;
        if (menuAdapter != null) {
            menuAdapter.notifyDataSetChanged();
        }
    }

    public final void show() {
        if (!isShowing()) {
            if (!this.mWasDismissed) {
                View view = this.mAnchorView;
                if (view != null) {
                    this.mShownAnchorView = view;
                    this.mPopup.setOnDismissListener(this);
                    ListPopupWindow listPopupWindow = this.mPopup;
                    listPopupWindow.mItemClickListener = this;
                    listPopupWindow.setModal$ar$ds();
                    view = this.mShownAnchorView;
                    ViewTreeObserver viewTreeObserver = this.mTreeObserver;
                    ViewTreeObserver viewTreeObserver2 = view.getViewTreeObserver();
                    this.mTreeObserver = viewTreeObserver2;
                    if (viewTreeObserver == null) {
                        viewTreeObserver2.addOnGlobalLayoutListener(this.mGlobalLayoutListener);
                    }
                    view.addOnAttachStateChangeListener(this.mAttachStateChangeListener);
                    ListPopupWindow listPopupWindow2 = this.mPopup;
                    listPopupWindow2.mDropDownAnchorView = view;
                    listPopupWindow2.mDropDownGravity = this.mDropDownGravity;
                    if (!this.mHasContentWidth) {
                        this.mContentWidth = MenuPopup.measureIndividualMenuWidth$ar$ds(this.mAdapter, this.mContext, this.mPopupMaxWidth);
                        this.mHasContentWidth = true;
                    }
                    this.mPopup.setContentWidth(this.mContentWidth);
                    this.mPopup.setInputMethodMode$ar$ds();
                    this.mPopup.setEpicenterBounds(this.mEpicenterBounds);
                    this.mPopup.show();
                    ViewGroup viewGroup = this.mPopup.mDropDownList;
                    viewGroup.setOnKeyListener(this);
                    if (this.mShowTitle && this.mMenu.mHeaderTitle != null) {
                        FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.mContext).inflate(R.layout.abc_popup_menu_header_item_layout, viewGroup, false);
                        TextView textView = (TextView) frameLayout.findViewById(16908310);
                        if (textView != null) {
                            textView.setText(this.mMenu.mHeaderTitle);
                        }
                        frameLayout.setEnabled(false);
                        viewGroup.addHeaderView(frameLayout, null, false);
                    }
                    this.mPopup.setAdapter(this.mAdapter);
                    this.mPopup.show();
                    return;
                }
            }
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }
}
