package android.support.p002v7.view;

import android.content.Context;
import android.content.res.Configuration;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.view.ActionBarPolicy */
public final class ActionBarPolicy {
    public static final int getMaxActionButtons$ar$objectUnboxing(Context context) {
        Configuration configuration = context.getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        return (configuration.smallestScreenWidthDp > 600 || i > 600) ? 5 : (i >= 500 || (i > 480 && configuration.screenHeightDp > 640)) ? 4 : i >= 360 ? 3 : 2;
    }

    public static final boolean hasEmbeddedTabs$ar$objectUnboxing(Context context) {
        return context.getResources().getBoolean(R.bool.abc_action_bar_embed_tabs);
    }
}
