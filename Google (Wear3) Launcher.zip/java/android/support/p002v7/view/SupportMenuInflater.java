package android.support.p002v7.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff.Mode;
import android.support.p000v4.internal.view.SupportMenu;
import android.support.p000v4.internal.view.SupportMenuItem;
import android.support.p000v4.view.ActionProvider;
import android.support.p002v7.view.menu.MenuItemImpl;
import android.support.p002v7.view.menu.MenuItemWrapperICS;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParserException;

/* compiled from: PG */
/* renamed from: android.support.v7.view.SupportMenuInflater */
public final class SupportMenuInflater extends MenuInflater {
    static final Class[] ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE;
    static final Class[] ACTION_VIEW_CONSTRUCTOR_SIGNATURE;
    final Object[] mActionProviderConstructorArguments;
    final Object[] mActionViewConstructorArguments;
    final Context mContext;
    public Object mRealOwner;

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.SupportMenuInflater$InflatedOnMenuItemClickListener */
    final class InflatedOnMenuItemClickListener implements OnMenuItemClickListener {
        private static final Class[] PARAM_TYPES = new Class[]{MenuItem.class};
        private Method mMethod;
        private final Object mRealOwner;

        public InflatedOnMenuItemClickListener(Object obj, String str) {
            this.mRealOwner = obj;
            Class cls = obj.getClass();
            try {
                this.mMethod = cls.getMethod(str, PARAM_TYPES);
            } catch (Throwable e) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Couldn't resolve menu item onClick handler ");
                stringBuilder.append(str);
                stringBuilder.append(" in class ");
                stringBuilder.append(cls.getName());
                InflateException inflateException = new InflateException(stringBuilder.toString());
                inflateException.initCause(e);
                throw inflateException;
            }
        }

        public final boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.mMethod.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.mMethod.invoke(this.mRealOwner, new Object[]{menuItem})).booleanValue();
                }
                this.mMethod.invoke(this.mRealOwner, new Object[]{menuItem});
                return true;
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.view.SupportMenuInflater$MenuState */
    final class MenuState {
        public int groupCategory;
        public int groupCheckable;
        public boolean groupEnabled;
        public int groupId;
        public int groupOrder;
        public boolean groupVisible;
        ActionProvider itemActionProvider;
        public String itemActionProviderClassName;
        public String itemActionViewClassName;
        public int itemActionViewLayout;
        public boolean itemAdded;
        public int itemAlphabeticModifiers;
        public char itemAlphabeticShortcut;
        public int itemCategoryOrder;
        public int itemCheckable;
        public boolean itemChecked;
        public CharSequence itemContentDescription;
        public boolean itemEnabled;
        public int itemIconResId;
        public ColorStateList itemIconTintList = null;
        public Mode itemIconTintMode = null;
        public int itemId;
        public String itemListenerMethodName;
        public int itemNumericModifiers;
        public char itemNumericShortcut;
        public int itemShowAsAction;
        public CharSequence itemTitle;
        public CharSequence itemTitleCondensed;
        public CharSequence itemTooltipText;
        public boolean itemVisible;
        public final Menu menu;

        public MenuState(Menu menu) {
            this.menu = menu;
            resetGroup();
        }

        public static final char getShortcut$ar$ds(String str) {
            return str == null ? '\u0000' : str.charAt(0);
        }

        public final SubMenu addSubMenuItem() {
            this.itemAdded = true;
            SubMenu addSubMenu = this.menu.addSubMenu(this.groupId, this.itemId, this.itemCategoryOrder, this.itemTitle);
            setItem(addSubMenu.getItem());
            return addSubMenu;
        }

        public final Object newInstance(String str, Class[] clsArr, Object[] objArr) {
            try {
                Constructor constructor = Class.forName(str, false, SupportMenuInflater.this.mContext.getClassLoader()).getConstructor(clsArr);
                constructor.setAccessible(true);
                str = constructor.newInstance(objArr);
                return str;
            } catch (Throwable e) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot instantiate class: ");
                stringBuilder.append(str);
                Log.w("SupportMenuInflater", stringBuilder.toString(), e);
                return null;
            }
        }

        public final void resetGroup() {
            this.groupId = 0;
            this.groupCategory = 0;
            this.groupOrder = 0;
            this.groupCheckable = 0;
            this.groupVisible = true;
            this.groupEnabled = true;
        }

        public final void setItem(MenuItem menuItem) {
            boolean z;
            MenuItem enabled = menuItem.setChecked(this.itemChecked).setVisible(this.itemVisible).setEnabled(this.itemEnabled);
            int i = 0;
            if (this.itemCheckable > 0) {
                z = true;
            } else {
                z = false;
            }
            enabled.setCheckable(z).setTitleCondensed(this.itemTitleCondensed).setIcon(this.itemIconResId);
            int i2 = this.itemShowAsAction;
            if (i2 >= 0) {
                menuItem.setShowAsAction(i2);
            }
            if (this.itemListenerMethodName != null) {
                if (SupportMenuInflater.this.mContext.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                SupportMenuInflater supportMenuInflater = SupportMenuInflater.this;
                if (supportMenuInflater.mRealOwner == null) {
                    supportMenuInflater.mRealOwner = supportMenuInflater.findRealOwner(supportMenuInflater.mContext);
                }
                menuItem.setOnMenuItemClickListener(new InflatedOnMenuItemClickListener(supportMenuInflater.mRealOwner, this.itemListenerMethodName));
            }
            if (this.itemCheckable >= 2) {
                if (menuItem instanceof MenuItemImpl) {
                    ((MenuItemImpl) menuItem).setExclusiveCheckable(true);
                } else if (menuItem instanceof MenuItemWrapperICS) {
                    MenuItemWrapperICS menuItemWrapperICS = (MenuItemWrapperICS) menuItem;
                    try {
                        if (menuItemWrapperICS.mSetExclusiveCheckableMethod == null) {
                            Class[] clsArr = new Class[]{Boolean.TYPE};
                            menuItemWrapperICS.mSetExclusiveCheckableMethod = menuItemWrapperICS.mWrappedObject.getClass().getDeclaredMethod("setExclusiveCheckable", clsArr);
                        }
                        menuItemWrapperICS.mSetExclusiveCheckableMethod.invoke(menuItemWrapperICS.mWrappedObject, new Object[]{Boolean.valueOf(true)});
                    } catch (Throwable e) {
                        Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e);
                    }
                }
            }
            String str = this.itemActionViewClassName;
            if (str != null) {
                menuItem.setActionView((View) newInstance(str, SupportMenuInflater.ACTION_VIEW_CONSTRUCTOR_SIGNATURE, SupportMenuInflater.this.mActionViewConstructorArguments));
                i = 1;
            }
            i2 = this.itemActionViewLayout;
            if (i2 > 0) {
                if (i == 0) {
                    menuItem.setActionView(i2);
                } else {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                }
            }
            ActionProvider actionProvider = this.itemActionProvider;
            if (actionProvider != null) {
                if (menuItem instanceof SupportMenuItem) {
                    ((SupportMenuItem) menuItem).setSupportActionProvider$ar$ds(actionProvider);
                } else {
                    Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
                }
            }
            CharSequence charSequence = this.itemContentDescription;
            z = menuItem instanceof SupportMenuItem;
            if (z) {
                ((SupportMenuItem) menuItem).setContentDescription$ar$ds(charSequence);
            } else {
                menuItem.setContentDescription(charSequence);
            }
            charSequence = this.itemTooltipText;
            if (z) {
                ((SupportMenuItem) menuItem).setTooltipText$ar$ds(charSequence);
            } else {
                menuItem.setTooltipText(charSequence);
            }
            char c = this.itemAlphabeticShortcut;
            i = this.itemAlphabeticModifiers;
            if (z) {
                ((SupportMenuItem) menuItem).setAlphabeticShortcut(c, i);
            } else {
                menuItem.setAlphabeticShortcut(c, i);
            }
            c = this.itemNumericShortcut;
            i = this.itemNumericModifiers;
            if (z) {
                ((SupportMenuItem) menuItem).setNumericShortcut(c, i);
            } else {
                menuItem.setNumericShortcut(c, i);
            }
            Mode mode = this.itemIconTintMode;
            if (mode != null) {
                if (z) {
                    ((SupportMenuItem) menuItem).setIconTintMode(mode);
                } else {
                    menuItem.setIconTintMode(mode);
                }
            }
            ColorStateList colorStateList = this.itemIconTintList;
            if (colorStateList != null) {
                if (z) {
                    ((SupportMenuItem) menuItem).setIconTintList(colorStateList);
                    return;
                }
                menuItem.setIconTintList(colorStateList);
            }
        }
    }

    static {
        Class[] clsArr = new Class[]{Context.class};
        ACTION_VIEW_CONSTRUCTOR_SIGNATURE = clsArr;
        ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE = clsArr;
    }

    public SupportMenuInflater(Context context) {
        super(context);
        this.mContext = context;
        Object[] objArr = new Object[]{context};
        this.mActionViewConstructorArguments = objArr;
        this.mActionProviderConstructorArguments = objArr;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void parseMenu(org.xmlpull.v1.XmlPullParser r17, android.util.AttributeSet r18, android.view.Menu r19) {
        /*
        r16 = this;
        r0 = r16;
        r1 = r18;
        r2 = new android.support.v7.view.SupportMenuInflater$MenuState;
        r3 = r19;
        r2.<init>(r3);
        r3 = r17.getEventType();
    L_0x000f:
        r4 = "menu";
        r5 = 2;
        r6 = 1;
        if (r3 != r5) goto L_0x003b;
    L_0x0015:
        r3 = r17.getName();
        r7 = r3.equals(r4);
        if (r7 == 0) goto L_0x0024;
    L_0x001f:
        r3 = r17.next();
        goto L_0x0041;
    L_0x0024:
        r1 = new java.lang.RuntimeException;
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r4 = "Expecting menu, got ";
        r2.append(r4);
        r2.append(r3);
        r2 = r2.toString();
        r1.<init>(r2);
        throw r1;
    L_0x003b:
        r3 = r17.next();
        if (r3 != r6) goto L_0x024f;
    L_0x0041:
        r8 = 0;
        r9 = 0;
        r10 = 0;
        r11 = 0;
    L_0x0045:
        if (r9 != 0) goto L_0x024e;
    L_0x0047:
        r12 = "item";
        r13 = "group";
        switch(r3) {
            case 1: goto L_0x0240;
            case 2: goto L_0x00b9;
            case 3: goto L_0x0053;
            default: goto L_0x004e;
        };
    L_0x004e:
        r12 = r17;
        r7 = 0;
        goto L_0x0248;
    L_0x0053:
        r3 = r17.getName();
        if (r10 == 0) goto L_0x0066;
    L_0x0059:
        r14 = r3.equals(r11);
        if (r14 == 0) goto L_0x0066;
    L_0x005f:
        r12 = r17;
        r7 = 0;
        r10 = 0;
        r11 = 0;
        goto L_0x0248;
        r13 = r3.equals(r13);
        if (r13 == 0) goto L_0x0075;
    L_0x006d:
        r2.resetGroup();
        r12 = r17;
        r7 = 0;
        goto L_0x0248;
        r12 = r3.equals(r12);
        if (r12 == 0) goto L_0x00ac;
    L_0x007c:
        r3 = r2.itemAdded;
        if (r3 != 0) goto L_0x00a6;
    L_0x0080:
        r3 = r2.itemActionProvider;
        if (r3 == 0) goto L_0x0092;
    L_0x0084:
        r3 = r3.hasSubMenu();
        if (r3 == 0) goto L_0x0092;
    L_0x008a:
        r2.addSubMenuItem();
        r12 = r17;
        r7 = 0;
        goto L_0x0248;
    L_0x0092:
        r2.itemAdded = r6;
        r3 = r2.menu;
        r12 = r2.groupId;
        r13 = r2.itemId;
        r14 = r2.itemCategoryOrder;
        r15 = r2.itemTitle;
        r3 = r3.add(r12, r13, r14, r15);
        r2.setItem(r3);
        goto L_0x00a7;
    L_0x00a7:
        r12 = r17;
        r7 = 0;
        goto L_0x0248;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x00bb;
    L_0x00b3:
        r12 = r17;
        r7 = 0;
        r9 = 1;
        goto L_0x0248;
    L_0x00b9:
        if (r10 == 0) goto L_0x00c0;
    L_0x00bb:
        r12 = r17;
        r7 = 0;
        goto L_0x0248;
    L_0x00c0:
        r3 = r17.getName();
        r13 = r3.equals(r13);
        r14 = 5;
        r15 = 4;
        r7 = 3;
        if (r13 == 0) goto L_0x0103;
    L_0x00cd:
        r3 = r2.this$0;
        r3 = r3.mContext;
        r12 = android.support.p002v7.appcompat.R$styleable.MenuGroup;
        r3 = r3.obtainStyledAttributes(r1, r12);
        r12 = r3.getResourceId(r6, r8);
        r2.groupId = r12;
        r7 = r3.getInt(r7, r8);
        r2.groupCategory = r7;
        r7 = r3.getInt(r15, r8);
        r2.groupOrder = r7;
        r7 = r3.getInt(r14, r8);
        r2.groupCheckable = r7;
        r7 = r3.getBoolean(r5, r6);
        r2.groupVisible = r7;
        r7 = r3.getBoolean(r8, r6);
        r2.groupEnabled = r7;
        r3.recycle();
        r12 = r17;
        r7 = 0;
        goto L_0x0248;
        r12 = r3.equals(r12);
        if (r12 == 0) goto L_0x022a;
    L_0x010a:
        r3 = r2.this$0;
        r3 = r3.mContext;
        r12 = android.support.p002v7.appcompat.R$styleable.MenuItem;
        r3 = android.support.p002v7.widget.TintTypedArray.obtainStyledAttributes(r3, r1, r12);
        r12 = r3.getResourceId(r5, r8);
        r2.itemId = r12;
        r12 = r2.groupCategory;
        r12 = r3.getInt(r14, r12);
        r13 = -65536; // 0xffffffffffff0000 float:NaN double:NaN;
        r12 = r12 & r13;
        r13 = 6;
        r14 = r2.groupOrder;
        r13 = r3.getInt(r13, r14);
        r13 = (char) r13;
        r12 = r12 | r13;
        r2.itemCategoryOrder = r12;
        r12 = 7;
        r12 = r3.getText(r12);
        r2.itemTitle = r12;
        r12 = 8;
        r12 = r3.getText(r12);
        r2.itemTitleCondensed = r12;
        r12 = r3.getResourceId(r8, r8);
        r2.itemIconResId = r12;
        r12 = 9;
        r12 = r3.getString(r12);
        r12 = android.support.p002v7.view.SupportMenuInflater.MenuState.getShortcut$ar$ds(r12);
        r2.itemAlphabeticShortcut = r12;
        r12 = 16;
        r13 = 4096; // 0x1000 float:5.74E-42 double:2.0237E-320;
        r12 = r3.getInt(r12, r13);
        r2.itemAlphabeticModifiers = r12;
        r12 = 10;
        r12 = r3.getString(r12);
        r12 = android.support.p002v7.view.SupportMenuInflater.MenuState.getShortcut$ar$ds(r12);
        r2.itemNumericShortcut = r12;
        r12 = 20;
        r12 = r3.getInt(r12, r13);
        r2.itemNumericModifiers = r12;
        r12 = 11;
        r13 = r3.hasValue(r12);
        if (r13 == 0) goto L_0x017c;
    L_0x0175:
        r12 = r3.getBoolean(r12, r8);
        r2.itemCheckable = r12;
        goto L_0x0180;
    L_0x017c:
        r12 = r2.groupCheckable;
        r2.itemCheckable = r12;
        r7 = r3.getBoolean(r7, r8);
        r2.itemChecked = r7;
        r7 = r2.groupVisible;
        r7 = r3.getBoolean(r15, r7);
        r2.itemVisible = r7;
        r7 = r2.groupEnabled;
        r7 = r3.getBoolean(r6, r7);
        r2.itemEnabled = r7;
        r7 = 21;
        r12 = -1;
        r7 = r3.getInt(r7, r12);
        r2.itemShowAsAction = r7;
        r7 = 12;
        r7 = r3.getString(r7);
        r2.itemListenerMethodName = r7;
        r7 = 13;
        r7 = r3.getResourceId(r7, r8);
        r2.itemActionViewLayout = r7;
        r7 = 15;
        r7 = r3.getString(r7);
        r2.itemActionViewClassName = r7;
        r7 = 14;
        r7 = r3.getString(r7);
        r2.itemActionProviderClassName = r7;
        r7 = r2.itemActionProviderClassName;
        if (r7 == 0) goto L_0x01e3;
    L_0x01c4:
        r13 = r2.itemActionViewLayout;
        if (r13 != 0) goto L_0x01db;
    L_0x01c8:
        r13 = r2.itemActionViewClassName;
        if (r13 != 0) goto L_0x01db;
    L_0x01cc:
        r13 = ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE;
        r14 = r2.this$0;
        r14 = r14.mActionProviderConstructorArguments;
        r7 = r2.newInstance(r7, r13, r14);
        r7 = (android.support.p000v4.view.ActionProvider) r7;
        r2.itemActionProvider = r7;
        goto L_0x01e6;
        r7 = "SupportMenuInflater";
        r13 = "Ignoring attribute 'actionProviderClass'. Action view already specified.";
        android.util.Log.w(r7, r13);
    L_0x01e3:
        r7 = 0;
        r2.itemActionProvider = r7;
    L_0x01e6:
        r7 = 17;
        r7 = r3.getText(r7);
        r2.itemContentDescription = r7;
        r7 = 22;
        r7 = r3.getText(r7);
        r2.itemTooltipText = r7;
        r7 = 19;
        r13 = r3.hasValue(r7);
        if (r13 == 0) goto L_0x020b;
    L_0x01fe:
        r7 = r3.getInt(r7, r12);
        r12 = r2.itemIconTintMode;
        r7 = android.support.p002v7.widget.DrawableUtils.parseTintMode(r7, r12);
        r2.itemIconTintMode = r7;
        goto L_0x020e;
    L_0x020b:
        r7 = 0;
        r2.itemIconTintMode = r7;
        r7 = 18;
        r12 = r3.hasValue(r7);
        if (r12 == 0) goto L_0x021f;
    L_0x0217:
        r7 = r3.getColorStateList(r7);
        r2.itemIconTintList = r7;
        r7 = 0;
        goto L_0x0222;
    L_0x021f:
        r7 = 0;
        r2.itemIconTintList = r7;
    L_0x0222:
        r3.recycle();
        r2.itemAdded = r8;
        r12 = r17;
        goto L_0x0248;
    L_0x022a:
        r7 = 0;
        r12 = r3.equals(r4);
        if (r12 == 0) goto L_0x023b;
    L_0x0231:
        r3 = r2.addSubMenuItem();
        r12 = r17;
        r0.parseMenu(r12, r1, r3);
        goto L_0x0248;
    L_0x023b:
        r12 = r17;
        r11 = r3;
        r10 = 1;
        goto L_0x0248;
    L_0x0240:
        r1 = new java.lang.RuntimeException;
        r2 = "Unexpected end of document";
        r1.<init>(r2);
        throw r1;
    L_0x0248:
        r3 = r17.next();
        goto L_0x0045;
    L_0x024e:
        return;
    L_0x024f:
        r12 = r17;
        goto L_0x000f;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.view.SupportMenuInflater.parseMenu(org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.view.Menu):void");
    }

    public final Object findRealOwner(Object obj) {
        if (obj instanceof Activity) {
            return obj;
        }
        if (obj instanceof ContextWrapper) {
            obj = findRealOwner(((ContextWrapper) obj).getBaseContext());
        }
        return obj;
    }

    public final void inflate(int i, Menu menu) {
        Throwable e;
        String str = "Error inflating menu XML";
        if (menu instanceof SupportMenu) {
            XmlResourceParser xmlResourceParser = null;
            try {
                xmlResourceParser = this.mContext.getResources().getLayout(i);
                try {
                    parseMenu(xmlResourceParser, Xml.asAttributeSet(xmlResourceParser), menu);
                    if (xmlResourceParser != null) {
                        xmlResourceParser.close();
                    }
                    return;
                } catch (XmlPullParserException e2) {
                    e = e2;
                    throw new InflateException(str, e);
                } catch (IOException e3) {
                    e = e3;
                    throw new InflateException(str, e);
                }
            } catch (XmlPullParserException e4) {
                e = e4;
                throw new InflateException(str, e);
            } catch (IOException e5) {
                e = e5;
                throw new InflateException(str, e);
            } catch (Throwable th) {
                e = th;
                if (xmlResourceParser != null) {
                    xmlResourceParser.close();
                }
                throw e;
            }
        }
        super.inflate(i, menu);
    }
}
