package android.support.p002v7.util;

import android.support.p002v7.widget.RecyclerView.Adapter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.util.DiffUtil */
public final class DiffUtil {
    private static final Comparator DIAGONAL_COMPARATOR = new PG();

    /* renamed from: android.support.v7.util.DiffUtil$1 */
    final class PG implements Comparator {
        public final /* bridge */ /* synthetic */ int compare(Object obj, Object obj2) {
            return ((Diagonal) obj).f5x - ((Diagonal) obj2).f5x;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.util.DiffUtil$Callback */
    public abstract class Callback {
        public abstract boolean areContentsTheSame(int i, int i2);

        public abstract boolean areItemsTheSame(int i, int i2);

        public Object getChangePayload$ar$ds(int i) {
            return null;
        }

        public abstract int getNewListSize();

        public abstract int getOldListSize();
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.util.DiffUtil$Diagonal */
    final class Diagonal {
        public final int size;
        /* renamed from: x */
        public final int f5x;
        /* renamed from: y */
        public final int f6y;

        public Diagonal(int i, int i2, int i3) {
            this.f5x = i;
            this.f6y = i2;
            this.size = i3;
        }

        final int endX() {
            return this.f5x + this.size;
        }

        final int endY() {
            return this.f6y + this.size;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.util.DiffUtil$DiffResult */
    public final class DiffResult {
        private final Callback mCallback;
        private final List mDiagonals;
        private final int[] mNewItemStatuses;
        private final int mNewListSize;
        private final int[] mOldItemStatuses;
        private final int mOldListSize;

        public DiffResult(Callback callback, List list, int[] iArr, int[] iArr2) {
            Diagonal diagonal;
            this.mDiagonals = list;
            this.mOldItemStatuses = iArr;
            this.mNewItemStatuses = iArr2;
            Arrays.fill(iArr, 0);
            Arrays.fill(iArr2, 0);
            this.mCallback = callback;
            int oldListSize = callback.getOldListSize();
            this.mOldListSize = oldListSize;
            int newListSize = callback.getNewListSize();
            this.mNewListSize = newListSize;
            if (list.isEmpty()) {
                diagonal = null;
            } else {
                diagonal = (Diagonal) list.get(0);
            }
            if (!(diagonal != null && diagonal.f5x == 0 && diagonal.f6y == 0)) {
                list.add(0, new Diagonal(0, 0, 0));
            }
            list.add(new Diagonal(oldListSize, newListSize, 0));
            for (Diagonal diagonal2 : list) {
                for (int i = 0; i < diagonal2.size; i++) {
                    int i2;
                    int i3 = diagonal2.f5x + i;
                    int i4 = diagonal2.f6y + i;
                    if (true != this.mCallback.areContentsTheSame(i3, i4)) {
                        i2 = 2;
                    } else {
                        i2 = 1;
                    }
                    this.mOldItemStatuses[i3] = (i4 << 4) | i2;
                    this.mNewItemStatuses[i4] = (i3 << 4) | i2;
                }
            }
            int i5 = 0;
            for (Diagonal diagonal3 : this.mDiagonals) {
                while (i5 < diagonal3.f5x) {
                    if (this.mOldItemStatuses[i5] == 0) {
                        i3 = this.mDiagonals.size();
                        i2 = 0;
                        for (i4 = 0; i4 < i3; i4++) {
                            Diagonal diagonal4 = (Diagonal) this.mDiagonals.get(i4);
                            while (i2 < diagonal4.f6y) {
                                if (this.mNewItemStatuses[i2] == 0 && this.mCallback.areItemsTheSame(i5, i2)) {
                                    if (true != this.mCallback.areContentsTheSame(i5, i2)) {
                                        i3 = 4;
                                    } else {
                                        i3 = 8;
                                    }
                                    this.mOldItemStatuses[i5] = (i2 << 4) | i3;
                                    this.mNewItemStatuses[i2] = i3 | (i5 << 4);
                                } else {
                                    i2++;
                                }
                            }
                            i2 = diagonal4.endY();
                        }
                    }
                    i5++;
                }
                i5 = diagonal3.endX();
            }
        }

        private static PostponedUpdate getPostponedUpdate(Collection collection, int i, boolean z) {
            PostponedUpdate postponedUpdate;
            Iterator it = collection.iterator();
            while (it.hasNext()) {
                postponedUpdate = (PostponedUpdate) it.next();
                if (postponedUpdate.posInOwnerList == i && postponedUpdate.removal == z) {
                    it.remove();
                    break;
                }
            }
            postponedUpdate = null;
            while (it.hasNext()) {
                PostponedUpdate postponedUpdate2 = (PostponedUpdate) it.next();
                if (z) {
                    postponedUpdate2.currentPos--;
                } else {
                    postponedUpdate2.currentPos++;
                }
            }
            return postponedUpdate;
        }

        public final void dispatchUpdatesTo(Adapter adapter) {
            BatchingListUpdateCallback batchingListUpdateCallback = new BatchingListUpdateCallback(new AdapterListUpdateCallback(adapter));
            int i = this.mOldListSize;
            Collection arrayDeque = new ArrayDeque();
            int i2 = this.mOldListSize;
            int i3 = this.mNewListSize;
            for (int size = this.mDiagonals.size() - 1; size >= 0; size--) {
                Diagonal diagonal = (Diagonal) this.mDiagonals.get(size);
                int endX = diagonal.endX();
                int endY = diagonal.endY();
                while (true) {
                    int i4 = 0;
                    if (i2 <= endX) {
                        break;
                    }
                    i2--;
                    int i5 = this.mOldItemStatuses[i2];
                    if ((i5 & 12) != 0) {
                        PostponedUpdate postponedUpdate = DiffResult.getPostponedUpdate(arrayDeque, i5 >> 4, false);
                        if (postponedUpdate != null) {
                            i4 = (i - postponedUpdate.currentPos) - 1;
                            batchingListUpdateCallback.onMoved(i2, i4);
                            if ((i5 & 4) != 0) {
                                batchingListUpdateCallback.onChanged$ar$ds(i4, this.mCallback.getChangePayload$ar$ds(i2));
                            }
                        } else {
                            arrayDeque.add(new PostponedUpdate(i2, (i - i2) - 1, true));
                        }
                    } else {
                        if (batchingListUpdateCallback.mLastEventType == 2) {
                            i4 = batchingListUpdateCallback.mLastEventPosition;
                            if (i4 >= i2 && i4 <= i2 + 1) {
                                batchingListUpdateCallback.mLastEventCount++;
                                batchingListUpdateCallback.mLastEventPosition = i2;
                                i--;
                            }
                        }
                        batchingListUpdateCallback.dispatchLastEvent();
                        batchingListUpdateCallback.mLastEventPosition = i2;
                        batchingListUpdateCallback.mLastEventCount = 1;
                        batchingListUpdateCallback.mLastEventType = 2;
                        i--;
                    }
                }
                while (i3 > endY) {
                    i3--;
                    endX = this.mNewItemStatuses[i3];
                    if ((endX & 12) != 0) {
                        i5 = endX >> 4;
                        PostponedUpdate postponedUpdate2 = DiffResult.getPostponedUpdate(arrayDeque, i5, true);
                        if (postponedUpdate2 == null) {
                            arrayDeque.add(new PostponedUpdate(i3, i - i2, false));
                        } else {
                            batchingListUpdateCallback.onMoved((i - postponedUpdate2.currentPos) - 1, i2);
                            if ((endX & 4) != 0) {
                                batchingListUpdateCallback.onChanged$ar$ds(i2, this.mCallback.getChangePayload$ar$ds(i5));
                            }
                        }
                    } else {
                        if (batchingListUpdateCallback.mLastEventType == 1) {
                            endX = batchingListUpdateCallback.mLastEventPosition;
                            if (i2 >= endX) {
                                i5 = batchingListUpdateCallback.mLastEventCount;
                                if (i2 <= endX + i5) {
                                    batchingListUpdateCallback.mLastEventCount = i5 + 1;
                                    batchingListUpdateCallback.mLastEventPosition = Math.min(i2, endX);
                                    i++;
                                }
                            }
                        }
                        batchingListUpdateCallback.dispatchLastEvent();
                        batchingListUpdateCallback.mLastEventPosition = i2;
                        batchingListUpdateCallback.mLastEventCount = 1;
                        batchingListUpdateCallback.mLastEventType = 1;
                        i++;
                    }
                }
                i2 = diagonal.f5x;
                i3 = diagonal.f6y;
                while (i4 < diagonal.size) {
                    if ((this.mOldItemStatuses[i2] & 15) == 2) {
                        batchingListUpdateCallback.onChanged$ar$ds(i2, this.mCallback.getChangePayload$ar$ds(i2));
                    }
                    i2++;
                    i4++;
                }
                i2 = diagonal.f5x;
                i3 = diagonal.f6y;
            }
            batchingListUpdateCallback.dispatchLastEvent();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.util.DiffUtil$PostponedUpdate */
    final class PostponedUpdate {
        int currentPos;
        final int posInOwnerList;
        final boolean removal;

        public PostponedUpdate(int i, int i2, boolean z) {
            this.posInOwnerList = i;
            this.currentPos = i2;
            this.removal = z;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.util.DiffUtil$Range */
    final class Range {
        int newListEnd;
        int newListStart;
        int oldListEnd;
        int oldListStart;

        public Range(int i, int i2) {
            this.oldListStart = 0;
            this.oldListEnd = i;
            this.newListStart = 0;
            this.newListEnd = i2;
        }

        final int newSize() {
            return this.newListEnd - this.newListStart;
        }

        final int oldSize() {
            return this.oldListEnd - this.oldListStart;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.util.DiffUtil$Snake */
    final class Snake {
        public int endX;
        public int endY;
        public boolean reverse;
        public int startX;
        public int startY;

        final int diagonalSize() {
            return Math.min(this.endX - this.startX, this.endY - this.startY);
        }
    }

    public static DiffResult calculateDiff(Callback callback) {
        Callback callback2 = callback;
        int oldListSize = callback.getOldListSize();
        int newListSize = callback.getNewListSize();
        List arrayList = new ArrayList();
        List arrayList2 = new ArrayList();
        arrayList2.add(new Range(oldListSize, newListSize));
        oldListSize += newListSize;
        newListSize = 1;
        oldListSize = (oldListSize + 1) / 2;
        oldListSize = (oldListSize + oldListSize) + 1;
        int[] iArr = new int[oldListSize];
        int i = oldListSize >> 1;
        int[] iArr2 = new int[oldListSize];
        ArrayList arrayList3 = new ArrayList();
        while (!arrayList2.isEmpty()) {
            List list;
            List list2;
            Range range;
            Snake snake;
            int oldSize;
            int i2;
            int i3;
            Object diagonal;
            Range range2;
            List list3;
            Range range3 = (Range) arrayList2.remove(arrayList2.size() - 1);
            if (range3.oldSize() > 0) {
                if (range3.newSize() <= 0) {
                    list = arrayList2;
                    list2 = arrayList3;
                    range = range3;
                    snake = null;
                } else {
                    oldSize = ((range3.oldSize() + range3.newSize()) + newListSize) / 2;
                    int i4 = i + 1;
                    iArr[i4] = range3.oldListStart;
                    iArr2[i4] = range3.oldListEnd;
                    int i5 = 0;
                    while (i5 < oldSize) {
                        int i6;
                        Snake snake2;
                        int abs = Math.abs(range3.oldSize() - range3.newSize()) % 2;
                        int oldSize2 = range3.oldSize() - range3.newSize();
                        int i7 = -i5;
                        int i8 = i7;
                        while (i8 <= i5) {
                            int i9;
                            if (i8 != i7) {
                                if (i8 == i5 || iArr[(i8 + 1) + i] <= iArr[(i8 - 1) + i]) {
                                    newListSize = iArr[(i8 - 1) + i];
                                    i4 = newListSize + 1;
                                    i6 = oldSize;
                                    list = arrayList2;
                                    oldSize = (range3.newListStart + (i4 - range3.oldListStart)) - i8;
                                    if (i5 != 0) {
                                        if (i4 != newListSize) {
                                            i2 = oldSize - 1;
                                            while (true) {
                                                list2 = arrayList3;
                                                if (i4 >= range3.oldListEnd || oldSize >= range3.newListEnd || !callback2.areItemsTheSame(i4, oldSize)) {
                                                    iArr[i8 + i] = i4;
                                                } else {
                                                    i4++;
                                                    oldSize++;
                                                    arrayList3 = list2;
                                                }
                                            }
                                            iArr[i8 + i] = i4;
                                            if (abs != 1) {
                                                i3 = oldSize2 - i8;
                                                i9 = abs;
                                                if (i3 >= i7 + 1 && i3 <= i5 - 1) {
                                                    if (iArr2[i3 + i] > i4) {
                                                        snake2 = new Snake();
                                                        snake2.startX = newListSize;
                                                        snake2.startY = i2;
                                                        snake2.endX = i4;
                                                        snake2.endY = oldSize;
                                                        snake2.reverse = false;
                                                        break;
                                                    }
                                                    i8 += 2;
                                                    oldSize = i6;
                                                    arrayList2 = list;
                                                    arrayList3 = list2;
                                                    abs = i9;
                                                }
                                            } else {
                                                i9 = abs;
                                            }
                                            i8 += 2;
                                            oldSize = i6;
                                            arrayList2 = list;
                                            arrayList3 = list2;
                                            abs = i9;
                                        }
                                    }
                                    i2 = oldSize;
                                    while (true) {
                                        list2 = arrayList3;
                                        if (i4 >= range3.oldListEnd) {
                                            break;
                                        }
                                        break;
                                        i4++;
                                        oldSize++;
                                        arrayList3 = list2;
                                    }
                                    iArr[i8 + i] = i4;
                                    if (abs != 1) {
                                        i3 = oldSize2 - i8;
                                        i9 = abs;
                                        if (iArr2[i3 + i] > i4) {
                                            snake2 = new Snake();
                                            snake2.startX = newListSize;
                                            snake2.startY = i2;
                                            snake2.endX = i4;
                                            snake2.endY = oldSize;
                                            snake2.reverse = false;
                                            break;
                                        }
                                        i8 += 2;
                                        oldSize = i6;
                                        arrayList2 = list;
                                        arrayList3 = list2;
                                        abs = i9;
                                    } else {
                                        i9 = abs;
                                    }
                                    i8 += 2;
                                    oldSize = i6;
                                    arrayList2 = list;
                                    arrayList3 = list2;
                                    abs = i9;
                                }
                            }
                            newListSize = iArr[(i8 + 1) + i];
                            i4 = newListSize;
                            i6 = oldSize;
                            list = arrayList2;
                            oldSize = (range3.newListStart + (i4 - range3.oldListStart)) - i8;
                            if (i5 != 0) {
                                if (i4 != newListSize) {
                                    i2 = oldSize - 1;
                                    while (true) {
                                        list2 = arrayList3;
                                        if (i4 >= range3.oldListEnd) {
                                            break;
                                        }
                                        break;
                                        i4++;
                                        oldSize++;
                                        arrayList3 = list2;
                                    }
                                    iArr[i8 + i] = i4;
                                    if (abs != 1) {
                                        i3 = oldSize2 - i8;
                                        i9 = abs;
                                        if (iArr2[i3 + i] > i4) {
                                            snake2 = new Snake();
                                            snake2.startX = newListSize;
                                            snake2.startY = i2;
                                            snake2.endX = i4;
                                            snake2.endY = oldSize;
                                            snake2.reverse = false;
                                            break;
                                        }
                                        i8 += 2;
                                        oldSize = i6;
                                        arrayList2 = list;
                                        arrayList3 = list2;
                                        abs = i9;
                                    } else {
                                        i9 = abs;
                                    }
                                    i8 += 2;
                                    oldSize = i6;
                                    arrayList2 = list;
                                    arrayList3 = list2;
                                    abs = i9;
                                }
                            }
                            i2 = oldSize;
                            while (true) {
                                list2 = arrayList3;
                                if (i4 >= range3.oldListEnd) {
                                    break;
                                }
                                break;
                                i4++;
                                oldSize++;
                                arrayList3 = list2;
                            }
                            iArr[i8 + i] = i4;
                            if (abs != 1) {
                                i3 = oldSize2 - i8;
                                i9 = abs;
                                if (iArr2[i3 + i] > i4) {
                                    snake2 = new Snake();
                                    snake2.startX = newListSize;
                                    snake2.startY = i2;
                                    snake2.endX = i4;
                                    snake2.endY = oldSize;
                                    snake2.reverse = false;
                                    break;
                                }
                                i8 += 2;
                                oldSize = i6;
                                arrayList2 = list;
                                arrayList3 = list2;
                                abs = i9;
                            } else {
                                i9 = abs;
                            }
                            i8 += 2;
                            oldSize = i6;
                            arrayList2 = list;
                            arrayList3 = list2;
                            abs = i9;
                        }
                        list = arrayList2;
                        list2 = arrayList3;
                        i6 = oldSize;
                        snake2 = null;
                        if (snake2 != null) {
                            snake = snake2;
                            range = range3;
                            break;
                        }
                        Snake snake3;
                        i2 = (range3.oldSize() - range3.newSize()) % 2;
                        i3 = range3.oldSize() - range3.newSize();
                        oldSize = i7;
                        while (oldSize <= i5) {
                            int i10;
                            if (oldSize != i7) {
                                if (oldSize == i5 || iArr2[(oldSize + 1) + i] >= iArr2[(oldSize - 1) + i]) {
                                    i8 = iArr2[(oldSize - 1) + i];
                                    i4 = i8 - 1;
                                    abs = range3.newListEnd - ((range3.oldListEnd - i4) - oldSize);
                                    if (i5 != 0) {
                                        if (i4 != i8) {
                                            oldSize2 = abs + 1;
                                            while (i4 > range3.oldListStart && abs > range3.newListStart) {
                                                newListSize = i4 - 1;
                                                range = range3;
                                                i10 = abs - 1;
                                                if (!callback2.areItemsTheSame(newListSize, i10)) {
                                                    break;
                                                }
                                                i4 = newListSize;
                                                abs = i10;
                                                range3 = range;
                                            }
                                            range = range3;
                                            iArr2[oldSize + i] = i4;
                                            if (i2 == 0) {
                                                newListSize = i3 - oldSize;
                                                if (newListSize >= i7 && newListSize <= i5) {
                                                    if (iArr[newListSize + i] < i4) {
                                                        snake3 = new Snake();
                                                        snake3.startX = i4;
                                                        snake3.startY = abs;
                                                        snake3.endX = i8;
                                                        snake3.endY = oldSize2;
                                                        snake3.reverse = true;
                                                        break;
                                                    }
                                                    oldSize += 2;
                                                    range3 = range;
                                                }
                                            }
                                            oldSize += 2;
                                            range3 = range;
                                        }
                                    }
                                    oldSize2 = abs;
                                    while (i4 > range3.oldListStart) {
                                        newListSize = i4 - 1;
                                        range = range3;
                                        i10 = abs - 1;
                                        if (!callback2.areItemsTheSame(newListSize, i10)) {
                                            break;
                                        }
                                        i4 = newListSize;
                                        abs = i10;
                                        range3 = range;
                                    }
                                    range = range3;
                                    iArr2[oldSize + i] = i4;
                                    if (i2 == 0) {
                                        newListSize = i3 - oldSize;
                                        if (iArr[newListSize + i] < i4) {
                                            snake3 = new Snake();
                                            snake3.startX = i4;
                                            snake3.startY = abs;
                                            snake3.endX = i8;
                                            snake3.endY = oldSize2;
                                            snake3.reverse = true;
                                            break;
                                        }
                                        oldSize += 2;
                                        range3 = range;
                                    }
                                    oldSize += 2;
                                    range3 = range;
                                }
                            }
                            i8 = iArr2[(oldSize + 1) + i];
                            i4 = i8;
                            abs = range3.newListEnd - ((range3.oldListEnd - i4) - oldSize);
                            if (i5 != 0) {
                                if (i4 != i8) {
                                    oldSize2 = abs + 1;
                                    while (i4 > range3.oldListStart) {
                                        newListSize = i4 - 1;
                                        range = range3;
                                        i10 = abs - 1;
                                        if (!callback2.areItemsTheSame(newListSize, i10)) {
                                            break;
                                        }
                                        i4 = newListSize;
                                        abs = i10;
                                        range3 = range;
                                    }
                                    range = range3;
                                    iArr2[oldSize + i] = i4;
                                    if (i2 == 0) {
                                        newListSize = i3 - oldSize;
                                        if (iArr[newListSize + i] < i4) {
                                            snake3 = new Snake();
                                            snake3.startX = i4;
                                            snake3.startY = abs;
                                            snake3.endX = i8;
                                            snake3.endY = oldSize2;
                                            snake3.reverse = true;
                                            break;
                                        }
                                        oldSize += 2;
                                        range3 = range;
                                    }
                                    oldSize += 2;
                                    range3 = range;
                                }
                            }
                            oldSize2 = abs;
                            while (i4 > range3.oldListStart) {
                                newListSize = i4 - 1;
                                range = range3;
                                i10 = abs - 1;
                                if (!callback2.areItemsTheSame(newListSize, i10)) {
                                    break;
                                }
                                i4 = newListSize;
                                abs = i10;
                                range3 = range;
                            }
                            range = range3;
                            iArr2[oldSize + i] = i4;
                            if (i2 == 0) {
                                newListSize = i3 - oldSize;
                                if (iArr[newListSize + i] < i4) {
                                    snake3 = new Snake();
                                    snake3.startX = i4;
                                    snake3.startY = abs;
                                    snake3.endX = i8;
                                    snake3.endY = oldSize2;
                                    snake3.reverse = true;
                                    break;
                                }
                                oldSize += 2;
                                range3 = range;
                            }
                            oldSize += 2;
                            range3 = range;
                        }
                        range = range3;
                        snake3 = null;
                        if (snake3 != null) {
                            snake = snake3;
                            break;
                        }
                        i5++;
                        oldSize = i6;
                        arrayList2 = list;
                        List list4 = list2;
                        range3 = range;
                    }
                }
                if (snake == null) {
                    if (snake.diagonalSize() > 0) {
                        newListSize = snake.endY;
                        i2 = snake.startY;
                        newListSize -= i2;
                        i3 = snake.endX;
                        oldSize = snake.startX;
                        i3 -= oldSize;
                        if (newListSize != i3) {
                            diagonal = new Diagonal(oldSize, i2, i3);
                        } else if (snake.reverse) {
                            diagonal = new Diagonal(oldSize, i2, snake.diagonalSize());
                        } else if (newListSize <= i3) {
                            diagonal = new Diagonal(oldSize, i2 + 1, snake.diagonalSize());
                        } else {
                            diagonal = new Diagonal(oldSize + 1, i2, snake.diagonalSize());
                        }
                        arrayList.add(diagonal);
                    }
                    if (list2.isEmpty()) {
                        arrayList2 = list2;
                        range2 = (Range) arrayList2.remove(list2.size() - 1);
                    } else {
                        range2 = new Range();
                        arrayList2 = list2;
                    }
                    Range range4 = range;
                    range2.oldListStart = range4.oldListStart;
                    range2.newListStart = range4.newListStart;
                    range2.oldListEnd = snake.startX;
                    range2.newListEnd = snake.startY;
                    list3 = list;
                    list3.add(range2);
                    newListSize = range4.oldListEnd;
                    newListSize = range4.newListEnd;
                    range4.oldListStart = snake.endX;
                    range4.newListStart = snake.endY;
                    list3.add(range4);
                    arrayList3 = arrayList2;
                    arrayList2 = list3;
                    newListSize = 1;
                } else {
                    list3 = list;
                    arrayList2 = list2;
                    arrayList2.add(range);
                    arrayList3 = arrayList2;
                    arrayList2 = list3;
                    newListSize = 1;
                }
            }
            list = arrayList2;
            list2 = arrayList3;
            range = range3;
            snake = null;
            if (snake == null) {
                list3 = list;
                arrayList2 = list2;
                arrayList2.add(range);
                arrayList3 = arrayList2;
                arrayList2 = list3;
                newListSize = 1;
            } else {
                if (snake.diagonalSize() > 0) {
                    newListSize = snake.endY;
                    i2 = snake.startY;
                    newListSize -= i2;
                    i3 = snake.endX;
                    oldSize = snake.startX;
                    i3 -= oldSize;
                    if (newListSize != i3) {
                        diagonal = new Diagonal(oldSize, i2, i3);
                    } else if (snake.reverse) {
                        diagonal = new Diagonal(oldSize, i2, snake.diagonalSize());
                    } else if (newListSize <= i3) {
                        diagonal = new Diagonal(oldSize + 1, i2, snake.diagonalSize());
                    } else {
                        diagonal = new Diagonal(oldSize, i2 + 1, snake.diagonalSize());
                    }
                    arrayList.add(diagonal);
                }
                if (list2.isEmpty()) {
                    arrayList2 = list2;
                    range2 = (Range) arrayList2.remove(list2.size() - 1);
                } else {
                    range2 = new Range();
                    arrayList2 = list2;
                }
                Range range42 = range;
                range2.oldListStart = range42.oldListStart;
                range2.newListStart = range42.newListStart;
                range2.oldListEnd = snake.startX;
                range2.newListEnd = snake.startY;
                list3 = list;
                list3.add(range2);
                newListSize = range42.oldListEnd;
                newListSize = range42.newListEnd;
                range42.oldListStart = snake.endX;
                range42.newListStart = snake.endY;
                list3.add(range42);
                arrayList3 = arrayList2;
                arrayList2 = list3;
                newListSize = 1;
            }
        }
        Collections.sort(arrayList, DIAGONAL_COMPARATOR);
        return new DiffResult(callback2, arrayList, iArr, iArr2);
    }
}
