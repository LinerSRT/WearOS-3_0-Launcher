package android.support.p002v7.util;

/* compiled from: PG */
/* renamed from: android.support.v7.util.ListUpdateCallback */
public interface ListUpdateCallback {
}
