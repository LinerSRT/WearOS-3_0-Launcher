package android.support.p002v7.util;

/* compiled from: PG */
/* renamed from: android.support.v7.util.BatchingListUpdateCallback */
public final class BatchingListUpdateCallback implements ListUpdateCallback {
    int mLastEventCount = -1;
    Object mLastEventPayload = null;
    int mLastEventPosition = -1;
    int mLastEventType = 0;
    final ListUpdateCallback mWrapped;

    public BatchingListUpdateCallback(ListUpdateCallback listUpdateCallback) {
        this.mWrapped = listUpdateCallback;
    }

    public final void onMoved(int i, int i2) {
        dispatchLastEvent();
        ((AdapterListUpdateCallback) this.mWrapped).mAdapter.notifyItemMoved(i, i2);
    }

    public final void dispatchLastEvent() {
        int i = this.mLastEventType;
        if (i != 0) {
            ListUpdateCallback listUpdateCallback;
            switch (i) {
                case 1:
                    listUpdateCallback = this.mWrapped;
                    ((AdapterListUpdateCallback) listUpdateCallback).mAdapter.notifyItemRangeInserted(this.mLastEventPosition, this.mLastEventCount);
                    break;
                case 2:
                    listUpdateCallback = this.mWrapped;
                    ((AdapterListUpdateCallback) listUpdateCallback).mAdapter.notifyItemRangeRemoved(this.mLastEventPosition, this.mLastEventCount);
                    break;
                default:
                    listUpdateCallback = this.mWrapped;
                    ((AdapterListUpdateCallback) listUpdateCallback).mAdapter.notifyItemRangeChanged(this.mLastEventPosition, this.mLastEventCount, this.mLastEventPayload);
                    break;
            }
            this.mLastEventPayload = null;
            this.mLastEventType = 0;
        }
    }

    public final void onChanged$ar$ds(int i, Object obj) {
        if (this.mLastEventType == 3) {
            int i2 = this.mLastEventPosition;
            int i3 = this.mLastEventCount + i2;
            if (i <= i3) {
                int i4 = i + 1;
                if (i4 >= i2 && this.mLastEventPayload == obj) {
                    this.mLastEventPosition = Math.min(i, i2);
                    this.mLastEventCount = Math.max(i3, i4) - this.mLastEventPosition;
                    return;
                }
            }
        }
        dispatchLastEvent();
        this.mLastEventPosition = i;
        this.mLastEventCount = 1;
        this.mLastEventPayload = obj;
        this.mLastEventType = 3;
    }
}
