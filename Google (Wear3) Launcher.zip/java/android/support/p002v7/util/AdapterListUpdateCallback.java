package android.support.p002v7.util;

import android.support.p002v7.widget.RecyclerView.Adapter;

/* compiled from: PG */
/* renamed from: android.support.v7.util.AdapterListUpdateCallback */
public final class AdapterListUpdateCallback implements ListUpdateCallback {
    public final Adapter mAdapter;

    public AdapterListUpdateCallback(Adapter adapter) {
        this.mAdapter = adapter;
    }
}
