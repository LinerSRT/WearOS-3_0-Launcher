package android.support.p002v7.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;

/* compiled from: PG */
/* renamed from: android.support.v7.graphics.drawable.DrawableWrapper */
public class DrawableWrapper extends Drawable implements Callback {
    public final Drawable mDrawable;

    public DrawableWrapper(Drawable drawable) {
        Drawable drawable2 = this.mDrawable;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.mDrawable = drawable;
        drawable.setCallback(this);
    }

    public void draw(Canvas canvas) {
        this.mDrawable.draw(canvas);
    }

    public final int getChangingConfigurations() {
        return this.mDrawable.getChangingConfigurations();
    }

    public final Drawable getCurrent() {
        return this.mDrawable.getCurrent();
    }

    public final int getIntrinsicHeight() {
        return this.mDrawable.getIntrinsicHeight();
    }

    public final int getIntrinsicWidth() {
        return this.mDrawable.getIntrinsicWidth();
    }

    public final int getMinimumHeight() {
        return this.mDrawable.getMinimumHeight();
    }

    public final int getMinimumWidth() {
        return this.mDrawable.getMinimumWidth();
    }

    public final int getOpacity() {
        return this.mDrawable.getOpacity();
    }

    public final boolean getPadding(Rect rect) {
        return this.mDrawable.getPadding(rect);
    }

    public final int[] getState() {
        return this.mDrawable.getState();
    }

    public final Region getTransparentRegion() {
        return this.mDrawable.getTransparentRegion();
    }

    public final void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    public final boolean isStateful() {
        return this.mDrawable.isStateful();
    }

    public final void jumpToCurrentState() {
        this.mDrawable.jumpToCurrentState();
    }

    protected final void onBoundsChange(Rect rect) {
        this.mDrawable.setBounds(rect);
    }

    protected final boolean onLevelChange(int i) {
        return this.mDrawable.setLevel(i);
    }

    public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        scheduleSelf(runnable, j);
    }

    public final void setAlpha(int i) {
        this.mDrawable.setAlpha(i);
    }

    public final void setChangingConfigurations(int i) {
        this.mDrawable.setChangingConfigurations(i);
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        this.mDrawable.setColorFilter(colorFilter);
    }

    public final void setDither(boolean z) {
        this.mDrawable.setDither(z);
    }

    public final void setFilterBitmap(boolean z) {
        this.mDrawable.setFilterBitmap(z);
    }

    public boolean setState(int[] iArr) {
        return this.mDrawable.setState(iArr);
    }

    public boolean setVisible(boolean z, boolean z2) {
        if (!super.setVisible(z, z2)) {
            if (!this.mDrawable.setVisible(z, z2)) {
                return false;
            }
        }
        return true;
    }

    public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }

    public final boolean isAutoMirrored() {
        return this.mDrawable.isAutoMirrored();
    }

    public final void setAutoMirrored(boolean z) {
        this.mDrawable.setAutoMirrored(z);
    }

    public void setHotspot(float f, float f2) {
        this.mDrawable.setHotspot(f, f2);
    }

    public void setHotspotBounds(int i, int i2, int i3, int i4) {
        this.mDrawable.setHotspotBounds(i, i2, i3, i4);
    }

    public final void setTint(int i) {
        this.mDrawable.setTint(i);
    }

    public final void setTintList(ColorStateList colorStateList) {
        this.mDrawable.setTintList(colorStateList);
    }

    public final void setTintMode(Mode mode) {
        this.mDrawable.setTintMode(mode);
    }
}
