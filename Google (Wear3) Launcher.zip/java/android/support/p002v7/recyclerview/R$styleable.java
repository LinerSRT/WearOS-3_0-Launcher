package android.support.p002v7.recyclerview;

import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.recyclerview.R$styleable */
public final class R$styleable {
    public static final int[] RecyclerView = new int[]{16842948, 16842987, 16842993, R.attr.fastScrollEnabled, R.attr.fastScrollHorizontalThumbDrawable, R.attr.fastScrollHorizontalTrackDrawable, R.attr.fastScrollVerticalThumbDrawable, R.attr.fastScrollVerticalTrackDrawable, R.attr.layoutManager, R.attr.reverseLayout, R.attr.spanCount, R.attr.stackFromEnd};
}
