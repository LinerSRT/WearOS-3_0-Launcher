package android.support.p002v7.widget;

import android.content.res.AssetFileDescriptor;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Movie;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import java.io.InputStream;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ResourcesWrapper */
class ResourcesWrapper extends Resources {
    public final XmlResourceParser getAnimation(int i) {
        throw null;
    }

    public final boolean getBoolean(int i) {
        throw null;
    }

    public final int getColor(int i) {
        throw null;
    }

    public final ColorStateList getColorStateList(int i) {
        throw null;
    }

    public final Configuration getConfiguration() {
        throw null;
    }

    public final float getDimension(int i) {
        throw null;
    }

    public final int getDimensionPixelOffset(int i) {
        throw null;
    }

    public final int getDimensionPixelSize(int i) {
        throw null;
    }

    public final DisplayMetrics getDisplayMetrics() {
        throw null;
    }

    public Drawable getDrawable(int i) {
        throw null;
    }

    public final Drawable getDrawable(int i, Theme theme) {
        throw null;
    }

    public final Drawable getDrawableForDensity(int i, int i2) {
        throw null;
    }

    public final Drawable getDrawableForDensity(int i, int i2, Theme theme) {
        throw null;
    }

    public final float getFraction(int i, int i2, int i3) {
        throw null;
    }

    public final int getIdentifier(String str, String str2, String str3) {
        throw null;
    }

    public final int[] getIntArray(int i) {
        throw null;
    }

    public final int getInteger(int i) {
        throw null;
    }

    public final XmlResourceParser getLayout(int i) {
        throw null;
    }

    public final Movie getMovie(int i) {
        throw null;
    }

    public final String getQuantityString(int i, int i2) {
        throw null;
    }

    public final String getQuantityString(int i, int i2, Object... objArr) {
        throw null;
    }

    public final CharSequence getQuantityText(int i, int i2) {
        throw null;
    }

    public final String getResourceEntryName(int i) {
        throw null;
    }

    public final String getResourceName(int i) {
        throw null;
    }

    public final String getResourcePackageName(int i) {
        throw null;
    }

    public final String getResourceTypeName(int i) {
        throw null;
    }

    public final String getString(int i) {
        throw null;
    }

    public final String getString(int i, Object... objArr) {
        throw null;
    }

    public final String[] getStringArray(int i) {
        throw null;
    }

    public final CharSequence getText(int i) {
        throw null;
    }

    public final CharSequence getText(int i, CharSequence charSequence) {
        throw null;
    }

    public final CharSequence[] getTextArray(int i) {
        throw null;
    }

    public final void getValue(int i, TypedValue typedValue, boolean z) {
        throw null;
    }

    public final void getValue(String str, TypedValue typedValue, boolean z) {
        throw null;
    }

    public final void getValueForDensity(int i, int i2, TypedValue typedValue, boolean z) {
        throw null;
    }

    public final XmlResourceParser getXml(int i) {
        throw null;
    }

    public final TypedArray obtainAttributes(AttributeSet attributeSet, int[] iArr) {
        throw null;
    }

    public final TypedArray obtainTypedArray(int i) {
        throw null;
    }

    public final InputStream openRawResource(int i) {
        throw null;
    }

    public final InputStream openRawResource(int i, TypedValue typedValue) {
        throw null;
    }

    public final AssetFileDescriptor openRawResourceFd(int i) {
        throw null;
    }

    public final void parseBundleExtra(String str, AttributeSet attributeSet, Bundle bundle) {
        throw null;
    }

    public final void parseBundleExtras(XmlResourceParser xmlResourceParser, Bundle bundle) {
        throw null;
    }

    public final void updateConfiguration(Configuration configuration, DisplayMetrics displayMetrics) {
        throw null;
    }
}
