package android.support.p002v7.widget.helper;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.support.p000v4.view.GestureDetectorCompat;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.widget.RecyclerView;
import android.support.p002v7.widget.RecyclerView.ItemAnimator;
import android.support.p002v7.widget.RecyclerView.ItemDecoration;
import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.OnChildAttachStateChangeListener;
import android.support.p002v7.widget.RecyclerView.OnItemTouchListener;
import android.support.p002v7.widget.RecyclerView.State;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.support.p002v7.widget.helper.ItemTouchHelper.RecoverAnimation;
import android.support.v7.widget.helper.ItemTouchHelper.C01152;
import android.support.v7.widget.helper.ItemTouchHelper.Callback.C01182;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.view.animation.Interpolator;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.helper.ItemTouchHelper */
public final class ItemTouchHelper extends ItemDecoration implements OnChildAttachStateChangeListener {
    private int mActionState = 0;
    int mActivePointerId = -1;
    final Callback mCallback;
    private List mDistances;
    public long mDragScrollStartTimeInMs;
    float mDx;
    float mDy;
    GestureDetectorCompat mGestureDetector;
    float mInitialTouchX;
    float mInitialTouchY;
    private ItemTouchHelperGestureListener mItemTouchHelperGestureListener;
    private float mMaxSwipeVelocity;
    private final OnItemTouchListener mOnItemTouchListener = new C01152();
    View mOverdrawChild = null;
    final List mPendingCleanup = new ArrayList();
    final List mRecoverAnimations = new ArrayList();
    RecyclerView mRecyclerView;
    final Runnable mScrollRunnable = new PG();
    ViewHolder mSelected = null;
    int mSelectedFlags;
    public float mSelectedStartX;
    public float mSelectedStartY;
    private int mSlop;
    private List mSwapTargets;
    private float mSwipeEscapeVelocity;
    private final float[] mTmpPosition = new float[2];
    public Rect mTmpRect;
    VelocityTracker mVelocityTracker;

    /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$1 */
    final class PG implements Runnable {
        public final void run() {
            ItemTouchHelper itemTouchHelper = ItemTouchHelper.this;
            if (itemTouchHelper.mSelected != null) {
                int i;
                int paddingLeft;
                float f;
                int i2;
                int i3;
                int i4;
                Callback callback;
                RecyclerView recyclerView;
                int width;
                ViewHolder viewHolder;
                long currentTimeMillis = System.currentTimeMillis();
                long j = itemTouchHelper.mDragScrollStartTimeInMs;
                if (j == Long.MIN_VALUE) {
                    j = 0;
                } else {
                    j = currentTimeMillis - j;
                }
                LayoutManager layoutManager = itemTouchHelper.mRecyclerView.mLayout;
                if (itemTouchHelper.mTmpRect == null) {
                    itemTouchHelper.mTmpRect = new Rect();
                }
                layoutManager.calculateItemDecorationsForChild(itemTouchHelper.mSelected.itemView, itemTouchHelper.mTmpRect);
                int i5 = 0;
                if (layoutManager.canScrollHorizontally()) {
                    i = (int) (itemTouchHelper.mSelectedStartX + itemTouchHelper.mDx);
                    paddingLeft = (i - itemTouchHelper.mTmpRect.left) - itemTouchHelper.mRecyclerView.getPaddingLeft();
                    f = itemTouchHelper.mDx;
                    if (f < 0.0f && paddingLeft < 0) {
                        if (layoutManager.canScrollVertically()) {
                            i2 = (int) (itemTouchHelper.mSelectedStartY + itemTouchHelper.mDy);
                            i = (i2 - itemTouchHelper.mTmpRect.top) - itemTouchHelper.mRecyclerView.getPaddingTop();
                            f = itemTouchHelper.mDy;
                            if (f >= 0.0f) {
                            }
                            if (f > 0.0f) {
                                i2 = ((i2 + itemTouchHelper.mSelected.itemView.getHeight()) + itemTouchHelper.mTmpRect.bottom) - (itemTouchHelper.mRecyclerView.getHeight() - itemTouchHelper.mRecyclerView.getPaddingBottom());
                                if (i2 <= 0) {
                                    i3 = i2;
                                    if (paddingLeft != 0) {
                                        i4 = paddingLeft;
                                    } else {
                                        callback = itemTouchHelper.mCallback;
                                        recyclerView = itemTouchHelper.mRecyclerView;
                                        width = itemTouchHelper.mSelected.itemView.getWidth();
                                        itemTouchHelper.mRecyclerView.getWidth();
                                        i4 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, paddingLeft, j);
                                    }
                                    if (i3 == 0) {
                                        callback = itemTouchHelper.mCallback;
                                        recyclerView = itemTouchHelper.mRecyclerView;
                                        width = itemTouchHelper.mSelected.itemView.getHeight();
                                        itemTouchHelper.mRecyclerView.getHeight();
                                        i3 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, i3, j);
                                    }
                                    if (i4 == 0) {
                                        i5 = i4;
                                    } else if (i3 != 0) {
                                        itemTouchHelper.mDragScrollStartTimeInMs = Long.MIN_VALUE;
                                        return;
                                    }
                                    if (itemTouchHelper.mDragScrollStartTimeInMs == Long.MIN_VALUE) {
                                        itemTouchHelper.mDragScrollStartTimeInMs = currentTimeMillis;
                                    }
                                    itemTouchHelper.mRecyclerView.scrollBy(i5, i3);
                                    itemTouchHelper = ItemTouchHelper.this;
                                    viewHolder = itemTouchHelper.mSelected;
                                    if (viewHolder != null) {
                                        itemTouchHelper.moveIfNecessary(viewHolder);
                                    }
                                    itemTouchHelper = ItemTouchHelper.this;
                                    itemTouchHelper.mRecyclerView.removeCallbacks(itemTouchHelper.mScrollRunnable);
                                    ViewCompat.postOnAnimation(ItemTouchHelper.this.mRecyclerView, r0);
                                }
                            }
                        }
                        i3 = 0;
                        if (paddingLeft != 0) {
                            callback = itemTouchHelper.mCallback;
                            recyclerView = itemTouchHelper.mRecyclerView;
                            width = itemTouchHelper.mSelected.itemView.getWidth();
                            itemTouchHelper.mRecyclerView.getWidth();
                            i4 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, paddingLeft, j);
                        } else {
                            i4 = paddingLeft;
                        }
                        if (i3 == 0) {
                            callback = itemTouchHelper.mCallback;
                            recyclerView = itemTouchHelper.mRecyclerView;
                            width = itemTouchHelper.mSelected.itemView.getHeight();
                            itemTouchHelper.mRecyclerView.getHeight();
                            i3 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, i3, j);
                        }
                        if (i4 == 0) {
                            i5 = i4;
                        } else if (i3 != 0) {
                            itemTouchHelper.mDragScrollStartTimeInMs = Long.MIN_VALUE;
                            return;
                        }
                        if (itemTouchHelper.mDragScrollStartTimeInMs == Long.MIN_VALUE) {
                            itemTouchHelper.mDragScrollStartTimeInMs = currentTimeMillis;
                        }
                        itemTouchHelper.mRecyclerView.scrollBy(i5, i3);
                        itemTouchHelper = ItemTouchHelper.this;
                        viewHolder = itemTouchHelper.mSelected;
                        if (viewHolder != null) {
                            itemTouchHelper.moveIfNecessary(viewHolder);
                        }
                        itemTouchHelper = ItemTouchHelper.this;
                        itemTouchHelper.mRecyclerView.removeCallbacks(itemTouchHelper.mScrollRunnable);
                        ViewCompat.postOnAnimation(ItemTouchHelper.this.mRecyclerView, r0);
                    } else if (f > 0.0f) {
                        i = ((i + itemTouchHelper.mSelected.itemView.getWidth()) + itemTouchHelper.mTmpRect.right) - (itemTouchHelper.mRecyclerView.getWidth() - itemTouchHelper.mRecyclerView.getPaddingRight());
                        if (i > 0) {
                            paddingLeft = i;
                            if (layoutManager.canScrollVertically()) {
                                i2 = (int) (itemTouchHelper.mSelectedStartY + itemTouchHelper.mDy);
                                i = (i2 - itemTouchHelper.mTmpRect.top) - itemTouchHelper.mRecyclerView.getPaddingTop();
                                f = itemTouchHelper.mDy;
                                if (f >= 0.0f && i < 0) {
                                    i3 = i;
                                    if (paddingLeft != 0) {
                                        i4 = paddingLeft;
                                    } else {
                                        callback = itemTouchHelper.mCallback;
                                        recyclerView = itemTouchHelper.mRecyclerView;
                                        width = itemTouchHelper.mSelected.itemView.getWidth();
                                        itemTouchHelper.mRecyclerView.getWidth();
                                        i4 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, paddingLeft, j);
                                    }
                                    if (i3 == 0) {
                                        callback = itemTouchHelper.mCallback;
                                        recyclerView = itemTouchHelper.mRecyclerView;
                                        width = itemTouchHelper.mSelected.itemView.getHeight();
                                        itemTouchHelper.mRecyclerView.getHeight();
                                        i3 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, i3, j);
                                    }
                                    if (i4 == 0) {
                                        i5 = i4;
                                    } else if (i3 != 0) {
                                        itemTouchHelper.mDragScrollStartTimeInMs = Long.MIN_VALUE;
                                        return;
                                    }
                                    if (itemTouchHelper.mDragScrollStartTimeInMs == Long.MIN_VALUE) {
                                        itemTouchHelper.mDragScrollStartTimeInMs = currentTimeMillis;
                                    }
                                    itemTouchHelper.mRecyclerView.scrollBy(i5, i3);
                                    itemTouchHelper = ItemTouchHelper.this;
                                    viewHolder = itemTouchHelper.mSelected;
                                    if (viewHolder != null) {
                                        itemTouchHelper.moveIfNecessary(viewHolder);
                                    }
                                    itemTouchHelper = ItemTouchHelper.this;
                                    itemTouchHelper.mRecyclerView.removeCallbacks(itemTouchHelper.mScrollRunnable);
                                    ViewCompat.postOnAnimation(ItemTouchHelper.this.mRecyclerView, r0);
                                } else if (f > 0.0f) {
                                    i2 = ((i2 + itemTouchHelper.mSelected.itemView.getHeight()) + itemTouchHelper.mTmpRect.bottom) - (itemTouchHelper.mRecyclerView.getHeight() - itemTouchHelper.mRecyclerView.getPaddingBottom());
                                    if (i2 <= 0) {
                                        i3 = i2;
                                        if (paddingLeft != 0) {
                                            callback = itemTouchHelper.mCallback;
                                            recyclerView = itemTouchHelper.mRecyclerView;
                                            width = itemTouchHelper.mSelected.itemView.getWidth();
                                            itemTouchHelper.mRecyclerView.getWidth();
                                            i4 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, paddingLeft, j);
                                        } else {
                                            i4 = paddingLeft;
                                        }
                                        if (i3 == 0) {
                                            callback = itemTouchHelper.mCallback;
                                            recyclerView = itemTouchHelper.mRecyclerView;
                                            width = itemTouchHelper.mSelected.itemView.getHeight();
                                            itemTouchHelper.mRecyclerView.getHeight();
                                            i3 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, i3, j);
                                        }
                                        if (i4 == 0) {
                                            i5 = i4;
                                        } else if (i3 != 0) {
                                            itemTouchHelper.mDragScrollStartTimeInMs = Long.MIN_VALUE;
                                            return;
                                        }
                                        if (itemTouchHelper.mDragScrollStartTimeInMs == Long.MIN_VALUE) {
                                            itemTouchHelper.mDragScrollStartTimeInMs = currentTimeMillis;
                                        }
                                        itemTouchHelper.mRecyclerView.scrollBy(i5, i3);
                                        itemTouchHelper = ItemTouchHelper.this;
                                        viewHolder = itemTouchHelper.mSelected;
                                        if (viewHolder != null) {
                                            itemTouchHelper.moveIfNecessary(viewHolder);
                                        }
                                        itemTouchHelper = ItemTouchHelper.this;
                                        itemTouchHelper.mRecyclerView.removeCallbacks(itemTouchHelper.mScrollRunnable);
                                        ViewCompat.postOnAnimation(ItemTouchHelper.this.mRecyclerView, r0);
                                    }
                                }
                            }
                            i3 = 0;
                            if (paddingLeft != 0) {
                                callback = itemTouchHelper.mCallback;
                                recyclerView = itemTouchHelper.mRecyclerView;
                                width = itemTouchHelper.mSelected.itemView.getWidth();
                                itemTouchHelper.mRecyclerView.getWidth();
                                i4 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, paddingLeft, j);
                            } else {
                                i4 = paddingLeft;
                            }
                            if (i3 == 0) {
                                callback = itemTouchHelper.mCallback;
                                recyclerView = itemTouchHelper.mRecyclerView;
                                width = itemTouchHelper.mSelected.itemView.getHeight();
                                itemTouchHelper.mRecyclerView.getHeight();
                                i3 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, i3, j);
                            }
                            if (i4 == 0) {
                                i5 = i4;
                            } else if (i3 != 0) {
                                itemTouchHelper.mDragScrollStartTimeInMs = Long.MIN_VALUE;
                                return;
                            }
                            if (itemTouchHelper.mDragScrollStartTimeInMs == Long.MIN_VALUE) {
                                itemTouchHelper.mDragScrollStartTimeInMs = currentTimeMillis;
                            }
                            itemTouchHelper.mRecyclerView.scrollBy(i5, i3);
                            itemTouchHelper = ItemTouchHelper.this;
                            viewHolder = itemTouchHelper.mSelected;
                            if (viewHolder != null) {
                                itemTouchHelper.moveIfNecessary(viewHolder);
                            }
                            itemTouchHelper = ItemTouchHelper.this;
                            itemTouchHelper.mRecyclerView.removeCallbacks(itemTouchHelper.mScrollRunnable);
                            ViewCompat.postOnAnimation(ItemTouchHelper.this.mRecyclerView, r0);
                        }
                    }
                }
                paddingLeft = 0;
                if (layoutManager.canScrollVertically()) {
                    i2 = (int) (itemTouchHelper.mSelectedStartY + itemTouchHelper.mDy);
                    i = (i2 - itemTouchHelper.mTmpRect.top) - itemTouchHelper.mRecyclerView.getPaddingTop();
                    f = itemTouchHelper.mDy;
                    if (f >= 0.0f) {
                    }
                    if (f > 0.0f) {
                        i2 = ((i2 + itemTouchHelper.mSelected.itemView.getHeight()) + itemTouchHelper.mTmpRect.bottom) - (itemTouchHelper.mRecyclerView.getHeight() - itemTouchHelper.mRecyclerView.getPaddingBottom());
                        if (i2 <= 0) {
                            i3 = i2;
                            if (paddingLeft != 0) {
                                i4 = paddingLeft;
                            } else {
                                callback = itemTouchHelper.mCallback;
                                recyclerView = itemTouchHelper.mRecyclerView;
                                width = itemTouchHelper.mSelected.itemView.getWidth();
                                itemTouchHelper.mRecyclerView.getWidth();
                                i4 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, paddingLeft, j);
                            }
                            if (i3 == 0) {
                                callback = itemTouchHelper.mCallback;
                                recyclerView = itemTouchHelper.mRecyclerView;
                                width = itemTouchHelper.mSelected.itemView.getHeight();
                                itemTouchHelper.mRecyclerView.getHeight();
                                i3 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, i3, j);
                            }
                            if (i4 == 0) {
                                i5 = i4;
                            } else if (i3 != 0) {
                                itemTouchHelper.mDragScrollStartTimeInMs = Long.MIN_VALUE;
                                return;
                            }
                            if (itemTouchHelper.mDragScrollStartTimeInMs == Long.MIN_VALUE) {
                                itemTouchHelper.mDragScrollStartTimeInMs = currentTimeMillis;
                            }
                            itemTouchHelper.mRecyclerView.scrollBy(i5, i3);
                            itemTouchHelper = ItemTouchHelper.this;
                            viewHolder = itemTouchHelper.mSelected;
                            if (viewHolder != null) {
                                itemTouchHelper.moveIfNecessary(viewHolder);
                            }
                            itemTouchHelper = ItemTouchHelper.this;
                            itemTouchHelper.mRecyclerView.removeCallbacks(itemTouchHelper.mScrollRunnable);
                            ViewCompat.postOnAnimation(ItemTouchHelper.this.mRecyclerView, r0);
                        }
                    }
                }
                i3 = 0;
                if (paddingLeft != 0) {
                    callback = itemTouchHelper.mCallback;
                    recyclerView = itemTouchHelper.mRecyclerView;
                    width = itemTouchHelper.mSelected.itemView.getWidth();
                    itemTouchHelper.mRecyclerView.getWidth();
                    i4 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, paddingLeft, j);
                } else {
                    i4 = paddingLeft;
                }
                if (i3 == 0) {
                    callback = itemTouchHelper.mCallback;
                    recyclerView = itemTouchHelper.mRecyclerView;
                    width = itemTouchHelper.mSelected.itemView.getHeight();
                    itemTouchHelper.mRecyclerView.getHeight();
                    i3 = callback.interpolateOutOfBoundsScroll$ar$ds(recyclerView, width, i3, j);
                }
                if (i4 == 0) {
                    i5 = i4;
                } else if (i3 != 0) {
                    itemTouchHelper.mDragScrollStartTimeInMs = Long.MIN_VALUE;
                    return;
                }
                if (itemTouchHelper.mDragScrollStartTimeInMs == Long.MIN_VALUE) {
                    itemTouchHelper.mDragScrollStartTimeInMs = currentTimeMillis;
                }
                itemTouchHelper.mRecyclerView.scrollBy(i5, i3);
                itemTouchHelper = ItemTouchHelper.this;
                viewHolder = itemTouchHelper.mSelected;
                if (viewHolder != null) {
                    itemTouchHelper.moveIfNecessary(viewHolder);
                }
                itemTouchHelper = ItemTouchHelper.this;
                itemTouchHelper.mRecyclerView.removeCallbacks(itemTouchHelper.mScrollRunnable);
                ViewCompat.postOnAnimation(ItemTouchHelper.this.mRecyclerView, r0);
            }
        }
    }

    /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$2 */
    final class C01152 implements OnItemTouchListener {
        public final boolean onInterceptTouchEvent$ar$ds(MotionEvent motionEvent) {
            android.support.p002v7.widget.helper.ItemTouchHelper.this.mGestureDetector.onTouchEvent$ar$ds(motionEvent);
            int actionMasked = motionEvent.getActionMasked();
            RecoverAnimation recoverAnimation = null;
            android.support.p002v7.widget.helper.ItemTouchHelper itemTouchHelper;
            if (actionMasked == 0) {
                android.support.p002v7.widget.helper.ItemTouchHelper.this.mActivePointerId = motionEvent.getPointerId(0);
                android.support.p002v7.widget.helper.ItemTouchHelper.this.mInitialTouchX = motionEvent.getX();
                android.support.p002v7.widget.helper.ItemTouchHelper.this.mInitialTouchY = motionEvent.getY();
                itemTouchHelper = android.support.p002v7.widget.helper.ItemTouchHelper.this;
                VelocityTracker velocityTracker = itemTouchHelper.mVelocityTracker;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                }
                itemTouchHelper.mVelocityTracker = VelocityTracker.obtain();
                itemTouchHelper = android.support.p002v7.widget.helper.ItemTouchHelper.this;
                if (itemTouchHelper.mSelected == null) {
                    if (!itemTouchHelper.mRecoverAnimations.isEmpty()) {
                        View findChildView = itemTouchHelper.findChildView(motionEvent);
                        for (int size = itemTouchHelper.mRecoverAnimations.size() - 1; size >= 0; size--) {
                            RecoverAnimation recoverAnimation2 = (RecoverAnimation) itemTouchHelper.mRecoverAnimations.get(size);
                            if (recoverAnimation2.mViewHolder.itemView == findChildView) {
                                recoverAnimation = recoverAnimation2;
                                break;
                            }
                        }
                    }
                    if (recoverAnimation != null) {
                        itemTouchHelper = android.support.p002v7.widget.helper.ItemTouchHelper.this;
                        itemTouchHelper.mInitialTouchX -= recoverAnimation.f7mX;
                        itemTouchHelper.mInitialTouchY -= recoverAnimation.f8mY;
                        itemTouchHelper.endRecoverAnimation(recoverAnimation.mViewHolder, true);
                        if (android.support.p002v7.widget.helper.ItemTouchHelper.this.mPendingCleanup.remove(recoverAnimation.mViewHolder.itemView)) {
                            android.support.p002v7.widget.helper.ItemTouchHelper.this.mCallback.clearView$ar$ds(recoverAnimation.mViewHolder);
                        }
                        android.support.p002v7.widget.helper.ItemTouchHelper.this.select(recoverAnimation.mViewHolder, recoverAnimation.mActionState);
                        itemTouchHelper = android.support.p002v7.widget.helper.ItemTouchHelper.this;
                        itemTouchHelper.updateDxDy(motionEvent, itemTouchHelper.mSelectedFlags, 0);
                    }
                }
            } else {
                if (actionMasked != 3) {
                    if (actionMasked != 1) {
                        int i = android.support.p002v7.widget.helper.ItemTouchHelper.this.mActivePointerId;
                        if (i != -1) {
                            i = motionEvent.findPointerIndex(i);
                            if (i >= 0) {
                                android.support.p002v7.widget.helper.ItemTouchHelper.this.checkSelectForSwipe(actionMasked, motionEvent, i);
                            }
                        }
                    }
                }
                itemTouchHelper = android.support.p002v7.widget.helper.ItemTouchHelper.this;
                itemTouchHelper.mActivePointerId = -1;
                itemTouchHelper.select(null, 0);
            }
            VelocityTracker velocityTracker2 = android.support.p002v7.widget.helper.ItemTouchHelper.this.mVelocityTracker;
            if (velocityTracker2 != null) {
                velocityTracker2.addMovement(motionEvent);
            }
            return android.support.p002v7.widget.helper.ItemTouchHelper.this.mSelected != null;
        }

        public final void onRequestDisallowInterceptTouchEvent(boolean z) {
            if (z) {
                android.support.p002v7.widget.helper.ItemTouchHelper.this.select(null, 0);
            }
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void onTouchEvent$ar$ds$fcc9275a_0(android.view.MotionEvent r7) {
            /*
            r6 = this;
            r0 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r0 = r0.mGestureDetector;
            r0.onTouchEvent$ar$ds(r7);
            r0 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r0 = r0.mVelocityTracker;
            if (r0 == 0) goto L_0x0010;
        L_0x000d:
            r0.addMovement(r7);
        L_0x0010:
            r0 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r0 = r0.mActivePointerId;
            r1 = -1;
            if (r0 != r1) goto L_0x0018;
        L_0x0017:
            return;
        L_0x0018:
            r0 = r7.getActionMasked();
            r2 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r2 = r2.mActivePointerId;
            r2 = r7.findPointerIndex(r2);
            if (r2 < 0) goto L_0x002b;
        L_0x0026:
            r3 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r3.checkSelectForSwipe(r0, r7, r2);
        L_0x002b:
            r3 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r4 = r3.mSelected;
            if (r4 != 0) goto L_0x0032;
        L_0x0031:
            return;
        L_0x0032:
            r5 = 0;
            switch(r0) {
                case 1: goto L_0x0084;
                case 2: goto L_0x0060;
                case 3: goto L_0x0058;
                case 4: goto L_0x0036;
                case 5: goto L_0x0036;
                case 6: goto L_0x0037;
                default: goto L_0x0036;
            };
        L_0x0036:
            goto L_0x008f;
        L_0x0037:
            r0 = r7.getActionIndex();
            r1 = r7.getPointerId(r0);
            r2 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r3 = r2.mActivePointerId;
            if (r1 != r3) goto L_0x008f;
        L_0x0045:
            if (r0 != 0) goto L_0x0049;
        L_0x0047:
            r5 = 1;
            goto L_0x004a;
        L_0x004a:
            r1 = r7.getPointerId(r5);
            r2.mActivePointerId = r1;
            r1 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r2 = r1.mSelectedFlags;
            r1.updateDxDy(r7, r2, r0);
            return;
        L_0x0058:
            r7 = r3.mVelocityTracker;
            if (r7 == 0) goto L_0x0084;
        L_0x005c:
            r7.clear();
            goto L_0x0084;
        L_0x0060:
            if (r2 < 0) goto L_0x008f;
        L_0x0062:
            r0 = r3.mSelectedFlags;
            r3.updateDxDy(r7, r0, r2);
            r7 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r7.moveIfNecessary(r4);
            r7 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r0 = r7.mRecyclerView;
            r7 = r7.mScrollRunnable;
            r0.removeCallbacks(r7);
            r7 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r7 = r7.mScrollRunnable;
            r7.run();
            r7 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r7 = r7.mRecyclerView;
            r7.invalidate();
            return;
        L_0x0084:
            r7 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r0 = 0;
            r7.select(r0, r5);
            r7 = android.support.p002v7.widget.helper.ItemTouchHelper.this;
            r7.mActivePointerId = r1;
            return;
        L_0x008f:
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.helper.ItemTouchHelper.2.onTouchEvent$ar$ds$fcc9275a_0(android.view.MotionEvent):void");
        }
    }

    /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$4 */
    final class C01174 implements Runnable {
        final /* synthetic */ RecoverAnimation val$anim;

        public C01174(RecoverAnimation recoverAnimation) {
            this.val$anim = recoverAnimation;
        }

        public final void run() {
            RecyclerView recyclerView = android.support.p002v7.widget.helper.ItemTouchHelper.this.mRecyclerView;
            if (recyclerView != null && recyclerView.mIsAttached) {
                RecoverAnimation recoverAnimation = this.val$anim;
                if (!(recoverAnimation.mOverridden || recoverAnimation.mViewHolder.getAbsoluteAdapterPosition() == -1)) {
                    ItemAnimator itemAnimator = android.support.p002v7.widget.helper.ItemTouchHelper.this.mRecyclerView.mItemAnimator;
                    if (itemAnimator == null || !itemAnimator.isRunning$ar$class_merging(null)) {
                        android.support.p002v7.widget.helper.ItemTouchHelper itemTouchHelper = android.support.p002v7.widget.helper.ItemTouchHelper.this;
                        int size = itemTouchHelper.mRecoverAnimations.size();
                        int i = 0;
                        while (i < size) {
                            if (((RecoverAnimation) itemTouchHelper.mRecoverAnimations.get(i)).mEnded) {
                                i++;
                            }
                        }
                        android.support.p002v7.widget.helper.ItemTouchHelper.this.mCallback.onSwiped$ar$ds(this.val$anim.mViewHolder);
                    }
                    android.support.p002v7.widget.helper.ItemTouchHelper.this.mRecyclerView.post(this);
                }
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$Callback */
    public abstract class Callback {
        private static final Interpolator sDragScrollInterpolator = new PG();
        private static final Interpolator sDragViewScrollCapInterpolator = new C01182();
        private int mCachedMaxScrollSpeed = -1;

        /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$Callback$1 */
        final class PG implements Interpolator {
            public final float getInterpolation(float f) {
                return (((f * f) * f) * f) * f;
            }
        }

        /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$Callback$2 */
        final class C01182 implements Interpolator {
            public final float getInterpolation(float f) {
                f -= 4.0f;
                return ((((f * f) * f) * f) * f) + 1.0f;
            }
        }

        public static int convertToRelativeDirection(int i, int i2) {
            int i3 = i & 789516;
            if (i3 == 0) {
                return i;
            }
            i &= i3 ^ -1;
            if (i2 == 0) {
                i2 = i3 << 2;
            } else {
                i3 += i3;
                i |= -789517 & i3;
                i2 = (i3 & 789516) << 2;
            }
            return i | i2;
        }

        public static int makeFlag(int i, int i2) {
            return i2 << (i * 8);
        }

        public final int convertToAbsoluteDirection(int i, int i2) {
            int i3 = i & 3158064;
            if (i3 == 0) {
                return i;
            }
            i &= i3 ^ -1;
            if (i2 == 0) {
                i2 = i3 >> 2;
            } else {
                i2 = i3 >> 1;
                i |= -3158065 & i2;
                i2 = (i2 & 3158064) >> 2;
            }
            return i | i2;
        }

        final int getAbsoluteMovementFlags(RecyclerView recyclerView, ViewHolder viewHolder) {
            return convertToAbsoluteDirection(getMovementFlags(recyclerView, viewHolder), ViewCompat.getLayoutDirection(recyclerView));
        }

        public abstract int getMovementFlags(RecyclerView recyclerView, ViewHolder viewHolder);

        public float getSwipeEscapeVelocity(float f) {
            throw null;
        }

        public void getSwipeThreshold$ar$ds() {
            throw null;
        }

        public abstract void onMove$ar$ds();

        public abstract void onSwiped$ar$ds(ViewHolder viewHolder);

        public final void clearView$ar$ds(ViewHolder viewHolder) {
            View view = viewHolder.itemView;
            Object tag = view.getTag(R.id.item_touch_helper_previous_elevation);
            if (tag instanceof Float) {
                ViewCompat.setElevation(view, ((Float) tag).floatValue());
            }
            view.setTag(R.id.item_touch_helper_previous_elevation, null);
            view.setTranslationX(0.0f);
            view.setTranslationY(0.0f);
        }

        public final int interpolateOutOfBoundsScroll$ar$ds(RecyclerView recyclerView, int i, int i2, long j) {
            int i3 = this.mCachedMaxScrollSpeed;
            if (i3 == -1) {
                i3 = recyclerView.getResources().getDimensionPixelSize(R.dimen.item_touch_helper_max_drag_scroll_per_frame);
                this.mCachedMaxScrollSpeed = i3;
            }
            int abs = Math.abs(i2);
            float f = ((float) abs) / ((float) i);
            float f2 = 1.0f;
            abs = (int) (((float) (((int) Math.signum((float) i2)) * i3)) * sDragViewScrollCapInterpolator.getInterpolation(Math.min(1.0f, f)));
            if (j <= 2000) {
                f2 = ((float) j) / 2000.0f;
            }
            abs = (int) (((float) abs) * sDragScrollInterpolator.getInterpolation(f2));
            if (abs != 0) {
                return abs;
            }
            if (i2 > 0) {
                return 1;
            }
            return -1;
        }

        public final void onChildDraw$ar$ds(RecyclerView recyclerView, ViewHolder viewHolder, float f, float f2, boolean z) {
            View view = viewHolder.itemView;
            if (z && view.getTag(R.id.item_touch_helper_previous_elevation) == null) {
                Float valueOf = Float.valueOf(ViewCompat.getElevation(view));
                int childCount = recyclerView.getChildCount();
                float f3 = 0.0f;
                for (int i = 0; i < childCount; i++) {
                    View childAt = recyclerView.getChildAt(i);
                    if (childAt != view) {
                        float elevation = ViewCompat.getElevation(childAt);
                        if (elevation > f3) {
                            f3 = elevation;
                        }
                    }
                }
                ViewCompat.setElevation(view, f3 + 1.0f);
                view.setTag(R.id.item_touch_helper_previous_elevation, valueOf);
            }
            view.setTranslationX(f);
            view.setTranslationY(f2);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$ItemTouchHelperGestureListener */
    final class ItemTouchHelperGestureListener extends SimpleOnGestureListener {
        public boolean mShouldReactToLongPress = true;

        public final boolean onDown(MotionEvent motionEvent) {
            return true;
        }

        public final void onLongPress(MotionEvent motionEvent) {
            if (this.mShouldReactToLongPress) {
                View findChildView = ItemTouchHelper.this.findChildView(motionEvent);
                if (findChildView != null) {
                    ViewHolder childViewHolder = ItemTouchHelper.this.mRecyclerView.getChildViewHolder(findChildView);
                    if (childViewHolder != null) {
                        ItemTouchHelper itemTouchHelper = ItemTouchHelper.this;
                        if ((itemTouchHelper.mCallback.getAbsoluteMovementFlags(itemTouchHelper.mRecyclerView, childViewHolder) & 16711680) != 0) {
                            int pointerId = motionEvent.getPointerId(0);
                            int i = ItemTouchHelper.this.mActivePointerId;
                            if (pointerId == i) {
                                pointerId = motionEvent.findPointerIndex(i);
                                float x = motionEvent.getX(pointerId);
                                float y = motionEvent.getY(pointerId);
                                itemTouchHelper = ItemTouchHelper.this;
                                itemTouchHelper.mInitialTouchX = x;
                                itemTouchHelper.mInitialTouchY = y;
                                itemTouchHelper.mDy = 0.0f;
                                itemTouchHelper.mDx = 0.0f;
                                itemTouchHelper.select(childViewHolder, 2);
                            }
                        }
                    }
                }
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$RecoverAnimation */
    class RecoverAnimation implements AnimatorListener {
        final int mActionState;
        boolean mEnded = false;
        public float mFraction;
        boolean mIsPendingCleanup;
        boolean mOverridden = false;
        final float mStartDx;
        final float mStartDy;
        final float mTargetX;
        final float mTargetY;
        final ValueAnimator mValueAnimator;
        final ViewHolder mViewHolder;
        /* renamed from: mX */
        float f7mX;
        /* renamed from: mY */
        float f8mY;

        /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$RecoverAnimation$1 */
        final class PG implements AnimatorUpdateListener {
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                RecoverAnimation.this.mFraction = valueAnimator.getAnimatedFraction();
            }
        }

        public RecoverAnimation(ViewHolder viewHolder, int i, float f, float f2, float f3, float f4) {
            this.mActionState = i;
            this.mViewHolder = viewHolder;
            this.mStartDx = f;
            this.mStartDy = f2;
            this.mTargetX = f3;
            this.mTargetY = f4;
            ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
            this.mValueAnimator = ofFloat;
            ofFloat.addUpdateListener(new PG());
            ofFloat.setTarget(viewHolder.itemView);
            ofFloat.addListener(this);
            this.mFraction = 0.0f;
        }

        public final void cancel() {
            this.mValueAnimator.cancel();
        }

        public final void onAnimationCancel(Animator animator) {
            this.mFraction = 1.0f;
        }

        public void onAnimationEnd(Animator animator) {
            if (!this.mEnded) {
                this.mViewHolder.setIsRecyclable(true);
            }
            this.mEnded = true;
        }

        public final void onAnimationRepeat(Animator animator) {
        }

        public final void onAnimationStart(Animator animator) {
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.helper.ItemTouchHelper$SimpleCallback */
    public abstract class SimpleCallback extends Callback {
        public final int getMovementFlags(RecyclerView recyclerView, ViewHolder viewHolder) {
            int swipeDirs = getSwipeDirs(recyclerView, viewHolder);
            return (Callback.makeFlag(1, swipeDirs) | Callback.makeFlag(0, swipeDirs)) | Callback.makeFlag(2, 0);
        }

        public int getSwipeDirs(RecyclerView recyclerView, ViewHolder viewHolder) {
            throw null;
        }
    }

    public ItemTouchHelper(Callback callback) {
        this.mCallback = callback;
    }

    private final int checkHorizontalSwipe$ar$ds(int i) {
        if ((i & 12) != 0) {
            int i2;
            int i3 = 8;
            if (this.mDx > 0.0f) {
                i2 = 8;
            } else {
                i2 = 4;
            }
            VelocityTracker velocityTracker = this.mVelocityTracker;
            if (velocityTracker != null && this.mActivePointerId >= 0) {
                velocityTracker.computeCurrentVelocity(1000, this.mMaxSwipeVelocity);
                float xVelocity = this.mVelocityTracker.getXVelocity(this.mActivePointerId);
                float yVelocity = this.mVelocityTracker.getYVelocity(this.mActivePointerId);
                if (xVelocity <= 0.0f) {
                    i3 = 4;
                }
                float abs = Math.abs(xVelocity);
                if ((i3 & i) != 0 && i2 == i3 && abs >= this.mCallback.getSwipeEscapeVelocity(this.mSwipeEscapeVelocity)) {
                    if (abs > Math.abs(yVelocity)) {
                        return i3;
                    }
                }
            }
            i3 = this.mRecyclerView.getWidth();
            this.mCallback.getSwipeThreshold$ar$ds();
            float f = ((float) i3) * 0.6f;
            if ((i & i2) != 0 && Math.abs(this.mDx) > f) {
                return i2;
            }
        }
        return 0;
    }

    private final int checkVerticalSwipe$ar$ds(int i) {
        if ((i & 3) != 0) {
            int i2;
            int i3 = 2;
            if (this.mDy > 0.0f) {
                i2 = 2;
            } else {
                i2 = 1;
            }
            VelocityTracker velocityTracker = this.mVelocityTracker;
            if (velocityTracker != null && this.mActivePointerId >= 0) {
                velocityTracker.computeCurrentVelocity(1000, this.mMaxSwipeVelocity);
                float xVelocity = this.mVelocityTracker.getXVelocity(this.mActivePointerId);
                float yVelocity = this.mVelocityTracker.getYVelocity(this.mActivePointerId);
                if (yVelocity <= 0.0f) {
                    i3 = 1;
                }
                float abs = Math.abs(yVelocity);
                if ((i3 & i) != 0 && i3 == i2 && abs >= this.mCallback.getSwipeEscapeVelocity(this.mSwipeEscapeVelocity)) {
                    if (abs > Math.abs(xVelocity)) {
                        return i3;
                    }
                }
            }
            i3 = this.mRecyclerView.getHeight();
            this.mCallback.getSwipeThreshold$ar$ds();
            float f = ((float) i3) * 0.6f;
            if ((i & i2) != 0 && Math.abs(this.mDy) > f) {
                return i2;
            }
        }
        return 0;
    }

    private final void getSelectedDxDy(float[] fArr) {
        if ((this.mSelectedFlags & 12) != 0) {
            fArr[0] = (this.mSelectedStartX + this.mDx) - ((float) this.mSelected.itemView.getLeft());
        } else {
            fArr[0] = this.mSelected.itemView.getTranslationX();
        }
        if ((this.mSelectedFlags & 3) != 0) {
            fArr[1] = (this.mSelectedStartY + this.mDy) - ((float) this.mSelected.itemView.getTop());
        } else {
            fArr[1] = this.mSelected.itemView.getTranslationY();
        }
    }

    private static boolean hitTest(View view, float f, float f2, float f3, float f4) {
        return f >= f3 && f <= f3 + ((float) view.getWidth()) && f2 >= f4 && f2 <= f4 + ((float) view.getHeight());
    }

    private final void releaseVelocityTracker() {
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.mVelocityTracker = null;
        }
    }

    final void endRecoverAnimation(ViewHolder viewHolder, boolean z) {
        for (int size = this.mRecoverAnimations.size() - 1; size >= 0; size--) {
            RecoverAnimation recoverAnimation = (RecoverAnimation) this.mRecoverAnimations.get(size);
            if (recoverAnimation.mViewHolder == viewHolder) {
                recoverAnimation.mOverridden |= z;
                if (!recoverAnimation.mEnded) {
                    recoverAnimation.cancel();
                }
                this.mRecoverAnimations.remove(size);
                return;
            }
        }
    }

    final View findChildView(MotionEvent motionEvent) {
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        ViewHolder viewHolder = this.mSelected;
        if (viewHolder != null) {
            View view = viewHolder.itemView;
            if (ItemTouchHelper.hitTest(view, x, y, this.mSelectedStartX + this.mDx, this.mSelectedStartY + this.mDy)) {
                return view;
            }
        }
        for (int size = this.mRecoverAnimations.size() - 1; size >= 0; size--) {
            RecoverAnimation recoverAnimation = (RecoverAnimation) this.mRecoverAnimations.get(size);
            View view2 = recoverAnimation.mViewHolder.itemView;
            if (ItemTouchHelper.hitTest(view2, x, y, recoverAnimation.f7mX, recoverAnimation.f8mY)) {
                return view2;
            }
        }
        return this.mRecyclerView.findChildViewUnder(x, y);
    }

    public final void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, State state) {
        rect.setEmpty();
    }

    final void moveIfNecessary(ViewHolder viewHolder) {
        ViewHolder viewHolder2 = viewHolder;
        if (!this.mRecyclerView.isLayoutRequested() && r0.mActionState == 2) {
            int size;
            int i = (int) (r0.mSelectedStartX + r0.mDx);
            int i2 = (int) (r0.mSelectedStartY + r0.mDy);
            if (((float) Math.abs(i2 - viewHolder2.itemView.getTop())) < ((float) viewHolder2.itemView.getHeight()) * 0.5f) {
                if (((float) Math.abs(i - viewHolder2.itemView.getLeft())) < ((float) viewHolder2.itemView.getWidth()) * 0.5f) {
                    return;
                }
            }
            List list = r0.mSwapTargets;
            if (list == null) {
                r0.mSwapTargets = new ArrayList();
                r0.mDistances = new ArrayList();
            } else {
                list.clear();
                r0.mDistances.clear();
            }
            int round = Math.round(r0.mSelectedStartX + r0.mDx);
            int round2 = Math.round(r0.mSelectedStartY + r0.mDy);
            int width = viewHolder2.itemView.getWidth() + round;
            int height = viewHolder2.itemView.getHeight() + round2;
            int i3 = (round + width) / 2;
            int i4 = (round2 + height) / 2;
            LayoutManager layoutManager = r0.mRecyclerView.mLayout;
            int childCount = layoutManager.getChildCount();
            int i5 = 0;
            while (i5 < childCount) {
                int i6;
                int i7;
                View childAt = layoutManager.getChildAt(i5);
                if (childAt == viewHolder2.itemView) {
                    i6 = round;
                    i7 = round2;
                } else if (childAt.getBottom() < round2 || childAt.getTop() > height) {
                    i6 = round;
                    i7 = round2;
                } else if (childAt.getRight() < round || childAt.getLeft() > width) {
                    i6 = round;
                    i7 = round2;
                } else {
                    ViewHolder childViewHolder = r0.mRecyclerView.getChildViewHolder(childAt);
                    int abs = Math.abs(i3 - ((childAt.getLeft() + childAt.getRight()) / 2));
                    int abs2 = Math.abs(i4 - ((childAt.getTop() + childAt.getBottom()) / 2));
                    abs2 = (abs * abs) + (abs2 * abs2);
                    size = r0.mSwapTargets.size();
                    i6 = round;
                    i7 = round2;
                    round = 0;
                    round2 = 0;
                    while (round < size) {
                        int i8 = size;
                        if (abs2 <= ((Integer) r0.mDistances.get(round)).intValue()) {
                            break;
                        }
                        round2++;
                        round++;
                        size = i8;
                    }
                    r0.mSwapTargets.add(round2, childViewHolder);
                    r0.mDistances.add(round2, Integer.valueOf(abs2));
                }
                i5++;
                round = i6;
                round2 = i7;
            }
            List list2 = r0.mSwapTargets;
            if (list2.size() != 0) {
                round = viewHolder2.itemView.getWidth() + i;
                round2 = viewHolder2.itemView.getHeight() + i2;
                width = i - viewHolder2.itemView.getLeft();
                height = i2 - viewHolder2.itemView.getTop();
                i3 = list2.size();
                ViewHolder viewHolder3 = null;
                int i9 = -1;
                int i10 = 0;
                while (i10 < i3) {
                    List list3;
                    ViewHolder viewHolder4 = (ViewHolder) list2.get(i10);
                    if (width > 0) {
                        i5 = viewHolder4.itemView.getRight() - round;
                        if (i5 < 0) {
                            list3 = list2;
                            if (viewHolder4.itemView.getRight() > viewHolder2.itemView.getRight()) {
                                size = Math.abs(i5);
                                if (size > i9) {
                                    i9 = size;
                                    viewHolder3 = viewHolder4;
                                    if (width < 0) {
                                        size = viewHolder4.itemView.getLeft() - i;
                                        if (size > 0 && viewHolder4.itemView.getLeft() < viewHolder2.itemView.getLeft()) {
                                            size = Math.abs(size);
                                            if (size > i9) {
                                                i9 = size;
                                                viewHolder3 = viewHolder4;
                                                if (height < 0) {
                                                    size = viewHolder4.itemView.getTop() - i2;
                                                    if (size > 0 && viewHolder4.itemView.getTop() < viewHolder2.itemView.getTop()) {
                                                        size = Math.abs(size);
                                                        if (size > i9) {
                                                            i9 = size;
                                                            viewHolder3 = viewHolder4;
                                                            if (height > 0) {
                                                                size = viewHolder4.itemView.getBottom() - round2;
                                                                if (size < 0 && viewHolder4.itemView.getBottom() > viewHolder2.itemView.getBottom()) {
                                                                    size = Math.abs(size);
                                                                    if (size > i9) {
                                                                        i9 = size;
                                                                        viewHolder3 = viewHolder4;
                                                                        i10++;
                                                                        list2 = list3;
                                                                    }
                                                                }
                                                            }
                                                            i10++;
                                                            list2 = list3;
                                                        }
                                                    }
                                                }
                                                if (height > 0) {
                                                    size = viewHolder4.itemView.getBottom() - round2;
                                                    size = Math.abs(size);
                                                    if (size > i9) {
                                                        i9 = size;
                                                        viewHolder3 = viewHolder4;
                                                        i10++;
                                                        list2 = list3;
                                                    }
                                                }
                                                i10++;
                                                list2 = list3;
                                            }
                                        }
                                    }
                                    if (height < 0) {
                                        size = viewHolder4.itemView.getTop() - i2;
                                        size = Math.abs(size);
                                        if (size > i9) {
                                            i9 = size;
                                            viewHolder3 = viewHolder4;
                                            if (height > 0) {
                                                size = viewHolder4.itemView.getBottom() - round2;
                                                size = Math.abs(size);
                                                if (size > i9) {
                                                    i9 = size;
                                                    viewHolder3 = viewHolder4;
                                                    i10++;
                                                    list2 = list3;
                                                }
                                            }
                                            i10++;
                                            list2 = list3;
                                        }
                                    }
                                    if (height > 0) {
                                        size = viewHolder4.itemView.getBottom() - round2;
                                        size = Math.abs(size);
                                        if (size > i9) {
                                            i9 = size;
                                            viewHolder3 = viewHolder4;
                                            i10++;
                                            list2 = list3;
                                        }
                                    }
                                    i10++;
                                    list2 = list3;
                                }
                            }
                            if (width < 0) {
                                size = viewHolder4.itemView.getLeft() - i;
                                size = Math.abs(size);
                                if (size > i9) {
                                    i9 = size;
                                    viewHolder3 = viewHolder4;
                                    if (height < 0) {
                                        size = viewHolder4.itemView.getTop() - i2;
                                        size = Math.abs(size);
                                        if (size > i9) {
                                            i9 = size;
                                            viewHolder3 = viewHolder4;
                                            if (height > 0) {
                                                size = viewHolder4.itemView.getBottom() - round2;
                                                size = Math.abs(size);
                                                if (size > i9) {
                                                    i9 = size;
                                                    viewHolder3 = viewHolder4;
                                                    i10++;
                                                    list2 = list3;
                                                }
                                            }
                                            i10++;
                                            list2 = list3;
                                        }
                                    }
                                    if (height > 0) {
                                        size = viewHolder4.itemView.getBottom() - round2;
                                        size = Math.abs(size);
                                        if (size > i9) {
                                            i9 = size;
                                            viewHolder3 = viewHolder4;
                                            i10++;
                                            list2 = list3;
                                        }
                                    }
                                    i10++;
                                    list2 = list3;
                                }
                            }
                            if (height < 0) {
                                size = viewHolder4.itemView.getTop() - i2;
                                size = Math.abs(size);
                                if (size > i9) {
                                    i9 = size;
                                    viewHolder3 = viewHolder4;
                                    if (height > 0) {
                                        size = viewHolder4.itemView.getBottom() - round2;
                                        size = Math.abs(size);
                                        if (size > i9) {
                                            i9 = size;
                                            viewHolder3 = viewHolder4;
                                            i10++;
                                            list2 = list3;
                                        }
                                    }
                                    i10++;
                                    list2 = list3;
                                }
                            }
                            if (height > 0) {
                                size = viewHolder4.itemView.getBottom() - round2;
                                size = Math.abs(size);
                                if (size > i9) {
                                    i9 = size;
                                    viewHolder3 = viewHolder4;
                                    i10++;
                                    list2 = list3;
                                }
                            }
                            i10++;
                            list2 = list3;
                        }
                    }
                    list3 = list2;
                    if (width < 0) {
                        size = viewHolder4.itemView.getLeft() - i;
                        size = Math.abs(size);
                        if (size > i9) {
                            i9 = size;
                            viewHolder3 = viewHolder4;
                            if (height < 0) {
                                size = viewHolder4.itemView.getTop() - i2;
                                size = Math.abs(size);
                                if (size > i9) {
                                    i9 = size;
                                    viewHolder3 = viewHolder4;
                                    if (height > 0) {
                                        size = viewHolder4.itemView.getBottom() - round2;
                                        size = Math.abs(size);
                                        if (size > i9) {
                                            i9 = size;
                                            viewHolder3 = viewHolder4;
                                            i10++;
                                            list2 = list3;
                                        }
                                    }
                                    i10++;
                                    list2 = list3;
                                }
                            }
                            if (height > 0) {
                                size = viewHolder4.itemView.getBottom() - round2;
                                size = Math.abs(size);
                                if (size > i9) {
                                    i9 = size;
                                    viewHolder3 = viewHolder4;
                                    i10++;
                                    list2 = list3;
                                }
                            }
                            i10++;
                            list2 = list3;
                        }
                    }
                    if (height < 0) {
                        size = viewHolder4.itemView.getTop() - i2;
                        size = Math.abs(size);
                        if (size > i9) {
                            i9 = size;
                            viewHolder3 = viewHolder4;
                            if (height > 0) {
                                size = viewHolder4.itemView.getBottom() - round2;
                                size = Math.abs(size);
                                if (size > i9) {
                                    i9 = size;
                                    viewHolder3 = viewHolder4;
                                    i10++;
                                    list2 = list3;
                                }
                            }
                            i10++;
                            list2 = list3;
                        }
                    }
                    if (height > 0) {
                        size = viewHolder4.itemView.getBottom() - round2;
                        size = Math.abs(size);
                        if (size > i9) {
                            i9 = size;
                            viewHolder3 = viewHolder4;
                            i10++;
                            list2 = list3;
                        }
                    }
                    i10++;
                    list2 = list3;
                }
                if (viewHolder3 == null) {
                    r0.mSwapTargets.clear();
                    r0.mDistances.clear();
                    return;
                }
                viewHolder3.getAbsoluteAdapterPosition();
                viewHolder.getAbsoluteAdapterPosition();
                r0.mCallback.onMove$ar$ds();
            }
        }
    }

    public final void onChildViewAttachedToWindow(View view) {
    }

    public final void onChildViewDetachedFromWindow(View view) {
        removeChildDrawingOrderCallbackIfNecessary(view);
        ViewHolder childViewHolder = this.mRecyclerView.getChildViewHolder(view);
        if (childViewHolder != null) {
            ViewHolder viewHolder = this.mSelected;
            if (viewHolder != null) {
                if (childViewHolder == viewHolder) {
                    select(null, 0);
                    return;
                }
            }
            endRecoverAnimation(childViewHolder, false);
            if (this.mPendingCleanup.remove(childViewHolder.itemView)) {
                this.mCallback.clearView$ar$ds(childViewHolder);
            }
        }
    }

    public final void onDraw$ar$ds(Canvas canvas, RecyclerView recyclerView) {
        ItemTouchHelper itemTouchHelper;
        float f;
        float f2;
        Canvas canvas2 = canvas;
        int i = 0;
        if (this.mSelected != null) {
            getSelectedDxDy(itemTouchHelper.mTmpPosition);
            float[] fArr = itemTouchHelper.mTmpPosition;
            float f3 = fArr[0];
            f = fArr[1];
            f2 = f3;
        } else {
            f2 = 0.0f;
            f = 0.0f;
        }
        Callback callback = itemTouchHelper.mCallback;
        ViewHolder viewHolder = itemTouchHelper.mSelected;
        List list = itemTouchHelper.mRecoverAnimations;
        int size = list.size();
        while (i < size) {
            RecoverAnimation recoverAnimation = (RecoverAnimation) list.get(i);
            float f4 = recoverAnimation.mStartDx;
            float f5 = recoverAnimation.mTargetX;
            if (f4 == f5) {
                recoverAnimation.f7mX = recoverAnimation.mViewHolder.itemView.getTranslationX();
            } else {
                recoverAnimation.f7mX = f4 + (recoverAnimation.mFraction * (f5 - f4));
            }
            f4 = recoverAnimation.mStartDy;
            f5 = recoverAnimation.mTargetY;
            if (f4 == f5) {
                recoverAnimation.f8mY = recoverAnimation.mViewHolder.itemView.getTranslationY();
            } else {
                recoverAnimation.f8mY = f4 + (recoverAnimation.mFraction * (f5 - f4));
            }
            int save = canvas.save();
            ViewHolder viewHolder2 = recoverAnimation.mViewHolder;
            float f6 = recoverAnimation.f7mX;
            float f7 = recoverAnimation.f8mY;
            int i2 = recoverAnimation.mActionState;
            int i3 = save;
            callback.onChildDraw$ar$ds(recyclerView, viewHolder2, f6, f7, false);
            canvas2.restoreToCount(i3);
            i++;
            itemTouchHelper = this;
        }
        if (viewHolder != null) {
            i3 = canvas.save();
            callback.onChildDraw$ar$ds(recyclerView, viewHolder, f2, f, true);
            canvas2.restoreToCount(i3);
        }
    }

    public final void onDrawOver$ar$ds(Canvas canvas, RecyclerView recyclerView) {
        if (this.mSelected != null) {
            getSelectedDxDy(this.mTmpPosition);
        }
        ViewHolder viewHolder = this.mSelected;
        List list = this.mRecoverAnimations;
        int size = list.size();
        Object obj = null;
        for (int i = 0; i < size; i++) {
            RecoverAnimation recoverAnimation = (RecoverAnimation) list.get(i);
            int save = canvas.save();
            ViewHolder viewHolder2 = recoverAnimation.mViewHolder;
            float f = recoverAnimation.f7mX;
            f = recoverAnimation.f8mY;
            int i2 = recoverAnimation.mActionState;
            canvas.restoreToCount(save);
        }
        if (viewHolder != null) {
            canvas.restoreToCount(canvas.save());
        }
        for (size--; size >= 0; size--) {
            RecoverAnimation recoverAnimation2 = (RecoverAnimation) list.get(size);
            if (!recoverAnimation2.mEnded) {
                obj = 1;
            } else if (!recoverAnimation2.mIsPendingCleanup) {
                list.remove(size);
            }
        }
        if (obj != null) {
            recyclerView.invalidate();
        }
    }

    final void removeChildDrawingOrderCallbackIfNecessary(View view) {
        if (view == this.mOverdrawChild) {
            this.mOverdrawChild = null;
        }
    }

    final void select(ViewHolder viewHolder, int i) {
        int convertToAbsoluteDirection;
        Object obj;
        ViewHolder viewHolder2 = viewHolder;
        int i2 = i;
        if (viewHolder2 == this.mSelected) {
            if (i2 == r10.mActionState) {
                return;
            }
        }
        r10.mDragScrollStartTimeInMs = Long.MIN_VALUE;
        int i3 = r10.mActionState;
        endRecoverAnimation(viewHolder2, true);
        r10.mActionState = i2;
        if (i2 == 2) {
            if (viewHolder2 != null) {
                r10.mOverdrawChild = viewHolder2.itemView;
            } else {
                throw new IllegalArgumentException("Must pass a ViewHolder when dragging");
            }
        }
        int i4 = (1 << ((i2 * 8) + 8)) - 1;
        final ViewHolder viewHolder3 = r10.mSelected;
        if (viewHolder3 != null) {
            if (viewHolder3.itemView.getParent() != null) {
                int i5;
                float signum;
                float f;
                if (i3 == 2) {
                    i5 = 0;
                } else if (r10.mActionState == 2) {
                    i5 = 0;
                } else {
                    int movementFlags = r10.mCallback.getMovementFlags(r10.mRecyclerView, viewHolder3);
                    convertToAbsoluteDirection = (r10.mCallback.convertToAbsoluteDirection(movementFlags, ViewCompat.getLayoutDirection(r10.mRecyclerView)) >> 8) & 255;
                    if (convertToAbsoluteDirection == 0) {
                        i5 = 0;
                    } else {
                        movementFlags = (movementFlags >> 8) & 255;
                        int checkHorizontalSwipe$ar$ds;
                        if (Math.abs(r10.mDx) > Math.abs(r10.mDy)) {
                            checkHorizontalSwipe$ar$ds = checkHorizontalSwipe$ar$ds(convertToAbsoluteDirection);
                            if (checkHorizontalSwipe$ar$ds > 0) {
                                i5 = (movementFlags & checkHorizontalSwipe$ar$ds) == 0 ? Callback.convertToRelativeDirection(checkHorizontalSwipe$ar$ds, ViewCompat.getLayoutDirection(r10.mRecyclerView)) : checkHorizontalSwipe$ar$ds;
                            } else {
                                movementFlags = checkVerticalSwipe$ar$ds(convertToAbsoluteDirection);
                                i5 = movementFlags <= 0 ? 0 : movementFlags;
                            }
                        } else {
                            checkHorizontalSwipe$ar$ds = checkVerticalSwipe$ar$ds(convertToAbsoluteDirection);
                            if (checkHorizontalSwipe$ar$ds > 0) {
                                i5 = checkHorizontalSwipe$ar$ds;
                            } else {
                                convertToAbsoluteDirection = checkHorizontalSwipe$ar$ds(convertToAbsoluteDirection);
                                i5 = convertToAbsoluteDirection > 0 ? (movementFlags & convertToAbsoluteDirection) == 0 ? Callback.convertToRelativeDirection(convertToAbsoluteDirection, ViewCompat.getLayoutDirection(r10.mRecyclerView)) : convertToAbsoluteDirection : 0;
                            }
                        }
                    }
                }
                releaseVelocityTracker();
                switch (i5) {
                    case 1:
                    case 2:
                        signum = Math.signum(r10.mDy) * ((float) r10.mRecyclerView.getHeight());
                        f = 0.0f;
                        break;
                    case 4:
                    case 8:
                    case 16:
                    case 32:
                        f = Math.signum(r10.mDx) * ((float) r10.mRecyclerView.getWidth());
                        signum = 0.0f;
                        break;
                    default:
                        f = 0.0f;
                        signum = 0.0f;
                        break;
                }
                Object obj2 = i3 == 2 ? 8 : i5 > 0 ? 2 : 4;
                getSelectedDxDy(r10.mTmpPosition);
                float[] fArr = r10.mTmpPosition;
                RecoverAnimation recoverAnimation = r0;
                Object obj3 = obj2;
                final int i6 = i5;
                RecoverAnimation c01163 = new RecoverAnimation(viewHolder3, i3, fArr[0], fArr[1], f, signum) {
                    public final void onAnimationEnd(Animator animator) {
                        super.onAnimationEnd(animator);
                        if (!this.mOverridden) {
                            android.support.p002v7.widget.helper.ItemTouchHelper itemTouchHelper;
                            if (i6 <= 0) {
                                android.support.p002v7.widget.helper.ItemTouchHelper.this.mCallback.clearView$ar$ds(viewHolder3);
                            } else {
                                android.support.p002v7.widget.helper.ItemTouchHelper.this.mPendingCleanup.add(viewHolder3.itemView);
                                this.mIsPendingCleanup = true;
                                if (i6 > 0) {
                                    itemTouchHelper = android.support.p002v7.widget.helper.ItemTouchHelper.this;
                                    itemTouchHelper.mRecyclerView.post(new C01174(this));
                                }
                            }
                            itemTouchHelper = android.support.p002v7.widget.helper.ItemTouchHelper.this;
                            View view = itemTouchHelper.mOverdrawChild;
                            View view2 = viewHolder3.itemView;
                            if (view == view2) {
                                itemTouchHelper.removeChildDrawingOrderCallbackIfNecessary(view2);
                            }
                        }
                    }
                };
                ItemAnimator itemAnimator = r10.mRecyclerView.mItemAnimator;
                long moveDuration = itemAnimator == null ? obj3 == 8 ? 200 : 250 : obj3 == 8 ? itemAnimator.getMoveDuration() : itemAnimator.getRemoveDuration();
                recoverAnimation.mValueAnimator.setDuration(moveDuration);
                r10.mRecoverAnimations.add(recoverAnimation);
                convertToAbsoluteDirection = false;
                recoverAnimation.mViewHolder.setIsRecyclable(false);
                recoverAnimation.mValueAnimator.start();
                obj = 1;
            } else {
                convertToAbsoluteDirection = false;
                removeChildDrawingOrderCallbackIfNecessary(viewHolder3.itemView);
                r10.mCallback.clearView$ar$ds(viewHolder3);
                obj = null;
            }
            r10.mSelected = null;
        } else {
            convertToAbsoluteDirection = 0;
            obj = null;
        }
        if (viewHolder2 != null) {
            r10.mSelectedFlags = (r10.mCallback.getAbsoluteMovementFlags(r10.mRecyclerView, viewHolder2) & i4) >> (r10.mActionState * 8);
            r10.mSelectedStartX = (float) viewHolder2.itemView.getLeft();
            r10.mSelectedStartY = (float) viewHolder2.itemView.getTop();
            r10.mSelected = viewHolder2;
            if (i2 == 2) {
                viewHolder2.itemView.performHapticFeedback(convertToAbsoluteDirection);
            }
        }
        ViewParent parent = r10.mRecyclerView.getParent();
        if (parent != null) {
            boolean z;
            if (r10.mSelected != null) {
                z = true;
            } else {
                z = false;
            }
            parent.requestDisallowInterceptTouchEvent(z);
        }
        if (obj == null) {
            r10.mRecyclerView.mLayout.requestSimpleAnimationsInNextLayout();
        }
        r10.mRecyclerView.invalidate();
    }

    final void updateDxDy(MotionEvent motionEvent, int i, int i2) {
        float x = motionEvent.getX(i2);
        float y = motionEvent.getY(i2);
        x -= this.mInitialTouchX;
        this.mDx = x;
        this.mDy = y - this.mInitialTouchY;
        if ((i & 4) == 0) {
            x = Math.max(0.0f, x);
            this.mDx = x;
        }
        if ((i & 8) == 0) {
            this.mDx = Math.min(0.0f, x);
        }
        if ((i & 1) == 0) {
            this.mDy = Math.max(0.0f, this.mDy);
        }
        if ((i & 2) == 0) {
            this.mDy = Math.min(0.0f, this.mDy);
        }
    }

    public final void attachToRecyclerView(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.mRecyclerView;
        if (recyclerView2 != recyclerView) {
            if (recyclerView2 != null) {
                recyclerView2.removeItemDecoration(this);
                this.mRecyclerView.removeOnItemTouchListener(this.mOnItemTouchListener);
                List list = this.mRecyclerView.mOnChildAttachStateListeners;
                if (list != null) {
                    list.remove(this);
                }
                for (int size = this.mRecoverAnimations.size() - 1; size >= 0; size--) {
                    RecoverAnimation recoverAnimation = (RecoverAnimation) this.mRecoverAnimations.get(0);
                    recoverAnimation.cancel();
                    this.mCallback.clearView$ar$ds(recoverAnimation.mViewHolder);
                }
                this.mRecoverAnimations.clear();
                this.mOverdrawChild = null;
                releaseVelocityTracker();
                ItemTouchHelperGestureListener itemTouchHelperGestureListener = this.mItemTouchHelperGestureListener;
                if (itemTouchHelperGestureListener != null) {
                    itemTouchHelperGestureListener.mShouldReactToLongPress = false;
                    this.mItemTouchHelperGestureListener = null;
                }
                if (this.mGestureDetector != null) {
                    this.mGestureDetector = null;
                }
            }
            this.mRecyclerView = recyclerView;
            if (recyclerView != null) {
                Resources resources = recyclerView.getResources();
                this.mSwipeEscapeVelocity = resources.getDimension(R.dimen.item_touch_helper_swipe_escape_velocity);
                this.mMaxSwipeVelocity = resources.getDimension(R.dimen.item_touch_helper_swipe_escape_max_velocity);
                this.mSlop = ViewConfiguration.get(this.mRecyclerView.getContext()).getScaledTouchSlop();
                this.mRecyclerView.addItemDecoration(this);
                this.mRecyclerView.addOnItemTouchListener(this.mOnItemTouchListener);
                this.mRecyclerView.addOnChildAttachStateChangeListener(this);
                this.mItemTouchHelperGestureListener = new ItemTouchHelperGestureListener();
                this.mGestureDetector = new GestureDetectorCompat(this.mRecyclerView.getContext(), this.mItemTouchHelperGestureListener);
            }
        }
    }

    final void checkSelectForSwipe(int i, MotionEvent motionEvent, int i2) {
        if (this.mSelected == null && i == 2 && this.mActionState != 2) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView.mScrollState != 1) {
                float x;
                float f;
                float y;
                float f2;
                LayoutManager layoutManager = recyclerView.mLayout;
                int i3 = this.mActivePointerId;
                ViewHolder viewHolder = null;
                if (i3 != -1) {
                    i3 = motionEvent.findPointerIndex(i3);
                    x = motionEvent.getX(i3);
                    f = this.mInitialTouchX;
                    y = motionEvent.getY(i3);
                    f2 = this.mInitialTouchY;
                    x = Math.abs(x - f);
                    y = Math.abs(y - f2);
                    f = (float) this.mSlop;
                    if (x >= f || y >= f) {
                        if (x <= y || !layoutManager.canScrollHorizontally()) {
                            if (y <= x || !layoutManager.canScrollVertically()) {
                                View findChildView = findChildView(motionEvent);
                                if (findChildView != null) {
                                    viewHolder = this.mRecyclerView.getChildViewHolder(findChildView);
                                }
                            }
                        }
                    }
                }
                if (viewHolder != null) {
                    i = (this.mCallback.getAbsoluteMovementFlags(this.mRecyclerView, viewHolder) >> 8) & 255;
                    if (i != 0) {
                        y = motionEvent.getX(i2);
                        y -= this.mInitialTouchX;
                        float y2 = motionEvent.getY(i2) - this.mInitialTouchY;
                        x = Math.abs(y);
                        f = Math.abs(y2);
                        f2 = (float) this.mSlop;
                        if (x < f2) {
                            if (f < f2) {
                                return;
                            }
                        }
                        if (x > f) {
                            if (y < 0.0f) {
                                if ((i & 4) == 0) {
                                    return;
                                }
                            }
                            if (y > 0.0f && (i & 8) == 0) {
                                return;
                            }
                        }
                        if (y2 < 0.0f) {
                            if ((i & 1) == 0) {
                                return;
                            }
                        }
                        if (y2 > 0.0f && (i & 2) == 0) {
                            return;
                        }
                        this.mDy = 0.0f;
                        this.mDx = 0.0f;
                        this.mActivePointerId = motionEvent.getPointerId(0);
                        select(viewHolder, 1);
                    }
                }
            }
        }
    }
}
