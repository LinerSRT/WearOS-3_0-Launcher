package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.p000v4.widget.AutoScrollHelper;
import android.support.p000v4.widget.ListViewAutoScrollHelper;
import android.support.p002v7.graphics.drawable.DrawableWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.google.android.wearable.sysui.R;
import java.lang.reflect.Field;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.DropDownListView */
class DropDownListView extends ListView {
    private boolean mDrawsInPressedState;
    private final boolean mHijackFocus;
    private Field mIsChildViewEnabled;
    public boolean mListSelectionHidden;
    private int mMotionPosition;
    ResolveHoverRunnable mResolveHoverRunnable;
    private ListViewAutoScrollHelper mScrollHelper;
    private int mSelectionBottomPadding = 0;
    private int mSelectionLeftPadding = 0;
    private int mSelectionRightPadding = 0;
    private int mSelectionTopPadding = 0;
    private GateKeeperDrawable mSelector;
    private final Rect mSelectorRect = new Rect();

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.DropDownListView$GateKeeperDrawable */
    final class GateKeeperDrawable extends DrawableWrapper {
        public boolean mEnabled = true;

        public GateKeeperDrawable(Drawable drawable) {
            super(drawable);
        }

        public final void draw(Canvas canvas) {
            if (this.mEnabled) {
                super.draw(canvas);
            }
        }

        public final void setHotspot(float f, float f2) {
            if (this.mEnabled) {
                super.setHotspot(f, f2);
            }
        }

        public final void setHotspotBounds(int i, int i2, int i3, int i4) {
            if (this.mEnabled) {
                super.setHotspotBounds(i, i2, i3, i4);
            }
        }

        public final boolean setState(int[] iArr) {
            return this.mEnabled ? super.setState(iArr) : false;
        }

        public final boolean setVisible(boolean z, boolean z2) {
            return this.mEnabled ? super.setVisible(z, z2) : false;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.DropDownListView$ResolveHoverRunnable */
    final class ResolveHoverRunnable implements Runnable {
        public final void run() {
            DropDownListView dropDownListView = DropDownListView.this;
            dropDownListView.mResolveHoverRunnable = null;
            dropDownListView.drawableStateChanged();
        }
    }

    public DropDownListView(Context context, boolean z) {
        super(context, null, R.attr.dropDownListViewStyle);
        this.mHijackFocus = z;
        setCacheColorHint(0);
        try {
            Field declaredField = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
            this.mIsChildViewEnabled = declaredField;
            declaredField.setAccessible(true);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

    private final void setSelectorEnabled(boolean z) {
        GateKeeperDrawable gateKeeperDrawable = this.mSelector;
        if (gateKeeperDrawable != null) {
            gateKeeperDrawable.mEnabled = z;
        }
    }

    private final void updateSelectorStateCompat() {
        Drawable selector = getSelector();
        if (selector != null && this.mDrawsInPressedState && isPressed()) {
            selector.setState(getDrawableState());
        }
    }

    protected final void drawableStateChanged() {
        if (this.mResolveHoverRunnable == null) {
            super.drawableStateChanged();
            setSelectorEnabled(true);
            updateSelectorStateCompat();
        }
    }

    public final boolean hasFocus() {
        if (!this.mHijackFocus) {
            if (!super.hasFocus()) {
                return false;
            }
        }
        return true;
    }

    public final boolean hasWindowFocus() {
        if (!this.mHijackFocus) {
            if (!super.hasWindowFocus()) {
                return false;
            }
        }
        return true;
    }

    public final boolean isFocused() {
        if (!this.mHijackFocus) {
            if (!super.isFocused()) {
                return false;
            }
        }
        return true;
    }

    public final boolean isInTouchMode() {
        return (this.mHijackFocus && this.mListSelectionHidden) || super.isInTouchMode();
    }

    public final int measureHeightOfChildrenCompat$ar$ds(int i, int i2) {
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        listPaddingTop += listPaddingBottom;
        if (adapter == null) {
            return listPaddingTop;
        }
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        View view = null;
        int i3 = 0;
        int i4 = 0;
        while (i3 < count) {
            int i5;
            int itemViewType = adapter.getItemViewType(i3);
            if (itemViewType != i4) {
                i5 = itemViewType;
            } else {
                i5 = i4;
            }
            if (itemViewType != i4) {
                view = null;
            }
            view = adapter.getView(i3, view, this);
            LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            if (layoutParams.height > 0) {
                i4 = MeasureSpec.makeMeasureSpec(layoutParams.height, 1073741824);
            } else {
                i4 = MeasureSpec.makeMeasureSpec(0, 0);
            }
            view.measure(i, i4);
            view.forceLayout();
            if (i3 > 0) {
                listPaddingTop += dividerHeight;
            }
            listPaddingTop += view.getMeasuredHeight();
            if (listPaddingTop >= i2) {
                return i2;
            }
            i3++;
            i4 = i5;
        }
        return listPaddingTop;
    }

    protected final void onDetachedFromWindow() {
        this.mResolveHoverRunnable = null;
        super.onDetachedFromWindow();
    }

    public final boolean onForwardedEvent(MotionEvent motionEvent, int i) {
        boolean z;
        View view = this;
        MotionEvent motionEvent2 = motionEvent;
        int actionMasked = motionEvent.getActionMasked();
        boolean z2 = false;
        switch (actionMasked) {
            case 1:
                z = false;
                break;
            case 2:
                z = true;
                break;
            case 3:
                z = false;
                break;
            default:
                z = true;
                z2 = false;
                break;
        }
        int findPointerIndex = motionEvent.findPointerIndex(i);
        if (findPointerIndex < 0) {
            z = false;
        } else {
            int x = (int) motionEvent2.getX(findPointerIndex);
            findPointerIndex = (int) motionEvent2.getY(findPointerIndex);
            int pointToPosition = pointToPosition(x, findPointerIndex);
            if (pointToPosition == -1) {
                z2 = true;
            } else {
                int i2;
                Object obj;
                Rect rect;
                float exactCenterX;
                float exactCenterY;
                boolean z3;
                Drawable selector;
                View childAt = getChildAt(pointToPosition - getFirstVisiblePosition());
                float f = (float) x;
                float f2 = (float) findPointerIndex;
                view.mDrawsInPressedState = true;
                drawableHotspotChanged(f, f2);
                if (!isPressed()) {
                    setPressed(true);
                }
                layoutChildren();
                int i3 = view.mMotionPosition;
                if (i3 != -1) {
                    View childAt2 = getChildAt(i3 - getFirstVisiblePosition());
                    if (!(childAt2 == null || childAt2 == childAt || !childAt2.isPressed())) {
                        childAt2.setPressed(false);
                    }
                }
                view.mMotionPosition = pointToPosition;
                childAt.drawableHotspotChanged(f - ((float) childAt.getLeft()), f2 - ((float) childAt.getTop()));
                if (!childAt.isPressed()) {
                    childAt.setPressed(true);
                }
                Drawable selector2 = getSelector();
                if (selector2 == null) {
                    i2 = pointToPosition;
                } else if (pointToPosition != -1) {
                    i2 = pointToPosition;
                    obj = 1;
                    if (obj != null) {
                        selector2.setVisible(false, false);
                    }
                    rect = view.mSelectorRect;
                    rect.set(childAt.getLeft(), childAt.getTop(), childAt.getRight(), childAt.getBottom());
                    rect.left -= view.mSelectionLeftPadding;
                    rect.top -= view.mSelectionTopPadding;
                    rect.right += view.mSelectionRightPadding;
                    rect.bottom += view.mSelectionBottomPadding;
                    z = view.mIsChildViewEnabled.getBoolean(view);
                    if (childAt.isEnabled() != z) {
                        view.mIsChildViewEnabled.set(view, Boolean.valueOf(z ^ true));
                        if (pointToPosition != -1) {
                            refreshDrawableState();
                        }
                    }
                    if (obj != null) {
                        rect = view.mSelectorRect;
                        exactCenterX = rect.exactCenterX();
                        exactCenterY = rect.exactCenterY();
                        if (getVisibility() != 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        selector2.setVisible(z3, false);
                        selector2.setHotspot(exactCenterX, exactCenterY);
                    }
                    selector = getSelector();
                    if (!(selector == null || i2 == -1)) {
                        selector.setHotspot(f, f2);
                    }
                    setSelectorEnabled(false);
                    refreshDrawableState();
                    if (actionMasked == 1) {
                        performItemClick(childAt, i2, getItemIdAtPosition(i2));
                    }
                    z = true;
                    z2 = false;
                } else {
                    pointToPosition = -1;
                    i2 = -1;
                }
                obj = null;
                if (obj != null) {
                    selector2.setVisible(false, false);
                }
                rect = view.mSelectorRect;
                rect.set(childAt.getLeft(), childAt.getTop(), childAt.getRight(), childAt.getBottom());
                rect.left -= view.mSelectionLeftPadding;
                rect.top -= view.mSelectionTopPadding;
                rect.right += view.mSelectionRightPadding;
                rect.bottom += view.mSelectionBottomPadding;
                try {
                    z = view.mIsChildViewEnabled.getBoolean(view);
                    if (childAt.isEnabled() != z) {
                        view.mIsChildViewEnabled.set(view, Boolean.valueOf(z ^ true));
                        if (pointToPosition != -1) {
                            refreshDrawableState();
                        }
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
                if (obj != null) {
                    rect = view.mSelectorRect;
                    exactCenterX = rect.exactCenterX();
                    exactCenterY = rect.exactCenterY();
                    if (getVisibility() != 0) {
                        z3 = false;
                    } else {
                        z3 = true;
                    }
                    selector2.setVisible(z3, false);
                    selector2.setHotspot(exactCenterX, exactCenterY);
                }
                selector = getSelector();
                selector.setHotspot(f, f2);
                setSelectorEnabled(false);
                refreshDrawableState();
                if (actionMasked == 1) {
                    performItemClick(childAt, i2, getItemIdAtPosition(i2));
                }
                z = true;
                z2 = false;
            }
        }
        if (!z || z2) {
            view.mDrawsInPressedState = false;
            setPressed(false);
            drawableStateChanged();
            View childAt3 = getChildAt(view.mMotionPosition - getFirstVisiblePosition());
            if (childAt3 != null) {
                childAt3.setPressed(false);
            }
        }
        if (z) {
            if (view.mScrollHelper == null) {
                view.mScrollHelper = new ListViewAutoScrollHelper(view);
            }
            view.mScrollHelper.setEnabled$ar$ds(true);
            view.mScrollHelper.onTouch(view, motionEvent2);
        } else {
            AutoScrollHelper autoScrollHelper = view.mScrollHelper;
            if (autoScrollHelper != null) {
                autoScrollHelper.setEnabled$ar$ds(false);
            }
        }
        return z;
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10) {
            if (this.mResolveHoverRunnable == null) {
                Runnable resolveHoverRunnable = new ResolveHoverRunnable();
                this.mResolveHoverRunnable = resolveHoverRunnable;
                resolveHoverRunnable.this$0.post(resolveHoverRunnable);
                actionMasked = 10;
            } else {
                actionMasked = 10;
            }
        }
        boolean onHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked != 9) {
            if (actionMasked != 7) {
                setSelection(-1);
                return onHoverEvent;
            }
        }
        int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        if (!(pointToPosition == -1 || pointToPosition == getSelectedItemPosition())) {
            View childAt = getChildAt(pointToPosition - getFirstVisiblePosition());
            if (childAt.isEnabled()) {
                setSelectionFromTop(pointToPosition, childAt.getTop() - getTop());
            }
            updateSelectorStateCompat();
        }
        return onHoverEvent;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.mMotionPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
                break;
            default:
                break;
        }
        Runnable runnable = this.mResolveHoverRunnable;
        if (runnable != null) {
            DropDownListView dropDownListView = runnable.this$0;
            dropDownListView.mResolveHoverRunnable = null;
            dropDownListView.removeCallbacks(runnable);
        }
        return super.onTouchEvent(motionEvent);
    }

    public final void setSelector(Drawable drawable) {
        Drawable gateKeeperDrawable;
        if (drawable != null) {
            gateKeeperDrawable = new GateKeeperDrawable(drawable);
        } else {
            gateKeeperDrawable = null;
        }
        this.mSelector = gateKeeperDrawable;
        super.setSelector(gateKeeperDrawable);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.mSelectionLeftPadding = rect.left;
        this.mSelectionTopPadding = rect.top;
        this.mSelectionRightPadding = rect.right;
        this.mSelectionBottomPadding = rect.bottom;
    }

    protected final void dispatchDraw(Canvas canvas) {
        if (!this.mSelectorRect.isEmpty()) {
            Drawable selector = getSelector();
            if (selector != null) {
                selector.setBounds(this.mSelectorRect);
                selector.draw(canvas);
            }
        }
        super.dispatchDraw(canvas);
    }
}
