package android.support.p002v7.widget;

import android.content.Context;
import android.support.p000v4.view.ViewPropertyAnimatorCompat;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.DecorToolbar */
public interface DecorToolbar {
    boolean canShowOverflowMenu();

    void collapseActionView();

    void dismissPopupMenus();

    Context getContext();

    int getDisplayOptions();

    void getNavigationMode$ar$ds();

    ViewGroup getViewGroup();

    boolean hasExpandedActionView();

    boolean hideOverflowMenu();

    void initIndeterminateProgress();

    void initProgress();

    boolean isOverflowMenuShowPending();

    boolean isOverflowMenuShowing();

    void setCollapsible$ar$ds();

    void setDisplayOptions(int i);

    void setEmbeddedTabView$ar$ds();

    void setHomeButtonEnabled$ar$ds();

    void setMenu(Menu menu, Callback callback);

    void setMenuPrepared();

    void setVisibility(int i);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);

    ViewPropertyAnimatorCompat setupAnimatorToVisibility(int i, long j);

    boolean showOverflowMenu();
}
