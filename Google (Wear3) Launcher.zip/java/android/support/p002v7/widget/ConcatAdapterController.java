package android.support.p002v7.widget;

import android.support.p002v7.widget.ConcatAdapter.Config;
import android.support.p002v7.widget.NestedAdapterWrapper.Callback;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.support.p002v7.widget.StableIdStorage.IsolatedStableIdStorage;
import android.support.p002v7.widget.StableIdStorage.NoStableIdStorage;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ConcatAdapterController */
final class ConcatAdapterController implements Callback {
    public final List mAttachedRecyclerViews = new ArrayList();
    public final IdentityHashMap mBinderLookup = new IdentityHashMap();
    public final ConcatAdapter mConcatAdapter;
    private WrapperAndLocalPosition mReusableHolder = new WrapperAndLocalPosition();
    private final int mStableIdMode$ar$edu;
    public final StableIdStorage mStableIdStorage;
    public final ViewTypeStorage$IsolatedViewTypeStorage mViewTypeStorage$ar$class_merging;
    public final List mWrappers = new ArrayList();

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ConcatAdapterController$WrapperAndLocalPosition */
    final class WrapperAndLocalPosition {
        boolean mInUse;
        int mLocalPosition;
        NestedAdapterWrapper mWrapper;
    }

    public ConcatAdapterController(ConcatAdapter concatAdapter, Config config) {
        this.mConcatAdapter = concatAdapter;
        this.mViewTypeStorage$ar$class_merging = new ViewTypeStorage$IsolatedViewTypeStorage();
        int i = config.stableIdMode$ar$edu;
        this.mStableIdMode$ar$edu = i;
        if (i == 1) {
            this.mStableIdStorage = new NoStableIdStorage();
        } else {
            this.mStableIdStorage = new IsolatedStableIdStorage();
        }
    }

    public final int countItemsBefore(NestedAdapterWrapper nestedAdapterWrapper) {
        int i = 0;
        for (NestedAdapterWrapper nestedAdapterWrapper2 : this.mWrappers) {
            if (nestedAdapterWrapper2 == nestedAdapterWrapper) {
                break;
            }
            i += nestedAdapterWrapper2.mCachedItemCount;
        }
        return i;
    }

    public final WrapperAndLocalPosition findWrapperAndLocalPosition(int i) {
        WrapperAndLocalPosition wrapperAndLocalPosition = this.mReusableHolder;
        if (wrapperAndLocalPosition.mInUse) {
            wrapperAndLocalPosition = new WrapperAndLocalPosition();
        } else {
            wrapperAndLocalPosition.mInUse = true;
        }
        int i2 = i;
        for (NestedAdapterWrapper nestedAdapterWrapper : this.mWrappers) {
            int i3 = nestedAdapterWrapper.mCachedItemCount;
            if (i3 > i2) {
                wrapperAndLocalPosition.mWrapper = nestedAdapterWrapper;
                wrapperAndLocalPosition.mLocalPosition = i2;
                break;
            }
            i2 -= i3;
        }
        if (wrapperAndLocalPosition.mWrapper != null) {
            return wrapperAndLocalPosition;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find wrapper for ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public final NestedAdapterWrapper getWrapper(ViewHolder viewHolder) {
        NestedAdapterWrapper nestedAdapterWrapper = (NestedAdapterWrapper) this.mBinderLookup.get(viewHolder);
        if (nestedAdapterWrapper != null) {
            return nestedAdapterWrapper;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find wrapper for ");
        stringBuilder.append(viewHolder);
        stringBuilder.append(", seems like it is not bound by this adapter: ");
        stringBuilder.append(this);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final boolean hasStableIds() {
        return this.mStableIdMode$ar$edu != 1;
    }

    public final void onItemRangeChanged(NestedAdapterWrapper nestedAdapterWrapper, int i, int i2, Object obj) {
        this.mConcatAdapter.notifyItemRangeChanged(i + countItemsBefore(nestedAdapterWrapper), i2, obj);
    }

    public final void releaseWrapperAndLocalPosition(WrapperAndLocalPosition wrapperAndLocalPosition) {
        wrapperAndLocalPosition.mInUse = false;
        wrapperAndLocalPosition.mWrapper = null;
        wrapperAndLocalPosition.mLocalPosition = -1;
        this.mReusableHolder = wrapperAndLocalPosition;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void calculateAndUpdateStateRestorationPolicy() {
        /*
        r5 = this;
        r0 = r5.mWrappers;
        r0 = r0.iterator();
    L_0x0006:
        r1 = r0.hasNext();
        r2 = 3;
        if (r1 == 0) goto L_0x0022;
    L_0x000d:
        r1 = r0.next();
        r1 = (android.support.p002v7.widget.NestedAdapterWrapper) r1;
        r3 = r1.adapter;
        r3 = r3.mStateRestorationPolicy$ar$edu;
        if (r3 != r2) goto L_0x001a;
    L_0x0019:
        goto L_0x0023;
    L_0x001a:
        r4 = 2;
        if (r3 != r4) goto L_0x0006;
    L_0x001d:
        r1 = r1.mCachedItemCount;
        if (r1 != 0) goto L_0x0006;
    L_0x0021:
        goto L_0x0023;
    L_0x0022:
        r2 = 1;
    L_0x0023:
        r0 = r5.mConcatAdapter;
        r1 = r0.mStateRestorationPolicy$ar$edu;
        if (r2 == r1) goto L_0x0030;
    L_0x0029:
        r0.mStateRestorationPolicy$ar$edu = r2;
        r0 = r0.mObservable;
        r0.notifyStateRestorationPolicyChanged();
    L_0x0030:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ConcatAdapterController.calculateAndUpdateStateRestorationPolicy():void");
    }
}
