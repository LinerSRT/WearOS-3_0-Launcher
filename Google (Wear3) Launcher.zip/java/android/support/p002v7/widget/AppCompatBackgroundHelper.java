package android.support.p002v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.util.AttributeSet;
import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatBackgroundHelper */
final class AppCompatBackgroundHelper {
    private int mBackgroundResId = -1;
    private final AppCompatDrawableManager mDrawableManager;
    private TintInfo mInternalBackgroundTint;
    private TintInfo mTmpInfo;
    private final View mView;

    public AppCompatBackgroundHelper(View view) {
        this.mView = view;
        this.mDrawableManager = AppCompatDrawableManager.get();
    }

    final void applySupportBackgroundTint() {
        Drawable background = this.mView.getBackground();
        if (background != null) {
            TintInfo tintInfo;
            if (this.mInternalBackgroundTint != null) {
                if (this.mTmpInfo == null) {
                    this.mTmpInfo = new TintInfo();
                }
                tintInfo = this.mTmpInfo;
                tintInfo.mTintList = null;
                tintInfo.mHasTintList = false;
                tintInfo.mTintMode = null;
                tintInfo.mHasTintMode = false;
                ColorStateList backgroundTintList = ViewCompat.getBackgroundTintList(this.mView);
                if (backgroundTintList != null) {
                    tintInfo.mHasTintList = true;
                    tintInfo.mTintList = backgroundTintList;
                }
                Mode backgroundTintMode = ViewCompat.getBackgroundTintMode(this.mView);
                if (backgroundTintMode != null) {
                    tintInfo.mHasTintMode = true;
                    tintInfo.mTintMode = backgroundTintMode;
                }
                if (tintInfo.mHasTintList || tintInfo.mHasTintMode) {
                    ResourceManagerInternal.tintDrawable(background, tintInfo, this.mView.getDrawableState());
                    return;
                }
            }
            tintInfo = this.mInternalBackgroundTint;
            if (tintInfo != null) {
                ResourceManagerInternal.tintDrawable(background, tintInfo, this.mView.getDrawableState());
            }
        }
    }

    final void loadFromAttributes(AttributeSet attributeSet, int i) {
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(this.mView.getContext(), attributeSet, R$styleable.ViewBackgroundHelper, i);
        View view = this.mView;
        ViewCompat.saveAttributeDataForStyleable(view, view.getContext(), R$styleable.ViewBackgroundHelper, attributeSet, obtainStyledAttributes$ar$ds.mWrapped, i, 0);
        try {
            if (obtainStyledAttributes$ar$ds.hasValue(0)) {
                this.mBackgroundResId = obtainStyledAttributes$ar$ds.getResourceId(0, -1);
                ColorStateList tintList = this.mDrawableManager.getTintList(this.mView.getContext(), this.mBackgroundResId);
                if (tintList != null) {
                    setInternalBackgroundTint(tintList);
                }
            }
            if (obtainStyledAttributes$ar$ds.hasValue(1)) {
                ViewCompat.setBackgroundTintList(this.mView, obtainStyledAttributes$ar$ds.getColorStateList(1));
            }
            if (obtainStyledAttributes$ar$ds.hasValue(2)) {
                ViewCompat.setBackgroundTintMode(this.mView, DrawableUtils.parseTintMode(obtainStyledAttributes$ar$ds.getInt(2, -1), null));
            }
            obtainStyledAttributes$ar$ds.recycle();
        } catch (Throwable th) {
            obtainStyledAttributes$ar$ds.recycle();
        }
    }

    final void onSetBackgroundDrawable$ar$ds() {
        this.mBackgroundResId = -1;
        setInternalBackgroundTint(null);
        applySupportBackgroundTint();
    }

    final void onSetBackgroundResource(int i) {
        ColorStateList tintList;
        this.mBackgroundResId = i;
        AppCompatDrawableManager appCompatDrawableManager = this.mDrawableManager;
        if (appCompatDrawableManager != null) {
            tintList = appCompatDrawableManager.getTintList(this.mView.getContext(), i);
        } else {
            tintList = null;
        }
        setInternalBackgroundTint(tintList);
        applySupportBackgroundTint();
    }

    final void setInternalBackgroundTint(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.mInternalBackgroundTint == null) {
                this.mInternalBackgroundTint = new TintInfo();
            }
            TintInfo tintInfo = this.mInternalBackgroundTint;
            tintInfo.mTintList = colorStateList;
            tintInfo.mHasTintList = true;
        } else {
            this.mInternalBackgroundTint = null;
        }
        applySupportBackgroundTint();
    }
}
