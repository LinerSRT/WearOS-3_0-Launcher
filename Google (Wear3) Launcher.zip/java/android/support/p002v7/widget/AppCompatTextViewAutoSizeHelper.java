package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.RectF;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import p020j$.util.concurrent.ConcurrentHashMap;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatTextViewAutoSizeHelper */
final class AppCompatTextViewAutoSizeHelper {
    public float mAutoSizeMaxTextSizeInPx = -1.0f;
    public float mAutoSizeMinTextSizeInPx = -1.0f;
    public float mAutoSizeStepGranularityInPx = -1.0f;
    public int[] mAutoSizeTextSizesInPx = new int[0];
    public int mAutoSizeTextType = 0;
    public final Context mContext;
    public boolean mHasPresetAutoSizeValues = false;
    public final TextView mTextView;

    static {
        RectF rectF = new RectF();
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        concurrentHashMap = new ConcurrentHashMap();
    }

    public AppCompatTextViewAutoSizeHelper(TextView textView) {
        this.mTextView = textView;
        this.mContext = textView.getContext();
    }

    public static final int[] cleanupAutoSizePresetSizes$ar$ds(int[] iArr) {
        if (r0 == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        List arrayList = new ArrayList();
        for (int i : iArr) {
            if (i > 0) {
                Integer valueOf = Integer.valueOf(i);
                if (Collections.binarySearch(arrayList, valueOf) < 0) {
                    arrayList.add(valueOf);
                }
            }
        }
        if (r0 == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i2 = 0; i2 < size; i2++) {
            iArr2[i2] = ((Integer) arrayList.get(i2)).intValue();
        }
        return iArr2;
    }

    public final boolean supportsAutoSizeText() {
        return !(this.mTextView instanceof AppCompatEditText);
    }
}
