package android.support.p002v7.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ActionBarBackgroundDrawable */
final class ActionBarBackgroundDrawable extends Drawable {
    final ActionBarContainer mContainer;

    public ActionBarBackgroundDrawable(ActionBarContainer actionBarContainer) {
        this.mContainer = actionBarContainer;
    }

    public final void draw(Canvas canvas) {
        ActionBarContainer actionBarContainer = this.mContainer;
        Drawable drawable;
        if (actionBarContainer.mIsSplit) {
            drawable = actionBarContainer.mSplitBackground;
            if (drawable != null) {
                drawable.draw(canvas);
                return;
            }
        }
        drawable = actionBarContainer.mBackground;
        if (drawable != null) {
            drawable.draw(canvas);
        }
        ActionBarContainer actionBarContainer2 = this.mContainer;
        if (actionBarContainer2.mStackedBackground != null) {
            boolean z = actionBarContainer2.mIsStacked;
        }
    }

    public final int getOpacity() {
        return 0;
    }

    public final void getOutline(Outline outline) {
        ActionBarContainer actionBarContainer = this.mContainer;
        Drawable drawable;
        if (actionBarContainer.mIsSplit) {
            drawable = actionBarContainer.mSplitBackground;
            if (drawable != null) {
                drawable.getOutline(outline);
                return;
            }
        }
        drawable = actionBarContainer.mBackground;
        if (drawable != null) {
            drawable.getOutline(outline);
        }
    }

    public final void setAlpha(int i) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }
}
