package android.support.p002v7.widget;

import android.support.p002v7.widget.RecyclerView;
import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.OnFlingListener;
import android.support.p002v7.widget.RecyclerView.OnScrollListener;
import android.support.p002v7.widget.RecyclerView.SmoothScroller;
import android.support.p002v7.widget.RecyclerView.SmoothScroller.Action;
import android.support.p002v7.widget.RecyclerView.SmoothScroller.ScrollVectorProvider;
import android.support.p002v7.widget.RecyclerView.State;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Scroller;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.SnapHelper */
public abstract class SnapHelper extends OnFlingListener {
    private Scroller mGravityScroller;
    RecyclerView mRecyclerView;
    private final OnScrollListener mScrollListener = new PG();

    /* renamed from: android.support.v7.widget.SnapHelper$1 */
    final class PG extends OnScrollListener {
        boolean mScrolled = false;

        public final void onScrollStateChanged(RecyclerView recyclerView, int i) {
            if (i == 0 && this.mScrolled) {
                this.mScrolled = false;
                SnapHelper.this.snapToTargetExistingView();
            }
        }

        public final void onScrolled(RecyclerView recyclerView, int i, int i2) {
            if (i == 0) {
                if (i2 == 0) {
                    return;
                }
            }
            this.mScrolled = true;
        }
    }

    public abstract int[] calculateDistanceToFinalSnap(LayoutManager layoutManager, View view);

    public int[] calculateScrollDistance(int i, int i2) {
        r0 = new int[2];
        this.mGravityScroller.fling(0, 0, i, i2, LinearLayoutManager.INVALID_OFFSET, Integer.MAX_VALUE, LinearLayoutManager.INVALID_OFFSET, Integer.MAX_VALUE);
        r0[0] = this.mGravityScroller.getFinalX();
        r0[1] = this.mGravityScroller.getFinalY();
        return r0;
    }

    public abstract View findSnapView(LayoutManager layoutManager);

    public abstract int findTargetSnapPosition(LayoutManager layoutManager, int i, int i2);

    public boolean onFling(int i, int i2) {
        RecyclerView recyclerView = this.mRecyclerView;
        LayoutManager layoutManager = recyclerView.mLayout;
        if (layoutManager == null || recyclerView.mAdapter == null) {
            return false;
        }
        int i3 = recyclerView.mMinFlingVelocity;
        if (Math.abs(i2) > i3 || Math.abs(i) > i3) {
            if (layoutManager instanceof ScrollVectorProvider) {
                SmoothScroller createScroller = createScroller(layoutManager);
                if (createScroller != null) {
                    i = findTargetSnapPosition(layoutManager, i, i2);
                    if (i != -1) {
                        createScroller.mTargetPosition = i;
                        layoutManager.startSmoothScroll(createScroller);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    final void snapToTargetExistingView() {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            LayoutManager layoutManager = recyclerView.mLayout;
            if (layoutManager != null) {
                View findSnapView = findSnapView(layoutManager);
                if (findSnapView != null) {
                    int[] calculateDistanceToFinalSnap = calculateDistanceToFinalSnap(layoutManager, findSnapView);
                    int i = 0;
                    int i2 = calculateDistanceToFinalSnap[0];
                    if (i2 != 0) {
                        i = i2;
                    } else if (calculateDistanceToFinalSnap[1] == 0) {
                        return;
                    }
                    this.mRecyclerView.smoothScrollBy(i, calculateDistanceToFinalSnap[1]);
                }
            }
        }
    }

    public void attachToRecyclerView(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.mRecyclerView;
        if (recyclerView2 != recyclerView) {
            if (recyclerView2 != null) {
                recyclerView2.removeOnScrollListener(this.mScrollListener);
                this.mRecyclerView.mOnFlingListener = null;
            }
            this.mRecyclerView = recyclerView;
            if (recyclerView == null) {
                return;
            }
            if (recyclerView.mOnFlingListener == null) {
                recyclerView.addOnScrollListener(this.mScrollListener);
                ViewGroup viewGroup = this.mRecyclerView;
                viewGroup.mOnFlingListener = this;
                this.mGravityScroller = new Scroller(viewGroup.getContext(), new DecelerateInterpolator());
                snapToTargetExistingView();
                return;
            }
            throw new IllegalStateException("An instance of OnFlingListener already set.");
        }
    }

    protected SmoothScroller createScroller(LayoutManager layoutManager) {
        if (layoutManager instanceof ScrollVectorProvider) {
            return new LinearSmoothScroller(this.mRecyclerView.getContext()) {
                protected final float calculateSpeedPerPixel(DisplayMetrics displayMetrics) {
                    return 100.0f / ((float) displayMetrics.densityDpi);
                }

                protected final void onTargetFound(View view, State state, Action action) {
                    android.support.p002v7.widget.SnapHelper snapHelper = android.support.p002v7.widget.SnapHelper.this;
                    RecyclerView recyclerView = snapHelper.mRecyclerView;
                    if (recyclerView != null) {
                        int[] calculateDistanceToFinalSnap = snapHelper.calculateDistanceToFinalSnap(recyclerView.mLayout, view);
                        int i = calculateDistanceToFinalSnap[0];
                        int i2 = calculateDistanceToFinalSnap[1];
                        int calculateTimeForDeceleration = calculateTimeForDeceleration(Math.max(Math.abs(i), Math.abs(i2)));
                        if (calculateTimeForDeceleration > 0) {
                            action.update(i, i2, calculateTimeForDeceleration, this.mDecelerateInterpolator);
                        }
                    }
                }
            };
        }
        return null;
    }
}
