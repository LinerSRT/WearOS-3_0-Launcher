package android.support.p002v7.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.app.AlertController.AlertParams;
import android.support.p002v7.app.AlertDialog;
import android.support.p002v7.app.AlertDialog.Builder;
import android.support.p002v7.app.AppCompatDialog;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.content.res.AppCompatResources;
import android.support.p002v7.view.menu.ShowableListMenu;
import android.support.v7.widget.AppCompatSpinner.C00912;
import android.support.v7.widget.AppCompatSpinner.DropdownPopup.C00922;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.view.ContextThemeWrapper;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatSpinner */
public final class AppCompatSpinner extends Spinner {
    private static final int[] ATTRS_ANDROID_SPINNERMODE = new int[]{16843505};
    private final AppCompatBackgroundHelper mBackgroundTintHelper;
    int mDropDownWidth;
    private ForwardingListener mForwardingListener;
    public SpinnerPopup mPopup;
    public final Context mPopupContext;
    private final boolean mPopupSet;
    private SpinnerAdapter mTempAdapter;
    final Rect mTempRect = new Rect();

    /* renamed from: android.support.v7.widget.AppCompatSpinner$2 */
    final class C00912 implements OnGlobalLayoutListener {
        public final void onGlobalLayout() {
            if (!android.support.p002v7.widget.AppCompatSpinner.this.mPopup.isShowing()) {
                android.support.p002v7.widget.AppCompatSpinner.this.showPopup();
            }
            ViewTreeObserver viewTreeObserver = android.support.p002v7.widget.AppCompatSpinner.this.getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this);
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.AppCompatSpinner$DialogPopup */
    final class DialogPopup implements SpinnerPopup, OnClickListener {
        private ListAdapter mListAdapter;
        AlertDialog mPopup;
        private CharSequence mPrompt;

        public final void dismiss() {
            AppCompatDialog appCompatDialog = this.mPopup;
            if (appCompatDialog != null) {
                appCompatDialog.dismiss();
                this.mPopup = null;
            }
        }

        public final Drawable getBackground() {
            return null;
        }

        public final CharSequence getHintText() {
            return this.mPrompt;
        }

        public final int getHorizontalOffset() {
            return 0;
        }

        public final int getVerticalOffset() {
            return 0;
        }

        public final boolean isShowing() {
            AlertDialog alertDialog = this.mPopup;
            return alertDialog != null ? alertDialog.isShowing() : false;
        }

        public final void onClick(DialogInterface dialogInterface, int i) {
            AppCompatSpinner.this.setSelection(i);
            if (AppCompatSpinner.this.getOnItemClickListener() != null) {
                AppCompatSpinner.this.performItemClick(null, i, this.mListAdapter.getItemId(i));
            }
            dismiss();
        }

        public final void setAdapter(ListAdapter listAdapter) {
            this.mListAdapter = listAdapter;
        }

        public final void setBackgroundDrawable(Drawable drawable) {
            Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
        }

        public final void setHorizontalOffset(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
        }

        public final void setHorizontalOriginalOffset(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
        }

        public final void setPromptText(CharSequence charSequence) {
            this.mPrompt = charSequence;
        }

        public final void setVerticalOffset(int i) {
            Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
        }

        public final void show(int i, int i2) {
            if (this.mListAdapter != null) {
                Builder builder = new Builder(AppCompatSpinner.this.mPopupContext);
                CharSequence charSequence = this.mPrompt;
                if (charSequence != null) {
                    builder.setTitle$ar$ds(charSequence);
                }
                ListAdapter listAdapter = this.mListAdapter;
                int selectedItemPosition = AppCompatSpinner.this.getSelectedItemPosition();
                AlertParams alertParams = builder.f4P;
                alertParams.mAdapter = listAdapter;
                alertParams.mOnClickListener = this;
                alertParams.mCheckedItem = selectedItemPosition;
                alertParams.mIsSingleChoice = true;
                AlertDialog create = builder.create();
                this.mPopup = create;
                ListView listView = create.mAlert.mListView;
                listView.setTextDirection(i);
                listView.setTextAlignment(i2);
                this.mPopup.show();
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.AppCompatSpinner$DropDownAdapter */
    final class DropDownAdapter implements ListAdapter, SpinnerAdapter {
        private final SpinnerAdapter mAdapter;
        private ListAdapter mListAdapter;

        public DropDownAdapter(SpinnerAdapter spinnerAdapter, Theme theme) {
            this.mAdapter = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.mListAdapter = (ListAdapter) spinnerAdapter;
            }
            if (theme != null) {
                if (spinnerAdapter instanceof ThemedSpinnerAdapter) {
                    ThemedSpinnerAdapter themedSpinnerAdapter = (ThemedSpinnerAdapter) spinnerAdapter;
                    if (themedSpinnerAdapter.getDropDownViewTheme() != theme) {
                        themedSpinnerAdapter.setDropDownViewTheme(theme);
                    }
                } else if (spinnerAdapter instanceof ThemedSpinnerAdapter) {
                    ThemedSpinnerAdapter themedSpinnerAdapter2 = (ThemedSpinnerAdapter) spinnerAdapter;
                    if (themedSpinnerAdapter2.getDropDownViewTheme() == null) {
                        themedSpinnerAdapter2.setDropDownViewTheme$ar$ds();
                    }
                }
            }
        }

        public final boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.mListAdapter;
            return listAdapter != null ? listAdapter.areAllItemsEnabled() : true;
        }

        public final int getCount() {
            SpinnerAdapter spinnerAdapter = this.mAdapter;
            return spinnerAdapter == null ? 0 : spinnerAdapter.getCount();
        }

        public final View getDropDownView(int i, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.mAdapter;
            return spinnerAdapter == null ? null : spinnerAdapter.getDropDownView(i, view, viewGroup);
        }

        public final Object getItem(int i) {
            SpinnerAdapter spinnerAdapter = this.mAdapter;
            return spinnerAdapter == null ? null : spinnerAdapter.getItem(i);
        }

        public final long getItemId(int i) {
            SpinnerAdapter spinnerAdapter = this.mAdapter;
            return spinnerAdapter == null ? -1 : spinnerAdapter.getItemId(i);
        }

        public final int getItemViewType(int i) {
            return 0;
        }

        public final View getView(int i, View view, ViewGroup viewGroup) {
            return getDropDownView(i, view, viewGroup);
        }

        public final int getViewTypeCount() {
            return 1;
        }

        public final boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.mAdapter;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        public final boolean isEmpty() {
            return getCount() == 0;
        }

        public final boolean isEnabled(int i) {
            ListAdapter listAdapter = this.mListAdapter;
            return listAdapter != null ? listAdapter.isEnabled(i) : true;
        }

        public final void registerDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.mAdapter;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        public final void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.mAdapter;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.AppCompatSpinner$DropdownPopup */
    final class DropdownPopup extends ListPopupWindow implements SpinnerPopup {
        ListAdapter mAdapter;
        public CharSequence mHintText;
        private int mOriginalHorizontalOffset;
        public final Rect mVisibleRect = new Rect();

        /* renamed from: android.support.v7.widget.AppCompatSpinner$DropdownPopup$1 */
        final class PG implements OnItemClickListener {
            public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                AppCompatSpinner.this.setSelection(i);
                if (AppCompatSpinner.this.getOnItemClickListener() != null) {
                    DropdownPopup dropdownPopup = DropdownPopup.this;
                    AppCompatSpinner.this.performItemClick(view, i, dropdownPopup.mAdapter.getItemId(i));
                }
                DropdownPopup.this.dismiss();
            }
        }

        /* renamed from: android.support.v7.widget.AppCompatSpinner$DropdownPopup$2 */
        final class C00922 implements OnGlobalLayoutListener {
            public final void onGlobalLayout() {
                android.support.p002v7.widget.AppCompatSpinner.DropdownPopup dropdownPopup = android.support.p002v7.widget.AppCompatSpinner.DropdownPopup.this;
                View view = android.support.p002v7.widget.AppCompatSpinner.this;
                if (ViewCompat.isAttachedToWindow(view) && view.getGlobalVisibleRect(dropdownPopup.mVisibleRect)) {
                    android.support.p002v7.widget.AppCompatSpinner.DropdownPopup.this.computeContentWidth();
                    super.show();
                    return;
                }
                android.support.p002v7.widget.AppCompatSpinner.DropdownPopup.this.dismiss();
            }
        }

        final void computeContentWidth() {
            Drawable background = getBackground();
            int i = 0;
            if (background != null) {
                background.getPadding(AppCompatSpinner.this.mTempRect);
                i = ViewUtils.isLayoutRtl(AppCompatSpinner.this) ? AppCompatSpinner.this.mTempRect.right : -AppCompatSpinner.this.mTempRect.left;
            } else {
                Rect rect = AppCompatSpinner.this.mTempRect;
                rect.right = 0;
                rect.left = 0;
            }
            int paddingLeft = AppCompatSpinner.this.getPaddingLeft();
            int paddingRight = AppCompatSpinner.this.getPaddingRight();
            int width = AppCompatSpinner.this.getWidth();
            AppCompatSpinner appCompatSpinner = AppCompatSpinner.this;
            int i2 = appCompatSpinner.mDropDownWidth;
            if (i2 == -2) {
                int compatMeasureContentWidth = appCompatSpinner.compatMeasureContentWidth(this.mAdapter, getBackground());
                i2 = (AppCompatSpinner.this.getContext().getResources().getDisplayMetrics().widthPixels - AppCompatSpinner.this.mTempRect.left) - AppCompatSpinner.this.mTempRect.right;
                if (compatMeasureContentWidth > i2) {
                    compatMeasureContentWidth = i2;
                }
                setContentWidth(Math.max(compatMeasureContentWidth, (width - paddingLeft) - paddingRight));
            } else if (i2 == -1) {
                setContentWidth((width - paddingLeft) - paddingRight);
            } else {
                setContentWidth(i2);
            }
            this.mDropDownHorizontalOffset = ViewUtils.isLayoutRtl(AppCompatSpinner.this) ? i + (((width - paddingRight) - this.mDropDownWidth) - this.mOriginalHorizontalOffset) : i + (paddingLeft + this.mOriginalHorizontalOffset);
        }

        public final CharSequence getHintText() {
            return this.mHintText;
        }

        public final void setAdapter(ListAdapter listAdapter) {
            super.setAdapter(listAdapter);
            this.mAdapter = listAdapter;
        }

        public final void setHorizontalOriginalOffset(int i) {
            this.mOriginalHorizontalOffset = i;
        }

        public final void setPromptText(CharSequence charSequence) {
            this.mHintText = charSequence;
        }

        public final void show(int i, int i2) {
            boolean isShowing = isShowing();
            computeContentWidth();
            setInputMethodMode$ar$ds();
            super.show();
            ListView listView = this.mDropDownList;
            listView.setChoiceMode(1);
            listView.setTextDirection(i);
            listView.setTextAlignment(i2);
            i = AppCompatSpinner.this.getSelectedItemPosition();
            ListView listView2 = this.mDropDownList;
            if (isShowing() && listView2 != null) {
                listView2.mListSelectionHidden = false;
                listView2.setSelection(i);
                if (listView2.getChoiceMode() != 0) {
                    listView2.setItemChecked(i, true);
                }
            }
            if (!isShowing) {
                ViewTreeObserver viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    final OnGlobalLayoutListener c00922 = new C00922();
                    viewTreeObserver.addOnGlobalLayoutListener(c00922);
                    setOnDismissListener(new OnDismissListener() {
                        public final void onDismiss() {
                            ViewTreeObserver viewTreeObserver = android.support.p002v7.widget.AppCompatSpinner.this.getViewTreeObserver();
                            if (viewTreeObserver != null) {
                                viewTreeObserver.removeGlobalOnLayoutListener(c00922);
                            }
                        }
                    });
                }
            }
        }

        public DropdownPopup(Context context, AttributeSet attributeSet) {
            super(context, attributeSet, R.attr.spinnerStyle);
            this.mDropDownAnchorView = AppCompatSpinner.this;
            setModal$ar$ds();
            this.mItemClickListener = new PG();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.AppCompatSpinner$SavedState */
    final class SavedState extends BaseSavedState {
        public static final Creator CREATOR = new PG();
        boolean mShowDropdown;

        /* renamed from: android.support.v7.widget.AppCompatSpinner$SavedState$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new SavedState[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }
        }

        public SavedState(Parcel parcel) {
            super(parcel);
            this.mShowDropdown = parcel.readByte() != (byte) 0;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeByte(this.mShowDropdown);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.AppCompatSpinner$SpinnerPopup */
    interface SpinnerPopup {
        void dismiss();

        Drawable getBackground();

        CharSequence getHintText();

        int getHorizontalOffset();

        int getVerticalOffset();

        boolean isShowing();

        void setAdapter(ListAdapter listAdapter);

        void setBackgroundDrawable(Drawable drawable);

        void setHorizontalOffset(int i);

        void setHorizontalOriginalOffset(int i);

        void setPromptText(CharSequence charSequence);

        void setVerticalOffset(int i);

        void show(int i, int i2);
    }

    final int compatMeasureContentWidth(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        int max2 = Math.max(0, max - (15 - (min - max)));
        View view = null;
        max = 0;
        while (max2 < min) {
            int i2;
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i) {
                i2 = itemViewType;
            } else {
                i2 = i;
            }
            if (itemViewType != i) {
                view = null;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            max = Math.max(max, view.getMeasuredWidth());
            max2++;
            i = i2;
        }
        if (drawable != null) {
            drawable.getPadding(this.mTempRect);
            max += this.mTempRect.left + this.mTempRect.right;
        }
        return max;
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        AppCompatBackgroundHelper appCompatBackgroundHelper = this.mBackgroundTintHelper;
        if (appCompatBackgroundHelper != null) {
            appCompatBackgroundHelper.applySupportBackgroundTint();
        }
    }

    public final int getDropDownHorizontalOffset() {
        SpinnerPopup spinnerPopup = this.mPopup;
        return spinnerPopup != null ? spinnerPopup.getHorizontalOffset() : super.getDropDownHorizontalOffset();
    }

    public final int getDropDownVerticalOffset() {
        SpinnerPopup spinnerPopup = this.mPopup;
        return spinnerPopup != null ? spinnerPopup.getVerticalOffset() : super.getDropDownVerticalOffset();
    }

    public final int getDropDownWidth() {
        return this.mPopup != null ? this.mDropDownWidth : super.getDropDownWidth();
    }

    public final Drawable getPopupBackground() {
        SpinnerPopup spinnerPopup = this.mPopup;
        if (spinnerPopup != null) {
            return spinnerPopup.getBackground();
        }
        return super.getPopupBackground();
    }

    public final Context getPopupContext() {
        return this.mPopupContext;
    }

    public final CharSequence getPrompt() {
        SpinnerPopup spinnerPopup = this.mPopup;
        return spinnerPopup != null ? spinnerPopup.getHintText() : super.getPrompt();
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        SpinnerPopup spinnerPopup = this.mPopup;
        if (spinnerPopup != null && spinnerPopup.isShowing()) {
            this.mPopup.dismiss();
        }
    }

    protected final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.mPopup != null && MeasureSpec.getMode(i) == LinearLayoutManager.INVALID_OFFSET) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), compatMeasureContentWidth(getAdapter(), getBackground())), MeasureSpec.getSize(i)), getMeasuredHeight());
        }
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (savedState.mShowDropdown) {
            ViewTreeObserver viewTreeObserver = getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.addOnGlobalLayoutListener(new C00912());
            }
        }
    }

    public final Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        SpinnerPopup spinnerPopup = this.mPopup;
        boolean z = false;
        if (spinnerPopup != null && spinnerPopup.isShowing()) {
            z = true;
        }
        savedState.mShowDropdown = z;
        return savedState;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ForwardingListener forwardingListener = this.mForwardingListener;
        if (forwardingListener == null || !forwardingListener.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public final boolean performClick() {
        SpinnerPopup spinnerPopup = this.mPopup;
        if (spinnerPopup == null) {
            return super.performClick();
        }
        if (!spinnerPopup.isShowing()) {
            showPopup();
        }
        return true;
    }

    public final void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        AppCompatBackgroundHelper appCompatBackgroundHelper = this.mBackgroundTintHelper;
        if (appCompatBackgroundHelper != null) {
            appCompatBackgroundHelper.onSetBackgroundDrawable$ar$ds();
        }
    }

    public final void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        AppCompatBackgroundHelper appCompatBackgroundHelper = this.mBackgroundTintHelper;
        if (appCompatBackgroundHelper != null) {
            appCompatBackgroundHelper.onSetBackgroundResource(i);
        }
    }

    public final void setDropDownHorizontalOffset(int i) {
        SpinnerPopup spinnerPopup = this.mPopup;
        if (spinnerPopup != null) {
            spinnerPopup.setHorizontalOriginalOffset(i);
            this.mPopup.setHorizontalOffset(i);
            return;
        }
        super.setDropDownHorizontalOffset(i);
    }

    public final void setDropDownVerticalOffset(int i) {
        SpinnerPopup spinnerPopup = this.mPopup;
        if (spinnerPopup != null) {
            spinnerPopup.setVerticalOffset(i);
        } else {
            super.setDropDownVerticalOffset(i);
        }
    }

    public final void setDropDownWidth(int i) {
        if (this.mPopup != null) {
            this.mDropDownWidth = i;
        } else {
            super.setDropDownWidth(i);
        }
    }

    public final void setPopupBackgroundDrawable(Drawable drawable) {
        SpinnerPopup spinnerPopup = this.mPopup;
        if (spinnerPopup != null) {
            spinnerPopup.setBackgroundDrawable(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    public final void setPopupBackgroundResource(int i) {
        setPopupBackgroundDrawable(AppCompatResources.getDrawable(this.mPopupContext, i));
    }

    public final void setPrompt(CharSequence charSequence) {
        SpinnerPopup spinnerPopup = this.mPopup;
        if (spinnerPopup != null) {
            spinnerPopup.setPromptText(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    final void showPopup() {
        this.mPopup.show(getTextDirection(), getTextAlignment());
    }

    public AppCompatSpinner(Context context, AttributeSet attributeSet) {
        Throwable e;
        CharSequence[] textArray;
        SpinnerAdapter arrayAdapter;
        SpinnerAdapter spinnerAdapter;
        Throwable th;
        super(context, attributeSet, R.attr.spinnerStyle);
        ThemeUtils.checkAppCompatTheme(this, getContext());
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(context, attributeSet, R$styleable.Spinner, R.attr.spinnerStyle);
        this.mBackgroundTintHelper = new AppCompatBackgroundHelper(this);
        int resourceId = obtainStyledAttributes$ar$ds.getResourceId(4, 0);
        if (resourceId != 0) {
            this.mPopupContext = new ContextThemeWrapper(context, resourceId);
        } else {
            this.mPopupContext = context;
        }
        TypedArray typedArray = null;
        TypedArray obtainStyledAttributes;
        try {
            obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ATTRS_ANDROID_SPINNERMODE, R.attr.spinnerStyle, 0);
            try {
                int i;
                if (obtainStyledAttributes.hasValue(0)) {
                    i = obtainStyledAttributes.getInt(0, 0);
                } else {
                    i = -1;
                }
                if (obtainStyledAttributes != null) {
                    obtainStyledAttributes.recycle();
                }
                switch (i) {
                    case 0:
                        SpinnerPopup dialogPopup = new DialogPopup();
                        this.mPopup = dialogPopup;
                        dialogPopup.setPromptText(obtainStyledAttributes$ar$ds.getString(2));
                        break;
                    case 1:
                        final DropdownPopup dropdownPopup = new DropdownPopup(this.mPopupContext, attributeSet);
                        TintTypedArray obtainStyledAttributes$ar$ds2 = TintTypedArray.obtainStyledAttributes$ar$ds(this.mPopupContext, attributeSet, R$styleable.Spinner, R.attr.spinnerStyle);
                        this.mDropDownWidth = obtainStyledAttributes$ar$ds2.getLayoutDimension(3, -2);
                        dropdownPopup.setBackgroundDrawable(obtainStyledAttributes$ar$ds2.getDrawable(1));
                        dropdownPopup.mHintText = obtainStyledAttributes$ar$ds.getString(2);
                        obtainStyledAttributes$ar$ds2.recycle();
                        this.mPopup = dropdownPopup;
                        this.mForwardingListener = new ForwardingListener(this) {
                            public final ShowableListMenu getPopup() {
                                return dropdownPopup;
                            }

                            public final boolean onForwardingStarted() {
                                if (!AppCompatSpinner.this.mPopup.isShowing()) {
                                    AppCompatSpinner.this.showPopup();
                                }
                                return true;
                            }
                        };
                        break;
                    default:
                        break;
                }
            } catch (Exception e2) {
                e = e2;
                try {
                    Log.i("AppCompatSpinner", "Could not read android:spinnerMode", e);
                    if (obtainStyledAttributes != null) {
                        obtainStyledAttributes.recycle();
                    }
                    textArray = obtainStyledAttributes$ar$ds.mWrapped.getTextArray(0);
                    if (textArray != null) {
                        arrayAdapter = new ArrayAdapter(context, 17367048, textArray);
                        arrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                        setAdapter(arrayAdapter);
                    }
                    obtainStyledAttributes$ar$ds.recycle();
                    this.mPopupSet = true;
                    spinnerAdapter = this.mTempAdapter;
                    if (spinnerAdapter != null) {
                        setAdapter(spinnerAdapter);
                        this.mTempAdapter = null;
                    }
                    this.mBackgroundTintHelper.loadFromAttributes(attributeSet, R.attr.spinnerStyle);
                } catch (Throwable th2) {
                    th = th2;
                    typedArray = obtainStyledAttributes;
                    if (typedArray != null) {
                        typedArray.recycle();
                    }
                    throw th;
                }
            }
        } catch (Throwable e3) {
            e = e3;
            obtainStyledAttributes = null;
            Log.i("AppCompatSpinner", "Could not read android:spinnerMode", e);
            if (obtainStyledAttributes != null) {
                obtainStyledAttributes.recycle();
            }
            textArray = obtainStyledAttributes$ar$ds.mWrapped.getTextArray(0);
            if (textArray != null) {
                arrayAdapter = new ArrayAdapter(context, 17367048, textArray);
                arrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                setAdapter(arrayAdapter);
            }
            obtainStyledAttributes$ar$ds.recycle();
            this.mPopupSet = true;
            spinnerAdapter = this.mTempAdapter;
            if (spinnerAdapter != null) {
                setAdapter(spinnerAdapter);
                this.mTempAdapter = null;
            }
            this.mBackgroundTintHelper.loadFromAttributes(attributeSet, R.attr.spinnerStyle);
        } catch (Throwable th3) {
            th = th3;
            if (typedArray != null) {
                typedArray.recycle();
            }
            throw th;
        }
        textArray = obtainStyledAttributes$ar$ds.mWrapped.getTextArray(0);
        if (textArray != null) {
            arrayAdapter = new ArrayAdapter(context, 17367048, textArray);
            arrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
            setAdapter(arrayAdapter);
        }
        obtainStyledAttributes$ar$ds.recycle();
        this.mPopupSet = true;
        spinnerAdapter = this.mTempAdapter;
        if (spinnerAdapter != null) {
            setAdapter(spinnerAdapter);
            this.mTempAdapter = null;
        }
        this.mBackgroundTintHelper.loadFromAttributes(attributeSet, R.attr.spinnerStyle);
    }

    public final void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (this.mPopupSet) {
            super.setAdapter(spinnerAdapter);
            if (this.mPopup != null) {
                Context context = this.mPopupContext;
                if (context == null) {
                    context = getContext();
                }
                this.mPopup.setAdapter(new DropDownAdapter(spinnerAdapter, context.getTheme()));
            }
            return;
        }
        this.mTempAdapter = spinnerAdapter;
    }
}
