package android.support.p002v7.widget;

import android.support.p000v4.util.Pools$SimplePool;
import android.support.p002v7.widget.RecyclerView.ItemAnimator.ItemHolderInfo;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import androidx.collection.LongSparseArray;
import androidx.collection.SimpleArrayMap;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ViewInfoStore */
final class ViewInfoStore {
    final SimpleArrayMap mLayoutHolderMap = new SimpleArrayMap();
    final LongSparseArray mOldChangedHolders = new LongSparseArray();

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ViewInfoStore$InfoRecord */
    final class InfoRecord {
        static final Pools$SimplePool sPool$ar$class_merging = new Pools$SimplePool(20);
        int flags;
        ItemHolderInfo postInfo;
        ItemHolderInfo preInfo;

        private InfoRecord() {
        }

        static void drainCache() {
            do {
            } while (sPool$ar$class_merging.acquire() != null);
        }

        static InfoRecord obtain() {
            InfoRecord infoRecord = (InfoRecord) sPool$ar$class_merging.acquire();
            return infoRecord == null ? new InfoRecord() : infoRecord;
        }

        static void recycle(InfoRecord infoRecord) {
            infoRecord.flags = 0;
            infoRecord.preInfo = null;
            infoRecord.postInfo = null;
            sPool$ar$class_merging.release(infoRecord);
        }
    }

    final void addToDisappearedInLayout(ViewHolder viewHolder) {
        InfoRecord infoRecord = (InfoRecord) this.mLayoutHolderMap.get(viewHolder);
        if (infoRecord == null) {
            infoRecord = InfoRecord.obtain();
            this.mLayoutHolderMap.put(viewHolder, infoRecord);
        }
        infoRecord.flags |= 1;
    }

    final void addToOldChangeHolders(long j, ViewHolder viewHolder) {
        this.mOldChangedHolders.put(j, viewHolder);
    }

    final void addToPostLayout(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo) {
        InfoRecord infoRecord = (InfoRecord) this.mLayoutHolderMap.get(viewHolder);
        if (infoRecord == null) {
            infoRecord = InfoRecord.obtain();
            this.mLayoutHolderMap.put(viewHolder, infoRecord);
        }
        infoRecord.postInfo = itemHolderInfo;
        infoRecord.flags |= 8;
    }

    final void addToPreLayout(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo) {
        InfoRecord infoRecord = (InfoRecord) this.mLayoutHolderMap.get(viewHolder);
        if (infoRecord == null) {
            infoRecord = InfoRecord.obtain();
            this.mLayoutHolderMap.put(viewHolder, infoRecord);
        }
        infoRecord.preInfo = itemHolderInfo;
        infoRecord.flags |= 4;
    }

    final void clear() {
        this.mLayoutHolderMap.clear();
        this.mOldChangedHolders.clear();
    }

    final boolean isDisappearing(ViewHolder viewHolder) {
        InfoRecord infoRecord = (InfoRecord) this.mLayoutHolderMap.get(viewHolder);
        return (infoRecord == null || (infoRecord.flags & 1) == 0) ? false : true;
    }

    public final ItemHolderInfo popFromLayoutStep(ViewHolder viewHolder, int i) {
        int indexOfKey = this.mLayoutHolderMap.indexOfKey(viewHolder);
        if (indexOfKey < 0) {
            return null;
        }
        InfoRecord infoRecord = (InfoRecord) this.mLayoutHolderMap.valueAt(indexOfKey);
        if (infoRecord != null) {
            int i2 = infoRecord.flags;
            if ((i2 & i) != 0) {
                ItemHolderInfo itemHolderInfo;
                int i3 = (i ^ -1) & i2;
                infoRecord.flags = i3;
                if (i == 4) {
                    itemHolderInfo = infoRecord.preInfo;
                } else if (i == 8) {
                    itemHolderInfo = infoRecord.postInfo;
                } else {
                    throw new IllegalArgumentException("Must provide flag PRE or POST");
                }
                if ((i3 & 12) == 0) {
                    this.mLayoutHolderMap.removeAt(indexOfKey);
                    InfoRecord.recycle(infoRecord);
                }
                return itemHolderInfo;
            }
        }
        return null;
    }

    final void removeFromDisappearedInLayout(ViewHolder viewHolder) {
        InfoRecord infoRecord = (InfoRecord) this.mLayoutHolderMap.get(viewHolder);
        if (infoRecord != null) {
            infoRecord.flags &= -2;
        }
    }

    final void removeViewHolder(ViewHolder viewHolder) {
        InfoRecord infoRecord;
        for (int size = this.mOldChangedHolders.size() - 1; size >= 0; size--) {
            if (viewHolder == this.mOldChangedHolders.valueAt(size)) {
                LongSparseArray longSparseArray = this.mOldChangedHolders;
                if (longSparseArray.mValues[size] != LongSparseArray.DELETED) {
                    longSparseArray.mValues[size] = LongSparseArray.DELETED;
                    longSparseArray.mGarbage = true;
                }
                infoRecord = (InfoRecord) this.mLayoutHolderMap.remove(viewHolder);
                if (infoRecord != null) {
                    InfoRecord.recycle(infoRecord);
                }
            }
        }
        infoRecord = (InfoRecord) this.mLayoutHolderMap.remove(viewHolder);
        if (infoRecord != null) {
            InfoRecord.recycle(infoRecord);
        }
    }
}
