package android.support.p002v7.widget;

import android.util.SparseArray;
import android.util.SparseIntArray;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ViewTypeStorage$IsolatedViewTypeStorage */
public final class ViewTypeStorage$IsolatedViewTypeStorage {
    final SparseArray mGlobalTypeToWrapper = new SparseArray();
    int mNextViewType = 0;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ViewTypeStorage$IsolatedViewTypeStorage$WrapperViewTypeLookup */
    final class WrapperViewTypeLookup {
        public final SparseIntArray mGlobalToLocalMapping = new SparseIntArray(1);
        public final SparseIntArray mLocalToGlobalMapping = new SparseIntArray(1);
        final NestedAdapterWrapper mWrapper;

        public WrapperViewTypeLookup(NestedAdapterWrapper nestedAdapterWrapper) {
            this.mWrapper = nestedAdapterWrapper;
        }
    }
}
