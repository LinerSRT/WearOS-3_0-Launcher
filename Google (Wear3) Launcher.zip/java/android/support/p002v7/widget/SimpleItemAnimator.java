package android.support.p002v7.widget;

import android.support.p002v7.widget.RecyclerView.ItemAnimator;
import android.support.p002v7.widget.RecyclerView.ItemAnimator.ItemHolderInfo;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.SimpleItemAnimator */
public abstract class SimpleItemAnimator extends ItemAnimator {
    public boolean mSupportsChangeAnimations = true;

    public abstract boolean animateAdd(ViewHolder viewHolder);

    public final boolean animateAppearance(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2) {
        if (itemHolderInfo != null) {
            int i = itemHolderInfo.left;
            int i2 = itemHolderInfo2.left;
            if (!(i == i2 && itemHolderInfo.top == itemHolderInfo2.top)) {
                return animateMove(viewHolder, i, itemHolderInfo.top, i2, itemHolderInfo2.top);
            }
        }
        return animateAdd(viewHolder);
    }

    public abstract boolean animateChange(ViewHolder viewHolder, ViewHolder viewHolder2, int i, int i2, int i3, int i4);

    public final boolean animateChange(ViewHolder viewHolder, ViewHolder viewHolder2, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2) {
        int i;
        int i2;
        int i3 = itemHolderInfo.left;
        int i4 = itemHolderInfo.top;
        if (viewHolder2.shouldIgnore()) {
            int i5 = itemHolderInfo.left;
            i = itemHolderInfo.top;
            i2 = i5;
        } else {
            i2 = itemHolderInfo2.left;
            i = itemHolderInfo2.top;
        }
        return animateChange(viewHolder, viewHolder2, i3, i4, i2, i);
    }

    public final boolean animateDisappearance(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2) {
        int left;
        int top;
        int i = itemHolderInfo.left;
        int i2 = itemHolderInfo.top;
        View view = viewHolder.itemView;
        if (itemHolderInfo2 == null) {
            left = view.getLeft();
        } else {
            left = itemHolderInfo2.left;
        }
        if (itemHolderInfo2 == null) {
            top = view.getTop();
        } else {
            top = itemHolderInfo2.top;
        }
        if (viewHolder.isRemoved() || (i == left && i2 == top)) {
            return animateRemove(viewHolder);
        }
        view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
        return animateMove(viewHolder, i, i2, left, top);
    }

    public abstract boolean animateMove(ViewHolder viewHolder, int i, int i2, int i3, int i4);

    public final boolean animatePersistence(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2) {
        int i = itemHolderInfo.left;
        int i2 = itemHolderInfo2.left;
        if (i == i2) {
            if (itemHolderInfo.top == itemHolderInfo2.top) {
                dispatchAnimationFinished(viewHolder);
                return false;
            }
        }
        return animateMove(viewHolder, i, itemHolderInfo.top, i2, itemHolderInfo2.top);
    }

    public abstract boolean animateRemove(ViewHolder viewHolder);

    public final boolean canReuseUpdatedViewHolder(ViewHolder viewHolder) {
        if (this.mSupportsChangeAnimations) {
            if (!viewHolder.isInvalid()) {
                return false;
            }
        }
        return true;
    }
}
