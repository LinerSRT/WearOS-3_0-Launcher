package android.support.p002v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Paint.FontMetricsInt;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.LocaleList;
import android.support.p000v4.util.Preconditions;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.widget.TextViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatTextHelper */
final class AppCompatTextHelper {
    public boolean mAsyncFontPending;
    private final AppCompatTextViewAutoSizeHelper mAutoSizeTextHelper;
    private TintInfo mDrawableBottomTint;
    private TintInfo mDrawableEndTint;
    private TintInfo mDrawableLeftTint;
    private TintInfo mDrawableRightTint;
    private TintInfo mDrawableStartTint;
    private TintInfo mDrawableTopTint;
    public Typeface mFontTypeface;
    private int mFontWeight = -1;
    public int mStyle = 0;
    private final TextView mView;

    /* renamed from: android.support.v7.widget.AppCompatTextHelper$2 */
    final class C00942 implements Runnable {
        final /* synthetic */ int val$style;
        final /* synthetic */ TextView val$textView;
        final /* synthetic */ Typeface val$typeface;

        public C00942(TextView textView, Typeface typeface, int i) {
            this.val$textView = textView;
            this.val$typeface = typeface;
            this.val$style = i;
        }

        public final void run() {
            this.val$textView.setTypeface(this.val$typeface, this.val$style);
        }
    }

    public AppCompatTextHelper(TextView textView) {
        this.mView = textView;
        this.mAutoSizeTextHelper = new AppCompatTextViewAutoSizeHelper(textView);
    }

    private final void applyCompoundDrawableTint(Drawable drawable, TintInfo tintInfo) {
        if (drawable != null && tintInfo != null) {
            ResourceManagerInternal.tintDrawable(drawable, tintInfo, this.mView.getDrawableState());
        }
    }

    private static TintInfo createTintInfo(Context context, AppCompatDrawableManager appCompatDrawableManager, int i) {
        ColorStateList tintList = appCompatDrawableManager.getTintList(context, i);
        if (tintList == null) {
            return null;
        }
        TintInfo tintInfo = new TintInfo();
        tintInfo.mHasTintList = true;
        tintInfo.mTintList = tintList;
        return tintInfo;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void updateTypefaceAndStyle(android.content.Context r10, android.support.p002v7.widget.TintTypedArray r11) {
        /*
        r9 = this;
        r0 = android.support.p002v7.appcompat.R$styleable.ActionBar;
        r0 = r9.mStyle;
        r1 = 2;
        r0 = r11.getInt(r1, r0);
        r9.mStyle = r0;
        r0 = 14;
        r2 = -1;
        r0 = r11.getInt(r0, r2);
        r9.mFontWeight = r0;
        if (r0 == r2) goto L_0x001b;
    L_0x0016:
        r0 = r9.mStyle;
        r0 = r0 & r1;
        r9.mStyle = r0;
    L_0x001b:
        r0 = 10;
        r3 = r11.hasValue(r0);
        r4 = 15;
        r5 = 0;
        r6 = 1;
        if (r3 != 0) goto L_0x004b;
    L_0x0027:
        r3 = r11.hasValue(r4);
        if (r3 == 0) goto L_0x002e;
    L_0x002d:
        goto L_0x004b;
        r10 = r11.hasValue(r6);
        if (r10 == 0) goto L_0x004a;
    L_0x0035:
        r9.mAsyncFontPending = r5;
        r10 = r11.getInt(r6, r6);
        switch(r10) {
            case 1: goto L_0x0047;
            case 2: goto L_0x0044;
            case 3: goto L_0x003f;
            default: goto L_0x003e;
        };
    L_0x003e:
        goto L_0x004a;
    L_0x003f:
        r10 = android.graphics.Typeface.MONOSPACE;
    L_0x0041:
        r9.mFontTypeface = r10;
        return;
    L_0x0044:
        r10 = android.graphics.Typeface.SERIF;
        goto L_0x0041;
    L_0x0047:
        r10 = android.graphics.Typeface.SANS_SERIF;
        goto L_0x0041;
    L_0x004a:
        return;
    L_0x004b:
        r3 = 0;
        r9.mFontTypeface = r3;
        r7 = r11.hasValue(r4);
        if (r6 == r7) goto L_0x0055;
    L_0x0054:
        goto L_0x0057;
    L_0x0055:
        r0 = 15;
    L_0x0057:
        r4 = r9.mFontWeight;
        r7 = r9.mStyle;
        r10 = r10.isRestricted();
        if (r10 != 0) goto L_0x00b5;
    L_0x0061:
        r10 = new java.lang.ref.WeakReference;
        r8 = r9.mView;
        r10.<init>(r8);
        r8 = new android.support.v7.widget.AppCompatTextHelper$1;
        r8.<init>(r4, r7, r10);
        r10 = r9.mStyle;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r4 = r11.mWrapped;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r4 = r4.getResourceId(r0, r5);	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        if (r4 != 0) goto L_0x0078;
    L_0x0077:
        goto L_0x008b;
    L_0x0078:
        r3 = r11.mTypedValue;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        if (r3 != 0) goto L_0x0083;
    L_0x007c:
        r3 = new android.util.TypedValue;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r3.<init>();	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r11.mTypedValue = r3;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
    L_0x0083:
        r3 = r11.mContext;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r7 = r11.mTypedValue;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r3 = android.support.p000v4.content.res.ResourcesCompat.getFont(r3, r4, r7, r10, r8);	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
    L_0x008b:
        if (r3 == 0) goto L_0x00a8;
    L_0x008d:
        r10 = r9.mFontWeight;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        if (r10 == r2) goto L_0x00a6;
    L_0x0091:
        r10 = android.graphics.Typeface.create(r3, r5);	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r3 = r9.mFontWeight;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r4 = r9.mStyle;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r4 = r4 & r1;
        if (r4 == 0) goto L_0x009e;
    L_0x009c:
        r4 = 1;
        goto L_0x009f;
    L_0x009e:
        r4 = 0;
    L_0x009f:
        r10 = android.graphics.Typeface.create(r10, r3, r4);	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        r9.mFontTypeface = r10;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        goto L_0x00a8;
    L_0x00a6:
        r9.mFontTypeface = r3;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
    L_0x00a8:
        r10 = r9.mFontTypeface;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        if (r10 != 0) goto L_0x00ae;
    L_0x00ac:
        r10 = 1;
        goto L_0x00af;
    L_0x00ae:
        r10 = 0;
    L_0x00af:
        r9.mAsyncFontPending = r10;	 Catch:{ UnsupportedOperationException -> 0x00b4, NotFoundException -> 0x00b2 }
        goto L_0x00b5;
    L_0x00b2:
        r10 = move-exception;
        goto L_0x00b5;
    L_0x00b4:
        r10 = move-exception;
    L_0x00b5:
        r10 = r9.mFontTypeface;
        if (r10 != 0) goto L_0x00e0;
    L_0x00b9:
        r10 = r11.getString(r0);
        if (r10 == 0) goto L_0x00e0;
    L_0x00bf:
        r11 = r9.mFontWeight;
        if (r11 == r2) goto L_0x00d8;
    L_0x00c3:
        r10 = android.graphics.Typeface.create(r10, r5);
        r11 = r9.mFontWeight;
        r0 = r9.mStyle;
        r0 = r0 & r1;
        if (r0 == 0) goto L_0x00d0;
    L_0x00ce:
        r5 = 1;
        goto L_0x00d1;
    L_0x00d1:
        r10 = android.graphics.Typeface.create(r10, r11, r5);
        r9.mFontTypeface = r10;
        return;
    L_0x00d8:
        r11 = r9.mStyle;
        r10 = android.graphics.Typeface.create(r10, r11);
        r9.mFontTypeface = r10;
    L_0x00e0:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.AppCompatTextHelper.updateTypefaceAndStyle(android.content.Context, android.support.v7.widget.TintTypedArray):void");
    }

    final void applyCompoundDrawablesTints() {
        Drawable[] compoundDrawables;
        if (!(this.mDrawableLeftTint == null && this.mDrawableTopTint == null && this.mDrawableRightTint == null && this.mDrawableBottomTint == null)) {
            compoundDrawables = this.mView.getCompoundDrawables();
            applyCompoundDrawableTint(compoundDrawables[0], this.mDrawableLeftTint);
            applyCompoundDrawableTint(compoundDrawables[1], this.mDrawableTopTint);
            applyCompoundDrawableTint(compoundDrawables[2], this.mDrawableRightTint);
            applyCompoundDrawableTint(compoundDrawables[3], this.mDrawableBottomTint);
        }
        if (this.mDrawableStartTint == null) {
            if (this.mDrawableEndTint == null) {
                return;
            }
        }
        compoundDrawables = this.mView.getCompoundDrawablesRelative();
        applyCompoundDrawableTint(compoundDrawables[0], this.mDrawableStartTint);
        applyCompoundDrawableTint(compoundDrawables[2], this.mDrawableEndTint);
    }

    final void loadFromAttributes(AttributeSet attributeSet, int i) {
        TintTypedArray obtainStyledAttributes;
        boolean z;
        Object obj;
        String string;
        String string2;
        String string3;
        int resourceId;
        int i2;
        Drawable drawable;
        Drawable drawable2;
        Drawable drawable3;
        Drawable drawable4;
        Drawable drawable5;
        Drawable drawable6;
        TextView textView;
        FontMetricsInt fontMetricsInt;
        AttributeSet attributeSet2 = attributeSet;
        int i3 = i;
        Context context = this.mView.getContext();
        AppCompatDrawableManager appCompatDrawableManager = AppCompatDrawableManager.get();
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(context, attributeSet2, R$styleable.AppCompatTextHelper, i3);
        View view = this.mView;
        ViewCompat.saveAttributeDataForStyleable(view, view.getContext(), R$styleable.AppCompatTextHelper, attributeSet, obtainStyledAttributes$ar$ds.mWrapped, i, 0);
        int resourceId2 = obtainStyledAttributes$ar$ds.getResourceId(0, -1);
        if (obtainStyledAttributes$ar$ds.hasValue(3)) {
            r0.mDrawableLeftTint = AppCompatTextHelper.createTintInfo(context, appCompatDrawableManager, obtainStyledAttributes$ar$ds.getResourceId(3, 0));
        }
        if (obtainStyledAttributes$ar$ds.hasValue(1)) {
            r0.mDrawableTopTint = AppCompatTextHelper.createTintInfo(context, appCompatDrawableManager, obtainStyledAttributes$ar$ds.getResourceId(1, 0));
        }
        if (obtainStyledAttributes$ar$ds.hasValue(4)) {
            r0.mDrawableRightTint = AppCompatTextHelper.createTintInfo(context, appCompatDrawableManager, obtainStyledAttributes$ar$ds.getResourceId(4, 0));
        }
        if (obtainStyledAttributes$ar$ds.hasValue(2)) {
            r0.mDrawableBottomTint = AppCompatTextHelper.createTintInfo(context, appCompatDrawableManager, obtainStyledAttributes$ar$ds.getResourceId(2, 0));
        }
        if (obtainStyledAttributes$ar$ds.hasValue(5)) {
            r0.mDrawableStartTint = AppCompatTextHelper.createTintInfo(context, appCompatDrawableManager, obtainStyledAttributes$ar$ds.getResourceId(5, 0));
        }
        if (obtainStyledAttributes$ar$ds.hasValue(6)) {
            r0.mDrawableEndTint = AppCompatTextHelper.createTintInfo(context, appCompatDrawableManager, obtainStyledAttributes$ar$ds.getResourceId(6, 0));
        }
        obtainStyledAttributes$ar$ds.recycle();
        boolean z2 = r0.mView.getTransformationMethod() instanceof PasswordTransformationMethod;
        if (resourceId2 != -1) {
            obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, resourceId2, R$styleable.TextAppearance);
            if (z2 || !obtainStyledAttributes.hasValue(17)) {
                z = false;
                obj = null;
            } else {
                z = obtainStyledAttributes.getBoolean(17, false);
                obj = 1;
            }
            updateTypefaceAndStyle(context, obtainStyledAttributes);
            string = obtainStyledAttributes.hasValue(18) ? obtainStyledAttributes.getString(18) : null;
            string2 = obtainStyledAttributes.hasValue(16) ? obtainStyledAttributes.getString(16) : null;
            obtainStyledAttributes.recycle();
        } else {
            z = false;
            obj = null;
            string = null;
            string2 = null;
        }
        obtainStyledAttributes = TintTypedArray.obtainStyledAttributes$ar$ds(context, attributeSet2, R$styleable.TextAppearance, i3);
        if (!z2 && obtainStyledAttributes.hasValue(17)) {
            z = obtainStyledAttributes.getBoolean(17, false);
            obj = 1;
        }
        if (obtainStyledAttributes.hasValue(18)) {
            string = obtainStyledAttributes.getString(18);
        }
        if (obtainStyledAttributes.hasValue(16)) {
            string3 = obtainStyledAttributes.getString(16);
        } else {
            string3 = string2;
        }
        if (obtainStyledAttributes.hasValue(0) && obtainStyledAttributes.getDimensionPixelSize(0, -1) == 0) {
            r0.mView.setTextSize(0, 0.0f);
        }
        updateTypefaceAndStyle(context, obtainStyledAttributes);
        obtainStyledAttributes.recycle();
        if (!(z2 || r19 == null)) {
            setAllCaps(z);
        }
        Typeface typeface = r0.mFontTypeface;
        if (typeface != null) {
            if (r0.mFontWeight == -1) {
                r0.mView.setTypeface(typeface, r0.mStyle);
            } else {
                r0.mView.setTypeface(typeface);
            }
        }
        if (string3 != null) {
            r0.mView.setFontVariationSettings(string3);
        }
        if (string != null) {
            r0.mView.setTextLocales(LocaleList.forLanguageTags(string));
        }
        AppCompatTextViewAutoSizeHelper appCompatTextViewAutoSizeHelper = r0.mAutoSizeTextHelper;
        TypedArray obtainStyledAttributes2 = appCompatTextViewAutoSizeHelper.mContext.obtainStyledAttributes(attributeSet2, R$styleable.AppCompatTextView, i3, 0);
        view = appCompatTextViewAutoSizeHelper.mTextView;
        TypedArray typedArray = obtainStyledAttributes2;
        AppCompatTextViewAutoSizeHelper appCompatTextViewAutoSizeHelper2 = appCompatTextViewAutoSizeHelper;
        ViewCompat.saveAttributeDataForStyleable(view, view.getContext(), R$styleable.AppCompatTextView, attributeSet, typedArray, i, 0);
        TypedArray typedArray2 = typedArray;
        if (typedArray2.hasValue(5)) {
            appCompatTextViewAutoSizeHelper2.mAutoSizeTextType = typedArray2.getInt(5, 0);
        }
        float dimension = typedArray2.hasValue(4) ? typedArray2.getDimension(4, -1.0f) : -1.0f;
        float dimension2 = typedArray2.hasValue(2) ? typedArray2.getDimension(2, -1.0f) : -1.0f;
        float dimension3 = typedArray2.hasValue(1) ? typedArray2.getDimension(1, -1.0f) : -1.0f;
        if (typedArray2.hasValue(3)) {
            resourceId = typedArray2.getResourceId(3, 0);
            if (resourceId > 0) {
                TypedArray obtainTypedArray = typedArray2.getResources().obtainTypedArray(resourceId);
                resourceId = obtainTypedArray.length();
                int[] iArr = new int[resourceId];
                if (resourceId > 0) {
                    for (int i4 = 0; i4 < resourceId; i4++) {
                        iArr[i4] = obtainTypedArray.getDimensionPixelSize(i4, -1);
                    }
                    appCompatTextViewAutoSizeHelper2.mAutoSizeTextSizesInPx = AppCompatTextViewAutoSizeHelper.cleanupAutoSizePresetSizes$ar$ds(iArr);
                    int[] iArr2 = appCompatTextViewAutoSizeHelper2.mAutoSizeTextSizesInPx;
                    resourceId = iArr2.length;
                    boolean z3 = resourceId > 0;
                    appCompatTextViewAutoSizeHelper2.mHasPresetAutoSizeValues = z3;
                    if (z3) {
                        appCompatTextViewAutoSizeHelper2.mAutoSizeTextType = 1;
                        appCompatTextViewAutoSizeHelper2.mAutoSizeMinTextSizeInPx = (float) iArr2[0];
                        appCompatTextViewAutoSizeHelper2.mAutoSizeMaxTextSizeInPx = (float) iArr2[resourceId - 1];
                        appCompatTextViewAutoSizeHelper2.mAutoSizeStepGranularityInPx = -1.0f;
                    }
                }
                obtainTypedArray.recycle();
            }
        }
        typedArray2.recycle();
        if (!appCompatTextViewAutoSizeHelper2.supportsAutoSizeText()) {
            appCompatTextViewAutoSizeHelper2.mAutoSizeTextType = 0;
        } else if (appCompatTextViewAutoSizeHelper2.mAutoSizeTextType == 1) {
            if (!appCompatTextViewAutoSizeHelper2.mHasPresetAutoSizeValues) {
                DisplayMetrics displayMetrics = appCompatTextViewAutoSizeHelper2.mContext.getResources().getDisplayMetrics();
                if (dimension2 == -1.0f) {
                    i2 = 2;
                    dimension2 = TypedValue.applyDimension(2, 12.0f, displayMetrics);
                } else {
                    i2 = 2;
                }
                if (dimension3 == -1.0f) {
                    dimension3 = TypedValue.applyDimension(i2, 112.0f, displayMetrics);
                }
                if (dimension == -1.0f) {
                    dimension = 1.0f;
                }
                String str = "px) is less or equal to (0px)";
                if (dimension2 <= 0.0f) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Minimum auto-size text size (");
                    stringBuilder.append(dimension2);
                    stringBuilder.append(str);
                    throw new IllegalArgumentException(stringBuilder.toString());
                } else if (dimension3 <= dimension2) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Maximum auto-size text size (");
                    stringBuilder2.append(dimension3);
                    stringBuilder2.append("px) is less or equal to minimum auto-size text size (");
                    stringBuilder2.append(dimension2);
                    stringBuilder2.append("px)");
                    throw new IllegalArgumentException(stringBuilder2.toString());
                } else if (dimension > 0.0f) {
                    appCompatTextViewAutoSizeHelper2.mAutoSizeTextType = 1;
                    appCompatTextViewAutoSizeHelper2.mAutoSizeMinTextSizeInPx = dimension2;
                    appCompatTextViewAutoSizeHelper2.mAutoSizeMaxTextSizeInPx = dimension3;
                    appCompatTextViewAutoSizeHelper2.mAutoSizeStepGranularityInPx = dimension;
                    appCompatTextViewAutoSizeHelper2.mHasPresetAutoSizeValues = false;
                } else {
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("The auto-size step granularity (");
                    stringBuilder3.append(dimension);
                    stringBuilder3.append(str);
                    throw new IllegalArgumentException(stringBuilder3.toString());
                }
            }
            if (appCompatTextViewAutoSizeHelper2.supportsAutoSizeText() && appCompatTextViewAutoSizeHelper2.mAutoSizeTextType == 1 && (!appCompatTextViewAutoSizeHelper2.mHasPresetAutoSizeValues || appCompatTextViewAutoSizeHelper2.mAutoSizeTextSizesInPx.length == 0)) {
                resourceId2 = ((int) Math.floor((double) ((appCompatTextViewAutoSizeHelper2.mAutoSizeMaxTextSizeInPx - appCompatTextViewAutoSizeHelper2.mAutoSizeMinTextSizeInPx) / appCompatTextViewAutoSizeHelper2.mAutoSizeStepGranularityInPx))) + 1;
                int[] iArr3 = new int[resourceId2];
                for (int i5 = 0; i5 < resourceId2; i5++) {
                    iArr3[i5] = Math.round(appCompatTextViewAutoSizeHelper2.mAutoSizeMinTextSizeInPx + (((float) i5) * appCompatTextViewAutoSizeHelper2.mAutoSizeStepGranularityInPx));
                }
                appCompatTextViewAutoSizeHelper2.mAutoSizeTextSizesInPx = AppCompatTextViewAutoSizeHelper.cleanupAutoSizePresetSizes$ar$ds(iArr3);
            }
        }
        AppCompatTextViewAutoSizeHelper appCompatTextViewAutoSizeHelper3 = r0.mAutoSizeTextHelper;
        if (appCompatTextViewAutoSizeHelper3.mAutoSizeTextType != 0) {
            int[] iArr4 = appCompatTextViewAutoSizeHelper3.mAutoSizeTextSizesInPx;
            if (iArr4.length > 0) {
                if (((float) r0.mView.getAutoSizeStepGranularity()) != -1.0f) {
                    r0.mView.setAutoSizeTextTypeUniformWithConfiguration(Math.round(r0.mAutoSizeTextHelper.mAutoSizeMinTextSizeInPx), Math.round(r0.mAutoSizeTextHelper.mAutoSizeMaxTextSizeInPx), Math.round(r0.mAutoSizeTextHelper.mAutoSizeStepGranularityInPx), 0);
                } else {
                    r0.mView.setAutoSizeTextTypeUniformWithPresetSizes(iArr4, 0);
                }
            }
        }
        obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, attributeSet2, R$styleable.AppCompatTextView);
        int resourceId3 = obtainStyledAttributes.getResourceId(8, -1);
        if (resourceId3 != -1) {
            drawable = appCompatDrawableManager.getDrawable(context, resourceId3);
        } else {
            drawable = null;
        }
        int resourceId4 = obtainStyledAttributes.getResourceId(13, -1);
        if (resourceId4 != -1) {
            drawable2 = appCompatDrawableManager.getDrawable(context, resourceId4);
        } else {
            drawable2 = null;
        }
        int resourceId5 = obtainStyledAttributes.getResourceId(9, -1);
        if (resourceId5 != -1) {
            drawable3 = appCompatDrawableManager.getDrawable(context, resourceId5);
        } else {
            drawable3 = null;
        }
        i2 = obtainStyledAttributes.getResourceId(6, -1);
        if (i2 != -1) {
            drawable4 = appCompatDrawableManager.getDrawable(context, i2);
        } else {
            drawable4 = null;
        }
        resourceId = obtainStyledAttributes.getResourceId(10, -1);
        if (resourceId != -1) {
            drawable5 = appCompatDrawableManager.getDrawable(context, resourceId);
        } else {
            drawable5 = null;
        }
        int resourceId6 = obtainStyledAttributes.getResourceId(7, -1);
        if (resourceId6 != -1) {
            drawable6 = appCompatDrawableManager.getDrawable(context, resourceId6);
        } else {
            drawable6 = null;
        }
        if (drawable5 == null) {
            if (drawable6 == null) {
                if (!(drawable == null && drawable2 == null && drawable3 == null && drawable4 == null)) {
                    Drawable[] compoundDrawablesRelative = r0.mView.getCompoundDrawablesRelative();
                    drawable5 = compoundDrawablesRelative[0];
                    if (drawable5 == null) {
                        if (compoundDrawablesRelative[2] == null) {
                            compoundDrawablesRelative = r0.mView.getCompoundDrawables();
                            TextView textView2 = r0.mView;
                            if (drawable == null) {
                                drawable = compoundDrawablesRelative[0];
                            }
                            if (drawable2 == null) {
                                drawable2 = compoundDrawablesRelative[1];
                            }
                            if (drawable3 == null) {
                                drawable3 = compoundDrawablesRelative[2];
                            }
                            if (drawable4 == null) {
                                drawable4 = compoundDrawablesRelative[3];
                            }
                            textView2.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
                        }
                    }
                    TextView textView3 = r0.mView;
                    if (drawable2 == null) {
                        drawable2 = compoundDrawablesRelative[1];
                    }
                    drawable3 = compoundDrawablesRelative[2];
                    if (drawable4 == null) {
                        drawable4 = compoundDrawablesRelative[3];
                    }
                    textView3.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable5, drawable2, drawable3, drawable4);
                }
                if (obtainStyledAttributes.hasValue(11)) {
                    r0.mView.setCompoundDrawableTintList(obtainStyledAttributes.getColorStateList(11));
                }
                if (obtainStyledAttributes.hasValue(12)) {
                    r0.mView.setCompoundDrawableTintMode(DrawableUtils.parseTintMode(obtainStyledAttributes.getInt(12, -1), null));
                }
                resourceId3 = obtainStyledAttributes.getDimensionPixelSize(14, -1);
                resourceId4 = obtainStyledAttributes.getDimensionPixelSize(17, -1);
                resourceId5 = obtainStyledAttributes.getDimensionPixelSize(18, -1);
                obtainStyledAttributes.recycle();
                if (resourceId3 != -1) {
                    textView = r0.mView;
                    Preconditions.checkArgumentNonnegative$ar$ds(resourceId3);
                    textView.setFirstBaselineToTopHeight(resourceId3);
                }
                if (resourceId4 != -1) {
                    textView = r0.mView;
                    Preconditions.checkArgumentNonnegative$ar$ds(resourceId4);
                    fontMetricsInt = textView.getPaint().getFontMetricsInt();
                    if (textView.getIncludeFontPadding()) {
                        resourceId3 = fontMetricsInt.descent;
                    } else {
                        resourceId3 = fontMetricsInt.bottom;
                    }
                    if (resourceId4 > Math.abs(resourceId3)) {
                        textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), resourceId4 - resourceId3);
                    }
                }
                if (resourceId5 != -1) {
                    TextViewCompat.setLineHeight(r0.mView, resourceId5);
                }
            }
        }
        Drawable[] compoundDrawablesRelative2 = r0.mView.getCompoundDrawablesRelative();
        TextView textView4 = r0.mView;
        if (drawable5 == null) {
            drawable5 = compoundDrawablesRelative2[0];
        }
        if (drawable2 == null) {
            drawable2 = compoundDrawablesRelative2[1];
        }
        if (drawable6 == null) {
            drawable6 = compoundDrawablesRelative2[2];
        }
        if (drawable4 == null) {
            drawable4 = compoundDrawablesRelative2[3];
        }
        textView4.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable5, drawable2, drawable6, drawable4);
        if (obtainStyledAttributes.hasValue(11)) {
            r0.mView.setCompoundDrawableTintList(obtainStyledAttributes.getColorStateList(11));
        }
        if (obtainStyledAttributes.hasValue(12)) {
            r0.mView.setCompoundDrawableTintMode(DrawableUtils.parseTintMode(obtainStyledAttributes.getInt(12, -1), null));
        }
        resourceId3 = obtainStyledAttributes.getDimensionPixelSize(14, -1);
        resourceId4 = obtainStyledAttributes.getDimensionPixelSize(17, -1);
        resourceId5 = obtainStyledAttributes.getDimensionPixelSize(18, -1);
        obtainStyledAttributes.recycle();
        if (resourceId3 != -1) {
            textView = r0.mView;
            Preconditions.checkArgumentNonnegative$ar$ds(resourceId3);
            textView.setFirstBaselineToTopHeight(resourceId3);
        }
        if (resourceId4 != -1) {
            textView = r0.mView;
            Preconditions.checkArgumentNonnegative$ar$ds(resourceId4);
            fontMetricsInt = textView.getPaint().getFontMetricsInt();
            if (textView.getIncludeFontPadding()) {
                resourceId3 = fontMetricsInt.descent;
            } else {
                resourceId3 = fontMetricsInt.bottom;
            }
            if (resourceId4 > Math.abs(resourceId3)) {
                textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), resourceId4 - resourceId3);
            }
        }
        if (resourceId5 != -1) {
            TextViewCompat.setLineHeight(r0.mView, resourceId5);
        }
    }

    final void onSetTextAppearance(Context context, int i) {
        TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, i, R$styleable.TextAppearance);
        if (obtainStyledAttributes.hasValue(17)) {
            setAllCaps(obtainStyledAttributes.getBoolean(17, false));
        }
        if (obtainStyledAttributes.hasValue(0) && obtainStyledAttributes.getDimensionPixelSize(0, -1) == 0) {
            this.mView.setTextSize(0, 0.0f);
        }
        updateTypefaceAndStyle(context, obtainStyledAttributes);
        if (obtainStyledAttributes.hasValue(16)) {
            String string = obtainStyledAttributes.getString(16);
            if (string != null) {
                this.mView.setFontVariationSettings(string);
            }
        }
        obtainStyledAttributes.recycle();
        Typeface typeface = this.mFontTypeface;
        if (typeface != null) {
            this.mView.setTypeface(typeface, this.mStyle);
        }
    }

    final void setAllCaps(boolean z) {
        this.mView.setAllCaps(z);
    }
}
