package android.support.p002v7.widget;

import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ViewBoundsCheck */
final class ViewBoundsCheck {
    final BoundFlags mBoundFlags = new BoundFlags();
    final Callback mCallback;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ViewBoundsCheck$BoundFlags */
    final class BoundFlags {
        int mBoundFlags = 0;
        int mChildEnd;
        int mChildStart;
        int mRvEnd;
        int mRvStart;

        static final int compare$ar$ds(int i, int i2) {
            return i > i2 ? 1 : i == i2 ? 2 : 4;
        }

        final void addFlags(int i) {
            this.mBoundFlags = i | this.mBoundFlags;
        }

        final boolean boundsMatch() {
            int i = this.mBoundFlags;
            if ((i & 7) != 0) {
                if ((i & BoundFlags.compare$ar$ds(this.mChildStart, this.mRvStart)) == 0) {
                    return false;
                }
            }
            i = this.mBoundFlags;
            if ((i & 112) != 0) {
                if ((i & (BoundFlags.compare$ar$ds(this.mChildStart, this.mRvEnd) << 4)) == 0) {
                    return false;
                }
            }
            i = this.mBoundFlags;
            if ((i & 1792) != 0) {
                if ((i & (BoundFlags.compare$ar$ds(this.mChildEnd, this.mRvStart) << 8)) == 0) {
                    return false;
                }
            }
            i = this.mBoundFlags;
            return (i & 28672) == 0 || (i & (BoundFlags.compare$ar$ds(this.mChildEnd, this.mRvEnd) << 12)) != 0;
        }

        final void resetFlags() {
            this.mBoundFlags = 0;
        }

        final void setBounds(int i, int i2, int i3, int i4) {
            this.mRvStart = i;
            this.mRvEnd = i2;
            this.mChildStart = i3;
            this.mChildEnd = i4;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ViewBoundsCheck$Callback */
    interface Callback {
        View getChildAt(int i);

        int getChildEnd(View view);

        int getChildStart(View view);

        int getParentEnd();

        int getParentStart();
    }

    public ViewBoundsCheck(Callback callback) {
        this.mCallback = callback;
    }

    final View findOneViewWithinBoundFlags(int i, int i2, int i3, int i4) {
        int i5;
        int parentStart = this.mCallback.getParentStart();
        int parentEnd = this.mCallback.getParentEnd();
        if (i2 > i) {
            i5 = 1;
        } else {
            i5 = -1;
        }
        View view = null;
        while (i != i2) {
            View childAt = this.mCallback.getChildAt(i);
            this.mBoundFlags.setBounds(parentStart, parentEnd, this.mCallback.getChildStart(childAt), this.mCallback.getChildEnd(childAt));
            this.mBoundFlags.resetFlags();
            this.mBoundFlags.addFlags(i3);
            if (this.mBoundFlags.boundsMatch()) {
                return childAt;
            }
            if (i4 != 0) {
                this.mBoundFlags.resetFlags();
                this.mBoundFlags.addFlags(i4);
                if (this.mBoundFlags.boundsMatch()) {
                    view = childAt;
                }
            }
            i += i5;
        }
        return view;
    }

    final boolean isViewWithinBoundFlags$ar$ds(View view) {
        this.mBoundFlags.setBounds(this.mCallback.getParentStart(), this.mCallback.getParentEnd(), this.mCallback.getChildStart(view), this.mCallback.getChildEnd(view));
        this.mBoundFlags.resetFlags();
        this.mBoundFlags.addFlags(24579);
        return this.mBoundFlags.boundsMatch();
    }
}
