package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.CollectionItemInfoCompat;
import android.support.p002v7.widget.LinearLayoutManager.AnchorInfo;
import android.support.p002v7.widget.LinearLayoutManager.LayoutChunkResult;
import android.support.p002v7.widget.LinearLayoutManager.LayoutState;
import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.LayoutManager.LayoutPrefetchRegistry;
import android.support.p002v7.widget.RecyclerView.LayoutParams;
import android.support.p002v7.widget.RecyclerView.Recycler;
import android.support.p002v7.widget.RecyclerView.State;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.GridLayoutManager */
public class GridLayoutManager extends LinearLayoutManager {
    int[] mCachedBorders;
    final Rect mDecorInsets = new Rect();
    boolean mPendingSpanCountChange = false;
    final SparseIntArray mPreLayoutSpanIndexCache = new SparseIntArray();
    final SparseIntArray mPreLayoutSpanSizeCache = new SparseIntArray();
    View[] mSet;
    int mSpanCount = -1;
    public SpanSizeLookup mSpanSizeLookup = new DefaultSpanSizeLookup();

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.GridLayoutManager$DefaultSpanSizeLookup */
    public final class DefaultSpanSizeLookup extends SpanSizeLookup {
        public final int getSpanIndex(int i, int i2) {
            return i % i2;
        }

        public final int getSpanSize(int i) {
            return 1;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.GridLayoutManager$LayoutParams */
    public final class LayoutParams extends android.support.p002v7.widget.RecyclerView.LayoutParams {
        int mSpanIndex = -1;
        int mSpanSize = 0;

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.GridLayoutManager$SpanSizeLookup */
    public abstract class SpanSizeLookup {
        final SparseIntArray mSpanGroupIndexCache = new SparseIntArray();
        final SparseIntArray mSpanIndexCache = new SparseIntArray();

        public final int getSpanGroupIndex(int i, int i2) {
            int spanSize = getSpanSize(i);
            int i3 = 0;
            int i4 = 0;
            for (int i5 = 0; i5 < i; i5++) {
                int spanSize2 = getSpanSize(i5);
                i3 += spanSize2;
                if (i3 == i2) {
                    i4++;
                    i3 = 0;
                } else if (i3 > i2) {
                    i4++;
                    i3 = spanSize2;
                }
            }
            return i3 + spanSize > i2 ? i4 + 1 : i4;
        }

        public int getSpanIndex(int i, int i2) {
            int spanSize = getSpanSize(i);
            if (spanSize != i2) {
                int i3 = 0;
                for (int i4 = 0; i4 < i; i4++) {
                    int spanSize2 = getSpanSize(i4);
                    i3 += spanSize2;
                    if (i3 == i2) {
                        i3 = 0;
                    } else if (i3 > i2) {
                        i3 = spanSize2;
                    }
                }
                if (spanSize + i3 <= i2) {
                    return i3;
                }
            }
            return 0;
        }

        public abstract int getSpanSize(int i);

        public final void invalidateSpanGroupIndexCache() {
            this.mSpanGroupIndexCache.clear();
        }

        public final void invalidateSpanIndexCache() {
            this.mSpanIndexCache.clear();
        }
    }

    public GridLayoutManager(Context context, int i) {
        super(context, 1, false);
        setSpanCount(i);
    }

    private final void ensureViewSet() {
        View[] viewArr = this.mSet;
        if (viewArr != null) {
            if (viewArr.length == this.mSpanCount) {
                return;
            }
        }
        this.mSet = new View[this.mSpanCount];
    }

    private final int getSpanGroupIndex(Recycler recycler, State state, int i) {
        if (!state.mInPreLayout) {
            return this.mSpanSizeLookup.getSpanGroupIndex(i, this.mSpanCount);
        }
        int convertPreLayoutPositionToPostLayout = recycler.convertPreLayoutPositionToPostLayout(i);
        if (convertPreLayoutPositionToPostLayout != -1) {
            return this.mSpanSizeLookup.getSpanGroupIndex(convertPreLayoutPositionToPostLayout, this.mSpanCount);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find span size for pre layout position. ");
        stringBuilder.append(i);
        Log.w("GridLayoutManager", stringBuilder.toString());
        return 0;
    }

    private final int getSpanIndex(Recycler recycler, State state, int i) {
        if (!state.mInPreLayout) {
            return this.mSpanSizeLookup.getSpanIndex(i, this.mSpanCount);
        }
        int i2 = this.mPreLayoutSpanIndexCache.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int convertPreLayoutPositionToPostLayout = recycler.convertPreLayoutPositionToPostLayout(i);
        if (convertPreLayoutPositionToPostLayout != -1) {
            return this.mSpanSizeLookup.getSpanIndex(convertPreLayoutPositionToPostLayout, this.mSpanCount);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
        stringBuilder.append(i);
        Log.w("GridLayoutManager", stringBuilder.toString());
        return 0;
    }

    private final int getSpanSize(Recycler recycler, State state, int i) {
        if (!state.mInPreLayout) {
            return this.mSpanSizeLookup.getSpanSize(i);
        }
        int i2 = this.mPreLayoutSpanSizeCache.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int convertPreLayoutPositionToPostLayout = recycler.convertPreLayoutPositionToPostLayout(i);
        if (convertPreLayoutPositionToPostLayout != -1) {
            return this.mSpanSizeLookup.getSpanSize(convertPreLayoutPositionToPostLayout);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
        stringBuilder.append(i);
        Log.w("GridLayoutManager", stringBuilder.toString());
        return 1;
    }

    private final void measureChild(View view, int i, boolean z) {
        int childMeasureSpec;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        Rect rect = layoutParams.mDecorInsets;
        int i2 = ((rect.top + rect.bottom) + layoutParams.topMargin) + layoutParams.bottomMargin;
        int i3 = ((rect.left + rect.right) + layoutParams.leftMargin) + layoutParams.rightMargin;
        int spaceForSpanRange = getSpaceForSpanRange(layoutParams.mSpanIndex, layoutParams.mSpanSize);
        if (this.mOrientation == 1) {
            i = LayoutManager.getChildMeasureSpec(spaceForSpanRange, i, i3, layoutParams.width, false);
            childMeasureSpec = LayoutManager.getChildMeasureSpec(this.mOrientationHelper.getTotalSpace(), getHeightMode(), i2, layoutParams.height, true);
        } else {
            i = LayoutManager.getChildMeasureSpec(spaceForSpanRange, i, i2, layoutParams.height, false);
            int childMeasureSpec2 = LayoutManager.getChildMeasureSpec(this.mOrientationHelper.getTotalSpace(), getWidthMode(), i3, layoutParams.width, true);
            childMeasureSpec = i;
            i = childMeasureSpec2;
        }
        measureChildWithDecorationsAndMargin(view, i, childMeasureSpec, z);
    }

    private final void measureChildWithDecorationsAndMargin(View view, int i, int i2, boolean z) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (z) {
            z = shouldReMeasureChild(view, i, i2, layoutParams);
        } else {
            z = shouldMeasureChild(view, i, i2, layoutParams);
        }
        if (z) {
            view.measure(i, i2);
        }
    }

    private final void updateMeasurements() {
        int width;
        if (getOrientation() == 1) {
            width = (getWidth() - getPaddingRight()) - getPaddingLeft();
        } else {
            width = (getHeight() - getPaddingBottom()) - getPaddingTop();
        }
        calculateItemBorders(width);
    }

    public final boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public final void collectPrefetchPositionsForLayoutState(State state, LayoutState layoutState, LayoutPrefetchRegistry layoutPrefetchRegistry) {
        int i = this.mSpanCount;
        for (int i2 = 0; i2 < this.mSpanCount && layoutState.hasMore(state) && i > 0; i2++) {
            int i3 = layoutState.mCurrentPosition;
            layoutPrefetchRegistry.addPosition(i3, Math.max(0, layoutState.mScrollingOffset));
            i -= this.mSpanSizeLookup.getSpanSize(i3);
            layoutState.mCurrentPosition += layoutState.mItemDirection;
        }
    }

    public final View findReferenceChild(Recycler recycler, State state, boolean z, boolean z2) {
        int i;
        int childCount = getChildCount();
        int i2 = -1;
        if (z2) {
            childCount = getChildCount() - 1;
            i = -1;
        } else {
            i2 = childCount;
            childCount = 0;
            i = 1;
        }
        int itemCount = state.getItemCount();
        ensureLayoutState();
        int startAfterPadding = this.mOrientationHelper.getStartAfterPadding();
        int endAfterPadding = this.mOrientationHelper.getEndAfterPadding();
        View view = null;
        View view2 = null;
        for (childCount = 
/*
Method generation error in method: android.support.v7.widget.GridLayoutManager.findReferenceChild(android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State, boolean, boolean):android.view.View, dex: classes.dex
jadx.core.utils.exceptions.CodegenException: Error generate insn: PHI: (r11_5 'childCount' int) = (r11_3 'childCount' int), (r11_4 'childCount' int) binds: {(r11_3 'childCount' int)=B:2:0x0007, (r11_4 'childCount' int)=B:3:0x000e} in method: android.support.v7.widget.GridLayoutManager.findReferenceChild(android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State, boolean, boolean):android.view.View, dex: classes.dex
	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:226)
	at jadx.core.codegen.RegionGen.makeLoop(RegionGen.java:184)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:61)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:87)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:53)
	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:187)
	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:320)
	at jadx.core.codegen.ClassGen.addMethods(ClassGen.java:257)
	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:220)
	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:110)
	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:75)
	at jadx.core.codegen.CodeGen.visit(CodeGen.java:12)
	at jadx.core.ProcessClass.process(ProcessClass.java:40)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
Caused by: jadx.core.utils.exceptions.CodegenException: PHI can be used only in fallback mode
	at jadx.core.codegen.InsnGen.fallbackOnlyInsn(InsnGen.java:537)
	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:509)
	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:220)
	... 15 more

*/

        public final LayoutParams generateDefaultLayoutParams() {
            if (this.mOrientation == 0) {
                return new LayoutParams(-2, -1);
            }
            return new LayoutParams(-1, -2);
        }

        public final LayoutParams generateLayoutParams(Context context, AttributeSet attributeSet) {
            return new LayoutParams(context, attributeSet);
        }

        public final int getColumnCountForAccessibility(Recycler recycler, State state) {
            if (this.mOrientation == 1) {
                return this.mSpanCount;
            }
            if (state.getItemCount() <= 0) {
                return 0;
            }
            return getSpanGroupIndex(recycler, state, state.getItemCount() - 1) + 1;
        }

        public final int getRowCountForAccessibility(Recycler recycler, State state) {
            if (this.mOrientation == 0) {
                return this.mSpanCount;
            }
            if (state.getItemCount() <= 0) {
                return 0;
            }
            return getSpanGroupIndex(recycler, state, state.getItemCount() - 1) + 1;
        }

        final int getSpaceForSpanRange(int i, int i2) {
            if (this.mOrientation == 1 && isLayoutRTL()) {
                int[] iArr = this.mCachedBorders;
                int i3 = this.mSpanCount - i;
                return iArr[i3] - iArr[i3 - i2];
            }
            iArr = this.mCachedBorders;
            return iArr[i2 + i] - iArr[i];
        }

        public final void layoutChunk(Recycler recycler, State state, LayoutState layoutState, LayoutChunkResult layoutChunkResult) {
            int i;
            int i2;
            Recycler recycler2 = recycler;
            State state2 = state;
            LayoutState layoutState2 = layoutState;
            LayoutChunkResult layoutChunkResult2 = layoutChunkResult;
            int modeInOther = this.mOrientationHelper.getModeInOther();
            if (getChildCount() > 0) {
                i = r6.mCachedBorders[r6.mSpanCount];
            } else {
                i = 0;
            }
            if (modeInOther != 1073741824) {
                updateMeasurements();
            }
            int i3 = layoutState2.mItemDirection;
            int i4 = r6.mSpanCount;
            if (i3 != 1) {
                i4 = getSpanIndex(recycler2, state2, layoutState2.mCurrentPosition) + getSpanSize(recycler2, state2, layoutState2.mCurrentPosition);
                i2 = 0;
            } else {
                i2 = 0;
            }
            while (i2 < r6.mSpanCount && layoutState2.hasMore(state2) && i4 > 0) {
                int i5 = layoutState2.mCurrentPosition;
                int spanSize = getSpanSize(recycler2, state2, i5);
                if (spanSize <= r6.mSpanCount) {
                    i4 -= spanSize;
                    if (i4 >= 0) {
                        View next = layoutState2.next(recycler2);
                        if (next == null) {
                            break;
                        }
                        r6.mSet[i2] = next;
                        i2++;
                    } else {
                        break;
                    }
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Item at position ");
                stringBuilder.append(i5);
                stringBuilder.append(" requires ");
                stringBuilder.append(spanSize);
                stringBuilder.append(" spans but GridLayoutManager has only ");
                stringBuilder.append(r6.mSpanCount);
                stringBuilder.append(" spans.");
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            if (i2 != 0) {
                int i6;
                View view;
                int spanSize2;
                int i7;
                View view2;
                int decoratedMeasurement;
                int i8;
                if (i3 == 1) {
                    spanSize = i2;
                    i5 = 0;
                    i6 = 1;
                } else {
                    i5 = i2 - 1;
                    spanSize = -1;
                    i6 = -1;
                }
                i4 = 0;
                for (i5 = 
/*
Method generation error in method: android.support.v7.widget.GridLayoutManager.layoutChunk(android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State, android.support.v7.widget.LinearLayoutManager$LayoutState, android.support.v7.widget.LinearLayoutManager$LayoutChunkResult):void, dex: classes.dex
jadx.core.utils.exceptions.CodegenException: Error generate insn: PHI: (r13_6 'i5' int) = (r13_4 'i5' int), (r13_5 'i5' int) binds: {(r13_4 'i5' int)=B:28:0x0095, (r13_5 'i5' int)=B:29:0x0099} in method: android.support.v7.widget.GridLayoutManager.layoutChunk(android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State, android.support.v7.widget.LinearLayoutManager$LayoutState, android.support.v7.widget.LinearLayoutManager$LayoutChunkResult):void, dex: classes.dex
	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:226)
	at jadx.core.codegen.RegionGen.makeLoop(RegionGen.java:184)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:61)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:87)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:53)
	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:93)
	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:118)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:57)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:87)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:53)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:87)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:53)
	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:187)
	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:320)
	at jadx.core.codegen.ClassGen.addMethods(ClassGen.java:257)
	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:220)
	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:110)
	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:75)
	at jadx.core.codegen.CodeGen.visit(CodeGen.java:12)
	at jadx.core.ProcessClass.process(ProcessClass.java:40)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
Caused by: jadx.core.utils.exceptions.CodegenException: PHI can be used only in fallback mode
	at jadx.core.codegen.InsnGen.fallbackOnlyInsn(InsnGen.java:537)
	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:509)
	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:220)
	... 22 more

*/

                public final void onAnchorReady(Recycler recycler, State state, AnchorInfo anchorInfo, int i) {
                    updateMeasurements();
                    if (state.getItemCount() > 0 && !state.mInPreLayout) {
                        int spanIndex = getSpanIndex(recycler, state, anchorInfo.mPosition);
                        if (i == 1) {
                            while (spanIndex > 0) {
                                i = anchorInfo.mPosition;
                                if (i <= 0) {
                                    break;
                                }
                                i--;
                                anchorInfo.mPosition = i;
                                spanIndex = getSpanIndex(recycler, state, i);
                            }
                        } else {
                            i = state.getItemCount() - 1;
                            int i2 = anchorInfo.mPosition;
                            while (i2 < i) {
                                int i3 = i2 + 1;
                                int spanIndex2 = getSpanIndex(recycler, state, i3);
                                if (spanIndex2 <= spanIndex) {
                                    break;
                                }
                                i2 = i3;
                                spanIndex = spanIndex2;
                            }
                            anchorInfo.mPosition = i2;
                        }
                    }
                    ensureViewSet();
                }

                /* JADX WARNING: inconsistent code. */
                /* Code decompiled incorrectly, please refer to instructions dump. */
                public final android.view.View onFocusSearchFailed(android.view.View r23, int r24, android.support.p002v7.widget.RecyclerView.Recycler r25, android.support.p002v7.widget.RecyclerView.State r26) {
                    /*
                    r22 = this;
                    r0 = r22;
                    r1 = r25;
                    r2 = r26;
                    r3 = r22.findContainingItemView(r23);
                    r4 = 0;
                    if (r3 != 0) goto L_0x000e;
                L_0x000d:
                    return r4;
                L_0x000e:
                    r5 = r3.getLayoutParams();
                    r5 = (android.support.p002v7.widget.GridLayoutManager.LayoutParams) r5;
                    r6 = r5.mSpanIndex;
                    r5 = r5.mSpanSize;
                    r5 = r5 + r6;
                    r7 = super.onFocusSearchFailed(r23, r24, r25, r26);
                    if (r7 != 0) goto L_0x0020;
                L_0x001f:
                    return r4;
                L_0x0020:
                    r7 = r24;
                    r7 = r0.convertFocusDirectionToLayoutDirection(r7);
                    r8 = 1;
                    if (r7 == r8) goto L_0x002b;
                L_0x0029:
                    r7 = 0;
                    goto L_0x002c;
                L_0x002b:
                    r7 = 1;
                L_0x002c:
                    r10 = r0.mShouldReverseLayout;
                    r11 = -1;
                    if (r7 == r10) goto L_0x0039;
                L_0x0031:
                    r7 = r22.getChildCount();
                    r7 = r7 + r11;
                    r10 = -1;
                    r12 = -1;
                    goto L_0x0040;
                L_0x0039:
                    r7 = r22.getChildCount();
                    r10 = r7;
                    r7 = 0;
                    r12 = 1;
                L_0x0040:
                    r13 = r0.mOrientation;
                    if (r13 != r8) goto L_0x004c;
                L_0x0044:
                    r13 = r22.isLayoutRTL();
                    if (r13 == 0) goto L_0x004c;
                L_0x004a:
                    r13 = 1;
                    goto L_0x004d;
                L_0x004c:
                    r13 = 0;
                L_0x004d:
                    r14 = r0.getSpanGroupIndex(r1, r2, r7);
                    r11 = r7;
                    r8 = 0;
                    r15 = -1;
                    r16 = -1;
                    r17 = 0;
                    r7 = r4;
                L_0x0059:
                    if (r11 == r10) goto L_0x0159;
                L_0x005b:
                    r9 = r0.getSpanGroupIndex(r1, r2, r11);
                    r1 = r0.getChildAt(r11);
                    if (r1 != r3) goto L_0x0067;
                L_0x0065:
                    goto L_0x0159;
                L_0x0067:
                    r18 = r1.hasFocusable();
                    if (r18 == 0) goto L_0x007f;
                L_0x006d:
                    if (r9 == r14) goto L_0x007f;
                L_0x006f:
                    if (r4 != 0) goto L_0x0159;
                L_0x0071:
                    r18 = r3;
                    r19 = r8;
                    r21 = r10;
                    r23 = r14;
                    r10 = r16;
                    r8 = r17;
                    goto L_0x0146;
                L_0x007f:
                    r9 = r1.getLayoutParams();
                    r9 = (android.support.p002v7.widget.GridLayoutManager.LayoutParams) r9;
                    r2 = r9.mSpanIndex;
                    r18 = r3;
                    r3 = r9.mSpanSize;
                    r3 = r3 + r2;
                    r19 = r1.hasFocusable();
                    if (r19 == 0) goto L_0x0098;
                L_0x0092:
                    if (r2 != r6) goto L_0x0098;
                L_0x0094:
                    if (r3 == r5) goto L_0x0097;
                L_0x0096:
                    goto L_0x0098;
                L_0x0097:
                    return r1;
                L_0x0098:
                    r19 = r1.hasFocusable();
                    if (r19 == 0) goto L_0x00ad;
                L_0x009e:
                    if (r4 == 0) goto L_0x00a1;
                L_0x00a0:
                    goto L_0x00ad;
                L_0x00a1:
                    r19 = r8;
                    r21 = r10;
                    r23 = r14;
                    r10 = r16;
                    r8 = r17;
                    goto L_0x0112;
                L_0x00ad:
                    r19 = r1.hasFocusable();
                    if (r19 != 0) goto L_0x00c0;
                L_0x00b3:
                    if (r7 != 0) goto L_0x00c0;
                L_0x00b5:
                    r19 = r8;
                    r21 = r10;
                    r23 = r14;
                    r10 = r16;
                    r8 = r17;
                    goto L_0x0112;
                L_0x00c0:
                    r19 = java.lang.Math.max(r2, r6);
                    r20 = java.lang.Math.min(r3, r5);
                    r21 = r10;
                    r10 = r20 - r19;
                    r19 = r1.hasFocusable();
                    if (r19 == 0) goto L_0x00f0;
                L_0x00d2:
                    if (r10 > r8) goto L_0x00e7;
                L_0x00d4:
                    if (r10 != r8) goto L_0x00dd;
                L_0x00d6:
                    if (r2 > r15) goto L_0x00da;
                L_0x00d8:
                    r10 = 0;
                    goto L_0x00db;
                L_0x00da:
                    r10 = 1;
                L_0x00db:
                    if (r13 == r10) goto L_0x00e7;
                L_0x00dd:
                    r19 = r8;
                    r23 = r14;
                    r10 = r16;
                    r8 = r17;
                    goto L_0x0146;
                L_0x00e7:
                    r19 = r8;
                    r23 = r14;
                    r10 = r16;
                    r8 = r17;
                    goto L_0x0112;
                L_0x00f0:
                    if (r4 != 0) goto L_0x013e;
                L_0x00f2:
                    r19 = r8;
                    r23 = r14;
                    r8 = 1;
                    r14 = 0;
                    r20 = r0.isViewPartiallyVisible(r1, r14, r8);
                    if (r20 == 0) goto L_0x0142;
                L_0x00fe:
                    r8 = r17;
                    if (r10 > r8) goto L_0x0110;
                L_0x0102:
                    if (r10 != r8) goto L_0x010d;
                L_0x0104:
                    r10 = r16;
                    if (r2 > r10) goto L_0x0109;
                L_0x0108:
                    goto L_0x010a;
                L_0x0109:
                    r14 = 1;
                L_0x010a:
                    if (r13 == r14) goto L_0x0112;
                L_0x010c:
                    goto L_0x0146;
                L_0x010d:
                    r10 = r16;
                    goto L_0x0146;
                L_0x0110:
                    r10 = r16;
                L_0x0112:
                    r14 = r1.hasFocusable();
                    if (r14 == 0) goto L_0x012c;
                L_0x0118:
                    r4 = r9.mSpanIndex;
                    r3 = java.lang.Math.min(r3, r5);
                    r2 = java.lang.Math.max(r2, r6);
                    r2 = r3 - r2;
                    r15 = r4;
                    r17 = r8;
                    r16 = r10;
                    r4 = r1;
                    r8 = r2;
                    goto L_0x014c;
                L_0x012c:
                    r7 = r9.mSpanIndex;
                    r3 = java.lang.Math.min(r3, r5);
                    r2 = java.lang.Math.max(r2, r6);
                    r17 = r3 - r2;
                    r16 = r7;
                    r8 = r19;
                    r7 = r1;
                    goto L_0x014c;
                L_0x013e:
                    r19 = r8;
                    r23 = r14;
                L_0x0142:
                    r10 = r16;
                    r8 = r17;
                L_0x0146:
                    r17 = r8;
                    r16 = r10;
                    r8 = r19;
                L_0x014c:
                    r11 = r11 + r12;
                    r14 = r23;
                    r1 = r25;
                    r2 = r26;
                    r3 = r18;
                    r10 = r21;
                    goto L_0x0059;
                L_0x0159:
                    if (r4 == 0) goto L_0x015c;
                L_0x015b:
                    return r4;
                L_0x015c:
                    return r7;
                    */
                    throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.onFocusSearchFailed(android.view.View, int, android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State):android.view.View");
                }

                public final void onInitializeAccessibilityNodeInfoForItem(Recycler recycler, State state, View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
                    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                    if (layoutParams instanceof LayoutParams) {
                        LayoutParams layoutParams2 = (LayoutParams) layoutParams;
                        int spanGroupIndex = getSpanGroupIndex(recycler, state, layoutParams2.getViewLayoutPosition());
                        if (this.mOrientation == 0) {
                            accessibilityNodeInfoCompat.setCollectionItemInfo(CollectionItemInfoCompat.obtain$ar$ds(layoutParams2.mSpanIndex, layoutParams2.mSpanSize, spanGroupIndex, 1));
                            return;
                        } else {
                            accessibilityNodeInfoCompat.setCollectionItemInfo(CollectionItemInfoCompat.obtain$ar$ds(spanGroupIndex, 1, layoutParams2.mSpanIndex, layoutParams2.mSpanSize));
                            return;
                        }
                    }
                    super.onInitializeAccessibilityNodeInfoForItem(view, accessibilityNodeInfoCompat);
                }

                public final void onItemsAdded(RecyclerView recyclerView, int i, int i2) {
                    this.mSpanSizeLookup.invalidateSpanIndexCache();
                    this.mSpanSizeLookup.invalidateSpanGroupIndexCache();
                }

                public final void onItemsChanged(RecyclerView recyclerView) {
                    this.mSpanSizeLookup.invalidateSpanIndexCache();
                    this.mSpanSizeLookup.invalidateSpanGroupIndexCache();
                }

                public final void onItemsMoved(RecyclerView recyclerView, int i, int i2, int i3) {
                    this.mSpanSizeLookup.invalidateSpanIndexCache();
                    this.mSpanSizeLookup.invalidateSpanGroupIndexCache();
                }

                public final void onItemsRemoved(RecyclerView recyclerView, int i, int i2) {
                    this.mSpanSizeLookup.invalidateSpanIndexCache();
                    this.mSpanSizeLookup.invalidateSpanGroupIndexCache();
                }

                public final void onItemsUpdated(RecyclerView recyclerView, int i, int i2, Object obj) {
                    this.mSpanSizeLookup.invalidateSpanIndexCache();
                    this.mSpanSizeLookup.invalidateSpanGroupIndexCache();
                }

                public final void onLayoutCompleted(State state) {
                    super.onLayoutCompleted(state);
                    this.mPendingSpanCountChange = false;
                }

                public final int scrollHorizontallyBy(int i, Recycler recycler, State state) {
                    updateMeasurements();
                    ensureViewSet();
                    return super.scrollHorizontallyBy(i, recycler, state);
                }

                public final int scrollVerticallyBy(int i, Recycler recycler, State state) {
                    updateMeasurements();
                    ensureViewSet();
                    return super.scrollVerticallyBy(i, recycler, state);
                }

                public final void setMeasuredDimension(Rect rect, int i, int i2) {
                    int chooseSize;
                    if (this.mCachedBorders == null) {
                        super.setMeasuredDimension(rect, i, i2);
                    }
                    int paddingLeft = getPaddingLeft() + getPaddingRight();
                    int paddingTop = getPaddingTop() + getPaddingBottom();
                    if (this.mOrientation == 1) {
                        chooseSize = LayoutManager.chooseSize(i2, rect.height() + paddingTop, getMinimumHeight());
                        int[] iArr = this.mCachedBorders;
                        i = LayoutManager.chooseSize(i, iArr[iArr.length - 1] + paddingLeft, getMinimumWidth());
                    } else {
                        i = LayoutManager.chooseSize(i, rect.width() + paddingLeft, getMinimumWidth());
                        int[] iArr2 = this.mCachedBorders;
                        chooseSize = LayoutManager.chooseSize(i2, iArr2[iArr2.length - 1] + paddingTop, getMinimumHeight());
                    }
                    setMeasuredDimension(i, chooseSize);
                }

                public final void setSpanCount(int i) {
                    if (i != this.mSpanCount) {
                        this.mPendingSpanCountChange = true;
                        if (i > 0) {
                            this.mSpanCount = i;
                            this.mSpanSizeLookup.invalidateSpanIndexCache();
                            requestLayout();
                            return;
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Span count should be at least 1. Provided ");
                        stringBuilder.append(i);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                }

                public final void setStackFromEnd(boolean z) {
                    if (z) {
                        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
                    }
                    super.setStackFromEnd(false);
                }

                public final boolean supportsPredictiveItemAnimations() {
                    return this.mPendingSavedState == null && !this.mPendingSpanCountChange;
                }

                /* JADX WARNING: inconsistent code. */
                /* Code decompiled incorrectly, please refer to instructions dump. */
                private final void calculateItemBorders(int r8) {
                    /*
                    r7 = this;
                    r0 = r7.mCachedBorders;
                    r1 = r7.mSpanCount;
                    if (r0 == 0) goto L_0x0011;
                L_0x0006:
                    r2 = r0.length;
                    r3 = r1 + 1;
                    if (r2 != r3) goto L_0x0011;
                L_0x000b:
                    r2 = r2 + -1;
                    r2 = r0[r2];
                    if (r2 == r8) goto L_0x0015;
                L_0x0011:
                    r0 = r1 + 1;
                    r0 = new int[r0];
                    r2 = 0;
                    r0[r2] = r2;
                    r3 = r8 / r1;
                    r8 = r8 % r1;
                    r4 = 1;
                    r4 = 0;
                    r5 = 1;
                L_0x001f:
                    if (r5 > r1) goto L_0x0034;
                L_0x0021:
                    r2 = r2 + r8;
                    if (r2 <= 0) goto L_0x002c;
                L_0x0024:
                    r6 = r1 - r2;
                    if (r6 >= r8) goto L_0x002c;
                L_0x0028:
                    r6 = r3 + 1;
                    r2 = r2 - r1;
                    goto L_0x002e;
                    r6 = r3;
                L_0x002e:
                    r4 = r4 + r6;
                    r0[r5] = r4;
                    r5 = r5 + 1;
                    goto L_0x001f;
                L_0x0034:
                    r7.mCachedBorders = r0;
                    return;
                    */
                    throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GridLayoutManager.calculateItemBorders(int):void");
                }

                public final LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
                    if (layoutParams instanceof MarginLayoutParams) {
                        return new LayoutParams((MarginLayoutParams) layoutParams);
                    }
                    return new LayoutParams(layoutParams);
                }

                public final void onLayoutChildren(Recycler recycler, State state) {
                    if (state.mInPreLayout) {
                        int childCount = getChildCount();
                        for (int i = 0; i < childCount; i++) {
                            LayoutParams layoutParams = (LayoutParams) getChildAt(i).getLayoutParams();
                            int viewLayoutPosition = layoutParams.getViewLayoutPosition();
                            this.mPreLayoutSpanSizeCache.put(viewLayoutPosition, layoutParams.mSpanSize);
                            this.mPreLayoutSpanIndexCache.put(viewLayoutPosition, layoutParams.mSpanIndex);
                        }
                    }
                    super.onLayoutChildren(recycler, state);
                    this.mPreLayoutSpanSizeCache.clear();
                    this.mPreLayoutSpanIndexCache.clear();
                }

                public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
                    super(context, attributeSet, i, i2);
                    setSpanCount(LayoutManager.getProperties(context, attributeSet, i, i2).spanCount);
                }
            }
