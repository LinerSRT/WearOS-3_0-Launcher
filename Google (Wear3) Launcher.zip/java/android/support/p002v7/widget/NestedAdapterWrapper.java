package android.support.p002v7.widget;

import android.support.p000v4.util.Preconditions;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.AdapterDataObserver;
import android.support.p002v7.widget.StableIdStorage.StableIdLookup;
import android.support.p002v7.widget.ViewTypeStorage.IsolatedViewTypeStorage.WrapperViewTypeLookup;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.NestedAdapterWrapper */
final class NestedAdapterWrapper {
    public final Adapter adapter;
    private final AdapterDataObserver mAdapterObserver;
    int mCachedItemCount;
    final Callback mCallback;
    public final StableIdLookup mStableIdLookup;
    public final WrapperViewTypeLookup mViewTypeLookup$ar$class_merging;

    /* renamed from: android.support.v7.widget.NestedAdapterWrapper$1 */
    final class PG extends AdapterDataObserver {
        public final void onChanged() {
            NestedAdapterWrapper nestedAdapterWrapper = NestedAdapterWrapper.this;
            nestedAdapterWrapper.mCachedItemCount = nestedAdapterWrapper.adapter.getItemCount();
            ConcatAdapterController concatAdapterController = (ConcatAdapterController) NestedAdapterWrapper.this.mCallback;
            concatAdapterController.mConcatAdapter.notifyDataSetChanged();
            concatAdapterController.calculateAndUpdateStateRestorationPolicy();
        }

        public final void onItemRangeChanged(int i, int i2) {
            NestedAdapterWrapper nestedAdapterWrapper = NestedAdapterWrapper.this;
            nestedAdapterWrapper.mCallback.onItemRangeChanged(nestedAdapterWrapper, i, i2, null);
        }

        public final void onItemRangeInserted(int i, int i2) {
            NestedAdapterWrapper nestedAdapterWrapper = NestedAdapterWrapper.this;
            nestedAdapterWrapper.mCachedItemCount += i2;
            ConcatAdapterController concatAdapterController = (ConcatAdapterController) nestedAdapterWrapper.mCallback;
            concatAdapterController.mConcatAdapter.notifyItemRangeInserted(i + concatAdapterController.countItemsBefore(nestedAdapterWrapper), i2);
            NestedAdapterWrapper nestedAdapterWrapper2 = NestedAdapterWrapper.this;
            if (nestedAdapterWrapper2.mCachedItemCount > 0 && nestedAdapterWrapper2.adapter.mStateRestorationPolicy$ar$edu == 2) {
                ((ConcatAdapterController) nestedAdapterWrapper2.mCallback).calculateAndUpdateStateRestorationPolicy();
            }
        }

        public final void onItemRangeMoved$ar$ds(int i, int i2) {
            Preconditions.checkArgument(true, "moving more than 1 item is not supported in RecyclerView");
            NestedAdapterWrapper nestedAdapterWrapper = NestedAdapterWrapper.this;
            ConcatAdapterController concatAdapterController = (ConcatAdapterController) nestedAdapterWrapper.mCallback;
            int countItemsBefore = concatAdapterController.countItemsBefore(nestedAdapterWrapper);
            concatAdapterController.mConcatAdapter.notifyItemMoved(i + countItemsBefore, i2 + countItemsBefore);
        }

        public final void onItemRangeRemoved(int i, int i2) {
            NestedAdapterWrapper nestedAdapterWrapper = NestedAdapterWrapper.this;
            nestedAdapterWrapper.mCachedItemCount -= i2;
            ConcatAdapterController concatAdapterController = (ConcatAdapterController) nestedAdapterWrapper.mCallback;
            concatAdapterController.mConcatAdapter.notifyItemRangeRemoved(i + concatAdapterController.countItemsBefore(nestedAdapterWrapper), i2);
            NestedAdapterWrapper nestedAdapterWrapper2 = NestedAdapterWrapper.this;
            if (nestedAdapterWrapper2.mCachedItemCount <= 0 && nestedAdapterWrapper2.adapter.mStateRestorationPolicy$ar$edu == 2) {
                ((ConcatAdapterController) nestedAdapterWrapper2.mCallback).calculateAndUpdateStateRestorationPolicy();
            }
        }

        public final void onStateRestorationPolicyChanged() {
            ((ConcatAdapterController) NestedAdapterWrapper.this.mCallback).calculateAndUpdateStateRestorationPolicy();
        }

        public final void onItemRangeChanged(int i, int i2, Object obj) {
            NestedAdapterWrapper nestedAdapterWrapper = NestedAdapterWrapper.this;
            nestedAdapterWrapper.mCallback.onItemRangeChanged(nestedAdapterWrapper, i, i2, obj);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.NestedAdapterWrapper$Callback */
    interface Callback {
        void onItemRangeChanged(NestedAdapterWrapper nestedAdapterWrapper, int i, int i2, Object obj);
    }

    public NestedAdapterWrapper(Adapter adapter, Callback callback, ViewTypeStorage$IsolatedViewTypeStorage viewTypeStorage$IsolatedViewTypeStorage, StableIdLookup stableIdLookup) {
        AdapterDataObserver pg = new PG();
        this.mAdapterObserver = pg;
        this.adapter = adapter;
        this.mCallback = callback;
        this.mViewTypeLookup$ar$class_merging = new WrapperViewTypeLookup(this);
        this.mStableIdLookup = stableIdLookup;
        this.mCachedItemCount = adapter.getItemCount();
        adapter.registerAdapterDataObserver(pg);
    }
}
