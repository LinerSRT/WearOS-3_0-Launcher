package android.support.p002v7.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region.Op;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.text.AllCapsTransformationMethod;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.SwitchCompat */
public class SwitchCompat extends CompoundButton {
    private static final int[] CHECKED_STATE_SET = new int[]{16842912};
    private static final Property THUMB_POS = new PG(Float.class);
    private boolean mHasThumbTint;
    private boolean mHasThumbTintMode;
    private boolean mHasTrackTint;
    private boolean mHasTrackTintMode;
    private int mMinFlingVelocity;
    private Layout mOffLayout;
    private Layout mOnLayout;
    ObjectAnimator mPositionAnimator;
    private boolean mShowText;
    private boolean mSplitTrack;
    private int mSwitchBottom;
    private int mSwitchHeight;
    private int mSwitchLeft;
    private int mSwitchMinWidth;
    private int mSwitchPadding;
    private int mSwitchRight;
    private int mSwitchTop;
    private TransformationMethod mSwitchTransformationMethod;
    private int mSwitchWidth;
    private final Rect mTempRect;
    private ColorStateList mTextColors;
    private final AppCompatTextHelper mTextHelper;
    public CharSequence mTextOff;
    public CharSequence mTextOn;
    private final TextPaint mTextPaint;
    private Drawable mThumbDrawable;
    float mThumbPosition;
    private int mThumbTextPadding;
    private ColorStateList mThumbTintList;
    private Mode mThumbTintMode;
    private int mThumbWidth;
    private int mTouchMode;
    private int mTouchSlop;
    private float mTouchX;
    private float mTouchY;
    private Drawable mTrackDrawable;
    private ColorStateList mTrackTintList;
    private Mode mTrackTintMode;
    private VelocityTracker mVelocityTracker;

    /* renamed from: android.support.v7.widget.SwitchCompat$1 */
    final class PG extends Property {
        public PG(Class cls) {
            super(cls, "thumbPos");
        }

        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            return Float.valueOf(((SwitchCompat) obj).mThumbPosition);
        }

        public final /* bridge */ /* synthetic */ void set(Object obj, Object obj2) {
            ((SwitchCompat) obj).setThumbPosition(((Float) obj2).floatValue());
        }
    }

    public SwitchCompat(Context context) {
        this(context, null);
    }

    private final boolean getTargetCheckedState() {
        return this.mThumbPosition > 0.5f;
    }

    private final int getThumbOffset() {
        float f;
        if (ViewUtils.isLayoutRtl(this)) {
            f = 1.0f - this.mThumbPosition;
        } else {
            f = this.mThumbPosition;
        }
        return (int) ((f * ((float) getThumbScrollRange())) + 0.5f);
    }

    private final int getThumbScrollRange() {
        Drawable drawable = this.mTrackDrawable;
        if (drawable == null) {
            return 0;
        }
        Rect opticalBounds;
        Rect rect = this.mTempRect;
        drawable.getPadding(rect);
        drawable = this.mThumbDrawable;
        if (drawable != null) {
            opticalBounds = DrawableUtils.getOpticalBounds(drawable);
        } else {
            opticalBounds = DrawableUtils.INSETS_NONE;
        }
        return ((((this.mSwitchWidth - this.mThumbWidth) - rect.left) - rect.right) - opticalBounds.left) - opticalBounds.right;
    }

    private final Layout makeLayout(CharSequence charSequence) {
        TransformationMethod transformationMethod = this.mSwitchTransformationMethod;
        if (transformationMethod != null) {
            charSequence = transformationMethod.getTransformation(charSequence, this);
        }
        CharSequence charSequence2 = charSequence;
        TextPaint textPaint = this.mTextPaint;
        return new StaticLayout(charSequence2, textPaint, charSequence2 != null ? (int) Math.ceil((double) Layout.getDesiredWidth(charSequence2, textPaint)) : 0, Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
    }

    public final void draw(Canvas canvas) {
        Rect opticalBounds;
        Rect rect = this.mTempRect;
        int i = this.mSwitchLeft;
        int i2 = this.mSwitchTop;
        int i3 = this.mSwitchRight;
        int i4 = this.mSwitchBottom;
        int thumbOffset = getThumbOffset() + i;
        Drawable drawable = this.mThumbDrawable;
        if (drawable != null) {
            opticalBounds = DrawableUtils.getOpticalBounds(drawable);
        } else {
            opticalBounds = DrawableUtils.INSETS_NONE;
        }
        Drawable drawable2 = this.mTrackDrawable;
        if (drawable2 != null) {
            int i5;
            int i6;
            drawable2.getPadding(rect);
            thumbOffset += rect.left;
            if (opticalBounds != null) {
                if (opticalBounds.left > rect.left) {
                    i += opticalBounds.left - rect.left;
                }
                if (opticalBounds.top > rect.top) {
                    i5 = (opticalBounds.top - rect.top) + i2;
                } else {
                    i5 = i2;
                }
                if (opticalBounds.right > rect.right) {
                    i3 -= opticalBounds.right - rect.right;
                }
                if (opticalBounds.bottom > rect.bottom) {
                    i6 = i4 - (opticalBounds.bottom - rect.bottom);
                    this.mTrackDrawable.setBounds(i, i5, i3, i6);
                }
            } else {
                i5 = i2;
            }
            i6 = i4;
            this.mTrackDrawable.setBounds(i, i5, i3, i6);
        }
        Drawable drawable3 = this.mThumbDrawable;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            i = thumbOffset - rect.left;
            thumbOffset = (thumbOffset + this.mThumbWidth) + rect.right;
            this.mThumbDrawable.setBounds(i, i2, thumbOffset, i4);
            Drawable background = getBackground();
            if (background != null) {
                background.setHotspotBounds(i, i2, thumbOffset, i4);
            }
        }
        super.draw(canvas);
    }

    public final void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        Drawable drawable = this.mThumbDrawable;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
        drawable = this.mTrackDrawable;
        if (drawable != null) {
            drawable.setHotspot(f, f2);
        }
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.mThumbDrawable;
        int i = 0;
        if (drawable != null && drawable.isStateful()) {
            i = drawable.setState(drawableState);
        }
        drawable = this.mTrackDrawable;
        if (drawable != null && drawable.isStateful()) {
            i |= drawable.setState(drawableState);
        }
        if (i != 0) {
            invalidate();
        }
    }

    public final int getCompoundPaddingLeft() {
        if (!ViewUtils.isLayoutRtl(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.mSwitchWidth;
        if (!TextUtils.isEmpty(getText())) {
            compoundPaddingLeft += this.mSwitchPadding;
        }
        return compoundPaddingLeft;
    }

    public final int getCompoundPaddingRight() {
        if (ViewUtils.isLayoutRtl(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.mSwitchWidth;
        if (!TextUtils.isEmpty(getText())) {
            compoundPaddingRight += this.mSwitchPadding;
        }
        return compoundPaddingRight;
    }

    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.mThumbDrawable;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        drawable = this.mTrackDrawable;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.mPositionAnimator;
        if (objectAnimator != null && objectAnimator.isStarted()) {
            this.mPositionAnimator.end();
            this.mPositionAnimator = null;
        }
    }

    protected final int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (isChecked()) {
            SwitchCompat.mergeDrawableStates(onCreateDrawableState, CHECKED_STATE_SET);
        }
        return onCreateDrawableState;
    }

    protected final void onDraw(Canvas canvas) {
        Layout layout;
        super.onDraw(canvas);
        Rect rect = this.mTempRect;
        Drawable drawable = this.mTrackDrawable;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i = this.mSwitchTop;
        i += rect.top;
        int i2 = this.mSwitchBottom - rect.bottom;
        Drawable drawable2 = this.mThumbDrawable;
        if (drawable != null) {
            if (!this.mSplitTrack || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect opticalBounds = DrawableUtils.getOpticalBounds(drawable2);
                drawable2.copyBounds(rect);
                rect.left += opticalBounds.left;
                rect.right -= opticalBounds.right;
                int save = canvas.save();
                canvas.clipRect(rect, Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(save);
            }
        }
        int save2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        if (getTargetCheckedState()) {
            layout = this.mOnLayout;
        } else {
            layout = this.mOffLayout;
        }
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.mTextColors;
            if (colorStateList != null) {
                this.mTextPaint.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.mTextPaint.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                save = bounds.left + bounds.right;
            } else {
                save = getWidth();
            }
            canvas.translate((float) ((save / 2) - (layout.getWidth() / 2)), (float) (((i + i2) / 2) - (layout.getHeight() / 2)));
            layout.draw(canvas);
        }
        canvas.restoreToCount(save2);
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int paddingLeft;
        super.onLayout(z, i, i2, i3, i4);
        i = 0;
        if (this.mThumbDrawable != null) {
            Rect rect = this.mTempRect;
            Drawable drawable = this.mTrackDrawable;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect opticalBounds = DrawableUtils.getOpticalBounds(this.mThumbDrawable);
            i3 = Math.max(0, opticalBounds.left - rect.left);
            i = Math.max(0, opticalBounds.right - rect.right);
        } else {
            i3 = 0;
        }
        if (ViewUtils.isLayoutRtl(this)) {
            paddingLeft = getPaddingLeft() + i3;
            i2 = ((this.mSwitchWidth + paddingLeft) - i3) - i;
        } else {
            i2 = (getWidth() - getPaddingRight()) - i;
            paddingLeft = ((i2 - this.mSwitchWidth) + i3) + i;
        }
        switch (getGravity() & 112) {
            case 16:
                i = getPaddingTop();
                i3 = getHeight();
                i4 = getPaddingBottom();
                int i5 = this.mSwitchHeight;
                i3 = (((i + i3) - i4) / 2) - (i5 / 2);
                i = i3 + i5;
                break;
            case 80:
                i = getHeight() - getPaddingBottom();
                i3 = i - this.mSwitchHeight;
                break;
            default:
                i3 = getPaddingTop();
                i = this.mSwitchHeight + i3;
                break;
        }
        this.mSwitchLeft = paddingLeft;
        this.mSwitchTop = i3;
        this.mSwitchBottom = i;
        this.mSwitchRight = i2;
    }

    public final void onMeasure(int i, int i2) {
        int intrinsicWidth;
        int intrinsicHeight;
        int max;
        int i3;
        if (this.mShowText) {
            if (this.mOnLayout == null) {
                this.mOnLayout = makeLayout(this.mTextOn);
            }
            if (this.mOffLayout == null) {
                this.mOffLayout = makeLayout(this.mTextOff);
            }
        }
        Rect rect = this.mTempRect;
        Drawable drawable = this.mThumbDrawable;
        int i4 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.mThumbDrawable.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.mThumbDrawable.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        if (this.mShowText) {
            max = Math.max(this.mOnLayout.getWidth(), this.mOffLayout.getWidth());
            i3 = this.mThumbTextPadding;
            max += i3 + i3;
        } else {
            max = 0;
        }
        this.mThumbWidth = Math.max(max, intrinsicWidth);
        drawable = this.mTrackDrawable;
        if (drawable != null) {
            drawable.getPadding(rect);
            i4 = this.mTrackDrawable.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        intrinsicWidth = rect.left;
        int i5 = rect.right;
        Drawable drawable2 = this.mThumbDrawable;
        if (drawable2 != null) {
            Rect opticalBounds = DrawableUtils.getOpticalBounds(drawable2);
            intrinsicWidth = Math.max(intrinsicWidth, opticalBounds.left);
            i5 = Math.max(i5, opticalBounds.right);
        }
        max = this.mSwitchMinWidth;
        i3 = this.mThumbWidth;
        i5 = Math.max(max, ((i3 + i3) + intrinsicWidth) + i5);
        intrinsicWidth = Math.max(i4, intrinsicHeight);
        this.mSwitchWidth = i5;
        this.mSwitchHeight = intrinsicWidth;
        super.onMeasure(i, i2);
        if (getMeasuredHeight() < intrinsicWidth) {
            setMeasuredDimension(getMeasuredWidthAndState(), intrinsicWidth);
        }
    }

    public final void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        Object obj;
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        if (isChecked()) {
            obj = this.mTextOn;
        } else {
            obj = this.mTextOff;
        }
        if (obj != null) {
            accessibilityEvent.getText().add(obj);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onTouchEvent(android.view.MotionEvent r10) {
        /*
        r9 = this;
        r0 = r9.mVelocityTracker;
        r0.addMovement(r10);
        r0 = r10.getActionMasked();
        r1 = 2;
        r2 = 0;
        r3 = 1;
        switch(r0) {
            case 0: goto L_0x00f9;
            case 1: goto L_0x0089;
            case 2: goto L_0x0011;
            case 3: goto L_0x0089;
            default: goto L_0x000f;
        };
    L_0x000f:
        goto L_0x014d;
    L_0x0011:
        r0 = r9.mTouchMode;
        switch(r0) {
            case 1: goto L_0x0055;
            case 2: goto L_0x0018;
            default: goto L_0x0016;
        };
    L_0x0016:
        goto L_0x014d;
    L_0x0018:
        r10 = r10.getX();
        r0 = r9.getThumbScrollRange();
        r1 = r9.mTouchX;
        r1 = r10 - r1;
        r4 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        if (r0 == 0) goto L_0x002b;
    L_0x0028:
        r0 = (float) r0;
        r1 = r1 / r0;
        goto L_0x0034;
    L_0x002b:
        r0 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1));
        if (r0 <= 0) goto L_0x0032;
    L_0x002f:
        r1 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        goto L_0x0034;
    L_0x0032:
        r1 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
    L_0x0034:
        r0 = android.support.p002v7.widget.ViewUtils.isLayoutRtl(r9);
        if (r0 == 0) goto L_0x003b;
    L_0x003a:
        r1 = -r1;
    L_0x003b:
        r0 = r9.mThumbPosition;
        r1 = r1 + r0;
        r5 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1));
        if (r5 >= 0) goto L_0x0043;
    L_0x0042:
        goto L_0x004b;
    L_0x0043:
        r2 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1));
        if (r2 <= 0) goto L_0x004a;
    L_0x0047:
        r2 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        goto L_0x004b;
    L_0x004a:
        r2 = r1;
    L_0x004b:
        r0 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1));
        if (r0 == 0) goto L_0x0054;
    L_0x004f:
        r9.mTouchX = r10;
        r9.setThumbPosition(r2);
    L_0x0054:
        return r3;
    L_0x0055:
        r0 = r10.getX();
        r2 = r10.getY();
        r4 = r9.mTouchX;
        r4 = r0 - r4;
        r4 = java.lang.Math.abs(r4);
        r5 = r9.mTouchSlop;
        r5 = (float) r5;
        r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1));
        if (r4 > 0) goto L_0x007b;
    L_0x006c:
        r4 = r9.mTouchY;
        r4 = r2 - r4;
        r4 = java.lang.Math.abs(r4);
        r5 = r9.mTouchSlop;
        r5 = (float) r5;
        r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1));
        if (r4 <= 0) goto L_0x014d;
    L_0x007b:
        r9.mTouchMode = r1;
        r10 = r9.getParent();
        r10.requestDisallowInterceptTouchEvent(r3);
        r9.mTouchX = r0;
        r9.mTouchY = r2;
        return r3;
    L_0x0089:
        r0 = r9.mTouchMode;
        r4 = 0;
        if (r0 != r1) goto L_0x00f1;
    L_0x008e:
        r9.mTouchMode = r4;
        r0 = r10.getAction();
        if (r0 != r3) goto L_0x009e;
    L_0x0096:
        r0 = r9.isEnabled();
        if (r0 == 0) goto L_0x009e;
    L_0x009c:
        r0 = 1;
        goto L_0x009f;
    L_0x009e:
        r0 = 0;
    L_0x009f:
        r1 = r9.isChecked();
        if (r0 == 0) goto L_0x00d6;
    L_0x00a5:
        r0 = r9.mVelocityTracker;
        r5 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r0.computeCurrentVelocity(r5);
        r0 = r9.mVelocityTracker;
        r0 = r0.getXVelocity();
        r5 = java.lang.Math.abs(r0);
        r6 = r9.mMinFlingVelocity;
        r6 = (float) r6;
        r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1));
        if (r5 <= 0) goto L_0x00d1;
    L_0x00bd:
        r5 = android.support.p002v7.widget.ViewUtils.isLayoutRtl(r9);
        if (r5 == 0) goto L_0x00c9;
    L_0x00c3:
        r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r0 >= 0) goto L_0x00cf;
    L_0x00c7:
        r0 = 1;
        goto L_0x00d7;
    L_0x00c9:
        r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r0 <= 0) goto L_0x00cf;
    L_0x00cd:
        r0 = 1;
        goto L_0x00d7;
    L_0x00cf:
        r0 = 0;
        goto L_0x00d7;
    L_0x00d1:
        r0 = r9.getTargetCheckedState();
        goto L_0x00d7;
    L_0x00d6:
        r0 = r1;
    L_0x00d7:
        if (r0 == r1) goto L_0x00dc;
    L_0x00d9:
        r9.playSoundEffect(r4);
    L_0x00dc:
        r9.setChecked(r0);
        r0 = android.view.MotionEvent.obtain(r10);
        r1 = 3;
        r0.setAction(r1);
        super.onTouchEvent(r0);
        r0.recycle();
        super.onTouchEvent(r10);
        return r3;
    L_0x00f1:
        r9.mTouchMode = r4;
        r0 = r9.mVelocityTracker;
        r0.clear();
        goto L_0x014d;
    L_0x00f9:
        r0 = r10.getX();
        r1 = r10.getY();
        r2 = r9.isEnabled();
        if (r2 == 0) goto L_0x014d;
    L_0x0107:
        r2 = r9.mThumbDrawable;
        if (r2 != 0) goto L_0x010c;
    L_0x010b:
        goto L_0x014d;
    L_0x010c:
        r2 = r9.getThumbOffset();
        r4 = r9.mThumbDrawable;
        r5 = r9.mTempRect;
        r4.getPadding(r5);
        r4 = r9.mSwitchTop;
        r5 = r9.mTouchSlop;
        r4 = r4 - r5;
        r6 = r9.mSwitchLeft;
        r6 = r6 + r2;
        r6 = r6 - r5;
        r2 = r9.mThumbWidth;
        r5 = r9.mTempRect;
        r5 = r5.left;
        r7 = r9.mTempRect;
        r7 = r7.right;
        r8 = r9.mTouchSlop;
        r2 = r2 + r6;
        r2 = r2 + r5;
        r2 = r2 + r7;
        r2 = r2 + r8;
        r5 = r9.mSwitchBottom;
        r5 = r5 + r8;
        r6 = (float) r6;
        r6 = (r0 > r6 ? 1 : (r0 == r6 ? 0 : -1));
        if (r6 <= 0) goto L_0x0016;
    L_0x0138:
        r2 = (float) r2;
        r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r2 >= 0) goto L_0x0016;
    L_0x013d:
        r2 = (float) r4;
        r2 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1));
        if (r2 <= 0) goto L_0x0016;
    L_0x0142:
        r2 = (float) r5;
        r2 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1));
        if (r2 >= 0) goto L_0x0016;
    L_0x0147:
        r9.mTouchMode = r3;
        r9.mTouchX = r0;
        r9.mTouchY = r1;
    L_0x014d:
        r10 = super.onTouchEvent(r10);
        return r10;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.SwitchCompat.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final void setChecked(boolean z) {
        super.setChecked(z);
        z = isChecked();
        if (z) {
            setOnStateDescriptionOnRAndAbove();
        } else {
            setOffStateDescriptionOnRAndAbove();
        }
        float f = 0.0f;
        if (getWindowToken() == null || !ViewCompat.isLaidOut(this)) {
            ObjectAnimator objectAnimator = this.mPositionAnimator;
            if (objectAnimator != null) {
                objectAnimator.cancel();
            }
            if (true == z) {
                f = 1.0f;
            }
            setThumbPosition(f);
            return;
        }
        if (true == z) {
            f = 1.0f;
        }
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, THUMB_POS, new float[]{f});
        this.mPositionAnimator = ofFloat;
        ofFloat.setDuration(250);
        this.mPositionAnimator.setAutoCancel(true);
        this.mPositionAnimator.start();
    }

    public final void setOffStateDescriptionOnRAndAbove() {
        CharSequence charSequence = this.mTextOff;
        if (charSequence == null) {
            charSequence = getResources().getString(R.string.abc_capital_off);
        }
        ViewCompat.setStateDescription(this, charSequence);
    }

    public final void setOnStateDescriptionOnRAndAbove() {
        CharSequence charSequence = this.mTextOn;
        if (charSequence == null) {
            charSequence = getResources().getString(R.string.abc_capital_on);
        }
        ViewCompat.setStateDescription(this, charSequence);
    }

    public final void setSwitchTypeface(Typeface typeface) {
        if ((this.mTextPaint.getTypeface() != null && !this.mTextPaint.getTypeface().equals(typeface)) || (this.mTextPaint.getTypeface() == null && typeface != null)) {
            this.mTextPaint.setTypeface(typeface);
            requestLayout();
            invalidate();
        }
    }

    final void setThumbPosition(float f) {
        this.mThumbPosition = f;
        invalidate();
    }

    public final void toggle() {
        setChecked(isChecked() ^ 1);
    }

    protected final boolean verifyDrawable(Drawable drawable) {
        if (!(super.verifyDrawable(drawable) || drawable == this.mThumbDrawable)) {
            if (drawable != this.mTrackDrawable) {
                return false;
            }
        }
        return true;
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.switchStyle);
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i) {
        Drawable drawable;
        Drawable mutate;
        super(context, attributeSet, i);
        this.mThumbTintList = null;
        this.mThumbTintMode = null;
        this.mHasThumbTint = false;
        this.mHasThumbTintMode = false;
        this.mTrackTintList = null;
        this.mTrackTintMode = null;
        this.mHasTrackTint = false;
        this.mHasTrackTintMode = false;
        this.mVelocityTracker = VelocityTracker.obtain();
        this.mTempRect = new Rect();
        ThemeUtils.checkAppCompatTheme(this, getContext());
        boolean z = true;
        TextPaint textPaint = new TextPaint(1);
        this.mTextPaint = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(context, attributeSet, R$styleable.SwitchCompat, i);
        ViewCompat.saveAttributeDataForStyleable(this, context, R$styleable.SwitchCompat, attributeSet, obtainStyledAttributes$ar$ds.mWrapped, i, 0);
        Drawable drawable2 = obtainStyledAttributes$ar$ds.getDrawable(2);
        this.mThumbDrawable = drawable2;
        if (drawable2 != null) {
            drawable2.setCallback(this);
        }
        drawable2 = obtainStyledAttributes$ar$ds.getDrawable(11);
        this.mTrackDrawable = drawable2;
        if (drawable2 != null) {
            drawable2.setCallback(this);
        }
        this.mTextOn = obtainStyledAttributes$ar$ds.getText(0);
        this.mTextOff = obtainStyledAttributes$ar$ds.getText(1);
        this.mShowText = obtainStyledAttributes$ar$ds.getBoolean(3, true);
        this.mThumbTextPadding = obtainStyledAttributes$ar$ds.getDimensionPixelSize(8, 0);
        this.mSwitchMinWidth = obtainStyledAttributes$ar$ds.getDimensionPixelSize(5, 0);
        this.mSwitchPadding = obtainStyledAttributes$ar$ds.getDimensionPixelSize(6, 0);
        this.mSplitTrack = obtainStyledAttributes$ar$ds.getBoolean(4, false);
        ColorStateList colorStateList = obtainStyledAttributes$ar$ds.getColorStateList(9);
        if (colorStateList != null) {
            this.mThumbTintList = colorStateList;
            this.mHasThumbTint = true;
        }
        Mode parseTintMode = DrawableUtils.parseTintMode(obtainStyledAttributes$ar$ds.getInt(10, -1), null);
        if (this.mThumbTintMode != parseTintMode) {
            this.mThumbTintMode = parseTintMode;
            this.mHasThumbTintMode = true;
        }
        boolean z2 = this.mHasThumbTint;
        if (z2 || this.mHasThumbTintMode) {
            drawable = this.mThumbDrawable;
            if (drawable != null && (z2 || this.mHasThumbTintMode)) {
                mutate = drawable.mutate();
                this.mThumbDrawable = mutate;
                if (this.mHasThumbTint) {
                    mutate.setTintList(this.mThumbTintList);
                }
                if (this.mHasThumbTintMode) {
                    this.mThumbDrawable.setTintMode(this.mThumbTintMode);
                }
                if (this.mThumbDrawable.isStateful()) {
                    this.mThumbDrawable.setState(getDrawableState());
                }
            }
        }
        colorStateList = obtainStyledAttributes$ar$ds.getColorStateList(12);
        if (colorStateList != null) {
            this.mTrackTintList = colorStateList;
            this.mHasTrackTint = true;
        }
        parseTintMode = DrawableUtils.parseTintMode(obtainStyledAttributes$ar$ds.getInt(13, -1), null);
        if (this.mTrackTintMode != parseTintMode) {
            this.mTrackTintMode = parseTintMode;
            this.mHasTrackTintMode = true;
        }
        z2 = this.mHasTrackTint;
        if (z2 || this.mHasTrackTintMode) {
            drawable = this.mTrackDrawable;
            if (drawable != null && (z2 || this.mHasTrackTintMode)) {
                mutate = drawable.mutate();
                this.mTrackDrawable = mutate;
                if (this.mHasTrackTint) {
                    mutate.setTintList(this.mTrackTintList);
                }
                if (this.mHasTrackTintMode) {
                    this.mTrackDrawable.setTintMode(this.mTrackTintMode);
                }
                if (this.mTrackDrawable.isStateful()) {
                    this.mTrackDrawable.setState(getDrawableState());
                }
            }
        }
        int resourceId = obtainStyledAttributes$ar$ds.getResourceId(7, 0);
        if (resourceId != 0) {
            Typeface typeface;
            TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, resourceId, R$styleable.TextAppearance);
            ColorStateList colorStateList2 = obtainStyledAttributes.getColorStateList(3);
            if (colorStateList2 != null) {
                this.mTextColors = colorStateList2;
            } else {
                this.mTextColors = getTextColors();
            }
            int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(0, 0);
            if (dimensionPixelSize != 0) {
                float f = (float) dimensionPixelSize;
                if (f != textPaint.getTextSize()) {
                    textPaint.setTextSize(f);
                    requestLayout();
                }
            }
            dimensionPixelSize = obtainStyledAttributes.getInt(1, -1);
            int i2 = obtainStyledAttributes.getInt(2, -1);
            switch (dimensionPixelSize) {
                case 1:
                    typeface = Typeface.SANS_SERIF;
                    break;
                case 2:
                    typeface = Typeface.SERIF;
                    break;
                case 3:
                    typeface = Typeface.MONOSPACE;
                    break;
                default:
                    typeface = null;
                    break;
            }
            float f2 = 0.0f;
            if (i2 > 0) {
                if (typeface == null) {
                    typeface = Typeface.defaultFromStyle(i2);
                } else {
                    typeface = Typeface.create(typeface, i2);
                }
                setSwitchTypeface(typeface);
                if (typeface != null) {
                    dimensionPixelSize = typeface.getStyle();
                } else {
                    dimensionPixelSize = 0;
                }
                dimensionPixelSize = (dimensionPixelSize ^ -1) & i2;
                if (1 != (dimensionPixelSize & 1)) {
                    z = false;
                }
                textPaint.setFakeBoldText(z);
                if ((dimensionPixelSize & 2) != 0) {
                    f2 = -0.25f;
                }
                textPaint.setTextSkewX(f2);
            } else {
                textPaint.setFakeBoldText(false);
                textPaint.setTextSkewX(0.0f);
                setSwitchTypeface(typeface);
            }
            if (obtainStyledAttributes.getBoolean(17, false)) {
                this.mSwitchTransformationMethod = new AllCapsTransformationMethod(getContext());
            } else {
                this.mSwitchTransformationMethod = null;
            }
            obtainStyledAttributes.recycle();
        }
        AppCompatTextHelper appCompatTextHelper = new AppCompatTextHelper(this);
        this.mTextHelper = appCompatTextHelper;
        appCompatTextHelper.loadFromAttributes(attributeSet, i);
        obtainStyledAttributes$ar$ds.recycle();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.mMinFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
        refreshDrawableState();
        setChecked(isChecked());
    }
}
