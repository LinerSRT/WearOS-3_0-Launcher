package android.support.p002v7.widget;

import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.State;
import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ScrollbarHelper */
final class ScrollbarHelper {
    static int computeScrollExtent(State state, OrientationHelper orientationHelper, View view, View view2, LayoutManager layoutManager, boolean z) {
        if (!(layoutManager.getChildCount() == 0 || state.getItemCount() == 0 || view == null)) {
            if (view2 != null) {
                if (!z) {
                    return Math.abs(layoutManager.getPosition(view) - layoutManager.getPosition(view2)) + 1;
                }
                return Math.min(orientationHelper.getTotalSpace(), orientationHelper.getDecoratedEnd(view2) - orientationHelper.getDecoratedStart(view));
            }
        }
        return 0;
    }

    static int computeScrollOffset(State state, OrientationHelper orientationHelper, View view, View view2, LayoutManager layoutManager, boolean z, boolean z2) {
        if (!(layoutManager.getChildCount() == 0 || state.getItemCount() == 0 || view == null)) {
            if (view2 != null) {
                int max = z2 ? Math.max(0, (state.getItemCount() - Math.max(layoutManager.getPosition(view), layoutManager.getPosition(view2))) - 1) : Math.max(0, Math.min(layoutManager.getPosition(view), layoutManager.getPosition(view2)));
                if (z) {
                    return Math.round((((float) max) * (((float) Math.abs(orientationHelper.getDecoratedEnd(view2) - orientationHelper.getDecoratedStart(view))) / ((float) (Math.abs(layoutManager.getPosition(view) - layoutManager.getPosition(view2)) + 1)))) + ((float) (orientationHelper.getStartAfterPadding() - orientationHelper.getDecoratedStart(view))));
                }
                return max;
            }
        }
        return 0;
    }

    static int computeScrollRange(State state, OrientationHelper orientationHelper, View view, View view2, LayoutManager layoutManager, boolean z) {
        if (!(layoutManager.getChildCount() == 0 || state.getItemCount() == 0 || view == null)) {
            if (view2 != null) {
                if (z) {
                    return (int) ((((float) (orientationHelper.getDecoratedEnd(view2) - orientationHelper.getDecoratedStart(view))) / ((float) (Math.abs(layoutManager.getPosition(view) - layoutManager.getPosition(view2)) + 1))) * ((float) state.getItemCount()));
                }
                return state.getItemCount();
            }
        }
        return 0;
    }
}
