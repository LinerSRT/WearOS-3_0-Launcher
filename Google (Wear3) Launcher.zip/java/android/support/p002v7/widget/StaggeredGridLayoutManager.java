package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.LayoutManager.LayoutPrefetchRegistry;
import android.support.p002v7.widget.RecyclerView.LayoutManager.Properties;
import android.support.p002v7.widget.RecyclerView.LayoutParams;
import android.support.p002v7.widget.RecyclerView.Recycler;
import android.support.p002v7.widget.RecyclerView.SmoothScroller;
import android.support.p002v7.widget.RecyclerView.SmoothScroller.ScrollVectorProvider;
import android.support.p002v7.widget.RecyclerView.State;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.StaggeredGridLayoutManager */
public class StaggeredGridLayoutManager extends LayoutManager implements ScrollVectorProvider {
    private final AnchorInfo mAnchorInfo;
    private final Runnable mCheckForGapsRunnable;
    private int mGapStrategy;
    private boolean mLastLayoutFromEnd;
    private boolean mLastLayoutRTL;
    private final LayoutState mLayoutState;
    LazySpanLookup mLazySpanLookup;
    private int mOrientation;
    private SavedState mPendingSavedState;
    int mPendingScrollPosition;
    int mPendingScrollPositionOffset;
    private int[] mPrefetchDistances;
    OrientationHelper mPrimaryOrientation;
    private BitSet mRemainingSpans;
    boolean mReverseLayout;
    OrientationHelper mSecondaryOrientation;
    boolean mShouldReverseLayout;
    private int mSizePerSpan;
    private boolean mSmoothScrollbarEnabled;
    private int mSpanCount = -1;
    Span[] mSpans;
    private final Rect mTmpRect;

    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$1 */
    final class PG implements Runnable {
        public final void run() {
            StaggeredGridLayoutManager.this.checkForGaps();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$AnchorInfo */
    final class AnchorInfo {
        boolean mInvalidateOffsets;
        boolean mLayoutFromEnd;
        int mOffset;
        int mPosition;
        int[] mSpanReferenceLines;
        boolean mValid;

        public AnchorInfo() {
            reset();
        }

        final void reset() {
            this.mPosition = -1;
            this.mOffset = LinearLayoutManager.INVALID_OFFSET;
            this.mLayoutFromEnd = false;
            this.mInvalidateOffsets = false;
            this.mValid = false;
            int[] iArr = this.mSpanReferenceLines;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$LayoutParams */
    public final class LayoutParams extends android.support.p002v7.widget.RecyclerView.LayoutParams {
        boolean mFullSpan;
        Span mSpan;

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$LazySpanLookup */
    final class LazySpanLookup {
        int[] mData;
        List mFullSpanItems;

        /* compiled from: PG */
        /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem */
        final class FullSpanItem implements Parcelable {
            public static final Creator CREATOR = new PG();
            int mGapDir;
            int[] mGapPerSpan;
            boolean mHasUnwantedGapAfter;
            int mPosition;

            /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem$1 */
            final class PG implements Creator {
                public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                    return new FullSpanItem[i];
                }

                public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                    return new FullSpanItem(parcel);
                }
            }

            FullSpanItem() {
            }

            public final int describeContents() {
                return 0;
            }

            public final String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("FullSpanItem{mPosition=");
                stringBuilder.append(this.mPosition);
                stringBuilder.append(", mGapDir=");
                stringBuilder.append(this.mGapDir);
                stringBuilder.append(", mHasUnwantedGapAfter=");
                stringBuilder.append(this.mHasUnwantedGapAfter);
                stringBuilder.append(", mGapPerSpan=");
                stringBuilder.append(Arrays.toString(this.mGapPerSpan));
                stringBuilder.append('}');
                return stringBuilder.toString();
            }

            public final void writeToParcel(Parcel parcel, int i) {
                parcel.writeInt(this.mPosition);
                parcel.writeInt(this.mGapDir);
                parcel.writeInt(this.mHasUnwantedGapAfter);
                int[] iArr = this.mGapPerSpan;
                if (iArr != null) {
                    parcel.writeInt(iArr.length);
                    parcel.writeIntArray(this.mGapPerSpan);
                    return;
                }
                parcel.writeInt(0);
            }

            public FullSpanItem(Parcel parcel) {
                this.mPosition = parcel.readInt();
                this.mGapDir = parcel.readInt();
                boolean z = true;
                if (parcel.readInt() != 1) {
                    z = false;
                }
                this.mHasUnwantedGapAfter = z;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    int[] iArr = new int[readInt];
                    this.mGapPerSpan = iArr;
                    parcel.readIntArray(iArr);
                }
            }
        }

        final void clear() {
            int[] iArr = this.mData;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.mFullSpanItems = null;
        }

        final void ensureSize(int i) {
            Object obj = this.mData;
            if (obj == null) {
                int[] iArr = new int[(Math.max(i, 10) + 1)];
                this.mData = iArr;
                Arrays.fill(iArr, -1);
                return;
            }
            int length = obj.length;
            if (i >= length) {
                while (length <= i) {
                    length += length;
                }
                Object obj2 = new int[length];
                this.mData = obj2;
                length = obj.length;
                System.arraycopy(obj, 0, obj2, 0, length);
                iArr = this.mData;
                Arrays.fill(iArr, length, iArr.length, -1);
            }
        }

        final void offsetForAddition(int i, int i2) {
            int[] iArr = this.mData;
            if (iArr != null) {
                if (i < iArr.length) {
                    int i3 = i + i2;
                    ensureSize(i3);
                    Object obj = this.mData;
                    System.arraycopy(obj, i, obj, i3, (obj.length - i) - i2);
                    Arrays.fill(this.mData, i, i3, -1);
                    List list = this.mFullSpanItems;
                    if (list != null) {
                        for (i3 = list.size() - 1; i3 >= 0; i3--) {
                            FullSpanItem fullSpanItem = (FullSpanItem) this.mFullSpanItems.get(i3);
                            int i4 = fullSpanItem.mPosition;
                            if (i4 >= i) {
                                fullSpanItem.mPosition = i4 + i2;
                            }
                        }
                    }
                }
            }
        }

        final void offsetForRemoval(int i, int i2) {
            int[] iArr = this.mData;
            if (iArr != null) {
                if (i < iArr.length) {
                    int i3 = i + i2;
                    ensureSize(i3);
                    Object obj = this.mData;
                    System.arraycopy(obj, i3, obj, i, (obj.length - i) - i2);
                    int[] iArr2 = this.mData;
                    int length = iArr2.length;
                    Arrays.fill(iArr2, length - i2, length, -1);
                    List list = this.mFullSpanItems;
                    if (list != null) {
                        for (int size = list.size() - 1; size >= 0; size--) {
                            FullSpanItem fullSpanItem = (FullSpanItem) this.mFullSpanItems.get(size);
                            int i4 = fullSpanItem.mPosition;
                            if (i4 >= i) {
                                if (i4 < i3) {
                                    this.mFullSpanItems.remove(size);
                                } else {
                                    fullSpanItem.mPosition = i4 - i2;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$SavedState */
    public final class SavedState implements Parcelable {
        public static final Creator CREATOR = new PG();
        boolean mAnchorLayoutFromEnd;
        int mAnchorPosition;
        List mFullSpanItems;
        boolean mLastLayoutRTL;
        boolean mReverseLayout;
        int[] mSpanLookup;
        int mSpanLookupSize;
        int[] mSpanOffsets;
        int mSpanOffsetsSize;
        int mVisibleAnchorPosition;

        /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$SavedState$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new SavedState[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }
        }

        public SavedState(SavedState savedState) {
            this.mSpanOffsetsSize = savedState.mSpanOffsetsSize;
            this.mAnchorPosition = savedState.mAnchorPosition;
            this.mVisibleAnchorPosition = savedState.mVisibleAnchorPosition;
            this.mSpanOffsets = savedState.mSpanOffsets;
            this.mSpanLookupSize = savedState.mSpanLookupSize;
            this.mSpanLookup = savedState.mSpanLookup;
            this.mReverseLayout = savedState.mReverseLayout;
            this.mAnchorLayoutFromEnd = savedState.mAnchorLayoutFromEnd;
            this.mLastLayoutRTL = savedState.mLastLayoutRTL;
            this.mFullSpanItems = savedState.mFullSpanItems;
        }

        public final int describeContents() {
            return 0;
        }

        final void invalidateAnchorPositionInfo() {
            this.mSpanOffsets = null;
            this.mSpanOffsetsSize = 0;
            this.mAnchorPosition = -1;
            this.mVisibleAnchorPosition = -1;
        }

        final void invalidateSpanInfo() {
            this.mSpanOffsets = null;
            this.mSpanOffsetsSize = 0;
            this.mSpanLookupSize = 0;
            this.mSpanLookup = null;
            this.mFullSpanItems = null;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.mAnchorPosition);
            parcel.writeInt(this.mVisibleAnchorPosition);
            parcel.writeInt(this.mSpanOffsetsSize);
            if (this.mSpanOffsetsSize > 0) {
                parcel.writeIntArray(this.mSpanOffsets);
            }
            parcel.writeInt(this.mSpanLookupSize);
            if (this.mSpanLookupSize > 0) {
                parcel.writeIntArray(this.mSpanLookup);
            }
            parcel.writeInt(this.mReverseLayout);
            parcel.writeInt(this.mAnchorLayoutFromEnd);
            parcel.writeInt(this.mLastLayoutRTL);
            parcel.writeList(this.mFullSpanItems);
        }

        public SavedState(Parcel parcel) {
            boolean z;
            this.mAnchorPosition = parcel.readInt();
            this.mVisibleAnchorPosition = parcel.readInt();
            int readInt = parcel.readInt();
            this.mSpanOffsetsSize = readInt;
            if (readInt > 0) {
                int[] iArr = new int[readInt];
                this.mSpanOffsets = iArr;
                parcel.readIntArray(iArr);
            }
            readInt = parcel.readInt();
            this.mSpanLookupSize = readInt;
            if (readInt > 0) {
                iArr = new int[readInt];
                this.mSpanLookup = iArr;
                parcel.readIntArray(iArr);
            }
            boolean z2 = false;
            if (parcel.readInt() == 1) {
                z = true;
            } else {
                z = false;
            }
            this.mReverseLayout = z;
            if (parcel.readInt() == 1) {
                z = true;
            } else {
                z = false;
            }
            this.mAnchorLayoutFromEnd = z;
            if (parcel.readInt() == 1) {
                z2 = true;
            }
            this.mLastLayoutRTL = z2;
            this.mFullSpanItems = parcel.readArrayList(FullSpanItem.class.getClassLoader());
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$Span */
    final class Span {
        int mCachedEnd = LinearLayoutManager.INVALID_OFFSET;
        int mCachedStart = LinearLayoutManager.INVALID_OFFSET;
        int mDeletedSize = 0;
        final int mIndex;
        final ArrayList mViews = new ArrayList();

        public Span(int i) {
            this.mIndex = i;
        }

        static final LayoutParams getLayoutParams$ar$ds(View view) {
            return (LayoutParams) view.getLayoutParams();
        }

        final void calculateCachedEnd() {
            ArrayList arrayList = this.mViews;
            View view = (View) arrayList.get(arrayList.size() - 1);
            LayoutParams layoutParams$ar$ds = Span.getLayoutParams$ar$ds(view);
            this.mCachedEnd = StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedEnd(view);
            boolean z = layoutParams$ar$ds.mFullSpan;
        }

        final void calculateCachedStart() {
            View view = (View) this.mViews.get(0);
            LayoutParams layoutParams$ar$ds = Span.getLayoutParams$ar$ds(view);
            this.mCachedStart = StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedStart(view);
            boolean z = layoutParams$ar$ds.mFullSpan;
        }

        final void clear() {
            this.mViews.clear();
            this.mCachedStart = LinearLayoutManager.INVALID_OFFSET;
            this.mCachedEnd = LinearLayoutManager.INVALID_OFFSET;
            this.mDeletedSize = 0;
        }

        public final int findFirstPartiallyVisibleItemPosition() {
            return StaggeredGridLayoutManager.this.mReverseLayout ? findOnePartiallyVisibleChild$ar$ds(this.mViews.size() - 1, -1) : findOnePartiallyVisibleChild$ar$ds(0, this.mViews.size());
        }

        public final int findLastPartiallyVisibleItemPosition() {
            return StaggeredGridLayoutManager.this.mReverseLayout ? findOnePartiallyVisibleChild$ar$ds(0, this.mViews.size()) : findOnePartiallyVisibleChild$ar$ds(this.mViews.size() - 1, -1);
        }

        final int getEndLine() {
            int i = this.mCachedEnd;
            if (i != LinearLayoutManager.INVALID_OFFSET) {
                return i;
            }
            calculateCachedEnd();
            return this.mCachedEnd;
        }

        public final View getFocusableViewAfter(int i, int i2) {
            View view = null;
            if (i2 != -1) {
                i2 = this.mViews.size() - 1;
                while (i2 >= 0) {
                    View view2 = (View) this.mViews.get(i2);
                    LayoutManager layoutManager = StaggeredGridLayoutManager.this;
                    if (layoutManager.mReverseLayout && layoutManager.getPosition(view2) >= i) {
                        break;
                    }
                    layoutManager = StaggeredGridLayoutManager.this;
                    if (layoutManager.mReverseLayout || layoutManager.getPosition(view2) > i) {
                        if (!view2.hasFocusable()) {
                            break;
                        }
                        i2--;
                        view = view2;
                    } else {
                        break;
                    }
                }
            }
            i2 = this.mViews.size();
            int i3 = 0;
            while (i3 < i2) {
                View view3 = (View) this.mViews.get(i3);
                LayoutManager layoutManager2 = StaggeredGridLayoutManager.this;
                if (layoutManager2.mReverseLayout && layoutManager2.getPosition(view3) <= i) {
                    break;
                }
                layoutManager2 = StaggeredGridLayoutManager.this;
                if (layoutManager2.mReverseLayout || layoutManager2.getPosition(view3) < i) {
                    if (!view3.hasFocusable()) {
                        break;
                    }
                    i3++;
                    view = view3;
                } else {
                    break;
                }
            }
            return view;
        }

        final int getStartLine() {
            int i = this.mCachedStart;
            if (i != LinearLayoutManager.INVALID_OFFSET) {
                return i;
            }
            calculateCachedStart();
            return this.mCachedStart;
        }

        final void onOffset(int i) {
            int i2 = this.mCachedStart;
            if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                this.mCachedStart = i2 + i;
            }
            i2 = this.mCachedEnd;
            if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                this.mCachedEnd = i2 + i;
            }
        }

        final void setLine(int i) {
            this.mCachedStart = i;
            this.mCachedEnd = i;
        }

        final int findOnePartiallyVisibleChild$ar$ds(int i, int i2) {
            int i3;
            int startAfterPadding = StaggeredGridLayoutManager.this.mPrimaryOrientation.getStartAfterPadding();
            int endAfterPadding = StaggeredGridLayoutManager.this.mPrimaryOrientation.getEndAfterPadding();
            if (i2 > i) {
                i3 = 1;
            } else {
                i3 = -1;
            }
            while (i != i2) {
                Object obj;
                View view = (View) this.mViews.get(i);
                int decoratedStart = StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedStart(view);
                int decoratedEnd = StaggeredGridLayoutManager.this.mPrimaryOrientation.getDecoratedEnd(view);
                Object obj2 = null;
                if (decoratedStart <= endAfterPadding) {
                    obj = 1;
                } else {
                    obj = null;
                }
                if (decoratedEnd >= startAfterPadding) {
                    obj2 = 1;
                }
                if (obj != null && obj2 != null && (decoratedStart < startAfterPadding || decoratedEnd > endAfterPadding)) {
                    return StaggeredGridLayoutManager.this.getPosition(view);
                }
                i += i3;
            }
            return -1;
        }

        final int getEndLine(int i) {
            int i2 = this.mCachedEnd;
            if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                return i2;
            }
            if (this.mViews.size() == 0) {
                return i;
            }
            calculateCachedEnd();
            return this.mCachedEnd;
        }

        final int getStartLine(int i) {
            int i2 = this.mCachedStart;
            if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                return i2;
            }
            if (this.mViews.size() == 0) {
                return i;
            }
            calculateCachedStart();
            return this.mCachedStart;
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        int i3 = 0;
        this.mReverseLayout = false;
        this.mShouldReverseLayout = false;
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = LinearLayoutManager.INVALID_OFFSET;
        this.mLazySpanLookup = new LazySpanLookup();
        this.mGapStrategy = 2;
        this.mTmpRect = new Rect();
        this.mAnchorInfo = new AnchorInfo();
        this.mSmoothScrollbarEnabled = true;
        this.mCheckForGapsRunnable = new PG();
        Properties properties = LayoutManager.getProperties(context, attributeSet, i, i2);
        int i4 = properties.orientation;
        if (i4 != 0) {
            if (i4 != 1) {
                throw new IllegalArgumentException("invalid orientation.");
            }
        }
        assertNotInLayoutOrScroll(null);
        if (i4 != this.mOrientation) {
            this.mOrientation = i4;
            OrientationHelper orientationHelper = this.mPrimaryOrientation;
            this.mPrimaryOrientation = this.mSecondaryOrientation;
            this.mSecondaryOrientation = orientationHelper;
            requestLayout();
        }
        i4 = properties.spanCount;
        assertNotInLayoutOrScroll(null);
        if (i4 != this.mSpanCount) {
            this.mLazySpanLookup.clear();
            requestLayout();
            this.mSpanCount = i4;
            this.mRemainingSpans = new BitSet(i4);
            this.mSpans = new Span[this.mSpanCount];
            while (i3 < this.mSpanCount) {
                this.mSpans[i3] = new Span(i3);
                i3++;
            }
            requestLayout();
        }
        setReverseLayout(properties.reverseLayout);
        this.mLayoutState = new LayoutState();
        this.mPrimaryOrientation = OrientationHelper.createOrientationHelper(this, this.mOrientation);
        this.mSecondaryOrientation = OrientationHelper.createOrientationHelper(this, 1 - this.mOrientation);
    }

    private final int calculateScrollDirectionForPosition(int i) {
        if (getChildCount() == 0) {
            return this.mShouldReverseLayout ? 1 : -1;
        } else {
            return (i < getFirstChildPosition()) != this.mShouldReverseLayout ? -1 : 1;
        }
    }

    private final int computeScrollExtent(State state) {
        if (getChildCount() == 0) {
            return 0;
        }
        return ScrollbarHelper.computeScrollExtent(state, this.mPrimaryOrientation, findFirstVisibleItemClosestToStart(this.mSmoothScrollbarEnabled ^ 1), findFirstVisibleItemClosestToEnd(this.mSmoothScrollbarEnabled ^ 1), this, this.mSmoothScrollbarEnabled);
    }

    private final int computeScrollOffset(State state) {
        if (getChildCount() == 0) {
            return 0;
        }
        return ScrollbarHelper.computeScrollOffset(state, this.mPrimaryOrientation, findFirstVisibleItemClosestToStart(this.mSmoothScrollbarEnabled ^ 1), findFirstVisibleItemClosestToEnd(this.mSmoothScrollbarEnabled ^ 1), this, this.mSmoothScrollbarEnabled, this.mShouldReverseLayout);
    }

    private final int computeScrollRange(State state) {
        if (getChildCount() == 0) {
            return 0;
        }
        return ScrollbarHelper.computeScrollRange(state, this.mPrimaryOrientation, findFirstVisibleItemClosestToStart(this.mSmoothScrollbarEnabled ^ 1), findFirstVisibleItemClosestToEnd(this.mSmoothScrollbarEnabled ^ 1), this, this.mSmoothScrollbarEnabled);
    }

    private final int fill(Recycler recycler, LayoutState layoutState, State state) {
        int i;
        int i2;
        Recycler recycler2 = recycler;
        LayoutState layoutState2 = layoutState;
        boolean z = true;
        this.mRemainingSpans.set(0, this.mSpanCount, true);
        if (this.mLayoutState.mInfinite) {
            if (layoutState2.mLayoutDirection == 1) {
                i = Integer.MAX_VALUE;
            } else {
                i = LinearLayoutManager.INVALID_OFFSET;
            }
        } else if (layoutState2.mLayoutDirection == 1) {
            i = layoutState2.mEndLine + layoutState2.mAvailable;
        } else {
            i = layoutState2.mStartLine - layoutState2.mAvailable;
        }
        int i3 = layoutState2.mLayoutDirection;
        for (i2 = 0; i2 < r6.mSpanCount; i2++) {
            if (!r6.mSpans[i2].mViews.isEmpty()) {
                updateRemainingSpans(r6.mSpans[i2], i3, i);
            }
        }
        int endAfterPadding = r6.mShouldReverseLayout ? r6.mPrimaryOrientation.getEndAfterPadding() : r6.mPrimaryOrientation.getStartAfterPadding();
        Object obj = null;
        while (layoutState.hasMore(state) && (r6.mLayoutState.mInfinite || !r6.mRemainingSpans.isEmpty())) {
            int i4;
            int i5;
            int i6;
            int startAfterPadding;
            int endAfterPadding2;
            Span span;
            LayoutParams layoutParams;
            View viewForPosition = recycler2.getViewForPosition(layoutState2.mCurrentPosition);
            layoutState2.mCurrentPosition += layoutState2.mItemDirection;
            LayoutParams layoutParams2 = (LayoutParams) viewForPosition.getLayoutParams();
            i3 = layoutParams2.getViewLayoutPosition();
            int[] iArr = r6.mLazySpanLookup.mData;
            i2 = iArr != null ? i3 >= iArr.length ? -1 : iArr[i3] : -1;
            if (i2 == -1) {
                Span span2;
                boolean z2 = layoutParams2.mFullSpan;
                if (preferLastSpan(layoutState2.mLayoutDirection)) {
                    i4 = r6.mSpanCount - 1;
                    i5 = -1;
                    i6 = -1;
                } else {
                    i5 = r6.mSpanCount;
                    i4 = 0;
                    i6 = 1;
                }
                Span span3 = null;
                int i7;
                int endLine;
                int i8;
                if (layoutState2.mLayoutDirection == z) {
                    startAfterPadding = r6.mPrimaryOrientation.getStartAfterPadding();
                    i7 = Integer.MAX_VALUE;
                    while (i4 != i5) {
                        span2 = r6.mSpans[i4];
                        endLine = span2.getEndLine(startAfterPadding);
                        i8 = endLine < i7 ? endLine : i7;
                        if (endLine < i7) {
                            span3 = span2;
                        }
                        i4 += i6;
                        i7 = i8;
                    }
                    span2 = span3;
                } else {
                    endAfterPadding2 = r6.mPrimaryOrientation.getEndAfterPadding();
                    endLine = LinearLayoutManager.INVALID_OFFSET;
                    while (i4 != i5) {
                        Span span4 = r6.mSpans[i4];
                        i7 = span4.getStartLine(endAfterPadding2);
                        i8 = i7 > endLine ? i7 : endLine;
                        if (i7 > endLine) {
                            span3 = span4;
                        }
                        i4 += i6;
                        endLine = i8;
                    }
                    span2 = span3;
                }
                LazySpanLookup lazySpanLookup = r6.mLazySpanLookup;
                lazySpanLookup.ensureSize(i3);
                lazySpanLookup.mData[i3] = span2.mIndex;
                span = span2;
            } else {
                span = r6.mSpans[i2];
            }
            layoutParams2.mSpan = span;
            if (layoutState2.mLayoutDirection == z) {
                addView(viewForPosition);
            } else {
                addView(viewForPosition, 0);
            }
            boolean z3 = layoutParams2.mFullSpan;
            if (r6.mOrientation == z) {
                measureChildWithDecorationsAndMargin$ar$ds(viewForPosition, LayoutManager.getChildMeasureSpec(r6.mSizePerSpan, getWidthMode(), 0, layoutParams2.width, false), LayoutManager.getChildMeasureSpec(getHeight(), getHeightMode(), getPaddingTop() + getPaddingBottom(), layoutParams2.height, z));
            } else {
                measureChildWithDecorationsAndMargin$ar$ds(viewForPosition, LayoutManager.getChildMeasureSpec(getWidth(), getWidthMode(), getPaddingLeft() + getPaddingRight(), layoutParams2.width, z), LayoutManager.getChildMeasureSpec(r6.mSizePerSpan, getHeightMode(), 0, layoutParams2.height, false));
            }
            boolean z4;
            if (layoutState2.mLayoutDirection == z) {
                z3 = layoutParams2.mFullSpan;
                i3 = span.getEndLine(endAfterPadding);
                endAfterPadding2 = r6.mPrimaryOrientation.getDecoratedMeasurement(viewForPosition) + i3;
                if (i2 == -1) {
                    z4 = layoutParams2.mFullSpan;
                }
                i4 = i3;
                startAfterPadding = endAfterPadding2;
            } else {
                z3 = layoutParams2.mFullSpan;
                i3 = span.getStartLine(endAfterPadding);
                endAfterPadding2 = i3 - r6.mPrimaryOrientation.getDecoratedMeasurement(viewForPosition);
                if (i2 == -1) {
                    z4 = layoutParams2.mFullSpan;
                }
                startAfterPadding = i3;
                i4 = endAfterPadding2;
            }
            z3 = layoutParams2.mFullSpan;
            Span span5;
            LayoutParams layoutParams$ar$ds;
            if (layoutState2.mLayoutDirection == z) {
                span5 = layoutParams2.mSpan;
                layoutParams$ar$ds = Span.getLayoutParams$ar$ds(viewForPosition);
                layoutParams$ar$ds.mSpan = span5;
                span5.mViews.add(viewForPosition);
                span5.mCachedEnd = LinearLayoutManager.INVALID_OFFSET;
                if (span5.mViews.size() == z) {
                    span5.mCachedStart = LinearLayoutManager.INVALID_OFFSET;
                }
                if (!layoutParams$ar$ds.isItemRemoved()) {
                    if (layoutParams$ar$ds.isItemChanged()) {
                    }
                }
                span5.mDeletedSize += span5.this$0.mPrimaryOrientation.getDecoratedMeasurement(viewForPosition);
            } else {
                span5 = layoutParams2.mSpan;
                layoutParams$ar$ds = Span.getLayoutParams$ar$ds(viewForPosition);
                layoutParams$ar$ds.mSpan = span5;
                span5.mViews.add(0, viewForPosition);
                span5.mCachedStart = LinearLayoutManager.INVALID_OFFSET;
                if (span5.mViews.size() == z) {
                    span5.mCachedEnd = LinearLayoutManager.INVALID_OFFSET;
                }
                if (layoutParams$ar$ds.isItemRemoved() || layoutParams$ar$ds.isItemChanged()) {
                    span5.mDeletedSize += span5.this$0.mPrimaryOrientation.getDecoratedMeasurement(viewForPosition);
                }
            }
            if (isLayoutRTL() && r6.mOrientation == z) {
                z3 = layoutParams2.mFullSpan;
                i3 = r6.mSecondaryOrientation.getEndAfterPadding() - (((r6.mSpanCount - 1) - span.mIndex) * r6.mSizePerSpan);
                i6 = i3;
                i5 = i3 - r6.mSecondaryOrientation.getDecoratedMeasurement(viewForPosition);
            } else {
                z3 = layoutParams2.mFullSpan;
                i3 = (span.mIndex * r6.mSizePerSpan) + r6.mSecondaryOrientation.getStartAfterPadding();
                i5 = i3;
                i6 = r6.mSecondaryOrientation.getDecoratedMeasurement(viewForPosition) + i3;
            }
            if (r6.mOrientation == z) {
                layoutParams = layoutParams2;
                layoutDecoratedWithMargins(viewForPosition, i5, i4, i6, startAfterPadding);
            } else {
                layoutParams = layoutParams2;
                layoutDecoratedWithMargins(viewForPosition, i4, i5, startAfterPadding, i6);
            }
            z3 = layoutParams.mFullSpan;
            updateRemainingSpans(span, r6.mLayoutState.mLayoutDirection, i);
            recycle(recycler2, r6.mLayoutState);
            if (r6.mLayoutState.mStopInFocusable && viewForPosition.hasFocusable()) {
                z3 = layoutParams.mFullSpan;
                r6.mRemainingSpans.set(span.mIndex, false);
            }
            obj = 1;
            z = true;
        }
        if (obj == null) {
            recycle(recycler2, r6.mLayoutState);
        }
        if (r6.mLayoutState.mLayoutDirection == -1) {
            i2 = r6.mPrimaryOrientation.getStartAfterPadding() - getMinStart(r6.mPrimaryOrientation.getStartAfterPadding());
        } else {
            i2 = getMaxEnd(r6.mPrimaryOrientation.getEndAfterPadding()) - r6.mPrimaryOrientation.getEndAfterPadding();
        }
        return i2 > 0 ? Math.min(layoutState2.mAvailable, i2) : 0;
    }

    private final void fixEndGap(Recycler recycler, State state, boolean z) {
        int maxEnd = getMaxEnd(LinearLayoutManager.INVALID_OFFSET);
        if (maxEnd != LinearLayoutManager.INVALID_OFFSET) {
            int endAfterPadding = this.mPrimaryOrientation.getEndAfterPadding() - maxEnd;
            if (endAfterPadding > 0) {
                endAfterPadding -= -scrollBy(-endAfterPadding, recycler, state);
                if (z && endAfterPadding > 0) {
                    this.mPrimaryOrientation.offsetChildren(endAfterPadding);
                }
            }
        }
    }

    private final void fixStartGap(Recycler recycler, State state, boolean z) {
        int minStart = getMinStart(Integer.MAX_VALUE);
        if (minStart != Integer.MAX_VALUE) {
            minStart -= this.mPrimaryOrientation.getStartAfterPadding();
            if (minStart > 0) {
                minStart -= scrollBy(minStart, recycler, state);
                if (z && minStart > 0) {
                    this.mPrimaryOrientation.offsetChildren(-minStart);
                }
            }
        }
    }

    private final int getMaxEnd(int i) {
        int endLine = this.mSpans[0].getEndLine(i);
        for (int i2 = 1; i2 < this.mSpanCount; i2++) {
            int endLine2 = this.mSpans[i2].getEndLine(i);
            if (endLine2 > endLine) {
                endLine = endLine2;
            }
        }
        return endLine;
    }

    private final int getMinStart(int i) {
        int startLine = this.mSpans[0].getStartLine(i);
        for (int i2 = 1; i2 < this.mSpanCount; i2++) {
            int startLine2 = this.mSpans[i2].getStartLine(i);
            if (startLine2 < startLine) {
                startLine = startLine2;
            }
        }
        return startLine;
    }

    private final void handleUpdate(int i, int i2, int i3) {
        int i4;
        int i5;
        int lastChildPosition = this.mShouldReverseLayout ? getLastChildPosition() : getFirstChildPosition();
        if (i3 != 8) {
            i4 = i + i2;
            i5 = i;
        } else if (i < i2) {
            i4 = i2 + 1;
            i5 = i;
        } else {
            i4 = i + 1;
            i5 = i2;
        }
        LazySpanLookup lazySpanLookup = this.mLazySpanLookup;
        int[] iArr = lazySpanLookup.mData;
        if (iArr != null) {
            if (i5 < iArr.length) {
                int i6;
                List list = lazySpanLookup.mFullSpanItems;
                if (list == null) {
                    i6 = -1;
                } else {
                    Object obj;
                    for (i6 = list.size() - 1; i6 >= 0; i6--) {
                        obj = (FullSpanItem) lazySpanLookup.mFullSpanItems.get(i6);
                        if (obj.mPosition == i5) {
                            break;
                        }
                    }
                    obj = null;
                    if (obj != null) {
                        lazySpanLookup.mFullSpanItems.remove(obj);
                    }
                    i6 = lazySpanLookup.mFullSpanItems.size();
                    int i7 = 0;
                    while (i7 < i6) {
                        if (((FullSpanItem) lazySpanLookup.mFullSpanItems.get(i7)).mPosition >= i5) {
                            break;
                        }
                        i7++;
                    }
                    i7 = -1;
                    if (i7 != -1) {
                        FullSpanItem fullSpanItem = (FullSpanItem) lazySpanLookup.mFullSpanItems.get(i7);
                        lazySpanLookup.mFullSpanItems.remove(i7);
                        i6 = fullSpanItem.mPosition;
                    } else {
                        i6 = -1;
                    }
                }
                if (i6 == -1) {
                    iArr = lazySpanLookup.mData;
                    Arrays.fill(iArr, i5, iArr.length, -1);
                    int length = lazySpanLookup.mData.length;
                } else {
                    Arrays.fill(lazySpanLookup.mData, i5, Math.min(i6 + 1, lazySpanLookup.mData.length), -1);
                }
            }
        }
        switch (i3) {
            case 1:
                this.mLazySpanLookup.offsetForAddition(i, i2);
                break;
            case 2:
                this.mLazySpanLookup.offsetForRemoval(i, i2);
                break;
            case 8:
                this.mLazySpanLookup.offsetForRemoval(i, 1);
                this.mLazySpanLookup.offsetForAddition(i2, 1);
                break;
            default:
                break;
        }
        if (i4 > lastChildPosition) {
            if (i5 <= (this.mShouldReverseLayout ? getFirstChildPosition() : getLastChildPosition())) {
                requestLayout();
            }
        }
    }

    private final void measureChildWithDecorationsAndMargin$ar$ds(View view, int i, int i2) {
        calculateItemDecorationsForChild(view, this.mTmpRect);
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        i = StaggeredGridLayoutManager.updateSpecWithExtra$ar$ds(i, layoutParams.leftMargin + this.mTmpRect.left, layoutParams.rightMargin + this.mTmpRect.right);
        i2 = StaggeredGridLayoutManager.updateSpecWithExtra$ar$ds(i2, layoutParams.topMargin + this.mTmpRect.top, layoutParams.bottomMargin + this.mTmpRect.bottom);
        if (shouldMeasureChild(view, i, i2, layoutParams)) {
            view.measure(i, i2);
        }
    }

    private final void onLayoutChildren(Recycler recycler, State state, boolean z) {
        AnchorInfo anchorInfo = this.mAnchorInfo;
        if (!(this.mPendingSavedState == null && this.mPendingScrollPosition == -1) && state.getItemCount() == 0) {
            removeAndRecycleAllViews(recycler);
            anchorInfo.reset();
            return;
        }
        SavedState savedState;
        int i;
        int i2;
        int i3;
        View findViewByPosition;
        int position;
        int i4;
        boolean z2 = true;
        Object obj = (anchorInfo.mValid && this.mPendingScrollPosition == -1) ? this.mPendingSavedState != null ? 1 : null : 1;
        if (obj != null) {
            anchorInfo.reset();
            savedState = this.mPendingSavedState;
            if (savedState != null) {
                i = savedState.mSpanOffsetsSize;
                if (i > 0) {
                    if (i == this.mSpanCount) {
                        for (i2 = 0; i2 < this.mSpanCount; i2++) {
                            this.mSpans[i2].clear();
                            SavedState savedState2 = this.mPendingSavedState;
                            i3 = savedState2.mSpanOffsets[i2];
                            if (i3 != LinearLayoutManager.INVALID_OFFSET) {
                                if (savedState2.mAnchorLayoutFromEnd) {
                                    i3 += this.mPrimaryOrientation.getEndAfterPadding();
                                } else {
                                    i3 += this.mPrimaryOrientation.getStartAfterPadding();
                                }
                            }
                            this.mSpans[i2].setLine(i3);
                        }
                    } else {
                        savedState.invalidateSpanInfo();
                        savedState = this.mPendingSavedState;
                        savedState.mAnchorPosition = savedState.mVisibleAnchorPosition;
                    }
                }
                savedState = this.mPendingSavedState;
                this.mLastLayoutRTL = savedState.mLastLayoutRTL;
                setReverseLayout(savedState.mReverseLayout);
                resolveShouldLayoutReverse();
                savedState = this.mPendingSavedState;
                i = savedState.mAnchorPosition;
                if (i != -1) {
                    this.mPendingScrollPosition = i;
                    anchorInfo.mLayoutFromEnd = savedState.mAnchorLayoutFromEnd;
                } else {
                    anchorInfo.mLayoutFromEnd = this.mShouldReverseLayout;
                }
                if (savedState.mSpanLookupSize > 1) {
                    LazySpanLookup lazySpanLookup = this.mLazySpanLookup;
                    lazySpanLookup.mData = savedState.mSpanLookup;
                    lazySpanLookup.mFullSpanItems = savedState.mFullSpanItems;
                }
            } else {
                resolveShouldLayoutReverse();
                anchorInfo.mLayoutFromEnd = this.mShouldReverseLayout;
            }
            if (!state.mInPreLayout) {
                i2 = this.mPendingScrollPosition;
                if (i2 != -1) {
                    if (i2 >= 0) {
                        if (i2 < state.getItemCount()) {
                            savedState = this.mPendingSavedState;
                            if (!(savedState == null || savedState.mAnchorPosition == -1)) {
                                if (savedState.mSpanOffsetsSize > 0) {
                                    anchorInfo.mOffset = LinearLayoutManager.INVALID_OFFSET;
                                    anchorInfo.mPosition = this.mPendingScrollPosition;
                                    anchorInfo.mValid = true;
                                }
                            }
                            findViewByPosition = findViewByPosition(this.mPendingScrollPosition);
                            if (findViewByPosition != null) {
                                anchorInfo.mPosition = this.mShouldReverseLayout ? getLastChildPosition() : getFirstChildPosition();
                                if (this.mPendingScrollPositionOffset != LinearLayoutManager.INVALID_OFFSET) {
                                    if (anchorInfo.mLayoutFromEnd) {
                                        anchorInfo.mOffset = (this.mPrimaryOrientation.getEndAfterPadding() - this.mPendingScrollPositionOffset) - this.mPrimaryOrientation.getDecoratedEnd(findViewByPosition);
                                    } else {
                                        anchorInfo.mOffset = (this.mPrimaryOrientation.getStartAfterPadding() + this.mPendingScrollPositionOffset) - this.mPrimaryOrientation.getDecoratedStart(findViewByPosition);
                                    }
                                } else if (this.mPrimaryOrientation.getDecoratedMeasurement(findViewByPosition) > this.mPrimaryOrientation.getTotalSpace()) {
                                    anchorInfo.mOffset = anchorInfo.mLayoutFromEnd ? this.mPrimaryOrientation.getEndAfterPadding() : this.mPrimaryOrientation.getStartAfterPadding();
                                } else {
                                    i = this.mPrimaryOrientation.getDecoratedStart(findViewByPosition) - this.mPrimaryOrientation.getStartAfterPadding();
                                    if (i < 0) {
                                        anchorInfo.mOffset = -i;
                                    } else {
                                        i = this.mPrimaryOrientation.getEndAfterPadding() - this.mPrimaryOrientation.getDecoratedEnd(findViewByPosition);
                                        if (i < 0) {
                                            anchorInfo.mOffset = i;
                                        } else {
                                            anchorInfo.mOffset = LinearLayoutManager.INVALID_OFFSET;
                                        }
                                    }
                                }
                            } else {
                                i2 = this.mPendingScrollPosition;
                                anchorInfo.mPosition = i2;
                                i = this.mPendingScrollPositionOffset;
                                if (i == LinearLayoutManager.INVALID_OFFSET) {
                                    boolean z3;
                                    if (calculateScrollDirectionForPosition(i2) == 1) {
                                        z3 = true;
                                    } else {
                                        z3 = false;
                                    }
                                    anchorInfo.mLayoutFromEnd = z3;
                                    anchorInfo.mOffset = z3 ? anchorInfo.this$0.mPrimaryOrientation.getEndAfterPadding() : anchorInfo.this$0.mPrimaryOrientation.getStartAfterPadding();
                                } else if (anchorInfo.mLayoutFromEnd) {
                                    anchorInfo.mOffset = anchorInfo.this$0.mPrimaryOrientation.getEndAfterPadding() - i;
                                } else {
                                    anchorInfo.mOffset = anchorInfo.this$0.mPrimaryOrientation.getStartAfterPadding() + i;
                                }
                                anchorInfo.mInvalidateOffsets = true;
                            }
                            anchorInfo.mValid = true;
                        }
                    }
                    this.mPendingScrollPosition = -1;
                    this.mPendingScrollPositionOffset = LinearLayoutManager.INVALID_OFFSET;
                }
            }
            if (this.mLastLayoutFromEnd) {
                i2 = state.getItemCount();
                for (i = getChildCount() - 1; i >= 0; i--) {
                    i3 = getPosition(getChildAt(i));
                    if (i3 >= 0 && i3 < i2) {
                        break;
                    }
                }
                i3 = 0;
            } else {
                i2 = state.getItemCount();
                i = getChildCount();
                for (i3 = 0; i3 < i; i3++) {
                    position = getPosition(getChildAt(i3));
                    if (position >= 0 && position < i2) {
                        i3 = position;
                        break;
                    }
                }
                i3 = 0;
            }
            anchorInfo.mPosition = i3;
            anchorInfo.mOffset = LinearLayoutManager.INVALID_OFFSET;
            anchorInfo.mValid = true;
        }
        if (this.mPendingSavedState == null && this.mPendingScrollPosition == -1 && !(anchorInfo.mLayoutFromEnd == this.mLastLayoutFromEnd && isLayoutRTL() == this.mLastLayoutRTL)) {
            this.mLazySpanLookup.clear();
            anchorInfo.mInvalidateOffsets = true;
        }
        if (getChildCount() > 0) {
            savedState = this.mPendingSavedState;
            if (savedState == null || savedState.mSpanOffsetsSize <= 0) {
                if (anchorInfo.mInvalidateOffsets) {
                    for (i4 = 0; i4 < this.mSpanCount; i4++) {
                        this.mSpans[i4].clear();
                        i2 = anchorInfo.mOffset;
                        if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                            this.mSpans[i4].setLine(i2);
                        }
                    }
                } else {
                    Span span;
                    if (obj != null) {
                        i4 = 0;
                    } else if (this.mAnchorInfo.mSpanReferenceLines == null) {
                        i4 = 0;
                    } else {
                        for (i4 = 0; i4 < this.mSpanCount; i4++) {
                            span = this.mSpans[i4];
                            span.clear();
                            span.setLine(this.mAnchorInfo.mSpanReferenceLines[i4]);
                        }
                    }
                    while (i4 < this.mSpanCount) {
                        span = this.mSpans[i4];
                        boolean z4 = this.mShouldReverseLayout;
                        i3 = anchorInfo.mOffset;
                        position = z4 ? span.getEndLine(LinearLayoutManager.INVALID_OFFSET) : span.getStartLine(LinearLayoutManager.INVALID_OFFSET);
                        span.clear();
                        if (position != LinearLayoutManager.INVALID_OFFSET) {
                            if ((!z4 || position >= span.this$0.mPrimaryOrientation.getEndAfterPadding()) && (z4 || position <= span.this$0.mPrimaryOrientation.getStartAfterPadding())) {
                                if (i3 != LinearLayoutManager.INVALID_OFFSET) {
                                    position += i3;
                                }
                                span.mCachedEnd = position;
                                span.mCachedStart = position;
                            }
                        }
                        i4++;
                    }
                    AnchorInfo anchorInfo2 = this.mAnchorInfo;
                    Span[] spanArr = this.mSpans;
                    i = spanArr.length;
                    int[] iArr = anchorInfo2.mSpanReferenceLines;
                    if (iArr != null) {
                        if (iArr.length >= i) {
                            i3 = 0;
                            while (i3 < i) {
                                anchorInfo2.mSpanReferenceLines[i3] = spanArr[i3].getStartLine(LinearLayoutManager.INVALID_OFFSET);
                                i3++;
                            }
                        }
                    }
                    anchorInfo2.mSpanReferenceLines = new int[anchorInfo2.this$0.mSpans.length];
                    i3 = 0;
                    while (i3 < i) {
                        anchorInfo2.mSpanReferenceLines[i3] = spanArr[i3].getStartLine(LinearLayoutManager.INVALID_OFFSET);
                        i3++;
                    }
                }
            }
        }
        detachAndScrapAttachedViews(recycler);
        this.mLayoutState.mRecycle = false;
        updateMeasureSpecs(this.mSecondaryOrientation.getTotalSpace());
        updateLayoutState(anchorInfo.mPosition, state);
        LayoutState layoutState;
        if (anchorInfo.mLayoutFromEnd) {
            setLayoutStateDirection(-1);
            fill(recycler, this.mLayoutState, state);
            setLayoutStateDirection(1);
            layoutState = this.mLayoutState;
            layoutState.mCurrentPosition = anchorInfo.mPosition + layoutState.mItemDirection;
            fill(recycler, layoutState, state);
        } else {
            setLayoutStateDirection(1);
            fill(recycler, this.mLayoutState, state);
            setLayoutStateDirection(-1);
            layoutState = this.mLayoutState;
            layoutState.mCurrentPosition = anchorInfo.mPosition + layoutState.mItemDirection;
            fill(recycler, layoutState, state);
        }
        if (this.mSecondaryOrientation.getMode() != 1073741824) {
            LayoutParams layoutParams;
            i4 = getChildCount();
            float f = 0.0f;
            for (i = 0; i < i4; i++) {
                View childAt = getChildAt(i);
                float decoratedMeasurement = (float) this.mSecondaryOrientation.getDecoratedMeasurement(childAt);
                if (decoratedMeasurement >= f) {
                    layoutParams = (LayoutParams) childAt.getLayoutParams();
                    f = Math.max(f, decoratedMeasurement);
                }
            }
            i = this.mSizePerSpan;
            i2 = Math.round(f * ((float) this.mSpanCount));
            if (this.mSecondaryOrientation.getMode() == LinearLayoutManager.INVALID_OFFSET) {
                i2 = Math.min(i2, this.mSecondaryOrientation.getTotalSpace());
            }
            updateMeasureSpecs(i2);
            if (this.mSizePerSpan != i) {
                for (int i5 = 0; i5 < i4; i5++) {
                    findViewByPosition = getChildAt(i5);
                    layoutParams = (LayoutParams) findViewByPosition.getLayoutParams();
                    boolean z5 = layoutParams.mFullSpan;
                    if (isLayoutRTL() && this.mOrientation == 1) {
                        i3 = -((this.mSpanCount - 1) - layoutParams.mSpan.mIndex);
                        findViewByPosition.offsetLeftAndRight((this.mSizePerSpan * i3) - (i3 * i));
                    } else {
                        i3 = layoutParams.mSpan.mIndex;
                        position = this.mSizePerSpan * i3;
                        i3 *= i;
                        if (this.mOrientation == 1) {
                            findViewByPosition.offsetLeftAndRight(position - i3);
                        } else {
                            findViewByPosition.offsetTopAndBottom(position - i3);
                        }
                    }
                }
            }
        }
        if (getChildCount() > 0) {
            if (this.mShouldReverseLayout) {
                fixEndGap(recycler, state, true);
                fixStartGap(recycler, state, false);
            } else {
                fixStartGap(recycler, state, true);
                fixEndGap(recycler, state, false);
            }
        }
        if (!(!z || state.mInPreLayout || this.mGapStrategy == 0 || getChildCount() <= 0 || hasGapsToFix() == null)) {
            removeCallbacks(this.mCheckForGapsRunnable);
            if (checkForGaps()) {
                if (state.mInPreLayout) {
                    this.mAnchorInfo.reset();
                }
                this.mLastLayoutFromEnd = anchorInfo.mLayoutFromEnd;
                this.mLastLayoutRTL = isLayoutRTL();
                if (z2) {
                    this.mAnchorInfo.reset();
                    onLayoutChildren(recycler, state, false);
                }
            }
        }
        z2 = false;
        if (state.mInPreLayout) {
            this.mAnchorInfo.reset();
        }
        this.mLastLayoutFromEnd = anchorInfo.mLayoutFromEnd;
        this.mLastLayoutRTL = isLayoutRTL();
        if (z2) {
            this.mAnchorInfo.reset();
            onLayoutChildren(recycler, state, false);
        }
    }

    private final boolean preferLastSpan(int i) {
        if (this.mOrientation == 0) {
            return (i == -1) != this.mShouldReverseLayout;
        } else {
            return ((i == -1) == this.mShouldReverseLayout) == isLayoutRTL();
        }
    }

    private final void recycle(Recycler recycler, LayoutState layoutState) {
        if (layoutState.mRecycle) {
            if (!layoutState.mInfinite) {
                if (layoutState.mAvailable != 0) {
                    int i = 1;
                    int i2;
                    int startLine;
                    int startLine2;
                    int i3;
                    if (layoutState.mLayoutDirection == -1) {
                        i2 = layoutState.mStartLine;
                        startLine = this.mSpans[0].getStartLine(i2);
                        while (i < this.mSpanCount) {
                            startLine2 = this.mSpans[i].getStartLine(i2);
                            if (startLine2 > startLine) {
                                startLine = startLine2;
                            }
                            i++;
                        }
                        i2 -= startLine;
                        if (i2 < 0) {
                            i3 = layoutState.mEndLine;
                        } else {
                            i3 = layoutState.mEndLine - Math.min(i2, layoutState.mAvailable);
                        }
                        recycleFromEnd(recycler, i3);
                        return;
                    }
                    i2 = layoutState.mEndLine;
                    startLine = this.mSpans[0].getEndLine(i2);
                    while (i < this.mSpanCount) {
                        startLine2 = this.mSpans[i].getEndLine(i2);
                        if (startLine2 < startLine) {
                            startLine = startLine2;
                        }
                        i++;
                    }
                    startLine -= layoutState.mEndLine;
                    if (startLine < 0) {
                        i3 = layoutState.mStartLine;
                    } else {
                        i3 = Math.min(startLine, layoutState.mAvailable) + layoutState.mStartLine;
                    }
                    recycleFromStart(recycler, i3);
                } else if (layoutState.mLayoutDirection == -1) {
                    recycleFromEnd(recycler, layoutState.mEndLine);
                } else {
                    recycleFromStart(recycler, layoutState.mStartLine);
                }
            }
        }
    }

    private final void recycleFromEnd(Recycler recycler, int i) {
        int childCount = getChildCount() - 1;
        while (childCount >= 0) {
            View childAt = getChildAt(childCount);
            if (this.mPrimaryOrientation.getDecoratedStart(childAt) < i || this.mPrimaryOrientation.getTransformedStartWithDecoration(childAt) < i) {
                break;
            }
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            boolean z = layoutParams.mFullSpan;
            if (layoutParams.mSpan.mViews.size() != 1) {
                Span span = layoutParams.mSpan;
                int size = span.mViews.size();
                View view = (View) span.mViews.remove(size - 1);
                LayoutParams layoutParams$ar$ds = Span.getLayoutParams$ar$ds(view);
                layoutParams$ar$ds.mSpan = null;
                if (layoutParams$ar$ds.isItemRemoved() || layoutParams$ar$ds.isItemChanged()) {
                    span.mDeletedSize -= span.this$0.mPrimaryOrientation.getDecoratedMeasurement(view);
                }
                if (size == 1) {
                    span.mCachedStart = LinearLayoutManager.INVALID_OFFSET;
                }
                span.mCachedEnd = LinearLayoutManager.INVALID_OFFSET;
                removeAndRecycleView(childAt, recycler);
                childCount--;
            } else {
                return;
            }
        }
    }

    private final void recycleFromStart(Recycler recycler, int i) {
        while (getChildCount() > 0) {
            View childAt = getChildAt(0);
            if (this.mPrimaryOrientation.getDecoratedEnd(childAt) > i || this.mPrimaryOrientation.getTransformedEndWithDecoration(childAt) > i) {
                break;
            }
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            boolean z = layoutParams.mFullSpan;
            if (layoutParams.mSpan.mViews.size() != 1) {
                Span span = layoutParams.mSpan;
                View view = (View) span.mViews.remove(0);
                LayoutParams layoutParams$ar$ds = Span.getLayoutParams$ar$ds(view);
                layoutParams$ar$ds.mSpan = null;
                if (span.mViews.size() == 0) {
                    span.mCachedEnd = LinearLayoutManager.INVALID_OFFSET;
                }
                if (layoutParams$ar$ds.isItemRemoved() || layoutParams$ar$ds.isItemChanged()) {
                    span.mDeletedSize -= span.this$0.mPrimaryOrientation.getDecoratedMeasurement(view);
                }
                span.mCachedStart = LinearLayoutManager.INVALID_OFFSET;
                removeAndRecycleView(childAt, recycler);
            } else {
                return;
            }
        }
    }

    private final void resolveShouldLayoutReverse() {
        boolean z;
        if (this.mOrientation != 1) {
            if (isLayoutRTL()) {
                z = this.mReverseLayout ^ true;
                this.mShouldReverseLayout = z;
            }
        }
        z = this.mReverseLayout;
        this.mShouldReverseLayout = z;
    }

    private final void setLayoutStateDirection(int i) {
        boolean z;
        LayoutState layoutState = this.mLayoutState;
        layoutState.mLayoutDirection = i;
        boolean z2 = this.mShouldReverseLayout;
        int i2 = 1;
        if (i != -1) {
            z = false;
        } else {
            z = true;
        }
        if (z2 != z) {
            i2 = -1;
        }
        layoutState.mItemDirection = i2;
    }

    private final void updateLayoutState(int i, State state) {
        int i2;
        LayoutState layoutState;
        LayoutState layoutState2 = this.mLayoutState;
        boolean z = false;
        layoutState2.mAvailable = 0;
        layoutState2.mCurrentPosition = i;
        if (isSmoothScrolling()) {
            i2 = state.mTargetPosition;
            if (i2 != -1) {
                boolean z2;
                boolean z3 = this.mShouldReverseLayout;
                if (i2 >= i) {
                    z2 = false;
                } else {
                    z2 = true;
                }
                if (z3 == z2) {
                    i = this.mPrimaryOrientation.getTotalSpace();
                    i2 = 0;
                } else {
                    i2 = this.mPrimaryOrientation.getTotalSpace();
                    i = 0;
                }
                if (getClipToPadding()) {
                    this.mLayoutState.mEndLine = this.mPrimaryOrientation.getEnd() + i;
                    this.mLayoutState.mStartLine = -i2;
                } else {
                    this.mLayoutState.mStartLine = this.mPrimaryOrientation.getStartAfterPadding() - i2;
                    this.mLayoutState.mEndLine = this.mPrimaryOrientation.getEndAfterPadding() + i;
                }
                layoutState = this.mLayoutState;
                layoutState.mStopInFocusable = false;
                layoutState.mRecycle = true;
                if (this.mPrimaryOrientation.getMode() != 0 && this.mPrimaryOrientation.getEnd() == 0) {
                    z = true;
                }
                layoutState.mInfinite = z;
            }
        }
        i = 0;
        i2 = 0;
        if (getClipToPadding()) {
            this.mLayoutState.mEndLine = this.mPrimaryOrientation.getEnd() + i;
            this.mLayoutState.mStartLine = -i2;
        } else {
            this.mLayoutState.mStartLine = this.mPrimaryOrientation.getStartAfterPadding() - i2;
            this.mLayoutState.mEndLine = this.mPrimaryOrientation.getEndAfterPadding() + i;
        }
        layoutState = this.mLayoutState;
        layoutState.mStopInFocusable = false;
        layoutState.mRecycle = true;
        if (this.mPrimaryOrientation.getMode() != 0) {
        }
        layoutState.mInfinite = z;
    }

    private final void updateRemainingSpans(Span span, int i, int i2) {
        int i3 = span.mDeletedSize;
        if (i == -1) {
            if (span.getStartLine() + i3 <= i2) {
                this.mRemainingSpans.set(span.mIndex, false);
            }
        } else if (span.getEndLine() - i3 >= i2) {
            this.mRemainingSpans.set(span.mIndex, false);
        }
    }

    private static final int updateSpecWithExtra$ar$ds(int i, int i2, int i3) {
        if (i2 == 0) {
            if (i3 == 0) {
                return i;
            }
            i2 = 0;
        }
        int mode = MeasureSpec.getMode(i);
        if (mode != LinearLayoutManager.INVALID_OFFSET) {
            if (mode != 1073741824) {
                return i;
            }
        }
        return MeasureSpec.makeMeasureSpec(Math.max(0, (MeasureSpec.getSize(i) - i2) - i3), mode);
    }

    public final void assertNotInLayoutOrScroll(String str) {
        if (this.mPendingSavedState == null) {
            super.assertNotInLayoutOrScroll(str);
        }
    }

    public final boolean canScrollHorizontally() {
        return this.mOrientation == 0;
    }

    public final boolean canScrollVertically() {
        return this.mOrientation == 1;
    }

    final boolean checkForGaps() {
        if (!(getChildCount() == 0 || this.mGapStrategy == 0)) {
            if (isAttachedToWindow()) {
                int lastChildPosition;
                if (this.mShouldReverseLayout) {
                    lastChildPosition = getLastChildPosition();
                    getFirstChildPosition();
                } else {
                    lastChildPosition = getFirstChildPosition();
                    getLastChildPosition();
                }
                if (lastChildPosition != 0 || hasGapsToFix() == null) {
                    return false;
                }
                this.mLazySpanLookup.clear();
                requestSimpleAnimationsInNextLayout();
                requestLayout();
                return true;
            }
        }
        return false;
    }

    public final boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public final void collectAdjacentPrefetchPositions(int i, int i2, State state, LayoutPrefetchRegistry layoutPrefetchRegistry) {
        if (1 == this.mOrientation) {
            i = i2;
        }
        if (getChildCount() != 0) {
            if (i != 0) {
                int i3;
                LayoutState layoutState;
                int i4;
                LayoutState layoutState2;
                prepareLayoutStateForDelta(i, state);
                int[] iArr = this.mPrefetchDistances;
                i2 = 0;
                if (iArr != null) {
                    if (iArr.length >= this.mSpanCount) {
                        i = 0;
                        i3 = 0;
                        while (i < this.mSpanCount) {
                            layoutState = this.mLayoutState;
                            if (layoutState.mItemDirection != -1) {
                                i4 = layoutState.mStartLine;
                                i4 -= this.mSpans[i].getStartLine(i4);
                            } else {
                                i4 = this.mSpans[i].getEndLine(layoutState.mEndLine) - this.mLayoutState.mEndLine;
                            }
                            if (i4 >= 0) {
                                this.mPrefetchDistances[i3] = i4;
                                i3++;
                            }
                            i++;
                        }
                        Arrays.sort(this.mPrefetchDistances, 0, i3);
                        while (i2 < i3 && this.mLayoutState.hasMore(state)) {
                            layoutPrefetchRegistry.addPosition(this.mLayoutState.mCurrentPosition, this.mPrefetchDistances[i2]);
                            layoutState2 = this.mLayoutState;
                            layoutState2.mCurrentPosition += layoutState2.mItemDirection;
                            i2++;
                        }
                    }
                }
                this.mPrefetchDistances = new int[this.mSpanCount];
                i = 0;
                i3 = 0;
                while (i < this.mSpanCount) {
                    layoutState = this.mLayoutState;
                    if (layoutState.mItemDirection != -1) {
                        i4 = this.mSpans[i].getEndLine(layoutState.mEndLine) - this.mLayoutState.mEndLine;
                    } else {
                        i4 = layoutState.mStartLine;
                        i4 -= this.mSpans[i].getStartLine(i4);
                    }
                    if (i4 >= 0) {
                        this.mPrefetchDistances[i3] = i4;
                        i3++;
                    }
                    i++;
                }
                Arrays.sort(this.mPrefetchDistances, 0, i3);
                while (i2 < i3) {
                    layoutPrefetchRegistry.addPosition(this.mLayoutState.mCurrentPosition, this.mPrefetchDistances[i2]);
                    layoutState2 = this.mLayoutState;
                    layoutState2.mCurrentPosition += layoutState2.mItemDirection;
                    i2++;
                }
            }
        }
    }

    public final int computeHorizontalScrollExtent(State state) {
        return computeScrollExtent(state);
    }

    public final int computeHorizontalScrollOffset(State state) {
        return computeScrollOffset(state);
    }

    public final int computeHorizontalScrollRange(State state) {
        return computeScrollRange(state);
    }

    public final PointF computeScrollVectorForPosition(int i) {
        i = calculateScrollDirectionForPosition(i);
        PointF pointF = new PointF();
        if (i == 0) {
            return null;
        }
        if (this.mOrientation == 0) {
            pointF.x = (float) i;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = (float) i;
        }
        return pointF;
    }

    public final int computeVerticalScrollExtent(State state) {
        return computeScrollExtent(state);
    }

    public final int computeVerticalScrollOffset(State state) {
        return computeScrollOffset(state);
    }

    public final int computeVerticalScrollRange(State state) {
        return computeScrollRange(state);
    }

    final View findFirstVisibleItemClosestToEnd(boolean z) {
        int startAfterPadding = this.mPrimaryOrientation.getStartAfterPadding();
        int endAfterPadding = this.mPrimaryOrientation.getEndAfterPadding();
        View view = null;
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            int decoratedStart = this.mPrimaryOrientation.getDecoratedStart(childAt);
            int decoratedEnd = this.mPrimaryOrientation.getDecoratedEnd(childAt);
            if (decoratedEnd > startAfterPadding) {
                if (decoratedStart < endAfterPadding) {
                    if (decoratedEnd > endAfterPadding) {
                        if (z) {
                            if (view == null) {
                                view = childAt;
                            }
                        }
                    }
                    return childAt;
                }
            }
        }
        return view;
    }

    final View findFirstVisibleItemClosestToStart(boolean z) {
        int startAfterPadding = this.mPrimaryOrientation.getStartAfterPadding();
        int endAfterPadding = this.mPrimaryOrientation.getEndAfterPadding();
        int childCount = getChildCount();
        View view = null;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int decoratedStart = this.mPrimaryOrientation.getDecoratedStart(childAt);
            if (this.mPrimaryOrientation.getDecoratedEnd(childAt) > startAfterPadding) {
                if (decoratedStart < endAfterPadding) {
                    if (decoratedStart < startAfterPadding) {
                        if (z) {
                            if (view == null) {
                                view = childAt;
                            }
                        }
                    }
                    return childAt;
                }
            }
        }
        return view;
    }

    public final LayoutParams generateDefaultLayoutParams() {
        if (this.mOrientation == 0) {
            return new LayoutParams(-2, -1);
        }
        return new LayoutParams(-1, -2);
    }

    public final LayoutParams generateLayoutParams(Context context, AttributeSet attributeSet) {
        return new LayoutParams(context, attributeSet);
    }

    final int getFirstChildPosition() {
        return getChildCount() == 0 ? 0 : getPosition(getChildAt(0));
    }

    final int getLastChildPosition() {
        int childCount = getChildCount();
        return childCount == 0 ? 0 : getPosition(getChildAt(childCount - 1));
    }

    final View hasGapsToFix() {
        int i;
        int childCount = getChildCount() - 1;
        BitSet bitSet = new BitSet(this.mSpanCount);
        bitSet.set(0, this.mSpanCount, true);
        Object obj = (this.mOrientation == 1 && isLayoutRTL()) ? 1 : -1;
        if (this.mShouldReverseLayout) {
            i = -1;
        } else {
            i = childCount + 1;
            childCount = 0;
        }
        int i2 = childCount < i ? 1 : -1;
        while (childCount != i) {
            View childAt = getChildAt(childCount);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (bitSet.get(layoutParams.mSpan.mIndex)) {
                Span span = layoutParams.mSpan;
                boolean z;
                if (this.mShouldReverseLayout) {
                    if (span.getEndLine() < this.mPrimaryOrientation.getEndAfterPadding()) {
                        ArrayList arrayList = span.mViews;
                        z = Span.getLayoutParams$ar$ds((View) arrayList.get(arrayList.size() - 1)).mFullSpan;
                    }
                    bitSet.clear(layoutParams.mSpan.mIndex);
                } else {
                    if (span.getStartLine() > this.mPrimaryOrientation.getStartAfterPadding()) {
                        z = Span.getLayoutParams$ar$ds((View) span.mViews.get(0)).mFullSpan;
                    }
                    bitSet.clear(layoutParams.mSpan.mIndex);
                }
                return childAt;
            }
            boolean z2 = layoutParams.mFullSpan;
            childCount += i2;
            if (childCount != i) {
                View childAt2 = getChildAt(childCount);
                int decoratedEnd;
                int decoratedEnd2;
                if (this.mShouldReverseLayout) {
                    decoratedEnd = this.mPrimaryOrientation.getDecoratedEnd(childAt);
                    decoratedEnd2 = this.mPrimaryOrientation.getDecoratedEnd(childAt2);
                    if (decoratedEnd < decoratedEnd2) {
                        return childAt;
                    }
                    if (decoratedEnd == decoratedEnd2) {
                        if ((layoutParams.mSpan.mIndex - ((LayoutParams) childAt2.getLayoutParams()).mSpan.mIndex < 0 ? null : 1) == (obj < null ? null : 1)) {
                            return childAt;
                        }
                    }
                } else {
                    decoratedEnd = this.mPrimaryOrientation.getDecoratedStart(childAt);
                    decoratedEnd2 = this.mPrimaryOrientation.getDecoratedStart(childAt2);
                    if (decoratedEnd > decoratedEnd2) {
                        return childAt;
                    }
                    if (decoratedEnd != decoratedEnd2) {
                    }
                    if (layoutParams.mSpan.mIndex - ((LayoutParams) childAt2.getLayoutParams()).mSpan.mIndex < 0) {
                    }
                    if (obj < null) {
                    }
                    if ((layoutParams.mSpan.mIndex - ((LayoutParams) childAt2.getLayoutParams()).mSpan.mIndex < 0 ? null : 1) == (obj < null ? null : 1)) {
                        return childAt;
                    }
                }
            }
        }
        return null;
    }

    public final boolean isAutoMeasureEnabled() {
        return this.mGapStrategy != 0;
    }

    final boolean isLayoutRTL() {
        return getLayoutDirection() == 1;
    }

    public final void offsetChildrenHorizontal(int i) {
        super.offsetChildrenHorizontal(i);
        for (int i2 = 0; i2 < this.mSpanCount; i2++) {
            this.mSpans[i2].onOffset(i);
        }
    }

    public final void offsetChildrenVertical(int i) {
        super.offsetChildrenVertical(i);
        for (int i2 = 0; i2 < this.mSpanCount; i2++) {
            this.mSpans[i2].onOffset(i);
        }
    }

    public final void onAdapterChanged(Adapter adapter, Adapter adapter2) {
        this.mLazySpanLookup.clear();
        for (int i = 0; i < this.mSpanCount; i++) {
            this.mSpans[i].clear();
        }
    }

    public final void onDetachedFromWindow(RecyclerView recyclerView, Recycler recycler) {
        super.onDetachedFromWindow(recyclerView, recycler);
        removeCallbacks(this.mCheckForGapsRunnable);
        for (int i = 0; i < this.mSpanCount; i++) {
            this.mSpans[i].clear();
        }
        recyclerView.requestLayout();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onFocusSearchFailed(android.view.View r9, int r10, android.support.p002v7.widget.RecyclerView.Recycler r11, android.support.p002v7.widget.RecyclerView.State r12) {
        /*
        r8 = this;
        r0 = r8.getChildCount();
        r1 = 0;
        if (r0 != 0) goto L_0x0008;
    L_0x0007:
        return r1;
    L_0x0008:
        r9 = r8.findContainingItemView(r9);
        if (r9 != 0) goto L_0x000f;
    L_0x000e:
        return r1;
    L_0x000f:
        r8.resolveShouldLayoutReverse();
        r0 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r2 = -1;
        r3 = 1;
        switch(r10) {
            case 1: goto L_0x0044;
            case 2: goto L_0x0034;
            case 17: goto L_0x002b;
            case 33: goto L_0x0026;
            case 66: goto L_0x0021;
            case 130: goto L_0x001c;
            default: goto L_0x0019;
        };
    L_0x0019:
        r10 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        goto L_0x0051;
    L_0x001c:
        r10 = r8.mOrientation;
        if (r10 != r3) goto L_0x0031;
    L_0x0020:
        goto L_0x0038;
    L_0x0021:
        r10 = r8.mOrientation;
        if (r10 != 0) goto L_0x0031;
    L_0x0025:
        goto L_0x0038;
    L_0x0026:
        r10 = r8.mOrientation;
        if (r10 != r3) goto L_0x0031;
    L_0x002a:
        goto L_0x002f;
    L_0x002b:
        r10 = r8.mOrientation;
        if (r10 != 0) goto L_0x0031;
    L_0x002f:
        r10 = -1;
        goto L_0x0051;
    L_0x0031:
        r10 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        goto L_0x0051;
    L_0x0034:
        r10 = r8.mOrientation;
        if (r10 != r3) goto L_0x003a;
    L_0x0038:
        r10 = 1;
        goto L_0x0051;
    L_0x003a:
        r10 = r8.isLayoutRTL();
        if (r10 == 0) goto L_0x0042;
    L_0x0040:
        r10 = -1;
        goto L_0x0051;
    L_0x0042:
        r10 = 1;
        goto L_0x0051;
    L_0x0044:
        r10 = r8.mOrientation;
        if (r10 != r3) goto L_0x004a;
    L_0x0048:
        r10 = -1;
        goto L_0x0051;
    L_0x004a:
        r10 = r8.isLayoutRTL();
        if (r10 == 0) goto L_0x002f;
    L_0x0050:
        goto L_0x0038;
    L_0x0051:
        if (r10 != r0) goto L_0x0054;
    L_0x0053:
        return r1;
    L_0x0054:
        r0 = r9.getLayoutParams();
        r0 = (android.support.p002v7.widget.StaggeredGridLayoutManager.LayoutParams) r0;
        r4 = r0.mFullSpan;
        r0 = r0.mSpan;
        if (r10 != r3) goto L_0x0065;
    L_0x0060:
        r4 = r8.getLastChildPosition();
        goto L_0x0069;
    L_0x0065:
        r4 = r8.getFirstChildPosition();
    L_0x0069:
        r8.updateLayoutState(r4, r12);
        r8.setLayoutStateDirection(r10);
        r5 = r8.mLayoutState;
        r6 = r5.mItemDirection;
        r6 = r6 + r4;
        r5.mCurrentPosition = r6;
        r6 = r8.mPrimaryOrientation;
        r6 = r6.getTotalSpace();
        r6 = (float) r6;
        r7 = 1051372203; // 0x3eaaaaab float:0.33333334 double:5.194468865E-315;
        r6 = r6 * r7;
        r6 = (int) r6;
        r5.mAvailable = r6;
        r5 = r8.mLayoutState;
        r5.mStopInFocusable = r3;
        r6 = 0;
        r5.mRecycle = r6;
        r8.fill(r11, r5, r12);
        r11 = r8.mShouldReverseLayout;
        r8.mLastLayoutFromEnd = r11;
        r11 = r0.getFocusableViewAfter(r4, r10);
        if (r11 == 0) goto L_0x009d;
    L_0x0099:
        if (r11 != r9) goto L_0x009c;
    L_0x009b:
        goto L_0x009d;
    L_0x009c:
        return r11;
    L_0x009d:
        r11 = r8.preferLastSpan(r10);
        if (r11 == 0) goto L_0x00b9;
    L_0x00a3:
        r11 = r8.mSpanCount;
        r11 = r11 + r2;
    L_0x00a6:
        if (r11 < 0) goto L_0x00cf;
    L_0x00a8:
        r12 = r8.mSpans;
        r12 = r12[r11];
        r12 = r12.getFocusableViewAfter(r4, r10);
        if (r12 == 0) goto L_0x00b6;
    L_0x00b2:
        if (r12 != r9) goto L_0x00b5;
    L_0x00b4:
        goto L_0x00b6;
    L_0x00b5:
        return r12;
    L_0x00b6:
        r11 = r11 + -1;
        goto L_0x00a6;
    L_0x00b9:
        r11 = 0;
    L_0x00ba:
        r12 = r8.mSpanCount;
        if (r11 >= r12) goto L_0x00cf;
    L_0x00be:
        r12 = r8.mSpans;
        r12 = r12[r11];
        r12 = r12.getFocusableViewAfter(r4, r10);
        if (r12 == 0) goto L_0x00cc;
    L_0x00c8:
        if (r12 != r9) goto L_0x00cb;
    L_0x00ca:
        goto L_0x00cc;
    L_0x00cb:
        return r12;
    L_0x00cc:
        r11 = r11 + 1;
        goto L_0x00ba;
    L_0x00cf:
        r11 = r8.mReverseLayout;
        r11 = r11 ^ r3;
        if (r10 == r2) goto L_0x00d6;
    L_0x00d4:
        r3 = 0;
        goto L_0x00d7;
    L_0x00d7:
        if (r11 != r3) goto L_0x00de;
    L_0x00d9:
        r12 = r0.findFirstPartiallyVisibleItemPosition();
        goto L_0x00e2;
    L_0x00de:
        r12 = r0.findLastPartiallyVisibleItemPosition();
    L_0x00e2:
        r12 = r8.findViewByPosition(r12);
        if (r12 == 0) goto L_0x00ec;
    L_0x00e8:
        if (r12 != r9) goto L_0x00eb;
    L_0x00ea:
        goto L_0x00ec;
    L_0x00eb:
        return r12;
    L_0x00ec:
        r10 = r8.preferLastSpan(r10);
        if (r10 == 0) goto L_0x011b;
    L_0x00f2:
        r10 = r8.mSpanCount;
        r10 = r10 + r2;
    L_0x00f5:
        if (r10 < 0) goto L_0x0140;
    L_0x00f7:
        r12 = r0.mIndex;
        if (r10 != r12) goto L_0x00fc;
    L_0x00fb:
        goto L_0x0118;
    L_0x00fc:
        if (r11 != r3) goto L_0x0107;
    L_0x00fe:
        r12 = r8.mSpans;
        r12 = r12[r10];
        r12 = r12.findFirstPartiallyVisibleItemPosition();
        goto L_0x010f;
    L_0x0107:
        r12 = r8.mSpans;
        r12 = r12[r10];
        r12 = r12.findLastPartiallyVisibleItemPosition();
    L_0x010f:
        r12 = r8.findViewByPosition(r12);
        if (r12 == 0) goto L_0x0118;
    L_0x0115:
        if (r12 == r9) goto L_0x0118;
    L_0x0117:
        return r12;
    L_0x0118:
        r10 = r10 + -1;
        goto L_0x00f5;
    L_0x011c:
        r10 = r8.mSpanCount;
        if (r6 >= r10) goto L_0x0140;
    L_0x0120:
        if (r11 != r3) goto L_0x012b;
    L_0x0122:
        r10 = r8.mSpans;
        r10 = r10[r6];
        r10 = r10.findFirstPartiallyVisibleItemPosition();
        goto L_0x0133;
    L_0x012b:
        r10 = r8.mSpans;
        r10 = r10[r6];
        r10 = r10.findLastPartiallyVisibleItemPosition();
    L_0x0133:
        r10 = r8.findViewByPosition(r10);
        if (r10 == 0) goto L_0x013d;
    L_0x0139:
        if (r10 != r9) goto L_0x013c;
    L_0x013b:
        goto L_0x013d;
    L_0x013c:
        return r10;
    L_0x013d:
        r6 = r6 + 1;
        goto L_0x011c;
    L_0x0140:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.StaggeredGridLayoutManager.onFocusSearchFailed(android.view.View, int, android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State):android.view.View");
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        if (getChildCount() > 0) {
            View findFirstVisibleItemClosestToStart = findFirstVisibleItemClosestToStart(false);
            View findFirstVisibleItemClosestToEnd = findFirstVisibleItemClosestToEnd(false);
            if (findFirstVisibleItemClosestToStart != null) {
                if (findFirstVisibleItemClosestToEnd != null) {
                    int position = getPosition(findFirstVisibleItemClosestToStart);
                    int position2 = getPosition(findFirstVisibleItemClosestToEnd);
                    if (position < position2) {
                        accessibilityEvent.setFromIndex(position);
                        accessibilityEvent.setToIndex(position2);
                        return;
                    }
                    accessibilityEvent.setFromIndex(position2);
                    accessibilityEvent.setToIndex(position);
                }
            }
        }
    }

    public final void onItemsAdded(RecyclerView recyclerView, int i, int i2) {
        handleUpdate(i, i2, 1);
    }

    public final void onItemsChanged(RecyclerView recyclerView) {
        this.mLazySpanLookup.clear();
        requestLayout();
    }

    public final void onItemsMoved(RecyclerView recyclerView, int i, int i2, int i3) {
        handleUpdate(i, i2, 8);
    }

    public final void onItemsRemoved(RecyclerView recyclerView, int i, int i2) {
        handleUpdate(i, i2, 2);
    }

    public final void onItemsUpdated(RecyclerView recyclerView, int i, int i2, Object obj) {
        handleUpdate(i, i2, 4);
    }

    public final void onLayoutCompleted(State state) {
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = LinearLayoutManager.INVALID_OFFSET;
        this.mPendingSavedState = null;
        this.mAnchorInfo.reset();
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            this.mPendingSavedState = savedState;
            if (this.mPendingScrollPosition != -1) {
                savedState.invalidateAnchorPositionInfo();
                this.mPendingSavedState.invalidateSpanInfo();
            }
            requestLayout();
        }
    }

    public final Parcelable onSaveInstanceState() {
        SavedState savedState = this.mPendingSavedState;
        if (savedState != null) {
            return new SavedState(savedState);
        }
        int i;
        View findFirstVisibleItemClosestToEnd;
        int i2;
        Parcelable savedState2 = new SavedState();
        savedState2.mReverseLayout = this.mReverseLayout;
        savedState2.mAnchorLayoutFromEnd = this.mLastLayoutFromEnd;
        savedState2.mLastLayoutRTL = this.mLastLayoutRTL;
        LazySpanLookup lazySpanLookup = this.mLazySpanLookup;
        int i3 = 0;
        if (lazySpanLookup != null) {
            int[] iArr = lazySpanLookup.mData;
            if (iArr != null) {
                savedState2.mSpanLookup = iArr;
                savedState2.mSpanLookupSize = savedState2.mSpanLookup.length;
                savedState2.mFullSpanItems = lazySpanLookup.mFullSpanItems;
                i = -1;
                if (getChildCount() <= 0) {
                    savedState2.mAnchorPosition = this.mLastLayoutFromEnd ? getLastChildPosition() : getFirstChildPosition();
                    findFirstVisibleItemClosestToEnd = this.mShouldReverseLayout ? findFirstVisibleItemClosestToEnd(true) : findFirstVisibleItemClosestToStart(true);
                    if (findFirstVisibleItemClosestToEnd == null) {
                        i = getPosition(findFirstVisibleItemClosestToEnd);
                    }
                    savedState2.mVisibleAnchorPosition = i;
                    i2 = this.mSpanCount;
                    savedState2.mSpanOffsetsSize = i2;
                    savedState2.mSpanOffsets = new int[i2];
                    while (i3 < this.mSpanCount) {
                        if (this.mLastLayoutFromEnd) {
                            i2 = this.mSpans[i3].getStartLine(LinearLayoutManager.INVALID_OFFSET);
                            if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                                i2 -= this.mPrimaryOrientation.getStartAfterPadding();
                            }
                        } else {
                            i2 = this.mSpans[i3].getEndLine(LinearLayoutManager.INVALID_OFFSET);
                            if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                                i2 -= this.mPrimaryOrientation.getEndAfterPadding();
                            }
                        }
                        savedState2.mSpanOffsets[i3] = i2;
                        i3++;
                    }
                } else {
                    savedState2.mAnchorPosition = -1;
                    savedState2.mVisibleAnchorPosition = -1;
                    savedState2.mSpanOffsetsSize = 0;
                }
                return savedState2;
            }
        }
        savedState2.mSpanLookupSize = 0;
        i = -1;
        if (getChildCount() <= 0) {
            savedState2.mAnchorPosition = -1;
            savedState2.mVisibleAnchorPosition = -1;
            savedState2.mSpanOffsetsSize = 0;
        } else {
            if (this.mLastLayoutFromEnd) {
            }
            savedState2.mAnchorPosition = this.mLastLayoutFromEnd ? getLastChildPosition() : getFirstChildPosition();
            if (this.mShouldReverseLayout) {
            }
            if (findFirstVisibleItemClosestToEnd == null) {
                i = getPosition(findFirstVisibleItemClosestToEnd);
            }
            savedState2.mVisibleAnchorPosition = i;
            i2 = this.mSpanCount;
            savedState2.mSpanOffsetsSize = i2;
            savedState2.mSpanOffsets = new int[i2];
            while (i3 < this.mSpanCount) {
                if (this.mLastLayoutFromEnd) {
                    i2 = this.mSpans[i3].getStartLine(LinearLayoutManager.INVALID_OFFSET);
                    if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                        i2 -= this.mPrimaryOrientation.getStartAfterPadding();
                    }
                } else {
                    i2 = this.mSpans[i3].getEndLine(LinearLayoutManager.INVALID_OFFSET);
                    if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                        i2 -= this.mPrimaryOrientation.getEndAfterPadding();
                    }
                }
                savedState2.mSpanOffsets[i3] = i2;
                i3++;
            }
        }
        return savedState2;
    }

    public final void onScrollStateChanged(int i) {
        if (i == 0) {
            checkForGaps();
        }
    }

    final void prepareLayoutStateForDelta(int i, State state) {
        int lastChildPosition;
        int i2;
        if (i > 0) {
            lastChildPosition = getLastChildPosition();
            i2 = 1;
        } else {
            lastChildPosition = getFirstChildPosition();
            i2 = -1;
        }
        this.mLayoutState.mRecycle = true;
        updateLayoutState(lastChildPosition, state);
        setLayoutStateDirection(i2);
        LayoutState layoutState = this.mLayoutState;
        layoutState.mCurrentPosition = lastChildPosition + layoutState.mItemDirection;
        layoutState.mAvailable = Math.abs(i);
    }

    final int scrollBy(int i, Recycler recycler, State state) {
        if (getChildCount() != 0) {
            if (i != 0) {
                prepareLayoutStateForDelta(i, state);
                int fill = fill(recycler, this.mLayoutState, state);
                if (this.mLayoutState.mAvailable >= fill) {
                    i = i < 0 ? -fill : fill;
                }
                this.mPrimaryOrientation.offsetChildren(-i);
                this.mLastLayoutFromEnd = this.mShouldReverseLayout;
                LayoutState layoutState = this.mLayoutState;
                layoutState.mAvailable = 0;
                recycle(recycler, layoutState);
                return i;
            }
        }
        return 0;
    }

    public final int scrollHorizontallyBy(int i, Recycler recycler, State state) {
        return scrollBy(i, recycler, state);
    }

    public final void scrollToPosition(int i) {
        SavedState savedState = this.mPendingSavedState;
        if (!(savedState == null || savedState.mAnchorPosition == i)) {
            savedState.invalidateAnchorPositionInfo();
        }
        this.mPendingScrollPosition = i;
        this.mPendingScrollPositionOffset = LinearLayoutManager.INVALID_OFFSET;
        requestLayout();
    }

    public final int scrollVerticallyBy(int i, Recycler recycler, State state) {
        return scrollBy(i, recycler, state);
    }

    public final void setMeasuredDimension(Rect rect, int i, int i2) {
        int chooseSize;
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int paddingTop = getPaddingTop() + getPaddingBottom();
        if (this.mOrientation == 1) {
            chooseSize = LayoutManager.chooseSize(i2, rect.height() + paddingTop, getMinimumHeight());
            i = LayoutManager.chooseSize(i, (this.mSizePerSpan * this.mSpanCount) + paddingLeft, getMinimumWidth());
        } else {
            i = LayoutManager.chooseSize(i, rect.width() + paddingLeft, getMinimumWidth());
            chooseSize = LayoutManager.chooseSize(i2, (this.mSizePerSpan * this.mSpanCount) + paddingTop, getMinimumHeight());
        }
        setMeasuredDimension(i, chooseSize);
    }

    public final void setReverseLayout(boolean z) {
        assertNotInLayoutOrScroll(null);
        SavedState savedState = this.mPendingSavedState;
        if (!(savedState == null || savedState.mReverseLayout == z)) {
            savedState.mReverseLayout = z;
        }
        this.mReverseLayout = z;
        requestLayout();
    }

    public final void smoothScrollToPosition(RecyclerView recyclerView, State state, int i) {
        SmoothScroller linearSmoothScroller = new LinearSmoothScroller(recyclerView.getContext());
        linearSmoothScroller.mTargetPosition = i;
        startSmoothScroll(linearSmoothScroller);
    }

    public final boolean supportsPredictiveItemAnimations() {
        return this.mPendingSavedState == null;
    }

    final void updateMeasureSpecs(int i) {
        this.mSizePerSpan = i / this.mSpanCount;
        MeasureSpec.makeMeasureSpec(i, this.mSecondaryOrientation.getMode());
    }

    public final LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof MarginLayoutParams) {
            return new LayoutParams((MarginLayoutParams) layoutParams);
        }
        return new LayoutParams(layoutParams);
    }

    public final void onLayoutChildren(Recycler recycler, State state) {
        onLayoutChildren(recycler, state, true);
    }
}
