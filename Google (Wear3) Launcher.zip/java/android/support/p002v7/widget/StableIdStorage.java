package android.support.p002v7.widget;

import androidx.collection.LongSparseArray;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.StableIdStorage */
interface StableIdStorage {

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.StableIdStorage$IsolatedStableIdStorage */
    public final class IsolatedStableIdStorage implements StableIdStorage {
        long mNextStableId = 0;

        /* compiled from: PG */
        /* renamed from: android.support.v7.widget.StableIdStorage$IsolatedStableIdStorage$WrapperStableIdLookup */
        final class WrapperStableIdLookup implements StableIdLookup {
            private final LongSparseArray mLocalToGlobalLookup = new LongSparseArray();

            public final long localToGlobal(long j) {
                Long l = (Long) this.mLocalToGlobalLookup.get(j);
                if (l == null) {
                    IsolatedStableIdStorage isolatedStableIdStorage = IsolatedStableIdStorage.this;
                    long j2 = isolatedStableIdStorage.mNextStableId;
                    isolatedStableIdStorage.mNextStableId = 1 + j2;
                    l = Long.valueOf(j2);
                    this.mLocalToGlobalLookup.put(j, l);
                }
                return l.longValue();
            }
        }

        public final StableIdLookup createStableIdLookup() {
            return new WrapperStableIdLookup();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.StableIdStorage$NoStableIdStorage */
    public final class NoStableIdStorage implements StableIdStorage {
        private final StableIdLookup mNoIdLookup = new PG();

        /* renamed from: android.support.v7.widget.StableIdStorage$NoStableIdStorage$1 */
        final class PG implements StableIdLookup {
            public final long localToGlobal(long j) {
                return -1;
            }
        }

        public final StableIdLookup createStableIdLookup() {
            return this.mNoIdLookup;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.StableIdStorage$StableIdLookup */
    public interface StableIdLookup {
        long localToGlobal(long j);
    }

    StableIdLookup createStableIdLookup();
}
