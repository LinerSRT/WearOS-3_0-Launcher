package android.support.p002v7.widget;

import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.OnChildAttachStateChangeListener;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.support.v7.widget.RecyclerView.C01085;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ChildHelper */
final class ChildHelper {
    final Bucket mBucket = new Bucket();
    final C01085 mCallback$ar$class_merging$5a35e444_0;
    final List mHiddenViews = new ArrayList();

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ChildHelper$Bucket */
    final class Bucket {
        long mData = 0;
        Bucket mNext;

        private final void ensureNext() {
            if (this.mNext == null) {
                this.mNext = new Bucket();
            }
        }

        final void clear(int i) {
            if (i >= 64) {
                Bucket bucket = this.mNext;
                if (bucket != null) {
                    bucket.clear(i - 64);
                }
                return;
            }
            this.mData &= (1 << i) ^ -1;
        }

        final int countOnesBefore(int i) {
            Bucket bucket = this.mNext;
            if (bucket == null) {
                if (i >= 64) {
                    return Long.bitCount(this.mData);
                }
                return Long.bitCount(this.mData & ((1 << i) - 1));
            } else if (i < 64) {
                return Long.bitCount(this.mData & ((1 << i) - 1));
            } else {
                return bucket.countOnesBefore(i - 64) + Long.bitCount(this.mData);
            }
        }

        final boolean get(int i) {
            if (i < 64) {
                return (this.mData & (1 << i)) != 0;
            } else {
                ensureNext();
                return this.mNext.get(i - 64);
            }
        }

        final void insert(int i, boolean z) {
            if (i >= 64) {
                ensureNext();
                this.mNext.insert(i - 64, z);
                return;
            }
            boolean z2;
            long j = this.mData;
            if ((Long.MIN_VALUE & j) != 0) {
                z2 = true;
            } else {
                z2 = false;
            }
            long j2 = (1 << i) - 1;
            long j3 = (-1 ^ j2) & j;
            this.mData = (j & j2) | (j3 + j3);
            if (z) {
                set(i);
            } else {
                clear(i);
            }
            if (!z2) {
                if (this.mNext == null) {
                    return;
                }
            }
            ensureNext();
            this.mNext.insert(0, z2);
        }

        final boolean remove(int i) {
            if (i >= 64) {
                ensureNext();
                return this.mNext.remove(i - 64);
            }
            boolean z;
            long j = 1 << i;
            long j2 = this.mData;
            if ((j2 & j) != 0) {
                z = true;
            } else {
                z = false;
            }
            j2 &= j ^ -1;
            this.mData = j2;
            j--;
            this.mData = Long.rotateRight((j ^ -1) & j2, 1) | (j2 & j);
            Bucket bucket = this.mNext;
            if (bucket != null) {
                if (bucket.get(0)) {
                    set(63);
                }
                this.mNext.remove(0);
            }
            return z;
        }

        final void reset() {
            this.mData = 0;
            Bucket bucket = this.mNext;
            if (bucket != null) {
                bucket.reset();
            }
        }

        final void set(int i) {
            if (i >= 64) {
                ensureNext();
                this.mNext.set(i - 64);
                return;
            }
            this.mData |= 1 << i;
        }

        public final String toString() {
            if (this.mNext == null) {
                return Long.toBinaryString(this.mData);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.mNext.toString());
            stringBuilder.append("xx");
            stringBuilder.append(Long.toBinaryString(this.mData));
            return stringBuilder.toString();
        }
    }

    public ChildHelper(C01085 c01085) {
        this.mCallback$ar$class_merging$5a35e444_0 = c01085;
    }

    private final int getOffset(int i) {
        if (i < 0) {
            return -1;
        }
        int childCount = this.mCallback$ar$class_merging$5a35e444_0.getChildCount();
        int i2 = i;
        while (i2 < childCount) {
            int countOnesBefore = i - (i2 - this.mBucket.countOnesBefore(i2));
            if (countOnesBefore == 0) {
                while (this.mBucket.get(i2)) {
                    i2++;
                }
                return i2;
            }
            i2 += countOnesBefore;
        }
        return -1;
    }

    final void addView(View view, int i, boolean z) {
        if (i < 0) {
            i = this.mCallback$ar$class_merging$5a35e444_0.getChildCount();
        } else {
            i = getOffset(i);
        }
        this.mBucket.insert(i, z);
        if (z) {
            hideViewInternal(view);
        }
        C01085 c01085 = this.mCallback$ar$class_merging$5a35e444_0;
        c01085.this$0.addView(view, i);
        RecyclerView recyclerView = c01085.this$0;
        ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        Adapter adapter = recyclerView.mAdapter;
        if (!(adapter == null || childViewHolderInt == null)) {
            adapter.onViewAttachedToWindow(childViewHolderInt);
        }
        List list = recyclerView.mOnChildAttachStateListeners;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                ((OnChildAttachStateChangeListener) recyclerView.mOnChildAttachStateListeners.get(size)).onChildViewAttachedToWindow(view);
            }
        }
    }

    final void attachViewToParent(View view, int i, LayoutParams layoutParams, boolean z) {
        if (i < 0) {
            i = this.mCallback$ar$class_merging$5a35e444_0.getChildCount();
        } else {
            i = getOffset(i);
        }
        this.mBucket.insert(i, z);
        if (z) {
            hideViewInternal(view);
        }
        C01085 c01085 = this.mCallback$ar$class_merging$5a35e444_0;
        ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        if (childViewHolderInt != null) {
            if (!childViewHolderInt.isTmpDetached()) {
                if (!childViewHolderInt.shouldIgnore()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Called attach on a child which is not detached: ");
                    stringBuilder.append(childViewHolderInt);
                    stringBuilder.append(c01085.this$0.exceptionLabel());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
            }
            childViewHolderInt.clearTmpDetachFlag();
        }
        c01085.this$0.attachViewToParent(view, i, layoutParams);
    }

    final void detachViewFromParent(int i) {
        i = getOffset(i);
        this.mBucket.remove(i);
        C01085 c01085 = this.mCallback$ar$class_merging$5a35e444_0;
        View childAt = c01085.getChildAt(i);
        if (childAt != null) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(childAt);
            if (childViewHolderInt != null) {
                if (childViewHolderInt.isTmpDetached()) {
                    if (!childViewHolderInt.shouldIgnore()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("called detach on an already detached child ");
                        stringBuilder.append(childViewHolderInt);
                        stringBuilder.append(c01085.this$0.exceptionLabel());
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                }
                childViewHolderInt.addFlags(256);
            }
        }
        c01085.this$0.detachViewFromParent(i);
    }

    final View getChildAt(int i) {
        return this.mCallback$ar$class_merging$5a35e444_0.getChildAt(getOffset(i));
    }

    final int getChildCount() {
        return this.mCallback$ar$class_merging$5a35e444_0.getChildCount() - this.mHiddenViews.size();
    }

    final View getUnfilteredChildAt(int i) {
        return this.mCallback$ar$class_merging$5a35e444_0.getChildAt(i);
    }

    final int getUnfilteredChildCount() {
        return this.mCallback$ar$class_merging$5a35e444_0.getChildCount();
    }

    public final void hideViewInternal(View view) {
        this.mHiddenViews.add(view);
        C01085 c01085 = this.mCallback$ar$class_merging$5a35e444_0;
        ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        if (childViewHolderInt != null) {
            RecyclerView recyclerView = c01085.this$0;
            int i = childViewHolderInt.mPendingAccessibilityState;
            if (i != -1) {
                childViewHolderInt.mWasImportantForAccessibilityBeforeHidden = i;
            } else {
                childViewHolderInt.mWasImportantForAccessibilityBeforeHidden = ViewCompat.getImportantForAccessibility(childViewHolderInt.itemView);
            }
            recyclerView.setChildImportantForAccessibilityInternal$ar$ds(childViewHolderInt, 4);
        }
    }

    final int indexOfChild(View view) {
        int indexOfChild = this.mCallback$ar$class_merging$5a35e444_0.indexOfChild(view);
        if (indexOfChild == -1 || this.mBucket.get(indexOfChild)) {
            return -1;
        }
        return indexOfChild - this.mBucket.countOnesBefore(indexOfChild);
    }

    final boolean isHidden(View view) {
        return this.mHiddenViews.contains(view);
    }

    final void removeViewAt(int i) {
        i = getOffset(i);
        View childAt = this.mCallback$ar$class_merging$5a35e444_0.getChildAt(i);
        if (childAt != null) {
            if (this.mBucket.remove(i)) {
                unhideViewInternal$ar$ds(childAt);
            }
            this.mCallback$ar$class_merging$5a35e444_0.removeViewAt(i);
        }
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.mBucket.toString());
        stringBuilder.append(", hidden list:");
        stringBuilder.append(this.mHiddenViews.size());
        return stringBuilder.toString();
    }

    public final void unhideViewInternal$ar$ds(View view) {
        if (this.mHiddenViews.remove(view)) {
            this.mCallback$ar$class_merging$5a35e444_0.onLeftHiddenState(view);
        }
    }
}
