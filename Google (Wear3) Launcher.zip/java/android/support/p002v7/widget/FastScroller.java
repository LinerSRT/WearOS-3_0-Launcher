package android.support.p002v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.widget.RecyclerView;
import android.support.p002v7.widget.RecyclerView.ItemDecoration;
import android.support.p002v7.widget.RecyclerView.OnItemTouchListener;
import android.support.p002v7.widget.RecyclerView.OnScrollListener;
import android.support.v7.widget.FastScroller.C01022;
import android.view.MotionEvent;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.FastScroller */
final class FastScroller extends ItemDecoration implements OnItemTouchListener {
    private static final int[] EMPTY_STATE_SET = new int[0];
    private static final int[] PRESSED_STATE_SET = new int[]{16842919};
    int mAnimationState;
    private int mDragState = 0;
    private final Runnable mHideRunnable;
    float mHorizontalDragX;
    private final int[] mHorizontalRange = new int[2];
    int mHorizontalThumbCenterX;
    private final StateListDrawable mHorizontalThumbDrawable;
    private final int mHorizontalThumbHeight;
    int mHorizontalThumbWidth;
    private final Drawable mHorizontalTrackDrawable;
    private final int mHorizontalTrackHeight;
    private final int mMargin;
    public boolean mNeedHorizontalScrollbar = false;
    public boolean mNeedVerticalScrollbar = false;
    private final OnScrollListener mOnScrollListener;
    public RecyclerView mRecyclerView;
    public int mRecyclerViewHeight = 0;
    public int mRecyclerViewWidth = 0;
    public final int mScrollbarMinimumRange;
    final ValueAnimator mShowHideAnimator;
    public int mState = 0;
    float mVerticalDragY;
    private final int[] mVerticalRange = new int[2];
    int mVerticalThumbCenterY;
    final StateListDrawable mVerticalThumbDrawable;
    int mVerticalThumbHeight;
    private final int mVerticalThumbWidth;
    final Drawable mVerticalTrackDrawable;
    private final int mVerticalTrackWidth;

    /* renamed from: android.support.v7.widget.FastScroller$1 */
    final class PG implements Runnable {
        public final void run() {
            FastScroller fastScroller = FastScroller.this;
            switch (fastScroller.mAnimationState) {
                case 1:
                    fastScroller.mShowHideAnimator.cancel();
                    break;
                case 2:
                    break;
                default:
                    return;
            }
            fastScroller.mAnimationState = 3;
            fastScroller.mShowHideAnimator.setFloatValues(new float[]{((Float) fastScroller.mShowHideAnimator.getAnimatedValue()).floatValue(), 0.0f});
            fastScroller.mShowHideAnimator.setDuration(500);
            fastScroller.mShowHideAnimator.start();
        }
    }

    /* renamed from: android.support.v7.widget.FastScroller$2 */
    final class C01022 extends OnScrollListener {
        public final void onScrolled(RecyclerView recyclerView, int i, int i2) {
            boolean z;
            boolean z2;
            android.support.p002v7.widget.FastScroller fastScroller = android.support.p002v7.widget.FastScroller.this;
            i2 = recyclerView.computeHorizontalScrollOffset();
            int computeVerticalScrollOffset = recyclerView.computeVerticalScrollOffset();
            int computeVerticalScrollRange = fastScroller.mRecyclerView.computeVerticalScrollRange();
            int i3 = fastScroller.mRecyclerViewHeight;
            if (computeVerticalScrollRange - i3 <= 0 || i3 < fastScroller.mScrollbarMinimumRange) {
                z = false;
            } else {
                z = true;
            }
            fastScroller.mNeedVerticalScrollbar = z;
            int computeHorizontalScrollRange = fastScroller.mRecyclerView.computeHorizontalScrollRange();
            int i4 = fastScroller.mRecyclerViewWidth;
            if (computeHorizontalScrollRange - i4 <= 0 || i4 < fastScroller.mScrollbarMinimumRange) {
                z2 = false;
            } else {
                z2 = true;
            }
            fastScroller.mNeedHorizontalScrollbar = z2;
            if (fastScroller.mNeedVerticalScrollbar) {
                float f = (float) i3;
                fastScroller.mVerticalThumbCenterY = (int) ((f * (((float) computeVerticalScrollOffset) + (f / 2.0f))) / ((float) computeVerticalScrollRange));
                fastScroller.mVerticalThumbHeight = Math.min(i3, (i3 * i3) / computeVerticalScrollRange);
            } else if (!z2) {
                if (fastScroller.mState != 0) {
                    fastScroller.setState(0);
                    return;
                }
                return;
            }
            if (fastScroller.mNeedHorizontalScrollbar) {
                float f2 = (float) i4;
                fastScroller.mHorizontalThumbCenterX = (int) ((f2 * (((float) i2) + (f2 / 2.0f))) / ((float) computeHorizontalScrollRange));
                fastScroller.mHorizontalThumbWidth = Math.min(i4, (i4 * i4) / computeHorizontalScrollRange);
            }
            computeVerticalScrollOffset = fastScroller.mState;
            if (computeVerticalScrollOffset != 0) {
                if (computeVerticalScrollOffset == 1) {
                }
                return;
            }
            fastScroller.setState(1);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.FastScroller$AnimatorListener */
    final class AnimatorListener extends AnimatorListenerAdapter {
        private boolean mCanceled = false;

        public final void onAnimationCancel(Animator animator) {
            this.mCanceled = true;
        }

        public final void onAnimationEnd(Animator animator) {
            if (this.mCanceled) {
                this.mCanceled = false;
            } else if (((Float) FastScroller.this.mShowHideAnimator.getAnimatedValue()).floatValue() == 0.0f) {
                r3 = FastScroller.this;
                r3.mAnimationState = 0;
                r3.setState(0);
            } else {
                r3 = FastScroller.this;
                r3.mAnimationState = 2;
                r3.requestRedraw();
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.FastScroller$AnimatorUpdater */
    final class AnimatorUpdater implements AnimatorUpdateListener {
        public final void onAnimationUpdate(ValueAnimator valueAnimator) {
            int floatValue = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
            FastScroller.this.mVerticalThumbDrawable.setAlpha(floatValue);
            FastScroller.this.mVerticalTrackDrawable.setAlpha(floatValue);
            FastScroller.this.requestRedraw();
        }
    }

    public FastScroller(RecyclerView recyclerView, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i, int i2, int i3) {
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
        this.mShowHideAnimator = ofFloat;
        this.mAnimationState = 0;
        this.mHideRunnable = new PG();
        OnScrollListener c01022 = new C01022();
        this.mOnScrollListener = c01022;
        this.mVerticalThumbDrawable = stateListDrawable;
        this.mVerticalTrackDrawable = drawable;
        this.mHorizontalThumbDrawable = stateListDrawable2;
        this.mHorizontalTrackDrawable = drawable2;
        this.mVerticalThumbWidth = Math.max(i, stateListDrawable.getIntrinsicWidth());
        this.mVerticalTrackWidth = Math.max(i, drawable.getIntrinsicWidth());
        this.mHorizontalThumbHeight = Math.max(i, stateListDrawable2.getIntrinsicWidth());
        this.mHorizontalTrackHeight = Math.max(i, drawable2.getIntrinsicWidth());
        this.mScrollbarMinimumRange = i2;
        this.mMargin = i3;
        stateListDrawable.setAlpha(255);
        drawable.setAlpha(255);
        ofFloat.addListener(new AnimatorListener());
        ofFloat.addUpdateListener(new AnimatorUpdater());
        RecyclerView recyclerView2 = this.mRecyclerView;
        if (recyclerView2 != recyclerView) {
            if (recyclerView2 != null) {
                recyclerView2.removeItemDecoration(this);
                this.mRecyclerView.removeOnItemTouchListener(this);
                this.mRecyclerView.removeOnScrollListener(c01022);
                cancelHide();
            }
            this.mRecyclerView = recyclerView;
            if (recyclerView != null) {
                recyclerView.addItemDecoration(this);
                this.mRecyclerView.addOnItemTouchListener(this);
                this.mRecyclerView.addOnScrollListener(c01022);
            }
        }
    }

    private final void cancelHide() {
        this.mRecyclerView.removeCallbacks(this.mHideRunnable);
    }

    private final boolean isLayoutRTL() {
        return ViewCompat.getLayoutDirection(this.mRecyclerView) == 1;
    }

    private final void resetHideDelay(int i) {
        cancelHide();
        this.mRecyclerView.postDelayed(this.mHideRunnable, (long) i);
    }

    private static final int scrollTo$ar$ds(float f, float f2, int[] iArr, int i, int i2, int i3) {
        int i4 = iArr[1] - iArr[0];
        if (i4 == 0) {
            return 0;
        }
        i -= i3;
        int i5 = (int) (((f2 - f) / ((float) i4)) * ((float) i));
        i2 += i5;
        return (i2 >= i || i2 < 0) ? 0 : i5;
    }

    final boolean isPointInsideHorizontalThumb(float f, float f2) {
        if (f2 >= ((float) (this.mRecyclerViewHeight - this.mHorizontalThumbHeight))) {
            int i = this.mHorizontalThumbCenterX;
            int i2 = this.mHorizontalThumbWidth / 2;
            if (f >= ((float) (i - i2)) && f <= ((float) (i + i2))) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final boolean isPointInsideVerticalThumb(float r3, float r4) {
        /*
        r2 = this;
        r0 = r2.isLayoutRTL();
        if (r0 == 0) goto L_0x000e;
    L_0x0006:
        r0 = r2.mVerticalThumbWidth;
        r0 = (float) r0;
        r3 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1));
        if (r3 > 0) goto L_0x002e;
    L_0x000d:
        goto L_0x0019;
    L_0x000e:
        r0 = r2.mRecyclerViewWidth;
        r1 = r2.mVerticalThumbWidth;
        r0 = r0 - r1;
        r0 = (float) r0;
        r3 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1));
        if (r3 < 0) goto L_0x002e;
    L_0x0018:
        goto L_0x000d;
    L_0x0019:
        r3 = r2.mVerticalThumbCenterY;
        r0 = r2.mVerticalThumbHeight;
        r0 = r0 / 2;
        r1 = r3 - r0;
        r1 = (float) r1;
        r1 = (r4 > r1 ? 1 : (r4 == r1 ? 0 : -1));
        if (r1 < 0) goto L_0x002e;
    L_0x0026:
        r3 = r3 + r0;
        r3 = (float) r3;
        r3 = (r4 > r3 ? 1 : (r4 == r3 ? 0 : -1));
        if (r3 > 0) goto L_0x002e;
    L_0x002c:
        r3 = 1;
        return r3;
    L_0x002e:
        r3 = 0;
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.FastScroller.isPointInsideVerticalThumb(float, float):boolean");
    }

    public final void onDrawOver$ar$ds(Canvas canvas, RecyclerView recyclerView) {
        if (this.mRecyclerViewWidth == this.mRecyclerView.getWidth()) {
            if (this.mRecyclerViewHeight == this.mRecyclerView.getHeight()) {
                if (this.mAnimationState != 0) {
                    int i;
                    int i2;
                    int i3;
                    int i4;
                    if (this.mNeedVerticalScrollbar) {
                        i = this.mRecyclerViewWidth;
                        i2 = this.mVerticalThumbWidth;
                        i -= i2;
                        i3 = this.mVerticalThumbCenterY;
                        i4 = this.mVerticalThumbHeight;
                        i3 -= i4 / 2;
                        this.mVerticalThumbDrawable.setBounds(0, 0, i2, i4);
                        this.mVerticalTrackDrawable.setBounds(0, 0, this.mVerticalTrackWidth, this.mRecyclerViewHeight);
                        if (isLayoutRTL()) {
                            this.mVerticalTrackDrawable.draw(canvas);
                            canvas.translate((float) this.mVerticalThumbWidth, (float) i3);
                            canvas.scale(-1.0f, 1.0f);
                            this.mVerticalThumbDrawable.draw(canvas);
                            canvas.scale(-1.0f, 1.0f);
                            canvas.translate((float) (-this.mVerticalThumbWidth), (float) (-i3));
                        } else {
                            canvas.translate((float) i, 0.0f);
                            this.mVerticalTrackDrawable.draw(canvas);
                            canvas.translate(0.0f, (float) i3);
                            this.mVerticalThumbDrawable.draw(canvas);
                            canvas.translate((float) (-i), (float) (-i3));
                        }
                    }
                    if (this.mNeedHorizontalScrollbar) {
                        i = this.mRecyclerViewHeight;
                        i2 = this.mHorizontalThumbHeight;
                        i -= i2;
                        i3 = this.mHorizontalThumbCenterX;
                        i4 = this.mHorizontalThumbWidth;
                        i3 -= i4 / 2;
                        this.mHorizontalThumbDrawable.setBounds(0, 0, i4, i2);
                        this.mHorizontalTrackDrawable.setBounds(0, 0, this.mRecyclerViewWidth, this.mHorizontalTrackHeight);
                        canvas.translate(0.0f, (float) i);
                        this.mHorizontalTrackDrawable.draw(canvas);
                        canvas.translate((float) i3, 0.0f);
                        this.mHorizontalThumbDrawable.draw(canvas);
                        canvas.translate((float) (-i3), (float) (-i));
                        return;
                    }
                }
                return;
            }
        }
        this.mRecyclerViewWidth = this.mRecyclerView.getWidth();
        this.mRecyclerViewHeight = this.mRecyclerView.getHeight();
        setState(0);
    }

    public final boolean onInterceptTouchEvent$ar$ds(MotionEvent motionEvent) {
        int i = this.mState;
        boolean z = false;
        if (i == 1) {
            boolean isPointInsideVerticalThumb = isPointInsideVerticalThumb(motionEvent.getX(), motionEvent.getY());
            boolean isPointInsideHorizontalThumb = isPointInsideHorizontalThumb(motionEvent.getX(), motionEvent.getY());
            if (motionEvent.getAction() == 0) {
                if (isPointInsideVerticalThumb) {
                    if (!isPointInsideHorizontalThumb) {
                        this.mDragState = 2;
                        this.mVerticalDragY = (float) ((int) motionEvent.getY());
                        setState(2);
                        z = true;
                        return z;
                    }
                } else if (!isPointInsideHorizontalThumb) {
                    return z;
                }
                this.mDragState = 1;
                this.mHorizontalDragX = (float) ((int) motionEvent.getX());
                setState(2);
                z = true;
                return z;
            }
        } else if (i == 2) {
            return true;
        }
        return z;
    }

    public final void onRequestDisallowInterceptTouchEvent(boolean z) {
    }

    public final void onTouchEvent$ar$ds$fcc9275a_0(MotionEvent motionEvent) {
        if (this.mState != 0) {
            if (motionEvent.getAction() == 0) {
                boolean isPointInsideVerticalThumb = isPointInsideVerticalThumb(motionEvent.getX(), motionEvent.getY());
                boolean isPointInsideHorizontalThumb = isPointInsideHorizontalThumb(motionEvent.getX(), motionEvent.getY());
                if (isPointInsideVerticalThumb) {
                    if (!isPointInsideHorizontalThumb) {
                        this.mDragState = 2;
                        this.mVerticalDragY = (float) ((int) motionEvent.getY());
                        setState(2);
                        return;
                    }
                } else if (isPointInsideHorizontalThumb) {
                }
                this.mDragState = 1;
                this.mHorizontalDragX = (float) ((int) motionEvent.getX());
                setState(2);
                return;
            }
            if (motionEvent.getAction() == 1) {
                if (this.mState == 2) {
                    this.mVerticalDragY = 0.0f;
                    this.mHorizontalDragX = 0.0f;
                    setState(1);
                    this.mDragState = 0;
                    return;
                }
            }
            if (motionEvent.getAction() == 2 && this.mState == 2) {
                int[] iArr;
                show();
                if (this.mDragState == 1) {
                    float x = motionEvent.getX();
                    iArr = this.mHorizontalRange;
                    int i = this.mMargin;
                    iArr[0] = i;
                    iArr[1] = this.mRecyclerViewWidth - i;
                    x = Math.max((float) iArr[0], Math.min((float) iArr[1], x));
                    if (Math.abs(((float) this.mHorizontalThumbCenterX) - x) >= 2.0f) {
                        i = FastScroller.scrollTo$ar$ds(this.mHorizontalDragX, x, iArr, this.mRecyclerView.computeHorizontalScrollRange(), this.mRecyclerView.computeHorizontalScrollOffset(), this.mRecyclerViewWidth);
                        if (i != 0) {
                            this.mRecyclerView.scrollBy(i, 0);
                        }
                        this.mHorizontalDragX = x;
                    }
                }
                if (this.mDragState == 2) {
                    float y = motionEvent.getY();
                    iArr = this.mVerticalRange;
                    int i2 = this.mMargin;
                    iArr[0] = i2;
                    iArr[1] = this.mRecyclerViewHeight - i2;
                    y = Math.max((float) iArr[0], Math.min((float) iArr[1], y));
                    if (Math.abs(((float) this.mVerticalThumbCenterY) - y) >= 2.0f) {
                        i2 = FastScroller.scrollTo$ar$ds(this.mVerticalDragY, y, iArr, this.mRecyclerView.computeVerticalScrollRange(), this.mRecyclerView.computeVerticalScrollOffset(), this.mRecyclerViewHeight);
                        if (i2 != 0) {
                            this.mRecyclerView.scrollBy(0, i2);
                        }
                        this.mVerticalDragY = y;
                    }
                }
            }
        }
    }

    final void requestRedraw() {
        this.mRecyclerView.invalidate();
    }

    final void setState(int i) {
        if (i == 2 && this.mState != 2) {
            this.mVerticalThumbDrawable.setState(PRESSED_STATE_SET);
            cancelHide();
        }
        if (i == 0) {
            requestRedraw();
        } else {
            show();
        }
        if (this.mState == 2 && i != 2) {
            this.mVerticalThumbDrawable.setState(EMPTY_STATE_SET);
            resetHideDelay(1200);
        } else if (i == 1) {
            resetHideDelay(1500);
        }
        this.mState = i;
    }

    public final void show() {
        switch (this.mAnimationState) {
            case 0:
                break;
            case 3:
                this.mShowHideAnimator.cancel();
                break;
            default:
                return;
        }
        this.mAnimationState = 1;
        this.mShowHideAnimator.setFloatValues(new float[]{((Float) this.mShowHideAnimator.getAnimatedValue()).floatValue(), 1.0f});
        this.mShowHideAnimator.setDuration(500);
        this.mShowHideAnimator.setStartDelay(0);
        this.mShowHideAnimator.start();
    }
}
