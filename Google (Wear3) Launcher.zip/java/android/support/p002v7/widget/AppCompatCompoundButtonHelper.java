package android.support.p002v7.widget;

import android.content.res.Resources.NotFoundException;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.content.res.AppCompatResources;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatCompoundButtonHelper */
final class AppCompatCompoundButtonHelper {
    private boolean mSkipNextApply;
    private final CompoundButton mView;

    public AppCompatCompoundButtonHelper(CompoundButton compoundButton) {
        this.mView = compoundButton;
    }

    final void loadFromAttributes(AttributeSet attributeSet, int i) {
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(this.mView.getContext(), attributeSet, R$styleable.CompoundButton, i);
        View view = this.mView;
        ViewCompat.saveAttributeDataForStyleable(view, view.getContext(), R$styleable.CompoundButton, attributeSet, obtainStyledAttributes$ar$ds.mWrapped, i, 0);
        try {
            int resourceId;
            CompoundButton compoundButton;
            if (obtainStyledAttributes$ar$ds.hasValue(1)) {
                resourceId = obtainStyledAttributes$ar$ds.getResourceId(1, 0);
                if (resourceId != 0) {
                    try {
                        compoundButton = this.mView;
                        compoundButton.setButtonDrawable(AppCompatResources.getDrawable(compoundButton.getContext(), resourceId));
                    } catch (NotFoundException e) {
                    }
                    if (obtainStyledAttributes$ar$ds.hasValue(2)) {
                        this.mView.setButtonTintList(obtainStyledAttributes$ar$ds.getColorStateList(2));
                    }
                    if (obtainStyledAttributes$ar$ds.hasValue(3)) {
                        this.mView.setButtonTintMode(DrawableUtils.parseTintMode(obtainStyledAttributes$ar$ds.getInt(3, -1), null));
                    }
                    obtainStyledAttributes$ar$ds.recycle();
                }
            }
            if (obtainStyledAttributes$ar$ds.hasValue(0)) {
                resourceId = obtainStyledAttributes$ar$ds.getResourceId(0, 0);
                if (resourceId != 0) {
                    compoundButton = this.mView;
                    compoundButton.setButtonDrawable(AppCompatResources.getDrawable(compoundButton.getContext(), resourceId));
                }
            }
            if (obtainStyledAttributes$ar$ds.hasValue(2)) {
                this.mView.setButtonTintList(obtainStyledAttributes$ar$ds.getColorStateList(2));
            }
            if (obtainStyledAttributes$ar$ds.hasValue(3)) {
                this.mView.setButtonTintMode(DrawableUtils.parseTintMode(obtainStyledAttributes$ar$ds.getInt(3, -1), null));
            }
            obtainStyledAttributes$ar$ds.recycle();
        } catch (Throwable th) {
            obtainStyledAttributes$ar$ds.recycle();
        }
    }

    final void onSetButtonDrawable() {
        if (this.mSkipNextApply) {
            this.mSkipNextApply = false;
            return;
        }
        this.mSkipNextApply = true;
        this.mView.getButtonDrawable();
    }
}
