package android.support.p002v7.widget;

import android.support.p000v4.util.Preconditions;
import android.support.p002v7.widget.ConcatAdapterController.WrapperAndLocalPosition;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.support.p002v7.widget.ViewTypeStorage.IsolatedViewTypeStorage.WrapperViewTypeLookup;
import android.util.Log;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ConcatAdapter */
public final class ConcatAdapter extends Adapter {
    private final ConcatAdapterController mController;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ConcatAdapter$Config */
    public final class Config {
        public final int stableIdMode$ar$edu;

        static {
            Config config = new Config(1);
        }

        public Config(int i) {
            this.stableIdMode$ar$edu = i;
        }
    }

    public ConcatAdapter(Config config, List list) {
        this.mController = new ConcatAdapterController(this, config);
        for (Adapter adapter : list) {
            ConcatAdapterController concatAdapterController = this.mController;
            int size = concatAdapterController.mWrappers.size();
            if (size < 0 || size > concatAdapterController.mWrappers.size()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Index must be between 0 and ");
                stringBuilder.append(concatAdapterController.mWrappers.size());
                stringBuilder.append(". Given:");
                stringBuilder.append(size);
                throw new IndexOutOfBoundsException(stringBuilder.toString());
            }
            NestedAdapterWrapper nestedAdapterWrapper;
            if (concatAdapterController.hasStableIds()) {
                Preconditions.checkArgument(adapter.mHasStableIds, "All sub adapters must have stable ids when stable id mode is ISOLATED_STABLE_IDS or SHARED_STABLE_IDS");
            } else if (adapter.mHasStableIds) {
                Log.w("ConcatAdapter", "Stable ids in the adapter will be ignored as the ConcatAdapter is configured not to have stable ids");
            }
            int size2 = concatAdapterController.mWrappers.size();
            int i = 0;
            while (i < size2) {
                if (((NestedAdapterWrapper) concatAdapterController.mWrappers.get(i)).adapter == adapter) {
                    break;
                }
                i++;
            }
            i = -1;
            if (i == -1) {
                nestedAdapterWrapper = null;
            } else {
                nestedAdapterWrapper = (NestedAdapterWrapper) concatAdapterController.mWrappers.get(i);
            }
            if (nestedAdapterWrapper == null) {
                nestedAdapterWrapper = new NestedAdapterWrapper(adapter, concatAdapterController, concatAdapterController.mViewTypeStorage$ar$class_merging, concatAdapterController.mStableIdStorage.createStableIdLookup());
                concatAdapterController.mWrappers.add(size, nestedAdapterWrapper);
                for (WeakReference weakReference : concatAdapterController.mAttachedRecyclerViews) {
                    RecyclerView recyclerView = (RecyclerView) weakReference.get();
                    if (recyclerView != null) {
                        adapter.onAttachedToRecyclerView(recyclerView);
                    }
                }
                if (nestedAdapterWrapper.mCachedItemCount > 0) {
                    concatAdapterController.mConcatAdapter.notifyItemRangeInserted(concatAdapterController.countItemsBefore(nestedAdapterWrapper), nestedAdapterWrapper.mCachedItemCount);
                }
                concatAdapterController.calculateAndUpdateStateRestorationPolicy();
            }
        }
        super.setHasStableIds(this.mController.hasStableIds());
    }

    public final long getItemId(int i) {
        ConcatAdapterController concatAdapterController = this.mController;
        WrapperAndLocalPosition findWrapperAndLocalPosition = concatAdapterController.findWrapperAndLocalPosition(i);
        NestedAdapterWrapper nestedAdapterWrapper = findWrapperAndLocalPosition.mWrapper;
        long localToGlobal = nestedAdapterWrapper.mStableIdLookup.localToGlobal(nestedAdapterWrapper.adapter.getItemId(findWrapperAndLocalPosition.mLocalPosition));
        concatAdapterController.releaseWrapperAndLocalPosition(findWrapperAndLocalPosition);
        return localToGlobal;
    }

    public final int getItemViewType(int i) {
        ConcatAdapterController concatAdapterController = this.mController;
        WrapperAndLocalPosition findWrapperAndLocalPosition = concatAdapterController.findWrapperAndLocalPosition(i);
        NestedAdapterWrapper nestedAdapterWrapper = findWrapperAndLocalPosition.mWrapper;
        int i2 = findWrapperAndLocalPosition.mLocalPosition;
        WrapperViewTypeLookup wrapperViewTypeLookup = nestedAdapterWrapper.mViewTypeLookup$ar$class_merging;
        int itemViewType = nestedAdapterWrapper.adapter.getItemViewType(i2);
        i2 = wrapperViewTypeLookup.mLocalToGlobalMapping.indexOfKey(itemViewType);
        if (i2 >= 0) {
            itemViewType = wrapperViewTypeLookup.mLocalToGlobalMapping.valueAt(i2);
        } else {
            ViewTypeStorage$IsolatedViewTypeStorage viewTypeStorage$IsolatedViewTypeStorage = wrapperViewTypeLookup.this$0;
            NestedAdapterWrapper nestedAdapterWrapper2 = wrapperViewTypeLookup.mWrapper;
            int i3 = viewTypeStorage$IsolatedViewTypeStorage.mNextViewType;
            viewTypeStorage$IsolatedViewTypeStorage.mNextViewType = i3 + 1;
            viewTypeStorage$IsolatedViewTypeStorage.mGlobalTypeToWrapper.put(i3, nestedAdapterWrapper2);
            wrapperViewTypeLookup.mLocalToGlobalMapping.put(itemViewType, i3);
            wrapperViewTypeLookup.mGlobalToLocalMapping.put(i3, itemViewType);
            itemViewType = i3;
        }
        concatAdapterController.releaseWrapperAndLocalPosition(findWrapperAndLocalPosition);
        return itemViewType;
    }

    public final void onBindViewHolder(ViewHolder viewHolder, int i) {
        ConcatAdapterController concatAdapterController = this.mController;
        WrapperAndLocalPosition findWrapperAndLocalPosition = concatAdapterController.findWrapperAndLocalPosition(i);
        concatAdapterController.mBinderLookup.put(viewHolder, findWrapperAndLocalPosition.mWrapper);
        NestedAdapterWrapper nestedAdapterWrapper = findWrapperAndLocalPosition.mWrapper;
        nestedAdapterWrapper.adapter.bindViewHolder(viewHolder, findWrapperAndLocalPosition.mLocalPosition);
        concatAdapterController.releaseWrapperAndLocalPosition(findWrapperAndLocalPosition);
    }

    public final void onViewAttachedToWindow(ViewHolder viewHolder) {
        this.mController.getWrapper(viewHolder).adapter.onViewAttachedToWindow(viewHolder);
    }

    public final void onViewDetachedFromWindow(ViewHolder viewHolder) {
        this.mController.getWrapper(viewHolder).adapter.onViewDetachedFromWindow(viewHolder);
    }

    public final int findRelativeAdapterPositionIn(Adapter adapter, ViewHolder viewHolder, int i) {
        ConcatAdapterController concatAdapterController = this.mController;
        NestedAdapterWrapper nestedAdapterWrapper = (NestedAdapterWrapper) concatAdapterController.mBinderLookup.get(viewHolder);
        if (nestedAdapterWrapper == null) {
            return -1;
        }
        i -= concatAdapterController.countItemsBefore(nestedAdapterWrapper);
        int itemCount = nestedAdapterWrapper.adapter.getItemCount();
        if (i >= 0 && i < itemCount) {
            return nestedAdapterWrapper.adapter.findRelativeAdapterPositionIn(adapter, viewHolder, i);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Detected inconsistent adapter updates. The local position of the view holder maps to ");
        stringBuilder.append(i);
        stringBuilder.append(" which is out of bounds for the adapter with size ");
        stringBuilder.append(itemCount);
        stringBuilder.append(".Make sure to immediately call notify methods in your adapter when you change the backing dataviewHolder:");
        stringBuilder.append(viewHolder);
        stringBuilder.append("adapter:");
        stringBuilder.append(adapter);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final int getItemCount() {
        int i = 0;
        for (NestedAdapterWrapper nestedAdapterWrapper : this.mController.mWrappers) {
            i += nestedAdapterWrapper.mCachedItemCount;
        }
        return i;
    }

    public final void onAttachedToRecyclerView(RecyclerView recyclerView) {
        ConcatAdapterController concatAdapterController = this.mController;
        for (WeakReference weakReference : concatAdapterController.mAttachedRecyclerViews) {
            if (weakReference.get() == recyclerView) {
                return;
            }
        }
        concatAdapterController.mAttachedRecyclerViews.add(new WeakReference(recyclerView));
        for (NestedAdapterWrapper nestedAdapterWrapper : concatAdapterController.mWrappers) {
            nestedAdapterWrapper.adapter.onAttachedToRecyclerView(recyclerView);
        }
    }

    public final ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        NestedAdapterWrapper nestedAdapterWrapper = (NestedAdapterWrapper) this.mController.mViewTypeStorage$ar$class_merging.mGlobalTypeToWrapper.get(i);
        if (nestedAdapterWrapper != null) {
            WrapperViewTypeLookup wrapperViewTypeLookup = nestedAdapterWrapper.mViewTypeLookup$ar$class_merging;
            int indexOfKey = wrapperViewTypeLookup.mGlobalToLocalMapping.indexOfKey(i);
            if (indexOfKey >= 0) {
                return nestedAdapterWrapper.adapter.onCreateViewHolder(viewGroup, wrapperViewTypeLookup.mGlobalToLocalMapping.valueAt(indexOfKey));
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("requested global type ");
            stringBuilder.append(i);
            stringBuilder.append(" does not belong to the adapter:");
            stringBuilder.append(wrapperViewTypeLookup.mWrapper.adapter);
            throw new IllegalStateException(stringBuilder.toString());
        }
        stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find the wrapper for global view type ");
        stringBuilder.append(i);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public final void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        ConcatAdapterController concatAdapterController = this.mController;
        for (int size = concatAdapterController.mAttachedRecyclerViews.size() - 1; size >= 0; size--) {
            WeakReference weakReference = (WeakReference) concatAdapterController.mAttachedRecyclerViews.get(size);
            if (weakReference.get() == null) {
                concatAdapterController.mAttachedRecyclerViews.remove(size);
            } else if (weakReference.get() == recyclerView) {
                concatAdapterController.mAttachedRecyclerViews.remove(size);
                break;
            }
        }
        for (NestedAdapterWrapper nestedAdapterWrapper : concatAdapterController.mWrappers) {
            nestedAdapterWrapper.adapter.onDetachedFromRecyclerView(recyclerView);
        }
    }

    public final void onFailedToRecycleView$ar$ds(ViewHolder viewHolder) {
        ConcatAdapterController concatAdapterController = this.mController;
        NestedAdapterWrapper nestedAdapterWrapper = (NestedAdapterWrapper) concatAdapterController.mBinderLookup.get(viewHolder);
        if (nestedAdapterWrapper != null) {
            nestedAdapterWrapper.adapter.onFailedToRecycleView$ar$ds(viewHolder);
            concatAdapterController.mBinderLookup.remove(viewHolder);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find wrapper for ");
        stringBuilder.append(viewHolder);
        stringBuilder.append(", seems like it is not bound by this adapter: ");
        stringBuilder.append(concatAdapterController);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final void onViewRecycled(ViewHolder viewHolder) {
        ConcatAdapterController concatAdapterController = this.mController;
        NestedAdapterWrapper nestedAdapterWrapper = (NestedAdapterWrapper) concatAdapterController.mBinderLookup.get(viewHolder);
        if (nestedAdapterWrapper != null) {
            nestedAdapterWrapper.adapter.onViewRecycled(viewHolder);
            concatAdapterController.mBinderLookup.remove(viewHolder);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot find wrapper for ");
        stringBuilder.append(viewHolder);
        stringBuilder.append(", seems like it is not bound by this adapter: ");
        stringBuilder.append(concatAdapterController);
        throw new IllegalStateException(stringBuilder.toString());
    }
}
