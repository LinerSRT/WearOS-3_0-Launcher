package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.p002v7.app.AppCompatDelegateImpl;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.v7.app.AppCompatDelegateImpl.C00815;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ContentFrameLayout */
public class ContentFrameLayout extends FrameLayout {
    public C00815 mAttachListener$ar$class_merging;
    public final Rect mDecorPadding;
    public TypedValue mFixedHeightMajor;
    public TypedValue mFixedHeightMinor;
    public TypedValue mFixedWidthMajor;
    public TypedValue mFixedWidthMinor;
    public TypedValue mMinWidthMajor;
    public TypedValue mMinWidthMinor;

    public ContentFrameLayout(Context context) {
        this(context, null);
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C00815 c00815 = this.mAttachListener$ar$class_merging;
        if (c00815 != null) {
            AppCompatDelegateImpl appCompatDelegateImpl = c00815.this$0;
            DecorContentParent decorContentParent = appCompatDelegateImpl.mDecorContentParent;
            if (decorContentParent != null) {
                decorContentParent.dismissPopups();
            }
            if (appCompatDelegateImpl.mActionModePopup != null) {
                appCompatDelegateImpl.mWindow.getDecorView().removeCallbacks(appCompatDelegateImpl.mShowActionModePopup);
                if (appCompatDelegateImpl.mActionModePopup.isShowing()) {
                    try {
                        appCompatDelegateImpl.mActionModePopup.dismiss();
                    } catch (IllegalArgumentException e) {
                    }
                }
                appCompatDelegateImpl.mActionModePopup = null;
            }
            appCompatDelegateImpl.endOnGoingFadeAnimation();
            MenuBuilder menuBuilder = appCompatDelegateImpl.getPanelState$ar$ds(0).menu;
            if (menuBuilder != null) {
                menuBuilder.close();
            }
        }
    }

    protected final void onMeasure(int i, int i2) {
        int dimension;
        Object obj;
        TypedValue typedValue;
        int makeMeasureSpec;
        TypedValue typedValue2;
        int dimension2;
        FrameLayout frameLayout = this;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        int i3 = displayMetrics.widthPixels;
        int i4 = displayMetrics.heightPixels;
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        Object obj2 = 1;
        if (mode == LinearLayoutManager.INVALID_OFFSET) {
            TypedValue typedValue3;
            if (i3 < i4) {
                typedValue3 = frameLayout.mFixedWidthMinor;
            } else {
                typedValue3 = frameLayout.mFixedWidthMajor;
            }
            if (!(typedValue3 == null || typedValue3.type == 0)) {
                dimension = typedValue3.type == 5 ? (int) typedValue3.getDimension(displayMetrics) : typedValue3.type == 6 ? (int) typedValue3.getFraction((float) displayMetrics.widthPixels, (float) displayMetrics.widthPixels) : 0;
                if (dimension > 0) {
                    dimension = MeasureSpec.makeMeasureSpec(Math.min(dimension - (frameLayout.mDecorPadding.left + frameLayout.mDecorPadding.right), MeasureSpec.getSize(i)), 1073741824);
                    obj = 1;
                } else {
                    dimension = i;
                    obj = null;
                }
                if (mode2 == LinearLayoutManager.INVALID_OFFSET) {
                    if (i3 >= i4) {
                        typedValue = frameLayout.mFixedHeightMajor;
                    } else {
                        typedValue = frameLayout.mFixedHeightMinor;
                    }
                    if (!(typedValue == null || typedValue.type == 0)) {
                        mode2 = typedValue.type != 5 ? (int) typedValue.getDimension(displayMetrics) : typedValue.type != 6 ? (int) typedValue.getFraction((float) displayMetrics.heightPixels, (float) displayMetrics.heightPixels) : 0;
                        if (mode2 > 0) {
                            mode2 = MeasureSpec.makeMeasureSpec(Math.min(mode2 - (frameLayout.mDecorPadding.top + frameLayout.mDecorPadding.bottom), MeasureSpec.getSize(i2)), 1073741824);
                            super.onMeasure(dimension, mode2);
                            dimension = getMeasuredWidth();
                            makeMeasureSpec = MeasureSpec.makeMeasureSpec(dimension, 1073741824);
                            if (obj == null && mode == LinearLayoutManager.INVALID_OFFSET) {
                                if (i3 >= i4) {
                                    typedValue2 = frameLayout.mMinWidthMinor;
                                } else {
                                    typedValue2 = frameLayout.mMinWidthMajor;
                                }
                                if (!(typedValue2 == null || typedValue2.type == 0)) {
                                    dimension2 = typedValue2.type != 5 ? (int) typedValue2.getDimension(displayMetrics) : typedValue2.type != 6 ? (int) typedValue2.getFraction((float) displayMetrics.widthPixels, (float) displayMetrics.widthPixels) : 0;
                                    if (dimension2 > 0) {
                                        dimension2 -= frameLayout.mDecorPadding.left + frameLayout.mDecorPadding.right;
                                    }
                                    if (dimension >= dimension2) {
                                        makeMeasureSpec = MeasureSpec.makeMeasureSpec(dimension2, 1073741824);
                                    } else {
                                        obj2 = null;
                                    }
                                    if (obj2 != null) {
                                        super.onMeasure(makeMeasureSpec, mode2);
                                    }
                                }
                            }
                            obj2 = null;
                            if (obj2 != null) {
                                super.onMeasure(makeMeasureSpec, mode2);
                            }
                        }
                    }
                }
                mode2 = i2;
                super.onMeasure(dimension, mode2);
                dimension = getMeasuredWidth();
                makeMeasureSpec = MeasureSpec.makeMeasureSpec(dimension, 1073741824);
                if (i3 >= i4) {
                    typedValue2 = frameLayout.mMinWidthMajor;
                } else {
                    typedValue2 = frameLayout.mMinWidthMinor;
                }
                if (typedValue2.type != 5) {
                    if (typedValue2.type != 6) {
                    }
                }
                if (dimension2 > 0) {
                    dimension2 -= frameLayout.mDecorPadding.left + frameLayout.mDecorPadding.right;
                }
                if (dimension >= dimension2) {
                    obj2 = null;
                } else {
                    makeMeasureSpec = MeasureSpec.makeMeasureSpec(dimension2, 1073741824);
                }
                if (obj2 != null) {
                    super.onMeasure(makeMeasureSpec, mode2);
                }
            }
        }
        dimension = i;
        obj = null;
        if (mode2 == LinearLayoutManager.INVALID_OFFSET) {
            if (i3 >= i4) {
                typedValue = frameLayout.mFixedHeightMinor;
            } else {
                typedValue = frameLayout.mFixedHeightMajor;
            }
            if (typedValue.type != 5) {
                if (typedValue.type != 6) {
                }
            }
            if (mode2 > 0) {
                mode2 = MeasureSpec.makeMeasureSpec(Math.min(mode2 - (frameLayout.mDecorPadding.top + frameLayout.mDecorPadding.bottom), MeasureSpec.getSize(i2)), 1073741824);
                super.onMeasure(dimension, mode2);
                dimension = getMeasuredWidth();
                makeMeasureSpec = MeasureSpec.makeMeasureSpec(dimension, 1073741824);
                if (i3 >= i4) {
                    typedValue2 = frameLayout.mMinWidthMinor;
                } else {
                    typedValue2 = frameLayout.mMinWidthMajor;
                }
                if (typedValue2.type != 5) {
                }
                if (dimension2 > 0) {
                    dimension2 -= frameLayout.mDecorPadding.left + frameLayout.mDecorPadding.right;
                }
                if (dimension >= dimension2) {
                    makeMeasureSpec = MeasureSpec.makeMeasureSpec(dimension2, 1073741824);
                } else {
                    obj2 = null;
                }
                if (obj2 != null) {
                    super.onMeasure(makeMeasureSpec, mode2);
                }
            }
        }
        mode2 = i2;
        super.onMeasure(dimension, mode2);
        dimension = getMeasuredWidth();
        makeMeasureSpec = MeasureSpec.makeMeasureSpec(dimension, 1073741824);
        if (i3 >= i4) {
            typedValue2 = frameLayout.mMinWidthMajor;
        } else {
            typedValue2 = frameLayout.mMinWidthMinor;
        }
        if (typedValue2.type != 5) {
            if (typedValue2.type != 6) {
            }
        }
        if (dimension2 > 0) {
            dimension2 -= frameLayout.mDecorPadding.left + frameLayout.mDecorPadding.right;
        }
        if (dimension >= dimension2) {
            obj2 = null;
        } else {
            makeMeasureSpec = MeasureSpec.makeMeasureSpec(dimension2, 1073741824);
        }
        if (obj2 != null) {
            super.onMeasure(makeMeasureSpec, mode2);
        }
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mDecorPadding = new Rect();
    }
}
