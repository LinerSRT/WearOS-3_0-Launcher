package android.support.p002v7.widget;

import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatReceiveContentHelper$1 */
public final class AppCompatReceiveContentHelper$1 {
    public final /* synthetic */ View val$view;

    public AppCompatReceiveContentHelper$1(View view) {
        this.val$view = view;
    }
}
