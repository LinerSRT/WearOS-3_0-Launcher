package android.support.p002v7.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p000v4.util.ObjectsCompat;
import android.support.p000v4.view.ContentInfoCompat.Builder;
import android.support.p000v4.view.ContentInfoCompat.BuilderCompat;
import android.support.p000v4.view.ContentInfoCompat.BuilderCompat31Impl;
import android.support.p000v4.view.ContentInfoCompat.BuilderCompatImpl;
import android.support.p000v4.view.ViewCompat;
import android.text.Selection;
import android.util.AttributeSet;
import android.util.Log;
import android.view.DragEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import androidx.core.view.inputmethod.InputConnectionCompat$1;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatEditText */
public final class AppCompatEditText extends EditText {
    private final AppCompatBackgroundHelper mBackgroundTintHelper;
    private final AppCompatTextHelper mTextHelper;

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        AppCompatBackgroundHelper appCompatBackgroundHelper = this.mBackgroundTintHelper;
        if (appCompatBackgroundHelper != null) {
            appCompatBackgroundHelper.applySupportBackgroundTint();
        }
        AppCompatTextHelper appCompatTextHelper = this.mTextHelper;
        if (appCompatTextHelper != null) {
            appCompatTextHelper.applyCompoundDrawablesTints();
        }
    }

    public final /* bridge */ /* synthetic */ CharSequence getText() {
        return getText();
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        AppCompatHintHelper.onCreateInputConnection$ar$ds(onCreateInputConnection, editorInfo, this);
        String[] onReceiveContentMimeTypes = ViewCompat.getOnReceiveContentMimeTypes(this);
        if (onCreateInputConnection == null || onReceiveContentMimeTypes == null) {
            return onCreateInputConnection;
        }
        editorInfo.contentMimeTypes = onReceiveContentMimeTypes;
        AppCompatReceiveContentHelper$1 appCompatReceiveContentHelper$1 = new AppCompatReceiveContentHelper$1(this);
        ObjectsCompat.requireNonNull$ar$ds(editorInfo, "editorInfo must be non-null");
        return new InputConnectionCompat$1(onCreateInputConnection, appCompatReceiveContentHelper$1);
    }

    public final void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        AppCompatBackgroundHelper appCompatBackgroundHelper = this.mBackgroundTintHelper;
        if (appCompatBackgroundHelper != null) {
            appCompatBackgroundHelper.onSetBackgroundDrawable$ar$ds();
        }
    }

    public final void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        AppCompatBackgroundHelper appCompatBackgroundHelper = this.mBackgroundTintHelper;
        if (appCompatBackgroundHelper != null) {
            appCompatBackgroundHelper.onSetBackgroundResource(i);
        }
    }

    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        AppCompatTextHelper appCompatTextHelper = this.mTextHelper;
        if (appCompatTextHelper != null) {
            appCompatTextHelper.onSetTextAppearance(context, i);
        }
    }

    public AppCompatEditText(Context context, AttributeSet attributeSet) {
        TintContextWrapper.wrap$ar$ds$c2d4b793_0(context);
        super(context, attributeSet, R.attr.editTextStyle);
        ThemeUtils.checkAppCompatTheme(this, getContext());
        AppCompatBackgroundHelper appCompatBackgroundHelper = new AppCompatBackgroundHelper(this);
        this.mBackgroundTintHelper = appCompatBackgroundHelper;
        appCompatBackgroundHelper.loadFromAttributes(attributeSet, R.attr.editTextStyle);
        AppCompatTextHelper appCompatTextHelper = new AppCompatTextHelper(this);
        this.mTextHelper = appCompatTextHelper;
        appCompatTextHelper.loadFromAttributes(attributeSet, R.attr.editTextStyle);
        appCompatTextHelper.applyCompoundDrawablesTints();
    }

    public final boolean onDragEvent(DragEvent dragEvent) {
        if (dragEvent.getLocalState() == null) {
            if (ViewCompat.getOnReceiveContentMimeTypes(this) != null) {
                Activity activity;
                for (Context context = getContext(); context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
                    if (context instanceof Activity) {
                        activity = (Activity) context;
                        break;
                    }
                }
                activity = null;
                if (activity == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Can't handle drop: no activity: view=");
                    stringBuilder.append(this);
                    Log.i("ReceiveContent", stringBuilder.toString());
                } else if (dragEvent.getAction() != 1 && dragEvent.getAction() == 3) {
                    activity.requestDragAndDropPermissions(dragEvent);
                    int offsetForPosition = getOffsetForPosition(dragEvent.getX(), dragEvent.getY());
                    beginBatchEdit();
                    try {
                        BuilderCompat builderCompat31Impl;
                        Selection.setSelection(getText(), offsetForPosition);
                        ClipData clipData = dragEvent.getClipData();
                        if (VERSION.SDK_INT >= 31) {
                            builderCompat31Impl = new BuilderCompat31Impl(clipData, 3);
                        } else {
                            builderCompat31Impl = new BuilderCompatImpl(clipData, 3);
                        }
                        ViewCompat.performReceiveContent(this, Builder.build$ar$objectUnboxing$9e7ca98a_0(builderCompat31Impl));
                        return true;
                    } finally {
                        endBatchEdit();
                    }
                }
            }
        }
        return super.onDragEvent(dragEvent);
    }

    public final boolean onTextContextMenuItem(int i) {
        int i2 = 16908337;
        if (i != 16908322) {
            if (i == 16908337) {
                i = 16908337;
            }
            return super.onTextContextMenuItem(i);
        }
        i2 = i;
        if (ViewCompat.getOnReceiveContentMimeTypes(this) != null) {
            ClipData clipData;
            ClipboardManager clipboardManager = (ClipboardManager) getContext().getSystemService("clipboard");
            if (clipboardManager == null) {
                clipData = null;
            } else {
                clipData = clipboardManager.getPrimaryClip();
            }
            if (clipData != null && clipData.getItemCount() > 0) {
                BuilderCompat builderCompat31Impl;
                if (VERSION.SDK_INT >= 31) {
                    builderCompat31Impl = new BuilderCompat31Impl(clipData, 1);
                } else {
                    builderCompat31Impl = new BuilderCompatImpl(clipData, 1);
                }
                if (i2 == 16908322) {
                    i = 0;
                } else {
                    i = 1;
                }
                builderCompat31Impl.setFlags(i);
                ViewCompat.performReceiveContent(this, Builder.build$ar$objectUnboxing$9e7ca98a_0(builderCompat31Impl));
            }
            return true;
        }
        return super.onTextContextMenuItem(i);
    }
}
