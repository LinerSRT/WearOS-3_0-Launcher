package android.support.p002v7.widget;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.os.Trace;
import android.support.p000v4.view.AccessibilityDelegateCompat;
import android.support.p000v4.view.NestedScrollingChildHelper;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.CollectionInfoCompat;
import android.support.p000v4.widget.EdgeEffectCompat;
import android.support.p002v7.recyclerview.R$styleable;
import android.support.p002v7.widget.AdapterHelper.UpdateOp;
import android.support.p002v7.widget.GapWorker.LayoutPrefetchRegistryImpl;
import android.support.p002v7.widget.RecyclerView.ItemAnimator;
import android.support.p002v7.widget.RecyclerView.ItemAnimator.ItemHolderInfo;
import android.support.p002v7.widget.RecyclerView.LayoutParams;
import android.support.p002v7.widget.RecyclerView.Recycler;
import android.support.p002v7.widget.RecyclerView.State;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.support.p002v7.widget.RecyclerViewAccessibilityDelegate.ItemDelegate;
import android.support.p002v7.widget.ViewBoundsCheck.Callback;
import android.support.p002v7.widget.ViewInfoStore.InfoRecord;
import android.support.v7.widget.RecyclerView.C01052;
import android.support.v7.widget.RecyclerView.C01063;
import android.support.v7.widget.RecyclerView.C01074;
import android.support.v7.widget.RecyclerView.C01085;
import android.support.v7.widget.RecyclerView.C01096;
import android.support.v7.widget.RecyclerView.LayoutManager.C01102;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import androidx.customview.view.AbsSavedState;
import com.google.android.clockwork.sysui.mainui.notification.revelio.trayview.p015ui.NotificationTrayViewController$1$$ExternalSyntheticLambda0;
import com.google.android.wearable.sysui.R;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.RecyclerView */
public class RecyclerView extends ViewGroup {
    private static final Class[] LAYOUT_MANAGER_CONSTRUCTOR_SIGNATURE = new Class[]{Context.class, AttributeSet.class, Integer.TYPE, Integer.TYPE};
    private static final int[] NESTED_SCROLLING_ATTRS = new int[]{16843830};
    public static final /* synthetic */ int RecyclerView$ar$NoOp = 0;
    static final StretchEdgeEffectFactory sDefaultEdgeEffectFactory = new StretchEdgeEffectFactory();
    static final Interpolator sQuinticInterpolator = new C01063();
    RecyclerViewAccessibilityDelegate mAccessibilityDelegate;
    private final AccessibilityManager mAccessibilityManager;
    public Adapter mAdapter;
    AdapterHelper mAdapterHelper;
    boolean mAdapterUpdateDuringMeasure;
    public EdgeEffect mBottomGlow;
    ChildHelper mChildHelper;
    boolean mClipToPadding;
    boolean mDataSetHasChangedAfterLayout;
    boolean mDispatchItemsChangedEvent;
    private int mDispatchScrollCounter;
    private int mEatenAccessibilityChangeFlags;
    private EdgeEffectFactory mEdgeEffectFactory;
    boolean mFirstLayoutComplete;
    GapWorker mGapWorker;
    boolean mHasFixedSize;
    private boolean mIgnoreMotionEventTillDown;
    private int mInitialTouchX;
    private int mInitialTouchY;
    private int mInterceptRequestLayoutDepth;
    private OnItemTouchListener mInterceptingOnItemTouchListener;
    public boolean mIsAttached;
    public ItemAnimator mItemAnimator;
    private ItemAnimatorRestoreListener mItemAnimatorListener$ar$class_merging;
    private Runnable mItemAnimatorRunner;
    final ArrayList mItemDecorations;
    boolean mItemsAddedOrRemoved;
    boolean mItemsChanged;
    private int mLastAutoMeasureNonExactMeasuredHeight;
    private int mLastAutoMeasureNonExactMeasuredWidth;
    private boolean mLastAutoMeasureSkippedDueToExact;
    private int mLastTouchX;
    private int mLastTouchY;
    public LayoutManager mLayout;
    private int mLayoutOrScrollCounter;
    boolean mLayoutSuppressed;
    boolean mLayoutWasDefered;
    public EdgeEffect mLeftGlow;
    public final int mMaxFlingVelocity;
    public final int mMinFlingVelocity;
    private final int[] mMinMaxLayoutPositions;
    private final int[] mNestedOffsets;
    private final RecyclerViewDataObserver mObserver;
    public List mOnChildAttachStateListeners;
    public OnFlingListener mOnFlingListener;
    private final ArrayList mOnItemTouchListeners;
    final List mPendingAccessibilityImportanceChange;
    SavedState mPendingSavedState;
    boolean mPostedAnimatorRunner;
    LayoutPrefetchRegistryImpl mPrefetchRegistry;
    private boolean mPreserveFocusAfterLayout;
    final Recycler mRecycler;
    final List mRecyclerListeners;
    final int[] mReusableIntPair;
    public EdgeEffect mRightGlow;
    private float mScaledHorizontalScrollFactor;
    private float mScaledVerticalScrollFactor;
    public OnScrollListener mScrollListener;
    public List mScrollListeners;
    private final int[] mScrollOffset;
    private int mScrollPointerId;
    public int mScrollState;
    private NestedScrollingChildHelper mScrollingChildHelper;
    final State mState;
    final Rect mTempRect;
    private final Rect mTempRect2;
    final RectF mTempRectF;
    public EdgeEffect mTopGlow;
    public int mTouchSlop;
    final Runnable mUpdateChildViewsRunnable;
    private VelocityTracker mVelocityTracker;
    final ViewFlinger mViewFlinger;
    private final C01074 mViewInfoProcessCallback$ar$class_merging;
    final ViewInfoStore mViewInfoStore;

    /* renamed from: android.support.v7.widget.RecyclerView$1 */
    final class PG implements Runnable {
        public final void run() {
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.mFirstLayoutComplete) {
                if (!recyclerView.isLayoutRequested()) {
                    recyclerView = RecyclerView.this;
                    if (!recyclerView.mIsAttached) {
                        recyclerView.requestLayout();
                    } else if (recyclerView.mLayoutSuppressed) {
                        recyclerView.mLayoutWasDefered = true;
                    } else {
                        recyclerView.consumePendingUpdateOperations();
                    }
                }
            }
        }
    }

    /* renamed from: android.support.v7.widget.RecyclerView$2 */
    final class C01052 implements Runnable {
        public final void run() {
            ItemAnimator itemAnimator = android.support.p002v7.widget.RecyclerView.this.mItemAnimator;
            if (itemAnimator != null) {
                itemAnimator.runPendingAnimations();
            }
            android.support.p002v7.widget.RecyclerView.this.mPostedAnimatorRunner = false;
        }
    }

    /* renamed from: android.support.v7.widget.RecyclerView$3 */
    final class C01063 implements Interpolator {
        public final float getInterpolation(float f) {
            f -= 4.0f;
            return ((((f * f) * f) * f) * f) + 1.0f;
        }
    }

    /* renamed from: android.support.v7.widget.RecyclerView$4 */
    final class C01074 {
        public final void processDisappeared(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2) {
            android.support.p002v7.widget.RecyclerView.this.mRecycler.unscrapView(viewHolder);
            android.support.p002v7.widget.RecyclerView recyclerView = android.support.p002v7.widget.RecyclerView.this;
            recyclerView.addAnimatingView(viewHolder);
            viewHolder.setIsRecyclable(false);
            if (recyclerView.mItemAnimator.animateDisappearance(viewHolder, itemHolderInfo, itemHolderInfo2)) {
                recyclerView.postAnimationRunner();
            }
        }

        public final void unused(ViewHolder viewHolder) {
            android.support.p002v7.widget.RecyclerView recyclerView = android.support.p002v7.widget.RecyclerView.this;
            recyclerView.mLayout.removeAndRecycleView(viewHolder.itemView, recyclerView.mRecycler);
        }

        public final void processAppeared(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2) {
            android.support.p002v7.widget.RecyclerView recyclerView = android.support.p002v7.widget.RecyclerView.this;
            viewHolder.setIsRecyclable(false);
            if (recyclerView.mItemAnimator.animateAppearance(viewHolder, itemHolderInfo, itemHolderInfo2)) {
                recyclerView.postAnimationRunner();
            }
        }
    }

    /* renamed from: android.support.v7.widget.RecyclerView$5 */
    final class C01085 {
        public final View getChildAt(int i) {
            return android.support.p002v7.widget.RecyclerView.this.getChildAt(i);
        }

        public final int getChildCount() {
            return android.support.p002v7.widget.RecyclerView.this.getChildCount();
        }

        public final int indexOfChild(View view) {
            return android.support.p002v7.widget.RecyclerView.this.indexOfChild(view);
        }

        public final void onLeftHiddenState(View view) {
            ViewHolder childViewHolderInt = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt != null) {
                android.support.p002v7.widget.RecyclerView.this.setChildImportantForAccessibilityInternal$ar$ds(childViewHolderInt, childViewHolderInt.mWasImportantForAccessibilityBeforeHidden);
                childViewHolderInt.mWasImportantForAccessibilityBeforeHidden = 0;
            }
        }

        public final void removeViewAt(int i) {
            View childAt = android.support.p002v7.widget.RecyclerView.this.getChildAt(i);
            if (childAt != null) {
                android.support.p002v7.widget.RecyclerView.this.dispatchChildDetached(childAt);
                childAt.clearAnimation();
            }
            android.support.p002v7.widget.RecyclerView.this.removeViewAt(i);
        }
    }

    /* renamed from: android.support.v7.widget.RecyclerView$6 */
    final class C01096 {
        final void dispatchUpdate(UpdateOp updateOp) {
            android.support.p002v7.widget.RecyclerView recyclerView;
            switch (updateOp.cmd) {
                case 1:
                    recyclerView = android.support.p002v7.widget.RecyclerView.this;
                    recyclerView.mLayout.onItemsAdded(recyclerView, updateOp.positionStart, updateOp.itemCount);
                    return;
                case 2:
                    recyclerView = android.support.p002v7.widget.RecyclerView.this;
                    recyclerView.mLayout.onItemsRemoved(recyclerView, updateOp.positionStart, updateOp.itemCount);
                    return;
                case 4:
                    recyclerView = android.support.p002v7.widget.RecyclerView.this;
                    recyclerView.mLayout.onItemsUpdated(recyclerView, updateOp.positionStart, updateOp.itemCount, updateOp.payload);
                    return;
                case 8:
                    recyclerView = android.support.p002v7.widget.RecyclerView.this;
                    recyclerView.mLayout.onItemsMoved(recyclerView, updateOp.positionStart, updateOp.itemCount, 1);
                    return;
                default:
                    return;
            }
        }

        public final void offsetPositionsForRemovingInvisible(int i, int i2) {
            android.support.p002v7.widget.RecyclerView.this.offsetPositionRecordsForRemove(i, i2, true);
            android.support.p002v7.widget.RecyclerView recyclerView = android.support.p002v7.widget.RecyclerView.this;
            recyclerView.mItemsAddedOrRemoved = true;
            State state = recyclerView.mState;
            state.mDeletedInvisibleItemCountSincePreviousLayout += i2;
        }

        public final ViewHolder findViewHolder(int i) {
            android.support.p002v7.widget.RecyclerView recyclerView = android.support.p002v7.widget.RecyclerView.this;
            int unfilteredChildCount = recyclerView.mChildHelper.getUnfilteredChildCount();
            ViewHolder viewHolder = null;
            for (int i2 = 0; i2 < unfilteredChildCount; i2++) {
                ViewHolder childViewHolderInt = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(recyclerView.mChildHelper.getUnfilteredChildAt(i2));
                if (!(childViewHolderInt == null || childViewHolderInt.isRemoved())) {
                    if (childViewHolderInt.mPosition == i) {
                        if (!recyclerView.mChildHelper.isHidden(childViewHolderInt.itemView)) {
                            viewHolder = childViewHolderInt;
                            break;
                        }
                        viewHolder = childViewHolderInt;
                    }
                }
            }
            if (viewHolder == null || android.support.p002v7.widget.RecyclerView.this.mChildHelper.isHidden(viewHolder.itemView)) {
                return null;
            }
            return viewHolder;
        }

        public final void markViewHoldersUpdated(int i, int i2, Object obj) {
            int i3;
            android.support.p002v7.widget.RecyclerView recyclerView = android.support.p002v7.widget.RecyclerView.this;
            int unfilteredChildCount = recyclerView.mChildHelper.getUnfilteredChildCount();
            i2 += i;
            for (i3 = 0; i3 < unfilteredChildCount; i3++) {
                View unfilteredChildAt = recyclerView.mChildHelper.getUnfilteredChildAt(i3);
                ViewHolder childViewHolderInt = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(unfilteredChildAt);
                if (childViewHolderInt != null) {
                    if (!childViewHolderInt.shouldIgnore()) {
                        int i4 = childViewHolderInt.mPosition;
                        if (i4 >= i && i4 < i2) {
                            childViewHolderInt.addFlags(2);
                            childViewHolderInt.addChangePayload(obj);
                            ((LayoutParams) unfilteredChildAt.getLayoutParams()).mInsetsDirty = true;
                        }
                    }
                }
            }
            Recycler recycler = recyclerView.mRecycler;
            for (int size = recycler.mCachedViews.size() - 1; size >= 0; size--) {
                ViewHolder viewHolder = (ViewHolder) recycler.mCachedViews.get(size);
                if (viewHolder != null) {
                    i3 = viewHolder.mPosition;
                    if (i3 >= i && i3 < i2) {
                        viewHolder.addFlags(2);
                        recycler.recycleCachedViewAt(size);
                    }
                }
            }
            android.support.p002v7.widget.RecyclerView.this.mItemsChanged = true;
        }

        public final void offsetPositionsForAdd(int i, int i2) {
            int i3;
            android.support.p002v7.widget.RecyclerView recyclerView = android.support.p002v7.widget.RecyclerView.this;
            int unfilteredChildCount = recyclerView.mChildHelper.getUnfilteredChildCount();
            for (i3 = 0; i3 < unfilteredChildCount; i3++) {
                ViewHolder childViewHolderInt = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(recyclerView.mChildHelper.getUnfilteredChildAt(i3));
                if (!(childViewHolderInt == null || childViewHolderInt.shouldIgnore() || childViewHolderInt.mPosition < i)) {
                    childViewHolderInt.offsetPosition(i2, false);
                    recyclerView.mState.mStructureChanged = true;
                }
            }
            Recycler recycler = recyclerView.mRecycler;
            i3 = recycler.mCachedViews.size();
            for (int i4 = 0; i4 < i3; i4++) {
                ViewHolder viewHolder = (ViewHolder) recycler.mCachedViews.get(i4);
                if (viewHolder != null && viewHolder.mPosition >= i) {
                    viewHolder.offsetPosition(i2, false);
                }
            }
            recyclerView.requestLayout();
            android.support.p002v7.widget.RecyclerView.this.mItemsAddedOrRemoved = true;
        }

        public final void offsetPositionsForMove(int i, int i2) {
            int i3;
            int i4;
            int i5;
            int i6;
            android.support.p002v7.widget.RecyclerView recyclerView = android.support.p002v7.widget.RecyclerView.this;
            int unfilteredChildCount = recyclerView.mChildHelper.getUnfilteredChildCount();
            int i7 = -1;
            if (i < i2) {
                i3 = -1;
            } else {
                i3 = 1;
            }
            if (i < i2) {
                i4 = i2;
            } else {
                i4 = i;
            }
            if (i < i2) {
                i5 = i;
            } else {
                i5 = i2;
            }
            for (i6 = 0; i6 < unfilteredChildCount; i6++) {
                int i8;
                ViewHolder childViewHolderInt = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(recyclerView.mChildHelper.getUnfilteredChildAt(i6));
                if (childViewHolderInt != null) {
                    i8 = childViewHolderInt.mPosition;
                    if (i8 >= i5) {
                        if (i8 <= i4) {
                            if (i8 == i) {
                                childViewHolderInt.offsetPosition(i2 - i, false);
                            } else {
                                childViewHolderInt.offsetPosition(i3, false);
                            }
                            recyclerView.mState.mStructureChanged = true;
                        }
                    }
                }
            }
            Recycler recycler = recyclerView.mRecycler;
            if (i >= i2) {
                i7 = 1;
            }
            i3 = recycler.mCachedViews.size();
            for (i6 = 0; i6 < i3; i6++) {
                childViewHolderInt = (ViewHolder) recycler.mCachedViews.get(i6);
                if (childViewHolderInt != null) {
                    i8 = childViewHolderInt.mPosition;
                    if (i8 >= i5) {
                        if (i8 <= i4) {
                            if (i8 == i) {
                                childViewHolderInt.offsetPosition(i2 - i, false);
                            } else {
                                childViewHolderInt.offsetPosition(i7, false);
                            }
                        }
                    }
                }
            }
            recyclerView.requestLayout();
            android.support.p002v7.widget.RecyclerView.this.mItemsAddedOrRemoved = true;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$Adapter */
    public abstract class Adapter {
        public boolean mHasStableIds = false;
        public final AdapterDataObservable mObservable = new AdapterDataObservable();
        public int mStateRestorationPolicy$ar$edu = 1;

        public final void bindViewHolder(ViewHolder viewHolder, int i) {
            Adapter adapter = viewHolder.mBindingAdapter;
            if (adapter == null) {
                viewHolder.mPosition = i;
                if (this.mHasStableIds) {
                    viewHolder.mItemId = getItemId(i);
                }
                viewHolder.setFlags(1, 519);
                Trace.beginSection("RV OnBindView");
            }
            viewHolder.mBindingAdapter = this;
            viewHolder.getUnmodifiedPayloads();
            onBindViewHolder(viewHolder, i);
            if (adapter == null) {
                viewHolder.clearPayload();
                ViewGroup.LayoutParams layoutParams = viewHolder.itemView.getLayoutParams();
                if (layoutParams instanceof LayoutParams) {
                    ((LayoutParams) layoutParams).mInsetsDirty = true;
                }
                Trace.endSection();
            }
        }

        public int findRelativeAdapterPositionIn(Adapter adapter, ViewHolder viewHolder, int i) {
            return adapter == this ? i : -1;
        }

        public abstract int getItemCount();

        public long getItemId(int i) {
            return -1;
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public final void notifyDataSetChanged() {
            this.mObservable.notifyChanged();
        }

        public final void notifyItemMoved(int i, int i2) {
            this.mObservable.notifyItemMoved(i, i2);
        }

        public final void notifyItemRangeChanged(int i, int i2, Object obj) {
            this.mObservable.notifyItemRangeChanged(i, i2, obj);
        }

        public final void notifyItemRangeInserted(int i, int i2) {
            this.mObservable.notifyItemRangeInserted(i, i2);
        }

        public final void notifyItemRangeRemoved(int i, int i2) {
            this.mObservable.notifyItemRangeRemoved(i, i2);
        }

        public final void notifyItemRemoved(int i) {
            this.mObservable.notifyItemRangeRemoved(i, 1);
        }

        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        }

        public abstract void onBindViewHolder(ViewHolder viewHolder, int i);

        public abstract ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i);

        public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        }

        public void onFailedToRecycleView$ar$ds(ViewHolder viewHolder) {
        }

        public void onViewAttachedToWindow(ViewHolder viewHolder) {
        }

        public void onViewDetachedFromWindow(ViewHolder viewHolder) {
        }

        public void onViewRecycled(ViewHolder viewHolder) {
        }

        public final void registerAdapterDataObserver(AdapterDataObserver adapterDataObserver) {
            this.mObservable.registerObserver(adapterDataObserver);
        }

        public final void unregisterAdapterDataObserver(AdapterDataObserver adapterDataObserver) {
            this.mObservable.unregisterObserver(adapterDataObserver);
        }

        final boolean canRestoreState() {
            int i = this.mStateRestorationPolicy$ar$edu;
            int i2 = i - 1;
            if (i != 0) {
                switch (i2) {
                    case 1:
                        return getItemCount() > 0;
                    case 2:
                        return false;
                    default:
                        return true;
                }
            }
            throw null;
        }

        public final void notifyItemChanged(int i) {
            this.mObservable.notifyItemRangeChanged(i, 1, null);
        }

        public final void setHasStableIds(boolean z) {
            if (this.mObservable.hasObservers()) {
                throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
            }
            this.mHasStableIds = z;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$AdapterDataObservable */
    public final class AdapterDataObservable extends Observable {
        public final boolean hasObservers() {
            return !this.mObservers.isEmpty();
        }

        public final void notifyChanged() {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((AdapterDataObserver) this.mObservers.get(size)).onChanged();
            }
        }

        public final void notifyItemMoved(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((AdapterDataObserver) this.mObservers.get(size)).onItemRangeMoved$ar$ds(i, i2);
            }
        }

        public final void notifyItemRangeChanged(int i, int i2, Object obj) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((AdapterDataObserver) this.mObservers.get(size)).onItemRangeChanged(i, i2, obj);
            }
        }

        public final void notifyItemRangeInserted(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((AdapterDataObserver) this.mObservers.get(size)).onItemRangeInserted(i, i2);
            }
        }

        public final void notifyItemRangeRemoved(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((AdapterDataObserver) this.mObservers.get(size)).onItemRangeRemoved(i, i2);
            }
        }

        public final void notifyStateRestorationPolicyChanged() {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                ((AdapterDataObserver) this.mObservers.get(size)).onStateRestorationPolicyChanged();
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$AdapterDataObserver */
    public class AdapterDataObserver {
        public void onChanged() {
        }

        public void onItemRangeChanged(int i, int i2) {
        }

        public void onItemRangeInserted(int i, int i2) {
        }

        public void onItemRangeMoved$ar$ds(int i, int i2) {
        }

        public void onItemRangeRemoved(int i, int i2) {
        }

        public void onStateRestorationPolicyChanged() {
        }

        public void onItemRangeChanged(int i, int i2, Object obj) {
            onItemRangeChanged(i, i2);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$EdgeEffectFactory */
    public class EdgeEffectFactory {
        protected EdgeEffect createEdgeEffect$ar$ds(RecyclerView recyclerView) {
            throw null;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$ItemAnimator */
    public abstract class ItemAnimator {
        private final ArrayList mFinishedListeners = new ArrayList();
        public ItemAnimatorRestoreListener mListener$ar$class_merging$4809de85_0 = null;

        /* compiled from: PG */
        /* renamed from: android.support.v7.widget.RecyclerView$ItemAnimator$ItemHolderInfo */
        public final class ItemHolderInfo {
            public int left;
            public int top;

            public final void setFrom$ar$ds(ViewHolder viewHolder) {
                View view = viewHolder.itemView;
                this.left = view.getLeft();
                this.top = view.getTop();
                view.getRight();
                view.getBottom();
            }
        }

        static void buildAdapterChangeFlagsForAnimations$ar$ds(ViewHolder viewHolder) {
            int i = viewHolder.mFlags;
            if (!viewHolder.isInvalid() && (i & 4) == 0) {
                i = viewHolder.mOldPosition;
                viewHolder.getAbsoluteAdapterPosition();
            }
        }

        public static final ItemHolderInfo obtainHolderInfo$ar$ds() {
            return new ItemHolderInfo();
        }

        public static final ItemHolderInfo recordPreLayoutInformation$ar$ds$2b04a7c7_0(ViewHolder viewHolder) {
            ItemHolderInfo obtainHolderInfo$ar$ds = ItemAnimator.obtainHolderInfo$ar$ds();
            obtainHolderInfo$ar$ds.setFrom$ar$ds(viewHolder);
            return obtainHolderInfo$ar$ds;
        }

        public abstract boolean animateAppearance(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2);

        public abstract boolean animateChange(ViewHolder viewHolder, ViewHolder viewHolder2, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2);

        public abstract boolean animateDisappearance(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2);

        public abstract boolean animatePersistence(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo, ItemHolderInfo itemHolderInfo2);

        public boolean canReuseUpdatedViewHolder(ViewHolder viewHolder) {
            throw null;
        }

        public boolean canReuseUpdatedViewHolder(ViewHolder viewHolder, List list) {
            throw null;
        }

        public final void dispatchAnimationsFinished() {
            int size = this.mFinishedListeners.size();
            for (int i = 0; i < size; i++) {
                ((NotificationTrayViewController$1$$ExternalSyntheticLambda0) this.mFinishedListeners.get(i)).onAnimationsFinished();
            }
            this.mFinishedListeners.clear();
        }

        public abstract void endAnimation(ViewHolder viewHolder);

        public abstract void endAnimations();

        public long getMoveDuration() {
            return 250;
        }

        public long getRemoveDuration() {
            return 120;
        }

        public abstract boolean isRunning();

        public final boolean isRunning$ar$class_merging(NotificationTrayViewController$1$$ExternalSyntheticLambda0 notificationTrayViewController$1$$ExternalSyntheticLambda0) {
            boolean isRunning = isRunning();
            if (notificationTrayViewController$1$$ExternalSyntheticLambda0 != null) {
                if (isRunning) {
                    this.mFinishedListeners.add(notificationTrayViewController$1$$ExternalSyntheticLambda0);
                } else {
                    notificationTrayViewController$1$$ExternalSyntheticLambda0.onAnimationsFinished();
                }
            }
            return isRunning;
        }

        public abstract void runPendingAnimations();

        public final void dispatchAnimationFinished(ViewHolder viewHolder) {
            ItemAnimatorRestoreListener itemAnimatorRestoreListener = this.mListener$ar$class_merging$4809de85_0;
            if (itemAnimatorRestoreListener != null) {
                int i = 1;
                viewHolder.setIsRecyclable(true);
                if (viewHolder.mShadowedHolder != null && viewHolder.mShadowingHolder == null) {
                    viewHolder.mShadowedHolder = null;
                }
                viewHolder.mShadowingHolder = null;
                if ((viewHolder.mFlags & 16) == 0) {
                    RecyclerView recyclerView = itemAnimatorRestoreListener.this$0;
                    View view = viewHolder.itemView;
                    recyclerView.startInterceptRequestLayout();
                    ChildHelper childHelper = recyclerView.mChildHelper;
                    int indexOfChild = childHelper.mCallback$ar$class_merging$5a35e444_0.indexOfChild(view);
                    if (indexOfChild == -1) {
                        childHelper.unhideViewInternal$ar$ds(view);
                    } else if (childHelper.mBucket.get(indexOfChild)) {
                        childHelper.mBucket.remove(indexOfChild);
                        childHelper.unhideViewInternal$ar$ds(view);
                        childHelper.mCallback$ar$class_merging$5a35e444_0.removeViewAt(indexOfChild);
                    } else {
                        i = 0;
                    }
                    if (i != 0) {
                        ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
                        recyclerView.mRecycler.unscrapView(childViewHolderInt);
                        recyclerView.mRecycler.recycleViewHolderInternal(childViewHolderInt);
                    }
                    recyclerView.stopInterceptRequestLayout(i ^ 1);
                    if (i == 0 && viewHolder.isTmpDetached()) {
                        itemAnimatorRestoreListener.this$0.removeDetachedView(viewHolder.itemView, false);
                    }
                }
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$ItemAnimatorRestoreListener */
    final class ItemAnimatorRestoreListener {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$ItemDecoration */
    public class ItemDecoration {
        public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, State state) {
            ((LayoutParams) view.getLayoutParams()).getViewLayoutPosition();
            rect.set(0, 0, 0, 0);
        }

        public void onDraw$ar$ds(Canvas canvas, RecyclerView recyclerView) {
        }

        public void onDrawOver$ar$ds(Canvas canvas, RecyclerView recyclerView) {
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$LayoutManager */
    public abstract class LayoutManager {
        boolean mAutoMeasure = false;
        ChildHelper mChildHelper;
        private int mHeight;
        private int mHeightMode;
        ViewBoundsCheck mHorizontalBoundCheck;
        private final Callback mHorizontalBoundCheckCallback;
        boolean mIsAttachedToWindow = false;
        private boolean mItemPrefetchEnabled = true;
        private boolean mMeasurementCacheEnabled = true;
        int mPrefetchMaxCountObserved;
        boolean mPrefetchMaxObservedInInitialPrefetch;
        RecyclerView mRecyclerView;
        boolean mRequestedSimpleAnimations = false;
        SmoothScroller mSmoothScroller;
        ViewBoundsCheck mVerticalBoundCheck;
        private final Callback mVerticalBoundCheckCallback;
        private int mWidth;
        private int mWidthMode;

        /* renamed from: android.support.v7.widget.RecyclerView$LayoutManager$1 */
        final class PG implements Callback {
            public final View getChildAt(int i) {
                return LayoutManager.this.getChildAt(i);
            }

            public final int getChildEnd(View view) {
                return LayoutManager.this.getDecoratedRight(view) + ((LayoutParams) view.getLayoutParams()).rightMargin;
            }

            public final int getChildStart(View view) {
                return LayoutManager.this.getDecoratedLeft(view) - ((LayoutParams) view.getLayoutParams()).leftMargin;
            }

            public final int getParentEnd() {
                return LayoutManager.this.getWidth() - LayoutManager.this.getPaddingRight();
            }

            public final int getParentStart() {
                return LayoutManager.this.getPaddingLeft();
            }
        }

        /* renamed from: android.support.v7.widget.RecyclerView$LayoutManager$2 */
        final class C01102 implements Callback {
            public final View getChildAt(int i) {
                return android.support.p002v7.widget.RecyclerView.LayoutManager.this.getChildAt(i);
            }

            public final int getChildEnd(View view) {
                return android.support.p002v7.widget.RecyclerView.LayoutManager.this.getDecoratedBottom(view) + ((LayoutParams) view.getLayoutParams()).bottomMargin;
            }

            public final int getChildStart(View view) {
                return android.support.p002v7.widget.RecyclerView.LayoutManager.this.getDecoratedTop(view) - ((LayoutParams) view.getLayoutParams()).topMargin;
            }

            public final int getParentEnd() {
                return android.support.p002v7.widget.RecyclerView.LayoutManager.this.getHeight() - android.support.p002v7.widget.RecyclerView.LayoutManager.this.getPaddingBottom();
            }

            public final int getParentStart() {
                return android.support.p002v7.widget.RecyclerView.LayoutManager.this.getPaddingTop();
            }
        }

        /* compiled from: PG */
        /* renamed from: android.support.v7.widget.RecyclerView$LayoutManager$LayoutPrefetchRegistry */
        public interface LayoutPrefetchRegistry {
            void addPosition(int i, int i2);
        }

        /* compiled from: PG */
        /* renamed from: android.support.v7.widget.RecyclerView$LayoutManager$Properties */
        public final class Properties {
            public int orientation;
            public boolean reverseLayout;
            public int spanCount;
            public boolean stackFromEnd;
        }

        public LayoutManager() {
            Callback pg = new PG();
            this.mHorizontalBoundCheckCallback = pg;
            Callback c01102 = new C01102();
            this.mVerticalBoundCheckCallback = c01102;
            this.mHorizontalBoundCheck = new ViewBoundsCheck(pg);
            this.mVerticalBoundCheck = new ViewBoundsCheck(c01102);
        }

        private void addViewInt(View view, int i, boolean z) {
            LayoutParams layoutParams;
            int indexOfChild;
            SmoothScroller smoothScroller;
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (!z) {
                if (!childViewHolderInt.isRemoved()) {
                    this.mRecyclerView.mViewInfoStore.removeFromDisappearedInLayout(childViewHolderInt);
                    layoutParams = (LayoutParams) view.getLayoutParams();
                    if (!childViewHolderInt.wasReturnedFromScrap()) {
                        if (childViewHolderInt.isScrap()) {
                            if (view.getParent() != this.mRecyclerView) {
                                indexOfChild = this.mChildHelper.indexOfChild(view);
                                if (i == -1) {
                                    i = this.mChildHelper.getChildCount();
                                }
                                if (indexOfChild != -1) {
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                                    stringBuilder.append(this.mRecyclerView.indexOfChild(view));
                                    stringBuilder.append(this.mRecyclerView.exceptionLabel());
                                    throw new IllegalStateException(stringBuilder.toString());
                                } else if (indexOfChild != i) {
                                    this.mRecyclerView.mLayout.moveView(indexOfChild, i);
                                }
                            } else {
                                this.mChildHelper.addView(view, i, false);
                                layoutParams.mInsetsDirty = true;
                                smoothScroller = this.mSmoothScroller;
                                if (smoothScroller != null && smoothScroller.mRunning && SmoothScroller.getChildPosition$ar$ds(view) == smoothScroller.mTargetPosition) {
                                    smoothScroller.mTargetView = view;
                                }
                            }
                            if (!layoutParams.mPendingInvalidate) {
                                childViewHolderInt.itemView.invalidate();
                                layoutParams.mPendingInvalidate = false;
                            }
                        }
                    }
                    if (childViewHolderInt.isScrap()) {
                        childViewHolderInt.clearReturnedFromScrapFlag();
                    } else {
                        childViewHolderInt.unScrap();
                    }
                    this.mChildHelper.attachViewToParent(view, i, view.getLayoutParams(), false);
                    if (!layoutParams.mPendingInvalidate) {
                        childViewHolderInt.itemView.invalidate();
                        layoutParams.mPendingInvalidate = false;
                    }
                }
            }
            this.mRecyclerView.mViewInfoStore.addToDisappearedInLayout(childViewHolderInt);
            layoutParams = (LayoutParams) view.getLayoutParams();
            if (childViewHolderInt.wasReturnedFromScrap()) {
                if (childViewHolderInt.isScrap()) {
                    if (view.getParent() != this.mRecyclerView) {
                        this.mChildHelper.addView(view, i, false);
                        layoutParams.mInsetsDirty = true;
                        smoothScroller = this.mSmoothScroller;
                        smoothScroller.mTargetView = view;
                    } else {
                        indexOfChild = this.mChildHelper.indexOfChild(view);
                        if (i == -1) {
                            i = this.mChildHelper.getChildCount();
                        }
                        if (indexOfChild != -1) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                            stringBuilder2.append(this.mRecyclerView.indexOfChild(view));
                            stringBuilder2.append(this.mRecyclerView.exceptionLabel());
                            throw new IllegalStateException(stringBuilder2.toString());
                        } else if (indexOfChild != i) {
                            this.mRecyclerView.mLayout.moveView(indexOfChild, i);
                        }
                    }
                    if (!layoutParams.mPendingInvalidate) {
                        childViewHolderInt.itemView.invalidate();
                        layoutParams.mPendingInvalidate = false;
                    }
                }
            }
            if (childViewHolderInt.isScrap()) {
                childViewHolderInt.clearReturnedFromScrapFlag();
            } else {
                childViewHolderInt.unScrap();
            }
            this.mChildHelper.attachViewToParent(view, i, view.getLayoutParams(), false);
            if (!layoutParams.mPendingInvalidate) {
                childViewHolderInt.itemView.invalidate();
                layoutParams.mPendingInvalidate = false;
            }
        }

        public static int chooseSize(int i, int i2, int i3) {
            int mode = MeasureSpec.getMode(i);
            i = MeasureSpec.getSize(i);
            switch (mode) {
                case LinearLayoutManager.INVALID_OFFSET /*-2147483648*/:
                    return Math.min(i, Math.max(i2, i3));
                case 1073741824:
                    break;
                default:
                    i = Math.max(i2, i3);
                    break;
            }
            return i;
        }

        private void detachViewInternal(int i, View view) {
            this.mChildHelper.detachViewFromParent(i);
        }

        public static int getChildMeasureSpec(int i, int i2, int i3, int i4, boolean z) {
            i = Math.max(0, i - i3);
            if (z) {
                if (i4 >= 0) {
                    i2 = 1073741824;
                    return MeasureSpec.makeMeasureSpec(i4, i2);
                }
                if (i4 == -1) {
                    switch (i2) {
                        case LinearLayoutManager.INVALID_OFFSET /*-2147483648*/:
                        case 1073741824:
                            break;
                        case 0:
                            break;
                        default:
                            break;
                    }
                }
                i2 = 0;
                i4 = 0;
                return MeasureSpec.makeMeasureSpec(i4, i2);
            } else if (i4 >= 0) {
                i2 = 1073741824;
                return MeasureSpec.makeMeasureSpec(i4, i2);
            } else if (i4 != -1) {
                if (i4 == -2) {
                    if (i2 != LinearLayoutManager.INVALID_OFFSET) {
                        if (i2 != 1073741824) {
                            i2 = 0;
                        }
                    }
                    i2 = LinearLayoutManager.INVALID_OFFSET;
                }
                i2 = 0;
                i4 = 0;
                return MeasureSpec.makeMeasureSpec(i4, i2);
            }
            i4 = i;
            return MeasureSpec.makeMeasureSpec(i4, i2);
        }

        private int[] getChildRectangleOnScreenScrollAmount(View view, Rect rect) {
            int[] iArr = new int[2];
            int paddingLeft = getPaddingLeft();
            int paddingTop = getPaddingTop();
            int width = getWidth();
            int paddingRight = getPaddingRight();
            int height = getHeight();
            int paddingBottom = getPaddingBottom();
            int left = (view.getLeft() + rect.left) - view.getScrollX();
            int top = (view.getTop() + rect.top) - view.getScrollY();
            int width2 = rect.width();
            int height2 = rect.height();
            paddingLeft = left - paddingLeft;
            int min = Math.min(0, paddingLeft);
            paddingTop = top - paddingTop;
            int min2 = Math.min(0, paddingTop);
            left = (left + width2) - (width - paddingRight);
            width2 = Math.max(0, left);
            height2 = Math.max(0, (top + height2) - (height - paddingBottom));
            if (getLayoutDirection() == 1) {
                if (width2 != 0) {
                    min = width2;
                } else {
                    min = Math.max(min, left);
                }
            } else if (min == 0) {
                min = Math.min(paddingLeft, width2);
            }
            if (min2 == 0) {
                min2 = Math.min(paddingTop, height2);
            }
            iArr[0] = min;
            iArr[1] = min2;
            return iArr;
        }

        public static Properties getProperties(Context context, AttributeSet attributeSet, int i, int i2) {
            Properties properties = new Properties();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.RecyclerView, i, i2);
            properties.orientation = obtainStyledAttributes.getInt(0, 1);
            properties.spanCount = obtainStyledAttributes.getInt(10, 1);
            properties.reverseLayout = obtainStyledAttributes.getBoolean(9, false);
            properties.stackFromEnd = obtainStyledAttributes.getBoolean(11, false);
            obtainStyledAttributes.recycle();
            return properties;
        }

        private boolean isFocusedChildVisibleAfterScrolling(RecyclerView recyclerView, int i, int i2) {
            View focusedChild = recyclerView.getFocusedChild();
            if (focusedChild == null) {
                return false;
            }
            int paddingLeft = getPaddingLeft();
            int paddingTop = getPaddingTop();
            int width = getWidth();
            int paddingRight = getPaddingRight();
            int height = getHeight() - getPaddingBottom();
            Rect rect = this.mRecyclerView.mTempRect;
            getDecoratedBoundsWithMargins(focusedChild, rect);
            if (rect.left - i < width - paddingRight && rect.right - i > paddingLeft && rect.top - i2 < height) {
                if (rect.bottom - i2 > paddingTop) {
                    return true;
                }
            }
            return false;
        }

        private static boolean isMeasurementUpToDate(int i, int i2, int i3) {
            int mode = MeasureSpec.getMode(i2);
            i2 = MeasureSpec.getSize(i2);
            if (i3 > 0) {
                if (i != i3) {
                    return false;
                }
            }
            switch (mode) {
                case LinearLayoutManager.INVALID_OFFSET /*-2147483648*/:
                    return i2 >= i;
                case 0:
                    return true;
                case 1073741824:
                    return i2 == i;
                default:
                    return false;
            }
        }

        private void scrapOrRecycleView(Recycler recycler, int i, View view) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (!childViewHolderInt.shouldIgnore()) {
                if (!childViewHolderInt.isInvalid() || childViewHolderInt.isRemoved() || this.mRecyclerView.mAdapter.mHasStableIds) {
                    detachViewAt(i);
                    recycler.scrapView(view);
                    this.mRecyclerView.mViewInfoStore.removeFromDisappearedInLayout(childViewHolderInt);
                    return;
                }
                removeViewAt(i);
                recycler.recycleViewHolderInternal(childViewHolderInt);
            }
        }

        public void addDisappearingView(View view) {
            addDisappearingView(view, -1);
        }

        public void addView(View view) {
            addView(view, -1);
        }

        public void assertNotInLayoutOrScroll(String str) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView != null) {
                recyclerView.assertNotInLayoutOrScroll(str);
            }
        }

        public void attachView(View view) {
            attachView(view, -1);
        }

        public void calculateItemDecorationsForChild(View view, Rect rect) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView == null) {
                rect.set(0, 0, 0, 0);
            } else {
                rect.set(recyclerView.getItemDecorInsetsForChild(view));
            }
        }

        public boolean canScrollHorizontally() {
            return false;
        }

        public boolean canScrollVertically() {
            return false;
        }

        public boolean checkLayoutParams(LayoutParams layoutParams) {
            return layoutParams != null;
        }

        public void collectAdjacentPrefetchPositions(int i, int i2, State state, LayoutPrefetchRegistry layoutPrefetchRegistry) {
        }

        public void collectInitialPrefetchPositions(int i, LayoutPrefetchRegistry layoutPrefetchRegistry) {
        }

        public int computeHorizontalScrollExtent(State state) {
            return 0;
        }

        public int computeHorizontalScrollOffset(State state) {
            return 0;
        }

        public int computeHorizontalScrollRange(State state) {
            return 0;
        }

        public int computeVerticalScrollExtent(State state) {
            return 0;
        }

        public int computeVerticalScrollOffset(State state) {
            return 0;
        }

        public int computeVerticalScrollRange(State state) {
            return 0;
        }

        public void detachAndScrapAttachedViews(Recycler recycler) {
            for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
                scrapOrRecycleView(recycler, childCount, getChildAt(childCount));
            }
        }

        public void detachAndScrapView(View view, Recycler recycler) {
            scrapOrRecycleView(recycler, this.mChildHelper.indexOfChild(view), view);
        }

        public void detachAndScrapViewAt(int i, Recycler recycler) {
            scrapOrRecycleView(recycler, i, getChildAt(i));
        }

        public void detachView(View view) {
            int indexOfChild = this.mChildHelper.indexOfChild(view);
            if (indexOfChild >= 0) {
                detachViewInternal(indexOfChild, view);
            }
        }

        public void detachViewAt(int i) {
            detachViewInternal(i, getChildAt(i));
        }

        public void dispatchAttachedToWindow(RecyclerView recyclerView) {
            this.mIsAttachedToWindow = true;
            onAttachedToWindow(recyclerView);
        }

        public void dispatchDetachedFromWindow(RecyclerView recyclerView, Recycler recycler) {
            this.mIsAttachedToWindow = false;
            onDetachedFromWindow(recyclerView, recycler);
        }

        public void endAnimation(View view) {
            ItemAnimator itemAnimator = this.mRecyclerView.mItemAnimator;
            if (itemAnimator != null) {
                itemAnimator.endAnimation(RecyclerView.getChildViewHolderInt(view));
            }
        }

        public View findContainingItemView(View view) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView == null) {
                return null;
            }
            view = recyclerView.findContainingItemView(view);
            if (view == null || this.mChildHelper.isHidden(view)) {
                return null;
            }
            return view;
        }

        public View findViewByPosition(int i) {
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(childAt);
                if (childViewHolderInt != null && childViewHolderInt.getLayoutPosition() == i && !childViewHolderInt.shouldIgnore()) {
                    if (this.mRecyclerView.mState.mInPreLayout || !childViewHolderInt.isRemoved()) {
                        return childAt;
                    }
                }
            }
            return null;
        }

        public abstract LayoutParams generateDefaultLayoutParams();

        public LayoutParams generateLayoutParams(Context context, AttributeSet attributeSet) {
            return new LayoutParams(context, attributeSet);
        }

        public int getBaseline() {
            return -1;
        }

        public int getBottomDecorationHeight(View view) {
            return ((LayoutParams) view.getLayoutParams()).mDecorInsets.bottom;
        }

        public View getChildAt(int i) {
            ChildHelper childHelper = this.mChildHelper;
            return childHelper != null ? childHelper.getChildAt(i) : null;
        }

        public int getChildCount() {
            ChildHelper childHelper = this.mChildHelper;
            return childHelper != null ? childHelper.getChildCount() : 0;
        }

        public boolean getClipToPadding() {
            RecyclerView recyclerView = this.mRecyclerView;
            return recyclerView != null && recyclerView.mClipToPadding;
        }

        public int getColumnCountForAccessibility(Recycler recycler, State state) {
            return -1;
        }

        public int getDecoratedBottom(View view) {
            return view.getBottom() + getBottomDecorationHeight(view);
        }

        public void getDecoratedBoundsWithMargins(View view, Rect rect) {
            RecyclerView.getDecoratedBoundsWithMarginsInt(view, rect);
        }

        public int getDecoratedLeft(View view) {
            return view.getLeft() - getLeftDecorationWidth(view);
        }

        public int getDecoratedMeasuredHeight(View view) {
            Rect rect = ((LayoutParams) view.getLayoutParams()).mDecorInsets;
            return (view.getMeasuredHeight() + rect.top) + rect.bottom;
        }

        public int getDecoratedMeasuredWidth(View view) {
            Rect rect = ((LayoutParams) view.getLayoutParams()).mDecorInsets;
            return (view.getMeasuredWidth() + rect.left) + rect.right;
        }

        public int getDecoratedRight(View view) {
            return view.getRight() + getRightDecorationWidth(view);
        }

        public int getDecoratedTop(View view) {
            return view.getTop() - getTopDecorationHeight(view);
        }

        public View getFocusedChild() {
            ViewGroup viewGroup = this.mRecyclerView;
            if (viewGroup == null) {
                return null;
            }
            View focusedChild = viewGroup.getFocusedChild();
            if (focusedChild != null) {
                if (!this.mChildHelper.isHidden(focusedChild)) {
                    return focusedChild;
                }
            }
            return null;
        }

        public int getHeight() {
            return this.mHeight;
        }

        public int getHeightMode() {
            return this.mHeightMode;
        }

        public int getItemCount() {
            RecyclerView recyclerView = this.mRecyclerView;
            Adapter adapter = recyclerView != null ? recyclerView.mAdapter : null;
            return adapter != null ? adapter.getItemCount() : 0;
        }

        public int getItemViewType(View view) {
            return RecyclerView.getChildViewHolderInt(view).mItemViewType;
        }

        public int getLayoutDirection() {
            return ViewCompat.getLayoutDirection(this.mRecyclerView);
        }

        public int getLeftDecorationWidth(View view) {
            return ((LayoutParams) view.getLayoutParams()).mDecorInsets.left;
        }

        public int getMinimumHeight() {
            return ViewCompat.getMinimumHeight(this.mRecyclerView);
        }

        public int getMinimumWidth() {
            return ViewCompat.getMinimumWidth(this.mRecyclerView);
        }

        public int getPaddingBottom() {
            ViewGroup viewGroup = this.mRecyclerView;
            return viewGroup != null ? viewGroup.getPaddingBottom() : 0;
        }

        public int getPaddingEnd() {
            View view = this.mRecyclerView;
            return view != null ? ViewCompat.getPaddingEnd(view) : 0;
        }

        public int getPaddingLeft() {
            ViewGroup viewGroup = this.mRecyclerView;
            return viewGroup != null ? viewGroup.getPaddingLeft() : 0;
        }

        public int getPaddingRight() {
            ViewGroup viewGroup = this.mRecyclerView;
            return viewGroup != null ? viewGroup.getPaddingRight() : 0;
        }

        public int getPaddingStart() {
            View view = this.mRecyclerView;
            return view != null ? ViewCompat.getPaddingStart(view) : 0;
        }

        public int getPaddingTop() {
            ViewGroup viewGroup = this.mRecyclerView;
            return viewGroup != null ? viewGroup.getPaddingTop() : 0;
        }

        public int getPosition(View view) {
            return ((LayoutParams) view.getLayoutParams()).getViewLayoutPosition();
        }

        public int getRightDecorationWidth(View view) {
            return ((LayoutParams) view.getLayoutParams()).mDecorInsets.right;
        }

        public int getRowCountForAccessibility(Recycler recycler, State state) {
            return -1;
        }

        public int getSelectionModeForAccessibility(Recycler recycler, State state) {
            return 0;
        }

        public int getTopDecorationHeight(View view) {
            return ((LayoutParams) view.getLayoutParams()).mDecorInsets.top;
        }

        public void getTransformedBoundingBox(View view, boolean z, Rect rect) {
            if (z) {
                Rect rect2 = ((LayoutParams) view.getLayoutParams()).mDecorInsets;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (this.mRecyclerView != null) {
                Matrix matrix = view.getMatrix();
                if (!(matrix == null || matrix.isIdentity())) {
                    RectF rectF = this.mRecyclerView.mTempRectF;
                    rectF.set(rect);
                    matrix.mapRect(rectF);
                    rect.set((int) Math.floor((double) rectF.left), (int) Math.floor((double) rectF.top), (int) Math.ceil((double) rectF.right), (int) Math.ceil((double) rectF.bottom));
                }
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        public int getWidth() {
            return this.mWidth;
        }

        public int getWidthMode() {
            return this.mWidthMode;
        }

        public boolean hasFlexibleChildInBothOrientations() {
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                ViewGroup.LayoutParams layoutParams = getChildAt(i).getLayoutParams();
                if (layoutParams.width < 0) {
                    if (layoutParams.height < 0) {
                        return true;
                    }
                }
            }
            return false;
        }

        public boolean hasFocus() {
            RecyclerView recyclerView = this.mRecyclerView;
            return recyclerView != null && recyclerView.hasFocus();
        }

        public void ignoreView(View view) {
            ViewParent parent = view.getParent();
            ViewParent viewParent = this.mRecyclerView;
            if (parent != viewParent || viewParent.indexOfChild(view) == -1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("View should be fully attached to be ignored");
                stringBuilder.append(this.mRecyclerView.exceptionLabel());
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            childViewHolderInt.addFlags(128);
            this.mRecyclerView.mViewInfoStore.removeViewHolder(childViewHolderInt);
        }

        public boolean isAttachedToWindow() {
            return this.mIsAttachedToWindow;
        }

        public boolean isAutoMeasureEnabled() {
            return this.mAutoMeasure;
        }

        public boolean isFocused() {
            RecyclerView recyclerView = this.mRecyclerView;
            return recyclerView != null && recyclerView.isFocused();
        }

        public final boolean isItemPrefetchEnabled() {
            return this.mItemPrefetchEnabled;
        }

        public boolean isLayoutHierarchical(Recycler recycler, State state) {
            return false;
        }

        public boolean isMeasurementCacheEnabled() {
            return this.mMeasurementCacheEnabled;
        }

        public boolean isSmoothScrolling() {
            SmoothScroller smoothScroller = this.mSmoothScroller;
            return smoothScroller != null && smoothScroller.mRunning;
        }

        public boolean isViewPartiallyVisible(View view, boolean z, boolean z2) {
            boolean z3 = this.mHorizontalBoundCheck.isViewWithinBoundFlags$ar$ds(view) && this.mVerticalBoundCheck.isViewWithinBoundFlags$ar$ds(view);
            if (z) {
                return z3;
            }
            return !z3;
        }

        public void layoutDecorated(View view, int i, int i2, int i3, int i4) {
            Rect rect = ((LayoutParams) view.getLayoutParams()).mDecorInsets;
            view.layout(i + rect.left, i2 + rect.top, i3 - rect.right, i4 - rect.bottom);
        }

        public void layoutDecoratedWithMargins(View view, int i, int i2, int i3, int i4) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            Rect rect = layoutParams.mDecorInsets;
            view.layout((i + rect.left) + layoutParams.leftMargin, (i2 + rect.top) + layoutParams.topMargin, (i3 - rect.right) - layoutParams.rightMargin, (i4 - rect.bottom) - layoutParams.bottomMargin);
        }

        public void measureChild(View view, int i, int i2) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            Rect itemDecorInsetsForChild = this.mRecyclerView.getItemDecorInsetsForChild(view);
            int i3 = itemDecorInsetsForChild.left;
            int i4 = itemDecorInsetsForChild.right;
            int i5 = itemDecorInsetsForChild.top;
            int i6 = itemDecorInsetsForChild.bottom;
            i = LayoutManager.getChildMeasureSpec(getWidth(), getWidthMode(), (getPaddingLeft() + getPaddingRight()) + (i + (i3 + i4)), layoutParams.width, canScrollHorizontally());
            i2 = LayoutManager.getChildMeasureSpec(getHeight(), getHeightMode(), (getPaddingTop() + getPaddingBottom()) + (i2 + (i5 + i6)), layoutParams.height, canScrollVertically());
            if (shouldMeasureChild(view, i, i2, layoutParams)) {
                view.measure(i, i2);
            }
        }

        public void measureChildWithMargins(View view, int i, int i2) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            Rect itemDecorInsetsForChild = this.mRecyclerView.getItemDecorInsetsForChild(view);
            int i3 = itemDecorInsetsForChild.left;
            int i4 = itemDecorInsetsForChild.right;
            int i5 = itemDecorInsetsForChild.top;
            int i6 = itemDecorInsetsForChild.bottom;
            i = LayoutManager.getChildMeasureSpec(getWidth(), getWidthMode(), (((getPaddingLeft() + getPaddingRight()) + layoutParams.leftMargin) + layoutParams.rightMargin) + (i + (i3 + i4)), layoutParams.width, canScrollHorizontally());
            i2 = LayoutManager.getChildMeasureSpec(getHeight(), getHeightMode(), (((getPaddingTop() + getPaddingBottom()) + layoutParams.topMargin) + layoutParams.bottomMargin) + (i2 + (i5 + i6)), layoutParams.height, canScrollVertically());
            if (shouldMeasureChild(view, i, i2, layoutParams)) {
                view.measure(i, i2);
            }
        }

        public void moveView(int i, int i2) {
            View childAt = getChildAt(i);
            if (childAt != null) {
                detachViewAt(i);
                attachView(childAt, i2);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot move a child from non-existing index:");
            stringBuilder.append(i);
            stringBuilder.append(this.mRecyclerView.toString());
            throw new IllegalArgumentException(stringBuilder.toString());
        }

        public void onAdapterChanged(Adapter adapter, Adapter adapter2) {
        }

        public boolean onAddFocusables(RecyclerView recyclerView, ArrayList arrayList, int i, int i2) {
            return false;
        }

        public void onAttachedToWindow(RecyclerView recyclerView) {
        }

        @Deprecated
        public void onDetachedFromWindow(RecyclerView recyclerView) {
        }

        public View onFocusSearchFailed(View view, int i, Recycler recycler, State state) {
            return null;
        }

        public void onInitializeAccessibilityEvent(Recycler recycler, State state, AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView != null) {
                if (accessibilityEvent != null) {
                    boolean z = true;
                    if (!recyclerView.canScrollVertically(1) && !this.mRecyclerView.canScrollVertically(-1) && !this.mRecyclerView.canScrollHorizontally(-1)) {
                        if (!this.mRecyclerView.canScrollHorizontally(1)) {
                            z = false;
                        }
                    }
                    accessibilityEvent.setScrollable(z);
                    Adapter adapter = this.mRecyclerView.mAdapter;
                    if (adapter != null) {
                        accessibilityEvent.setItemCount(adapter.getItemCount());
                    }
                }
            }
        }

        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            RecyclerView recyclerView = this.mRecyclerView;
            onInitializeAccessibilityNodeInfo(recyclerView.mRecycler, recyclerView.mState, accessibilityNodeInfoCompat);
        }

        public void onInitializeAccessibilityNodeInfoForItem(Recycler recycler, State state, View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
        }

        public View onInterceptFocusSearch(View view, int i) {
            return null;
        }

        public void onItemsAdded(RecyclerView recyclerView, int i, int i2) {
        }

        public void onItemsChanged(RecyclerView recyclerView) {
        }

        public void onItemsMoved(RecyclerView recyclerView, int i, int i2, int i3) {
        }

        public void onItemsRemoved(RecyclerView recyclerView, int i, int i2) {
        }

        public void onItemsUpdated(RecyclerView recyclerView, int i, int i2) {
        }

        public void onLayoutChildren(Recycler recycler, State state) {
            Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        public void onLayoutCompleted(State state) {
        }

        public void onMeasure(Recycler recycler, State state, int i, int i2) {
            this.mRecyclerView.defaultOnMeasure(i, i2);
        }

        public boolean onRequestChildFocus(RecyclerView recyclerView, State state, View view, View view2) {
            return onRequestChildFocus(recyclerView, view, view2);
        }

        public void onRestoreInstanceState(Parcelable parcelable) {
        }

        public Parcelable onSaveInstanceState() {
            return null;
        }

        public void onScrollStateChanged(int i) {
        }

        public void onSmoothScrollerStopped(SmoothScroller smoothScroller) {
            if (this.mSmoothScroller == smoothScroller) {
                this.mSmoothScroller = null;
            }
        }

        public boolean performAccessibilityAction(int i, Bundle bundle) {
            RecyclerView recyclerView = this.mRecyclerView;
            return performAccessibilityAction(recyclerView.mRecycler, recyclerView.mState, i, bundle);
        }

        public boolean performAccessibilityActionForItem(Recycler recycler, State state, View view, int i, Bundle bundle) {
            return false;
        }

        public void postOnAnimation(Runnable runnable) {
            View view = this.mRecyclerView;
            if (view != null) {
                ViewCompat.postOnAnimation(view, runnable);
            }
        }

        public void removeAllViews() {
            for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
                this.mChildHelper.removeViewAt(childCount);
            }
        }

        public void removeAndRecycleAllViews(Recycler recycler) {
            for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
                if (!RecyclerView.getChildViewHolderInt(getChildAt(childCount)).shouldIgnore()) {
                    removeAndRecycleViewAt(childCount, recycler);
                }
            }
        }

        public void removeAndRecycleView(View view, Recycler recycler) {
            removeView(view);
            recycler.recycleView(view);
        }

        public void removeAndRecycleViewAt(int i, Recycler recycler) {
            View childAt = getChildAt(i);
            removeViewAt(i);
            recycler.recycleView(childAt);
        }

        public boolean removeCallbacks(Runnable runnable) {
            ViewGroup viewGroup = this.mRecyclerView;
            return viewGroup != null ? viewGroup.removeCallbacks(runnable) : false;
        }

        public void removeDetachedView(View view) {
            this.mRecyclerView.removeDetachedView(view, false);
        }

        public void removeViewAt(int i) {
            if (getChildAt(i) != null) {
                this.mChildHelper.removeViewAt(i);
            }
        }

        public boolean requestChildRectangleOnScreen(RecyclerView recyclerView, View view, Rect rect, boolean z) {
            return requestChildRectangleOnScreen(recyclerView, view, rect, z, false);
        }

        public void requestLayout() {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }

        public void requestSimpleAnimationsInNextLayout() {
            this.mRequestedSimpleAnimations = true;
        }

        public int scrollHorizontallyBy(int i, Recycler recycler, State state) {
            return 0;
        }

        public void scrollToPosition(int i) {
        }

        public int scrollVerticallyBy(int i, Recycler recycler, State state) {
            return 0;
        }

        @Deprecated
        public void setAutoMeasureEnabled(boolean z) {
            this.mAutoMeasure = z;
        }

        public void setExactMeasureSpecsFrom(RecyclerView recyclerView) {
            setMeasureSpecs(MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
        }

        public final void setItemPrefetchEnabled(boolean z) {
            if (z != this.mItemPrefetchEnabled) {
                this.mItemPrefetchEnabled = z;
                this.mPrefetchMaxCountObserved = 0;
                RecyclerView recyclerView = this.mRecyclerView;
                if (recyclerView != null) {
                    recyclerView.mRecycler.updateViewCacheSize();
                }
            }
        }

        public void setMeasureSpecs(int i, int i2) {
            this.mWidth = MeasureSpec.getSize(i);
            i = MeasureSpec.getMode(i);
            this.mWidthMode = i;
            if (i == 0) {
                i = RecyclerView.RecyclerView$ar$NoOp;
            }
            this.mHeight = MeasureSpec.getSize(i2);
            i = MeasureSpec.getMode(i2);
            this.mHeightMode = i;
            if (i == 0) {
                i = RecyclerView.RecyclerView$ar$NoOp;
            }
        }

        public void setMeasuredDimension(int i, int i2) {
            this.mRecyclerView.setMeasuredDimension(i, i2);
        }

        public void setMeasuredDimensionFromChildren(int i, int i2) {
            int childCount = getChildCount();
            if (childCount != 0) {
                int i3 = LinearLayoutManager.INVALID_OFFSET;
                int i4 = LinearLayoutManager.INVALID_OFFSET;
                int i5 = Integer.MAX_VALUE;
                int i6 = Integer.MAX_VALUE;
                for (int i7 = 0; i7 < childCount; i7++) {
                    View childAt = getChildAt(i7);
                    Rect rect = this.mRecyclerView.mTempRect;
                    getDecoratedBoundsWithMargins(childAt, rect);
                    if (rect.left < i5) {
                        i5 = rect.left;
                    }
                    if (rect.right > i3) {
                        i3 = rect.right;
                    }
                    if (rect.top < i6) {
                        i6 = rect.top;
                    }
                    if (rect.bottom > i4) {
                        i4 = rect.bottom;
                    }
                }
                this.mRecyclerView.mTempRect.set(i5, i6, i3, i4);
                setMeasuredDimension(this.mRecyclerView.mTempRect, i, i2);
                return;
            }
            this.mRecyclerView.defaultOnMeasure(i, i2);
        }

        public void setMeasurementCacheEnabled(boolean z) {
            this.mMeasurementCacheEnabled = z;
        }

        public void setRecyclerView(RecyclerView recyclerView) {
            if (recyclerView == null) {
                this.mRecyclerView = null;
                this.mChildHelper = null;
                this.mWidth = 0;
                this.mHeight = 0;
            } else {
                this.mRecyclerView = recyclerView;
                this.mChildHelper = recyclerView.mChildHelper;
                this.mWidth = recyclerView.getWidth();
                this.mHeight = recyclerView.getHeight();
            }
            this.mWidthMode = 1073741824;
            this.mHeightMode = 1073741824;
        }

        public boolean shouldMeasureChild(View view, int i, int i2, LayoutParams layoutParams) {
            if (!view.isLayoutRequested() && this.mMeasurementCacheEnabled && LayoutManager.isMeasurementUpToDate(view.getWidth(), i, layoutParams.width)) {
                if (LayoutManager.isMeasurementUpToDate(view.getHeight(), i2, layoutParams.height)) {
                    return false;
                }
            }
            return true;
        }

        public boolean shouldMeasureTwice() {
            return false;
        }

        public boolean shouldReMeasureChild(View view, int i, int i2, LayoutParams layoutParams) {
            if (this.mMeasurementCacheEnabled && LayoutManager.isMeasurementUpToDate(view.getMeasuredWidth(), i, layoutParams.width)) {
                if (LayoutManager.isMeasurementUpToDate(view.getMeasuredHeight(), i2, layoutParams.height)) {
                    return false;
                }
            }
            return true;
        }

        public void smoothScrollToPosition(RecyclerView recyclerView, State state, int i) {
            Log.e("RecyclerView", "You must override smoothScrollToPosition to support smooth scrolling");
        }

        public void startSmoothScroll(SmoothScroller smoothScroller) {
            SmoothScroller smoothScroller2 = this.mSmoothScroller;
            if (!(smoothScroller2 == null || smoothScroller == smoothScroller2 || !smoothScroller2.mRunning)) {
                smoothScroller2.stop();
            }
            this.mSmoothScroller = smoothScroller;
            RecyclerView recyclerView = this.mRecyclerView;
            recyclerView.mViewFlinger.stop();
            if (smoothScroller.mStarted) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("An instance of ");
                stringBuilder.append(smoothScroller.getClass().getSimpleName());
                stringBuilder.append(" was started more than once. Each instance of");
                stringBuilder.append(smoothScroller.getClass().getSimpleName());
                stringBuilder.append(" is intended to only be used once. You should create a new instance for each use.");
                Log.w("RecyclerView", stringBuilder.toString());
            }
            smoothScroller.mRecyclerView = recyclerView;
            smoothScroller.mLayoutManager = this;
            int i = smoothScroller.mTargetPosition;
            if (i != -1) {
                RecyclerView recyclerView2 = smoothScroller.mRecyclerView;
                recyclerView2.mState.mTargetPosition = i;
                smoothScroller.mRunning = true;
                smoothScroller.mPendingInitialRun = true;
                smoothScroller.mTargetView = recyclerView2.mLayout.findViewByPosition(smoothScroller.mTargetPosition);
                smoothScroller.mRecyclerView.mViewFlinger.postOnAnimation();
                smoothScroller.mStarted = true;
                return;
            }
            throw new IllegalArgumentException("Invalid target position");
        }

        public void stopIgnoringView(View view) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            childViewHolderInt.mFlags &= -129;
            childViewHolderInt.resetInternal();
            childViewHolderInt.addFlags(4);
        }

        public void stopSmoothScroller() {
            SmoothScroller smoothScroller = this.mSmoothScroller;
            if (smoothScroller != null) {
                smoothScroller.stop();
            }
        }

        public boolean supportsPredictiveItemAnimations() {
            return false;
        }

        public void addDisappearingView(View view, int i) {
            addViewInt(view, i, true);
        }

        public void addView(View view, int i) {
            addViewInt(view, i, false);
        }

        public void assertInLayoutOrScroll(String str) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView != null && !recyclerView.isComputingLayout()) {
                if (str == null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Cannot call this method unless RecyclerView is computing a layout or scrolling");
                    stringBuilder.append(recyclerView.exceptionLabel());
                    throw new IllegalStateException(stringBuilder.toString());
                }
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(recyclerView.exceptionLabel());
                throw new IllegalStateException(stringBuilder2.toString());
            }
        }

        public void attachView(View view, int i) {
            attachView(view, i, (LayoutParams) view.getLayoutParams());
        }

        public LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
            if (layoutParams instanceof LayoutParams) {
                return new LayoutParams((LayoutParams) layoutParams);
            }
            if (layoutParams instanceof MarginLayoutParams) {
                return new LayoutParams((MarginLayoutParams) layoutParams);
            }
            return new LayoutParams(layoutParams);
        }

        public void offsetChildrenHorizontal(int i) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView != null) {
                int childCount = recyclerView.mChildHelper.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    recyclerView.mChildHelper.getChildAt(i2).offsetLeftAndRight(i);
                }
            }
        }

        public void offsetChildrenVertical(int i) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView != null) {
                int childCount = recyclerView.mChildHelper.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    recyclerView.mChildHelper.getChildAt(i2).offsetTopAndBottom(i);
                }
            }
        }

        public void onDetachedFromWindow(RecyclerView recyclerView, Recycler recycler) {
            onDetachedFromWindow(recyclerView);
        }

        public void onInitializeAccessibilityNodeInfo(Recycler recycler, State state, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            if (this.mRecyclerView.canScrollVertically(-1) || this.mRecyclerView.canScrollHorizontally(-1)) {
                accessibilityNodeInfoCompat.addAction(8192);
                accessibilityNodeInfoCompat.setScrollable(true);
            }
            if (this.mRecyclerView.canScrollVertically(1) || this.mRecyclerView.canScrollHorizontally(1)) {
                accessibilityNodeInfoCompat.addAction(4096);
                accessibilityNodeInfoCompat.setScrollable(true);
            }
            accessibilityNodeInfoCompat.setCollectionInfo(CollectionInfoCompat.obtain(getRowCountForAccessibility(recycler, state), getColumnCountForAccessibility(recycler, state), isLayoutHierarchical(recycler, state), getSelectionModeForAccessibility(recycler, state)));
        }

        public void onInitializeAccessibilityNodeInfoForItem(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt != null && !childViewHolderInt.isRemoved() && !this.mChildHelper.isHidden(childViewHolderInt.itemView)) {
                RecyclerView recyclerView = this.mRecyclerView;
                onInitializeAccessibilityNodeInfoForItem(recyclerView.mRecycler, recyclerView.mState, view, accessibilityNodeInfoCompat);
            }
        }

        public void onItemsUpdated(RecyclerView recyclerView, int i, int i2, Object obj) {
            onItemsUpdated(recyclerView, i, i2);
        }

        @Deprecated
        public boolean onRequestChildFocus(RecyclerView recyclerView, View view, View view2) {
            if (!isSmoothScrolling()) {
                if (!recyclerView.isComputingLayout()) {
                    return false;
                }
            }
            return true;
        }

        public boolean performAccessibilityActionForItem(View view, int i, Bundle bundle) {
            RecyclerView recyclerView = this.mRecyclerView;
            return performAccessibilityActionForItem(recyclerView.mRecycler, recyclerView.mState, view, i, bundle);
        }

        public void removeAndRecycleScrapInt(Recycler recycler) {
            int size = recycler.mAttachedScrap.size();
            for (int i = size - 1; i >= 0; i--) {
                View view = ((ViewHolder) recycler.mAttachedScrap.get(i)).itemView;
                ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
                if (!childViewHolderInt.shouldIgnore()) {
                    childViewHolderInt.setIsRecyclable(false);
                    if (childViewHolderInt.isTmpDetached()) {
                        this.mRecyclerView.removeDetachedView(view, false);
                    }
                    ItemAnimator itemAnimator = this.mRecyclerView.mItemAnimator;
                    if (itemAnimator != null) {
                        itemAnimator.endAnimation(childViewHolderInt);
                    }
                    childViewHolderInt.setIsRecyclable(true);
                    recycler.quickRecycleScrapView(view);
                }
            }
            recycler.mAttachedScrap.clear();
            ArrayList arrayList = recycler.mChangedScrap;
            if (arrayList != null) {
                arrayList.clear();
            }
            if (size > 0) {
                this.mRecyclerView.invalidate();
            }
        }

        public void removeView(View view) {
            ChildHelper childHelper = this.mChildHelper;
            int indexOfChild = childHelper.mCallback$ar$class_merging$5a35e444_0.indexOfChild(view);
            if (indexOfChild >= 0) {
                if (childHelper.mBucket.remove(indexOfChild)) {
                    childHelper.unhideViewInternal$ar$ds(view);
                }
                childHelper.mCallback$ar$class_merging$5a35e444_0.removeViewAt(indexOfChild);
            }
        }

        public boolean requestChildRectangleOnScreen(RecyclerView recyclerView, View view, Rect rect, boolean z, boolean z2) {
            int[] childRectangleOnScreenScrollAmount = getChildRectangleOnScreenScrollAmount(view, rect);
            int i = 0;
            int i2 = childRectangleOnScreenScrollAmount[0];
            int i3 = childRectangleOnScreenScrollAmount[1];
            if (!z2 || isFocusedChildVisibleAfterScrolling(recyclerView, i2, i3)) {
                if (i2 != 0) {
                    i = i2;
                } else if (i3 != 0) {
                }
                if (z) {
                    recyclerView.scrollBy(i, i3);
                } else {
                    recyclerView.smoothScrollBy(i, i3);
                }
                return true;
            }
            return false;
        }

        public void setMeasuredDimension(Rect rect, int i, int i2) {
            int width = rect.width();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int height = rect.height();
            int paddingTop = getPaddingTop();
            setMeasuredDimension(LayoutManager.chooseSize(i, (width + paddingLeft) + paddingRight, getMinimumWidth()), LayoutManager.chooseSize(i2, (height + paddingTop) + getPaddingBottom(), getMinimumHeight()));
        }

        @Deprecated
        public static int getChildMeasureSpec(int i, int i2, int i3, boolean z) {
            i -= i2;
            i2 = 0;
            i = Math.max(0, i);
            if (!z) {
                if (i3 >= 0) {
                    i2 = 1073741824;
                } else {
                    if (i3 == -1) {
                        i2 = 1073741824;
                    } else if (i3 == -2) {
                        i2 = LinearLayoutManager.INVALID_OFFSET;
                    }
                    i3 = i;
                }
                return MeasureSpec.makeMeasureSpec(i3, i2);
            } else if (i3 >= 0) {
                i2 = 1073741824;
                return MeasureSpec.makeMeasureSpec(i3, i2);
            }
            i3 = 0;
            return MeasureSpec.makeMeasureSpec(i3, i2);
        }

        public void attachView(View view, int i, LayoutParams layoutParams) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt.isRemoved()) {
                this.mRecyclerView.mViewInfoStore.addToDisappearedInLayout(childViewHolderInt);
            } else {
                this.mRecyclerView.mViewInfoStore.removeFromDisappearedInLayout(childViewHolderInt);
            }
            this.mChildHelper.attachViewToParent(view, i, layoutParams, childViewHolderInt.isRemoved());
        }

        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.mRecyclerView;
            onInitializeAccessibilityEvent(recyclerView.mRecycler, recyclerView.mState, accessibilityEvent);
        }

        public boolean performAccessibilityAction(Recycler recycler, State state, int i, Bundle bundle) {
            RecyclerView recyclerView = this.mRecyclerView;
            int i2 = 0;
            if (recyclerView == null) {
                return false;
            }
            int height;
            switch (i) {
                case 4096:
                    if (recyclerView.canScrollVertically(1)) {
                        height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                    } else {
                        height = 0;
                    }
                    if (!this.mRecyclerView.canScrollHorizontally(1)) {
                        i = 0;
                        break;
                    }
                    i = (getWidth() - getPaddingLeft()) - getPaddingRight();
                    break;
                case 8192:
                    if (recyclerView.canScrollVertically(-1)) {
                        height = -((getHeight() - getPaddingTop()) - getPaddingBottom());
                    } else {
                        height = 0;
                    }
                    if (!this.mRecyclerView.canScrollHorizontally(-1)) {
                        i = 0;
                        break;
                    }
                    i = -((getWidth() - getPaddingLeft()) - getPaddingRight());
                    break;
                default:
                    height = 0;
                    i = 0;
                    break;
            }
            if (height != 0) {
                i2 = height;
            } else if (i == 0) {
                return false;
            }
            this.mRecyclerView.smoothScrollBy$ar$ds$a5e2b4f9_0(i, i2, true);
            return true;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$LayoutParams */
    public class LayoutParams extends MarginLayoutParams {
        final Rect mDecorInsets = new Rect();
        boolean mInsetsDirty = true;
        boolean mPendingInvalidate = false;
        ViewHolder mViewHolder;

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public final int getViewLayoutPosition() {
            return this.mViewHolder.getLayoutPosition();
        }

        public final boolean isItemChanged() {
            return this.mViewHolder.isUpdated();
        }

        public final boolean isItemRemoved() {
            return this.mViewHolder.isRemoved();
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public LayoutParams(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$OnChildAttachStateChangeListener */
    public interface OnChildAttachStateChangeListener {
        void onChildViewAttachedToWindow(View view);

        void onChildViewDetachedFromWindow(View view);
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$OnFlingListener */
    public abstract class OnFlingListener {
        public abstract boolean onFling(int i, int i2);
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$OnItemTouchListener */
    public interface OnItemTouchListener {
        boolean onInterceptTouchEvent$ar$ds(MotionEvent motionEvent);

        void onRequestDisallowInterceptTouchEvent(boolean z);

        void onTouchEvent$ar$ds$fcc9275a_0(MotionEvent motionEvent);
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$OnScrollListener */
    public class OnScrollListener {
        public void onScrollStateChanged(RecyclerView recyclerView, int i) {
        }

        public void onScrolled(RecyclerView recyclerView, int i, int i2) {
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$RecycledViewPool */
    public final class RecycledViewPool {
        public int mAttachCount = 0;
        final SparseArray mScrap = new SparseArray();

        /* compiled from: PG */
        /* renamed from: android.support.v7.widget.RecyclerView$RecycledViewPool$ScrapData */
        final class ScrapData {
            long mBindRunningAverageNs = 0;
            long mCreateRunningAverageNs = 0;
            final int mMaxScrap = 5;
            final ArrayList mScrapHeap = new ArrayList();
        }

        static final long runningAverage$ar$ds(long j, long j2) {
            return j == 0 ? j2 : ((j / 4) * 3) + (j2 / 4);
        }

        public final ScrapData getScrapDataForType(int i) {
            ScrapData scrapData = (ScrapData) this.mScrap.get(i);
            if (scrapData != null) {
                return scrapData;
            }
            scrapData = new ScrapData();
            this.mScrap.put(i, scrapData);
            return scrapData;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$Recycler */
    public final class Recycler {
        final ArrayList mAttachedScrap;
        final ArrayList mCachedViews = new ArrayList();
        ArrayList mChangedScrap = null;
        RecycledViewPool mRecyclerPool;
        public final List mUnmodifiableAttachedScrap;
        int mViewCacheMax;

        public Recycler() {
            List arrayList = new ArrayList();
            this.mAttachedScrap = arrayList;
            this.mUnmodifiableAttachedScrap = Collections.unmodifiableList(arrayList);
            this.mViewCacheMax = 2;
        }

        final void addViewHolderToRecycledViewPool(ViewHolder viewHolder, boolean z) {
            int size;
            int i;
            RecyclerView.clearNestedRecyclerViewIfNotNested(viewHolder);
            View view = viewHolder.itemView;
            RecyclerViewAccessibilityDelegate recyclerViewAccessibilityDelegate = RecyclerView.this.mAccessibilityDelegate;
            if (recyclerViewAccessibilityDelegate != null) {
                AccessibilityDelegateCompat accessibilityDelegateCompat;
                ItemDelegate itemDelegate = recyclerViewAccessibilityDelegate.mItemDelegate;
                if (itemDelegate instanceof ItemDelegate) {
                    accessibilityDelegateCompat = (AccessibilityDelegateCompat) itemDelegate.mOriginalItemDelegates.remove(view);
                } else {
                    accessibilityDelegateCompat = null;
                }
                ViewCompat.setAccessibilityDelegate(view, accessibilityDelegateCompat);
            }
            if (z) {
                size = RecyclerView.this.mRecyclerListeners.size();
                for (i = 0; i < size; i++) {
                    ((RecyclerListener) RecyclerView.this.mRecyclerListeners.get(i)).onViewRecycled$ar$ds();
                }
                Adapter adapter = RecyclerView.this.mAdapter;
                if (adapter != null) {
                    adapter.onViewRecycled(viewHolder);
                }
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.mState != null) {
                    recyclerView.mViewInfoStore.removeViewHolder(viewHolder);
                }
            }
            viewHolder.mBindingAdapter = null;
            viewHolder.mOwnerRecyclerView = null;
            RecycledViewPool recycledViewPool = getRecycledViewPool();
            i = viewHolder.mItemViewType;
            ArrayList arrayList = recycledViewPool.getScrapDataForType(i).mScrapHeap;
            size = ((ScrapData) recycledViewPool.mScrap.get(i)).mMaxScrap;
            if (arrayList.size() < 5) {
                viewHolder.resetInternal();
                arrayList.add(viewHolder);
            }
        }

        public final void clear() {
            this.mAttachedScrap.clear();
            recycleAndClearCachedViews();
        }

        public final int convertPreLayoutPositionToPostLayout(int i) {
            if (i < 0 || i >= RecyclerView.this.mState.getItemCount()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("invalid position ");
                stringBuilder.append(i);
                stringBuilder.append(". State item count is ");
                stringBuilder.append(RecyclerView.this.mState.getItemCount());
                stringBuilder.append(RecyclerView.this.exceptionLabel());
                throw new IndexOutOfBoundsException(stringBuilder.toString());
            }
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.mState.mInPreLayout) {
                return recyclerView.mAdapterHelper.findPositionOffset(i);
            }
            return i;
        }

        final RecycledViewPool getRecycledViewPool() {
            if (this.mRecyclerPool == null) {
                this.mRecyclerPool = new RecycledViewPool();
            }
            return this.mRecyclerPool;
        }

        final void quickRecycleScrapView(View view) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            childViewHolderInt.mScrapContainer = null;
            childViewHolderInt.mInChangeScrap = false;
            childViewHolderInt.clearReturnedFromScrapFlag();
            recycleViewHolderInternal(childViewHolderInt);
        }

        final void recycleAndClearCachedViews() {
            int size;
            for (size = this.mCachedViews.size() - 1; size >= 0; size--) {
                recycleCachedViewAt(size);
            }
            this.mCachedViews.clear();
            size = RecyclerView.RecyclerView$ar$NoOp;
            RecyclerView.this.mPrefetchRegistry.clearPrefetchPositions();
        }

        final void recycleCachedViewAt(int i) {
            addViewHolderToRecycledViewPool((ViewHolder) this.mCachedViews.get(i), true);
            this.mCachedViews.remove(i);
        }

        public final void recycleView(View view) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt.isTmpDetached()) {
                RecyclerView.this.removeDetachedView(view, false);
            }
            if (childViewHolderInt.isScrap()) {
                childViewHolderInt.unScrap();
            } else if (childViewHolderInt.wasReturnedFromScrap()) {
                childViewHolderInt.clearReturnedFromScrapFlag();
            }
            recycleViewHolderInternal(childViewHolderInt);
            if (RecyclerView.this.mItemAnimator != null && !childViewHolderInt.isRecyclable()) {
                RecyclerView.this.mItemAnimator.endAnimation(childViewHolderInt);
            }
        }

        final void recycleViewHolderInternal(ViewHolder viewHolder) {
            boolean z = true;
            int i = 0;
            if (!viewHolder.isScrap()) {
                if (viewHolder.itemView.getParent() == null) {
                    if (viewHolder.isTmpDetached()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
                        stringBuilder.append(viewHolder);
                        stringBuilder.append(RecyclerView.this.exceptionLabel());
                        throw new IllegalArgumentException(stringBuilder.toString());
                    } else if (viewHolder.shouldIgnore()) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.");
                        stringBuilder2.append(RecyclerView.this.exceptionLabel());
                        throw new IllegalArgumentException(stringBuilder2.toString());
                    } else {
                        Object obj = ((viewHolder.mFlags & 16) == 0 && ViewCompat.hasTransientState(viewHolder.itemView)) ? 1 : null;
                        Adapter adapter = RecyclerView.this.mAdapter;
                        if (!(adapter == null || obj == null)) {
                            adapter.onFailedToRecycleView$ar$ds(viewHolder);
                        }
                        if (viewHolder.isRecyclable()) {
                            int i2;
                            if (this.mViewCacheMax <= 0 || viewHolder.hasAnyOfTheFlags(526)) {
                                i2 = 0;
                            } else {
                                i2 = this.mCachedViews.size();
                                if (i2 >= this.mViewCacheMax && i2 > 0) {
                                    recycleCachedViewAt(0);
                                    i2--;
                                }
                                if (i2 > 0 && !RecyclerView.this.mPrefetchRegistry.lastPrefetchIncludedPosition(viewHolder.mPosition)) {
                                    i2--;
                                    while (i2 >= 0) {
                                        if (!RecyclerView.this.mPrefetchRegistry.lastPrefetchIncludedPosition(((ViewHolder) this.mCachedViews.get(i2)).mPosition)) {
                                            break;
                                        }
                                        i2--;
                                    }
                                    i2++;
                                }
                                this.mCachedViews.add(i2, viewHolder);
                                i2 = 1;
                            }
                            if (i2 == 0) {
                                addViewHolderToRecycledViewPool(viewHolder, true);
                                i = i2;
                                RecyclerView.this.mViewInfoStore.removeViewHolder(viewHolder);
                                if (i == 0 && !r1 && obj != null) {
                                    viewHolder.mBindingAdapter = null;
                                    viewHolder.mOwnerRecyclerView = null;
                                    return;
                                }
                                return;
                            }
                            i = i2;
                        }
                        z = false;
                        RecyclerView.this.mViewInfoStore.removeViewHolder(viewHolder);
                        if (i == 0) {
                            return;
                        }
                        return;
                    }
                }
            }
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Scrapped or attached views may not be recycled. isScrap:");
            stringBuilder3.append(viewHolder.isScrap());
            stringBuilder3.append(" isAttached:");
            if (viewHolder.itemView.getParent() == null) {
                z = false;
            }
            stringBuilder3.append(z);
            stringBuilder3.append(RecyclerView.this.exceptionLabel());
            throw new IllegalArgumentException(stringBuilder3.toString());
        }

        final void scrapView(View view) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (!childViewHolderInt.hasAnyOfTheFlags(12) && childViewHolderInt.isUpdated()) {
                ItemAnimator itemAnimator = RecyclerView.this.mItemAnimator;
                if (itemAnimator != null) {
                    if (!itemAnimator.canReuseUpdatedViewHolder(childViewHolderInt, childViewHolderInt.getUnmodifiedPayloads())) {
                        if (this.mChangedScrap == null) {
                            this.mChangedScrap = new ArrayList();
                        }
                        childViewHolderInt.setScrapContainer(this, true);
                        this.mChangedScrap.add(childViewHolderInt);
                        return;
                    }
                }
            }
            if (childViewHolderInt.isInvalid() && !childViewHolderInt.isRemoved()) {
                if (!RecyclerView.this.mAdapter.mHasStableIds) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.");
                    stringBuilder.append(RecyclerView.this.exceptionLabel());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
            }
            childViewHolderInt.setScrapContainer(this, false);
            this.mAttachedScrap.add(childViewHolderInt);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        final android.support.p002v7.widget.RecyclerView.ViewHolder tryGetViewHolderForPositionByDeadline$ar$ds(int r19, long r20) {
            /*
            r18 = this;
            r1 = r18;
            r0 = r19;
            if (r0 < 0) goto L_0x04f9;
        L_0x0006:
            r2 = android.support.p002v7.widget.RecyclerView.this;
            r2 = r2.mState;
            r2 = r2.getItemCount();
            if (r0 >= r2) goto L_0x04f9;
        L_0x0010:
            r2 = android.support.p002v7.widget.RecyclerView.this;
            r2 = r2.mState;
            r2 = r2.mInPreLayout;
            r3 = 32;
            r5 = 0;
            r6 = 0;
            if (r2 == 0) goto L_0x008e;
        L_0x001c:
            r2 = r1.mChangedScrap;
            if (r2 == 0) goto L_0x0087;
        L_0x0020:
            r2 = r2.size();
            if (r2 != 0) goto L_0x0028;
        L_0x0026:
            r8 = r6;
            goto L_0x0088;
        L_0x0028:
            r7 = 0;
        L_0x0029:
            if (r7 >= r2) goto L_0x0046;
        L_0x002b:
            r8 = r1.mChangedScrap;
            r8 = r8.get(r7);
            r8 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r8;
            r9 = r8.wasReturnedFromScrap();
            if (r9 != 0) goto L_0x0043;
        L_0x0039:
            r9 = r8.getLayoutPosition();
            if (r9 != r0) goto L_0x0043;
        L_0x003f:
            r8.addFlags(r3);
            goto L_0x0088;
        L_0x0043:
            r7 = r7 + 1;
            goto L_0x0029;
        L_0x0046:
            r7 = android.support.p002v7.widget.RecyclerView.this;
            r8 = r7.mAdapter;
            r8 = r8.mHasStableIds;
            if (r8 == 0) goto L_0x0087;
        L_0x004e:
            r7 = r7.mAdapterHelper;
            r7 = r7.findPositionOffset(r0);
            if (r7 <= 0) goto L_0x0087;
        L_0x0056:
            r8 = android.support.p002v7.widget.RecyclerView.this;
            r8 = r8.mAdapter;
            r8 = r8.getItemCount();
            if (r7 >= r8) goto L_0x0087;
        L_0x0060:
            r8 = android.support.p002v7.widget.RecyclerView.this;
            r8 = r8.mAdapter;
            r7 = r8.getItemId(r7);
            r9 = 0;
        L_0x0069:
            if (r9 >= r2) goto L_0x0087;
        L_0x006b:
            r10 = r1.mChangedScrap;
            r10 = r10.get(r9);
            r10 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r10;
            r11 = r10.wasReturnedFromScrap();
            if (r11 != 0) goto L_0x0084;
        L_0x0079:
            r11 = r10.mItemId;
            r13 = (r11 > r7 ? 1 : (r11 == r7 ? 0 : -1));
            if (r13 != 0) goto L_0x0084;
        L_0x007f:
            r10.addFlags(r3);
            r8 = r10;
            goto L_0x0088;
        L_0x0084:
            r9 = r9 + 1;
            goto L_0x0069;
        L_0x0087:
            r8 = r6;
        L_0x0088:
            if (r8 == 0) goto L_0x008c;
        L_0x008a:
            r2 = 1;
            goto L_0x008d;
        L_0x008c:
            r2 = 0;
        L_0x008d:
            goto L_0x0090;
        L_0x008e:
            r8 = r6;
            r2 = 0;
        L_0x0090:
            r7 = -1;
            if (r8 != 0) goto L_0x0249;
        L_0x0093:
            r8 = r1.mAttachedScrap;
            r8 = r8.size();
            r9 = 0;
        L_0x009a:
            if (r9 >= r8) goto L_0x00cd;
        L_0x009c:
            r10 = r1.mAttachedScrap;
            r10 = r10.get(r9);
            r10 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r10;
            r11 = r10.wasReturnedFromScrap();
            if (r11 != 0) goto L_0x00ca;
        L_0x00aa:
            r11 = r10.getLayoutPosition();
            if (r11 != r0) goto L_0x00ca;
        L_0x00b0:
            r11 = r10.isInvalid();
            if (r11 != 0) goto L_0x00ca;
        L_0x00b6:
            r11 = android.support.p002v7.widget.RecyclerView.this;
            r11 = r11.mState;
            r11 = r11.mInPreLayout;
            if (r11 != 0) goto L_0x00c4;
        L_0x00be:
            r11 = r10.isRemoved();
            if (r11 != 0) goto L_0x00ca;
        L_0x00c4:
            r10.addFlags(r3);
            r8 = r10;
            goto L_0x01b8;
        L_0x00ca:
            r9 = r9 + 1;
            goto L_0x009a;
        L_0x00cd:
            r8 = android.support.p002v7.widget.RecyclerView.this;
            r8 = r8.mChildHelper;
            r9 = r8.mHiddenViews;
            r9 = r9.size();
            r10 = 0;
        L_0x00d8:
            if (r10 >= r9) goto L_0x00fe;
        L_0x00da:
            r11 = r8.mHiddenViews;
            r11 = r11.get(r10);
            r11 = (android.view.View) r11;
            r12 = r8.mCallback$ar$class_merging$5a35e444_0;
            r12 = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(r11);
            r13 = r12.getLayoutPosition();
            if (r13 != r0) goto L_0x00fb;
        L_0x00ee:
            r13 = r12.isInvalid();
            if (r13 != 0) goto L_0x00fb;
        L_0x00f4:
            r12 = r12.isRemoved();
            if (r12 != 0) goto L_0x00fb;
        L_0x00fa:
            goto L_0x00ff;
        L_0x00fb:
            r10 = r10 + 1;
            goto L_0x00d8;
        L_0x00fe:
            r11 = r6;
        L_0x00ff:
            if (r11 == 0) goto L_0x018a;
        L_0x0101:
            r8 = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(r11);
            r9 = android.support.p002v7.widget.RecyclerView.this;
            r9 = r9.mChildHelper;
            r10 = r9.mCallback$ar$class_merging$5a35e444_0;
            r10 = r10.indexOfChild(r11);
            if (r10 < 0) goto L_0x0173;
        L_0x0111:
            r12 = r9.mBucket;
            r12 = r12.get(r10);
            if (r12 == 0) goto L_0x015c;
        L_0x0119:
            r12 = r9.mBucket;
            r12.clear(r10);
            r9.unhideViewInternal$ar$ds(r11);
            r9 = android.support.p002v7.widget.RecyclerView.this;
            r9 = r9.mChildHelper;
            r9 = r9.indexOfChild(r11);
            if (r9 == r7) goto L_0x013c;
        L_0x012b:
            r10 = android.support.p002v7.widget.RecyclerView.this;
            r10 = r10.mChildHelper;
            r10.detachViewFromParent(r9);
            r1.scrapView(r11);
            r9 = 8224; // 0x2020 float:1.1524E-41 double:4.063E-320;
            r8.addFlags(r9);
            goto L_0x01b8;
        L_0x013c:
            r0 = new java.lang.IllegalStateException;
            r2 = new java.lang.StringBuilder;
            r2.<init>();
            r3 = "layout index should not be -1 after unhiding a view:";
            r2.append(r3);
            r2.append(r8);
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.exceptionLabel();
            r2.append(r3);
            r2 = r2.toString();
            r0.<init>(r2);
            throw r0;
        L_0x015c:
            r0 = new java.lang.RuntimeException;
            r2 = new java.lang.StringBuilder;
            r2.<init>();
            r3 = "trying to unhide a view that was not hidden";
            r2.append(r3);
            r2.append(r11);
            r2 = r2.toString();
            r0.<init>(r2);
            throw r0;
        L_0x0173:
            r0 = new java.lang.IllegalArgumentException;
            r2 = new java.lang.StringBuilder;
            r2.<init>();
            r3 = "view is not a child, cannot hide ";
            r2.append(r3);
            r2.append(r11);
            r2 = r2.toString();
            r0.<init>(r2);
            throw r0;
        L_0x018a:
            r8 = r1.mCachedViews;
            r8 = r8.size();
            r9 = 0;
        L_0x0191:
            if (r9 >= r8) goto L_0x01b7;
        L_0x0193:
            r10 = r1.mCachedViews;
            r10 = r10.get(r9);
            r10 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r10;
            r11 = r10.isInvalid();
            if (r11 != 0) goto L_0x01b4;
        L_0x01a1:
            r11 = r10.getLayoutPosition();
            if (r11 != r0) goto L_0x01b4;
        L_0x01a7:
            r11 = r10.isAttachedToTransitionOverlay();
            if (r11 != 0) goto L_0x01b4;
        L_0x01ad:
            r8 = r1.mCachedViews;
            r8.remove(r9);
            r8 = r10;
            goto L_0x01b8;
        L_0x01b4:
            r9 = r9 + 1;
            goto L_0x0191;
        L_0x01b7:
            r8 = r6;
        L_0x01b8:
            if (r8 == 0) goto L_0x0248;
        L_0x01ba:
            r9 = r8.isRemoved();
            if (r9 == 0) goto L_0x01cc;
        L_0x01c0:
            r9 = android.support.p002v7.widget.RecyclerView.this;
            r9 = r9.mState;
            r9 = r9.mInPreLayout;
            if (r9 != 0) goto L_0x01c9;
        L_0x01c8:
            goto L_0x0203;
        L_0x01c9:
            r2 = 1;
            goto L_0x024a;
        L_0x01cc:
            r9 = r8.mPosition;
            if (r9 < 0) goto L_0x0228;
        L_0x01d0:
            r10 = android.support.p002v7.widget.RecyclerView.this;
            r10 = r10.mAdapter;
            r10 = r10.getItemCount();
            if (r9 >= r10) goto L_0x0228;
        L_0x01da:
            r9 = android.support.p002v7.widget.RecyclerView.this;
            r10 = r9.mState;
            r10 = r10.mInPreLayout;
            if (r10 != 0) goto L_0x01ee;
        L_0x01e2:
            r9 = r9.mAdapter;
            r10 = r8.mPosition;
            r9 = r9.getItemViewType(r10);
            r10 = r8.mItemViewType;
            if (r9 != r10) goto L_0x0203;
        L_0x01ee:
            r9 = android.support.p002v7.widget.RecyclerView.this;
            r9 = r9.mAdapter;
            r10 = r9.mHasStableIds;
            if (r10 == 0) goto L_0x0226;
        L_0x01f6:
            r10 = r8.mItemId;
            r12 = r8.mPosition;
            r12 = r9.getItemId(r12);
            r9 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1));
            if (r9 != 0) goto L_0x0203;
        L_0x0202:
            goto L_0x0226;
        L_0x0203:
            r9 = 4;
            r8.addFlags(r9);
            r9 = r8.isScrap();
            if (r9 == 0) goto L_0x0218;
        L_0x020d:
            r9 = android.support.p002v7.widget.RecyclerView.this;
            r10 = r8.itemView;
            r9.removeDetachedView(r10, r5);
            r8.unScrap();
            goto L_0x0221;
        L_0x0218:
            r9 = r8.wasReturnedFromScrap();
            if (r9 == 0) goto L_0x0221;
        L_0x021e:
            r8.clearReturnedFromScrapFlag();
        L_0x0221:
            r1.recycleViewHolderInternal(r8);
            r8 = r6;
            goto L_0x024a;
        L_0x0226:
            r2 = 1;
            goto L_0x024a;
        L_0x0228:
            r0 = new java.lang.IndexOutOfBoundsException;
            r2 = new java.lang.StringBuilder;
            r2.<init>();
            r3 = "Inconsistency detected. Invalid view holder adapter position";
            r2.append(r3);
            r2.append(r8);
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.exceptionLabel();
            r2.append(r3);
            r2 = r2.toString();
            r0.<init>(r2);
            throw r0;
        L_0x0248:
            goto L_0x024a;
        L_0x024a:
            r11 = 9223372036854775807; // 0x7fffffffffffffff float:NaN double:NaN;
            if (r8 != 0) goto L_0x03e0;
        L_0x0251:
            r13 = android.support.p002v7.widget.RecyclerView.this;
            r13 = r13.mAdapterHelper;
            r13 = r13.findPositionOffset(r0);
            if (r13 < 0) goto L_0x03a8;
        L_0x025b:
            r14 = android.support.p002v7.widget.RecyclerView.this;
            r14 = r14.mAdapter;
            r14 = r14.getItemCount();
            if (r13 >= r14) goto L_0x03a8;
        L_0x0265:
            r14 = android.support.p002v7.widget.RecyclerView.this;
            r14 = r14.mAdapter;
            r14 = r14.getItemViewType(r13);
            r15 = android.support.p002v7.widget.RecyclerView.this;
            r15 = r15.mAdapter;
            r4 = r15.mHasStableIds;
            if (r4 == 0) goto L_0x02ff;
        L_0x0275:
            r16 = r15.getItemId(r13);
            r4 = r1.mAttachedScrap;
            r4 = r4.size();
            r4 = r4 + r7;
        L_0x0280:
            if (r4 < 0) goto L_0x02c7;
        L_0x0282:
            r8 = r1.mAttachedScrap;
            r8 = r8.get(r4);
            r8 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r8;
            r9 = r8.mItemId;
            r15 = (r9 > r16 ? 1 : (r9 == r16 ? 0 : -1));
            if (r15 != 0) goto L_0x02c4;
        L_0x0290:
            r9 = r8.wasReturnedFromScrap();
            if (r9 != 0) goto L_0x02c4;
        L_0x0296:
            r9 = r8.mItemViewType;
            if (r14 != r9) goto L_0x02b3;
        L_0x029a:
            r8.addFlags(r3);
            r3 = r8.isRemoved();
            if (r3 == 0) goto L_0x02b2;
        L_0x02a3:
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.mState;
            r3 = r3.mInPreLayout;
            if (r3 != 0) goto L_0x02b2;
        L_0x02ab:
            r3 = 2;
            r4 = 14;
            r8.setFlags(r3, r4);
            goto L_0x02f8;
        L_0x02b2:
            goto L_0x02f8;
        L_0x02b3:
            r9 = r1.mAttachedScrap;
            r9.remove(r4);
            r9 = android.support.p002v7.widget.RecyclerView.this;
            r10 = r8.itemView;
            r9.removeDetachedView(r10, r5);
            r8 = r8.itemView;
            r1.quickRecycleScrapView(r8);
        L_0x02c4:
            r4 = r4 + -1;
            goto L_0x0280;
        L_0x02c7:
            r3 = r1.mCachedViews;
            r3 = r3.size();
            r3 = r3 + r7;
        L_0x02ce:
            if (r3 < 0) goto L_0x02f6;
        L_0x02d0:
            r4 = r1.mCachedViews;
            r4 = r4.get(r3);
            r4 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r4;
            r8 = r4.mItemId;
            r10 = (r8 > r16 ? 1 : (r8 == r16 ? 0 : -1));
            if (r10 != 0) goto L_0x02f3;
        L_0x02de:
            r8 = r4.isAttachedToTransitionOverlay();
            if (r8 != 0) goto L_0x02f3;
        L_0x02e4:
            r8 = r4.mItemViewType;
            if (r14 != r8) goto L_0x02ef;
        L_0x02e8:
            r8 = r1.mCachedViews;
            r8.remove(r3);
            r8 = r4;
            goto L_0x02f8;
        L_0x02ef:
            r1.recycleCachedViewAt(r3);
            goto L_0x02f7;
        L_0x02f3:
            r3 = r3 + -1;
            goto L_0x02ce;
        L_0x02f7:
            r8 = r6;
        L_0x02f8:
            if (r8 == 0) goto L_0x02fe;
        L_0x02fa:
            r8.mPosition = r13;
            r2 = 1;
            goto L_0x0300;
        L_0x02fe:
            goto L_0x0300;
        L_0x0300:
            if (r8 != 0) goto L_0x033e;
        L_0x0302:
            r3 = r18.getRecycledViewPool();
            r3 = r3.mScrap;
            r3 = r3.get(r14);
            r3 = (android.support.p002v7.widget.RecyclerView.RecycledViewPool.ScrapData) r3;
            if (r3 == 0) goto L_0x0337;
        L_0x0310:
            r4 = r3.mScrapHeap;
            r4 = r4.isEmpty();
            if (r4 != 0) goto L_0x0337;
        L_0x0318:
            r3 = r3.mScrapHeap;
            r4 = r3.size();
            r4 = r4 + r7;
        L_0x031f:
            if (r4 < 0) goto L_0x0337;
        L_0x0321:
            r7 = r3.get(r4);
            r7 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r7;
            r7 = r7.isAttachedToTransitionOverlay();
            if (r7 != 0) goto L_0x0334;
        L_0x032d:
            r3 = r3.remove(r4);
            r3 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r3;
            goto L_0x0338;
        L_0x0334:
            r4 = r4 + -1;
            goto L_0x031f;
        L_0x0337:
            r3 = r6;
        L_0x0338:
            if (r3 == 0) goto L_0x033d;
        L_0x033a:
            r3.resetInternal();
        L_0x033d:
            r8 = r3;
        L_0x033e:
            if (r8 != 0) goto L_0x03a7;
        L_0x0340:
            r3 = java.lang.System.nanoTime();
            r7 = (r20 > r11 ? 1 : (r20 == r11 ? 0 : -1));
            if (r7 == 0) goto L_0x035d;
        L_0x0348:
            r7 = r1.mRecyclerPool;
            r7 = r7.getScrapDataForType(r14);
            r7 = r7.mCreateRunningAverageNs;
            r9 = 0;
            r13 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1));
            if (r13 == 0) goto L_0x035d;
        L_0x0356:
            r7 = r7 + r3;
            r9 = (r7 > r20 ? 1 : (r7 == r20 ? 0 : -1));
            if (r9 >= 0) goto L_0x035c;
        L_0x035b:
            goto L_0x035d;
        L_0x035c:
            return r6;
        L_0x035d:
            r7 = android.support.p002v7.widget.RecyclerView.this;
            r8 = r7.mAdapter;
            r9 = "RV CreateView";
            android.os.Trace.beginSection(r9);	 Catch:{ all -> 0x03a2 }
            r8 = r8.onCreateViewHolder(r7, r14);	 Catch:{ all -> 0x03a2 }
            r7 = r8.itemView;	 Catch:{ all -> 0x03a2 }
            r7 = r7.getParent();	 Catch:{ all -> 0x03a2 }
            if (r7 != 0) goto L_0x039a;
        L_0x0372:
            r8.mItemViewType = r14;	 Catch:{ all -> 0x03a2 }
            android.os.Trace.endSection();
            r7 = r8.itemView;
            r7 = android.support.p002v7.widget.RecyclerView.findNestedRecyclerView(r7);
            if (r7 == 0) goto L_0x0386;
        L_0x037f:
            r9 = new java.lang.ref.WeakReference;
            r9.<init>(r7);
            r8.mNestedRecyclerView = r9;
        L_0x0386:
            r9 = java.lang.System.nanoTime();
            r7 = r1.mRecyclerPool;
            r7 = r7.getScrapDataForType(r14);
            r13 = r7.mCreateRunningAverageNs;
            r9 = r9 - r3;
            r3 = android.support.p002v7.widget.RecyclerView.RecycledViewPool.runningAverage$ar$ds(r13, r9);
            r7.mCreateRunningAverageNs = r3;
            goto L_0x03e1;
        L_0x039a:
            r0 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x03a2 }
            r2 = "ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)";
            r0.<init>(r2);	 Catch:{ all -> 0x03a2 }
            throw r0;	 Catch:{ all -> 0x03a2 }
        L_0x03a2:
            r0 = move-exception;
            android.os.Trace.endSection();
            throw r0;
        L_0x03a7:
            goto L_0x03e1;
        L_0x03a8:
            r2 = new java.lang.IndexOutOfBoundsException;
            r3 = new java.lang.StringBuilder;
            r3.<init>();
            r4 = "Inconsistency detected. Invalid item position ";
            r3.append(r4);
            r3.append(r0);
            r0 = "(offset:";
            r3.append(r0);
            r3.append(r13);
            r0 = ").state:";
            r3.append(r0);
            r0 = android.support.p002v7.widget.RecyclerView.this;
            r0 = r0.mState;
            r0 = r0.getItemCount();
            r3.append(r0);
            r0 = android.support.p002v7.widget.RecyclerView.this;
            r0 = r0.exceptionLabel();
            r3.append(r0);
            r0 = r3.toString();
            r2.<init>(r0);
            throw r2;
        L_0x03e1:
            if (r2 == 0) goto L_0x040d;
        L_0x03e3:
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.mState;
            r3 = r3.mInPreLayout;
            if (r3 != 0) goto L_0x040d;
        L_0x03eb:
            r3 = 8192; // 0x2000 float:1.14794E-41 double:4.0474E-320;
            r4 = r8.hasAnyOfTheFlags(r3);
            if (r4 == 0) goto L_0x040d;
        L_0x03f3:
            r8.setFlags(r5, r3);
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.mState;
            r3 = r3.mRunSimpleAnimations;
            if (r3 == 0) goto L_0x040d;
        L_0x03fe:
            android.support.p002v7.widget.RecyclerView.ItemAnimator.buildAdapterChangeFlagsForAnimations$ar$ds(r8);
            r8.getUnmodifiedPayloads();
            r3 = android.support.p002v7.widget.RecyclerView.ItemAnimator.recordPreLayoutInformation$ar$ds$2b04a7c7_0(r8);
            r4 = android.support.p002v7.widget.RecyclerView.this;
            r4.recordAnimationInfoIfBouncedHiddenView(r8, r3);
        L_0x040d:
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.mState;
            r3 = r3.mInPreLayout;
            if (r3 == 0) goto L_0x0421;
        L_0x0415:
            r3 = r8.isBound();
            if (r3 == 0) goto L_0x0421;
        L_0x041b:
            r8.mPreLayoutPosition = r0;
            r0 = 0;
            r4 = 1;
            goto L_0x04c1;
        L_0x0421:
            r3 = r8.isBound();
            if (r3 == 0) goto L_0x0438;
        L_0x0427:
            r3 = r8.needsUpdate();
            if (r3 != 0) goto L_0x0438;
        L_0x042d:
            r3 = r8.isInvalid();
            if (r3 == 0) goto L_0x0434;
        L_0x0433:
            goto L_0x0438;
        L_0x0434:
            r0 = 0;
            r4 = 1;
            goto L_0x04c1;
        L_0x0438:
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.mAdapterHelper;
            r3 = r3.findPositionOffset(r0);
            r8.mBindingAdapter = r6;
            r4 = android.support.p002v7.widget.RecyclerView.this;
            r8.mOwnerRecyclerView = r4;
            r4 = r8.mItemViewType;
            r6 = java.lang.System.nanoTime();
            r9 = (r20 > r11 ? 1 : (r20 == r11 ? 0 : -1));
            if (r9 == 0) goto L_0x0463;
        L_0x0450:
            r9 = r1.mRecyclerPool;
            r4 = r9.getScrapDataForType(r4);
            r9 = r4.mBindRunningAverageNs;
            r11 = 0;
            r4 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1));
            if (r4 == 0) goto L_0x0463;
        L_0x045e:
            r9 = r9 + r6;
            r4 = (r9 > r20 ? 1 : (r9 == r20 ? 0 : -1));
            if (r4 >= 0) goto L_0x0434;
        L_0x0463:
            r4 = android.support.p002v7.widget.RecyclerView.this;
            r4 = r4.mAdapter;
            r4.bindViewHolder(r8, r3);
            r3 = java.lang.System.nanoTime();
            r9 = r1.mRecyclerPool;
            r10 = r8.mItemViewType;
            r9 = r9.getScrapDataForType(r10);
            r10 = r9.mBindRunningAverageNs;
            r3 = r3 - r6;
            r3 = android.support.p002v7.widget.RecyclerView.RecycledViewPool.runningAverage$ar$ds(r10, r3);
            r9.mBindRunningAverageNs = r3;
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.isAccessibilityEnabled();
            if (r3 == 0) goto L_0x04b3;
        L_0x0487:
            r3 = r8.itemView;
            r4 = android.support.p000v4.view.ViewCompat.getImportantForAccessibility(r3);
            if (r4 != 0) goto L_0x0494;
        L_0x048f:
            r4 = 1;
            android.support.p000v4.view.ViewCompat.setImportantForAccessibility(r3, r4);
            goto L_0x0495;
        L_0x0494:
            r4 = 1;
        L_0x0495:
            r6 = android.support.p002v7.widget.RecyclerView.this;
            r6 = r6.mAccessibilityDelegate;
            if (r6 != 0) goto L_0x049c;
        L_0x049b:
            goto L_0x04b4;
        L_0x049c:
            r6 = r6.mItemDelegate;
            r7 = r6 instanceof android.support.p002v7.widget.RecyclerViewAccessibilityDelegate.ItemDelegate;
            if (r7 == 0) goto L_0x04af;
        L_0x04a2:
            r7 = android.support.p000v4.view.ViewCompat.getAccessibilityDelegate(r3);
            if (r7 == 0) goto L_0x04af;
        L_0x04a8:
            if (r7 == r6) goto L_0x04af;
        L_0x04aa:
            r9 = r6.mOriginalItemDelegates;
            r9.put(r3, r7);
        L_0x04af:
            android.support.p000v4.view.ViewCompat.setAccessibilityDelegate(r3, r6);
            goto L_0x04b4;
        L_0x04b3:
            r4 = 1;
        L_0x04b4:
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.mState;
            r3 = r3.mInPreLayout;
            if (r3 == 0) goto L_0x04bf;
        L_0x04bc:
            r8.mPreLayoutPosition = r0;
            goto L_0x04c0;
        L_0x04c0:
            r0 = 1;
        L_0x04c1:
            r3 = r8.itemView;
            r3 = r3.getLayoutParams();
            if (r3 != 0) goto L_0x04d5;
        L_0x04c9:
            r3 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r3.generateDefaultLayoutParams();
            r6 = r8.itemView;
            r6.setLayoutParams(r3);
            goto L_0x04eb;
        L_0x04d5:
            r6 = android.support.p002v7.widget.RecyclerView.this;
            r6 = r6.checkLayoutParams(r3);
            if (r6 != 0) goto L_0x04e9;
        L_0x04dd:
            r6 = android.support.p002v7.widget.RecyclerView.this;
            r3 = r6.generateLayoutParams(r3);
            r6 = r8.itemView;
            r6.setLayoutParams(r3);
            goto L_0x04eb;
        L_0x04e9:
            r3 = (android.support.p002v7.widget.RecyclerView.LayoutParams) r3;
        L_0x04eb:
            r3 = (android.support.p002v7.widget.RecyclerView.LayoutParams) r3;
            r3.mViewHolder = r8;
            if (r2 == 0) goto L_0x04f4;
        L_0x04f1:
            if (r0 == 0) goto L_0x04f4;
        L_0x04f3:
            goto L_0x04f5;
        L_0x04f4:
            r4 = 0;
            r3.mPendingInvalidate = r4;
            return r8;
        L_0x04f9:
            r2 = new java.lang.IndexOutOfBoundsException;
            r3 = new java.lang.StringBuilder;
            r3.<init>();
            r4 = "Invalid item position ";
            r3.append(r4);
            r3.append(r0);
            r4 = "(";
            r3.append(r4);
            r3.append(r0);
            r0 = "). Item count:";
            r3.append(r0);
            r0 = android.support.p002v7.widget.RecyclerView.this;
            r0 = r0.mState;
            r0 = r0.getItemCount();
            r3.append(r0);
            r0 = android.support.p002v7.widget.RecyclerView.this;
            r0 = r0.exceptionLabel();
            r3.append(r0);
            r0 = r3.toString();
            r2.<init>(r0);
            goto L_0x0532;
        L_0x0531:
            throw r2;
        L_0x0532:
            goto L_0x0531;
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.Recycler.tryGetViewHolderForPositionByDeadline$ar$ds(int, long):android.support.v7.widget.RecyclerView$ViewHolder");
        }

        final void unscrapView(ViewHolder viewHolder) {
            if (viewHolder.mInChangeScrap) {
                this.mChangedScrap.remove(viewHolder);
            } else {
                this.mAttachedScrap.remove(viewHolder);
            }
            viewHolder.mScrapContainer = null;
            viewHolder.mInChangeScrap = false;
            viewHolder.clearReturnedFromScrapFlag();
        }

        final void updateViewCacheSize() {
            LayoutManager layoutManager = RecyclerView.this.mLayout;
            this.mViewCacheMax = (layoutManager != null ? layoutManager.mPrefetchMaxCountObserved : 0) + 2;
            for (int size = this.mCachedViews.size() - 1; size >= 0 && this.mCachedViews.size() > this.mViewCacheMax; size--) {
                recycleCachedViewAt(size);
            }
        }

        public final View getViewForPosition(int i) {
            return tryGetViewHolderForPositionByDeadline$ar$ds(i, Long.MAX_VALUE).itemView;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$RecyclerListener */
    public interface RecyclerListener {
        void onViewRecycled$ar$ds();
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$RecyclerViewDataObserver */
    final class RecyclerViewDataObserver extends AdapterDataObserver {
        public final void onChanged() {
            RecyclerView.this.assertNotInLayoutOrScroll(null);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.mState.mStructureChanged = true;
            recyclerView.processDataSetCompletelyChanged(true);
            if (!RecyclerView.this.mAdapterHelper.hasPendingUpdates()) {
                RecyclerView.this.requestLayout();
            }
        }

        public final void onItemRangeChanged(int i, int i2, Object obj) {
            RecyclerView.this.assertNotInLayoutOrScroll(null);
            AdapterHelper adapterHelper = RecyclerView.this.mAdapterHelper;
            if (i2 > 0) {
                adapterHelper.mPendingUpdates.add(adapterHelper.obtainUpdateOp(4, i, i2, obj));
                adapterHelper.mExistingUpdateTypes |= 4;
                if (adapterHelper.mPendingUpdates.size() == 1) {
                    triggerUpdateProcessor();
                }
            }
        }

        public final void onItemRangeInserted(int i, int i2) {
            RecyclerView.this.assertNotInLayoutOrScroll(null);
            AdapterHelper adapterHelper = RecyclerView.this.mAdapterHelper;
            if (i2 > 0) {
                adapterHelper.mPendingUpdates.add(adapterHelper.obtainUpdateOp(1, i, i2, null));
                adapterHelper.mExistingUpdateTypes |= 1;
                if (adapterHelper.mPendingUpdates.size() == 1) {
                    triggerUpdateProcessor();
                }
            }
        }

        public final void onItemRangeMoved$ar$ds(int i, int i2) {
            RecyclerView.this.assertNotInLayoutOrScroll(null);
            AdapterHelper adapterHelper = RecyclerView.this.mAdapterHelper;
            if (i != i2) {
                adapterHelper.mPendingUpdates.add(adapterHelper.obtainUpdateOp(8, i, i2, null));
                adapterHelper.mExistingUpdateTypes |= 8;
                if (adapterHelper.mPendingUpdates.size() == 1) {
                    triggerUpdateProcessor();
                }
            }
        }

        public final void onItemRangeRemoved(int i, int i2) {
            RecyclerView.this.assertNotInLayoutOrScroll(null);
            AdapterHelper adapterHelper = RecyclerView.this.mAdapterHelper;
            if (i2 > 0) {
                adapterHelper.mPendingUpdates.add(adapterHelper.obtainUpdateOp(2, i, i2, null));
                adapterHelper.mExistingUpdateTypes |= 2;
                if (adapterHelper.mPendingUpdates.size() == 1) {
                    triggerUpdateProcessor();
                }
            }
        }

        public final void onStateRestorationPolicyChanged() {
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.mPendingSavedState != null) {
                Adapter adapter = recyclerView.mAdapter;
                if (adapter != null && adapter.canRestoreState()) {
                    RecyclerView.this.requestLayout();
                }
            }
        }

        final void triggerUpdateProcessor() {
            int i = RecyclerView.RecyclerView$ar$NoOp;
            View view = RecyclerView.this;
            if (view.mHasFixedSize && view.mIsAttached) {
                ViewCompat.postOnAnimation(view, view.mUpdateChildViewsRunnable);
                return;
            }
            view.mAdapterUpdateDuringMeasure = true;
            view.requestLayout();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$SavedState */
    public final class SavedState extends AbsSavedState {
        public static final Creator CREATOR = new PG();
        Parcelable mLayoutState;

        /* renamed from: android.support.v7.widget.RecyclerView$SavedState$1 */
        final class PG implements ClassLoaderCreator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new SavedState[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel, null);
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            if (classLoader == null) {
                classLoader = LayoutManager.class.getClassLoader();
            }
            this.mLayoutState = parcel.readParcelable(classLoader);
        }

        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeParcelable(this.mLayoutState, 0);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$SmoothScroller */
    public abstract class SmoothScroller {
        public LayoutManager mLayoutManager;
        public boolean mPendingInitialRun;
        public RecyclerView mRecyclerView;
        private final Action mRecyclingAction = new Action();
        public boolean mRunning;
        public boolean mStarted;
        public int mTargetPosition = -1;
        public View mTargetView;

        /* compiled from: PG */
        /* renamed from: android.support.v7.widget.RecyclerView$SmoothScroller$Action */
        public final class Action {
            private boolean mChanged = false;
            private int mConsecutiveUpdates = 0;
            private int mDuration = LinearLayoutManager.INVALID_OFFSET;
            private int mDx = 0;
            private int mDy = 0;
            private Interpolator mInterpolator = null;
            public int mJumpToPosition = -1;

            final void runIfNecessary(RecyclerView recyclerView) {
                int i = this.mJumpToPosition;
                if (i >= 0) {
                    this.mJumpToPosition = -1;
                    recyclerView.jumpToPositionForSmoothScroller(i);
                    this.mChanged = false;
                } else if (this.mChanged) {
                    Interpolator interpolator = this.mInterpolator;
                    if (interpolator != null) {
                        if (this.mDuration <= 0) {
                            throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
                        }
                    }
                    int i2 = this.mDuration;
                    if (i2 > 0) {
                        recyclerView.mViewFlinger.smoothScrollBy(this.mDx, this.mDy, i2, interpolator);
                        int i3 = this.mConsecutiveUpdates + 1;
                        this.mConsecutiveUpdates = i3;
                        if (i3 > 10) {
                            Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
                        }
                        this.mChanged = false;
                        return;
                    }
                    throw new IllegalStateException("Scroll duration must be a positive number");
                } else {
                    this.mConsecutiveUpdates = 0;
                }
            }

            public final void update(int i, int i2, int i3, Interpolator interpolator) {
                this.mDx = i;
                this.mDy = i2;
                this.mDuration = i3;
                this.mInterpolator = interpolator;
                this.mChanged = true;
            }
        }

        /* compiled from: PG */
        /* renamed from: android.support.v7.widget.RecyclerView$SmoothScroller$ScrollVectorProvider */
        public interface ScrollVectorProvider {
            PointF computeScrollVectorForPosition(int i);
        }

        protected static final void normalize$ar$ds(PointF pointF) {
            float sqrt = (float) Math.sqrt((double) ((pointF.x * pointF.x) + (pointF.y * pointF.y)));
            pointF.x /= sqrt;
            pointF.y /= sqrt;
        }

        public PointF computeScrollVectorForPosition(int i) {
            LayoutManager layoutManager = this.mLayoutManager;
            if (layoutManager instanceof ScrollVectorProvider) {
                return ((ScrollVectorProvider) layoutManager).computeScrollVectorForPosition(i);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("You should override computeScrollVectorForPosition when the LayoutManager does not implement ");
            stringBuilder.append(ScrollVectorProvider.class.getCanonicalName());
            Log.w("RecyclerView", stringBuilder.toString());
            return null;
        }

        final void onAnimation(int i, int i2) {
            RecyclerView recyclerView = this.mRecyclerView;
            if (this.mTargetPosition == -1 || recyclerView == null) {
                stop();
            }
            if (this.mPendingInitialRun && this.mTargetView == null && this.mLayoutManager != null) {
                PointF computeScrollVectorForPosition = computeScrollVectorForPosition(this.mTargetPosition);
                if (!(computeScrollVectorForPosition == null || (computeScrollVectorForPosition.x == 0.0f && computeScrollVectorForPosition.y == 0.0f))) {
                    recyclerView.scrollStep((int) Math.signum(computeScrollVectorForPosition.x), (int) Math.signum(computeScrollVectorForPosition.y), null);
                }
            }
            this.mPendingInitialRun = false;
            View view = this.mTargetView;
            if (view != null) {
                if (SmoothScroller.getChildPosition$ar$ds(view) == this.mTargetPosition) {
                    onTargetFound(this.mTargetView, recyclerView.mState, this.mRecyclingAction);
                    this.mRecyclingAction.runIfNecessary(recyclerView);
                    stop();
                } else {
                    Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
                    this.mTargetView = null;
                }
            }
            if (this.mRunning) {
                State state = recyclerView.mState;
                onSeekTargetStep$ar$ds(i, i2, this.mRecyclingAction);
                Action action = this.mRecyclingAction;
                i2 = action.mJumpToPosition;
                action.runIfNecessary(recyclerView);
                if (i2 >= 0 && this.mRunning) {
                    this.mPendingInitialRun = true;
                    recyclerView.mViewFlinger.postOnAnimation();
                }
            }
        }

        protected abstract void onSeekTargetStep$ar$ds(int i, int i2, Action action);

        protected abstract void onStop();

        protected abstract void onTargetFound(View view, State state, Action action);

        protected final void stop() {
            if (this.mRunning) {
                this.mRunning = false;
                onStop();
                this.mRecyclerView.mState.mTargetPosition = -1;
                this.mTargetView = null;
                this.mTargetPosition = -1;
                this.mPendingInitialRun = false;
                this.mLayoutManager.onSmoothScrollerStopped(this);
                this.mLayoutManager = null;
                this.mRecyclerView = null;
            }
        }

        public static final int getChildPosition$ar$ds(View view) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            return childViewHolderInt != null ? childViewHolderInt.getLayoutPosition() : -1;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$State */
    public final class State {
        int mDeletedInvisibleItemCountSincePreviousLayout = 0;
        long mFocusedItemId;
        int mFocusedItemPosition;
        int mFocusedSubChildId;
        public boolean mInPreLayout = false;
        boolean mIsMeasuring = false;
        int mItemCount = 0;
        int mLayoutStep = 1;
        int mPreviousLayoutItemCount = 0;
        public int mRemainingScrollHorizontal;
        public int mRemainingScrollVertical;
        boolean mRunPredictiveAnimations = false;
        boolean mRunSimpleAnimations = false;
        boolean mStructureChanged = false;
        int mTargetPosition = -1;
        boolean mTrackOldChangeHolders = false;

        final void assertLayoutStep(int i) {
            if ((this.mLayoutStep & i) == 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Layout state should be one of ");
                stringBuilder.append(Integer.toBinaryString(i));
                stringBuilder.append(" but it is ");
                stringBuilder.append(Integer.toBinaryString(this.mLayoutStep));
                throw new IllegalStateException(stringBuilder.toString());
            }
        }

        public final int getItemCount() {
            return this.mInPreLayout ? this.mPreviousLayoutItemCount - this.mDeletedInvisibleItemCountSincePreviousLayout : this.mItemCount;
        }

        public final boolean hasTargetScrollPosition() {
            return this.mTargetPosition != -1;
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("State{mTargetPosition=");
            stringBuilder.append(this.mTargetPosition);
            stringBuilder.append(", mData=");
            stringBuilder.append(null);
            stringBuilder.append(", mItemCount=");
            stringBuilder.append(this.mItemCount);
            stringBuilder.append(", mIsMeasuring=");
            stringBuilder.append(this.mIsMeasuring);
            stringBuilder.append(", mPreviousLayoutItemCount=");
            stringBuilder.append(this.mPreviousLayoutItemCount);
            stringBuilder.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
            stringBuilder.append(this.mDeletedInvisibleItemCountSincePreviousLayout);
            stringBuilder.append(", mStructureChanged=");
            stringBuilder.append(this.mStructureChanged);
            stringBuilder.append(", mInPreLayout=");
            stringBuilder.append(this.mInPreLayout);
            stringBuilder.append(", mRunSimpleAnimations=");
            stringBuilder.append(this.mRunSimpleAnimations);
            stringBuilder.append(", mRunPredictiveAnimations=");
            stringBuilder.append(this.mRunPredictiveAnimations);
            stringBuilder.append('}');
            return stringBuilder.toString();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$StretchEdgeEffectFactory */
    final class StretchEdgeEffectFactory extends EdgeEffectFactory {
        protected final EdgeEffect createEdgeEffect$ar$ds(RecyclerView recyclerView) {
            return new EdgeEffect(recyclerView.getContext());
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$ViewFlinger */
    final class ViewFlinger implements Runnable {
        private boolean mEatRunOnAnimationRequest = false;
        Interpolator mInterpolator = RecyclerView.sQuinticInterpolator;
        public int mLastFlingX;
        public int mLastFlingY;
        OverScroller mOverScroller;
        private boolean mReSchedulePostAnimationCallback = false;

        public ViewFlinger() {
            this.mOverScroller = new OverScroller(RecyclerView.this.getContext(), RecyclerView.sQuinticInterpolator);
        }

        private final void internalPostOnAnimation() {
            RecyclerView.this.removeCallbacks(this);
            ViewCompat.postOnAnimation(RecyclerView.this, this);
        }

        final void postOnAnimation() {
            if (this.mEatRunOnAnimationRequest) {
                this.mReSchedulePostAnimationCallback = true;
            } else {
                internalPostOnAnimation();
            }
        }

        public final void run() {
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.mLayout == null) {
                stop();
                return;
            }
            r0.mReSchedulePostAnimationCallback = false;
            r0.mEatRunOnAnimationRequest = true;
            recyclerView.consumePendingUpdateOperations();
            OverScroller overScroller = r0.mOverScroller;
            if (overScroller.computeScrollOffset()) {
                int[] iArr;
                int i;
                int i2;
                int finalX;
                int currY;
                int finalY;
                Object obj;
                RecyclerView recyclerView2;
                SmoothScroller smoothScroller;
                int currVelocity;
                View view;
                GapWorker gapWorker;
                int currX = overScroller.getCurrX();
                int currY2 = overScroller.getCurrY();
                int i3 = currX - r0.mLastFlingX;
                int i4 = currY2 - r0.mLastFlingY;
                r0.mLastFlingX = currX;
                r0.mLastFlingY = currY2;
                RecyclerView recyclerView3 = RecyclerView.this;
                int[] iArr2 = recyclerView3.mReusableIntPair;
                iArr2[0] = 0;
                iArr2[1] = 0;
                if (recyclerView3.dispatchNestedPreScroll(i3, i4, iArr2, null, 1)) {
                    iArr = RecyclerView.this.mReusableIntPair;
                    i3 -= iArr[0];
                    i4 -= iArr[1];
                }
                if (RecyclerView.this.getOverScrollMode() != 2) {
                    RecyclerView.this.considerReleasingGlowsOnScroll(i3, i4);
                }
                RecyclerView recyclerView4 = RecyclerView.this;
                if (recyclerView4.mAdapter != null) {
                    int[] iArr3 = recyclerView4.mReusableIntPair;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    recyclerView4.scrollStep(i3, i4, iArr3);
                    recyclerView4 = RecyclerView.this;
                    iArr3 = recyclerView4.mReusableIntPair;
                    i = iArr3[0];
                    i2 = iArr3[1];
                    i3 -= i;
                    i4 -= i2;
                    SmoothScroller smoothScroller2 = recyclerView4.mLayout.mSmoothScroller;
                    if (smoothScroller2 != null && !smoothScroller2.mPendingInitialRun && smoothScroller2.mRunning) {
                        currX = recyclerView4.mState.getItemCount();
                        if (currX == 0) {
                            smoothScroller2.stop();
                        } else if (smoothScroller2.mTargetPosition >= currX) {
                            smoothScroller2.mTargetPosition = currX - 1;
                            smoothScroller2.onAnimation(i, i2);
                        } else {
                            smoothScroller2.onAnimation(i, i2);
                        }
                    }
                } else {
                    i2 = 0;
                    i = 0;
                }
                if (!RecyclerView.this.mItemDecorations.isEmpty()) {
                    RecyclerView.this.invalidate();
                }
                RecyclerView recyclerView5 = RecyclerView.this;
                iArr = recyclerView5.mReusableIntPair;
                iArr[0] = 0;
                iArr[1] = 0;
                recyclerView5.dispatchNestedScroll(i, i2, i3, i4, null, 1, iArr);
                recyclerView4 = RecyclerView.this;
                int[] iArr4 = recyclerView4.mReusableIntPair;
                i3 -= iArr4[0];
                i4 -= iArr4[1];
                if (i == 0) {
                    if (i2 != 0) {
                        i = 0;
                    } else {
                        i2 = 0;
                        i = 0;
                        if (!RecyclerView.this.awakenScrollBars()) {
                            RecyclerView.this.invalidate();
                        }
                        currX = overScroller.getCurrX();
                        finalX = overScroller.getFinalX();
                        currY = overScroller.getCurrY();
                        finalY = overScroller.getFinalY();
                        if (!overScroller.isFinished()) {
                            if (currX != finalX) {
                                if (i3 != 0) {
                                    obj = null;
                                    i3 = 0;
                                    recyclerView2 = RecyclerView.this;
                                    smoothScroller = recyclerView2.mLayout.mSmoothScroller;
                                    if (smoothScroller != null || !smoothScroller.mPendingInitialRun) {
                                        if (obj != null) {
                                            if (recyclerView2.getOverScrollMode() != 2) {
                                                currVelocity = (int) overScroller.getCurrVelocity();
                                                currX = i3 >= 0 ? -currVelocity : i3 <= 0 ? currVelocity : 0;
                                                if (i4 < 0) {
                                                    currVelocity = -currVelocity;
                                                } else if (i4 > 0) {
                                                    currVelocity = 0;
                                                }
                                                view = RecyclerView.this;
                                                if (currX < 0) {
                                                    view.ensureLeftGlow();
                                                    if (view.mLeftGlow.isFinished()) {
                                                        view.mLeftGlow.onAbsorb(-currX);
                                                    }
                                                } else if (currX > 0) {
                                                    view.ensureRightGlow();
                                                    if (view.mRightGlow.isFinished()) {
                                                        view.mRightGlow.onAbsorb(currX);
                                                    }
                                                }
                                                if (currVelocity < 0) {
                                                    view.ensureTopGlow();
                                                    if (view.mTopGlow.isFinished()) {
                                                        view.mTopGlow.onAbsorb(-currVelocity);
                                                    }
                                                } else if (currVelocity > 0) {
                                                    view.ensureBottomGlow();
                                                    if (view.mBottomGlow.isFinished()) {
                                                        view.mBottomGlow.onAbsorb(currVelocity);
                                                    }
                                                }
                                                if (!(currX == 0 && currVelocity == 0)) {
                                                    ViewCompat.postInvalidateOnAnimation(view);
                                                }
                                            }
                                            RecyclerView.this.mPrefetchRegistry.clearPrefetchPositions();
                                        }
                                    }
                                    postOnAnimation();
                                    recyclerView = RecyclerView.this;
                                    gapWorker = recyclerView.mGapWorker;
                                    if (gapWorker != null) {
                                        gapWorker.postFromTraversal(recyclerView, i, i2);
                                    }
                                }
                            }
                            if (currY != finalY) {
                                if (i4 == 0) {
                                    obj = 1;
                                } else {
                                    obj = null;
                                    i4 = 0;
                                }
                                recyclerView2 = RecyclerView.this;
                                smoothScroller = recyclerView2.mLayout.mSmoothScroller;
                                if (smoothScroller != null) {
                                }
                                if (obj != null) {
                                    if (recyclerView2.getOverScrollMode() != 2) {
                                        currVelocity = (int) overScroller.getCurrVelocity();
                                        if (i3 >= 0) {
                                            if (i3 <= 0) {
                                            }
                                        }
                                        if (i4 < 0) {
                                            currVelocity = -currVelocity;
                                        } else if (i4 > 0) {
                                            currVelocity = 0;
                                        }
                                        view = RecyclerView.this;
                                        if (currX < 0) {
                                            view.ensureLeftGlow();
                                            if (view.mLeftGlow.isFinished()) {
                                                view.mLeftGlow.onAbsorb(-currX);
                                            }
                                        } else if (currX > 0) {
                                            view.ensureRightGlow();
                                            if (view.mRightGlow.isFinished()) {
                                                view.mRightGlow.onAbsorb(currX);
                                            }
                                        }
                                        if (currVelocity < 0) {
                                            view.ensureTopGlow();
                                            if (view.mTopGlow.isFinished()) {
                                                view.mTopGlow.onAbsorb(-currVelocity);
                                            }
                                        } else if (currVelocity > 0) {
                                            view.ensureBottomGlow();
                                            if (view.mBottomGlow.isFinished()) {
                                                view.mBottomGlow.onAbsorb(currVelocity);
                                            }
                                        }
                                        ViewCompat.postInvalidateOnAnimation(view);
                                    }
                                    RecyclerView.this.mPrefetchRegistry.clearPrefetchPositions();
                                }
                                postOnAnimation();
                                recyclerView = RecyclerView.this;
                                gapWorker = recyclerView.mGapWorker;
                                if (gapWorker != null) {
                                    gapWorker.postFromTraversal(recyclerView, i, i2);
                                }
                            }
                        }
                        obj = 1;
                        recyclerView2 = RecyclerView.this;
                        smoothScroller = recyclerView2.mLayout.mSmoothScroller;
                        if (smoothScroller != null) {
                        }
                        if (obj != null) {
                            if (recyclerView2.getOverScrollMode() != 2) {
                                currVelocity = (int) overScroller.getCurrVelocity();
                                if (i3 >= 0) {
                                }
                                if (i4 < 0) {
                                    currVelocity = -currVelocity;
                                } else if (i4 > 0) {
                                    currVelocity = 0;
                                }
                                view = RecyclerView.this;
                                if (currX < 0) {
                                    view.ensureLeftGlow();
                                    if (view.mLeftGlow.isFinished()) {
                                        view.mLeftGlow.onAbsorb(-currX);
                                    }
                                } else if (currX > 0) {
                                    view.ensureRightGlow();
                                    if (view.mRightGlow.isFinished()) {
                                        view.mRightGlow.onAbsorb(currX);
                                    }
                                }
                                if (currVelocity < 0) {
                                    view.ensureTopGlow();
                                    if (view.mTopGlow.isFinished()) {
                                        view.mTopGlow.onAbsorb(-currVelocity);
                                    }
                                } else if (currVelocity > 0) {
                                    view.ensureBottomGlow();
                                    if (view.mBottomGlow.isFinished()) {
                                        view.mBottomGlow.onAbsorb(currVelocity);
                                    }
                                }
                                ViewCompat.postInvalidateOnAnimation(view);
                            }
                            RecyclerView.this.mPrefetchRegistry.clearPrefetchPositions();
                        }
                        postOnAnimation();
                        recyclerView = RecyclerView.this;
                        gapWorker = recyclerView.mGapWorker;
                        if (gapWorker != null) {
                            gapWorker.postFromTraversal(recyclerView, i, i2);
                        }
                    }
                }
                recyclerView4.dispatchOnScrolled(i, i2);
                if (RecyclerView.this.awakenScrollBars()) {
                    RecyclerView.this.invalidate();
                }
                currX = overScroller.getCurrX();
                finalX = overScroller.getFinalX();
                currY = overScroller.getCurrY();
                finalY = overScroller.getFinalY();
                if (overScroller.isFinished()) {
                    if (currX != finalX) {
                        if (i3 != 0) {
                            obj = null;
                            i3 = 0;
                            recyclerView2 = RecyclerView.this;
                            smoothScroller = recyclerView2.mLayout.mSmoothScroller;
                            if (smoothScroller != null) {
                            }
                            if (obj != null) {
                                if (recyclerView2.getOverScrollMode() != 2) {
                                    currVelocity = (int) overScroller.getCurrVelocity();
                                    if (i3 >= 0) {
                                        if (i3 <= 0) {
                                        }
                                    }
                                    if (i4 < 0) {
                                        currVelocity = -currVelocity;
                                    } else if (i4 > 0) {
                                        currVelocity = 0;
                                    }
                                    view = RecyclerView.this;
                                    if (currX < 0) {
                                        view.ensureLeftGlow();
                                        if (view.mLeftGlow.isFinished()) {
                                            view.mLeftGlow.onAbsorb(-currX);
                                        }
                                    } else if (currX > 0) {
                                        view.ensureRightGlow();
                                        if (view.mRightGlow.isFinished()) {
                                            view.mRightGlow.onAbsorb(currX);
                                        }
                                    }
                                    if (currVelocity < 0) {
                                        view.ensureTopGlow();
                                        if (view.mTopGlow.isFinished()) {
                                            view.mTopGlow.onAbsorb(-currVelocity);
                                        }
                                    } else if (currVelocity > 0) {
                                        view.ensureBottomGlow();
                                        if (view.mBottomGlow.isFinished()) {
                                            view.mBottomGlow.onAbsorb(currVelocity);
                                        }
                                    }
                                    ViewCompat.postInvalidateOnAnimation(view);
                                }
                                RecyclerView.this.mPrefetchRegistry.clearPrefetchPositions();
                            }
                            postOnAnimation();
                            recyclerView = RecyclerView.this;
                            gapWorker = recyclerView.mGapWorker;
                            if (gapWorker != null) {
                                gapWorker.postFromTraversal(recyclerView, i, i2);
                            }
                        }
                    }
                    if (currY != finalY) {
                        if (i4 == 0) {
                            obj = null;
                            i4 = 0;
                        } else {
                            obj = 1;
                        }
                        recyclerView2 = RecyclerView.this;
                        smoothScroller = recyclerView2.mLayout.mSmoothScroller;
                        if (smoothScroller != null) {
                        }
                        if (obj != null) {
                            if (recyclerView2.getOverScrollMode() != 2) {
                                currVelocity = (int) overScroller.getCurrVelocity();
                                if (i3 >= 0) {
                                }
                                if (i4 < 0) {
                                    currVelocity = -currVelocity;
                                } else if (i4 > 0) {
                                    currVelocity = 0;
                                }
                                view = RecyclerView.this;
                                if (currX < 0) {
                                    view.ensureLeftGlow();
                                    if (view.mLeftGlow.isFinished()) {
                                        view.mLeftGlow.onAbsorb(-currX);
                                    }
                                } else if (currX > 0) {
                                    view.ensureRightGlow();
                                    if (view.mRightGlow.isFinished()) {
                                        view.mRightGlow.onAbsorb(currX);
                                    }
                                }
                                if (currVelocity < 0) {
                                    view.ensureTopGlow();
                                    if (view.mTopGlow.isFinished()) {
                                        view.mTopGlow.onAbsorb(-currVelocity);
                                    }
                                } else if (currVelocity > 0) {
                                    view.ensureBottomGlow();
                                    if (view.mBottomGlow.isFinished()) {
                                        view.mBottomGlow.onAbsorb(currVelocity);
                                    }
                                }
                                ViewCompat.postInvalidateOnAnimation(view);
                            }
                            RecyclerView.this.mPrefetchRegistry.clearPrefetchPositions();
                        }
                        postOnAnimation();
                        recyclerView = RecyclerView.this;
                        gapWorker = recyclerView.mGapWorker;
                        if (gapWorker != null) {
                            gapWorker.postFromTraversal(recyclerView, i, i2);
                        }
                    }
                }
                obj = 1;
                recyclerView2 = RecyclerView.this;
                smoothScroller = recyclerView2.mLayout.mSmoothScroller;
                if (smoothScroller != null) {
                }
                if (obj != null) {
                    if (recyclerView2.getOverScrollMode() != 2) {
                        currVelocity = (int) overScroller.getCurrVelocity();
                        if (i3 >= 0) {
                            if (i3 <= 0) {
                            }
                        }
                        if (i4 < 0) {
                            currVelocity = -currVelocity;
                        } else if (i4 > 0) {
                            currVelocity = 0;
                        }
                        view = RecyclerView.this;
                        if (currX < 0) {
                            view.ensureLeftGlow();
                            if (view.mLeftGlow.isFinished()) {
                                view.mLeftGlow.onAbsorb(-currX);
                            }
                        } else if (currX > 0) {
                            view.ensureRightGlow();
                            if (view.mRightGlow.isFinished()) {
                                view.mRightGlow.onAbsorb(currX);
                            }
                        }
                        if (currVelocity < 0) {
                            view.ensureTopGlow();
                            if (view.mTopGlow.isFinished()) {
                                view.mTopGlow.onAbsorb(-currVelocity);
                            }
                        } else if (currVelocity > 0) {
                            view.ensureBottomGlow();
                            if (view.mBottomGlow.isFinished()) {
                                view.mBottomGlow.onAbsorb(currVelocity);
                            }
                        }
                        ViewCompat.postInvalidateOnAnimation(view);
                    }
                    RecyclerView.this.mPrefetchRegistry.clearPrefetchPositions();
                }
                postOnAnimation();
                recyclerView = RecyclerView.this;
                gapWorker = recyclerView.mGapWorker;
                if (gapWorker != null) {
                    gapWorker.postFromTraversal(recyclerView, i, i2);
                }
            }
            SmoothScroller smoothScroller3 = RecyclerView.this.mLayout.mSmoothScroller;
            if (smoothScroller3 != null && smoothScroller3.mPendingInitialRun) {
                smoothScroller3.onAnimation(0, 0);
            }
            r0.mEatRunOnAnimationRequest = false;
            if (r0.mReSchedulePostAnimationCallback) {
                internalPostOnAnimation();
                return;
            }
            RecyclerView.this.setScrollState(0);
            RecyclerView.this.stopNestedScroll(1);
        }

        public final void stop() {
            RecyclerView.this.removeCallbacks(this);
            this.mOverScroller.abortAnimation();
        }

        public final void smoothScrollBy(int i, int i2, int i3, Interpolator interpolator) {
            int min;
            if (i3 == LinearLayoutManager.INVALID_OFFSET) {
                i3 = Math.abs(i);
                int abs = Math.abs(i2);
                int width = i3 > abs ? RecyclerView.this.getWidth() : RecyclerView.this.getHeight();
                if (i3 <= abs) {
                    i3 = abs;
                }
                min = Math.min((int) (((((float) i3) / ((float) width)) + 1.0f) * 300.0f), 2000);
            } else {
                min = i3;
            }
            if (interpolator == null) {
                interpolator = RecyclerView.sQuinticInterpolator;
            }
            if (this.mInterpolator != interpolator) {
                this.mInterpolator = interpolator;
                this.mOverScroller = new OverScroller(RecyclerView.this.getContext(), interpolator);
            }
            this.mLastFlingY = 0;
            this.mLastFlingX = 0;
            RecyclerView.this.setScrollState(2);
            this.mOverScroller.startScroll(0, 0, i, i2, min);
            postOnAnimation();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.RecyclerView$ViewHolder */
    public class ViewHolder {
        private static final List FULLUPDATE_PAYLOADS = Collections.emptyList();
        public final View itemView;
        Adapter mBindingAdapter;
        int mFlags;
        boolean mInChangeScrap = false;
        private int mIsRecyclableCount = 0;
        long mItemId = -1;
        public int mItemViewType = -1;
        WeakReference mNestedRecyclerView;
        int mOldPosition = -1;
        RecyclerView mOwnerRecyclerView;
        List mPayloads = null;
        int mPendingAccessibilityState = -1;
        public int mPosition = -1;
        public int mPreLayoutPosition = -1;
        Recycler mScrapContainer = null;
        ViewHolder mShadowedHolder = null;
        ViewHolder mShadowingHolder = null;
        List mUnmodifiedPayloads = null;
        public int mWasImportantForAccessibilityBeforeHidden = 0;

        public ViewHolder(View view) {
            if (view != null) {
                this.itemView = view;
                return;
            }
            throw new IllegalArgumentException("itemView may not be null");
        }

        final void addChangePayload(Object obj) {
            if (obj == null) {
                addFlags(1024);
                return;
            }
            if ((1024 & this.mFlags) == 0) {
                if (this.mPayloads == null) {
                    List arrayList = new ArrayList();
                    this.mPayloads = arrayList;
                    this.mUnmodifiedPayloads = Collections.unmodifiableList(arrayList);
                }
                this.mPayloads.add(obj);
            }
        }

        final void addFlags(int i) {
            this.mFlags = i | this.mFlags;
        }

        final void clearOldPosition() {
            this.mOldPosition = -1;
            this.mPreLayoutPosition = -1;
        }

        final void clearPayload() {
            List list = this.mPayloads;
            if (list != null) {
                list.clear();
            }
            this.mFlags &= -1025;
        }

        final void clearReturnedFromScrapFlag() {
            this.mFlags &= -33;
        }

        final void clearTmpDetachFlag() {
            this.mFlags &= -257;
        }

        public final int getAbsoluteAdapterPosition() {
            RecyclerView recyclerView = this.mOwnerRecyclerView;
            return recyclerView == null ? -1 : recyclerView.getAdapterPositionInRecyclerView(this);
        }

        public final int getBindingAdapterPosition() {
            if (this.mBindingAdapter == null) {
                return -1;
            }
            RecyclerView recyclerView = this.mOwnerRecyclerView;
            if (recyclerView == null) {
                return -1;
            }
            Adapter adapter = recyclerView.mAdapter;
            if (adapter == null) {
                return -1;
            }
            int adapterPositionInRecyclerView = recyclerView.getAdapterPositionInRecyclerView(this);
            if (adapterPositionInRecyclerView == -1) {
                return -1;
            }
            return adapter.findRelativeAdapterPositionIn(this.mBindingAdapter, this, adapterPositionInRecyclerView);
        }

        public final int getLayoutPosition() {
            int i = this.mPreLayoutPosition;
            return i == -1 ? this.mPosition : i;
        }

        final List getUnmodifiedPayloads() {
            if ((this.mFlags & 1024) != 0) {
                return FULLUPDATE_PAYLOADS;
            }
            List list = this.mPayloads;
            if (list != null) {
                if (list.size() != 0) {
                    return this.mUnmodifiedPayloads;
                }
            }
            return FULLUPDATE_PAYLOADS;
        }

        final boolean hasAnyOfTheFlags(int i) {
            return (i & this.mFlags) != 0;
        }

        final boolean isAttachedToTransitionOverlay() {
            return (this.itemView.getParent() == null || this.itemView.getParent() == this.mOwnerRecyclerView) ? false : true;
        }

        final boolean isBound() {
            return (this.mFlags & 1) != 0;
        }

        final boolean isInvalid() {
            return (this.mFlags & 4) != 0;
        }

        public final boolean isRecyclable() {
            return (this.mFlags & 16) == 0 && !ViewCompat.hasTransientState(this.itemView);
        }

        final boolean isRemoved() {
            return (this.mFlags & 8) != 0;
        }

        final boolean isScrap() {
            return this.mScrapContainer != null;
        }

        final boolean isTmpDetached() {
            return (this.mFlags & 256) != 0;
        }

        final boolean isUpdated() {
            return (this.mFlags & 2) != 0;
        }

        final boolean needsUpdate() {
            return (this.mFlags & 2) != 0;
        }

        final void offsetPosition(int i, boolean z) {
            if (this.mOldPosition == -1) {
                this.mOldPosition = this.mPosition;
            }
            int i2 = this.mPreLayoutPosition;
            if (i2 == -1) {
                i2 = this.mPosition;
                this.mPreLayoutPosition = i2;
            }
            if (z) {
                this.mPreLayoutPosition = i2 + i;
            }
            this.mPosition += i;
            if (this.itemView.getLayoutParams() != null) {
                ((LayoutParams) this.itemView.getLayoutParams()).mInsetsDirty = true;
            }
        }

        final void resetInternal() {
            this.mFlags = 0;
            this.mPosition = -1;
            this.mOldPosition = -1;
            this.mItemId = -1;
            this.mPreLayoutPosition = -1;
            this.mIsRecyclableCount = 0;
            this.mShadowedHolder = null;
            this.mShadowingHolder = null;
            clearPayload();
            this.mWasImportantForAccessibilityBeforeHidden = 0;
            this.mPendingAccessibilityState = -1;
            RecyclerView.clearNestedRecyclerViewIfNotNested(this);
        }

        final void setFlags(int i, int i2) {
            this.mFlags = (i & i2) | (this.mFlags & (i2 ^ -1));
        }

        public final void setIsRecyclable(boolean z) {
            int i = this.mIsRecyclableCount;
            i = z ? i - 1 : i + 1;
            this.mIsRecyclableCount = i;
            if (i < 0) {
                this.mIsRecyclableCount = 0;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for ");
                stringBuilder.append(this);
                Log.e("View", stringBuilder.toString());
                return;
            }
            if (!z) {
                if (i == 1) {
                    this.mFlags |= 16;
                    return;
                }
            }
            if (z && i == 0) {
                this.mFlags &= -17;
            }
        }

        final void setScrapContainer(Recycler recycler, boolean z) {
            this.mScrapContainer = recycler;
            this.mInChangeScrap = z;
        }

        final boolean shouldIgnore() {
            return (this.mFlags & 128) != 0;
        }

        public String toString() {
            String simpleName = getClass().isAnonymousClass() ? "ViewHolder" : getClass().getSimpleName();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(simpleName);
            stringBuilder.append("{");
            stringBuilder.append(Integer.toHexString(hashCode()));
            stringBuilder.append(" position=");
            stringBuilder.append(this.mPosition);
            stringBuilder.append(" id=");
            stringBuilder.append(this.mItemId);
            stringBuilder.append(", oldPos=");
            stringBuilder.append(this.mOldPosition);
            stringBuilder.append(", pLpos:");
            stringBuilder.append(this.mPreLayoutPosition);
            StringBuilder stringBuilder2 = new StringBuilder(stringBuilder.toString());
            if (isScrap()) {
                stringBuilder2.append(" scrap ");
                if (true != this.mInChangeScrap) {
                    simpleName = "[attachedScrap]";
                } else {
                    simpleName = "[changeScrap]";
                }
                stringBuilder2.append(simpleName);
            }
            if (isInvalid()) {
                stringBuilder2.append(" invalid");
            }
            if (!isBound()) {
                stringBuilder2.append(" unbound");
            }
            if (needsUpdate()) {
                stringBuilder2.append(" update");
            }
            if (isRemoved()) {
                stringBuilder2.append(" removed");
            }
            if (shouldIgnore()) {
                stringBuilder2.append(" ignored");
            }
            if (isTmpDetached()) {
                stringBuilder2.append(" tmpDetached");
            }
            if (!isRecyclable()) {
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append(" not recyclable(");
                stringBuilder3.append(this.mIsRecyclableCount);
                stringBuilder3.append(")");
                stringBuilder2.append(stringBuilder3.toString());
            }
            if ((this.mFlags & 512) != 0 || isInvalid()) {
                stringBuilder2.append(" undefined adapter position");
            }
            if (this.itemView.getParent() == null) {
                stringBuilder2.append(" no parent");
            }
            stringBuilder2.append("}");
            return stringBuilder2.toString();
        }

        final void unScrap() {
            this.mScrapContainer.unscrapView(this);
        }

        final boolean wasReturnedFromScrap() {
            return (this.mFlags & 32) != 0;
        }
    }

    public RecyclerView(Context context) {
        this(context, null);
    }

    private final void cancelScroll() {
        resetScroll();
        setScrollState(0);
    }

    static void clearNestedRecyclerViewIfNotNested(ViewHolder viewHolder) {
        WeakReference weakReference = viewHolder.mNestedRecyclerView;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            while (view != null) {
                if (view != viewHolder.itemView) {
                    ViewParent parent = view.getParent();
                    view = parent instanceof View ? (View) parent : null;
                } else {
                    return;
                }
            }
            viewHolder.mNestedRecyclerView = null;
        }
    }

    private final void createLayoutManager$ar$ds(Context context, String str, AttributeSet attributeSet, int i) {
        StringBuilder stringBuilder;
        StringBuilder stringBuilder2;
        String str2 = ": Could not instantiate the LayoutManager: ";
        if (str != null) {
            str = str.trim();
            if (!str.isEmpty()) {
                StringBuilder stringBuilder3;
                if (str.charAt(0) == '.') {
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(context.getPackageName());
                    stringBuilder3.append(str);
                    str = stringBuilder3.toString();
                } else if (!str.contains(".")) {
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(RecyclerView.class.getPackage().getName());
                    stringBuilder3.append('.');
                    stringBuilder3.append(str);
                    str = stringBuilder3.toString();
                }
                try {
                    ClassLoader classLoader;
                    Constructor constructor;
                    Object[] objArr;
                    if (isInEditMode()) {
                        classLoader = getClass().getClassLoader();
                    } else {
                        classLoader = context.getClassLoader();
                    }
                    Class asSubclass = Class.forName(str, false, classLoader).asSubclass(LayoutManager.class);
                    try {
                        constructor = asSubclass.getConstructor(LAYOUT_MANAGER_CONSTRUCTOR_SIGNATURE);
                        objArr = new Object[]{context, attributeSet, Integer.valueOf(i), Integer.valueOf(0)};
                    } catch (Throwable e) {
                        constructor = asSubclass.getConstructor(new Class[0]);
                        objArr = null;
                    }
                    constructor.setAccessible(true);
                    setLayoutManager((LayoutManager) constructor.newInstance(objArr));
                } catch (Throwable e2) {
                    e2.initCause(e);
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(attributeSet.getPositionDescription());
                    stringBuilder.append(": Error creating LayoutManager ");
                    stringBuilder.append(str);
                    throw new IllegalStateException(stringBuilder.toString(), e2);
                } catch (Throwable e3) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(attributeSet.getPositionDescription());
                    stringBuilder2.append(": Unable to find LayoutManager ");
                    stringBuilder2.append(str);
                    throw new IllegalStateException(stringBuilder2.toString(), e3);
                } catch (Throwable e32) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(attributeSet.getPositionDescription());
                    stringBuilder.append(str2);
                    stringBuilder.append(str);
                    throw new IllegalStateException(stringBuilder.toString(), e32);
                } catch (Throwable e322) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(attributeSet.getPositionDescription());
                    stringBuilder.append(str2);
                    stringBuilder.append(str);
                    throw new IllegalStateException(stringBuilder.toString(), e322);
                } catch (Throwable e3222) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(attributeSet.getPositionDescription());
                    stringBuilder2.append(": Cannot access non-public constructor ");
                    stringBuilder2.append(str);
                    throw new IllegalStateException(stringBuilder2.toString(), e3222);
                } catch (Throwable e32222) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(attributeSet.getPositionDescription());
                    stringBuilder2.append(": Class is not a LayoutManager ");
                    stringBuilder2.append(str);
                    throw new IllegalStateException(stringBuilder2.toString(), e32222);
                }
            }
        }
    }

    private final void dispatchLayoutStep1() {
        View focusedChild;
        int childCount;
        boolean z = true;
        this.mState.assertLayoutStep(1);
        fillRemainingScrollValues(this.mState);
        this.mState.mIsMeasuring = false;
        startInterceptRequestLayout();
        this.mViewInfoStore.clear();
        onEnterLayoutOrScroll();
        processAdapterUpdatesAndSetAnimationFlags();
        ViewHolder viewHolder = null;
        if (this.mPreserveFocusAfterLayout && hasFocus() && this.mAdapter != null) {
            focusedChild = getFocusedChild();
        } else {
            focusedChild = null;
        }
        if (focusedChild != null) {
            viewHolder = findContainingViewHolder(focusedChild);
        }
        if (viewHolder == null) {
            resetFocusInfo();
        } else {
            int i;
            State state = this.mState;
            state.mFocusedItemId = this.mAdapter.mHasStableIds ? viewHolder.mItemId : -1;
            if (this.mDataSetHasChangedAfterLayout) {
                i = -1;
            } else if (viewHolder.isRemoved()) {
                i = viewHolder.mOldPosition;
            } else {
                i = viewHolder.getAbsoluteAdapterPosition();
            }
            state.mFocusedItemPosition = i;
            state = this.mState;
            View view = viewHolder.itemView;
            i = view.getId();
            while (!view.isFocused() && (view instanceof ViewGroup) && view.hasFocus()) {
                view = ((ViewGroup) view).getFocusedChild();
                if (view.getId() != -1) {
                    i = view.getId();
                }
            }
            state.mFocusedSubChildId = i;
        }
        State state2 = this.mState;
        if (!state2.mRunSimpleAnimations || !this.mItemsChanged) {
            z = false;
        }
        state2.mTrackOldChangeHolders = z;
        this.mItemsChanged = false;
        this.mItemsAddedOrRemoved = false;
        state2.mInPreLayout = state2.mRunPredictiveAnimations;
        state2.mItemCount = this.mAdapter.getItemCount();
        findMinMaxChildLayoutPositions(this.mMinMaxLayoutPositions);
        if (this.mState.mRunSimpleAnimations) {
            childCount = this.mChildHelper.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(this.mChildHelper.getChildAt(i2));
                if (!childViewHolderInt.shouldIgnore()) {
                    if (!childViewHolderInt.isInvalid() || this.mAdapter.mHasStableIds) {
                        ItemAnimator.buildAdapterChangeFlagsForAnimations$ar$ds(childViewHolderInt);
                        childViewHolderInt.getUnmodifiedPayloads();
                        this.mViewInfoStore.addToPreLayout(childViewHolderInt, ItemAnimator.recordPreLayoutInformation$ar$ds$2b04a7c7_0(childViewHolderInt));
                        if (!(!this.mState.mTrackOldChangeHolders || !childViewHolderInt.isUpdated() || childViewHolderInt.isRemoved() || childViewHolderInt.shouldIgnore() || childViewHolderInt.isInvalid())) {
                            this.mViewInfoStore.addToOldChangeHolders(getChangedHolderKey(childViewHolderInt), childViewHolderInt);
                        }
                    }
                }
            }
        }
        if (this.mState.mRunPredictiveAnimations) {
            childCount = this.mChildHelper.getUnfilteredChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                ViewHolder childViewHolderInt2 = RecyclerView.getChildViewHolderInt(this.mChildHelper.getUnfilteredChildAt(i3));
                if (!childViewHolderInt2.shouldIgnore() && childViewHolderInt2.mOldPosition == -1) {
                    childViewHolderInt2.mOldPosition = childViewHolderInt2.mPosition;
                }
            }
            State state3 = this.mState;
            z = state3.mStructureChanged;
            state3.mStructureChanged = false;
            this.mLayout.onLayoutChildren(this.mRecycler, state3);
            this.mState.mStructureChanged = z;
            for (int i4 = 0; i4 < this.mChildHelper.getChildCount(); i4++) {
                ViewHolder childViewHolderInt3 = RecyclerView.getChildViewHolderInt(this.mChildHelper.getChildAt(i4));
                if (!childViewHolderInt3.shouldIgnore()) {
                    InfoRecord infoRecord = (InfoRecord) this.mViewInfoStore.mLayoutHolderMap.get(childViewHolderInt3);
                    if (infoRecord == null || (infoRecord.flags & 4) == 0) {
                        ItemAnimator.buildAdapterChangeFlagsForAnimations$ar$ds(childViewHolderInt3);
                        boolean hasAnyOfTheFlags = childViewHolderInt3.hasAnyOfTheFlags(8192);
                        childViewHolderInt3.getUnmodifiedPayloads();
                        ItemHolderInfo recordPreLayoutInformation$ar$ds$2b04a7c7_0 = ItemAnimator.recordPreLayoutInformation$ar$ds$2b04a7c7_0(childViewHolderInt3);
                        if (hasAnyOfTheFlags) {
                            recordAnimationInfoIfBouncedHiddenView(childViewHolderInt3, recordPreLayoutInformation$ar$ds$2b04a7c7_0);
                        } else {
                            ViewInfoStore viewInfoStore = this.mViewInfoStore;
                            InfoRecord infoRecord2 = (InfoRecord) viewInfoStore.mLayoutHolderMap.get(childViewHolderInt3);
                            if (infoRecord2 == null) {
                                infoRecord2 = InfoRecord.obtain();
                                viewInfoStore.mLayoutHolderMap.put(childViewHolderInt3, infoRecord2);
                            }
                            infoRecord2.flags |= 2;
                            infoRecord2.preInfo = recordPreLayoutInformation$ar$ds$2b04a7c7_0;
                        }
                    }
                }
            }
            clearOldPositions();
        } else {
            clearOldPositions();
        }
        onExitLayoutOrScroll();
        stopInterceptRequestLayout(false);
        this.mState.mLayoutStep = 2;
    }

    private final void dispatchLayoutStep2() {
        startInterceptRequestLayout();
        onEnterLayoutOrScroll();
        this.mState.assertLayoutStep(6);
        this.mAdapterHelper.consumeUpdatesInOnePass();
        this.mState.mItemCount = this.mAdapter.getItemCount();
        this.mState.mDeletedInvisibleItemCountSincePreviousLayout = 0;
        if (this.mPendingSavedState != null && this.mAdapter.canRestoreState()) {
            Parcelable parcelable = this.mPendingSavedState.mLayoutState;
            if (parcelable != null) {
                this.mLayout.onRestoreInstanceState(parcelable);
            }
            this.mPendingSavedState = null;
        }
        State state = this.mState;
        state.mInPreLayout = false;
        this.mLayout.onLayoutChildren(this.mRecycler, state);
        state = this.mState;
        state.mStructureChanged = false;
        boolean z = state.mRunSimpleAnimations && this.mItemAnimator != null;
        state.mRunSimpleAnimations = z;
        state.mLayoutStep = 4;
        onExitLayoutOrScroll();
        stopInterceptRequestLayout(false);
    }

    private final boolean findInterceptingOnItemTouchListener(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        int size = this.mOnItemTouchListeners.size();
        for (int i = 0; i < size; i++) {
            OnItemTouchListener onItemTouchListener = (OnItemTouchListener) this.mOnItemTouchListeners.get(i);
            if (onItemTouchListener.onInterceptTouchEvent$ar$ds(motionEvent)) {
                if (action != 3) {
                    this.mInterceptingOnItemTouchListener = onItemTouchListener;
                    return true;
                }
            }
        }
        return false;
    }

    private final void findMinMaxChildLayoutPositions(int[] iArr) {
        int childCount = this.mChildHelper.getChildCount();
        if (childCount != 0) {
            int i = Integer.MAX_VALUE;
            int i2 = LinearLayoutManager.INVALID_OFFSET;
            for (int i3 = 0; i3 < childCount; i3++) {
                ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(this.mChildHelper.getChildAt(i3));
                if (!childViewHolderInt.shouldIgnore()) {
                    int layoutPosition = childViewHolderInt.getLayoutPosition();
                    if (layoutPosition < i) {
                        i = layoutPosition;
                    }
                    if (layoutPosition > i2) {
                        i2 = layoutPosition;
                    }
                }
            }
            iArr[0] = i;
            iArr[1] = i2;
            return;
        }
        iArr[0] = -1;
        iArr[1] = -1;
    }

    static RecyclerView findNestedRecyclerView(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            RecyclerView findNestedRecyclerView = RecyclerView.findNestedRecyclerView(viewGroup.getChildAt(i));
            if (findNestedRecyclerView != null) {
                return findNestedRecyclerView;
            }
        }
        return null;
    }

    static ViewHolder getChildViewHolderInt(View view) {
        return view == null ? null : ((LayoutParams) view.getLayoutParams()).mViewHolder;
    }

    static void getDecoratedBoundsWithMarginsInt(View view, Rect rect) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        Rect rect2 = layoutParams.mDecorInsets;
        rect.set((view.getLeft() - rect2.left) - layoutParams.leftMargin, (view.getTop() - rect2.top) - layoutParams.topMargin, (view.getRight() + rect2.right) + layoutParams.rightMargin, (view.getBottom() + rect2.bottom) + layoutParams.bottomMargin);
    }

    private final NestedScrollingChildHelper getScrollingChildHelper() {
        if (this.mScrollingChildHelper == null) {
            this.mScrollingChildHelper = new NestedScrollingChildHelper(this);
        }
        return this.mScrollingChildHelper;
    }

    private final void onPointerUp(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.mScrollPointerId) {
            if (actionIndex == 0) {
                actionIndex = 1;
            } else {
                actionIndex = 0;
            }
            this.mScrollPointerId = motionEvent.getPointerId(actionIndex);
            int x = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.mLastTouchX = x;
            this.mInitialTouchX = x;
            int y = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.mLastTouchY = y;
            this.mInitialTouchY = y;
        }
    }

    private final boolean predictiveItemAnimationsEnabled() {
        return this.mItemAnimator != null && this.mLayout.supportsPredictiveItemAnimations();
    }

    private final void processAdapterUpdatesAndSetAnimationFlags() {
        boolean z;
        if (this.mDataSetHasChangedAfterLayout) {
            this.mAdapterHelper.reset();
            if (this.mDispatchItemsChangedEvent) {
                this.mLayout.onItemsChanged(this);
            }
        }
        if (predictiveItemAnimationsEnabled()) {
            this.mAdapterHelper.preProcess();
        } else {
            this.mAdapterHelper.consumeUpdatesInOnePass();
        }
        boolean z2 = true;
        Object obj = !this.mItemsAddedOrRemoved ? this.mItemsChanged ? 1 : null : 1;
        State state = this.mState;
        if (this.mFirstLayoutComplete && this.mItemAnimator != null) {
            z = this.mDataSetHasChangedAfterLayout;
            if (z || obj != null || this.mLayout.mRequestedSimpleAnimations) {
                if (!z) {
                    z = true;
                } else if (this.mAdapter.mHasStableIds) {
                    z = true;
                }
                state.mRunSimpleAnimations = z;
                if (z || obj == null || this.mDataSetHasChangedAfterLayout || !predictiveItemAnimationsEnabled()) {
                    z2 = false;
                }
                state.mRunPredictiveAnimations = z2;
            }
        }
        z = false;
        state.mRunSimpleAnimations = z;
        if (z) {
        }
        z2 = false;
        state.mRunPredictiveAnimations = z2;
    }

    private final int releaseHorizontalGlow(int i, float f) {
        f /= (float) getHeight();
        float width = ((float) i) / ((float) getWidth());
        EdgeEffect edgeEffect = this.mLeftGlow;
        float f2 = 0.0f;
        if (edgeEffect == null || EdgeEffectCompat.getDistance(edgeEffect) == 0.0f) {
            edgeEffect = this.mRightGlow;
            if (edgeEffect == null || EdgeEffectCompat.getDistance(edgeEffect) == 0.0f) {
                i = Math.round(f2 * ((float) getWidth()));
                if (i != 0) {
                    invalidate();
                }
                return i;
            }
            width = EdgeEffectCompat.onPullDistance(this.mRightGlow, width, f);
            if (EdgeEffectCompat.getDistance(this.mRightGlow) == 0.0f) {
                this.mRightGlow.onRelease();
            }
        } else {
            width = -EdgeEffectCompat.onPullDistance(this.mLeftGlow, -width, 1.0f - f);
            if (EdgeEffectCompat.getDistance(this.mLeftGlow) == 0.0f) {
                this.mLeftGlow.onRelease();
            }
        }
        f2 = width;
        i = Math.round(f2 * ((float) getWidth()));
        if (i != 0) {
            invalidate();
        }
        return i;
    }

    private final int releaseVerticalGlow(int i, float f) {
        f /= (float) getWidth();
        float height = ((float) i) / ((float) getHeight());
        EdgeEffect edgeEffect = this.mTopGlow;
        float f2 = 0.0f;
        if (edgeEffect == null || EdgeEffectCompat.getDistance(edgeEffect) == 0.0f) {
            edgeEffect = this.mBottomGlow;
            if (edgeEffect == null || EdgeEffectCompat.getDistance(edgeEffect) == 0.0f) {
                i = Math.round(f2 * ((float) getHeight()));
                if (i != 0) {
                    invalidate();
                }
                return i;
            }
            height = EdgeEffectCompat.onPullDistance(this.mBottomGlow, height, 1.0f - f);
            if (EdgeEffectCompat.getDistance(this.mBottomGlow) == 0.0f) {
                this.mBottomGlow.onRelease();
            }
        } else {
            height = -EdgeEffectCompat.onPullDistance(this.mTopGlow, -height, f);
            if (EdgeEffectCompat.getDistance(this.mTopGlow) == 0.0f) {
                this.mTopGlow.onRelease();
            }
        }
        f2 = height;
        i = Math.round(f2 * ((float) getHeight()));
        if (i != 0) {
            invalidate();
        }
        return i;
    }

    private final void requestChildOnScreen(View view, View view2) {
        View view3;
        boolean z;
        if (view2 != null) {
            view3 = view2;
        } else {
            view3 = view;
        }
        this.mTempRect.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof LayoutParams) {
            LayoutParams layoutParams2 = (LayoutParams) layoutParams;
            if (!layoutParams2.mInsetsDirty) {
                Rect rect = layoutParams2.mDecorInsets;
                Rect rect2 = this.mTempRect;
                rect2.left -= rect.left;
                rect2 = this.mTempRect;
                rect2.right += rect.right;
                rect2 = this.mTempRect;
                rect2.top -= rect.top;
                rect2 = this.mTempRect;
                rect2.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.mTempRect);
            offsetRectIntoDescendantCoords(view, this.mTempRect);
        } else {
            view2 = null;
        }
        LayoutManager layoutManager = this.mLayout;
        Rect rect3 = this.mTempRect;
        boolean z2 = this.mFirstLayoutComplete ^ 1;
        if (view2 == null) {
            z = true;
        } else {
            z = false;
        }
        layoutManager.requestChildRectangleOnScreen(this, view, rect3, z2, z);
    }

    private final void resetFocusInfo() {
        State state = this.mState;
        state.mFocusedItemId = -1;
        state.mFocusedItemPosition = -1;
        state.mFocusedSubChildId = -1;
    }

    private final void resetScroll() {
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        int i = 0;
        stopNestedScroll(0);
        EdgeEffect edgeEffect = this.mLeftGlow;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            i = this.mLeftGlow.isFinished();
        }
        edgeEffect = this.mTopGlow;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            i |= this.mTopGlow.isFinished();
        }
        edgeEffect = this.mRightGlow;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            i |= this.mRightGlow.isFinished();
        }
        edgeEffect = this.mBottomGlow;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            i |= this.mBottomGlow.isFinished();
        }
        if (i != 0) {
            ViewCompat.postInvalidateOnAnimation(this);
        }
    }

    private final void stopScrollersInternal() {
        this.mViewFlinger.stop();
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            layoutManager.stopSmoothScroller();
        }
    }

    public final void addAnimatingView(ViewHolder viewHolder) {
        View view = viewHolder.itemView;
        RecyclerView parent = view.getParent();
        this.mRecycler.unscrapView(getChildViewHolder(view));
        if (viewHolder.isTmpDetached()) {
            this.mChildHelper.attachViewToParent(view, -1, view.getLayoutParams(), true);
        } else if (parent != this) {
            this.mChildHelper.addView(view, -1, true);
        } else {
            ChildHelper childHelper = this.mChildHelper;
            int indexOfChild = childHelper.mCallback$ar$class_merging$5a35e444_0.indexOfChild(view);
            if (indexOfChild >= 0) {
                childHelper.mBucket.set(indexOfChild);
                childHelper.hideViewInternal(view);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("view is not a child, cannot hide ");
            stringBuilder.append(view);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
    }

    public final void addFocusables(ArrayList arrayList, int i, int i2) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            if (layoutManager.onAddFocusables(this, arrayList, i, i2)) {
                return;
            }
        }
        super.addFocusables(arrayList, i, i2);
    }

    public final void addOnChildAttachStateChangeListener(OnChildAttachStateChangeListener onChildAttachStateChangeListener) {
        if (this.mOnChildAttachStateListeners == null) {
            this.mOnChildAttachStateListeners = new ArrayList();
        }
        this.mOnChildAttachStateListeners.add(onChildAttachStateChangeListener);
    }

    public final void addOnItemTouchListener(OnItemTouchListener onItemTouchListener) {
        this.mOnItemTouchListeners.add(onItemTouchListener);
    }

    public final void addOnScrollListener(OnScrollListener onScrollListener) {
        if (this.mScrollListeners == null) {
            this.mScrollListeners = new ArrayList();
        }
        this.mScrollListeners.add(onScrollListener);
    }

    final void assertNotInLayoutOrScroll(String str) {
        StringBuilder stringBuilder;
        if (isComputingLayout()) {
            if (str == null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot call this method while RecyclerView is computing a layout or scrolling");
                stringBuilder.append(exceptionLabel());
                throw new IllegalStateException(stringBuilder.toString());
            }
            throw new IllegalStateException(str);
        } else if (this.mDispatchScrollCounter > 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(exceptionLabel());
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(stringBuilder.toString()));
        }
    }

    protected final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && this.mLayout.checkLayoutParams((LayoutParams) layoutParams);
    }

    final void clearOldPositions() {
        int i;
        int i2;
        int unfilteredChildCount = this.mChildHelper.getUnfilteredChildCount();
        for (i = 0; i < unfilteredChildCount; i++) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(this.mChildHelper.getUnfilteredChildAt(i));
            if (!childViewHolderInt.shouldIgnore()) {
                childViewHolderInt.clearOldPosition();
            }
        }
        Recycler recycler = this.mRecycler;
        i = recycler.mCachedViews.size();
        for (i2 = 0; i2 < i; i2++) {
            ((ViewHolder) recycler.mCachedViews.get(i2)).clearOldPosition();
        }
        i = recycler.mAttachedScrap.size();
        for (i2 = 0; i2 < i; i2++) {
            ((ViewHolder) recycler.mAttachedScrap.get(i2)).clearOldPosition();
        }
        ArrayList arrayList = recycler.mChangedScrap;
        if (arrayList != null) {
            i = arrayList.size();
            for (int i3 = 0; i3 < i; i3++) {
                ((ViewHolder) recycler.mChangedScrap.get(i3)).clearOldPosition();
            }
        }
    }

    public final int computeHorizontalScrollExtent() {
        LayoutManager layoutManager = this.mLayout;
        return (layoutManager != null && layoutManager.canScrollHorizontally()) ? this.mLayout.computeHorizontalScrollExtent(this.mState) : 0;
    }

    public final int computeHorizontalScrollOffset() {
        LayoutManager layoutManager = this.mLayout;
        return (layoutManager != null && layoutManager.canScrollHorizontally()) ? this.mLayout.computeHorizontalScrollOffset(this.mState) : 0;
    }

    public final int computeHorizontalScrollRange() {
        LayoutManager layoutManager = this.mLayout;
        return (layoutManager != null && layoutManager.canScrollHorizontally()) ? this.mLayout.computeHorizontalScrollRange(this.mState) : 0;
    }

    public final int computeVerticalScrollExtent() {
        LayoutManager layoutManager = this.mLayout;
        return (layoutManager != null && layoutManager.canScrollVertically()) ? this.mLayout.computeVerticalScrollExtent(this.mState) : 0;
    }

    public final int computeVerticalScrollOffset() {
        LayoutManager layoutManager = this.mLayout;
        return (layoutManager != null && layoutManager.canScrollVertically()) ? this.mLayout.computeVerticalScrollOffset(this.mState) : 0;
    }

    public final int computeVerticalScrollRange() {
        LayoutManager layoutManager = this.mLayout;
        return (layoutManager != null && layoutManager.canScrollVertically()) ? this.mLayout.computeVerticalScrollRange(this.mState) : 0;
    }

    final void considerReleasingGlowsOnScroll(int i, int i2) {
        EdgeEffect edgeEffect = this.mLeftGlow;
        int i3 = 0;
        if (edgeEffect != null && !edgeEffect.isFinished() && i > 0) {
            this.mLeftGlow.onRelease();
            i3 = this.mLeftGlow.isFinished();
        }
        edgeEffect = this.mRightGlow;
        if (edgeEffect != null && !edgeEffect.isFinished() && i < 0) {
            this.mRightGlow.onRelease();
            i3 |= this.mRightGlow.isFinished();
        }
        EdgeEffect edgeEffect2 = this.mTopGlow;
        if (!(edgeEffect2 == null || edgeEffect2.isFinished() || i2 <= 0)) {
            this.mTopGlow.onRelease();
            i3 |= this.mTopGlow.isFinished();
        }
        edgeEffect2 = this.mBottomGlow;
        if (!(edgeEffect2 == null || edgeEffect2.isFinished() || i2 >= 0)) {
            this.mBottomGlow.onRelease();
            i3 |= this.mBottomGlow.isFinished();
        }
        if (i3 != 0) {
            ViewCompat.postInvalidateOnAnimation(this);
        }
    }

    final void defaultOnMeasure(int i, int i2) {
        setMeasuredDimension(LayoutManager.chooseSize(i, getPaddingLeft() + getPaddingRight(), ViewCompat.getMinimumWidth(this)), LayoutManager.chooseSize(i2, getPaddingTop() + getPaddingBottom(), ViewCompat.getMinimumHeight(this)));
    }

    final void dispatchChildDetached(View view) {
        ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        Adapter adapter = this.mAdapter;
        if (!(adapter == null || childViewHolderInt == null)) {
            adapter.onViewDetachedFromWindow(childViewHolderInt);
        }
        List list = this.mOnChildAttachStateListeners;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                ((OnChildAttachStateChangeListener) this.mOnChildAttachStateListeners.get(size)).onChildViewDetachedFromWindow(view);
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final void dispatchLayout() {
        /*
        r17 = this;
        r0 = r17;
        r1 = r0.mAdapter;
        r2 = "RecyclerView";
        if (r1 != 0) goto L_0x000e;
    L_0x0008:
        r1 = "No adapter attached; skipping layout";
        android.util.Log.w(r2, r1);
        return;
    L_0x000e:
        r1 = r0.mLayout;
        if (r1 != 0) goto L_0x0018;
    L_0x0012:
        r1 = "No layout manager attached; skipping layout";
        android.util.Log.e(r2, r1);
        return;
    L_0x0018:
        r1 = r0.mState;
        r3 = 0;
        r1.mIsMeasuring = r3;
        r1 = r0.mLastAutoMeasureSkippedDueToExact;
        r4 = 1;
        if (r1 == 0) goto L_0x0038;
    L_0x0022:
        r1 = r0.mLastAutoMeasureNonExactMeasuredWidth;
        r5 = r17.getWidth();
        if (r1 != r5) goto L_0x0036;
    L_0x002a:
        r1 = r0.mLastAutoMeasureNonExactMeasuredHeight;
        r5 = r17.getHeight();
        if (r1 == r5) goto L_0x0034;
    L_0x0032:
        r1 = 1;
        goto L_0x0039;
    L_0x0034:
        r1 = 0;
        goto L_0x0039;
    L_0x0036:
        r1 = 1;
        goto L_0x0039;
    L_0x0038:
        r1 = 0;
    L_0x0039:
        r0.mLastAutoMeasureNonExactMeasuredWidth = r3;
        r0.mLastAutoMeasureNonExactMeasuredHeight = r3;
        r0.mLastAutoMeasureSkippedDueToExact = r3;
        r5 = r0.mState;
        r5 = r5.mLayoutStep;
        if (r5 != r4) goto L_0x0051;
    L_0x0045:
        r17.dispatchLayoutStep1();
        r1 = r0.mLayout;
        r1.setExactMeasureSpecsFrom(r0);
        r17.dispatchLayoutStep2();
        goto L_0x008c;
    L_0x0051:
        r5 = r0.mAdapterHelper;
        r6 = r5.mPostponedList;
        r6 = r6.isEmpty();
        if (r6 != 0) goto L_0x0064;
    L_0x005b:
        r5 = r5.mPendingUpdates;
        r5 = r5.isEmpty();
        if (r5 != 0) goto L_0x0064;
    L_0x0063:
        goto L_0x0084;
    L_0x0064:
        if (r1 != 0) goto L_0x0084;
    L_0x0066:
        r1 = r0.mLayout;
        r1 = r1.getWidth();
        r5 = r17.getWidth();
        if (r1 != r5) goto L_0x0084;
    L_0x0072:
        r1 = r0.mLayout;
        r1 = r1.getHeight();
        r5 = r17.getHeight();
        if (r1 != r5) goto L_0x0084;
    L_0x007e:
        r1 = r0.mLayout;
        r1.setExactMeasureSpecsFrom(r0);
        goto L_0x008c;
    L_0x0084:
        r1 = r0.mLayout;
        r1.setExactMeasureSpecsFrom(r0);
        r17.dispatchLayoutStep2();
    L_0x008c:
        r1 = r0.mState;
        r5 = 4;
        r1.assertLayoutStep(r5);
        r17.startInterceptRequestLayout();
        r17.onEnterLayoutOrScroll();
        r1 = r0.mState;
        r1.mLayoutStep = r4;
        r1 = r1.mRunSimpleAnimations;
        r6 = -1;
        r7 = 0;
        if (r1 == 0) goto L_0x0263;
    L_0x00a2:
        r1 = r0.mChildHelper;
        r1 = r1.getChildCount();
        r1 = r1 + r6;
    L_0x00a9:
        if (r1 < 0) goto L_0x01d2;
    L_0x00ab:
        r8 = r0.mChildHelper;
        r8 = r8.getChildAt(r1);
        r8 = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(r8);
        r9 = r8.shouldIgnore();
        if (r9 == 0) goto L_0x00bd;
    L_0x00bb:
        goto L_0x01cd;
    L_0x00bd:
        r9 = r0.getChangedHolderKey(r8);
        r11 = android.support.p002v7.widget.RecyclerView.ItemAnimator.obtainHolderInfo$ar$ds();
        r11.setFrom$ar$ds(r8);
        r12 = r0.mViewInfoStore;
        r12 = r12.mOldChangedHolders;
        r12 = r12.get(r9);
        r12 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r12;
        if (r12 == 0) goto L_0x01c8;
    L_0x00d4:
        r13 = r12.shouldIgnore();
        if (r13 != 0) goto L_0x01c8;
    L_0x00da:
        r13 = r0.mViewInfoStore;
        r13 = r13.isDisappearing(r12);
        r14 = r0.mViewInfoStore;
        r14 = r14.isDisappearing(r8);
        if (r13 == 0) goto L_0x00f1;
    L_0x00e8:
        if (r12 != r8) goto L_0x00f1;
    L_0x00ea:
        r9 = r0.mViewInfoStore;
        r9.addToPostLayout(r8, r11);
        goto L_0x01cd;
    L_0x00f1:
        r15 = r0.mViewInfoStore;
        r15 = r15.popFromLayoutStep(r12, r5);
        r5 = r0.mViewInfoStore;
        r5.addToPostLayout(r8, r11);
        r5 = r0.mViewInfoStore;
        r11 = 8;
        r5 = r5.popFromLayoutStep(r8, r11);
        if (r15 != 0) goto L_0x019d;
    L_0x0106:
        r5 = r0.mChildHelper;
        r5 = r5.getChildCount();
        r11 = 0;
    L_0x010d:
        if (r11 >= r5) goto L_0x0179;
    L_0x010f:
        r13 = r0.mChildHelper;
        r13 = r13.getChildAt(r11);
        r13 = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(r13);
        if (r13 != r8) goto L_0x011c;
    L_0x011b:
        goto L_0x0176;
    L_0x011c:
        r14 = r0.getChangedHolderKey(r13);
        r16 = (r14 > r9 ? 1 : (r14 == r9 ? 0 : -1));
        if (r16 != 0) goto L_0x0176;
    L_0x0124:
        r1 = r0.mAdapter;
        r2 = " \n View Holder 2:";
        if (r1 == 0) goto L_0x0152;
    L_0x012a:
        r1 = r1.mHasStableIds;
        if (r1 == 0) goto L_0x0152;
    L_0x012e:
        r1 = new java.lang.IllegalStateException;
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r4 = "Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:";
        r3.append(r4);
        r3.append(r13);
        r3.append(r2);
        r3.append(r8);
        r2 = r17.exceptionLabel();
        r3.append(r2);
        r2 = r3.toString();
        r1.<init>(r2);
        throw r1;
    L_0x0152:
        r1 = new java.lang.IllegalStateException;
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r4 = "Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:";
        r3.append(r4);
        r3.append(r13);
        r3.append(r2);
        r3.append(r8);
        r2 = r17.exceptionLabel();
        r3.append(r2);
        r2 = r3.toString();
        r1.<init>(r2);
        throw r1;
    L_0x0176:
        r11 = r11 + 1;
        goto L_0x010d;
    L_0x0179:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r9 = "Problem while matching changed view holders with the newones. The pre-layout information for the change holder ";
        r5.append(r9);
        r5.append(r12);
        r9 = " cannot be found but it is necessary for ";
        r5.append(r9);
        r5.append(r8);
        r8 = r17.exceptionLabel();
        r5.append(r8);
        r5 = r5.toString();
        android.util.Log.e(r2, r5);
        goto L_0x01cd;
        r12.setIsRecyclable(r3);
        if (r13 == 0) goto L_0x01a6;
    L_0x01a3:
        r0.addAnimatingView(r12);
    L_0x01a6:
        if (r12 == r8) goto L_0x01bc;
    L_0x01a8:
        if (r14 == 0) goto L_0x01ad;
    L_0x01aa:
        r0.addAnimatingView(r8);
    L_0x01ad:
        r12.mShadowedHolder = r8;
        r0.addAnimatingView(r12);
        r9 = r0.mRecycler;
        r9.unscrapView(r12);
        r8.setIsRecyclable(r3);
        r8.mShadowingHolder = r12;
    L_0x01bc:
        r9 = r0.mItemAnimator;
        r5 = r9.animateChange(r12, r8, r15, r5);
        if (r5 == 0) goto L_0x01cd;
    L_0x01c4:
        r17.postAnimationRunner();
        goto L_0x01cd;
    L_0x01c8:
        r5 = r0.mViewInfoStore;
        r5.addToPostLayout(r8, r11);
    L_0x01cd:
        r1 = r1 + -1;
        r5 = 4;
        goto L_0x00a9;
    L_0x01d2:
        r1 = r0.mViewInfoStore;
        r2 = r0.mViewInfoProcessCallback$ar$class_merging;
        r5 = r1.mLayoutHolderMap;
        r5 = r5.mSize;
        r5 = r5 + r6;
    L_0x01db:
        if (r5 < 0) goto L_0x0263;
    L_0x01dd:
        r8 = r1.mLayoutHolderMap;
        r8 = r8.keyAt(r5);
        r8 = (android.support.p002v7.widget.RecyclerView.ViewHolder) r8;
        r9 = r1.mLayoutHolderMap;
        r9 = r9.removeAt(r5);
        r9 = (android.support.p002v7.widget.ViewInfoStore.InfoRecord) r9;
        r10 = r9.flags;
        r11 = r10 & 3;
        r12 = 3;
        if (r11 != r12) goto L_0x01f8;
    L_0x01f4:
        r2.unused(r8);
        goto L_0x025c;
    L_0x01f8:
        r11 = r10 & 1;
        if (r11 == 0) goto L_0x020a;
    L_0x01fc:
        r10 = r9.preInfo;
        if (r10 != 0) goto L_0x0204;
    L_0x0200:
        r2.unused(r8);
        goto L_0x025c;
    L_0x0204:
        r11 = r9.postInfo;
        r2.processDisappeared(r8, r10, r11);
        goto L_0x025c;
    L_0x020a:
        r11 = r10 & 14;
        r12 = 14;
        if (r11 != r12) goto L_0x0218;
    L_0x0210:
        r10 = r9.preInfo;
        r11 = r9.postInfo;
        r2.processAppeared(r8, r10, r11);
        goto L_0x025c;
    L_0x0218:
        r11 = r10 & 12;
        r12 = 12;
        if (r11 != r12) goto L_0x0247;
    L_0x021e:
        r10 = r9.preInfo;
        r11 = r9.postInfo;
        r8.setIsRecyclable(r3);
        r12 = r2.this$0;
        r13 = r12.mDataSetHasChangedAfterLayout;
        if (r13 == 0) goto L_0x0239;
    L_0x022b:
        r12 = r12.mItemAnimator;
        r8 = r12.animateChange(r8, r8, r10, r11);
        if (r8 == 0) goto L_0x025c;
    L_0x0233:
        r8 = r2.this$0;
        r8.postAnimationRunner();
        goto L_0x025c;
    L_0x0239:
        r12 = r12.mItemAnimator;
        r8 = r12.animatePersistence(r8, r10, r11);
        if (r8 == 0) goto L_0x025c;
    L_0x0241:
        r8 = r2.this$0;
        r8.postAnimationRunner();
        goto L_0x025c;
    L_0x0247:
        r11 = r10 & 4;
        if (r11 == 0) goto L_0x0251;
    L_0x024b:
        r10 = r9.preInfo;
        r2.processDisappeared(r8, r10, r7);
        goto L_0x025c;
    L_0x0251:
        r10 = r10 & 8;
        if (r10 == 0) goto L_0x025c;
    L_0x0255:
        r10 = r9.preInfo;
        r11 = r9.postInfo;
        r2.processAppeared(r8, r10, r11);
    L_0x025c:
        android.support.p002v7.widget.ViewInfoStore.InfoRecord.recycle(r9);
        r5 = r5 + -1;
        goto L_0x01db;
    L_0x0263:
        r1 = r0.mLayout;
        r2 = r0.mRecycler;
        r1.removeAndRecycleScrapInt(r2);
        r1 = r0.mState;
        r2 = r1.mItemCount;
        r1.mPreviousLayoutItemCount = r2;
        r0.mDataSetHasChangedAfterLayout = r3;
        r0.mDispatchItemsChangedEvent = r3;
        r1.mRunSimpleAnimations = r3;
        r1.mRunPredictiveAnimations = r3;
        r1 = r0.mLayout;
        r1.mRequestedSimpleAnimations = r3;
        r1 = r0.mRecycler;
        r1 = r1.mChangedScrap;
        if (r1 == 0) goto L_0x0285;
    L_0x0282:
        r1.clear();
    L_0x0285:
        r1 = r0.mLayout;
        r2 = r1.mPrefetchMaxObservedInInitialPrefetch;
        if (r2 == 0) goto L_0x0294;
    L_0x028b:
        r1.mPrefetchMaxCountObserved = r3;
        r1.mPrefetchMaxObservedInInitialPrefetch = r3;
        r1 = r0.mRecycler;
        r1.updateViewCacheSize();
    L_0x0294:
        r1 = r0.mLayout;
        r2 = r0.mState;
        r1.onLayoutCompleted(r2);
        r17.onExitLayoutOrScroll();
        r0.stopInterceptRequestLayout(r3);
        r1 = r0.mViewInfoStore;
        r1.clear();
        r1 = r0.mMinMaxLayoutPositions;
        r2 = r1[r3];
        r5 = r1[r4];
        r0.findMinMaxChildLayoutPositions(r1);
        r1 = r0.mMinMaxLayoutPositions;
        r8 = r1[r3];
        if (r8 != r2) goto L_0x02b9;
    L_0x02b5:
        r1 = r1[r4];
        if (r1 == r5) goto L_0x02bc;
    L_0x02b9:
        r0.dispatchOnScrolled(r3, r3);
    L_0x02bc:
        r1 = r0.mPreserveFocusAfterLayout;
        if (r1 == 0) goto L_0x03b5;
    L_0x02c0:
        r1 = r0.mAdapter;
        if (r1 == 0) goto L_0x03b5;
    L_0x02c4:
        r1 = r17.hasFocus();
        if (r1 == 0) goto L_0x03b5;
    L_0x02ca:
        r1 = r17.getDescendantFocusability();
        r2 = 393216; // 0x60000 float:5.51013E-40 double:1.942745E-318;
        if (r1 == r2) goto L_0x03b5;
    L_0x02d2:
        r1 = r17.getDescendantFocusability();
        r2 = 131072; // 0x20000 float:1.83671E-40 double:6.47582E-319;
        if (r1 != r2) goto L_0x02e0;
    L_0x02da:
        r1 = r17.isFocused();
        if (r1 != 0) goto L_0x03b5;
    L_0x02e0:
        r1 = r17.isFocused();
        if (r1 != 0) goto L_0x02f2;
    L_0x02e6:
        r1 = r17.getFocusedChild();
        r2 = r0.mChildHelper;
        r1 = r2.isHidden(r1);
        if (r1 == 0) goto L_0x03b5;
    L_0x02f2:
        r1 = r0.mState;
        r1 = r1.mFocusedItemId;
        r4 = -1;
        r8 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1));
        if (r8 == 0) goto L_0x0337;
    L_0x02fc:
        r8 = r0.mAdapter;
        r9 = r8.mHasStableIds;
        if (r9 == 0) goto L_0x0337;
    L_0x0302:
        if (r8 == 0) goto L_0x0337;
    L_0x0304:
        r8 = r0.mChildHelper;
        r8 = r8.getUnfilteredChildCount();
        r10 = r7;
        r9 = 0;
    L_0x030c:
        if (r9 >= r8) goto L_0x0338;
    L_0x030e:
        r11 = r0.mChildHelper;
        r11 = r11.getUnfilteredChildAt(r9);
        r11 = android.support.p002v7.widget.RecyclerView.getChildViewHolderInt(r11);
        if (r11 == 0) goto L_0x0334;
    L_0x031a:
        r12 = r11.isRemoved();
        if (r12 != 0) goto L_0x0334;
    L_0x0320:
        r12 = r11.mItemId;
        r14 = (r12 > r1 ? 1 : (r12 == r1 ? 0 : -1));
        if (r14 != 0) goto L_0x0334;
    L_0x0326:
        r10 = r0.mChildHelper;
        r12 = r11.itemView;
        r10 = r10.isHidden(r12);
        if (r10 == 0) goto L_0x0332;
    L_0x0330:
        r10 = r11;
        goto L_0x0334;
    L_0x0332:
        r10 = r11;
        goto L_0x0338;
    L_0x0334:
        r9 = r9 + 1;
        goto L_0x030c;
    L_0x0337:
        r10 = r7;
    L_0x0338:
        if (r10 == 0) goto L_0x0350;
    L_0x033a:
        r1 = r0.mChildHelper;
        r2 = r10.itemView;
        r1 = r1.isHidden(r2);
        if (r1 != 0) goto L_0x0350;
    L_0x0344:
        r1 = r10.itemView;
        r1 = r1.hasFocusable();
        if (r1 != 0) goto L_0x034d;
    L_0x034c:
        goto L_0x0350;
    L_0x034d:
        r7 = r10.itemView;
        goto L_0x039a;
    L_0x0350:
        r1 = r0.mChildHelper;
        r1 = r1.getChildCount();
        if (r1 <= 0) goto L_0x0399;
    L_0x0358:
        r1 = r0.mState;
        r2 = r1.mFocusedItemPosition;
        if (r2 != r6) goto L_0x035f;
    L_0x035e:
        goto L_0x0360;
    L_0x035f:
        r3 = r2;
    L_0x0360:
        r1 = r1.getItemCount();
        r2 = r3;
    L_0x0365:
        if (r2 >= r1) goto L_0x037c;
    L_0x0367:
        r8 = r0.findViewHolderForAdapterPosition(r2);
        if (r8 != 0) goto L_0x036e;
    L_0x036d:
        goto L_0x037c;
    L_0x036e:
        r9 = r8.itemView;
        r9 = r9.hasFocusable();
        if (r9 == 0) goto L_0x0379;
    L_0x0376:
        r7 = r8.itemView;
        goto L_0x039a;
    L_0x0379:
        r2 = r2 + 1;
        goto L_0x0365;
    L_0x037c:
        r1 = java.lang.Math.min(r1, r3);
        r1 = r1 + r6;
    L_0x0381:
        if (r1 < 0) goto L_0x0398;
    L_0x0383:
        r2 = r0.findViewHolderForAdapterPosition(r1);
        if (r2 != 0) goto L_0x038a;
    L_0x0389:
        goto L_0x039a;
    L_0x038a:
        r3 = r2.itemView;
        r3 = r3.hasFocusable();
        if (r3 == 0) goto L_0x0395;
    L_0x0392:
        r7 = r2.itemView;
        goto L_0x039a;
    L_0x0395:
        r1 = r1 + -1;
        goto L_0x0381;
    L_0x0398:
        goto L_0x039a;
    L_0x039a:
        if (r7 == 0) goto L_0x03b5;
    L_0x039c:
        r1 = r0.mState;
        r1 = r1.mFocusedSubChildId;
        r2 = (long) r1;
        r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1));
        if (r6 == 0) goto L_0x03b2;
    L_0x03a5:
        r1 = r7.findViewById(r1);
        if (r1 == 0) goto L_0x03b2;
    L_0x03ab:
        r2 = r1.isFocusable();
        if (r2 == 0) goto L_0x03b2;
    L_0x03b1:
        r7 = r1;
    L_0x03b2:
        r7.requestFocus();
    L_0x03b5:
        r17.resetFocusInfo();
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.dispatchLayout():void");
    }

    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        return getScrollingChildHelper().dispatchNestedFling(f, f2, z);
    }

    public final boolean dispatchNestedPreFling(float f, float f2) {
        return getScrollingChildHelper().dispatchNestedPreFling(f, f2);
    }

    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().dispatchNestedPreScroll(i, i2, iArr, iArr2, 0);
    }

    public final void dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2) {
        getScrollingChildHelper().dispatchNestedScrollInternal(i, i2, i3, i4, iArr, i5, iArr2);
    }

    final void dispatchOnScrolled(int i, int i2) {
        this.mDispatchScrollCounter++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i, scrollY - i2);
        onScrolled(i, i2);
        OnScrollListener onScrollListener = this.mScrollListener;
        if (onScrollListener != null) {
            onScrollListener.onScrolled(this, i, i2);
        }
        List list = this.mScrollListeners;
        if (list != null) {
            for (scrollX = list.size() - 1; scrollX >= 0; scrollX--) {
                ((OnScrollListener) this.mScrollListeners.get(scrollX)).onScrolled(this, i, i2);
            }
        }
        this.mDispatchScrollCounter--;
    }

    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    protected final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    protected final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    public final void draw(Canvas canvas) {
        int i;
        EdgeEffect edgeEffect;
        int i2;
        super.draw(canvas);
        int size = this.mItemDecorations.size();
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            ((ItemDecoration) this.mItemDecorations.get(i4)).onDrawOver$ar$ds(canvas, this);
        }
        EdgeEffect edgeEffect2 = this.mLeftGlow;
        if (edgeEffect2 == null || edgeEffect2.isFinished()) {
            i = 0;
        } else {
            size = canvas.save();
            if (this.mClipToPadding) {
                i = getPaddingBottom();
            } else {
                i = 0;
            }
            canvas.rotate(270.0f);
            canvas.translate((float) ((-getHeight()) + i), 0.0f);
            EdgeEffect edgeEffect3 = this.mLeftGlow;
            if (edgeEffect3 == null || !edgeEffect3.draw(canvas)) {
                i = 0;
            } else {
                i = 1;
            }
            canvas.restoreToCount(size);
        }
        edgeEffect2 = this.mTopGlow;
        if (!(edgeEffect2 == null || edgeEffect2.isFinished())) {
            size = canvas.save();
            if (this.mClipToPadding) {
                canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
            }
            edgeEffect = this.mTopGlow;
            if (edgeEffect == null || !edgeEffect.draw(canvas)) {
                i2 = 0;
            } else {
                i2 = 1;
            }
            i |= i2;
            canvas.restoreToCount(size);
        }
        edgeEffect2 = this.mRightGlow;
        if (!(edgeEffect2 == null || edgeEffect2.isFinished())) {
            int paddingTop;
            size = canvas.save();
            i2 = getWidth();
            if (this.mClipToPadding) {
                paddingTop = getPaddingTop();
            } else {
                paddingTop = 0;
            }
            canvas.rotate(90.0f);
            canvas.translate((float) paddingTop, (float) (-i2));
            edgeEffect = this.mRightGlow;
            if (edgeEffect == null || !edgeEffect.draw(canvas)) {
                i2 = 0;
            } else {
                i2 = 1;
            }
            i |= i2;
            canvas.restoreToCount(size);
        }
        edgeEffect2 = this.mBottomGlow;
        if (edgeEffect2 != null && !edgeEffect2.isFinished()) {
            size = canvas.save();
            canvas.rotate(180.0f);
            if (this.mClipToPadding) {
                canvas.translate((float) ((-getWidth()) + getPaddingRight()), (float) ((-getHeight()) + getPaddingBottom()));
            } else {
                canvas.translate((float) (-getWidth()), (float) (-getHeight()));
            }
            edgeEffect = this.mBottomGlow;
            if (edgeEffect != null && edgeEffect.draw(canvas)) {
                i3 = 1;
            }
            i |= i3;
            canvas.restoreToCount(size);
        }
        if (i == 0) {
            if (this.mItemAnimator == null || this.mItemDecorations.size() <= 0 || !this.mItemAnimator.isRunning()) {
                return;
            }
        }
        ViewCompat.postInvalidateOnAnimation(this);
    }

    public final boolean drawChild(Canvas canvas, View view, long j) {
        return super.drawChild(canvas, view, j);
    }

    final void ensureBottomGlow() {
        if (this.mBottomGlow == null) {
            EdgeEffect createEdgeEffect$ar$ds = this.mEdgeEffectFactory.createEdgeEffect$ar$ds(this);
            this.mBottomGlow = createEdgeEffect$ar$ds;
            if (this.mClipToPadding) {
                createEdgeEffect$ar$ds.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
            } else {
                createEdgeEffect$ar$ds.setSize(getMeasuredWidth(), getMeasuredHeight());
            }
        }
    }

    final void ensureLeftGlow() {
        if (this.mLeftGlow == null) {
            EdgeEffect createEdgeEffect$ar$ds = this.mEdgeEffectFactory.createEdgeEffect$ar$ds(this);
            this.mLeftGlow = createEdgeEffect$ar$ds;
            if (this.mClipToPadding) {
                createEdgeEffect$ar$ds.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
            } else {
                createEdgeEffect$ar$ds.setSize(getMeasuredHeight(), getMeasuredWidth());
            }
        }
    }

    final void ensureRightGlow() {
        if (this.mRightGlow == null) {
            EdgeEffect createEdgeEffect$ar$ds = this.mEdgeEffectFactory.createEdgeEffect$ar$ds(this);
            this.mRightGlow = createEdgeEffect$ar$ds;
            if (this.mClipToPadding) {
                createEdgeEffect$ar$ds.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
            } else {
                createEdgeEffect$ar$ds.setSize(getMeasuredHeight(), getMeasuredWidth());
            }
        }
    }

    final void ensureTopGlow() {
        if (this.mTopGlow == null) {
            EdgeEffect createEdgeEffect$ar$ds = this.mEdgeEffectFactory.createEdgeEffect$ar$ds(this);
            this.mTopGlow = createEdgeEffect$ar$ds;
            if (this.mClipToPadding) {
                createEdgeEffect$ar$ds.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
            } else {
                createEdgeEffect$ar$ds.setSize(getMeasuredWidth(), getMeasuredHeight());
            }
        }
    }

    final String exceptionLabel() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" ");
        stringBuilder.append(super.toString());
        stringBuilder.append(", adapter:");
        stringBuilder.append(this.mAdapter);
        stringBuilder.append(", layout:");
        stringBuilder.append(this.mLayout);
        stringBuilder.append(", context:");
        stringBuilder.append(getContext());
        return stringBuilder.toString();
    }

    final void fillRemainingScrollValues(State state) {
        if (this.mScrollState == 2) {
            OverScroller overScroller = this.mViewFlinger.mOverScroller;
            state.mRemainingScrollHorizontal = overScroller.getFinalX() - overScroller.getCurrX();
            state.mRemainingScrollVertical = overScroller.getFinalY() - overScroller.getCurrY();
            return;
        }
        state.mRemainingScrollHorizontal = 0;
        state.mRemainingScrollVertical = 0;
    }

    public final View findChildViewUnder(float f, float f2) {
        for (int childCount = this.mChildHelper.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = this.mChildHelper.getChildAt(childCount);
            float translationX = childAt.getTranslationX();
            float translationY = childAt.getTranslationY();
            if (f >= ((float) childAt.getLeft()) + translationX && f <= ((float) childAt.getRight()) + translationX && f2 >= ((float) childAt.getTop()) + translationY) {
                if (f2 <= ((float) childAt.getBottom()) + translationY) {
                    return childAt;
                }
            }
        }
        return null;
    }

    public final View findContainingItemView(View view) {
        RecyclerView parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        return parent == this ? view : null;
    }

    public final ViewHolder findContainingViewHolder(View view) {
        view = findContainingItemView(view);
        return view == null ? null : getChildViewHolder(view);
    }

    public final ViewHolder findViewHolderForAdapterPosition(int i) {
        ViewHolder viewHolder = null;
        if (this.mDataSetHasChangedAfterLayout) {
            return null;
        }
        int unfilteredChildCount = this.mChildHelper.getUnfilteredChildCount();
        for (int i2 = 0; i2 < unfilteredChildCount; i2++) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(this.mChildHelper.getUnfilteredChildAt(i2));
            if (!(childViewHolderInt == null || childViewHolderInt.isRemoved() || getAdapterPositionInRecyclerView(childViewHolderInt) != i)) {
                if (!this.mChildHelper.isHidden(childViewHolderInt.itemView)) {
                    return childViewHolderInt;
                }
                viewHolder = childViewHolderInt;
            }
        }
        return viewHolder;
    }

    public boolean fling(int i, int i2) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager == null) {
            Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return false;
        } else if (r0.mLayoutSuppressed) {
            return false;
        } else {
            EdgeEffect edgeEffect;
            int canScrollHorizontally = layoutManager.canScrollHorizontally();
            boolean canScrollVertically = r0.mLayout.canScrollVertically();
            int i3 = canScrollHorizontally != 0 ? Math.abs(i) < r0.mMinFlingVelocity ? 0 : i : 0;
            int i4 = canScrollVertically ? Math.abs(i2) < r0.mMinFlingVelocity ? 0 : i2 : 0;
            if (i3 == 0) {
                if (i4 == 0) {
                    return false;
                }
                i3 = 0;
            }
            if (i3 != 0) {
                edgeEffect = r0.mLeftGlow;
                if (edgeEffect == null || EdgeEffectCompat.getDistance(edgeEffect) == 0.0f) {
                    edgeEffect = r0.mRightGlow;
                    if (!(edgeEffect == null || EdgeEffectCompat.getDistance(edgeEffect) == 0.0f)) {
                        r0.mRightGlow.onAbsorb(i3);
                        i3 = 0;
                    }
                } else {
                    r0.mLeftGlow.onAbsorb(-i3);
                    i3 = 0;
                }
            }
            if (i4 != 0) {
                edgeEffect = r0.mTopGlow;
                if (edgeEffect == null || EdgeEffectCompat.getDistance(edgeEffect) == 0.0f) {
                    edgeEffect = r0.mBottomGlow;
                    if (!(edgeEffect == null || EdgeEffectCompat.getDistance(edgeEffect) == 0.0f)) {
                        r0.mBottomGlow.onAbsorb(i4);
                        i4 = 0;
                    }
                } else {
                    r0.mTopGlow.onAbsorb(-i4);
                    i4 = 0;
                }
            }
            if (i3 == 0) {
                if (i4 == 0) {
                    return false;
                }
                i3 = 0;
            }
            float f = (float) i3;
            float f2 = (float) i4;
            if (!dispatchNestedPreFling(f, f2)) {
                boolean z;
                if (canScrollHorizontally != 0) {
                    z = true;
                } else if (canScrollVertically) {
                    z = true;
                } else {
                    z = false;
                }
                dispatchNestedFling(f, f2, z);
                OnFlingListener onFlingListener = r0.mOnFlingListener;
                if (onFlingListener != null) {
                    if (onFlingListener.onFling(i3, i4)) {
                        return true;
                    }
                }
                if (z) {
                    if (canScrollVertically) {
                        canScrollHorizontally |= 2;
                    }
                    startNestedScroll$ar$ds(canScrollHorizontally, 1);
                    canScrollHorizontally = r0.mMaxFlingVelocity;
                    int max = Math.max(-canScrollHorizontally, Math.min(i3, canScrollHorizontally));
                    canScrollHorizontally = r0.mMaxFlingVelocity;
                    int max2 = Math.max(-canScrollHorizontally, Math.min(i4, canScrollHorizontally));
                    ViewFlinger viewFlinger = r0.mViewFlinger;
                    viewFlinger.this$0.setScrollState(2);
                    viewFlinger.mLastFlingY = 0;
                    viewFlinger.mLastFlingX = 0;
                    Interpolator interpolator = viewFlinger.mInterpolator;
                    Interpolator interpolator2 = sQuinticInterpolator;
                    if (interpolator != interpolator2) {
                        viewFlinger.mInterpolator = interpolator2;
                        viewFlinger.mOverScroller = new OverScroller(viewFlinger.this$0.getContext(), interpolator2);
                    }
                    viewFlinger.mOverScroller.fling(0, 0, max, max2, LinearLayoutManager.INVALID_OFFSET, Integer.MAX_VALUE, LinearLayoutManager.INVALID_OFFSET, Integer.MAX_VALUE);
                    viewFlinger.postOnAnimation();
                    return true;
                }
            }
            return false;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View focusSearch(android.view.View r9, int r10) {
        /*
        r8 = this;
        r0 = r8.mLayout;
        r0 = r0.onInterceptFocusSearch(r9, r10);
        if (r0 == 0) goto L_0x0009;
    L_0x0008:
        return r0;
    L_0x0009:
        r0 = r8.mAdapter;
        r1 = 1;
        r2 = 0;
        if (r0 == 0) goto L_0x0021;
    L_0x000f:
        r0 = r8.mLayout;
        if (r0 == 0) goto L_0x001f;
    L_0x0013:
        r0 = r8.isComputingLayout();
        if (r0 != 0) goto L_0x001f;
    L_0x0019:
        r0 = r8.mLayoutSuppressed;
        if (r0 != 0) goto L_0x001f;
    L_0x001d:
        r0 = 1;
        goto L_0x0022;
    L_0x001f:
        r0 = 0;
        goto L_0x0022;
    L_0x0021:
        r0 = 0;
    L_0x0022:
        r3 = android.view.FocusFinder.getInstance();
        r4 = 0;
        if (r0 == 0) goto L_0x0088;
    L_0x0029:
        r5 = 2;
        if (r10 == r5) goto L_0x002f;
    L_0x002c:
        if (r10 != r1) goto L_0x0088;
    L_0x002e:
        r10 = 1;
    L_0x002f:
        r0 = r8.mLayout;
        r0 = r0.canScrollVertically();
        if (r0 == 0) goto L_0x0044;
    L_0x0037:
        if (r10 != r5) goto L_0x003c;
    L_0x0039:
        r0 = 130; // 0x82 float:1.82E-43 double:6.4E-322;
        goto L_0x003e;
    L_0x003c:
        r0 = 33;
    L_0x003e:
        r0 = r3.findNextFocus(r8, r9, r0);
        if (r0 == 0) goto L_0x006a;
    L_0x0044:
        r0 = r8.mLayout;
        r0 = r0.canScrollHorizontally();
        if (r0 == 0) goto L_0x0083;
    L_0x004c:
        r0 = r8.mLayout;
        r0 = r0.getLayoutDirection();
        if (r0 != r1) goto L_0x0056;
    L_0x0054:
        r0 = 1;
        goto L_0x0057;
    L_0x0056:
        r0 = 0;
    L_0x0057:
        if (r10 != r5) goto L_0x005b;
    L_0x0059:
        r5 = 1;
        goto L_0x005c;
    L_0x005b:
        r5 = 0;
    L_0x005c:
        r0 = r0 ^ r5;
        if (r1 == r0) goto L_0x0062;
    L_0x005f:
        r0 = 17;
        goto L_0x0064;
    L_0x0062:
        r0 = 66;
    L_0x0064:
        r0 = r3.findNextFocus(r8, r9, r0);
        if (r0 != 0) goto L_0x0083;
    L_0x006a:
        r8.consumePendingUpdateOperations();
        r0 = r8.findContainingItemView(r9);
        if (r0 != 0) goto L_0x0074;
    L_0x0073:
        return r4;
    L_0x0074:
        r8.startInterceptRequestLayout();
        r0 = r8.mLayout;
        r5 = r8.mRecycler;
        r6 = r8.mState;
        r0.onFocusSearchFailed(r9, r10, r5, r6);
        r8.stopInterceptRequestLayout(r2);
    L_0x0083:
        r0 = r3.findNextFocus(r8, r9, r10);
        goto L_0x00ad;
    L_0x0088:
        r3 = r3.findNextFocus(r8, r9, r10);
        if (r3 != 0) goto L_0x00ab;
    L_0x008e:
        if (r0 == 0) goto L_0x00ab;
    L_0x0090:
        r8.consumePendingUpdateOperations();
        r0 = r8.findContainingItemView(r9);
        if (r0 != 0) goto L_0x009a;
    L_0x0099:
        return r4;
    L_0x009a:
        r8.startInterceptRequestLayout();
        r0 = r8.mLayout;
        r3 = r8.mRecycler;
        r5 = r8.mState;
        r0 = r0.onFocusSearchFailed(r9, r10, r3, r5);
        r8.stopInterceptRequestLayout(r2);
        goto L_0x00ad;
        r0 = r3;
    L_0x00ad:
        if (r0 == 0) goto L_0x00c5;
    L_0x00af:
        r3 = r0.hasFocusable();
        if (r3 != 0) goto L_0x00c5;
    L_0x00b5:
        r1 = r8.getFocusedChild();
        if (r1 != 0) goto L_0x00c0;
    L_0x00bb:
        r9 = super.focusSearch(r9, r10);
        return r9;
        r8.requestChildOnScreen(r0, r4);
        return r9;
    L_0x00c5:
        if (r0 == 0) goto L_0x01d2;
    L_0x00c7:
        if (r0 == r8) goto L_0x01d2;
    L_0x00c9:
        if (r0 != r9) goto L_0x00cd;
    L_0x00cb:
        goto L_0x01d2;
    L_0x00cd:
        r3 = r8.findContainingItemView(r0);
        if (r3 == 0) goto L_0x01d2;
    L_0x00d3:
        if (r9 != 0) goto L_0x00d7;
    L_0x00d5:
        goto L_0x01d1;
    L_0x00d7:
        r3 = r8.findContainingItemView(r9);
        if (r3 == 0) goto L_0x01d1;
    L_0x00dd:
        r3 = r8.mTempRect;
        r4 = r9.getWidth();
        r5 = r9.getHeight();
        r3.set(r2, r2, r4, r5);
        r3 = r8.mTempRect2;
        r4 = r0.getWidth();
        r5 = r0.getHeight();
        r3.set(r2, r2, r4, r5);
        r3 = r8.mTempRect;
        r8.offsetDescendantRectToMyCoords(r9, r3);
        r3 = r8.mTempRect2;
        r8.offsetDescendantRectToMyCoords(r0, r3);
        r3 = r8.mLayout;
        r3 = r3.getLayoutDirection();
        r4 = -1;
        if (r3 != r1) goto L_0x010c;
    L_0x010a:
        r3 = -1;
        goto L_0x010d;
    L_0x010c:
        r3 = 1;
    L_0x010d:
        r5 = r8.mTempRect;
        r5 = r5.left;
        r6 = r8.mTempRect2;
        r6 = r6.left;
        if (r5 < r6) goto L_0x0121;
    L_0x0117:
        r5 = r8.mTempRect;
        r5 = r5.right;
        r6 = r8.mTempRect2;
        r6 = r6.left;
        if (r5 > r6) goto L_0x012d;
    L_0x0121:
        r5 = r8.mTempRect;
        r5 = r5.right;
        r6 = r8.mTempRect2;
        r6 = r6.right;
        if (r5 >= r6) goto L_0x012d;
    L_0x012b:
        r5 = 1;
        goto L_0x014e;
    L_0x012d:
        r5 = r8.mTempRect;
        r5 = r5.right;
        r6 = r8.mTempRect2;
        r6 = r6.right;
        if (r5 > r6) goto L_0x0141;
    L_0x0137:
        r5 = r8.mTempRect;
        r5 = r5.left;
        r6 = r8.mTempRect2;
        r6 = r6.right;
        if (r5 < r6) goto L_0x014d;
    L_0x0141:
        r5 = r8.mTempRect;
        r5 = r5.left;
        r6 = r8.mTempRect2;
        r6 = r6.left;
        if (r5 <= r6) goto L_0x014d;
    L_0x014b:
        r5 = -1;
        goto L_0x014e;
    L_0x014d:
        r5 = 0;
    L_0x014e:
        r6 = r8.mTempRect;
        r6 = r6.top;
        r7 = r8.mTempRect2;
        r7 = r7.top;
        if (r6 < r7) goto L_0x0162;
    L_0x0158:
        r6 = r8.mTempRect;
        r6 = r6.bottom;
        r7 = r8.mTempRect2;
        r7 = r7.top;
        if (r6 > r7) goto L_0x016e;
    L_0x0162:
        r6 = r8.mTempRect;
        r6 = r6.bottom;
        r7 = r8.mTempRect2;
        r7 = r7.bottom;
        if (r6 >= r7) goto L_0x016e;
    L_0x016c:
        r4 = 1;
        goto L_0x018e;
    L_0x016e:
        r6 = r8.mTempRect;
        r6 = r6.bottom;
        r7 = r8.mTempRect2;
        r7 = r7.bottom;
        if (r6 > r7) goto L_0x0182;
    L_0x0178:
        r6 = r8.mTempRect;
        r6 = r6.top;
        r7 = r8.mTempRect2;
        r7 = r7.bottom;
        if (r6 < r7) goto L_0x018d;
    L_0x0182:
        r6 = r8.mTempRect;
        r6 = r6.top;
        r7 = r8.mTempRect2;
        r7 = r7.top;
        if (r6 <= r7) goto L_0x018d;
    L_0x018c:
        goto L_0x018e;
    L_0x018d:
        r4 = 0;
    L_0x018e:
        switch(r10) {
            case 1: goto L_0x01c4;
            case 2: goto L_0x01bb;
            case 17: goto L_0x01b8;
            case 33: goto L_0x01b5;
            case 66: goto L_0x01b2;
            case 130: goto L_0x01af;
            default: goto L_0x0191;
        };
    L_0x0191:
        r9 = new java.lang.IllegalArgumentException;
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = "Invalid direction: ";
        r0.append(r1);
        r0.append(r10);
        r10 = r8.exceptionLabel();
        r0.append(r10);
        r10 = r0.toString();
        r9.<init>(r10);
        throw r9;
    L_0x01af:
        if (r4 <= 0) goto L_0x01d2;
    L_0x01b1:
        goto L_0x01ba;
    L_0x01b2:
        if (r5 <= 0) goto L_0x01d2;
    L_0x01b4:
        goto L_0x01ba;
    L_0x01b5:
        if (r4 >= 0) goto L_0x01d2;
    L_0x01b7:
        goto L_0x01ba;
    L_0x01b8:
        if (r5 >= 0) goto L_0x01d2;
    L_0x01ba:
        goto L_0x01d1;
    L_0x01bb:
        if (r4 > 0) goto L_0x01ce;
    L_0x01bd:
        if (r4 != 0) goto L_0x01cd;
    L_0x01bf:
        r5 = r5 * r3;
        if (r5 <= 0) goto L_0x01d2;
    L_0x01c3:
        goto L_0x01ce;
    L_0x01c4:
        if (r4 < 0) goto L_0x01ce;
    L_0x01c6:
        if (r4 != 0) goto L_0x01cd;
    L_0x01c8:
        r5 = r5 * r3;
        if (r5 >= 0) goto L_0x01d2;
    L_0x01cc:
        goto L_0x01ce;
    L_0x01cd:
        r1 = 0;
    L_0x01ce:
        if (r1 == 0) goto L_0x01d2;
    L_0x01d0:
        goto L_0x01ba;
    L_0x01d1:
        return r0;
    L_0x01d2:
        r9 = super.focusSearch(r9, r10);
        return r9;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.focusSearch(android.view.View, int):android.view.View");
    }

    protected final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            return layoutManager.generateDefaultLayoutParams();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RecyclerView has no LayoutManager");
        stringBuilder.append(exceptionLabel());
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            return layoutManager.generateLayoutParams(getContext(), attributeSet);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RecyclerView has no LayoutManager");
        stringBuilder.append(exceptionLabel());
        throw new IllegalStateException(stringBuilder.toString());
    }

    public CharSequence getAccessibilityClassName() {
        return "android.support.v7.widget.RecyclerView";
    }

    public int getBaseline() {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            return layoutManager.getBaseline();
        }
        return super.getBaseline();
    }

    final long getChangedHolderKey(ViewHolder viewHolder) {
        return this.mAdapter.mHasStableIds ? viewHolder.mItemId : (long) viewHolder.mPosition;
    }

    public final int getChildAdapterPosition(View view) {
        ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        return childViewHolderInt != null ? childViewHolderInt.getAbsoluteAdapterPosition() : -1;
    }

    public ViewHolder getChildViewHolder(View view) {
        Object parent = view.getParent();
        if (parent != null) {
            if (parent != this) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("View ");
                stringBuilder.append(view);
                stringBuilder.append(" is not a direct child of ");
                stringBuilder.append(this);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        return RecyclerView.getChildViewHolderInt(view);
    }

    public final boolean getClipToPadding() {
        return this.mClipToPadding;
    }

    final Rect getItemDecorInsetsForChild(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (!layoutParams.mInsetsDirty) {
            return layoutParams.mDecorInsets;
        }
        if (this.mState.mInPreLayout) {
            if (layoutParams.isItemChanged() || layoutParams.mViewHolder.isInvalid()) {
                return layoutParams.mDecorInsets;
            }
        }
        Rect rect = layoutParams.mDecorInsets;
        rect.set(0, 0, 0, 0);
        int size = this.mItemDecorations.size();
        for (int i = 0; i < size; i++) {
            this.mTempRect.set(0, 0, 0, 0);
            ((ItemDecoration) this.mItemDecorations.get(i)).getItemOffsets(this.mTempRect, view, this, this.mState);
            rect.left += this.mTempRect.left;
            rect.top += this.mTempRect.top;
            rect.right += this.mTempRect.right;
            rect.bottom += this.mTempRect.bottom;
        }
        layoutParams.mInsetsDirty = false;
        return rect;
    }

    public final boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().hasNestedScrollingParent(0);
    }

    public final boolean hasPendingAdapterUpdates() {
        if (this.mFirstLayoutComplete && !this.mDataSetHasChangedAfterLayout) {
            if (!this.mAdapterHelper.hasPendingUpdates()) {
                return false;
            }
        }
        return true;
    }

    final void invalidateGlows() {
        this.mBottomGlow = null;
        this.mTopGlow = null;
        this.mRightGlow = null;
        this.mLeftGlow = null;
    }

    public final void invalidateItemDecorations() {
        if (this.mItemDecorations.size() != 0) {
            LayoutManager layoutManager = this.mLayout;
            if (layoutManager != null) {
                layoutManager.assertNotInLayoutOrScroll("Cannot invalidate item decorations during a scroll or layout");
            }
            markItemDecorInsetsDirty();
            requestLayout();
        }
    }

    final boolean isAccessibilityEnabled() {
        AccessibilityManager accessibilityManager = this.mAccessibilityManager;
        return accessibilityManager != null && accessibilityManager.isEnabled();
    }

    public final boolean isAttachedToWindow() {
        return this.mIsAttached;
    }

    public final boolean isComputingLayout() {
        return this.mLayoutOrScrollCounter > 0;
    }

    public final boolean isLayoutSuppressed() {
        return this.mLayoutSuppressed;
    }

    public final boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().mIsNestedScrollingEnabled;
    }

    final void jumpToPositionForSmoothScroller(int i) {
        if (this.mLayout != null) {
            setScrollState(2);
            this.mLayout.scrollToPosition(i);
            awakenScrollBars();
        }
    }

    final void markItemDecorInsetsDirty() {
        int i;
        int unfilteredChildCount = this.mChildHelper.getUnfilteredChildCount();
        for (i = 0; i < unfilteredChildCount; i++) {
            ((LayoutParams) this.mChildHelper.getUnfilteredChildAt(i).getLayoutParams()).mInsetsDirty = true;
        }
        Recycler recycler = this.mRecycler;
        i = recycler.mCachedViews.size();
        for (int i2 = 0; i2 < i; i2++) {
            LayoutParams layoutParams = (LayoutParams) ((ViewHolder) recycler.mCachedViews.get(i2)).itemView.getLayoutParams();
            if (layoutParams != null) {
                layoutParams.mInsetsDirty = true;
            }
        }
    }

    final void offsetPositionRecordsForRemove(int i, int i2, boolean z) {
        int i3;
        int i4 = i + i2;
        int unfilteredChildCount = this.mChildHelper.getUnfilteredChildCount();
        for (i3 = 0; i3 < unfilteredChildCount; i3++) {
            int i5;
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(this.mChildHelper.getUnfilteredChildAt(i3));
            if (!(childViewHolderInt == null || childViewHolderInt.shouldIgnore())) {
                i5 = childViewHolderInt.mPosition;
                if (i5 >= i4) {
                    childViewHolderInt.offsetPosition(-i2, z);
                    this.mState.mStructureChanged = true;
                } else if (i5 >= i) {
                    childViewHolderInt.addFlags(8);
                    childViewHolderInt.offsetPosition(-i2, z);
                    childViewHolderInt.mPosition = i - 1;
                    this.mState.mStructureChanged = true;
                }
            }
        }
        Recycler recycler = this.mRecycler;
        for (i3 = recycler.mCachedViews.size() - 1; i3 >= 0; i3--) {
            childViewHolderInt = (ViewHolder) recycler.mCachedViews.get(i3);
            if (childViewHolderInt != null) {
                i5 = childViewHolderInt.mPosition;
                if (i5 >= i4) {
                    childViewHolderInt.offsetPosition(-i2, z);
                } else if (i5 >= i) {
                    childViewHolderInt.addFlags(8);
                    recycler.recycleCachedViewAt(i3);
                }
            }
        }
        requestLayout();
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mLayoutOrScrollCounter = 0;
        boolean z = true;
        this.mIsAttached = true;
        if (!this.mFirstLayoutComplete || isLayoutRequested()) {
            z = false;
        }
        this.mFirstLayoutComplete = z;
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            layoutManager.dispatchAttachedToWindow(this);
        }
        this.mPostedAnimatorRunner = false;
        GapWorker gapWorker = (GapWorker) GapWorker.sGapWorker.get();
        this.mGapWorker = gapWorker;
        if (gapWorker == null) {
            this.mGapWorker = new GapWorker();
            Display display = ViewCompat.getDisplay(this);
            float f = 60.0f;
            if (!isInEditMode() && display != null) {
                float refreshRate = display.getRefreshRate();
                if (refreshRate >= 30.0f) {
                    f = refreshRate;
                }
            }
            this.mGapWorker.mFrameIntervalNs = (long) (1.0E9f / f);
            GapWorker.sGapWorker.set(this.mGapWorker);
        }
        this.mGapWorker.mRecyclerViews.add(this);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ItemAnimator itemAnimator = this.mItemAnimator;
        if (itemAnimator != null) {
            itemAnimator.endAnimations();
        }
        stopScroll();
        this.mIsAttached = false;
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            layoutManager.dispatchDetachedFromWindow(this, this.mRecycler);
        }
        this.mPendingAccessibilityImportanceChange.clear();
        removeCallbacks(this.mItemAnimatorRunner);
        InfoRecord.drainCache();
        GapWorker gapWorker = this.mGapWorker;
        if (gapWorker != null) {
            gapWorker.mRecyclerViews.remove(this);
            this.mGapWorker = null;
        }
    }

    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.mItemDecorations.size();
        for (int i = 0; i < size; i++) {
            ((ItemDecoration) this.mItemDecorations.get(i)).onDraw$ar$ds(canvas, this);
        }
    }

    final void onEnterLayoutOrScroll() {
        this.mLayoutOrScrollCounter++;
    }

    final void onExitLayoutOrScroll() {
        onExitLayoutOrScroll(true);
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (!(this.mLayout == null || this.mLayoutSuppressed || motionEvent.getAction() != 8)) {
            float f;
            float axisValue;
            if ((motionEvent.getSource() & 2) != 0) {
                if (this.mLayout.canScrollVertically()) {
                    f = -motionEvent.getAxisValue(9);
                } else {
                    f = 0.0f;
                }
                axisValue = this.mLayout.canScrollHorizontally() ? motionEvent.getAxisValue(10) : 0.0f;
            } else {
                if ((motionEvent.getSource() & 4194304) != 0) {
                    axisValue = motionEvent.getAxisValue(26);
                    if (this.mLayout.canScrollVertically()) {
                        f = -axisValue;
                        axisValue = 0.0f;
                    } else if (this.mLayout.canScrollHorizontally()) {
                        f = 0.0f;
                    }
                }
                f = 0.0f;
                axisValue = 0.0f;
            }
            if (!(f == 0.0f && axisValue == 0.0f)) {
                int i = (int) (axisValue * this.mScaledHorizontalScrollFactor);
                int i2 = (int) (f * this.mScaledVerticalScrollFactor);
                LayoutManager layoutManager = this.mLayout;
                if (layoutManager == null) {
                    Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                } else if (!this.mLayoutSuppressed) {
                    int i3;
                    int i4;
                    int i5;
                    int i6;
                    int i7;
                    int[] iArr = this.mReusableIntPair;
                    iArr[0] = 0;
                    iArr[1] = 0;
                    boolean canScrollHorizontally = layoutManager.canScrollHorizontally();
                    boolean canScrollVertically = this.mLayout.canScrollVertically();
                    if (canScrollHorizontally) {
                        i3 = 1;
                    } else {
                        i3 = 0;
                    }
                    if (canScrollVertically) {
                        i3 |= 2;
                    }
                    i -= releaseHorizontalGlow(i, motionEvent == null ? ((float) getHeight()) / 2.0f : motionEvent.getY());
                    i2 -= releaseVerticalGlow(i2, motionEvent == null ? ((float) getWidth()) / 2.0f : motionEvent.getX());
                    startNestedScroll$ar$ds(i3, 1);
                    if (true != canScrollHorizontally) {
                        i4 = 0;
                    } else {
                        i4 = i;
                    }
                    if (true != canScrollVertically) {
                        i5 = 0;
                    } else {
                        i5 = i2;
                    }
                    if (dispatchNestedPreScroll(i4, i5, this.mReusableIntPair, this.mScrollOffset, 1)) {
                        int[] iArr2 = this.mReusableIntPair;
                        i -= iArr2[0];
                        i2 -= iArr2[1];
                    }
                    if (true != canScrollHorizontally) {
                        i6 = 0;
                    } else {
                        i6 = i;
                    }
                    if (true != canScrollVertically) {
                        i7 = 0;
                    } else {
                        i7 = i2;
                    }
                    scrollByInternal(i6, i7, motionEvent, 1);
                    GapWorker gapWorker = this.mGapWorker;
                    if (gapWorker != null) {
                        if (i == 0) {
                            if (i2 != 0) {
                                i = 0;
                            }
                        }
                        gapWorker.postFromTraversal(this, i, i2);
                    }
                    stopNestedScroll(1);
                }
            }
        }
        return false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r10) {
        /*
        r9 = this;
        r0 = r9.mLayoutSuppressed;
        r1 = 0;
        if (r0 == 0) goto L_0x0006;
    L_0x0005:
        return r1;
    L_0x0006:
        r0 = 0;
        r9.mInterceptingOnItemTouchListener = r0;
        r0 = r9.findInterceptingOnItemTouchListener(r10);
        r2 = 1;
        if (r0 == 0) goto L_0x0014;
    L_0x0010:
        r9.cancelScroll();
        return r2;
    L_0x0014:
        r0 = r9.mLayout;
        if (r0 != 0) goto L_0x0019;
    L_0x0018:
        return r1;
    L_0x0019:
        r0 = r0.canScrollHorizontally();
        r3 = r9.mLayout;
        r3 = r3.canScrollVertically();
        r4 = r9.mVelocityTracker;
        if (r4 != 0) goto L_0x002d;
    L_0x0027:
        r4 = android.view.VelocityTracker.obtain();
        r9.mVelocityTracker = r4;
    L_0x002d:
        r4 = r9.mVelocityTracker;
        r4.addMovement(r10);
        r4 = r10.getActionMasked();
        r5 = r10.getActionIndex();
        r6 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        switch(r4) {
            case 0: goto L_0x00d3;
            case 1: goto L_0x00c9;
            case 2: goto L_0x0067;
            case 3: goto L_0x0062;
            case 4: goto L_0x003f;
            case 5: goto L_0x0046;
            case 6: goto L_0x0041;
            default: goto L_0x003f;
        };
    L_0x003f:
        goto L_0x018f;
    L_0x0041:
        r9.onPointerUp(r10);
        goto L_0x018f;
    L_0x0046:
        r0 = r10.getPointerId(r5);
        r9.mScrollPointerId = r0;
        r0 = r10.getX(r5);
        r0 = r0 + r6;
        r0 = (int) r0;
        r9.mLastTouchX = r0;
        r9.mInitialTouchX = r0;
        r10 = r10.getY(r5);
        r10 = r10 + r6;
        r10 = (int) r10;
        r9.mLastTouchY = r10;
        r9.mInitialTouchY = r10;
        goto L_0x018f;
    L_0x0062:
        r9.cancelScroll();
        goto L_0x018f;
    L_0x0067:
        r4 = r9.mScrollPointerId;
        r4 = r10.findPointerIndex(r4);
        if (r4 >= 0) goto L_0x008d;
    L_0x006f:
        r10 = new java.lang.StringBuilder;
        r10.<init>();
        r0 = "Error processing scroll; pointer index for id ";
        r10.append(r0);
        r0 = r9.mScrollPointerId;
        r10.append(r0);
        r0 = " not found. Did any MotionEvents get skipped?";
        r10.append(r0);
        r10 = r10.toString();
        r0 = "RecyclerView";
        android.util.Log.e(r0, r10);
        return r1;
    L_0x008d:
        r5 = r10.getX(r4);
        r5 = r5 + r6;
        r5 = (int) r5;
        r10 = r10.getY(r4);
        r10 = r10 + r6;
        r10 = (int) r10;
        r4 = r9.mScrollState;
        if (r4 == r2) goto L_0x018f;
    L_0x009d:
        r4 = r9.mInitialTouchX;
        r4 = r5 - r4;
        r6 = r9.mInitialTouchY;
        r6 = r10 - r6;
        if (r0 == 0) goto L_0x00b3;
    L_0x00a7:
        r0 = java.lang.Math.abs(r4);
        r4 = r9.mTouchSlop;
        if (r0 <= r4) goto L_0x00b3;
    L_0x00af:
        r9.mLastTouchX = r5;
        r0 = 1;
        goto L_0x00b4;
    L_0x00b3:
        r0 = 0;
    L_0x00b4:
        if (r3 == 0) goto L_0x00c1;
    L_0x00b6:
        r3 = java.lang.Math.abs(r6);
        r4 = r9.mTouchSlop;
        if (r3 <= r4) goto L_0x00c1;
    L_0x00be:
        r9.mLastTouchY = r10;
        goto L_0x00c3;
    L_0x00c1:
        if (r0 == 0) goto L_0x018f;
        r9.setScrollState(r2);
        goto L_0x018f;
    L_0x00c9:
        r10 = r9.mVelocityTracker;
        r10.clear();
        r9.stopNestedScroll(r1);
        goto L_0x018f;
    L_0x00d3:
        r4 = r9.mIgnoreMotionEventTillDown;
        if (r4 == 0) goto L_0x00d9;
    L_0x00d7:
        r9.mIgnoreMotionEventTillDown = r1;
    L_0x00d9:
        r4 = r10.getPointerId(r1);
        r9.mScrollPointerId = r4;
        r4 = r10.getX();
        r4 = r4 + r6;
        r4 = (int) r4;
        r9.mLastTouchX = r4;
        r9.mInitialTouchX = r4;
        r4 = r10.getY();
        r4 = r4 + r6;
        r4 = (int) r4;
        r9.mLastTouchY = r4;
        r9.mInitialTouchY = r4;
        r4 = r9.mLeftGlow;
        r5 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r6 = 0;
        if (r4 == 0) goto L_0x0115;
    L_0x00fa:
        r4 = android.support.p000v4.widget.EdgeEffectCompat.getDistance(r4);
        r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r4 == 0) goto L_0x0115;
    L_0x0102:
        r4 = r9.mLeftGlow;
        r7 = r10.getY();
        r8 = r9.getHeight();
        r8 = (float) r8;
        r7 = r7 / r8;
        r7 = r5 - r7;
        android.support.p000v4.widget.EdgeEffectCompat.onPullDistance(r4, r6, r7);
        r4 = 1;
        goto L_0x0116;
    L_0x0115:
        r4 = 0;
    L_0x0116:
        r7 = r9.mRightGlow;
        if (r7 == 0) goto L_0x0132;
    L_0x011a:
        r7 = android.support.p000v4.widget.EdgeEffectCompat.getDistance(r7);
        r7 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1));
        if (r7 == 0) goto L_0x0132;
    L_0x0122:
        r4 = r9.mRightGlow;
        r7 = r10.getY();
        r8 = r9.getHeight();
        r8 = (float) r8;
        r7 = r7 / r8;
        android.support.p000v4.widget.EdgeEffectCompat.onPullDistance(r4, r6, r7);
        r4 = 1;
    L_0x0132:
        r7 = r9.mTopGlow;
        if (r7 == 0) goto L_0x014e;
    L_0x0136:
        r7 = android.support.p000v4.widget.EdgeEffectCompat.getDistance(r7);
        r7 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1));
        if (r7 == 0) goto L_0x014e;
    L_0x013e:
        r4 = r9.mTopGlow;
        r7 = r10.getX();
        r8 = r9.getWidth();
        r8 = (float) r8;
        r7 = r7 / r8;
        android.support.p000v4.widget.EdgeEffectCompat.onPullDistance(r4, r6, r7);
        r4 = 1;
    L_0x014e:
        r7 = r9.mBottomGlow;
        if (r7 == 0) goto L_0x016b;
    L_0x0152:
        r7 = android.support.p000v4.widget.EdgeEffectCompat.getDistance(r7);
        r7 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1));
        if (r7 == 0) goto L_0x016b;
    L_0x015a:
        r4 = r9.mBottomGlow;
        r10 = r10.getX();
        r7 = r9.getWidth();
        r7 = (float) r7;
        r10 = r10 / r7;
        r5 = r5 - r10;
        android.support.p000v4.widget.EdgeEffectCompat.onPullDistance(r4, r6, r5);
        goto L_0x0172;
    L_0x016b:
        if (r4 != 0) goto L_0x0172;
    L_0x016d:
        r10 = r9.mScrollState;
        r4 = 2;
        if (r10 != r4) goto L_0x017f;
    L_0x0172:
        r10 = r9.getParent();
        r10.requestDisallowInterceptTouchEvent(r2);
        r9.setScrollState(r2);
        r9.stopNestedScroll(r2);
    L_0x017f:
        r10 = r9.mNestedOffsets;
        r10[r2] = r1;
        r10[r1] = r1;
        if (r3 == 0) goto L_0x018a;
    L_0x0187:
        r0 = r0 | 2;
        goto L_0x018b;
        r9.startNestedScroll$ar$ds(r0, r1);
    L_0x018f:
        r10 = r9.mScrollState;
        if (r10 != r2) goto L_0x0194;
    L_0x0193:
        return r2;
    L_0x0194:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    protected final void onMeasure(int i, int i2) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager == null) {
            defaultOnMeasure(i, i2);
            return;
        }
        boolean z = false;
        if (layoutManager.isAutoMeasureEnabled()) {
            int mode = MeasureSpec.getMode(i);
            int mode2 = MeasureSpec.getMode(i2);
            this.mLayout.onMeasure(this.mRecycler, this.mState, i, i2);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z = true;
            }
            this.mLastAutoMeasureSkippedDueToExact = z;
            if (!z) {
                if (this.mAdapter != null) {
                    if (this.mState.mLayoutStep == 1) {
                        dispatchLayoutStep1();
                    }
                    this.mLayout.setMeasureSpecs(i, i2);
                    this.mState.mIsMeasuring = true;
                    dispatchLayoutStep2();
                    this.mLayout.setMeasuredDimensionFromChildren(i, i2);
                    if (this.mLayout.shouldMeasureTwice()) {
                        this.mLayout.setMeasureSpecs(MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                        this.mState.mIsMeasuring = true;
                        dispatchLayoutStep2();
                        this.mLayout.setMeasuredDimensionFromChildren(i, i2);
                    }
                    this.mLastAutoMeasureNonExactMeasuredWidth = getMeasuredWidth();
                    this.mLastAutoMeasureNonExactMeasuredHeight = getMeasuredHeight();
                }
            }
        } else if (this.mHasFixedSize) {
            this.mLayout.onMeasure(this.mRecycler, this.mState, i, i2);
        } else {
            if (this.mAdapterUpdateDuringMeasure) {
                startInterceptRequestLayout();
                onEnterLayoutOrScroll();
                processAdapterUpdatesAndSetAnimationFlags();
                onExitLayoutOrScroll();
                State state = this.mState;
                if (state.mRunPredictiveAnimations) {
                    state.mInPreLayout = true;
                } else {
                    this.mAdapterHelper.consumeUpdatesInOnePass();
                    this.mState.mInPreLayout = false;
                }
                this.mAdapterUpdateDuringMeasure = false;
                stopInterceptRequestLayout(false);
            } else if (this.mState.mRunPredictiveAnimations) {
                setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
                return;
            }
            Adapter adapter = this.mAdapter;
            if (adapter != null) {
                this.mState.mItemCount = adapter.getItemCount();
            } else {
                this.mState.mItemCount = 0;
            }
            startInterceptRequestLayout();
            this.mLayout.onMeasure(this.mRecycler, this.mState, i, i2);
            stopInterceptRequestLayout(false);
            this.mState.mInPreLayout = false;
        }
    }

    protected final boolean onRequestFocusInDescendants(int i, Rect rect) {
        return isComputingLayout() ? false : super.onRequestFocusInDescendants(i, rect);
    }

    protected final void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            this.mPendingSavedState = savedState;
            super.onRestoreInstanceState(savedState.mSuperState);
            requestLayout();
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    protected final Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        SavedState savedState2 = this.mPendingSavedState;
        if (savedState2 != null) {
            savedState.mLayoutState = savedState2.mLayoutState;
        } else {
            LayoutManager layoutManager = this.mLayout;
            savedState.mLayoutState = layoutManager != null ? layoutManager.onSaveInstanceState() : null;
        }
        return savedState;
    }

    public void onScrolled(int i, int i2) {
    }

    protected final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i == i3) {
            if (i2 == i4) {
                return;
            }
        }
        invalidateGlows();
    }

    final void postAnimationRunner() {
        if (!this.mPostedAnimatorRunner && this.mIsAttached) {
            ViewCompat.postOnAnimation(this, this.mItemAnimatorRunner);
            this.mPostedAnimatorRunner = true;
        }
    }

    final void recordAnimationInfoIfBouncedHiddenView(ViewHolder viewHolder, ItemHolderInfo itemHolderInfo) {
        viewHolder.setFlags(0, 8192);
        if (this.mState.mTrackOldChangeHolders && viewHolder.isUpdated() && !viewHolder.isRemoved() && !viewHolder.shouldIgnore()) {
            this.mViewInfoStore.addToOldChangeHolders(getChangedHolderKey(viewHolder), viewHolder);
        }
        this.mViewInfoStore.addToPreLayout(viewHolder, itemHolderInfo);
    }

    final void removeAndRecycleViews() {
        ItemAnimator itemAnimator = this.mItemAnimator;
        if (itemAnimator != null) {
            itemAnimator.endAnimations();
        }
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            layoutManager.removeAndRecycleAllViews(this.mRecycler);
            this.mLayout.removeAndRecycleScrapInt(this.mRecycler);
        }
        this.mRecycler.clear();
    }

    protected final void removeDetachedView(View view, boolean z) {
        ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        if (childViewHolderInt != null) {
            if (childViewHolderInt.isTmpDetached()) {
                childViewHolderInt.clearTmpDetachFlag();
            } else if (!childViewHolderInt.shouldIgnore()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
                stringBuilder.append(childViewHolderInt);
                stringBuilder.append(exceptionLabel());
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        view.clearAnimation();
        dispatchChildDetached(view);
        super.removeDetachedView(view, z);
    }

    public final void removeItemDecoration(ItemDecoration itemDecoration) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            layoutManager.assertNotInLayoutOrScroll("Cannot remove item decoration during a scroll  or layout");
        }
        this.mItemDecorations.remove(itemDecoration);
        if (this.mItemDecorations.isEmpty()) {
            boolean z;
            if (getOverScrollMode() == 2) {
                z = true;
            } else {
                z = false;
            }
            setWillNotDraw(z);
        }
        markItemDecorInsetsDirty();
        requestLayout();
    }

    public final void removeOnItemTouchListener(OnItemTouchListener onItemTouchListener) {
        this.mOnItemTouchListeners.remove(onItemTouchListener);
        if (this.mInterceptingOnItemTouchListener == onItemTouchListener) {
            this.mInterceptingOnItemTouchListener = null;
        }
    }

    public final void removeOnScrollListener(OnScrollListener onScrollListener) {
        List list = this.mScrollListeners;
        if (list != null) {
            list.remove(onScrollListener);
        }
    }

    public final void requestChildFocus(View view, View view2) {
        if (!(this.mLayout.onRequestChildFocus(this, this.mState, view, view2) || view2 == null)) {
            requestChildOnScreen(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        return this.mLayout.requestChildRectangleOnScreen(this, view, rect, z);
    }

    public final void requestDisallowInterceptTouchEvent(boolean z) {
        int size = this.mOnItemTouchListeners.size();
        for (int i = 0; i < size; i++) {
            ((OnItemTouchListener) this.mOnItemTouchListeners.get(i)).onRequestDisallowInterceptTouchEvent(z);
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public final void requestLayout() {
        if (this.mInterceptRequestLayoutDepth != 0 || this.mLayoutSuppressed) {
            this.mLayoutWasDefered = true;
        } else {
            super.requestLayout();
        }
    }

    public final void scrollBy(int i, int i2) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.mLayoutSuppressed) {
            boolean canScrollHorizontally = layoutManager.canScrollHorizontally();
            boolean canScrollVertically = this.mLayout.canScrollVertically();
            if (!canScrollHorizontally) {
                if (canScrollVertically) {
                    canScrollVertically = true;
                } else {
                    return;
                }
            }
            if (true != canScrollHorizontally) {
                i = 0;
            }
            if (true != canScrollVertically) {
                i2 = 0;
            }
            scrollByInternal(i, i2, null, 0);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final boolean scrollByInternal(int r18, int r19, android.view.MotionEvent r20, int r21) {
        /*
        r17 = this;
        r8 = r17;
        r9 = r18;
        r10 = r19;
        r17.consumePendingUpdateOperations();
        r0 = r8.mAdapter;
        r11 = 1;
        r12 = 0;
        if (r0 == 0) goto L_0x0028;
    L_0x000f:
        r0 = r8.mReusableIntPair;
        r0[r12] = r12;
        r0[r11] = r12;
        r8.scrollStep(r9, r10, r0);
        r0 = r8.mReusableIntPair;
        r1 = r0[r12];
        r0 = r0[r11];
        r2 = r9 - r1;
        r3 = r10 - r0;
        r13 = r0;
        r14 = r1;
        r15 = r2;
        r16 = r3;
        goto L_0x002d;
    L_0x0028:
        r13 = 0;
        r14 = 0;
        r15 = 0;
        r16 = 0;
    L_0x002d:
        r0 = r8.mItemDecorations;
        r0 = r0.isEmpty();
        if (r0 != 0) goto L_0x0038;
    L_0x0035:
        r17.invalidate();
    L_0x0038:
        r7 = r8.mReusableIntPair;
        r7[r12] = r12;
        r7[r11] = r12;
        r5 = r8.mScrollOffset;
        r0 = r17;
        r1 = r14;
        r2 = r13;
        r3 = r15;
        r4 = r16;
        r6 = r21;
        r0.dispatchNestedScroll(r1, r2, r3, r4, r5, r6, r7);
        r0 = r8.mReusableIntPair;
        r1 = r0[r12];
        r15 = r15 - r1;
        r0 = r0[r11];
        r2 = r16 - r0;
        if (r1 != 0) goto L_0x005d;
    L_0x0057:
        if (r0 == 0) goto L_0x005b;
    L_0x0059:
        r0 = 1;
        goto L_0x005e;
    L_0x005b:
        r0 = 0;
        goto L_0x005e;
    L_0x005d:
        r0 = 1;
    L_0x005e:
        r1 = r8.mLastTouchX;
        r3 = r8.mScrollOffset;
        r4 = r3[r12];
        r1 = r1 - r4;
        r8.mLastTouchX = r1;
        r1 = r8.mLastTouchY;
        r5 = r3[r11];
        r1 = r1 - r5;
        r8.mLastTouchY = r1;
        r1 = r8.mNestedOffsets;
        r5 = r1[r12];
        r5 = r5 + r4;
        r1[r12] = r5;
        r4 = r1[r11];
        r3 = r3[r11];
        r4 = r4 + r3;
        r1[r11] = r4;
        r1 = r17.getOverScrollMode();
        r3 = 2;
        if (r1 == r3) goto L_0x011a;
    L_0x0083:
        if (r20 == 0) goto L_0x0117;
    L_0x0085:
        r1 = r20.getSource();
        r3 = 8194; // 0x2002 float:1.1482E-41 double:4.0484E-320;
        r1 = r1 & r3;
        if (r1 != r3) goto L_0x0090;
    L_0x008e:
        goto L_0x0117;
    L_0x0090:
        r1 = r20.getX();
        r3 = (float) r15;
        r4 = r20.getY();
        r2 = (float) r2;
        r5 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r6 = 0;
        r7 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
        if (r7 >= 0) goto L_0x00ba;
    L_0x00a1:
        r17.ensureLeftGlow();
        r7 = r8.mLeftGlow;
        r15 = -r3;
        r11 = r17.getWidth();
        r11 = (float) r11;
        r15 = r15 / r11;
        r11 = r17.getHeight();
        r11 = (float) r11;
        r4 = r4 / r11;
        r4 = r5 - r4;
        android.support.p000v4.widget.EdgeEffectCompat.onPullDistance(r7, r15, r4);
        r4 = 1;
        goto L_0x00d6;
    L_0x00ba:
        r7 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
        if (r7 <= 0) goto L_0x00d5;
    L_0x00be:
        r17.ensureRightGlow();
        r7 = r8.mRightGlow;
        r11 = r17.getWidth();
        r11 = (float) r11;
        r11 = r3 / r11;
        r15 = r17.getHeight();
        r15 = (float) r15;
        r4 = r4 / r15;
        android.support.p000v4.widget.EdgeEffectCompat.onPullDistance(r7, r11, r4);
        r4 = 1;
        goto L_0x00d6;
    L_0x00d5:
        r4 = 0;
    L_0x00d6:
        r7 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1));
        if (r7 >= 0) goto L_0x00f0;
    L_0x00da:
        r17.ensureTopGlow();
        r3 = r8.mTopGlow;
        r2 = -r2;
        r4 = r17.getHeight();
        r4 = (float) r4;
        r2 = r2 / r4;
        r4 = r17.getWidth();
        r4 = (float) r4;
        r1 = r1 / r4;
        android.support.p000v4.widget.EdgeEffectCompat.onPullDistance(r3, r2, r1);
        goto L_0x0114;
    L_0x00f0:
        r7 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1));
        if (r7 <= 0) goto L_0x010a;
    L_0x00f4:
        r17.ensureBottomGlow();
        r3 = r8.mBottomGlow;
        r4 = r17.getHeight();
        r4 = (float) r4;
        r2 = r2 / r4;
        r4 = r17.getWidth();
        r4 = (float) r4;
        r1 = r1 / r4;
        r5 = r5 - r1;
        android.support.p000v4.widget.EdgeEffectCompat.onPullDistance(r3, r2, r5);
        goto L_0x0114;
    L_0x010a:
        if (r4 != 0) goto L_0x0114;
    L_0x010c:
        r1 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1));
        if (r1 != 0) goto L_0x0114;
    L_0x0110:
        r1 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1));
        if (r1 == 0) goto L_0x0117;
    L_0x0114:
        android.support.p000v4.view.ViewCompat.postInvalidateOnAnimation(r17);
    L_0x0117:
        r17.considerReleasingGlowsOnScroll(r18, r19);
    L_0x011a:
        if (r14 != 0) goto L_0x0123;
    L_0x011c:
        if (r13 == 0) goto L_0x0120;
    L_0x011e:
        r14 = 0;
        goto L_0x0124;
    L_0x0120:
        r13 = 0;
        r14 = 0;
        goto L_0x0127;
    L_0x0124:
        r8.dispatchOnScrolled(r14, r13);
    L_0x0127:
        r1 = r17.awakenScrollBars();
        if (r1 != 0) goto L_0x0130;
    L_0x012d:
        r17.invalidate();
    L_0x0130:
        if (r0 != 0) goto L_0x0138;
    L_0x0132:
        if (r14 != 0) goto L_0x0138;
    L_0x0134:
        if (r13 == 0) goto L_0x0137;
    L_0x0136:
        goto L_0x0138;
    L_0x0137:
        return r12;
    L_0x0138:
        r0 = 1;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.scrollByInternal(int, int, android.view.MotionEvent, int):boolean");
    }

    final void scrollStep(int i, int i2, int[] iArr) {
        startInterceptRequestLayout();
        onEnterLayoutOrScroll();
        Trace.beginSection("RV Scroll");
        fillRemainingScrollValues(this.mState);
        if (i != 0) {
            i = this.mLayout.scrollHorizontallyBy(i, this.mRecycler, this.mState);
        } else {
            i = 0;
        }
        if (i2 != 0) {
            i2 = this.mLayout.scrollVerticallyBy(i2, this.mRecycler, this.mState);
        } else {
            i2 = 0;
        }
        Trace.endSection();
        int childCount = this.mChildHelper.getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = this.mChildHelper.getChildAt(i3);
            ViewHolder childViewHolder = getChildViewHolder(childAt);
            if (childViewHolder != null) {
                childViewHolder = childViewHolder.mShadowingHolder;
                if (childViewHolder != null) {
                    View view = childViewHolder.itemView;
                    int left = childAt.getLeft();
                    int top = childAt.getTop();
                    if (left != view.getLeft() || top != view.getTop()) {
                        view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                    }
                }
            }
        }
        onExitLayoutOrScroll();
        stopInterceptRequestLayout(false);
        if (iArr != null) {
            iArr[0] = i;
            iArr[1] = i2;
        }
    }

    public final void scrollTo(int i, int i2) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    public final void scrollToPosition(int i) {
        if (!this.mLayoutSuppressed) {
            stopScroll();
            LayoutManager layoutManager = this.mLayout;
            if (layoutManager == null) {
                Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
                return;
            }
            layoutManager.scrollToPosition(i);
            awakenScrollBars();
        }
    }

    final void setChildImportantForAccessibilityInternal$ar$ds(ViewHolder viewHolder, int i) {
        if (isComputingLayout()) {
            viewHolder.mPendingAccessibilityState = i;
            this.mPendingAccessibilityImportanceChange.add(viewHolder);
            return;
        }
        ViewCompat.setImportantForAccessibility(viewHolder.itemView, i);
    }

    public final void setClipToPadding(boolean z) {
        if (z != this.mClipToPadding) {
            invalidateGlows();
        }
        this.mClipToPadding = z;
        super.setClipToPadding(z);
        if (this.mFirstLayoutComplete) {
            requestLayout();
        }
    }

    public final void setHasFixedSize$ar$ds() {
        this.mHasFixedSize = true;
    }

    public final void setItemAnimator(ItemAnimator itemAnimator) {
        ItemAnimator itemAnimator2 = this.mItemAnimator;
        if (itemAnimator2 != null) {
            itemAnimator2.endAnimations();
            this.mItemAnimator.mListener$ar$class_merging$4809de85_0 = null;
        }
        this.mItemAnimator = itemAnimator;
        if (itemAnimator != null) {
            itemAnimator.mListener$ar$class_merging$4809de85_0 = this.mItemAnimatorListener$ar$class_merging;
        }
    }

    public final void setLayoutManager(LayoutManager layoutManager) {
        if (layoutManager != this.mLayout) {
            int size;
            stopScroll();
            if (this.mLayout != null) {
                ItemAnimator itemAnimator = this.mItemAnimator;
                if (itemAnimator != null) {
                    itemAnimator.endAnimations();
                }
                this.mLayout.removeAndRecycleAllViews(this.mRecycler);
                this.mLayout.removeAndRecycleScrapInt(this.mRecycler);
                this.mRecycler.clear();
                if (this.mIsAttached) {
                    this.mLayout.dispatchDetachedFromWindow(this, this.mRecycler);
                }
                this.mLayout.setRecyclerView(null);
                this.mLayout = null;
            } else {
                this.mRecycler.clear();
            }
            ChildHelper childHelper = this.mChildHelper;
            childHelper.mBucket.reset();
            for (size = childHelper.mHiddenViews.size() - 1; size >= 0; size--) {
                childHelper.mCallback$ar$class_merging$5a35e444_0.onLeftHiddenState((View) childHelper.mHiddenViews.get(size));
                childHelper.mHiddenViews.remove(size);
            }
            C01085 c01085 = childHelper.mCallback$ar$class_merging$5a35e444_0;
            size = c01085.getChildCount();
            for (int i = 0; i < size; i++) {
                View childAt = c01085.getChildAt(i);
                c01085.this$0.dispatchChildDetached(childAt);
                childAt.clearAnimation();
            }
            c01085.this$0.removeAllViews();
            this.mLayout = layoutManager;
            if (layoutManager != null) {
                if (layoutManager.mRecyclerView == null) {
                    this.mLayout.setRecyclerView(this);
                    if (this.mIsAttached) {
                        this.mLayout.dispatchAttachedToWindow(this);
                    }
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("LayoutManager ");
                    stringBuilder.append(layoutManager);
                    stringBuilder.append(" is already attached to a RecyclerView:");
                    stringBuilder.append(layoutManager.mRecyclerView.exceptionLabel());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
            }
            this.mRecycler.updateViewCacheSize();
            requestLayout();
        }
    }

    public final void setNestedScrollingEnabled(boolean z) {
        getScrollingChildHelper().setNestedScrollingEnabled(z);
    }

    final void setScrollState(int i) {
        if (i != this.mScrollState) {
            this.mScrollState = i;
            if (i != 2) {
                stopScrollersInternal();
            }
            LayoutManager layoutManager = this.mLayout;
            if (layoutManager != null) {
                layoutManager.onScrollStateChanged(i);
            }
            OnScrollListener onScrollListener = this.mScrollListener;
            if (onScrollListener != null) {
                onScrollListener.onScrollStateChanged(this, i);
            }
            List list = this.mScrollListeners;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    ((OnScrollListener) this.mScrollListeners.get(size)).onScrollStateChanged(this, i);
                }
            }
        }
    }

    final void smoothScrollBy$ar$ds$a5e2b4f9_0(int i, int i2, boolean z) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.mLayoutSuppressed) {
            int i3 = 0;
            if (true != layoutManager.canScrollHorizontally()) {
                i = 0;
            }
            if (true != this.mLayout.canScrollVertically()) {
                i2 = 0;
            }
            if (i == 0) {
                if (i2 != 0) {
                    i = 0;
                } else {
                    return;
                }
            }
            if (z) {
                if (i != 0) {
                    i3 = 1;
                }
                if (i2 != 0) {
                    i3 |= 2;
                }
                startNestedScroll$ar$ds(i3, 1);
            }
            this.mViewFlinger.smoothScrollBy(i, i2, LinearLayoutManager.INVALID_OFFSET, null);
        }
    }

    public final void smoothScrollToPosition(int i) {
        if (!this.mLayoutSuppressed) {
            LayoutManager layoutManager = this.mLayout;
            if (layoutManager == null) {
                Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            } else {
                layoutManager.smoothScrollToPosition(this, this.mState, i);
            }
        }
    }

    final void startInterceptRequestLayout() {
        int i = this.mInterceptRequestLayoutDepth + 1;
        this.mInterceptRequestLayoutDepth = i;
        if (i == 1 && !this.mLayoutSuppressed) {
            this.mLayoutWasDefered = false;
        }
    }

    public final boolean startNestedScroll(int i) {
        return getScrollingChildHelper().startNestedScroll(i, 0);
    }

    public final void startNestedScroll$ar$ds(int i, int i2) {
        getScrollingChildHelper().startNestedScroll(i, i2);
    }

    final void stopInterceptRequestLayout(boolean z) {
        int i = this.mInterceptRequestLayoutDepth;
        if (i <= 0) {
            this.mInterceptRequestLayoutDepth = 1;
            i = 1;
        }
        if (!(z || this.mLayoutSuppressed)) {
            this.mLayoutWasDefered = false;
        }
        if (i == 1) {
            if (!(!z || !this.mLayoutWasDefered || this.mLayoutSuppressed || this.mLayout == null || this.mAdapter == null)) {
                dispatchLayout();
            }
            if (!this.mLayoutSuppressed) {
                this.mLayoutWasDefered = false;
            }
        }
        this.mInterceptRequestLayoutDepth--;
    }

    public final void stopNestedScroll() {
        getScrollingChildHelper().stopNestedScroll(0);
    }

    public final void stopScroll() {
        setScrollState(0);
        stopScrollersInternal();
    }

    public final void suppressLayout(boolean z) {
        if (z != this.mLayoutSuppressed) {
            assertNotInLayoutOrScroll("Do not suppressLayout in layout or scroll");
            if (z) {
                long uptimeMillis = SystemClock.uptimeMillis();
                onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
                this.mLayoutSuppressed = true;
                this.mIgnoreMotionEventTillDown = true;
                stopScroll();
            } else {
                this.mLayoutSuppressed = false;
                if (!(!this.mLayoutWasDefered || this.mLayout == null || this.mAdapter == null)) {
                    requestLayout();
                }
                this.mLayoutWasDefered = false;
            }
        }
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.recyclerViewStyle);
    }

    public final void addItemDecoration(ItemDecoration itemDecoration) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            layoutManager.assertNotInLayoutOrScroll("Cannot add item decoration during a scroll  or layout");
        }
        if (this.mItemDecorations.isEmpty()) {
            setWillNotDraw(false);
        }
        this.mItemDecorations.add(itemDecoration);
        markItemDecorInsetsDirty();
        requestLayout();
    }

    final void consumePendingUpdateOperations() {
        String str = "RV FullInvalidate";
        if (this.mFirstLayoutComplete) {
            if (!this.mDataSetHasChangedAfterLayout) {
                if (!this.mAdapterHelper.hasPendingUpdates()) {
                    return;
                }
                if (!this.mAdapterHelper.hasAnyUpdateTypes(4) || this.mAdapterHelper.hasAnyUpdateTypes(11)) {
                    if (this.mAdapterHelper.hasPendingUpdates()) {
                        Trace.beginSection(str);
                        dispatchLayout();
                        Trace.endSection();
                    }
                    return;
                }
                Trace.beginSection("RV PartialInvalidate");
                startInterceptRequestLayout();
                onEnterLayoutOrScroll();
                this.mAdapterHelper.preProcess();
                if (!this.mLayoutWasDefered) {
                    int childCount = this.mChildHelper.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(this.mChildHelper.getChildAt(i));
                        if (childViewHolderInt != null) {
                            if (!childViewHolderInt.shouldIgnore()) {
                                if (childViewHolderInt.isUpdated()) {
                                    dispatchLayout();
                                    break;
                                }
                            }
                        }
                    }
                    this.mAdapterHelper.consumePostponedUpdates();
                }
                stopInterceptRequestLayout(true);
                onExitLayoutOrScroll();
                Trace.endSection();
                return;
            }
        }
        Trace.beginSection(str);
        dispatchLayout();
        Trace.endSection();
    }

    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return getScrollingChildHelper().dispatchNestedPreScroll(i, i2, iArr, iArr2, i3);
    }

    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return getScrollingChildHelper().dispatchNestedScroll(i, i2, i3, i4, iArr);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final int getAdapterPositionInRecyclerView(android.support.p002v7.widget.RecyclerView.ViewHolder r7) {
        /*
        r6 = this;
        r0 = 524; // 0x20c float:7.34E-43 double:2.59E-321;
        r0 = r7.hasAnyOfTheFlags(r0);
        r1 = -1;
        if (r0 != 0) goto L_0x0055;
    L_0x0009:
        r0 = r7.isBound();
        if (r0 != 0) goto L_0x0010;
    L_0x000f:
        goto L_0x0055;
    L_0x0010:
        r0 = r6.mAdapterHelper;
        r7 = r7.mPosition;
        r2 = r0.mPendingUpdates;
        r2 = r2.size();
        r3 = 0;
    L_0x001b:
        if (r3 >= r2) goto L_0x0053;
    L_0x001d:
        r4 = r0.mPendingUpdates;
        r4 = r4.get(r3);
        r4 = (android.support.p002v7.widget.AdapterHelper.UpdateOp) r4;
        r5 = r4.cmd;
        switch(r5) {
            case 1: goto L_0x0049;
            case 2: goto L_0x003d;
            case 8: goto L_0x002b;
            default: goto L_0x002a;
        };
    L_0x002a:
        goto L_0x0050;
    L_0x002b:
        r5 = r4.positionStart;
        if (r5 != r7) goto L_0x0032;
    L_0x002f:
        r7 = r4.itemCount;
        goto L_0x0050;
    L_0x0032:
        if (r5 >= r7) goto L_0x0036;
    L_0x0034:
        r7 = r7 + -1;
    L_0x0036:
        r4 = r4.itemCount;
        if (r4 > r7) goto L_0x0050;
    L_0x003a:
        r7 = r7 + 1;
        goto L_0x0050;
    L_0x003d:
        r5 = r4.positionStart;
        if (r5 > r7) goto L_0x0050;
    L_0x0041:
        r4 = r4.itemCount;
        r5 = r5 + r4;
        if (r5 <= r7) goto L_0x0047;
    L_0x0046:
        goto L_0x0054;
    L_0x0047:
        r7 = r7 - r4;
        goto L_0x0050;
    L_0x0049:
        r5 = r4.positionStart;
        if (r5 > r7) goto L_0x0050;
    L_0x004d:
        r4 = r4.itemCount;
        r7 = r7 + r4;
    L_0x0050:
        r3 = r3 + 1;
        goto L_0x001b;
    L_0x0053:
        r1 = r7;
    L_0x0054:
        return r1;
    L_0x0055:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.getAdapterPositionInRecyclerView(android.support.v7.widget.RecyclerView$ViewHolder):int");
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Trace.beginSection("RV OnLayout");
        dispatchLayout();
        Trace.endSection();
        this.mFirstLayoutComplete = true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        int i = 0;
        if (!this.mLayoutSuppressed) {
            if (!r6.mIgnoreMotionEventTillDown) {
                OnItemTouchListener onItemTouchListener = r6.mInterceptingOnItemTouchListener;
                int actionMasked;
                if (onItemTouchListener == null) {
                    if (motionEvent.getAction() != 0) {
                        if (findInterceptingOnItemTouchListener(motionEvent)) {
                        }
                    }
                    LayoutManager layoutManager = r6.mLayout;
                    if (layoutManager == null) {
                        return false;
                    }
                    int[] iArr;
                    int canScrollHorizontally = layoutManager.canScrollHorizontally();
                    boolean canScrollVertically = r6.mLayout.canScrollVertically();
                    if (r6.mVelocityTracker == null) {
                        r6.mVelocityTracker = VelocityTracker.obtain();
                    }
                    actionMasked = motionEvent.getActionMasked();
                    int actionIndex = motionEvent.getActionIndex();
                    if (actionMasked == 0) {
                        iArr = r6.mNestedOffsets;
                        iArr[1] = 0;
                        iArr[0] = 0;
                        actionMasked = 0;
                    }
                    MotionEvent obtain = MotionEvent.obtain(motionEvent);
                    int[] iArr2 = r6.mNestedOffsets;
                    obtain.offsetLocation((float) iArr2[0], (float) iArr2[1]);
                    switch (actionMasked) {
                        case 0:
                            r6.mScrollPointerId = motionEvent2.getPointerId(0);
                            actionMasked = (int) (motionEvent.getX() + 0.5f);
                            r6.mLastTouchX = actionMasked;
                            r6.mInitialTouchX = actionMasked;
                            actionMasked = (int) (motionEvent.getY() + 0.5f);
                            r6.mLastTouchY = actionMasked;
                            r6.mInitialTouchY = actionMasked;
                            if (canScrollVertically) {
                                canScrollHorizontally |= 2;
                            }
                            startNestedScroll$ar$ds(canScrollHorizontally, 0);
                            break;
                        case 1:
                            float f;
                            r6.mVelocityTracker.addMovement(obtain);
                            r6.mVelocityTracker.computeCurrentVelocity(1000, (float) r6.mMaxFlingVelocity);
                            if (canScrollHorizontally != 0) {
                                f = -r6.mVelocityTracker.getXVelocity(r6.mScrollPointerId);
                            } else {
                                f = 0.0f;
                            }
                            float f2;
                            if (canScrollVertically) {
                                f2 = -r6.mVelocityTracker.getYVelocity(r6.mScrollPointerId);
                            } else {
                                f2 = 0.0f;
                            }
                            if ((f == 0.0f && f2 == 0.0f) || !fling((int) f, (int) f2)) {
                                setScrollState(0);
                            }
                            resetScroll();
                            break;
                        case 2:
                            actionMasked = motionEvent2.findPointerIndex(r6.mScrollPointerId);
                            if (actionMasked >= 0) {
                                int x = (int) (motionEvent2.getX(actionMasked) + 0.5f);
                                int y = (int) (motionEvent2.getY(actionMasked) + 0.5f);
                                actionMasked = r6.mLastTouchX - x;
                                actionIndex = r6.mLastTouchY - y;
                                if (r6.mScrollState != 1) {
                                    Object obj;
                                    if (canScrollHorizontally != 0) {
                                        if (actionMasked > 0) {
                                            actionMasked = Math.max(0, actionMasked - r6.mTouchSlop);
                                        } else {
                                            actionMasked = Math.min(0, actionMasked + r6.mTouchSlop);
                                        }
                                        if (actionMasked != 0) {
                                            obj = 1;
                                        } else {
                                            obj = null;
                                        }
                                    } else {
                                        obj = null;
                                    }
                                    if (canScrollVertically) {
                                        if (actionIndex > 0) {
                                            actionIndex = Math.max(0, actionIndex - r6.mTouchSlop);
                                        } else {
                                            actionIndex = Math.min(0, actionIndex + r6.mTouchSlop);
                                        }
                                        if (actionIndex != 0) {
                                            obj = 1;
                                        }
                                    }
                                    if (obj != null) {
                                        setScrollState(1);
                                    }
                                }
                                if (r6.mScrollState == 1) {
                                    int i2;
                                    iArr2 = r6.mReusableIntPair;
                                    iArr2[0] = 0;
                                    iArr2[1] = 0;
                                    int releaseHorizontalGlow = actionMasked - releaseHorizontalGlow(actionMasked, motionEvent.getY());
                                    int releaseVerticalGlow = actionIndex - releaseVerticalGlow(actionIndex, motionEvent.getX());
                                    if (1 != canScrollHorizontally) {
                                        actionIndex = 0;
                                    } else {
                                        actionIndex = releaseHorizontalGlow;
                                    }
                                    if (true != canScrollVertically) {
                                        i2 = 0;
                                    } else {
                                        i2 = releaseVerticalGlow;
                                    }
                                    if (dispatchNestedPreScroll(actionIndex, i2, r6.mReusableIntPair, r6.mScrollOffset, 0)) {
                                        iArr = r6.mReusableIntPair;
                                        releaseHorizontalGlow -= iArr[0];
                                        releaseVerticalGlow -= iArr[1];
                                        iArr = r6.mNestedOffsets;
                                        actionIndex = iArr[0];
                                        iArr2 = r6.mScrollOffset;
                                        iArr[0] = actionIndex + iArr2[0];
                                        iArr[1] = iArr[1] + iArr2[1];
                                        getParent().requestDisallowInterceptTouchEvent(true);
                                        actionMasked = releaseVerticalGlow;
                                    } else {
                                        actionMasked = releaseVerticalGlow;
                                    }
                                    int[] iArr3 = r6.mScrollOffset;
                                    r6.mLastTouchX = x - iArr3[0];
                                    r6.mLastTouchY = y - iArr3[1];
                                    if (1 != canScrollHorizontally) {
                                        actionIndex = 0;
                                    } else {
                                        actionIndex = releaseHorizontalGlow;
                                    }
                                    if (true != canScrollVertically) {
                                        i2 = 0;
                                    } else {
                                        i2 = actionMasked;
                                    }
                                    if (scrollByInternal(actionIndex, i2, motionEvent2, 0)) {
                                        getParent().requestDisallowInterceptTouchEvent(true);
                                    }
                                    GapWorker gapWorker = r6.mGapWorker;
                                    if (gapWorker != null) {
                                        if (releaseHorizontalGlow != 0) {
                                            i = releaseHorizontalGlow;
                                        } else if (actionMasked != 0) {
                                        }
                                        gapWorker.postFromTraversal(r6, i, actionMasked);
                                        break;
                                    }
                                }
                            }
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Error processing scroll; pointer index for id ");
                            stringBuilder.append(r6.mScrollPointerId);
                            stringBuilder.append(" not found. Did any MotionEvents get skipped?");
                            Log.e("RecyclerView", stringBuilder.toString());
                            return false;
                            break;
                        case 3:
                            cancelScroll();
                            break;
                        case 5:
                            r6.mScrollPointerId = motionEvent2.getPointerId(actionIndex);
                            actionMasked = (int) (motionEvent2.getX(actionIndex) + 0.5f);
                            r6.mLastTouchX = actionMasked;
                            r6.mInitialTouchX = actionMasked;
                            actionMasked = (int) (motionEvent2.getY(actionIndex) + 0.5f);
                            r6.mLastTouchY = actionMasked;
                            r6.mInitialTouchY = actionMasked;
                            break;
                        case 6:
                            onPointerUp(motionEvent);
                            break;
                        default:
                            break;
                    }
                    r6.mVelocityTracker.addMovement(obtain);
                    obtain.recycle();
                    return true;
                }
                onItemTouchListener.onTouchEvent$ar$ds$fcc9275a_0(motionEvent2);
                actionMasked = motionEvent.getAction();
                if (actionMasked == 3 || actionMasked == 1) {
                    r6.mInterceptingOnItemTouchListener = null;
                }
                cancelScroll();
                return true;
            }
        }
        return false;
    }

    final void processDataSetCompletelyChanged(boolean z) {
        int i;
        this.mDispatchItemsChangedEvent = z | this.mDispatchItemsChangedEvent;
        this.mDataSetHasChangedAfterLayout = true;
        int unfilteredChildCount = this.mChildHelper.getUnfilteredChildCount();
        for (i = 0; i < unfilteredChildCount; i++) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(this.mChildHelper.getUnfilteredChildAt(i));
            if (!(childViewHolderInt == null || childViewHolderInt.shouldIgnore())) {
                childViewHolderInt.addFlags(6);
            }
        }
        markItemDecorInsetsDirty();
        Recycler recycler = this.mRecycler;
        i = recycler.mCachedViews.size();
        for (int i2 = 0; i2 < i; i2++) {
            childViewHolderInt = (ViewHolder) recycler.mCachedViews.get(i2);
            if (childViewHolderInt != null) {
                childViewHolderInt.addFlags(6);
                childViewHolderInt.addChangePayload(null);
            }
        }
        Adapter adapter = recycler.this$0.mAdapter;
        if (adapter != null) {
            if (adapter.mHasStableIds) {
                return;
            }
        }
        recycler.recycleAndClearCachedViews();
    }

    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (isComputingLayout()) {
            int i = 0;
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            if (contentChangeTypes != 0) {
                i = contentChangeTypes;
            }
            this.mEatenAccessibilityChangeFlags |= i;
            return;
        }
        super.sendAccessibilityEventUnchecked(accessibilityEvent);
    }

    public void setAdapter(Adapter adapter) {
        suppressLayout(false);
        Adapter adapter2 = this.mAdapter;
        if (adapter2 != null) {
            adapter2.unregisterAdapterDataObserver(this.mObserver);
            this.mAdapter.onDetachedFromRecyclerView(this);
        }
        removeAndRecycleViews();
        this.mAdapterHelper.reset();
        adapter2 = this.mAdapter;
        this.mAdapter = adapter;
        if (adapter != null) {
            adapter.registerAdapterDataObserver(this.mObserver);
            adapter.onAttachedToRecyclerView(this);
        }
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            layoutManager.onAdapterChanged(adapter2, this.mAdapter);
        }
        Recycler recycler = this.mRecycler;
        Adapter adapter3 = this.mAdapter;
        recycler.clear();
        RecycledViewPool recycledViewPool = recycler.getRecycledViewPool();
        if (adapter2 != null) {
            recycledViewPool.mAttachCount--;
        }
        if (recycledViewPool.mAttachCount == 0) {
            for (int i = 0; i < recycledViewPool.mScrap.size(); i++) {
                ((ScrapData) recycledViewPool.mScrap.valueAt(i)).mScrapHeap.clear();
            }
        }
        if (adapter3 != null) {
            recycledViewPool.mAttachCount++;
        }
        this.mState.mStructureChanged = true;
        processDataSetCompletelyChanged(false);
        requestLayout();
    }

    @Deprecated
    public final void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition == null) {
            super.setLayoutTransition(null);
            return;
        }
        throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
    }

    public final void smoothScrollBy(int i, int i2) {
        smoothScrollBy$ar$ds$a5e2b4f9_0(i, i2, false);
    }

    public final void stopNestedScroll(int i) {
        getScrollingChildHelper().stopNestedScroll(i);
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i) {
        String str;
        Context context2 = context;
        AttributeSet attributeSet2 = attributeSet;
        int i2 = i;
        super(context, attributeSet, i);
        this.mObserver = new RecyclerViewDataObserver();
        this.mRecycler = new Recycler();
        this.mViewInfoStore = new ViewInfoStore();
        this.mUpdateChildViewsRunnable = new PG();
        this.mTempRect = new Rect();
        this.mTempRect2 = new Rect();
        this.mTempRectF = new RectF();
        this.mRecyclerListeners = new ArrayList();
        this.mItemDecorations = new ArrayList();
        this.mOnItemTouchListeners = new ArrayList();
        this.mInterceptRequestLayoutDepth = 0;
        this.mDataSetHasChangedAfterLayout = false;
        this.mDispatchItemsChangedEvent = false;
        this.mLayoutOrScrollCounter = 0;
        this.mDispatchScrollCounter = 0;
        this.mEdgeEffectFactory = sDefaultEdgeEffectFactory;
        this.mItemAnimator = new DefaultItemAnimator();
        this.mScrollState = 0;
        this.mScrollPointerId = -1;
        this.mScaledHorizontalScrollFactor = Float.MIN_VALUE;
        this.mScaledVerticalScrollFactor = Float.MIN_VALUE;
        this.mPreserveFocusAfterLayout = true;
        this.mViewFlinger = new ViewFlinger();
        this.mPrefetchRegistry = new LayoutPrefetchRegistryImpl();
        this.mState = new State();
        this.mItemsAddedOrRemoved = false;
        this.mItemsChanged = false;
        this.mItemAnimatorListener$ar$class_merging = new ItemAnimatorRestoreListener();
        this.mPostedAnimatorRunner = false;
        this.mMinMaxLayoutPositions = new int[2];
        this.mScrollOffset = new int[2];
        this.mNestedOffsets = new int[2];
        this.mReusableIntPair = new int[2];
        this.mPendingAccessibilityImportanceChange = new ArrayList();
        this.mItemAnimatorRunner = new C01052();
        this.mLastAutoMeasureNonExactMeasuredWidth = 0;
        this.mLastAutoMeasureNonExactMeasuredHeight = 0;
        this.mViewInfoProcessCallback$ar$class_merging = new C01074();
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.mScaledHorizontalScrollFactor = viewConfiguration.getScaledHorizontalScrollFactor();
        this.mScaledVerticalScrollFactor = viewConfiguration.getScaledVerticalScrollFactor();
        this.mMinFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
        this.mMaxFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        r9.mItemAnimator.mListener$ar$class_merging$4809de85_0 = r9.mItemAnimatorListener$ar$class_merging;
        r9.mAdapterHelper = new AdapterHelper(new C01096());
        r9.mChildHelper = new ChildHelper(new C01085());
        if (ViewCompat.getImportantForAutofill(this) == 0) {
            ViewCompat.setImportantForAutofill$ar$ds(this);
        }
        if (ViewCompat.getImportantForAccessibility(this) == 0) {
            ViewCompat.setImportantForAccessibility(r9, 1);
        }
        r9.mAccessibilityManager = (AccessibilityManager) getContext().getSystemService("accessibility");
        AccessibilityDelegateCompat recyclerViewAccessibilityDelegate = new RecyclerViewAccessibilityDelegate(r9);
        r9.mAccessibilityDelegate = recyclerViewAccessibilityDelegate;
        ViewCompat.setAccessibilityDelegate(r9, recyclerViewAccessibilityDelegate);
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet2, R$styleable.RecyclerView, i2, 0);
        ViewCompat.saveAttributeDataForStyleable(this, context, R$styleable.RecyclerView, attributeSet, obtainStyledAttributes, i, 0);
        String string = obtainStyledAttributes.getString(8);
        if (obtainStyledAttributes.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        r9.mClipToPadding = obtainStyledAttributes.getBoolean(1, true);
        if (obtainStyledAttributes.getBoolean(3, false)) {
            StateListDrawable stateListDrawable = (StateListDrawable) obtainStyledAttributes.getDrawable(6);
            Drawable drawable = obtainStyledAttributes.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) obtainStyledAttributes.getDrawable(4);
            Drawable drawable2 = obtainStyledAttributes.getDrawable(5);
            if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Trying to set fast scroller without both required drawables.");
                stringBuilder.append(exceptionLabel());
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            Resources resources = getContext().getResources();
            str = string;
            FastScroller fastScroller = new FastScroller(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(R.dimen.fastscroll_margin));
        } else {
            str = string;
        }
        obtainStyledAttributes.recycle();
        createLayoutManager$ar$ds(context2, str, attributeSet2, i2);
        int[] iArr = NESTED_SCROLLING_ATTRS;
        TypedArray obtainStyledAttributes2 = context2.obtainStyledAttributes(attributeSet2, iArr, i2, 0);
        ViewCompat.saveAttributeDataForStyleable(this, context, iArr, attributeSet, obtainStyledAttributes2, i, 0);
        boolean z = obtainStyledAttributes2.getBoolean(0, true);
        obtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z);
    }

    protected final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        LayoutManager layoutManager = this.mLayout;
        if (layoutManager != null) {
            return layoutManager.generateLayoutParams(layoutParams);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RecyclerView has no LayoutManager");
        stringBuilder.append(exceptionLabel());
        throw new IllegalStateException(stringBuilder.toString());
    }

    final void onExitLayoutOrScroll(boolean z) {
        int i = this.mLayoutOrScrollCounter - 1;
        this.mLayoutOrScrollCounter = i;
        if (i <= 0) {
            this.mLayoutOrScrollCounter = 0;
            if (z) {
                int i2 = this.mEatenAccessibilityChangeFlags;
                this.mEatenAccessibilityChangeFlags = 0;
                if (i2 != 0 && isAccessibilityEnabled()) {
                    AccessibilityEvent obtain = AccessibilityEvent.obtain();
                    obtain.setEventType(2048);
                    obtain.setContentChangeTypes(i2);
                    sendAccessibilityEventUnchecked(obtain);
                }
                for (i2 = this.mPendingAccessibilityImportanceChange.size() - 1; i2 >= 0; i2--) {
                    ViewHolder viewHolder = (ViewHolder) this.mPendingAccessibilityImportanceChange.get(i2);
                    if (viewHolder.itemView.getParent() == this) {
                        if (!viewHolder.shouldIgnore()) {
                            int i3 = viewHolder.mPendingAccessibilityState;
                            if (i3 != -1) {
                                ViewCompat.setImportantForAccessibility(viewHolder.itemView, i3);
                                viewHolder.mPendingAccessibilityState = -1;
                            }
                        }
                    }
                }
                this.mPendingAccessibilityImportanceChange.clear();
            }
        }
    }
}
