package android.support.p002v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.p002v7.content.res.AppCompatResources;
import android.util.AttributeSet;
import android.util.TypedValue;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.TintTypedArray */
public final class TintTypedArray {
    public final Context mContext;
    public TypedValue mTypedValue;
    public final TypedArray mWrapped;

    private TintTypedArray(Context context, TypedArray typedArray) {
        this.mContext = context;
        this.mWrapped = typedArray;
    }

    public static TintTypedArray obtainStyledAttributes(Context context, int i, int[] iArr) {
        return new TintTypedArray(context, context.obtainStyledAttributes(i, iArr));
    }

    public static TintTypedArray obtainStyledAttributes$ar$ds(Context context, AttributeSet attributeSet, int[] iArr, int i) {
        return new TintTypedArray(context, context.obtainStyledAttributes(attributeSet, iArr, i, 0));
    }

    public final boolean getBoolean(int i, boolean z) {
        return this.mWrapped.getBoolean(i, z);
    }

    public final ColorStateList getColorStateList(int i) {
        if (this.mWrapped.hasValue(i)) {
            int resourceId = this.mWrapped.getResourceId(i, 0);
            if (resourceId != 0) {
                ColorStateList colorStateList = AppCompatResources.getColorStateList(this.mContext, resourceId);
                if (colorStateList != null) {
                    return colorStateList;
                }
            }
        }
        return this.mWrapped.getColorStateList(i);
    }

    public final int getDimensionPixelOffset(int i, int i2) {
        return this.mWrapped.getDimensionPixelOffset(i, i2);
    }

    public final int getDimensionPixelSize(int i, int i2) {
        return this.mWrapped.getDimensionPixelSize(i, i2);
    }

    public final Drawable getDrawable(int i) {
        if (this.mWrapped.hasValue(i)) {
            int resourceId = this.mWrapped.getResourceId(i, 0);
            if (resourceId != 0) {
                return AppCompatResources.getDrawable(this.mContext, resourceId);
            }
        }
        return this.mWrapped.getDrawable(i);
    }

    public final Drawable getDrawableIfKnown(int i) {
        if (this.mWrapped.hasValue(i)) {
            i = this.mWrapped.getResourceId(i, 0);
            if (i != 0) {
                return AppCompatDrawableManager.get().getDrawable$ar$ds(this.mContext, i);
            }
        }
        return null;
    }

    public final int getInt(int i, int i2) {
        return this.mWrapped.getInt(i, i2);
    }

    public final int getInteger(int i, int i2) {
        return this.mWrapped.getInteger(i, i2);
    }

    public final int getLayoutDimension(int i, int i2) {
        return this.mWrapped.getLayoutDimension(i, i2);
    }

    public final int getResourceId(int i, int i2) {
        return this.mWrapped.getResourceId(i, i2);
    }

    public final String getString(int i) {
        return this.mWrapped.getString(i);
    }

    public final CharSequence getText(int i) {
        return this.mWrapped.getText(i);
    }

    public final boolean hasValue(int i) {
        return this.mWrapped.hasValue(i);
    }

    public final void recycle() {
        this.mWrapped.recycle();
    }

    public static TintTypedArray obtainStyledAttributes(Context context, AttributeSet attributeSet, int[] iArr) {
        return new TintTypedArray(context, context.obtainStyledAttributes(attributeSet, iArr));
    }
}
