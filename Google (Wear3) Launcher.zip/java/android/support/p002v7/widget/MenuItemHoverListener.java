package android.support.p002v7.widget;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.MenuItemHoverListener */
public interface MenuItemHoverListener {
}
