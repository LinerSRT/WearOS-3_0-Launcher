package android.support.p002v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.widget.DefaultItemAnimator.ChangeInfo;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.support.v7.widget.DefaultItemAnimator.C00996;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.DefaultItemAnimator */
public class DefaultItemAnimator extends SimpleItemAnimator {
    private static TimeInterpolator sDefaultInterpolator;
    final ArrayList mAddAnimations = new ArrayList();
    final ArrayList mAdditionsList = new ArrayList();
    final ArrayList mChangeAnimations = new ArrayList();
    final ArrayList mChangesList = new ArrayList();
    final ArrayList mMoveAnimations = new ArrayList();
    final ArrayList mMovesList = new ArrayList();
    private final ArrayList mPendingAdditions = new ArrayList();
    private final ArrayList mPendingChanges = new ArrayList();
    private final ArrayList mPendingMoves = new ArrayList();
    private final ArrayList mPendingRemovals = new ArrayList();
    final ArrayList mRemoveAnimations = new ArrayList();

    /* renamed from: android.support.v7.widget.DefaultItemAnimator$5 */
    final class C00985 extends AnimatorListenerAdapter {
        final /* synthetic */ ViewPropertyAnimator val$animation;
        final /* synthetic */ ViewHolder val$holder;
        final /* synthetic */ View val$view;

        public C00985(ViewHolder viewHolder, View view, ViewPropertyAnimator viewPropertyAnimator) {
            this.val$holder = viewHolder;
            this.val$view = view;
            this.val$animation = viewPropertyAnimator;
        }

        public final void onAnimationCancel(Animator animator) {
            this.val$view.setAlpha(1.0f);
        }

        public final void onAnimationEnd(Animator animator) {
            this.val$animation.setListener(null);
            android.support.p002v7.widget.DefaultItemAnimator.this.dispatchAnimationFinished(this.val$holder);
            android.support.p002v7.widget.DefaultItemAnimator.this.mAddAnimations.remove(this.val$holder);
            android.support.p002v7.widget.DefaultItemAnimator.this.dispatchFinishedWhenDone();
        }

        public final void onAnimationStart(Animator animator) {
        }
    }

    /* renamed from: android.support.v7.widget.DefaultItemAnimator$6 */
    final class C00996 extends AnimatorListenerAdapter {
        final /* synthetic */ ViewPropertyAnimator val$animation;
        final /* synthetic */ int val$deltaX;
        final /* synthetic */ int val$deltaY;
        final /* synthetic */ ViewHolder val$holder;
        final /* synthetic */ View val$view;

        public C00996(ViewHolder viewHolder, int i, View view, int i2, ViewPropertyAnimator viewPropertyAnimator) {
            this.val$holder = viewHolder;
            this.val$deltaX = i;
            this.val$view = view;
            this.val$deltaY = i2;
            this.val$animation = viewPropertyAnimator;
        }

        public final void onAnimationCancel(Animator animator) {
            if (this.val$deltaX != 0) {
                this.val$view.setTranslationX(0.0f);
            }
            if (this.val$deltaY != 0) {
                this.val$view.setTranslationY(0.0f);
            }
        }

        public final void onAnimationEnd(Animator animator) {
            this.val$animation.setListener(null);
            android.support.p002v7.widget.DefaultItemAnimator.this.dispatchAnimationFinished(this.val$holder);
            android.support.p002v7.widget.DefaultItemAnimator.this.mMoveAnimations.remove(this.val$holder);
            android.support.p002v7.widget.DefaultItemAnimator.this.dispatchFinishedWhenDone();
        }

        public final void onAnimationStart(Animator animator) {
        }
    }

    /* renamed from: android.support.v7.widget.DefaultItemAnimator$7 */
    final class C01007 extends AnimatorListenerAdapter {
        final /* synthetic */ ChangeInfo val$changeInfo;
        final /* synthetic */ ViewPropertyAnimator val$oldViewAnim;
        final /* synthetic */ View val$view;

        public C01007(ChangeInfo changeInfo, ViewPropertyAnimator viewPropertyAnimator, View view) {
            this.val$changeInfo = changeInfo;
            this.val$oldViewAnim = viewPropertyAnimator;
            this.val$view = view;
        }

        public final void onAnimationEnd(Animator animator) {
            this.val$oldViewAnim.setListener(null);
            this.val$view.setAlpha(1.0f);
            this.val$view.setTranslationX(0.0f);
            this.val$view.setTranslationY(0.0f);
            android.support.p002v7.widget.DefaultItemAnimator.this.dispatchAnimationFinished(this.val$changeInfo.oldHolder);
            android.support.p002v7.widget.DefaultItemAnimator.this.mChangeAnimations.remove(this.val$changeInfo.oldHolder);
            android.support.p002v7.widget.DefaultItemAnimator.this.dispatchFinishedWhenDone();
        }

        public final void onAnimationStart(Animator animator) {
            ViewHolder viewHolder = this.val$changeInfo.oldHolder;
        }
    }

    /* renamed from: android.support.v7.widget.DefaultItemAnimator$8 */
    final class C01018 extends AnimatorListenerAdapter {
        final /* synthetic */ ChangeInfo val$changeInfo;
        final /* synthetic */ View val$newView;
        final /* synthetic */ ViewPropertyAnimator val$newViewAnimation;

        public C01018(ChangeInfo changeInfo, ViewPropertyAnimator viewPropertyAnimator, View view) {
            this.val$changeInfo = changeInfo;
            this.val$newViewAnimation = viewPropertyAnimator;
            this.val$newView = view;
        }

        public final void onAnimationEnd(Animator animator) {
            this.val$newViewAnimation.setListener(null);
            this.val$newView.setAlpha(1.0f);
            this.val$newView.setTranslationX(0.0f);
            this.val$newView.setTranslationY(0.0f);
            android.support.p002v7.widget.DefaultItemAnimator.this.dispatchAnimationFinished(this.val$changeInfo.newHolder);
            android.support.p002v7.widget.DefaultItemAnimator.this.mChangeAnimations.remove(this.val$changeInfo.newHolder);
            android.support.p002v7.widget.DefaultItemAnimator.this.dispatchFinishedWhenDone();
        }

        public final void onAnimationStart(Animator animator) {
            ViewHolder viewHolder = this.val$changeInfo.newHolder;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.DefaultItemAnimator$ChangeInfo */
    final class ChangeInfo {
        public final int fromX;
        public final int fromY;
        public ViewHolder newHolder;
        public ViewHolder oldHolder;
        public final int toX;
        public final int toY;

        public ChangeInfo(ViewHolder viewHolder, ViewHolder viewHolder2, int i, int i2, int i3, int i4) {
            this.oldHolder = viewHolder;
            this.newHolder = viewHolder2;
            this.fromX = i;
            this.fromY = i2;
            this.toX = i3;
            this.toY = i4;
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("ChangeInfo{oldHolder=");
            stringBuilder.append(this.oldHolder);
            stringBuilder.append(", newHolder=");
            stringBuilder.append(this.newHolder);
            stringBuilder.append(", fromX=");
            stringBuilder.append(this.fromX);
            stringBuilder.append(", fromY=");
            stringBuilder.append(this.fromY);
            stringBuilder.append(", toX=");
            stringBuilder.append(this.toX);
            stringBuilder.append(", toY=");
            stringBuilder.append(this.toY);
            stringBuilder.append('}');
            return stringBuilder.toString();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.DefaultItemAnimator$MoveInfo */
    final class MoveInfo {
        public final int fromX;
        public final int fromY;
        public final ViewHolder holder;
        public final int toX;
        public final int toY;

        public MoveInfo(ViewHolder viewHolder, int i, int i2, int i3, int i4) {
            this.holder = viewHolder;
            this.fromX = i;
            this.fromY = i2;
            this.toX = i3;
            this.toY = i4;
        }
    }

    static final void cancelAll$ar$ds(List list) {
        for (int size = list.size() - 1; size >= 0; size--) {
            ((ViewHolder) list.get(size)).itemView.animate().cancel();
        }
    }

    private final void endChangeAnimation(List list, ViewHolder viewHolder) {
        for (int size = list.size() - 1; size >= 0; size--) {
            ChangeInfo changeInfo = (ChangeInfo) list.get(size);
            if (endChangeAnimationIfNecessary(changeInfo, viewHolder) && changeInfo.oldHolder == null && changeInfo.newHolder == null) {
                list.remove(changeInfo);
            }
        }
    }

    private final void endChangeAnimationIfNecessary(ChangeInfo changeInfo) {
        ViewHolder viewHolder = changeInfo.oldHolder;
        if (viewHolder != null) {
            endChangeAnimationIfNecessary(changeInfo, viewHolder);
        }
        viewHolder = changeInfo.newHolder;
        if (viewHolder != null) {
            endChangeAnimationIfNecessary(changeInfo, viewHolder);
        }
    }

    private final void resetAnimation(ViewHolder viewHolder) {
        if (sDefaultInterpolator == null) {
            sDefaultInterpolator = new ValueAnimator().getInterpolator();
        }
        viewHolder.itemView.animate().setInterpolator(sDefaultInterpolator);
        endAnimation(viewHolder);
    }

    public boolean animateAdd(ViewHolder viewHolder) {
        resetAnimation(viewHolder);
        viewHolder.itemView.setAlpha(0.0f);
        this.mPendingAdditions.add(viewHolder);
        return true;
    }

    public boolean animateChange(ViewHolder viewHolder, ViewHolder viewHolder2, int i, int i2, int i3, int i4) {
        if (viewHolder == viewHolder2) {
            return animateMove(viewHolder, i, i2, i3, i4);
        }
        float translationX = viewHolder.itemView.getTranslationX();
        float translationY = viewHolder.itemView.getTranslationY();
        float alpha = viewHolder.itemView.getAlpha();
        resetAnimation(viewHolder);
        int i5 = (int) (((float) (i3 - i)) - translationX);
        int i6 = (int) (((float) (i4 - i2)) - translationY);
        viewHolder.itemView.setTranslationX(translationX);
        viewHolder.itemView.setTranslationY(translationY);
        viewHolder.itemView.setAlpha(alpha);
        if (viewHolder2 != null) {
            resetAnimation(viewHolder2);
            viewHolder2.itemView.setTranslationX((float) (-i5));
            viewHolder2.itemView.setTranslationY((float) (-i6));
            viewHolder2.itemView.setAlpha(0.0f);
        }
        this.mPendingChanges.add(new ChangeInfo(viewHolder, viewHolder2, i, i2, i3, i4));
        return true;
    }

    public boolean animateMove(ViewHolder viewHolder, int i, int i2, int i3, int i4) {
        View view = viewHolder.itemView;
        int translationX = i + ((int) view.getTranslationX());
        int translationY = i2 + ((int) viewHolder.itemView.getTranslationY());
        resetAnimation(viewHolder);
        i = i3 - translationX;
        i2 = i4 - translationY;
        if (i == 0) {
            if (i2 != 0) {
                i = 0;
            } else {
                dispatchAnimationFinished(viewHolder);
                return false;
            }
        }
        if (i != 0) {
            view.setTranslationX((float) (-i));
        }
        if (i2 != 0) {
            view.setTranslationY((float) (-i2));
        }
        this.mPendingMoves.add(new MoveInfo(viewHolder, translationX, translationY, i3, i4));
        return true;
    }

    public boolean animateRemove(ViewHolder viewHolder) {
        resetAnimation(viewHolder);
        this.mPendingRemovals.add(viewHolder);
        return true;
    }

    public final boolean canReuseUpdatedViewHolder(ViewHolder viewHolder, List list) {
        if (list.isEmpty()) {
            if (!canReuseUpdatedViewHolder(viewHolder)) {
                return false;
            }
        }
        return true;
    }

    final void dispatchFinishedWhenDone() {
        if (!isRunning()) {
            dispatchAnimationsFinished();
        }
    }

    public final void endAnimation(ViewHolder viewHolder) {
        int size;
        View view = viewHolder.itemView;
        view.animate().cancel();
        for (size = this.mPendingMoves.size() - 1; size >= 0; size--) {
            if (((MoveInfo) this.mPendingMoves.get(size)).holder == viewHolder) {
                view.setTranslationY(0.0f);
                view.setTranslationX(0.0f);
                dispatchAnimationFinished(viewHolder);
                this.mPendingMoves.remove(size);
            }
        }
        endChangeAnimation(this.mPendingChanges, viewHolder);
        if (this.mPendingRemovals.remove(viewHolder)) {
            view.setAlpha(1.0f);
            dispatchAnimationFinished(viewHolder);
        }
        if (this.mPendingAdditions.remove(viewHolder)) {
            view.setAlpha(1.0f);
            dispatchAnimationFinished(viewHolder);
        }
        for (size = this.mChangesList.size() - 1; size >= 0; size--) {
            ArrayList arrayList = (ArrayList) this.mChangesList.get(size);
            endChangeAnimation(arrayList, viewHolder);
            if (arrayList.isEmpty()) {
                this.mChangesList.remove(size);
            }
        }
        for (size = this.mMovesList.size() - 1; size >= 0; size--) {
            arrayList = (ArrayList) this.mMovesList.get(size);
            int size2 = arrayList.size() - 1;
            while (size2 >= 0) {
                if (((MoveInfo) arrayList.get(size2)).holder == viewHolder) {
                    view.setTranslationY(0.0f);
                    view.setTranslationX(0.0f);
                    dispatchAnimationFinished(viewHolder);
                    arrayList.remove(size2);
                    if (arrayList.isEmpty()) {
                        this.mMovesList.remove(size);
                    }
                } else {
                    size2--;
                }
            }
        }
        for (size = this.mAdditionsList.size() - 1; size >= 0; size--) {
            ArrayList arrayList2 = (ArrayList) this.mAdditionsList.get(size);
            if (arrayList2.remove(viewHolder)) {
                view.setAlpha(1.0f);
                dispatchAnimationFinished(viewHolder);
                if (arrayList2.isEmpty()) {
                    this.mAdditionsList.remove(size);
                }
            }
        }
        this.mRemoveAnimations.remove(viewHolder);
        this.mAddAnimations.remove(viewHolder);
        this.mChangeAnimations.remove(viewHolder);
        this.mMoveAnimations.remove(viewHolder);
        dispatchFinishedWhenDone();
    }

    public final void endAnimations() {
        int size;
        for (size = this.mPendingMoves.size() - 1; size >= 0; size--) {
            MoveInfo moveInfo = (MoveInfo) this.mPendingMoves.get(size);
            View view = moveInfo.holder.itemView;
            view.setTranslationY(0.0f);
            view.setTranslationX(0.0f);
            dispatchAnimationFinished(moveInfo.holder);
            this.mPendingMoves.remove(size);
        }
        for (size = this.mPendingRemovals.size() - 1; size >= 0; size--) {
            dispatchAnimationFinished((ViewHolder) this.mPendingRemovals.get(size));
            this.mPendingRemovals.remove(size);
        }
        for (size = this.mPendingAdditions.size() - 1; size >= 0; size--) {
            ViewHolder viewHolder = (ViewHolder) this.mPendingAdditions.get(size);
            viewHolder.itemView.setAlpha(1.0f);
            dispatchAnimationFinished(viewHolder);
            this.mPendingAdditions.remove(size);
        }
        for (size = this.mPendingChanges.size() - 1; size >= 0; size--) {
            endChangeAnimationIfNecessary((ChangeInfo) this.mPendingChanges.get(size));
        }
        this.mPendingChanges.clear();
        if (isRunning()) {
            ArrayList arrayList;
            for (size = this.mMovesList.size() - 1; size >= 0; size--) {
                ArrayList arrayList2 = (ArrayList) this.mMovesList.get(size);
                for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
                    MoveInfo moveInfo2 = (MoveInfo) arrayList2.get(size2);
                    View view2 = moveInfo2.holder.itemView;
                    view2.setTranslationY(0.0f);
                    view2.setTranslationX(0.0f);
                    dispatchAnimationFinished(moveInfo2.holder);
                    arrayList2.remove(size2);
                    if (arrayList2.isEmpty()) {
                        this.mMovesList.remove(arrayList2);
                    }
                }
            }
            for (size = this.mAdditionsList.size() - 1; size >= 0; size--) {
                arrayList = (ArrayList) this.mAdditionsList.get(size);
                for (int size3 = arrayList.size() - 1; size3 >= 0; size3--) {
                    ViewHolder viewHolder2 = (ViewHolder) arrayList.get(size3);
                    viewHolder2.itemView.setAlpha(1.0f);
                    dispatchAnimationFinished(viewHolder2);
                    arrayList.remove(size3);
                    if (arrayList.isEmpty()) {
                        this.mAdditionsList.remove(arrayList);
                    }
                }
            }
            for (size = this.mChangesList.size() - 1; size >= 0; size--) {
                arrayList = (ArrayList) this.mChangesList.get(size);
                for (int size4 = arrayList.size() - 1; size4 >= 0; size4--) {
                    endChangeAnimationIfNecessary((ChangeInfo) arrayList.get(size4));
                    if (arrayList.isEmpty()) {
                        this.mChangesList.remove(arrayList);
                    }
                }
            }
            DefaultItemAnimator.cancelAll$ar$ds(this.mRemoveAnimations);
            DefaultItemAnimator.cancelAll$ar$ds(this.mMoveAnimations);
            DefaultItemAnimator.cancelAll$ar$ds(this.mAddAnimations);
            DefaultItemAnimator.cancelAll$ar$ds(this.mChangeAnimations);
            dispatchAnimationsFinished();
        }
    }

    public final boolean isRunning() {
        if (this.mPendingAdditions.isEmpty() && this.mPendingChanges.isEmpty() && this.mPendingMoves.isEmpty() && this.mPendingRemovals.isEmpty() && this.mMoveAnimations.isEmpty() && this.mRemoveAnimations.isEmpty() && this.mAddAnimations.isEmpty() && this.mChangeAnimations.isEmpty() && this.mMovesList.isEmpty() && this.mAdditionsList.isEmpty()) {
            if (this.mChangesList.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public final void runPendingAnimations() {
        final ArrayList arrayList;
        Runnable pg;
        long j;
        boolean isEmpty = this.mPendingRemovals.isEmpty();
        int i = isEmpty ^ 1;
        boolean isEmpty2 = this.mPendingMoves.isEmpty();
        int i2 = isEmpty2 ^ 1;
        boolean isEmpty3 = this.mPendingChanges.isEmpty();
        int i3 = isEmpty3 ^ 1;
        int isEmpty4 = this.mPendingAdditions.isEmpty() ^ 1;
        if (i == 0 && i2 == 0 && isEmpty4 == 0) {
            if (i3 == 0) {
                return;
            }
        }
        List list = r0.mPendingRemovals;
        int size = list.size();
        for (int i4 = 0; i4 < size; i4++) {
            final ViewHolder viewHolder = (ViewHolder) list.get(i4);
            final View view = viewHolder.itemView;
            final ViewPropertyAnimator animate = view.animate();
            r0.mRemoveAnimations.add(viewHolder);
            animate.setDuration(120).alpha(0.0f).setListener(new AnimatorListenerAdapter() {
                public final void onAnimationEnd(Animator animator) {
                    animate.setListener(null);
                    view.setAlpha(1.0f);
                    android.support.p002v7.widget.DefaultItemAnimator.this.dispatchAnimationFinished(viewHolder);
                    android.support.p002v7.widget.DefaultItemAnimator.this.mRemoveAnimations.remove(viewHolder);
                    android.support.p002v7.widget.DefaultItemAnimator.this.dispatchFinishedWhenDone();
                }

                public final void onAnimationStart(Animator animator) {
                }
            }).start();
        }
        r0.mPendingRemovals.clear();
        if (i2 != 0) {
            arrayList = new ArrayList();
            arrayList.addAll(r0.mPendingMoves);
            r0.mMovesList.add(arrayList);
            r0.mPendingMoves.clear();
            pg = new Runnable() {
                public final void run() {
                    List list = arrayList;
                    int size = list.size();
                    for (int i = 0; i < size; i++) {
                        MoveInfo moveInfo = (MoveInfo) list.get(i);
                        DefaultItemAnimator defaultItemAnimator = DefaultItemAnimator.this;
                        ViewHolder viewHolder = moveInfo.holder;
                        int i2 = moveInfo.fromX;
                        int i3 = moveInfo.fromY;
                        int i4 = moveInfo.toX;
                        int i5 = moveInfo.toY;
                        View view = viewHolder.itemView;
                        i4 -= i2;
                        i5 -= i3;
                        if (i4 != 0) {
                            view.animate().translationX(0.0f);
                        }
                        if (i5 != 0) {
                            view.animate().translationY(0.0f);
                        }
                        ViewPropertyAnimator animate = view.animate();
                        defaultItemAnimator.mMoveAnimations.add(viewHolder);
                        animate.setDuration(250).setListener(new C00996(viewHolder, i4, view, i5, animate)).start();
                    }
                    arrayList.clear();
                    DefaultItemAnimator.this.mMovesList.remove(arrayList);
                }
            };
            if (i != 0) {
                ViewCompat.postOnAnimationDelayed(((MoveInfo) arrayList.get(0)).holder.itemView, pg, 120);
            } else {
                pg.run();
            }
        }
        if (i3 != 0) {
            arrayList = new ArrayList();
            arrayList.addAll(r0.mPendingChanges);
            r0.mChangesList.add(arrayList);
            r0.mPendingChanges.clear();
            pg = new Runnable() {
                public final void run() {
                    List list = arrayList;
                    int size = list.size();
                    for (int i = 0; i < size; i++) {
                        View view;
                        ChangeInfo changeInfo = (ChangeInfo) list.get(i);
                        android.support.p002v7.widget.DefaultItemAnimator defaultItemAnimator = android.support.p002v7.widget.DefaultItemAnimator.this;
                        ViewHolder viewHolder = changeInfo.oldHolder;
                        View view2 = null;
                        if (viewHolder == null) {
                            view = null;
                        } else {
                            view = viewHolder.itemView;
                        }
                        ViewHolder viewHolder2 = changeInfo.newHolder;
                        if (viewHolder2 != null) {
                            view2 = viewHolder2.itemView;
                        }
                        if (view != null) {
                            ViewPropertyAnimator duration = view.animate().setDuration(250);
                            defaultItemAnimator.mChangeAnimations.add(changeInfo.oldHolder);
                            duration.translationX((float) (changeInfo.toX - changeInfo.fromX));
                            duration.translationY((float) (changeInfo.toY - changeInfo.fromY));
                            duration.alpha(0.0f).setListener(new C01007(changeInfo, duration, view)).start();
                        }
                        if (view2 != null) {
                            ViewPropertyAnimator animate = view2.animate();
                            defaultItemAnimator.mChangeAnimations.add(changeInfo.newHolder);
                            animate.translationX(0.0f).translationY(0.0f).setDuration(250).alpha(1.0f).setListener(new C01018(changeInfo, animate, view2)).start();
                        }
                    }
                    arrayList.clear();
                    android.support.p002v7.widget.DefaultItemAnimator.this.mChangesList.remove(arrayList);
                }
            };
            if (i != 0) {
                j = 120;
                ViewCompat.postOnAnimationDelayed(((ChangeInfo) arrayList.get(0)).oldHolder.itemView, pg, 120);
            } else {
                j = 120;
                pg.run();
            }
        } else {
            j = 120;
        }
        if (isEmpty4 != 0) {
            long j2;
            final ArrayList arrayList2 = new ArrayList();
            arrayList2.addAll(r0.mPendingAdditions);
            r0.mAdditionsList.add(arrayList2);
            r0.mPendingAdditions.clear();
            Runnable c00963 = new Runnable() {
                public final void run() {
                    List list = arrayList2;
                    int size = list.size();
                    for (int i = 0; i < size; i++) {
                        ViewHolder viewHolder = (ViewHolder) list.get(i);
                        android.support.p002v7.widget.DefaultItemAnimator defaultItemAnimator = android.support.p002v7.widget.DefaultItemAnimator.this;
                        View view = viewHolder.itemView;
                        ViewPropertyAnimator animate = view.animate();
                        defaultItemAnimator.mAddAnimations.add(viewHolder);
                        animate.alpha(1.0f).setDuration(120).setListener(new C00985(viewHolder, view, animate)).start();
                    }
                    arrayList2.clear();
                    android.support.p002v7.widget.DefaultItemAnimator.this.mAdditionsList.remove(arrayList2);
                }
            };
            if (i == 0 && i2 == 0) {
                if (i3 == 0) {
                    c00963.run();
                    return;
                }
            }
            long j3 = 0;
            if (true == isEmpty) {
                j = 0;
            }
            if (true != isEmpty2) {
                j2 = 250;
            } else {
                j2 = 0;
            }
            if (true != isEmpty3) {
                j3 = 250;
            }
            ViewCompat.postOnAnimationDelayed(((ViewHolder) arrayList2.get(0)).itemView, c00963, j + Math.max(j2, j3));
        }
    }

    private final boolean endChangeAnimationIfNecessary(ChangeInfo changeInfo, ViewHolder viewHolder) {
        if (changeInfo.newHolder == viewHolder) {
            changeInfo.newHolder = null;
        } else if (changeInfo.oldHolder != viewHolder) {
            return false;
        } else {
            changeInfo.oldHolder = null;
        }
        viewHolder.itemView.setAlpha(1.0f);
        viewHolder.itemView.setTranslationX(0.0f);
        viewHolder.itemView.setTranslationY(0.0f);
        dispatchAnimationFinished(viewHolder);
        return true;
    }
}
