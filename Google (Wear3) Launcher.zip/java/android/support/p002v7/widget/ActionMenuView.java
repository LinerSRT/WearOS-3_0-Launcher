package android.support.p002v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.support.p002v7.view.menu.ActionMenuItemView;
import android.support.p002v7.view.menu.BaseMenuPresenter;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.p002v7.view.menu.MenuBuilder.ItemInvoker;
import android.support.p002v7.view.menu.MenuItemImpl;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.support.p002v7.view.menu.MenuView;
import android.support.p002v7.widget.Toolbar.PG;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.accessibility.AccessibilityEvent;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ActionMenuView */
public class ActionMenuView extends LinearLayoutCompat implements ItemInvoker, MenuView {
    private boolean mFormatItems;
    private int mFormatItemsWidth;
    private int mGeneratedItemPadding;
    public MenuBuilder mMenu;
    private int mMinCellSize;
    PG mOnMenuItemClickListener$ar$class_merging;
    private Context mPopupContext;
    private int mPopupTheme;
    public ActionMenuPresenter mPresenter;
    public boolean mReserveOverflow;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuView$ActionMenuChildView */
    public interface ActionMenuChildView {
        boolean needsDividerAfter();

        boolean needsDividerBefore();
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuView$ActionMenuPresenterCallback */
    final class ActionMenuPresenterCallback implements Callback {
        public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        }

        public final boolean onOpenSubMenu(MenuBuilder menuBuilder) {
            return false;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuView$LayoutParams */
    public final class LayoutParams extends android.support.p002v7.widget.LinearLayoutCompat.LayoutParams {
        @ExportedProperty
        public int cellsUsed;
        @ExportedProperty
        public boolean expandable;
        boolean expanded;
        @ExportedProperty
        public int extraPixels;
        @ExportedProperty
        public boolean isOverflowButton;
        @ExportedProperty
        public boolean preventEdgeOffset;

        public LayoutParams() {
            super(-2);
            this.isOverflowButton = false;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((android.view.ViewGroup.LayoutParams) layoutParams);
            this.isOverflowButton = layoutParams.isOverflowButton;
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuView$MenuBuilderCallback */
    final class MenuBuilderCallback implements MenuBuilder.Callback {
        public final boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
            return false;
        }

        public final void onMenuModeChange$ar$ds() {
        }
    }

    public ActionMenuView(Context context) {
        this(context, null);
    }

    protected static final LayoutParams generateDefaultLayoutParams$ar$ds() {
        LayoutParams layoutParams = new LayoutParams();
        layoutParams.gravity = 16;
        return layoutParams;
    }

    protected static final LayoutParams generateLayoutParams$ar$ds$b524489_0(LayoutParams layoutParams) {
        if (layoutParams == null) {
            return ActionMenuView.generateDefaultLayoutParams$ar$ds();
        }
        LayoutParams layoutParams2 = layoutParams instanceof LayoutParams ? new LayoutParams((LayoutParams) layoutParams) : new LayoutParams(layoutParams);
        if (layoutParams2.gravity <= 0) {
            layoutParams2.gravity = 16;
        }
        return layoutParams2;
    }

    protected final boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public final void dismissPopupMenus() {
        ActionMenuPresenter actionMenuPresenter = this.mPresenter;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.dismissPopupMenus$ar$ds();
        }
    }

    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public final LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public final Menu getMenu() {
        if (this.mMenu == null) {
            Context context = getContext();
            MenuBuilder menuBuilder = new MenuBuilder(context);
            this.mMenu = menuBuilder;
            menuBuilder.setCallback(new MenuBuilderCallback());
            ActionMenuPresenter actionMenuPresenter = new ActionMenuPresenter(context);
            this.mPresenter = actionMenuPresenter;
            actionMenuPresenter.setReserveOverflow$ar$ds();
            this.mPresenter.mCallback = new ActionMenuPresenterCallback();
            this.mMenu.addMenuPresenter(this.mPresenter, this.mPopupContext);
            this.mPresenter.setMenuView(this);
        }
        return this.mMenu;
    }

    protected final boolean hasSupportDividerBeforeChildAt(int i) {
        boolean z = false;
        if (i == 0) {
            return false;
        }
        View childAt = getChildAt(i - 1);
        View childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof ActionMenuChildView)) {
            z = ((ActionMenuChildView) childAt).needsDividerAfter();
        }
        return (i <= 0 || !(childAt2 instanceof ActionMenuChildView)) ? z : ((ActionMenuChildView) childAt2).needsDividerBefore() | z;
    }

    public final void initialize(MenuBuilder menuBuilder) {
        this.mMenu = menuBuilder;
    }

    public final boolean invokeItem(MenuItemImpl menuItemImpl) {
        return this.mMenu.performItemAction(menuItemImpl, 0);
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        BaseMenuPresenter baseMenuPresenter = this.mPresenter;
        if (baseMenuPresenter != null) {
            baseMenuPresenter.updateMenuView$ar$ds();
            if (this.mPresenter.isOverflowMenuShowing()) {
                this.mPresenter.hideOverflowMenu();
                this.mPresenter.showOverflowMenu();
            }
        }
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        dismissPopupMenus();
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.mFormatItems) {
            int i5;
            int i6;
            int childCount = getChildCount();
            int i7 = (i4 - i2) / 2;
            int i8 = r0.mDividerWidth;
            int i9 = i3 - i;
            int paddingRight = (i9 - getPaddingRight()) - getPaddingLeft();
            boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
            int i10 = 0;
            int i11 = 0;
            for (i5 = 0; i5 < childCount; i5++) {
                View childAt = getChildAt(i5);
                if (childAt.getVisibility() != 8) {
                    LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                    if (layoutParams.isOverflowButton) {
                        int paddingLeft;
                        int i12;
                        i10 = childAt.getMeasuredWidth();
                        if (hasSupportDividerBeforeChildAt(i5)) {
                            i10 += i8;
                        }
                        int measuredHeight = childAt.getMeasuredHeight();
                        if (isLayoutRtl) {
                            paddingLeft = getPaddingLeft() + layoutParams.leftMargin;
                            i12 = paddingLeft + i10;
                        } else {
                            i12 = (getWidth() - getPaddingRight()) - layoutParams.rightMargin;
                            paddingLeft = i12 - i10;
                        }
                        i6 = i7 - (measuredHeight / 2);
                        childAt.layout(paddingLeft, i6, i12, measuredHeight + i6);
                        paddingRight -= i10;
                        i10 = 1;
                    } else {
                        paddingRight -= (childAt.getMeasuredWidth() + layoutParams.leftMargin) + layoutParams.rightMargin;
                        hasSupportDividerBeforeChildAt(i5);
                        i11++;
                    }
                }
            }
            if (childCount == 1) {
                if (i10 != 0) {
                    childCount = 1;
                } else {
                    View childAt2 = getChildAt(0);
                    i8 = childAt2.getMeasuredWidth();
                    paddingRight = childAt2.getMeasuredHeight();
                    i9 = (i9 / 2) - (i8 / 2);
                    i7 -= paddingRight / 2;
                    childAt2.layout(i9, i7, i8 + i9, paddingRight + i7);
                    return;
                }
            }
            i11 -= i10 ^ 1;
            if (i11 > 0) {
                i8 = paddingRight / i11;
            } else {
                i8 = 0;
            }
            i8 = Math.max(0, i8);
            View childAt3;
            LayoutParams layoutParams2;
            if (isLayoutRtl) {
                paddingRight = getWidth() - getPaddingRight();
                for (i6 = 0; i6 < childCount; i6++) {
                    childAt3 = getChildAt(i6);
                    layoutParams2 = (LayoutParams) childAt3.getLayoutParams();
                    if (!(childAt3.getVisibility() == 8 || layoutParams2.isOverflowButton)) {
                        paddingRight -= layoutParams2.rightMargin;
                        i5 = childAt3.getMeasuredWidth();
                        i10 = childAt3.getMeasuredHeight();
                        i11 = i7 - (i10 / 2);
                        childAt3.layout(paddingRight - i5, i11, paddingRight, i10 + i11);
                        paddingRight -= (i5 + layoutParams2.leftMargin) + i8;
                    }
                }
            } else {
                paddingRight = getPaddingLeft();
                for (i6 = 0; i6 < childCount; i6++) {
                    childAt3 = getChildAt(i6);
                    layoutParams2 = (LayoutParams) childAt3.getLayoutParams();
                    if (!(childAt3.getVisibility() == 8 || layoutParams2.isOverflowButton)) {
                        paddingRight += layoutParams2.leftMargin;
                        i5 = childAt3.getMeasuredWidth();
                        i10 = childAt3.getMeasuredHeight();
                        i11 = i7 - (i10 / 2);
                        childAt3.layout(paddingRight, i11, paddingRight + i5, i10 + i11);
                        paddingRight += (i5 + layoutParams2.rightMargin) + i8;
                    }
                }
            }
            return;
        }
        super.onLayout(z, i, i2, i3, i4);
    }

    protected final void onMeasure(int i, int i2) {
        boolean z;
        int i3;
        boolean z2 = this.mFormatItems;
        if (MeasureSpec.getMode(i) == 1073741824) {
            z = true;
        } else {
            z = false;
        }
        r0.mFormatItems = z;
        if (z2 != z) {
            r0.mFormatItemsWidth = 0;
        }
        int size = MeasureSpec.getSize(i);
        if (r0.mFormatItems) {
            MenuBuilder menuBuilder = r0.mMenu;
            if (!(menuBuilder == null || size == r0.mFormatItemsWidth)) {
                r0.mFormatItemsWidth = size;
                menuBuilder.onItemsChanged(true);
            }
        }
        size = getChildCount();
        int i4;
        if (!r0.mFormatItems) {
            i4 = i2;
            i3 = 0;
        } else if (size > 0) {
            size = MeasureSpec.getMode(i2);
            int size2 = MeasureSpec.getSize(i);
            i3 = MeasureSpec.getSize(i2);
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int paddingTop = getPaddingTop() + getPaddingBottom();
            int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, paddingTop, -2);
            size2 -= paddingLeft + paddingRight;
            paddingLeft = r0.mMinCellSize;
            paddingRight = size2 / paddingLeft;
            i4 = size2 % paddingLeft;
            if (paddingRight == 0) {
                setMeasuredDimension(size2, 0);
                return;
            }
            View childAt;
            int i5;
            int i6;
            int i7;
            Object obj;
            Object obj2;
            Object obj3;
            int i8;
            paddingLeft += i4 / paddingRight;
            i4 = getChildCount();
            int i9 = 0;
            int i10 = 0;
            int i11 = 0;
            int i12 = 0;
            long j = 0;
            int i13 = 0;
            int i14 = 0;
            while (i11 < i4) {
                int i15;
                childAt = getChildAt(i11);
                if (childAt.getVisibility() == 8) {
                    i5 = size2;
                    i6 = i3;
                    i15 = paddingTop;
                } else {
                    boolean z3;
                    ActionMenuItemView actionMenuItemView;
                    boolean z4 = childAt instanceof ActionMenuItemView;
                    i9++;
                    if (z4) {
                        i7 = r0.mGeneratedItemPadding;
                        i6 = i3;
                        z3 = false;
                        childAt.setPadding(i7, 0, i7, 0);
                    } else {
                        i6 = i3;
                        z3 = false;
                    }
                    LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                    layoutParams.expanded = z3;
                    layoutParams.extraPixels = z3;
                    layoutParams.cellsUsed = z3;
                    layoutParams.expandable = z3;
                    layoutParams.leftMargin = z3;
                    layoutParams.rightMargin = z3;
                    z3 = z4 && ((ActionMenuItemView) childAt).hasText();
                    layoutParams.preventEdgeOffset = z3;
                    int i16 = i9;
                    i3 = true != layoutParams.isOverflowButton ? paddingRight : 1;
                    LayoutParams layoutParams2 = (LayoutParams) childAt.getLayoutParams();
                    i5 = size2;
                    i15 = paddingTop;
                    size2 = MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(childMeasureSpec) - paddingTop, MeasureSpec.getMode(childMeasureSpec));
                    if (z4) {
                        actionMenuItemView = (ActionMenuItemView) childAt;
                    } else {
                        actionMenuItemView = null;
                    }
                    if (actionMenuItemView == null || !actionMenuItemView.hasText()) {
                        obj = null;
                    } else {
                        obj = 1;
                    }
                    if (i3 <= 0 || (obj != null && i3 < 2)) {
                        paddingTop = 0;
                    } else {
                        childAt.measure(MeasureSpec.makeMeasureSpec(i3 * paddingLeft, LinearLayoutManager.INVALID_OFFSET), size2);
                        i3 = childAt.getMeasuredWidth();
                        paddingTop = i3 / paddingLeft;
                        if (i3 % paddingLeft != 0) {
                            paddingTop++;
                        }
                        if (obj != null && r9 < 2) {
                            paddingTop = 2;
                        }
                    }
                    if (layoutParams2.isOverflowButton || obj == null) {
                        z4 = false;
                    } else {
                        z4 = true;
                    }
                    layoutParams2.expandable = z4;
                    layoutParams2.cellsUsed = paddingTop;
                    childAt.measure(MeasureSpec.makeMeasureSpec(paddingTop * paddingLeft, 1073741824), size2);
                    i13 = Math.max(i13, paddingTop);
                    if (layoutParams.expandable) {
                        i14++;
                    }
                    i12 |= layoutParams.isOverflowButton;
                    paddingRight -= paddingTop;
                    i10 = Math.max(i10, childAt.getMeasuredHeight());
                    if (paddingTop == 1) {
                        j |= (long) (1 << i11);
                    }
                    i9 = i16;
                }
                i11++;
                i3 = i6;
                paddingTop = i15;
                size2 = i5;
            }
            i5 = size2;
            i6 = i3;
            size2 = i13;
            if (i12 == 0 || i9 != 2) {
                obj2 = null;
            } else {
                obj2 = 1;
                i9 = 2;
            }
            obj = null;
            while (i14 > 0 && paddingRight > 0) {
                LayoutParams layoutParams3;
                int i17;
                paddingTop = Integer.MAX_VALUE;
                i7 = 0;
                i11 = 0;
                long j2 = 0;
                while (i7 < i4) {
                    layoutParams3 = (LayoutParams) getChildAt(i7).getLayoutParams();
                    obj3 = obj;
                    if (layoutParams3.expandable) {
                        i17 = layoutParams3.cellsUsed;
                        if (i17 < paddingTop) {
                            j2 = 1 << i7;
                            paddingTop = i17;
                            i11 = 1;
                        } else if (i17 == paddingTop) {
                            j2 |= 1 << i7;
                            i11++;
                        }
                    }
                    i7++;
                    obj = obj3;
                }
                obj3 = obj;
                j |= j2;
                if (i11 > paddingRight) {
                    i8 = i10;
                    break;
                }
                paddingTop++;
                i17 = 0;
                while (i17 < i4) {
                    View childAt2 = getChildAt(i17);
                    layoutParams3 = (LayoutParams) childAt2.getLayoutParams();
                    i8 = i10;
                    long j3 = (long) (1 << i17);
                    if ((j2 & j3) != 0) {
                        if (obj2 != null && layoutParams3.preventEdgeOffset && r8 == 1) {
                            paddingRight = r0.mGeneratedItemPadding;
                            childAt2.setPadding(paddingRight + paddingLeft, 0, paddingRight, 0);
                            paddingRight = 1;
                        }
                        layoutParams3.cellsUsed++;
                        layoutParams3.expanded = true;
                        paddingRight--;
                    } else if (layoutParams3.cellsUsed == paddingTop) {
                        j |= j3;
                    }
                    i17++;
                    i10 = i8;
                }
                i8 = i10;
                obj = 1;
            }
            obj3 = obj;
            i8 = i10;
            if (i12 == 0 && r12 == 1) {
                obj2 = 1;
                i9 = 1;
            } else {
                obj2 = null;
            }
            if (paddingRight <= 0 || j == 0 || (paddingRight >= r12 - 1 && obj2 == null && size2 <= 1)) {
                obj = obj3;
            } else {
                float bitCount = (float) Long.bitCount(j);
                if (obj2 == null) {
                    if (!((j & 1) == 0 || ((LayoutParams) getChildAt(0).getLayoutParams()).preventEdgeOffset)) {
                        bitCount -= 8.0f;
                    }
                    int i18 = i4 - 1;
                    if (!((j & ((long) (1 << i18))) == 0 || ((LayoutParams) getChildAt(i18).getLayoutParams()).preventEdgeOffset)) {
                        bitCount -= 8.0f;
                    }
                }
                if (bitCount > 0.0f) {
                    i3 = (int) (((float) (paddingRight * paddingLeft)) / bitCount);
                } else {
                    i3 = 0;
                }
                Object obj4 = obj3;
                size2 = 0;
                while (size2 < i4) {
                    if ((j & ((long) (1 << size2))) != 0) {
                        childAt = getChildAt(size2);
                        LayoutParams layoutParams4 = (LayoutParams) childAt.getLayoutParams();
                        if (childAt instanceof ActionMenuItemView) {
                            layoutParams4.extraPixels = i3;
                            layoutParams4.expanded = true;
                            if (size2 == 0) {
                                if (!layoutParams4.preventEdgeOffset) {
                                    layoutParams4.leftMargin = (-i3) / 2;
                                }
                                size2 = 0;
                            }
                            obj4 = 1;
                        } else if (layoutParams4.isOverflowButton) {
                            layoutParams4.extraPixels = i3;
                            layoutParams4.expanded = true;
                            layoutParams4.rightMargin = (-i3) / 2;
                            obj4 = 1;
                        } else {
                            if (size2 != 0) {
                                layoutParams4.leftMargin = i3 / 2;
                            }
                            if (size2 != i4 - 1) {
                                layoutParams4.rightMargin = i3 / 2;
                            }
                        }
                    }
                    size2++;
                }
                obj = obj4;
            }
            if (obj != null) {
                for (i7 = 0; i7 < i4; i7++) {
                    View childAt3 = getChildAt(i7);
                    LayoutParams layoutParams5 = (LayoutParams) childAt3.getLayoutParams();
                    if (layoutParams5.expanded) {
                        childAt3.measure(MeasureSpec.makeMeasureSpec((layoutParams5.cellsUsed * paddingLeft) + layoutParams5.extraPixels, 1073741824), childMeasureSpec);
                    }
                }
            }
            if (size != 1073741824) {
                i3 = i8;
            } else {
                i3 = i6;
            }
            setMeasuredDimension(i5, i3);
            return;
        } else {
            i4 = i2;
            i3 = 0;
        }
        while (i3 < size) {
            LayoutParams layoutParams6 = (LayoutParams) getChildAt(i3).getLayoutParams();
            layoutParams6.rightMargin = 0;
            layoutParams6.leftMargin = 0;
            i3++;
        }
        super.onMeasure(i, i2);
    }

    public final void setPopupTheme(int i) {
        if (this.mPopupTheme != i) {
            this.mPopupTheme = i;
            if (i == 0) {
                this.mPopupContext = getContext();
                return;
            }
            this.mPopupContext = new ContextThemeWrapper(getContext(), i);
        }
    }

    public final void setPresenter(ActionMenuPresenter actionMenuPresenter) {
        this.mPresenter = actionMenuPresenter;
        actionMenuPresenter.setMenuView(this);
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned$ar$ds();
        float f = context.getResources().getDisplayMetrics().density;
        this.mMinCellSize = (int) (56.0f * f);
        this.mGeneratedItemPadding = (int) (f * 4.0f);
        this.mPopupContext = context;
        this.mPopupTheme = 0;
    }
}
