package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.LayoutManager.LayoutPrefetchRegistry;
import android.support.p002v7.widget.RecyclerView.LayoutManager.Properties;
import android.support.p002v7.widget.RecyclerView.LayoutParams;
import android.support.p002v7.widget.RecyclerView.Recycler;
import android.support.p002v7.widget.RecyclerView.SmoothScroller;
import android.support.p002v7.widget.RecyclerView.SmoothScroller.ScrollVectorProvider;
import android.support.p002v7.widget.RecyclerView.State;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.LinearLayoutManager */
public class LinearLayoutManager extends LayoutManager implements ScrollVectorProvider {
    static final boolean DEBUG = false;
    public static final int HORIZONTAL = 0;
    public static final int INVALID_OFFSET = Integer.MIN_VALUE;
    private static final float MAX_SCROLL_FACTOR = 0.33333334f;
    private static final String TAG = "LinearLayoutManager";
    public static final int VERTICAL = 1;
    final AnchorInfo mAnchorInfo;
    private int mInitialPrefetchItemCount;
    private boolean mLastStackFromEnd;
    private final LayoutChunkResult mLayoutChunkResult;
    private LayoutState mLayoutState;
    int mOrientation;
    OrientationHelper mOrientationHelper;
    SavedState mPendingSavedState;
    int mPendingScrollPosition;
    int mPendingScrollPositionOffset;
    private boolean mRecycleChildrenOnDetach;
    private int[] mReusableIntPair;
    private boolean mReverseLayout;
    boolean mShouldReverseLayout;
    private boolean mSmoothScrollbarEnabled;
    private boolean mStackFromEnd;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.LinearLayoutManager$AnchorInfo */
    final class AnchorInfo {
        int mCoordinate;
        boolean mLayoutFromEnd;
        OrientationHelper mOrientationHelper;
        int mPosition;
        boolean mValid;

        public AnchorInfo() {
            reset();
        }

        final void assignCoordinateFromPadding() {
            this.mCoordinate = this.mLayoutFromEnd ? this.mOrientationHelper.getEndAfterPadding() : this.mOrientationHelper.getStartAfterPadding();
        }

        public final void assignFromView(View view, int i) {
            if (this.mLayoutFromEnd) {
                this.mCoordinate = this.mOrientationHelper.getDecoratedEnd(view) + this.mOrientationHelper.getTotalSpaceChange();
            } else {
                this.mCoordinate = this.mOrientationHelper.getDecoratedStart(view);
            }
            this.mPosition = i;
        }

        public final void assignFromViewAndKeepVisibleRect(View view, int i) {
            int totalSpaceChange = this.mOrientationHelper.getTotalSpaceChange();
            if (totalSpaceChange >= 0) {
                assignFromView(view, i);
                return;
            }
            this.mPosition = i;
            int i2;
            if (this.mLayoutFromEnd) {
                i = (this.mOrientationHelper.getEndAfterPadding() - totalSpaceChange) - this.mOrientationHelper.getDecoratedEnd(view);
                this.mCoordinate = this.mOrientationHelper.getEndAfterPadding() - i;
                if (i > 0) {
                    totalSpaceChange = this.mOrientationHelper.getDecoratedMeasurement(view);
                    i2 = this.mCoordinate;
                    int startAfterPadding = this.mOrientationHelper.getStartAfterPadding();
                    i2 = (i2 - totalSpaceChange) - (startAfterPadding + Math.min(this.mOrientationHelper.getDecoratedStart(view) - startAfterPadding, 0));
                    if (i2 < 0) {
                        this.mCoordinate += Math.min(i, -i2);
                        return;
                    }
                }
            }
            i = this.mOrientationHelper.getDecoratedStart(view);
            i2 = i - this.mOrientationHelper.getStartAfterPadding();
            this.mCoordinate = i;
            if (i2 > 0) {
                startAfterPadding = this.mOrientationHelper.getDecoratedMeasurement(view);
                int endAfterPadding = this.mOrientationHelper.getEndAfterPadding();
                int endAfterPadding2 = (this.mOrientationHelper.getEndAfterPadding() - Math.min(0, (endAfterPadding - totalSpaceChange) - this.mOrientationHelper.getDecoratedEnd(view))) - (i + startAfterPadding);
                if (endAfterPadding2 < 0) {
                    this.mCoordinate -= Math.min(i2, -endAfterPadding2);
                }
            }
        }

        final void reset() {
            this.mPosition = -1;
            this.mCoordinate = LinearLayoutManager.INVALID_OFFSET;
            this.mLayoutFromEnd = LinearLayoutManager.DEBUG;
            this.mValid = LinearLayoutManager.DEBUG;
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("AnchorInfo{mPosition=");
            stringBuilder.append(this.mPosition);
            stringBuilder.append(", mCoordinate=");
            stringBuilder.append(this.mCoordinate);
            stringBuilder.append(", mLayoutFromEnd=");
            stringBuilder.append(this.mLayoutFromEnd);
            stringBuilder.append(", mValid=");
            stringBuilder.append(this.mValid);
            stringBuilder.append('}');
            return stringBuilder.toString();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.LinearLayoutManager$LayoutChunkResult */
    public final class LayoutChunkResult {
        public int mConsumed;
        public boolean mFinished;
        public boolean mFocusable;
        public boolean mIgnoreConsumed;

        protected LayoutChunkResult() {
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.LinearLayoutManager$LayoutState */
    final class LayoutState {
        int mAvailable;
        int mCurrentPosition;
        int mExtraFillSpace = 0;
        boolean mInfinite;
        boolean mIsPreLayout = LinearLayoutManager.DEBUG;
        int mItemDirection;
        int mLastScrollDelta;
        int mLayoutDirection;
        int mNoRecycleSpace = 0;
        int mOffset;
        boolean mRecycle = true;
        List mScrapList = null;
        int mScrollingOffset;

        public final void assignPositionFromScrapList() {
            assignPositionFromScrapList(null);
        }

        final boolean hasMore(State state) {
            int i = this.mCurrentPosition;
            return (i < 0 || i >= state.getItemCount()) ? LinearLayoutManager.DEBUG : true;
        }

        final View next(Recycler recycler) {
            List list = this.mScrapList;
            if (list != null) {
                View view;
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    view = ((ViewHolder) this.mScrapList.get(i)).itemView;
                    LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
                    if (!layoutParams.isItemRemoved()) {
                        if (this.mCurrentPosition == layoutParams.getViewLayoutPosition()) {
                            assignPositionFromScrapList(view);
                            break;
                        }
                    }
                }
                view = null;
                return view;
            }
            View viewForPosition = recycler.getViewForPosition(this.mCurrentPosition);
            this.mCurrentPosition += this.mItemDirection;
            return viewForPosition;
        }

        public final void assignPositionFromScrapList(View view) {
            int size = this.mScrapList.size();
            View view2 = null;
            int i = Integer.MAX_VALUE;
            for (int i2 = 0; i2 < size; i2++) {
                View view3 = ((ViewHolder) this.mScrapList.get(i2)).itemView;
                LayoutParams layoutParams = (LayoutParams) view3.getLayoutParams();
                if (view3 != view) {
                    if (!layoutParams.isItemRemoved()) {
                        int viewLayoutPosition = (layoutParams.getViewLayoutPosition() - this.mCurrentPosition) * this.mItemDirection;
                        if (viewLayoutPosition >= 0) {
                            if (viewLayoutPosition < i) {
                                if (viewLayoutPosition == 0) {
                                    view2 = view3;
                                    break;
                                } else {
                                    view2 = view3;
                                    i = viewLayoutPosition;
                                }
                            }
                        }
                    }
                }
            }
            if (view2 == null) {
                this.mCurrentPosition = -1;
            } else {
                this.mCurrentPosition = ((LayoutParams) view2.getLayoutParams()).getViewLayoutPosition();
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.LinearLayoutManager$SavedState */
    public final class SavedState implements Parcelable {
        public static final Creator CREATOR = new PG();
        boolean mAnchorLayoutFromEnd;
        int mAnchorOffset;
        int mAnchorPosition;

        /* renamed from: android.support.v7.widget.LinearLayoutManager$SavedState$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new SavedState[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }
        }

        public SavedState(SavedState savedState) {
            this.mAnchorPosition = savedState.mAnchorPosition;
            this.mAnchorOffset = savedState.mAnchorOffset;
            this.mAnchorLayoutFromEnd = savedState.mAnchorLayoutFromEnd;
        }

        public final int describeContents() {
            return 0;
        }

        final boolean hasValidAnchor() {
            return this.mAnchorPosition >= 0 ? true : LinearLayoutManager.DEBUG;
        }

        final void invalidateAnchor() {
            this.mAnchorPosition = -1;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.mAnchorPosition);
            parcel.writeInt(this.mAnchorOffset);
            parcel.writeInt(this.mAnchorLayoutFromEnd);
        }

        public SavedState(Parcel parcel) {
            this.mAnchorPosition = parcel.readInt();
            this.mAnchorOffset = parcel.readInt();
            boolean z = true;
            if (parcel.readInt() != 1) {
                z = LinearLayoutManager.DEBUG;
            }
            this.mAnchorLayoutFromEnd = z;
        }
    }

    public LinearLayoutManager(Context context) {
        this(context, 1, DEBUG);
    }

    private int computeScrollExtent(State state) {
        if (getChildCount() == 0) {
            return 0;
        }
        ensureLayoutState();
        return ScrollbarHelper.computeScrollExtent(state, this.mOrientationHelper, findFirstVisibleChildClosestToStart(this.mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToEnd(this.mSmoothScrollbarEnabled ^ true, true), this, this.mSmoothScrollbarEnabled);
    }

    private int computeScrollOffset(State state) {
        if (getChildCount() == 0) {
            return 0;
        }
        ensureLayoutState();
        return ScrollbarHelper.computeScrollOffset(state, this.mOrientationHelper, findFirstVisibleChildClosestToStart(this.mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToEnd(this.mSmoothScrollbarEnabled ^ true, true), this, this.mSmoothScrollbarEnabled, this.mShouldReverseLayout);
    }

    private int computeScrollRange(State state) {
        if (getChildCount() == 0) {
            return 0;
        }
        ensureLayoutState();
        return ScrollbarHelper.computeScrollRange(state, this.mOrientationHelper, findFirstVisibleChildClosestToStart(this.mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToEnd(this.mSmoothScrollbarEnabled ^ true, true), this, this.mSmoothScrollbarEnabled);
    }

    private View findFirstPartiallyOrCompletelyInvisibleChild() {
        return findOnePartiallyOrCompletelyInvisibleChild(0, getChildCount());
    }

    private View findLastPartiallyOrCompletelyInvisibleChild() {
        return findOnePartiallyOrCompletelyInvisibleChild(getChildCount() - 1, -1);
    }

    private View findPartiallyOrCompletelyInvisibleChildClosestToEnd() {
        return this.mShouldReverseLayout ? findFirstPartiallyOrCompletelyInvisibleChild() : findLastPartiallyOrCompletelyInvisibleChild();
    }

    private View findPartiallyOrCompletelyInvisibleChildClosestToStart() {
        return this.mShouldReverseLayout ? findLastPartiallyOrCompletelyInvisibleChild() : findFirstPartiallyOrCompletelyInvisibleChild();
    }

    private int fixLayoutEndGap(int i, Recycler recycler, State state, boolean z) {
        int endAfterPadding = this.mOrientationHelper.getEndAfterPadding() - i;
        if (endAfterPadding <= 0) {
            return 0;
        }
        int i2 = -scrollBy(-endAfterPadding, recycler, state);
        i += i2;
        if (z) {
            int endAfterPadding2 = this.mOrientationHelper.getEndAfterPadding() - i;
            if (endAfterPadding2 > 0) {
                this.mOrientationHelper.offsetChildren(endAfterPadding2);
                return endAfterPadding2 + i2;
            }
        }
        return i2;
    }

    private int fixLayoutStartGap(int i, Recycler recycler, State state, boolean z) {
        int startAfterPadding = i - this.mOrientationHelper.getStartAfterPadding();
        if (startAfterPadding <= 0) {
            return 0;
        }
        int i2 = -scrollBy(startAfterPadding, recycler, state);
        i += i2;
        if (z) {
            i -= this.mOrientationHelper.getStartAfterPadding();
            if (i > 0) {
                this.mOrientationHelper.offsetChildren(-i);
                i2 -= i;
            }
        }
        return i2;
    }

    private View getChildClosestToEnd() {
        return getChildAt(this.mShouldReverseLayout ? 0 : getChildCount() - 1);
    }

    private View getChildClosestToStart() {
        return getChildAt(this.mShouldReverseLayout ? getChildCount() - 1 : 0);
    }

    private void layoutForPredictiveAnimations(Recycler recycler, State state, int i, int i2) {
        if (!(!state.mRunPredictiveAnimations || getChildCount() == 0 || state.mInPreLayout)) {
            if (supportsPredictiveItemAnimations()) {
                LayoutState layoutState;
                List list = recycler.mUnmodifiableAttachedScrap;
                int size = list.size();
                int position = getPosition(getChildAt(0));
                int i3 = 0;
                int i4 = 0;
                for (int i5 = 0; i5 < size; i5++) {
                    ViewHolder viewHolder = (ViewHolder) list.get(i5);
                    if (!viewHolder.isRemoved()) {
                        boolean z;
                        if (viewHolder.getLayoutPosition() >= position) {
                            z = DEBUG;
                        } else {
                            z = true;
                        }
                        if (z != this.mShouldReverseLayout) {
                            i3 += this.mOrientationHelper.getDecoratedMeasurement(viewHolder.itemView);
                        } else {
                            i4 += this.mOrientationHelper.getDecoratedMeasurement(viewHolder.itemView);
                        }
                    }
                }
                this.mLayoutState.mScrapList = list;
                if (i3 > 0) {
                    updateLayoutStateToFillStart(getPosition(getChildClosestToStart()), i);
                    layoutState = this.mLayoutState;
                    layoutState.mExtraFillSpace = i3;
                    layoutState.mAvailable = 0;
                    layoutState.assignPositionFromScrapList();
                    fill(recycler, this.mLayoutState, state, DEBUG);
                }
                if (i4 > 0) {
                    updateLayoutStateToFillEnd(getPosition(getChildClosestToEnd()), i2);
                    layoutState = this.mLayoutState;
                    layoutState.mExtraFillSpace = i4;
                    layoutState.mAvailable = 0;
                    layoutState.assignPositionFromScrapList();
                    fill(recycler, this.mLayoutState, state, DEBUG);
                }
                this.mLayoutState.mScrapList = null;
            }
        }
    }

    private void logChildren() {
        String str = TAG;
        Log.d(str, "internal representation of views on the screen");
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("item ");
            stringBuilder.append(getPosition(childAt));
            stringBuilder.append(", coord:");
            stringBuilder.append(this.mOrientationHelper.getDecoratedStart(childAt));
            Log.d(str, stringBuilder.toString());
        }
        Log.d(str, "==============");
    }

    private void recycleByLayoutState(Recycler recycler, LayoutState layoutState) {
        if (layoutState.mRecycle) {
            if (!layoutState.mInfinite) {
                int i = layoutState.mScrollingOffset;
                int i2 = layoutState.mNoRecycleSpace;
                if (layoutState.mLayoutDirection == -1) {
                    recycleViewsFromEnd(recycler, i, i2);
                } else {
                    recycleViewsFromStart(recycler, i, i2);
                }
            }
        }
    }

    private void recycleViewsFromEnd(Recycler recycler, int i, int i2) {
        int childCount = getChildCount();
        if (i >= 0) {
            int end = (this.mOrientationHelper.getEnd() - i) + i2;
            if (this.mShouldReverseLayout) {
                i2 = 0;
                while (i2 < childCount) {
                    View childAt = getChildAt(i2);
                    if (this.mOrientationHelper.getDecoratedStart(childAt) >= end) {
                        if (this.mOrientationHelper.getTransformedStartWithDecoration(childAt) >= end) {
                            i2++;
                        }
                    }
                    recycleChildren(recycler, 0, i2);
                    return;
                }
            }
            childCount--;
            i = childCount;
            while (i >= 0) {
                View childAt2 = getChildAt(i);
                if (this.mOrientationHelper.getDecoratedStart(childAt2) >= end) {
                    if (this.mOrientationHelper.getTransformedStartWithDecoration(childAt2) >= end) {
                        i--;
                    }
                }
                recycleChildren(recycler, childCount, i);
                return;
            }
        }
    }

    private void recycleViewsFromStart(Recycler recycler, int i, int i2) {
        if (i >= 0) {
            i -= i2;
            i2 = getChildCount();
            if (this.mShouldReverseLayout) {
                i2--;
                int i3 = i2;
                while (i3 >= 0) {
                    View childAt = getChildAt(i3);
                    if (this.mOrientationHelper.getDecoratedEnd(childAt) <= i) {
                        if (this.mOrientationHelper.getTransformedEndWithDecoration(childAt) <= i) {
                            i3--;
                        }
                    }
                    recycleChildren(recycler, i2, i3);
                    return;
                }
            }
            int i4 = 0;
            while (i4 < i2) {
                View childAt2 = getChildAt(i4);
                if (this.mOrientationHelper.getDecoratedEnd(childAt2) <= i) {
                    if (this.mOrientationHelper.getTransformedEndWithDecoration(childAt2) <= i) {
                        i4++;
                    }
                }
                recycleChildren(recycler, 0, i4);
                return;
            }
        }
    }

    private void resolveShouldLayoutReverse() {
        boolean z;
        if (this.mOrientation != 1) {
            if (isLayoutRTL()) {
                z = this.mReverseLayout ^ true;
                this.mShouldReverseLayout = z;
            }
        }
        z = this.mReverseLayout;
        this.mShouldReverseLayout = z;
    }

    private boolean updateAnchorFromChildren(Recycler recycler, State state, AnchorInfo anchorInfo) {
        int childCount = getChildCount();
        boolean z = DEBUG;
        if (childCount == 0) {
            return DEBUG;
        }
        View focusedChild = getFocusedChild();
        if (focusedChild != null) {
            LayoutParams layoutParams = (LayoutParams) focusedChild.getLayoutParams();
            if (!layoutParams.isItemRemoved() && layoutParams.getViewLayoutPosition() >= 0) {
                if (layoutParams.getViewLayoutPosition() < state.getItemCount()) {
                    anchorInfo.assignFromViewAndKeepVisibleRect(focusedChild, getPosition(focusedChild));
                    return true;
                }
            }
        }
        boolean z2 = this.mLastStackFromEnd;
        boolean z3 = this.mStackFromEnd;
        if (z2 != z3) {
            return DEBUG;
        }
        View findReferenceChild = findReferenceChild(recycler, state, anchorInfo.mLayoutFromEnd, z3);
        if (findReferenceChild == null) {
            return DEBUG;
        }
        anchorInfo.assignFromView(findReferenceChild, getPosition(findReferenceChild));
        if (!state.mInPreLayout && supportsPredictiveItemAnimations()) {
            Object obj;
            int decoratedStart = this.mOrientationHelper.getDecoratedStart(findReferenceChild);
            int decoratedEnd = this.mOrientationHelper.getDecoratedEnd(findReferenceChild);
            childCount = this.mOrientationHelper.getStartAfterPadding();
            int endAfterPadding = this.mOrientationHelper.getEndAfterPadding();
            if (decoratedEnd > childCount || decoratedStart >= childCount) {
                obj = null;
            } else {
                obj = 1;
            }
            if (decoratedStart >= endAfterPadding && decoratedEnd > endAfterPadding) {
                z = true;
            }
            if (obj != null || z) {
                if (true == anchorInfo.mLayoutFromEnd) {
                    childCount = endAfterPadding;
                }
                anchorInfo.mCoordinate = childCount;
            }
        }
        return true;
    }

    private boolean updateAnchorFromPendingData(State state, AnchorInfo anchorInfo) {
        boolean z = state.mInPreLayout;
        boolean z2 = DEBUG;
        if (!z) {
            int i = this.mPendingScrollPosition;
            if (i != -1) {
                if (i >= 0) {
                    if (i < state.getItemCount()) {
                        anchorInfo.mPosition = this.mPendingScrollPosition;
                        SavedState savedState = this.mPendingSavedState;
                        boolean z3;
                        if (savedState != null && savedState.hasValidAnchor()) {
                            z3 = this.mPendingSavedState.mAnchorLayoutFromEnd;
                            anchorInfo.mLayoutFromEnd = z3;
                            if (z3) {
                                anchorInfo.mCoordinate = this.mOrientationHelper.getEndAfterPadding() - this.mPendingSavedState.mAnchorOffset;
                            } else {
                                anchorInfo.mCoordinate = this.mOrientationHelper.getStartAfterPadding() + this.mPendingSavedState.mAnchorOffset;
                            }
                            return true;
                        } else if (this.mPendingScrollPositionOffset == INVALID_OFFSET) {
                            View findViewByPosition = findViewByPosition(this.mPendingScrollPosition);
                            if (findViewByPosition == null) {
                                if (getChildCount() > 0) {
                                    if (this.mPendingScrollPosition >= getPosition(getChildAt(0))) {
                                        z3 = DEBUG;
                                    } else {
                                        z3 = true;
                                    }
                                    if (z3 == this.mShouldReverseLayout) {
                                        z2 = true;
                                    }
                                    anchorInfo.mLayoutFromEnd = z2;
                                }
                                anchorInfo.assignCoordinateFromPadding();
                            } else if (this.mOrientationHelper.getDecoratedMeasurement(findViewByPosition) > this.mOrientationHelper.getTotalSpace()) {
                                anchorInfo.assignCoordinateFromPadding();
                                return true;
                            } else if (this.mOrientationHelper.getDecoratedStart(findViewByPosition) - this.mOrientationHelper.getStartAfterPadding() < 0) {
                                anchorInfo.mCoordinate = this.mOrientationHelper.getStartAfterPadding();
                                anchorInfo.mLayoutFromEnd = DEBUG;
                                return true;
                            } else if (this.mOrientationHelper.getEndAfterPadding() - this.mOrientationHelper.getDecoratedEnd(findViewByPosition) < 0) {
                                anchorInfo.mCoordinate = this.mOrientationHelper.getEndAfterPadding();
                                anchorInfo.mLayoutFromEnd = true;
                                return true;
                            } else {
                                anchorInfo.mCoordinate = anchorInfo.mLayoutFromEnd ? this.mOrientationHelper.getDecoratedEnd(findViewByPosition) + this.mOrientationHelper.getTotalSpaceChange() : this.mOrientationHelper.getDecoratedStart(findViewByPosition);
                            }
                            return true;
                        } else {
                            z3 = this.mShouldReverseLayout;
                            anchorInfo.mLayoutFromEnd = z3;
                            if (z3) {
                                anchorInfo.mCoordinate = this.mOrientationHelper.getEndAfterPadding() - this.mPendingScrollPositionOffset;
                            } else {
                                anchorInfo.mCoordinate = this.mOrientationHelper.getStartAfterPadding() + this.mPendingScrollPositionOffset;
                            }
                            return true;
                        }
                    }
                }
                this.mPendingScrollPosition = -1;
                this.mPendingScrollPositionOffset = INVALID_OFFSET;
            }
        }
        return DEBUG;
    }

    private void updateAnchorInfoForLayout(Recycler recycler, State state, AnchorInfo anchorInfo) {
        if (!updateAnchorFromPendingData(state, anchorInfo) && !updateAnchorFromChildren(recycler, state, anchorInfo)) {
            anchorInfo.assignCoordinateFromPadding();
            anchorInfo.mPosition = this.mStackFromEnd ? state.getItemCount() - 1 : 0;
        }
    }

    private void updateLayoutState(int i, int i2, boolean z, State state) {
        int i3;
        this.mLayoutState.mInfinite = resolveIsInfinite();
        this.mLayoutState.mLayoutDirection = i;
        int[] iArr = this.mReusableIntPair;
        iArr[0] = 0;
        int i4 = 1;
        iArr[1] = 0;
        calculateExtraLayoutSpace(state, iArr);
        int max = Math.max(0, this.mReusableIntPair[0]);
        int max2 = Math.max(0, this.mReusableIntPair[1]);
        LayoutState layoutState = this.mLayoutState;
        if (i == 1) {
            i3 = max2;
        } else {
            i3 = max;
        }
        layoutState.mExtraFillSpace = i3;
        if (i != 1) {
            max = max2;
        }
        layoutState.mNoRecycleSpace = max;
        View childClosestToEnd;
        LayoutState layoutState2;
        if (i == 1) {
            layoutState.mExtraFillSpace = i3 + this.mOrientationHelper.getEndPadding();
            childClosestToEnd = getChildClosestToEnd();
            layoutState2 = this.mLayoutState;
            if (true == this.mShouldReverseLayout) {
                i4 = -1;
            }
            layoutState2.mItemDirection = i4;
            max = getPosition(childClosestToEnd);
            layoutState = this.mLayoutState;
            layoutState2.mCurrentPosition = max + layoutState.mItemDirection;
            layoutState.mOffset = this.mOrientationHelper.getDecoratedEnd(childClosestToEnd);
            i = this.mOrientationHelper.getDecoratedEnd(childClosestToEnd) - this.mOrientationHelper.getEndAfterPadding();
        } else {
            childClosestToEnd = getChildClosestToStart();
            layoutState2 = this.mLayoutState;
            layoutState2.mExtraFillSpace += this.mOrientationHelper.getStartAfterPadding();
            layoutState2 = this.mLayoutState;
            if (true != this.mShouldReverseLayout) {
                i4 = -1;
            }
            layoutState2.mItemDirection = i4;
            max = getPosition(childClosestToEnd);
            layoutState = this.mLayoutState;
            layoutState2.mCurrentPosition = max + layoutState.mItemDirection;
            layoutState.mOffset = this.mOrientationHelper.getDecoratedStart(childClosestToEnd);
            i = (-this.mOrientationHelper.getDecoratedStart(childClosestToEnd)) + this.mOrientationHelper.getStartAfterPadding();
        }
        LayoutState layoutState3 = this.mLayoutState;
        layoutState3.mAvailable = i2;
        if (z) {
            layoutState3.mAvailable = i2 - i;
        }
        layoutState3.mScrollingOffset = i;
    }

    private void updateLayoutStateToFillEnd(int i, int i2) {
        int i3;
        this.mLayoutState.mAvailable = this.mOrientationHelper.getEndAfterPadding() - i2;
        LayoutState layoutState = this.mLayoutState;
        if (true != this.mShouldReverseLayout) {
            i3 = 1;
        } else {
            i3 = -1;
        }
        layoutState.mItemDirection = i3;
        layoutState.mCurrentPosition = i;
        layoutState.mLayoutDirection = 1;
        layoutState.mOffset = i2;
        layoutState.mScrollingOffset = INVALID_OFFSET;
    }

    private void updateLayoutStateToFillStart(int i, int i2) {
        this.mLayoutState.mAvailable = i2 - this.mOrientationHelper.getStartAfterPadding();
        LayoutState layoutState = this.mLayoutState;
        layoutState.mCurrentPosition = i;
        int i3 = 1;
        if (true != this.mShouldReverseLayout) {
            i3 = -1;
        }
        layoutState.mItemDirection = i3;
        layoutState.mLayoutDirection = -1;
        layoutState.mOffset = i2;
        layoutState.mScrollingOffset = INVALID_OFFSET;
    }

    public void assertNotInLayoutOrScroll(String str) {
        if (this.mPendingSavedState == null) {
            super.assertNotInLayoutOrScroll(str);
        }
    }

    protected void calculateExtraLayoutSpace(State state, int[] iArr) {
        int i;
        int extraLayoutSpace = getExtraLayoutSpace(state);
        int i2 = this.mLayoutState.mLayoutDirection;
        if (i2 == -1) {
            i = 0;
        } else {
            i = extraLayoutSpace;
        }
        if (i2 != -1) {
            extraLayoutSpace = 0;
        }
        iArr[0] = extraLayoutSpace;
        iArr[1] = i;
    }

    public boolean canScrollHorizontally() {
        return this.mOrientation == 0 ? true : DEBUG;
    }

    public boolean canScrollVertically() {
        return this.mOrientation == 1 ? true : DEBUG;
    }

    public void collectAdjacentPrefetchPositions(int i, int i2, State state, LayoutPrefetchRegistry layoutPrefetchRegistry) {
        if (this.mOrientation != 0) {
            i = i2;
        }
        if (getChildCount() != 0) {
            if (i != 0) {
                int i3;
                ensureLayoutState();
                if (i > 0) {
                    i3 = 1;
                } else {
                    i3 = -1;
                }
                updateLayoutState(i3, Math.abs(i), true, state);
                collectPrefetchPositionsForLayoutState(state, this.mLayoutState, layoutPrefetchRegistry);
            }
        }
    }

    public void collectPrefetchPositionsForLayoutState(State state, LayoutState layoutState, LayoutPrefetchRegistry layoutPrefetchRegistry) {
        int i = layoutState.mCurrentPosition;
        if (i >= 0 && i < state.getItemCount()) {
            layoutPrefetchRegistry.addPosition(i, Math.max(0, layoutState.mScrollingOffset));
        }
    }

    public int computeHorizontalScrollExtent(State state) {
        return computeScrollExtent(state);
    }

    public int computeHorizontalScrollOffset(State state) {
        return computeScrollOffset(state);
    }

    public int computeHorizontalScrollRange(State state) {
        return computeScrollRange(state);
    }

    public PointF computeScrollVectorForPosition(int i) {
        if (getChildCount() == 0) {
            return null;
        }
        boolean z = DEBUG;
        int i2 = 1;
        if (i < getPosition(getChildAt(0))) {
            z = true;
        }
        if (z != this.mShouldReverseLayout) {
            i2 = -1;
        }
        if (this.mOrientation == 0) {
            return new PointF((float) i2, 0.0f);
        }
        return new PointF(0.0f, (float) i2);
    }

    public int computeVerticalScrollExtent(State state) {
        return computeScrollExtent(state);
    }

    public int computeVerticalScrollOffset(State state) {
        return computeScrollOffset(state);
    }

    public int computeVerticalScrollRange(State state) {
        return computeScrollRange(state);
    }

    public LayoutState createLayoutState() {
        return new LayoutState();
    }

    public void ensureLayoutState() {
        if (this.mLayoutState == null) {
            this.mLayoutState = createLayoutState();
        }
    }

    public int fill(Recycler recycler, LayoutState layoutState, State state, boolean z) {
        int i = layoutState.mAvailable;
        int i2 = layoutState.mScrollingOffset;
        if (i2 != INVALID_OFFSET) {
            if (i < 0) {
                layoutState.mScrollingOffset = i2 + i;
            }
            recycleByLayoutState(recycler, layoutState);
        }
        i2 = layoutState.mAvailable + layoutState.mExtraFillSpace;
        LayoutChunkResult layoutChunkResult = this.mLayoutChunkResult;
        while (true) {
            if ((!layoutState.mInfinite && i2 <= 0) || !layoutState.hasMore(state)) {
                break;
            }
            layoutChunkResult.mConsumed = 0;
            layoutChunkResult.mFinished = DEBUG;
            layoutChunkResult.mIgnoreConsumed = DEBUG;
            layoutChunkResult.mFocusable = DEBUG;
            layoutChunk(recycler, state, layoutState, layoutChunkResult);
            if (!layoutChunkResult.mFinished) {
                int i3 = layoutState.mOffset;
                int i4 = layoutChunkResult.mConsumed;
                layoutState.mOffset = i3 + (layoutState.mLayoutDirection * i4);
                if (!(layoutChunkResult.mIgnoreConsumed && layoutState.mScrapList == null && state.mInPreLayout)) {
                    layoutState.mAvailable -= i4;
                    i2 -= i4;
                }
                i3 = layoutState.mScrollingOffset;
                if (i3 != INVALID_OFFSET) {
                    i3 += i4;
                    layoutState.mScrollingOffset = i3;
                    i4 = layoutState.mAvailable;
                    if (i4 < 0) {
                        layoutState.mScrollingOffset = i3 + i4;
                    }
                    recycleByLayoutState(recycler, layoutState);
                }
                if (z && layoutChunkResult.mFocusable) {
                    break;
                }
            } else {
                break;
            }
        }
        return i - layoutState.mAvailable;
    }

    public int findFirstCompletelyVisibleItemPosition() {
        View findOneVisibleChild = findOneVisibleChild(0, getChildCount(), true, DEBUG);
        return findOneVisibleChild == null ? -1 : getPosition(findOneVisibleChild);
    }

    public View findFirstVisibleChildClosestToEnd(boolean z, boolean z2) {
        if (this.mShouldReverseLayout) {
            return findOneVisibleChild(0, getChildCount(), z, z2);
        }
        return findOneVisibleChild(getChildCount() - 1, -1, z, z2);
    }

    public View findFirstVisibleChildClosestToStart(boolean z, boolean z2) {
        if (this.mShouldReverseLayout) {
            return findOneVisibleChild(getChildCount() - 1, -1, z, z2);
        }
        return findOneVisibleChild(0, getChildCount(), z, z2);
    }

    public int findFirstVisibleItemPosition() {
        View findOneVisibleChild = findOneVisibleChild(0, getChildCount(), DEBUG, true);
        return findOneVisibleChild == null ? -1 : getPosition(findOneVisibleChild);
    }

    public int findLastCompletelyVisibleItemPosition() {
        View findOneVisibleChild = findOneVisibleChild(getChildCount() - 1, -1, true, DEBUG);
        return findOneVisibleChild == null ? -1 : getPosition(findOneVisibleChild);
    }

    public int findLastVisibleItemPosition() {
        View findOneVisibleChild = findOneVisibleChild(getChildCount() - 1, -1, DEBUG, true);
        return findOneVisibleChild == null ? -1 : getPosition(findOneVisibleChild);
    }

    public View findOnePartiallyOrCompletelyInvisibleChild(int i, int i2) {
        int i3;
        View findOneViewWithinBoundFlags;
        ensureLayoutState();
        if (i2 <= i) {
            if (i2 >= i) {
                return getChildAt(i);
            }
        }
        int decoratedStart = this.mOrientationHelper.getDecoratedStart(getChildAt(i));
        int startAfterPadding = this.mOrientationHelper.getStartAfterPadding();
        if (decoratedStart < startAfterPadding) {
            i3 = 16388;
        } else {
            i3 = 4097;
        }
        if (decoratedStart < startAfterPadding) {
            decoratedStart = 16644;
        } else {
            decoratedStart = 4161;
        }
        if (this.mOrientation == 0) {
            findOneViewWithinBoundFlags = this.mHorizontalBoundCheck.findOneViewWithinBoundFlags(i, i2, decoratedStart, i3);
        } else {
            findOneViewWithinBoundFlags = this.mVerticalBoundCheck.findOneViewWithinBoundFlags(i, i2, decoratedStart, i3);
        }
        return findOneViewWithinBoundFlags;
    }

    public View findOneVisibleChild(int i, int i2, boolean z, boolean z2) {
        int i3;
        ensureLayoutState();
        int i4 = 320;
        if (true != z) {
            i3 = 320;
        } else {
            i3 = 24579;
        }
        if (true != z2) {
            i4 = 0;
        }
        if (this.mOrientation == 0) {
            return this.mHorizontalBoundCheck.findOneViewWithinBoundFlags(i, i2, i3, i4);
        }
        return this.mVerticalBoundCheck.findOneViewWithinBoundFlags(i, i2, i3, i4);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View findReferenceChild(android.support.p002v7.widget.RecyclerView.Recycler r17, android.support.p002v7.widget.RecyclerView.State r18, boolean r19, boolean r20) {
        /*
        r16 = this;
        r0 = r16;
        r16.ensureLayoutState();
        r1 = r16.getChildCount();
        r2 = -1;
        r3 = 1;
        r4 = 0;
        if (r20 == 0) goto L_0x0015;
    L_0x000e:
        r1 = r16.getChildCount();
        r1 = r1 + r2;
        r5 = -1;
        goto L_0x0018;
    L_0x0015:
        r2 = r1;
        r1 = 0;
        r5 = 1;
    L_0x0018:
        r6 = r18.getItemCount();
        r7 = r0.mOrientationHelper;
        r7 = r7.getStartAfterPadding();
        r8 = r0.mOrientationHelper;
        r8 = r8.getEndAfterPadding();
        r9 = 0;
        r10 = r9;
        r11 = r10;
    L_0x002b:
        if (r1 == r2) goto L_0x007c;
    L_0x002d:
        r12 = r0.getChildAt(r1);
        r13 = r0.getPosition(r12);
        r14 = r0.mOrientationHelper;
        r14 = r14.getDecoratedStart(r12);
        r15 = r0.mOrientationHelper;
        r15 = r15.getDecoratedEnd(r12);
        if (r13 < 0) goto L_0x0079;
    L_0x0043:
        if (r13 >= r6) goto L_0x0079;
    L_0x0045:
        r13 = r12.getLayoutParams();
        r13 = (android.support.p002v7.widget.RecyclerView.LayoutParams) r13;
        r13 = r13.isItemRemoved();
        if (r13 == 0) goto L_0x0055;
    L_0x0051:
        if (r11 != 0) goto L_0x0079;
    L_0x0053:
        r11 = r12;
        goto L_0x007a;
    L_0x0055:
        if (r15 > r7) goto L_0x005b;
    L_0x0057:
        if (r14 >= r7) goto L_0x005b;
    L_0x0059:
        r13 = 1;
        goto L_0x005c;
    L_0x005b:
        r13 = 0;
    L_0x005c:
        if (r14 < r8) goto L_0x0062;
    L_0x005e:
        if (r15 <= r8) goto L_0x0062;
    L_0x0060:
        r14 = 1;
        goto L_0x0063;
    L_0x0062:
        r14 = 0;
    L_0x0063:
        if (r13 != 0) goto L_0x0069;
    L_0x0065:
        if (r14 == 0) goto L_0x0068;
    L_0x0067:
        goto L_0x0069;
    L_0x0068:
        return r12;
    L_0x0069:
        if (r19 == 0) goto L_0x0071;
    L_0x006b:
        if (r14 == 0) goto L_0x006e;
    L_0x006d:
        goto L_0x0073;
    L_0x006e:
        if (r9 != 0) goto L_0x0079;
    L_0x0070:
        goto L_0x0077;
    L_0x0071:
        if (r13 == 0) goto L_0x0075;
    L_0x0073:
        r10 = r12;
        goto L_0x007a;
    L_0x0075:
        if (r9 != 0) goto L_0x0079;
    L_0x0077:
        r9 = r12;
        goto L_0x007a;
    L_0x007a:
        r1 = r1 + r5;
        goto L_0x002b;
    L_0x007c:
        if (r9 == 0) goto L_0x007f;
    L_0x007e:
        goto L_0x0082;
    L_0x007f:
        if (r10 != 0) goto L_0x0083;
    L_0x0081:
        r9 = r11;
    L_0x0082:
        return r9;
    L_0x0083:
        return r10;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.LinearLayoutManager.findReferenceChild(android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State, boolean, boolean):android.view.View");
    }

    public View findViewByPosition(int i) {
        int childCount = getChildCount();
        if (childCount == 0) {
            return null;
        }
        int position = i - getPosition(getChildAt(0));
        if (position >= 0 && position < childCount) {
            View childAt = getChildAt(position);
            if (getPosition(childAt) == i) {
                return childAt;
            }
        }
        return super.findViewByPosition(i);
    }

    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    @Deprecated
    protected int getExtraLayoutSpace(State state) {
        return state.hasTargetScrollPosition() ? this.mOrientationHelper.getTotalSpace() : 0;
    }

    public int getInitialPrefetchItemCount() {
        return this.mInitialPrefetchItemCount;
    }

    public int getOrientation() {
        return this.mOrientation;
    }

    public boolean getRecycleChildrenOnDetach() {
        return this.mRecycleChildrenOnDetach;
    }

    public boolean getReverseLayout() {
        return this.mReverseLayout;
    }

    public boolean getStackFromEnd() {
        return this.mStackFromEnd;
    }

    public boolean isAutoMeasureEnabled() {
        return true;
    }

    protected boolean isLayoutRTL() {
        return getLayoutDirection() == 1 ? true : DEBUG;
    }

    public boolean isSmoothScrollbarEnabled() {
        return this.mSmoothScrollbarEnabled;
    }

    public void layoutChunk(Recycler recycler, State state, LayoutState layoutState, LayoutChunkResult layoutChunkResult) {
        View next = layoutState.next(recycler);
        if (next == null) {
            layoutChunkResult.mFinished = true;
            return;
        }
        int decoratedMeasurementInOther;
        int i;
        int i2;
        int i3;
        LayoutParams layoutParams = (LayoutParams) next.getLayoutParams();
        boolean z;
        boolean z2;
        if (layoutState.mScrapList == null) {
            z = this.mShouldReverseLayout;
            if (layoutState.mLayoutDirection != -1) {
                z2 = DEBUG;
            } else {
                z2 = true;
            }
            if (z == z2) {
                addView(next);
            } else {
                addView(next, 0);
            }
        } else {
            z = this.mShouldReverseLayout;
            if (layoutState.mLayoutDirection != -1) {
                z2 = DEBUG;
            } else {
                z2 = true;
            }
            if (z == z2) {
                addDisappearingView(next);
            } else {
                addDisappearingView(next, 0);
            }
        }
        measureChildWithMargins(next, 0, 0);
        layoutChunkResult.mConsumed = this.mOrientationHelper.getDecoratedMeasurement(next);
        int width;
        int i4;
        if (this.mOrientation == 1) {
            if (isLayoutRTL()) {
                width = getWidth() - getPaddingRight();
                decoratedMeasurementInOther = width - this.mOrientationHelper.getDecoratedMeasurementInOther(next);
            } else {
                decoratedMeasurementInOther = getPaddingLeft();
                width = this.mOrientationHelper.getDecoratedMeasurementInOther(next) + decoratedMeasurementInOther;
            }
            if (layoutState.mLayoutDirection == -1) {
                i4 = layoutState.mOffset;
                i = i4;
                i2 = width;
                i3 = i4 - layoutChunkResult.mConsumed;
            } else {
                i4 = layoutState.mOffset;
                i3 = i4;
                i2 = width;
                i = layoutChunkResult.mConsumed + i4;
            }
        } else {
            width = getPaddingTop();
            decoratedMeasurementInOther = this.mOrientationHelper.getDecoratedMeasurementInOther(next) + width;
            if (layoutState.mLayoutDirection == -1) {
                i4 = layoutState.mOffset;
                i2 = i4;
                i3 = width;
                i = decoratedMeasurementInOther;
                decoratedMeasurementInOther = i4 - layoutChunkResult.mConsumed;
            } else {
                i4 = layoutState.mOffset;
                i3 = width;
                i2 = layoutChunkResult.mConsumed + i4;
                i = decoratedMeasurementInOther;
                decoratedMeasurementInOther = i4;
            }
        }
        layoutDecoratedWithMargins(next, decoratedMeasurementInOther, i3, i2, i);
        if (layoutParams.isItemRemoved() || layoutParams.isItemChanged()) {
            layoutChunkResult.mIgnoreConsumed = true;
        }
        layoutChunkResult.mFocusable = next.hasFocusable();
    }

    public void onAnchorReady(Recycler recycler, State state, AnchorInfo anchorInfo, int i) {
    }

    public void onDetachedFromWindow(RecyclerView recyclerView, Recycler recycler) {
        super.onDetachedFromWindow(recyclerView, recycler);
        if (this.mRecycleChildrenOnDetach) {
            removeAndRecycleAllViews(recycler);
            recycler.clear();
        }
    }

    public View onFocusSearchFailed(View view, int i, Recycler recycler, State state) {
        resolveShouldLayoutReverse();
        if (getChildCount() == 0) {
            return null;
        }
        int convertFocusDirectionToLayoutDirection = convertFocusDirectionToLayoutDirection(i);
        if (convertFocusDirectionToLayoutDirection == INVALID_OFFSET) {
            return null;
        }
        View findPartiallyOrCompletelyInvisibleChildClosestToStart;
        ensureLayoutState();
        updateLayoutState(convertFocusDirectionToLayoutDirection, (int) (((float) this.mOrientationHelper.getTotalSpace()) * MAX_SCROLL_FACTOR), DEBUG, state);
        LayoutState layoutState = this.mLayoutState;
        layoutState.mScrollingOffset = INVALID_OFFSET;
        layoutState.mRecycle = DEBUG;
        fill(recycler, layoutState, state, true);
        if (convertFocusDirectionToLayoutDirection == -1) {
            findPartiallyOrCompletelyInvisibleChildClosestToStart = findPartiallyOrCompletelyInvisibleChildClosestToStart();
        } else {
            findPartiallyOrCompletelyInvisibleChildClosestToStart = findPartiallyOrCompletelyInvisibleChildClosestToEnd();
        }
        if (convertFocusDirectionToLayoutDirection == -1) {
            view = getChildClosestToStart();
        } else {
            view = getChildClosestToEnd();
        }
        if (!view.hasFocusable()) {
            return findPartiallyOrCompletelyInvisibleChildClosestToStart;
        }
        if (findPartiallyOrCompletelyInvisibleChildClosestToStart == null) {
            return null;
        }
        return view;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        if (getChildCount() > 0) {
            accessibilityEvent.setFromIndex(findFirstVisibleItemPosition());
            accessibilityEvent.setToIndex(findLastVisibleItemPosition());
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayoutChildren(android.support.p002v7.widget.RecyclerView.Recycler r9, android.support.p002v7.widget.RecyclerView.State r10) {
        /*
        r8 = this;
        r0 = r8.mPendingSavedState;
        r1 = -1;
        if (r0 != 0) goto L_0x0009;
    L_0x0005:
        r0 = r8.mPendingScrollPosition;
        if (r0 == r1) goto L_0x000f;
    L_0x0009:
        r0 = r10.getItemCount();
        if (r0 == 0) goto L_0x01dd;
    L_0x000f:
        r0 = r8.mPendingSavedState;
        if (r0 == 0) goto L_0x001f;
    L_0x0013:
        r0 = r0.hasValidAnchor();
        if (r0 == 0) goto L_0x001f;
    L_0x0019:
        r0 = r8.mPendingSavedState;
        r0 = r0.mAnchorPosition;
        r8.mPendingScrollPosition = r0;
    L_0x001f:
        r8.ensureLayoutState();
        r0 = r8.mLayoutState;
        r2 = 0;
        r0.mRecycle = r2;
        r8.resolveShouldLayoutReverse();
        r0 = r8.getFocusedChild();
        r3 = r8.mAnchorInfo;
        r4 = r3.mValid;
        r5 = 1;
        if (r4 == 0) goto L_0x0066;
    L_0x0035:
        r4 = r8.mPendingScrollPosition;
        if (r4 != r1) goto L_0x0066;
    L_0x0039:
        r4 = r8.mPendingSavedState;
        if (r4 == 0) goto L_0x003e;
    L_0x003d:
        goto L_0x0066;
    L_0x003e:
        if (r0 == 0) goto L_0x0079;
    L_0x0040:
        r3 = r8.mOrientationHelper;
        r3 = r3.getDecoratedStart(r0);
        r4 = r8.mOrientationHelper;
        r4 = r4.getEndAfterPadding();
        if (r3 >= r4) goto L_0x005c;
    L_0x004e:
        r3 = r8.mOrientationHelper;
        r3 = r3.getDecoratedEnd(r0);
        r4 = r8.mOrientationHelper;
        r4 = r4.getStartAfterPadding();
        if (r3 > r4) goto L_0x0079;
    L_0x005c:
        r3 = r8.mAnchorInfo;
        r4 = r8.getPosition(r0);
        r3.assignFromViewAndKeepVisibleRect(r0, r4);
        goto L_0x0079;
    L_0x0066:
        r3.reset();
        r0 = r8.mAnchorInfo;
        r3 = r8.mShouldReverseLayout;
        r4 = r8.mStackFromEnd;
        r3 = r3 ^ r4;
        r0.mLayoutFromEnd = r3;
        r8.updateAnchorInfoForLayout(r9, r10, r0);
        r0 = r8.mAnchorInfo;
        r0.mValid = r5;
    L_0x0079:
        r0 = r8.mLayoutState;
        r3 = r0.mLastScrollDelta;
        if (r3 < 0) goto L_0x0081;
    L_0x007f:
        r3 = 1;
        goto L_0x0082;
    L_0x0081:
        r3 = -1;
    L_0x0082:
        r0.mLayoutDirection = r3;
        r0 = r8.mReusableIntPair;
        r0[r2] = r2;
        r0[r5] = r2;
        r8.calculateExtraLayoutSpace(r10, r0);
        r0 = r8.mReusableIntPair;
        r0 = r0[r2];
        r0 = java.lang.Math.max(r2, r0);
        r3 = r8.mOrientationHelper;
        r3 = r3.getStartAfterPadding();
        r0 = r0 + r3;
        r3 = r8.mReusableIntPair;
        r3 = r3[r5];
        r3 = java.lang.Math.max(r2, r3);
        r4 = r8.mOrientationHelper;
        r4 = r4.getEndPadding();
        r3 = r3 + r4;
        r4 = r10.mInPreLayout;
        if (r4 == 0) goto L_0x00eb;
    L_0x00af:
        r4 = r8.mPendingScrollPosition;
        if (r4 == r1) goto L_0x00eb;
    L_0x00b3:
        r6 = r8.mPendingScrollPositionOffset;
        r7 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        if (r6 == r7) goto L_0x00eb;
    L_0x00b9:
        r4 = r8.findViewByPosition(r4);
        if (r4 == 0) goto L_0x00eb;
    L_0x00bf:
        r6 = r8.mShouldReverseLayout;
        if (r6 == 0) goto L_0x00d4;
    L_0x00c3:
        r6 = r8.mOrientationHelper;
        r6 = r6.getEndAfterPadding();
        r7 = r8.mOrientationHelper;
        r4 = r7.getDecoratedEnd(r4);
        r6 = r6 - r4;
        r4 = r8.mPendingScrollPositionOffset;
        r6 = r6 - r4;
        goto L_0x00e5;
    L_0x00d4:
        r6 = r8.mOrientationHelper;
        r4 = r6.getDecoratedStart(r4);
        r6 = r8.mOrientationHelper;
        r6 = r6.getStartAfterPadding();
        r7 = r8.mPendingScrollPositionOffset;
        r4 = r4 - r6;
        r6 = r7 - r4;
    L_0x00e5:
        if (r6 <= 0) goto L_0x00e9;
    L_0x00e7:
        r0 = r0 + r6;
        goto L_0x00ec;
    L_0x00e9:
        r3 = r3 - r6;
        goto L_0x00ec;
    L_0x00ec:
        r4 = r8.mAnchorInfo;
        r6 = r4.mLayoutFromEnd;
        if (r6 == 0) goto L_0x00f7;
    L_0x00f2:
        r6 = r8.mShouldReverseLayout;
        if (r5 == r6) goto L_0x00fb;
    L_0x00f6:
        goto L_0x00fc;
    L_0x00f7:
        r6 = r8.mShouldReverseLayout;
        if (r5 == r6) goto L_0x00fc;
    L_0x00fb:
        r1 = 1;
    L_0x00fc:
        r8.onAnchorReady(r9, r10, r4, r1);
        r8.detachAndScrapAttachedViews(r9);
        r1 = r8.mLayoutState;
        r4 = r8.resolveIsInfinite();
        r1.mInfinite = r4;
        r1 = r8.mLayoutState;
        r4 = r10.mInPreLayout;
        r1.mIsPreLayout = r4;
        r1.mNoRecycleSpace = r2;
        r1 = r8.mAnchorInfo;
        r4 = r1.mLayoutFromEnd;
        if (r4 == 0) goto L_0x015a;
    L_0x0118:
        r8.updateLayoutStateToFillStart(r1);
        r1 = r8.mLayoutState;
        r1.mExtraFillSpace = r0;
        r8.fill(r9, r1, r10, r2);
        r0 = r8.mLayoutState;
        r1 = r0.mOffset;
        r4 = r0.mCurrentPosition;
        r0 = r0.mAvailable;
        if (r0 <= 0) goto L_0x012e;
    L_0x012c:
        r3 = r3 + r0;
        goto L_0x012f;
    L_0x012f:
        r0 = r8.mAnchorInfo;
        r8.updateLayoutStateToFillEnd(r0);
        r0 = r8.mLayoutState;
        r0.mExtraFillSpace = r3;
        r3 = r0.mCurrentPosition;
        r6 = r0.mItemDirection;
        r3 = r3 + r6;
        r0.mCurrentPosition = r3;
        r8.fill(r9, r0, r10, r2);
        r0 = r8.mLayoutState;
        r3 = r0.mOffset;
        r0 = r0.mAvailable;
        if (r0 <= 0) goto L_0x0159;
    L_0x014a:
        r8.updateLayoutStateToFillStart(r4, r1);
        r1 = r8.mLayoutState;
        r1.mExtraFillSpace = r0;
        r8.fill(r9, r1, r10, r2);
        r0 = r8.mLayoutState;
        r1 = r0.mOffset;
        goto L_0x019a;
    L_0x0159:
        goto L_0x019a;
    L_0x015a:
        r8.updateLayoutStateToFillEnd(r1);
        r1 = r8.mLayoutState;
        r1.mExtraFillSpace = r3;
        r8.fill(r9, r1, r10, r2);
        r1 = r8.mLayoutState;
        r3 = r1.mOffset;
        r4 = r1.mCurrentPosition;
        r1 = r1.mAvailable;
        if (r1 <= 0) goto L_0x016f;
    L_0x016e:
        r0 = r0 + r1;
    L_0x016f:
        r1 = r8.mAnchorInfo;
        r8.updateLayoutStateToFillStart(r1);
        r1 = r8.mLayoutState;
        r1.mExtraFillSpace = r0;
        r0 = r1.mCurrentPosition;
        r6 = r1.mItemDirection;
        r0 = r0 + r6;
        r1.mCurrentPosition = r0;
        r8.fill(r9, r1, r10, r2);
        r0 = r8.mLayoutState;
        r1 = r0.mOffset;
        r0 = r0.mAvailable;
        if (r0 <= 0) goto L_0x0199;
    L_0x018a:
        r8.updateLayoutStateToFillEnd(r4, r3);
        r3 = r8.mLayoutState;
        r3.mExtraFillSpace = r0;
        r8.fill(r9, r3, r10, r2);
        r0 = r8.mLayoutState;
        r3 = r0.mOffset;
        goto L_0x019a;
    L_0x019a:
        r0 = r8.getChildCount();
        if (r0 <= 0) goto L_0x01c2;
    L_0x01a0:
        r0 = r8.mShouldReverseLayout;
        r4 = r8.mStackFromEnd;
        r0 = r0 ^ r4;
        if (r0 == 0) goto L_0x01b4;
    L_0x01a7:
        r0 = r8.fixLayoutEndGap(r3, r9, r10, r5);
        r1 = r1 + r0;
        r2 = r8.fixLayoutStartGap(r1, r9, r10, r2);
        r1 = r1 + r2;
        r3 = r3 + r0;
        r3 = r3 + r2;
        goto L_0x01c3;
        r0 = r8.fixLayoutStartGap(r1, r9, r10, r5);
        r3 = r3 + r0;
        r2 = r8.fixLayoutEndGap(r3, r9, r10, r2);
        r1 = r1 + r0;
        r1 = r1 + r2;
        r3 = r3 + r2;
        goto L_0x01c3;
    L_0x01c3:
        r8.layoutForPredictiveAnimations(r9, r10, r1, r3);
        r9 = r10.mInPreLayout;
        if (r9 != 0) goto L_0x01d3;
    L_0x01ca:
        r9 = r8.mOrientationHelper;
        r10 = r9.getTotalSpace();
        r9.mLastTotalSpace = r10;
        goto L_0x01d8;
    L_0x01d3:
        r9 = r8.mAnchorInfo;
        r9.reset();
    L_0x01d8:
        r9 = r8.mStackFromEnd;
        r8.mLastStackFromEnd = r9;
        return;
    L_0x01dd:
        r8.removeAndRecycleAllViews(r9);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.LinearLayoutManager.onLayoutChildren(android.support.v7.widget.RecyclerView$Recycler, android.support.v7.widget.RecyclerView$State):void");
    }

    public void onLayoutCompleted(State state) {
        this.mPendingSavedState = null;
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = INVALID_OFFSET;
        this.mAnchorInfo.reset();
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            this.mPendingSavedState = savedState;
            if (this.mPendingScrollPosition != -1) {
                savedState.invalidateAnchor();
            }
            requestLayout();
        }
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = this.mPendingSavedState;
        if (savedState != null) {
            return new SavedState(savedState);
        }
        Parcelable savedState2 = new SavedState();
        if (getChildCount() > 0) {
            ensureLayoutState();
            boolean z = this.mLastStackFromEnd ^ this.mShouldReverseLayout;
            savedState2.mAnchorLayoutFromEnd = z;
            View childClosestToEnd;
            if (z) {
                childClosestToEnd = getChildClosestToEnd();
                savedState2.mAnchorOffset = this.mOrientationHelper.getEndAfterPadding() - this.mOrientationHelper.getDecoratedEnd(childClosestToEnd);
                savedState2.mAnchorPosition = getPosition(childClosestToEnd);
            } else {
                childClosestToEnd = getChildClosestToStart();
                savedState2.mAnchorPosition = getPosition(childClosestToEnd);
                savedState2.mAnchorOffset = this.mOrientationHelper.getDecoratedStart(childClosestToEnd) - this.mOrientationHelper.getStartAfterPadding();
            }
        } else {
            savedState2.invalidateAnchor();
        }
        return savedState2;
    }

    public void prepareForDrop(View view, View view2, int i, int i2) {
        assertNotInLayoutOrScroll("Cannot drop a view during a scroll or layout calculation");
        ensureLayoutState();
        resolveShouldLayoutReverse();
        i = getPosition(view);
        i2 = getPosition(view2);
        if (i < i2) {
            i = 1;
        } else {
            i = -1;
        }
        if (this.mShouldReverseLayout) {
            if (i == 1) {
                scrollToPositionWithOffset(i2, this.mOrientationHelper.getEndAfterPadding() - (this.mOrientationHelper.getDecoratedStart(view2) + this.mOrientationHelper.getDecoratedMeasurement(view)));
            } else {
                scrollToPositionWithOffset(i2, this.mOrientationHelper.getEndAfterPadding() - this.mOrientationHelper.getDecoratedEnd(view2));
            }
        } else if (i == -1) {
            scrollToPositionWithOffset(i2, this.mOrientationHelper.getDecoratedStart(view2));
        } else {
            scrollToPositionWithOffset(i2, this.mOrientationHelper.getDecoratedEnd(view2) - this.mOrientationHelper.getDecoratedMeasurement(view));
        }
    }

    public boolean resolveIsInfinite() {
        return (this.mOrientationHelper.getMode() == 0 && this.mOrientationHelper.getEnd() == 0) ? true : DEBUG;
    }

    public int scrollBy(int i, Recycler recycler, State state) {
        if (getChildCount() != 0) {
            if (i != 0) {
                int i2;
                ensureLayoutState();
                this.mLayoutState.mRecycle = true;
                if (i > 0) {
                    i2 = 1;
                } else {
                    i2 = -1;
                }
                int abs = Math.abs(i);
                updateLayoutState(i2, abs, true, state);
                LayoutState layoutState = this.mLayoutState;
                int fill = layoutState.mScrollingOffset + fill(recycler, layoutState, state, DEBUG);
                if (fill < 0) {
                    return 0;
                }
                if (abs > fill) {
                    i = i2 * fill;
                }
                this.mOrientationHelper.offsetChildren(-i);
                this.mLayoutState.mLastScrollDelta = i;
                return i;
            }
        }
        return 0;
    }

    public int scrollHorizontallyBy(int i, Recycler recycler, State state) {
        return this.mOrientation == 1 ? 0 : scrollBy(i, recycler, state);
    }

    public void scrollToPosition(int i) {
        this.mPendingScrollPosition = i;
        this.mPendingScrollPositionOffset = INVALID_OFFSET;
        SavedState savedState = this.mPendingSavedState;
        if (savedState != null) {
            savedState.invalidateAnchor();
        }
        requestLayout();
    }

    public void scrollToPositionWithOffset(int i, int i2) {
        this.mPendingScrollPosition = i;
        this.mPendingScrollPositionOffset = i2;
        SavedState savedState = this.mPendingSavedState;
        if (savedState != null) {
            savedState.invalidateAnchor();
        }
        requestLayout();
    }

    public int scrollVerticallyBy(int i, Recycler recycler, State state) {
        return this.mOrientation == 0 ? 0 : scrollBy(i, recycler, state);
    }

    public void setInitialPrefetchItemCount(int i) {
        this.mInitialPrefetchItemCount = i;
    }

    public void setOrientation(int i) {
        if (i != 0) {
            if (i != 1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("invalid orientation:");
                stringBuilder.append(i);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        assertNotInLayoutOrScroll(null);
        if (i == this.mOrientation) {
            if (this.mOrientationHelper != null) {
                return;
            }
        }
        OrientationHelper createOrientationHelper = OrientationHelper.createOrientationHelper(this, i);
        this.mOrientationHelper = createOrientationHelper;
        this.mAnchorInfo.mOrientationHelper = createOrientationHelper;
        this.mOrientation = i;
        requestLayout();
    }

    public void setRecycleChildrenOnDetach(boolean z) {
        this.mRecycleChildrenOnDetach = z;
    }

    public void setReverseLayout(boolean z) {
        assertNotInLayoutOrScroll(null);
        if (z != this.mReverseLayout) {
            this.mReverseLayout = z;
            requestLayout();
        }
    }

    public void setSmoothScrollbarEnabled(boolean z) {
        this.mSmoothScrollbarEnabled = z;
    }

    public void setStackFromEnd(boolean z) {
        assertNotInLayoutOrScroll(null);
        if (this.mStackFromEnd != z) {
            this.mStackFromEnd = z;
            requestLayout();
        }
    }

    public boolean shouldMeasureTwice() {
        return (getHeightMode() == 1073741824 || getWidthMode() == 1073741824 || !hasFlexibleChildInBothOrientations()) ? DEBUG : true;
    }

    public void smoothScrollToPosition(RecyclerView recyclerView, State state, int i) {
        SmoothScroller linearSmoothScroller = new LinearSmoothScroller(recyclerView.getContext());
        linearSmoothScroller.mTargetPosition = i;
        startSmoothScroll(linearSmoothScroller);
    }

    public boolean supportsPredictiveItemAnimations() {
        return (this.mPendingSavedState == null && this.mLastStackFromEnd == this.mStackFromEnd) ? true : DEBUG;
    }

    void validateChildOrder() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("validating child count ");
        stringBuilder.append(getChildCount());
        Log.d(TAG, stringBuilder.toString());
        if (getChildCount() > 0) {
            boolean z = DEBUG;
            int position = getPosition(getChildAt(0));
            int decoratedStart = this.mOrientationHelper.getDecoratedStart(getChildAt(0));
            String str = "detected invalid location";
            String str2 = "detected invalid position. loc invalid? ";
            int i;
            View childAt;
            int position2;
            int decoratedStart2;
            StringBuilder stringBuilder2;
            if (this.mShouldReverseLayout) {
                i = 1;
                while (i < getChildCount()) {
                    childAt = getChildAt(i);
                    position2 = getPosition(childAt);
                    decoratedStart2 = this.mOrientationHelper.getDecoratedStart(childAt);
                    if (position2 < position) {
                        logChildren();
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str2);
                        if (decoratedStart2 < decoratedStart) {
                            z = true;
                        }
                        stringBuilder2.append(z);
                        throw new RuntimeException(stringBuilder2.toString());
                    } else if (decoratedStart2 <= decoratedStart) {
                        i++;
                    } else {
                        logChildren();
                        throw new RuntimeException(str);
                    }
                }
            }
            i = 1;
            while (i < getChildCount()) {
                childAt = getChildAt(i);
                position2 = getPosition(childAt);
                decoratedStart2 = this.mOrientationHelper.getDecoratedStart(childAt);
                if (position2 < position) {
                    logChildren();
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(str2);
                    if (decoratedStart2 < decoratedStart) {
                        z = true;
                    }
                    stringBuilder2.append(z);
                    throw new RuntimeException(stringBuilder2.toString());
                } else if (decoratedStart2 >= decoratedStart) {
                    i++;
                } else {
                    logChildren();
                    throw new RuntimeException(str);
                }
            }
        }
    }

    public LinearLayoutManager(Context context, int i, boolean z) {
        this.mOrientation = 1;
        this.mReverseLayout = DEBUG;
        this.mShouldReverseLayout = DEBUG;
        this.mStackFromEnd = DEBUG;
        this.mSmoothScrollbarEnabled = true;
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = INVALID_OFFSET;
        this.mPendingSavedState = null;
        this.mAnchorInfo = new AnchorInfo();
        this.mLayoutChunkResult = new LayoutChunkResult();
        this.mInitialPrefetchItemCount = 2;
        this.mReusableIntPair = new int[2];
        setOrientation(i);
        setReverseLayout(z);
    }

    private void recycleChildren(Recycler recycler, int i, int i2) {
        if (i != i2) {
            if (i2 > i) {
                while (true) {
                    i2--;
                    if (i2 < i) {
                        break;
                    }
                    removeAndRecycleViewAt(i2, recycler);
                }
            } else {
                while (i > i2) {
                    removeAndRecycleViewAt(i, recycler);
                    i--;
                }
            }
        }
    }

    public void collectInitialPrefetchPositions(int i, LayoutPrefetchRegistry layoutPrefetchRegistry) {
        boolean z;
        int i2;
        SavedState savedState = this.mPendingSavedState;
        int i3 = -1;
        if (savedState == null || !savedState.hasValidAnchor()) {
            resolveShouldLayoutReverse();
            z = this.mShouldReverseLayout;
            i2 = this.mPendingScrollPosition;
            if (i2 == -1) {
                i2 = z ? i - 1 : 0;
            }
        } else {
            savedState = this.mPendingSavedState;
            z = savedState.mAnchorLayoutFromEnd;
            i2 = savedState.mAnchorPosition;
        }
        if (true != z) {
            i3 = 1;
        }
        for (int i4 = 0; i4 < this.mInitialPrefetchItemCount && i2 >= 0 && i2 < i; i4++) {
            layoutPrefetchRegistry.addPosition(i2, 0);
            i2 += i3;
        }
    }

    public int convertFocusDirectionToLayoutDirection(int i) {
        switch (i) {
            case 1:
                return (this.mOrientation != 1 && isLayoutRTL()) ? 1 : -1;
            case 2:
                return (this.mOrientation != 1 && isLayoutRTL()) ? -1 : 1;
            case 17:
                return this.mOrientation == 0 ? -1 : INVALID_OFFSET;
            case 33:
                return this.mOrientation == 1 ? -1 : INVALID_OFFSET;
            case 66:
                return this.mOrientation == 0 ? 1 : INVALID_OFFSET;
            case 130:
                return this.mOrientation == 1 ? 1 : INVALID_OFFSET;
            default:
                return INVALID_OFFSET;
        }
    }

    private void updateLayoutStateToFillEnd(AnchorInfo anchorInfo) {
        updateLayoutStateToFillEnd(anchorInfo.mPosition, anchorInfo.mCoordinate);
    }

    private void updateLayoutStateToFillStart(AnchorInfo anchorInfo) {
        updateLayoutStateToFillStart(anchorInfo.mPosition, anchorInfo.mCoordinate);
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.mOrientation = 1;
        this.mReverseLayout = DEBUG;
        this.mShouldReverseLayout = DEBUG;
        this.mStackFromEnd = DEBUG;
        this.mSmoothScrollbarEnabled = true;
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = INVALID_OFFSET;
        this.mPendingSavedState = null;
        this.mAnchorInfo = new AnchorInfo();
        this.mLayoutChunkResult = new LayoutChunkResult();
        this.mInitialPrefetchItemCount = 2;
        this.mReusableIntPair = new int[2];
        Properties properties = LayoutManager.getProperties(context, attributeSet, i, i2);
        setOrientation(properties.orientation);
        setReverseLayout(properties.reverseLayout);
        setStackFromEnd(properties.stackFromEnd);
    }
}
