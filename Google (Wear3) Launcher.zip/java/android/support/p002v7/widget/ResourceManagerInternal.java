package android.support.p002v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.LayerDrawable;
import android.support.p002v7.widget.AppCompatDrawableManager.PG;
import android.util.Log;
import android.util.TypedValue;
import androidx.collection.LongSparseArray;
import androidx.collection.LruCache;
import androidx.core.content.ContextCompat.Api21Impl;
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat;
import com.google.android.wearable.sysui.R;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ResourceManagerInternal */
public final class ResourceManagerInternal {
    private static final ColorFilterLruCache COLOR_FILTER_CACHE = new ColorFilterLruCache();
    private static final Mode DEFAULT_MODE = Mode.SRC_IN;
    private static ResourceManagerInternal INSTANCE;
    private final WeakHashMap mDrawableCaches = new WeakHashMap(0);
    private boolean mHasCheckedVectorDrawableSetup;
    private ResourceManagerHooks mHooks;
    private WeakHashMap mTintLists;
    private TypedValue mTypedValue;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ResourceManagerInternal$ColorFilterLruCache */
    final class ColorFilterLruCache extends LruCache {
        public ColorFilterLruCache() {
            super(6);
        }

        public static int generateCacheKey(int i, Mode mode) {
            return ((i + 31) * 31) + mode.hashCode();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ResourceManagerInternal$ResourceManagerHooks */
    public interface ResourceManagerHooks {
    }

    private final synchronized void addDrawableToCache$ar$ds(Context context, long j, Drawable drawable) {
        ConstantState constantState = drawable.getConstantState();
        if (constantState != null) {
            LongSparseArray longSparseArray = (LongSparseArray) this.mDrawableCaches.get(context);
            if (longSparseArray == null) {
                longSparseArray = new LongSparseArray();
                this.mDrawableCaches.put(context, longSparseArray);
            }
            longSparseArray.put(j, new WeakReference(constantState));
        }
    }

    public static synchronized ResourceManagerInternal get() {
        ResourceManagerInternal resourceManagerInternal;
        synchronized (ResourceManagerInternal.class) {
            if (INSTANCE == null) {
                INSTANCE = new ResourceManagerInternal();
            }
            resourceManagerInternal = INSTANCE;
        }
        return resourceManagerInternal;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final synchronized android.graphics.drawable.Drawable getCachedDrawable(android.content.Context r4, long r5) {
        /*
        r3 = this;
        monitor-enter(r3);
        r0 = r3.mDrawableCaches;	 Catch:{ all -> 0x0046 }
        r0 = r0.get(r4);	 Catch:{ all -> 0x0046 }
        r0 = (androidx.collection.LongSparseArray) r0;	 Catch:{ all -> 0x0046 }
        r1 = 0;
        if (r0 != 0) goto L_0x000e;
    L_0x000c:
        monitor-exit(r3);
        return r1;
    L_0x000e:
        r2 = r0.get(r5);	 Catch:{ all -> 0x0046 }
        r2 = (java.lang.ref.WeakReference) r2;	 Catch:{ all -> 0x0046 }
        if (r2 == 0) goto L_0x0044;
    L_0x0016:
        r2 = r2.get();	 Catch:{ all -> 0x0046 }
        r2 = (android.graphics.drawable.Drawable.ConstantState) r2;	 Catch:{ all -> 0x0046 }
        if (r2 != 0) goto L_0x003a;
    L_0x001e:
        r4 = r0.mKeys;	 Catch:{ all -> 0x0046 }
        r2 = r0.mSize;	 Catch:{ all -> 0x0046 }
        r4 = androidx.collection.ContainerHelpers.binarySearch(r4, r2, r5);	 Catch:{ all -> 0x0046 }
        if (r4 < 0) goto L_0x0044;
    L_0x0028:
        r5 = r0.mValues;	 Catch:{ all -> 0x0046 }
        r5 = r5[r4];	 Catch:{ all -> 0x0046 }
        r6 = androidx.collection.LongSparseArray.DELETED;	 Catch:{ all -> 0x0046 }
        if (r5 == r6) goto L_0x0044;
    L_0x0030:
        r5 = r0.mValues;	 Catch:{ all -> 0x0046 }
        r6 = androidx.collection.LongSparseArray.DELETED;	 Catch:{ all -> 0x0046 }
        r5[r4] = r6;	 Catch:{ all -> 0x0046 }
        r4 = 1;
        r0.mGarbage = r4;	 Catch:{ all -> 0x0046 }
        goto L_0x0044;
    L_0x003a:
        r4 = r4.getResources();	 Catch:{ all -> 0x0046 }
        r4 = r2.newDrawable(r4);	 Catch:{ all -> 0x0046 }
        monitor-exit(r3);
        return r4;
    L_0x0044:
        monitor-exit(r3);
        return r1;
    L_0x0046:
        r4 = move-exception;
        monitor-exit(r3);
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ResourceManagerInternal.getCachedDrawable(android.content.Context, long):android.graphics.drawable.Drawable");
    }

    public static synchronized PorterDuffColorFilter getPorterDuffColorFilter(int i, Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        synchronized (ResourceManagerInternal.class) {
            LruCache lruCache = COLOR_FILTER_CACHE;
            porterDuffColorFilter = (PorterDuffColorFilter) lruCache.get(Integer.valueOf(ColorFilterLruCache.generateCacheKey(i, mode)));
            if (porterDuffColorFilter == null) {
                porterDuffColorFilter = new PorterDuffColorFilter(i, mode);
                PorterDuffColorFilter porterDuffColorFilter2 = (PorterDuffColorFilter) lruCache.put(Integer.valueOf(ColorFilterLruCache.generateCacheKey(i, mode)), porterDuffColorFilter);
            }
        }
        return porterDuffColorFilter;
    }

    static void tintDrawable(Drawable drawable, TintInfo tintInfo, int[] iArr) {
        ColorStateList colorStateList;
        Mode mode;
        if (DrawableUtils.canSafelyMutateDrawable(drawable)) {
            if (drawable.mutate() != drawable) {
                Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
                return;
            }
        }
        ColorFilter colorFilter = null;
        if (tintInfo.mHasTintList) {
            colorStateList = tintInfo.mTintList;
        } else if (tintInfo.mHasTintMode) {
            colorStateList = null;
        } else {
            drawable.clearColorFilter();
            return;
        }
        if (tintInfo.mHasTintMode) {
            mode = tintInfo.mTintMode;
        } else {
            mode = DEFAULT_MODE;
        }
        if (colorStateList != null) {
            if (mode != null) {
                colorFilter = ResourceManagerInternal.getPorterDuffColorFilter(colorStateList.getColorForState(iArr, 0), mode);
            }
        }
        drawable.setColorFilter(colorFilter);
    }

    public final synchronized Drawable getDrawable(Context context, int i) {
        return getDrawable(context, i, false);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final synchronized android.content.res.ColorStateList getTintList(android.content.Context r10, int r11) {
        /*
        r9 = this;
        monitor-enter(r9);
        r0 = r9.mTintLists;	 Catch:{ all -> 0x0186 }
        r1 = 0;
        if (r0 == 0) goto L_0x0015;
    L_0x0006:
        r0 = r0.get(r10);	 Catch:{ all -> 0x0186 }
        r0 = (androidx.collection.SparseArrayCompat) r0;	 Catch:{ all -> 0x0186 }
        if (r0 == 0) goto L_0x0015;
    L_0x000e:
        r0 = r0.get(r11);	 Catch:{ all -> 0x0186 }
        r0 = (android.content.res.ColorStateList) r0;	 Catch:{ all -> 0x0186 }
        goto L_0x0016;
    L_0x0015:
        r0 = r1;
    L_0x0016:
        if (r0 != 0) goto L_0x0183;
    L_0x0018:
        r0 = r9.mHooks;	 Catch:{ all -> 0x0186 }
        r2 = 2131230830; // 0x7f08006e float:1.8077724E38 double:1.0529679365E-314;
        r3 = 1;
        r4 = 0;
        if (r0 != 0) goto L_0x0023;
    L_0x0021:
        goto L_0x0122;
    L_0x0023:
        r5 = 2131230792; // 0x7f080048 float:1.8077647E38 double:1.0529679177E-314;
        if (r11 != r5) goto L_0x0031;
    L_0x0028:
        r0 = 2131099669; // 0x7f060015 float:1.7811698E38 double:1.0529031343E-314;
        r1 = android.support.p002v7.content.res.AppCompatResources.getColorStateList(r10, r0);	 Catch:{ all -> 0x0186 }
        goto L_0x0122;
    L_0x0031:
        r5 = 2131230838; // 0x7f080076 float:1.807774E38 double:1.0529679404E-314;
        if (r11 != r5) goto L_0x003f;
    L_0x0036:
        r0 = 2131099672; // 0x7f060018 float:1.7811704E38 double:1.052903136E-314;
        r1 = android.support.p002v7.content.res.AppCompatResources.getColorStateList(r10, r0);	 Catch:{ all -> 0x0186 }
        goto L_0x0122;
    L_0x003f:
        r5 = 2131230837; // 0x7f080075 float:1.8077738E38 double:1.05296794E-314;
        if (r11 != r5) goto L_0x00a1;
    L_0x0044:
        r0 = 3;
        r1 = new int[r0][];	 Catch:{ all -> 0x0186 }
        r0 = new int[r0];	 Catch:{ all -> 0x0186 }
        r2 = 2130968805; // 0x7f0400e5 float:1.7546274E38 double:1.052838479E-314;
        r5 = android.support.p002v7.widget.ThemeUtils.getThemeAttrColorStateList(r10, r2);	 Catch:{ all -> 0x0186 }
        r6 = 2130968787; // 0x7f0400d3 float:1.7546238E38 double:1.05283847E-314;
        r7 = 2;
        if (r5 == 0) goto L_0x007b;
    L_0x0056:
        r8 = r5.isStateful();	 Catch:{ all -> 0x0186 }
        if (r8 == 0) goto L_0x007b;
    L_0x005c:
        r2 = android.support.p002v7.widget.ThemeUtils.DISABLED_STATE_SET;	 Catch:{ all -> 0x0186 }
        r1[r4] = r2;	 Catch:{ all -> 0x0186 }
        r2 = r5.getColorForState(r2, r4);	 Catch:{ all -> 0x0186 }
        r0[r4] = r2;	 Catch:{ all -> 0x0186 }
        r2 = android.support.p002v7.widget.ThemeUtils.CHECKED_STATE_SET;	 Catch:{ all -> 0x0186 }
        r1[r3] = r2;	 Catch:{ all -> 0x0186 }
        r2 = android.support.p002v7.widget.ThemeUtils.getThemeAttrColor(r10, r6);	 Catch:{ all -> 0x0186 }
        r0[r3] = r2;	 Catch:{ all -> 0x0186 }
        r2 = android.support.p002v7.widget.ThemeUtils.EMPTY_STATE_SET;	 Catch:{ all -> 0x0186 }
        r1[r7] = r2;	 Catch:{ all -> 0x0186 }
        r2 = r5.getDefaultColor();	 Catch:{ all -> 0x0186 }
        r0[r7] = r2;	 Catch:{ all -> 0x0186 }
        goto L_0x0099;
    L_0x007b:
        r5 = android.support.p002v7.widget.ThemeUtils.DISABLED_STATE_SET;	 Catch:{ all -> 0x0186 }
        r1[r4] = r5;	 Catch:{ all -> 0x0186 }
        r5 = android.support.p002v7.widget.ThemeUtils.getDisabledThemeAttrColor(r10, r2);	 Catch:{ all -> 0x0186 }
        r0[r4] = r5;	 Catch:{ all -> 0x0186 }
        r5 = android.support.p002v7.widget.ThemeUtils.CHECKED_STATE_SET;	 Catch:{ all -> 0x0186 }
        r1[r3] = r5;	 Catch:{ all -> 0x0186 }
        r5 = android.support.p002v7.widget.ThemeUtils.getThemeAttrColor(r10, r6);	 Catch:{ all -> 0x0186 }
        r0[r3] = r5;	 Catch:{ all -> 0x0186 }
        r5 = android.support.p002v7.widget.ThemeUtils.EMPTY_STATE_SET;	 Catch:{ all -> 0x0186 }
        r1[r7] = r5;	 Catch:{ all -> 0x0186 }
        r2 = android.support.p002v7.widget.ThemeUtils.getThemeAttrColor(r10, r2);	 Catch:{ all -> 0x0186 }
        r0[r7] = r2;	 Catch:{ all -> 0x0186 }
    L_0x0099:
        r2 = new android.content.res.ColorStateList;	 Catch:{ all -> 0x0186 }
        r2.<init>(r1, r0);	 Catch:{ all -> 0x0186 }
        r1 = r2;
        goto L_0x0122;
    L_0x00a1:
        r5 = 2131230780; // 0x7f08003c float:1.8077622E38 double:1.052967912E-314;
        if (r11 != r5) goto L_0x00b3;
    L_0x00a6:
        r0 = 2130968786; // 0x7f0400d2 float:1.7546235E38 double:1.0528384695E-314;
        r0 = android.support.p002v7.widget.ThemeUtils.getThemeAttrColor(r10, r0);	 Catch:{ all -> 0x0186 }
    L_0x00ad:
        r1 = android.support.p002v7.widget.AppCompatDrawableManager.PG.createButtonColorStateList$ar$ds(r10, r0);	 Catch:{ all -> 0x0186 }
        goto L_0x0122;
    L_0x00b3:
        r5 = 2131230774; // 0x7f080036 float:1.807761E38 double:1.052967909E-314;
        if (r11 != r5) goto L_0x00bd;
    L_0x00b8:
        r1 = android.support.p002v7.widget.AppCompatDrawableManager.PG.createButtonColorStateList$ar$ds(r10, r4);	 Catch:{ all -> 0x0186 }
        goto L_0x0122;
    L_0x00bd:
        r5 = 2131230779; // 0x7f08003b float:1.807762E38 double:1.0529679113E-314;
        if (r11 != r5) goto L_0x00ca;
    L_0x00c2:
        r0 = 2130968783; // 0x7f0400cf float:1.754623E38 double:1.052838468E-314;
        r0 = android.support.p002v7.widget.ThemeUtils.getThemeAttrColor(r10, r0);	 Catch:{ all -> 0x0186 }
        goto L_0x00ad;
    L_0x00ca:
        r5 = 2131230833; // 0x7f080071 float:1.807773E38 double:1.052967938E-314;
        if (r11 == r5) goto L_0x011b;
    L_0x00cf:
        r5 = 2131230834; // 0x7f080072 float:1.8077732E38 double:1.0529679384E-314;
        if (r11 != r5) goto L_0x00d5;
    L_0x00d4:
        goto L_0x011b;
    L_0x00d5:
        r5 = r0;
        r5 = (android.support.p002v7.widget.AppCompatDrawableManager.PG) r5;	 Catch:{ all -> 0x0186 }
        r5 = r5.TINT_COLOR_CONTROL_NORMAL;	 Catch:{ all -> 0x0186 }
        r5 = android.support.p002v7.widget.AppCompatDrawableManager.PG.arrayContains$ar$ds(r5, r11);	 Catch:{ all -> 0x0186 }
        if (r5 == 0) goto L_0x00e8;
    L_0x00e0:
        r0 = 2130968789; // 0x7f0400d5 float:1.7546242E38 double:1.052838471E-314;
        r1 = android.support.p002v7.widget.ThemeUtils.getThemeAttrColorStateList(r10, r0);	 Catch:{ all -> 0x0186 }
        goto L_0x0122;
    L_0x00e8:
        r5 = r0;
        r5 = (android.support.p002v7.widget.AppCompatDrawableManager.PG) r5;	 Catch:{ all -> 0x0186 }
        r5 = r5.TINT_COLOR_CONTROL_STATE_LIST;	 Catch:{ all -> 0x0186 }
        r5 = android.support.p002v7.widget.AppCompatDrawableManager.PG.arrayContains$ar$ds(r5, r11);	 Catch:{ all -> 0x0186 }
        if (r5 == 0) goto L_0x00fb;
    L_0x00f3:
        r0 = 2131099668; // 0x7f060014 float:1.7811696E38 double:1.052903134E-314;
        r1 = android.support.p002v7.content.res.AppCompatResources.getColorStateList(r10, r0);	 Catch:{ all -> 0x0186 }
        goto L_0x0122;
    L_0x00fb:
        r0 = (android.support.p002v7.widget.AppCompatDrawableManager.PG) r0;	 Catch:{ all -> 0x0186 }
        r0 = r0.TINT_CHECKABLE_BUTTON_LIST;	 Catch:{ all -> 0x0186 }
        r0 = android.support.p002v7.widget.AppCompatDrawableManager.PG.arrayContains$ar$ds(r0, r11);	 Catch:{ all -> 0x0186 }
        if (r0 == 0) goto L_0x010d;
    L_0x0105:
        r0 = 2131099667; // 0x7f060013 float:1.7811694E38 double:1.0529031333E-314;
        r1 = android.support.p002v7.content.res.AppCompatResources.getColorStateList(r10, r0);	 Catch:{ all -> 0x0186 }
        goto L_0x0122;
    L_0x010d:
        if (r11 != r2) goto L_0x011a;
    L_0x010f:
        r11 = 2131099670; // 0x7f060016 float:1.78117E38 double:1.052903135E-314;
        r1 = android.support.p002v7.content.res.AppCompatResources.getColorStateList(r10, r11);	 Catch:{ all -> 0x0186 }
        r11 = 2131230830; // 0x7f08006e float:1.8077724E38 double:1.0529679365E-314;
        goto L_0x0122;
    L_0x011a:
        goto L_0x0122;
    L_0x011b:
        r0 = 2131099671; // 0x7f060017 float:1.7811702E38 double:1.0529031353E-314;
        r1 = android.support.p002v7.content.res.AppCompatResources.getColorStateList(r10, r0);	 Catch:{ all -> 0x0186 }
    L_0x0122:
        if (r1 == 0) goto L_0x0181;
    L_0x0124:
        r0 = r9.mTintLists;	 Catch:{ all -> 0x0186 }
        if (r0 != 0) goto L_0x012f;
    L_0x0128:
        r0 = new java.util.WeakHashMap;	 Catch:{ all -> 0x0186 }
        r0.<init>();	 Catch:{ all -> 0x0186 }
        r9.mTintLists = r0;	 Catch:{ all -> 0x0186 }
    L_0x012f:
        r0 = r9.mTintLists;	 Catch:{ all -> 0x0186 }
        r0 = r0.get(r10);	 Catch:{ all -> 0x0186 }
        r0 = (androidx.collection.SparseArrayCompat) r0;	 Catch:{ all -> 0x0186 }
        if (r0 != 0) goto L_0x0144;
    L_0x0139:
        r0 = new androidx.collection.SparseArrayCompat;	 Catch:{ all -> 0x0186 }
        r0.<init>();	 Catch:{ all -> 0x0186 }
        r2 = r9.mTintLists;	 Catch:{ all -> 0x0186 }
        r2.put(r10, r0);	 Catch:{ all -> 0x0186 }
        goto L_0x0145;
    L_0x0145:
        r10 = r0.mSize;	 Catch:{ all -> 0x0186 }
        if (r10 == 0) goto L_0x0155;
    L_0x0149:
        r2 = r0.mKeys;	 Catch:{ all -> 0x0186 }
        r5 = r10 + -1;
        r2 = r2[r5];	 Catch:{ all -> 0x0186 }
        if (r11 > r2) goto L_0x0155;
    L_0x0151:
        r0.put(r11, r1);	 Catch:{ all -> 0x0186 }
        goto L_0x017f;
    L_0x0155:
        r2 = r0.mKeys;	 Catch:{ all -> 0x0186 }
        r2 = r2.length;	 Catch:{ all -> 0x0186 }
        if (r10 < r2) goto L_0x0174;
    L_0x015a:
        r2 = r10 + 1;
        r2 = androidx.collection.ContainerHelpers.idealIntArraySize(r2);	 Catch:{ all -> 0x0186 }
        r5 = new int[r2];	 Catch:{ all -> 0x0186 }
        r2 = new java.lang.Object[r2];	 Catch:{ all -> 0x0186 }
        r6 = r0.mKeys;	 Catch:{ all -> 0x0186 }
        r7 = r6.length;	 Catch:{ all -> 0x0186 }
        java.lang.System.arraycopy(r6, r4, r5, r4, r7);	 Catch:{ all -> 0x0186 }
        r6 = r0.mValues;	 Catch:{ all -> 0x0186 }
        r7 = r6.length;	 Catch:{ all -> 0x0186 }
        java.lang.System.arraycopy(r6, r4, r2, r4, r7);	 Catch:{ all -> 0x0186 }
        r0.mKeys = r5;	 Catch:{ all -> 0x0186 }
        r0.mValues = r2;	 Catch:{ all -> 0x0186 }
    L_0x0174:
        r2 = r0.mKeys;	 Catch:{ all -> 0x0186 }
        r2[r10] = r11;	 Catch:{ all -> 0x0186 }
        r11 = r0.mValues;	 Catch:{ all -> 0x0186 }
        r11[r10] = r1;	 Catch:{ all -> 0x0186 }
        r10 = r10 + r3;
        r0.mSize = r10;	 Catch:{ all -> 0x0186 }
    L_0x017f:
        monitor-exit(r9);
        return r1;
    L_0x0181:
        r0 = r1;
        goto L_0x0184;
    L_0x0184:
        monitor-exit(r9);
        return r0;
    L_0x0186:
        r10 = move-exception;
        monitor-exit(r9);
        goto L_0x018a;
    L_0x0189:
        throw r10;
    L_0x018a:
        goto L_0x0189;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ResourceManagerInternal.getTintList(android.content.Context, int):android.content.res.ColorStateList");
    }

    public final synchronized void onConfigurationChanged(Context context) {
        LongSparseArray longSparseArray = (LongSparseArray) this.mDrawableCaches.get(context);
        if (longSparseArray != null) {
            longSparseArray.clear();
        }
    }

    public final synchronized void setHooks(ResourceManagerHooks resourceManagerHooks) {
        this.mHooks = resourceManagerHooks;
    }

    final synchronized Drawable getDrawable(Context context, int i, boolean z) {
        Drawable drawable;
        ResourceManagerInternal resourceManagerInternal = this;
        Context context2 = context;
        int i2 = i;
        synchronized (this) {
            Rect rect;
            boolean z2 = false;
            Drawable drawable2;
            if (!resourceManagerInternal.mHasCheckedVectorDrawableSetup) {
                resourceManagerInternal.mHasCheckedVectorDrawableSetup = true;
                drawable2 = getDrawable(context2, R.drawable.abc_vector_test);
                if (drawable2 == null || !((drawable2 instanceof VectorDrawableCompat) || "android.graphics.drawable.VectorDrawable".equals(drawable2.getClass().getName()))) {
                    resourceManagerInternal.mHasCheckedVectorDrawableSetup = false;
                    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
                }
            }
            if (resourceManagerInternal.mTypedValue == null) {
                resourceManagerInternal.mTypedValue = new TypedValue();
            }
            TypedValue typedValue = resourceManagerInternal.mTypedValue;
            context.getResources().getValue(i2, typedValue, true);
            long j = (((long) typedValue.assetCookie) << 32) | ((long) typedValue.data);
            Drawable cachedDrawable = getCachedDrawable(context2, j);
            drawable = null;
            if (cachedDrawable == null) {
                if (resourceManagerInternal.mHooks == null) {
                    cachedDrawable = null;
                } else if (i2 == R.drawable.abc_cab_background_top_material) {
                    cachedDrawable = new LayerDrawable(new Drawable[]{getDrawable(context2, R.drawable.abc_cab_background_internal_bg), getDrawable(context2, R.drawable.abc_cab_background_top_mtrl_alpha)});
                } else if (i2 == R.drawable.abc_ratingbar_material) {
                    cachedDrawable = PG.getRatingBarLayerDrawable$ar$ds(resourceManagerInternal, context2, R.dimen.abc_star_big);
                } else if (i2 == R.drawable.abc_ratingbar_indicator_material) {
                    cachedDrawable = PG.getRatingBarLayerDrawable$ar$ds(resourceManagerInternal, context2, R.dimen.abc_star_medium);
                } else if (i2 == R.drawable.abc_ratingbar_small_material) {
                    cachedDrawable = PG.getRatingBarLayerDrawable$ar$ds(resourceManagerInternal, context2, R.dimen.abc_star_small);
                    i2 = R.drawable.abc_ratingbar_small_material;
                } else {
                    cachedDrawable = null;
                }
                if (cachedDrawable != null) {
                    cachedDrawable.setChangingConfigurations(typedValue.changingConfigurations);
                    addDrawableToCache$ar$ds(context2, j, cachedDrawable);
                }
            }
            if (cachedDrawable == null) {
                cachedDrawable = Api21Impl.getDrawable(context2, i2);
            }
            if (cachedDrawable != null) {
                ColorStateList tintList = getTintList(context2, i2);
                if (tintList != null) {
                    Mode mode;
                    if (DrawableUtils.canSafelyMutateDrawable(cachedDrawable)) {
                        cachedDrawable = cachedDrawable.mutate();
                    }
                    cachedDrawable.setTintList(tintList);
                    if (resourceManagerInternal.mHooks != null) {
                        if (i2 == R.drawable.abc_switch_thumb_material) {
                            mode = Mode.MULTIPLY;
                        }
                    }
                    if (mode != null) {
                        cachedDrawable.setTintMode(mode);
                    }
                } else {
                    ResourceManagerHooks resourceManagerHooks = resourceManagerInternal.mHooks;
                    if (resourceManagerHooks != null) {
                        Drawable findDrawableByLayerId;
                        int themeAttrColor;
                        Mode mode2;
                        LayerDrawable layerDrawable;
                        if (i2 == R.drawable.abc_seekbar_track_material) {
                            layerDrawable = (LayerDrawable) cachedDrawable;
                            PG.setPorterDuffColorFilter$ar$ds(layerDrawable.findDrawableByLayerId(16908288), ThemeUtils.getThemeAttrColor(context2, R.attr.colorControlNormal), AppCompatDrawableManager.DEFAULT_MODE);
                            PG.setPorterDuffColorFilter$ar$ds(layerDrawable.findDrawableByLayerId(16908303), ThemeUtils.getThemeAttrColor(context2, R.attr.colorControlNormal), AppCompatDrawableManager.DEFAULT_MODE);
                            findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908301);
                            themeAttrColor = ThemeUtils.getThemeAttrColor(context2, R.attr.colorControlActivated);
                            mode2 = AppCompatDrawableManager.DEFAULT_MODE;
                        } else if (i2 == R.drawable.abc_ratingbar_material || i2 == R.drawable.abc_ratingbar_indicator_material || i2 == R.drawable.abc_ratingbar_small_material) {
                            layerDrawable = (LayerDrawable) cachedDrawable;
                            PG.setPorterDuffColorFilter$ar$ds(layerDrawable.findDrawableByLayerId(16908288), ThemeUtils.getDisabledThemeAttrColor(context2, R.attr.colorControlNormal), AppCompatDrawableManager.DEFAULT_MODE);
                            PG.setPorterDuffColorFilter$ar$ds(layerDrawable.findDrawableByLayerId(16908303), ThemeUtils.getThemeAttrColor(context2, R.attr.colorControlActivated), AppCompatDrawableManager.DEFAULT_MODE);
                            findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908301);
                            themeAttrColor = ThemeUtils.getThemeAttrColor(context2, R.attr.colorControlActivated);
                            mode2 = AppCompatDrawableManager.DEFAULT_MODE;
                        }
                        PG.setPorterDuffColorFilter$ar$ds(findDrawableByLayerId, themeAttrColor, mode2);
                    }
                    if (resourceManagerHooks != null) {
                        Mode mode3 = AppCompatDrawableManager.DEFAULT_MODE;
                        int i3 = 16842801;
                        if (PG.arrayContains$ar$ds(((PG) resourceManagerHooks).COLORFILTER_TINT_COLOR_CONTROL_NORMAL, i2)) {
                            i2 = -1;
                            z2 = true;
                            i3 = R.attr.colorControlNormal;
                        } else if (PG.arrayContains$ar$ds(((PG) resourceManagerHooks).COLORFILTER_COLOR_CONTROL_ACTIVATED, i2)) {
                            i2 = -1;
                            z2 = true;
                            i3 = R.attr.colorControlActivated;
                        } else if (PG.arrayContains$ar$ds(((PG) resourceManagerHooks).COLORFILTER_COLOR_BACKGROUND_MULTIPLY, i2)) {
                            mode3 = Mode.MULTIPLY;
                            i2 = -1;
                            z2 = true;
                        } else if (i2 == R.drawable.abc_list_divider_mtrl_alpha) {
                            i2 = Math.round(40.8f);
                            z2 = true;
                            i3 = 16842800;
                        } else if (i2 == R.drawable.abc_dialog_material_background) {
                            i2 = -1;
                            z2 = true;
                        } else {
                            i2 = -1;
                            i3 = 0;
                        }
                        if (z2) {
                            if (DrawableUtils.canSafelyMutateDrawable(cachedDrawable)) {
                                drawable2 = cachedDrawable.mutate();
                            } else {
                                drawable2 = cachedDrawable;
                            }
                            drawable2.setColorFilter(AppCompatDrawableManager.getPorterDuffColorFilter(ThemeUtils.getThemeAttrColor(context2, i3), mode3));
                            if (i2 != -1) {
                                drawable2.setAlpha(i2);
                            }
                        }
                    }
                    if (z) {
                        if (drawable != null) {
                            rect = DrawableUtils.INSETS_NONE;
                        }
                    }
                }
                drawable = cachedDrawable;
                if (drawable != null) {
                    rect = DrawableUtils.INSETS_NONE;
                }
            }
            drawable = cachedDrawable;
            if (drawable != null) {
                rect = DrawableUtils.INSETS_NONE;
            }
        }
        return drawable;
    }
}
