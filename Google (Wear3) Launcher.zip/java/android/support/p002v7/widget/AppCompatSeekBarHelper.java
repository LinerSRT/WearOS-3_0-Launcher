package android.support.p002v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.SeekBar;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatSeekBarHelper */
final class AppCompatSeekBarHelper extends AppCompatProgressBarHelper {
    private boolean mHasTickMarkTint = false;
    private boolean mHasTickMarkTintMode = false;
    public Drawable mTickMark;
    private ColorStateList mTickMarkTintList = null;
    private Mode mTickMarkTintMode = null;
    public final SeekBar mView;

    public AppCompatSeekBarHelper(SeekBar seekBar) {
        super(seekBar);
        this.mView = seekBar;
    }

    private final void applyTickMarkTint() {
        Drawable drawable = this.mTickMark;
        if (drawable == null) {
            return;
        }
        if (this.mHasTickMarkTint || this.mHasTickMarkTintMode) {
            drawable = drawable.mutate();
            this.mTickMark = drawable;
            if (this.mHasTickMarkTint) {
                drawable.setTintList(this.mTickMarkTintList);
            }
            if (this.mHasTickMarkTintMode) {
                this.mTickMark.setTintMode(this.mTickMarkTintMode);
            }
            if (this.mTickMark.isStateful()) {
                this.mTickMark.setState(this.mView.getDrawableState());
            }
        }
    }

    public final void loadFromAttributes(AttributeSet attributeSet, int i) {
        super.loadFromAttributes(attributeSet, R.attr.seekBarStyle);
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(this.mView.getContext(), attributeSet, R$styleable.AppCompatSeekBar, R.attr.seekBarStyle);
        View view = this.mView;
        ViewCompat.saveAttributeDataForStyleable(view, view.getContext(), R$styleable.AppCompatSeekBar, attributeSet, obtainStyledAttributes$ar$ds.mWrapped, R.attr.seekBarStyle, 0);
        Drawable drawableIfKnown = obtainStyledAttributes$ar$ds.getDrawableIfKnown(0);
        if (drawableIfKnown != null) {
            this.mView.setThumb(drawableIfKnown);
        }
        Drawable drawable = obtainStyledAttributes$ar$ds.getDrawable(1);
        Drawable drawable2 = this.mTickMark;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.mTickMark = drawable;
        if (drawable != null) {
            drawable.setCallback(this.mView);
            drawable.setLayoutDirection(ViewCompat.getLayoutDirection(this.mView));
            if (drawable.isStateful()) {
                drawable.setState(this.mView.getDrawableState());
            }
            applyTickMarkTint();
        }
        this.mView.invalidate();
        if (obtainStyledAttributes$ar$ds.hasValue(3)) {
            this.mTickMarkTintMode = DrawableUtils.parseTintMode(obtainStyledAttributes$ar$ds.getInt(3, -1), this.mTickMarkTintMode);
            this.mHasTickMarkTintMode = true;
        }
        if (obtainStyledAttributes$ar$ds.hasValue(2)) {
            this.mTickMarkTintList = obtainStyledAttributes$ar$ds.getColorStateList(2);
            this.mHasTickMarkTint = true;
        }
        obtainStyledAttributes$ar$ds.recycle();
        applyTickMarkTint();
    }
}
