package android.support.p002v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.p000v4.graphics.Insets;
import android.support.p000v4.view.NestedScrollingParent2;
import android.support.p000v4.view.NestedScrollingParent3;
import android.support.p000v4.view.NestedScrollingParentHelper;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.WindowInsetsCompat;
import android.support.p000v4.view.WindowInsetsCompat.Builder;
import android.support.p000v4.view.WindowInsetsCompat.BuilderImpl;
import android.support.p000v4.view.WindowInsetsCompat.BuilderImpl30;
import android.support.p002v7.app.WindowDecorActionBar;
import android.support.p002v7.view.ViewPropertyAnimatorCompatSet;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.support.v7.widget.ActionBarOverlayLayout.C00892;
import android.support.v7.widget.ActionBarOverlayLayout.C00903;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ActionBarOverlayLayout */
public class ActionBarOverlayLayout extends ViewGroup implements DecorContentParent, NestedScrollingParent2, NestedScrollingParent3 {
    static final int[] ATTRS = new int[]{R.attr.actionBarSize, 16842841};
    private int mActionBarHeight;
    ActionBarContainer mActionBarTop;
    public ActionBarVisibilityCallback mActionBarVisibilityCallback;
    private final Runnable mAddActionBarHideOffset;
    boolean mAnimatingForFling;
    private final Rect mBaseContentInsets;
    private WindowInsetsCompat mBaseInnerInsets;
    private ContentFrameLayout mContent;
    private final Rect mContentInsets;
    ViewPropertyAnimator mCurrentActionBarTopAnimator;
    private DecorToolbar mDecorToolbar;
    private OverScroller mFlingEstimator;
    public boolean mHasNonEmbeddedTabs;
    private boolean mHideOnContentScroll;
    private int mHideOnContentScrollReference;
    private boolean mIgnoreWindowContentOverlay;
    private WindowInsetsCompat mInnerInsets;
    private final Rect mLastBaseContentInsets;
    private WindowInsetsCompat mLastBaseInnerInsets;
    private WindowInsetsCompat mLastInnerInsets;
    public int mLastSystemUiVisibility;
    public boolean mOverlayMode;
    private final NestedScrollingParentHelper mParentHelper;
    private final Runnable mRemoveActionBarHideOffset;
    final AnimatorListenerAdapter mTopAnimatorListener;
    private Drawable mWindowContentOverlay;
    public int mWindowVisibility;

    /* renamed from: android.support.v7.widget.ActionBarOverlayLayout$1 */
    final class PG extends AnimatorListenerAdapter {
        public final void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.mCurrentActionBarTopAnimator = null;
            actionBarOverlayLayout.mAnimatingForFling = false;
        }

        public final void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.mCurrentActionBarTopAnimator = null;
            actionBarOverlayLayout.mAnimatingForFling = false;
        }
    }

    /* renamed from: android.support.v7.widget.ActionBarOverlayLayout$2 */
    final class C00892 implements Runnable {
        public final void run() {
            android.support.p002v7.widget.ActionBarOverlayLayout.this.haltActionBarHideOffsetAnimations();
            android.support.p002v7.widget.ActionBarOverlayLayout actionBarOverlayLayout = android.support.p002v7.widget.ActionBarOverlayLayout.this;
            actionBarOverlayLayout.mCurrentActionBarTopAnimator = actionBarOverlayLayout.mActionBarTop.animate().translationY(0.0f).setListener(android.support.p002v7.widget.ActionBarOverlayLayout.this.mTopAnimatorListener);
        }
    }

    /* renamed from: android.support.v7.widget.ActionBarOverlayLayout$3 */
    final class C00903 implements Runnable {
        public final void run() {
            android.support.p002v7.widget.ActionBarOverlayLayout.this.haltActionBarHideOffsetAnimations();
            android.support.p002v7.widget.ActionBarOverlayLayout actionBarOverlayLayout = android.support.p002v7.widget.ActionBarOverlayLayout.this;
            actionBarOverlayLayout.mCurrentActionBarTopAnimator = actionBarOverlayLayout.mActionBarTop.animate().translationY((float) (-android.support.p002v7.widget.ActionBarOverlayLayout.this.mActionBarTop.getHeight())).setListener(android.support.p002v7.widget.ActionBarOverlayLayout.this.mTopAnimatorListener);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionBarOverlayLayout$ActionBarVisibilityCallback */
    public interface ActionBarVisibilityCallback {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionBarOverlayLayout$LayoutParams */
    public final class LayoutParams extends MarginLayoutParams {
        public LayoutParams() {
            super(-1, -1);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context) {
        this(context, null);
    }

    private static final boolean applyInsets$ar$ds(View view, Rect rect, boolean z) {
        boolean z2;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (layoutParams.leftMargin != rect.left) {
            layoutParams.leftMargin = rect.left;
            z2 = true;
        } else {
            z2 = false;
        }
        if (layoutParams.topMargin != rect.top) {
            layoutParams.topMargin = rect.top;
            z2 = true;
        }
        if (layoutParams.rightMargin != rect.right) {
            layoutParams.rightMargin = rect.right;
            z2 = true;
        }
        if (!z || layoutParams.bottomMargin == rect.bottom) {
            return z2;
        }
        layoutParams.bottomMargin = rect.bottom;
        return true;
    }

    private final void init(Context context) {
        boolean z;
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(ATTRS);
        boolean z2 = false;
        this.mActionBarHeight = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.mWindowContentOverlay = drawable;
        if (drawable == null) {
            z = true;
        } else {
            z = false;
        }
        setWillNotDraw(z);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z2 = true;
        }
        this.mIgnoreWindowContentOverlay = z2;
        this.mFlingEstimator = new OverScroller(context);
    }

    public final boolean canShowOverflowMenu() {
        pullChildren();
        return this.mDecorToolbar.canShowOverflowMenu();
    }

    protected final boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public final void dismissPopups() {
        pullChildren();
        this.mDecorToolbar.dismissPopupMenus();
    }

    public final void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.mWindowContentOverlay != null && !this.mIgnoreWindowContentOverlay) {
            int bottom;
            if (this.mActionBarTop.getVisibility() == 0) {
                bottom = (int) ((((float) this.mActionBarTop.getBottom()) + this.mActionBarTop.getTranslationY()) + 0.5f);
            } else {
                bottom = 0;
            }
            this.mWindowContentOverlay.setBounds(0, bottom, getWidth(), this.mWindowContentOverlay.getIntrinsicHeight() + bottom);
            this.mWindowContentOverlay.draw(canvas);
        }
    }

    public final int getNestedScrollAxes() {
        return this.mParentHelper.getNestedScrollAxes();
    }

    final void haltActionBarHideOffsetAnimations() {
        removeCallbacks(this.mRemoveActionBarHideOffset);
        removeCallbacks(this.mAddActionBarHideOffset);
        ViewPropertyAnimator viewPropertyAnimator = this.mCurrentActionBarTopAnimator;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final boolean hideOverflowMenu() {
        pullChildren();
        return this.mDecorToolbar.hideOverflowMenu();
    }

    public final void initFeature(int i) {
        pullChildren();
        switch (i) {
            case 2:
                this.mDecorToolbar.initProgress();
                return;
            case 5:
                this.mDecorToolbar.initIndeterminateProgress();
                return;
            case 109:
                boolean z = true;
                this.mOverlayMode = true;
                if (getContext().getApplicationInfo().targetSdkVersion >= 19) {
                    z = false;
                }
                this.mIgnoreWindowContentOverlay = z;
                return;
            default:
                return;
        }
    }

    public final boolean isOverflowMenuShowPending() {
        pullChildren();
        return this.mDecorToolbar.isOverflowMenuShowPending();
    }

    public final boolean isOverflowMenuShowing() {
        pullChildren();
        return this.mDecorToolbar.isOverflowMenuShowing();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.WindowInsets onApplyWindowInsets(android.view.WindowInsets r6) {
        /*
        r5 = this;
        r5.pullChildren();
        r6 = android.support.p000v4.view.WindowInsetsCompat.toWindowInsetsCompat(r6, r5);
        r0 = new android.graphics.Rect;
        r1 = r6.getSystemWindowInsetLeft();
        r2 = r6.getSystemWindowInsetTop();
        r3 = r6.getSystemWindowInsetRight();
        r4 = r6.getSystemWindowInsetBottom();
        r0.<init>(r1, r2, r3, r4);
        r1 = r5.mActionBarTop;
        r2 = 0;
        r0 = android.support.p002v7.widget.ActionBarOverlayLayout.applyInsets$ar$ds(r1, r0, r2);
        r1 = r5.mBaseContentInsets;
        android.support.p000v4.view.ViewCompat.computeSystemWindowInsets$ar$ds(r5, r6, r1);
        r1 = r5.mBaseContentInsets;
        r1 = r1.left;
        r2 = r5.mBaseContentInsets;
        r2 = r2.top;
        r3 = r5.mBaseContentInsets;
        r3 = r3.right;
        r4 = r5.mBaseContentInsets;
        r4 = r4.bottom;
        r1 = r6.inset(r1, r2, r3, r4);
        r5.mBaseInnerInsets = r1;
        r2 = r5.mLastBaseInnerInsets;
        r1 = r2.equals(r1);
        if (r1 != 0) goto L_0x004b;
    L_0x0046:
        r0 = r5.mBaseInnerInsets;
        r5.mLastBaseInnerInsets = r0;
        r0 = 1;
    L_0x004b:
        r1 = r5.mLastBaseContentInsets;
        r2 = r5.mBaseContentInsets;
        r1 = r1.equals(r2);
        if (r1 != 0) goto L_0x005d;
    L_0x0055:
        r0 = r5.mLastBaseContentInsets;
        r1 = r5.mBaseContentInsets;
        r0.set(r1);
        goto L_0x005f;
    L_0x005d:
        if (r0 == 0) goto L_0x0062;
    L_0x005f:
        r5.requestLayout();
    L_0x0062:
        r6 = r6.consumeDisplayCutout();
        r6 = r6.consumeSystemWindowInsets();
        r6 = r6.consumeStableInsets();
        r6 = r6.toWindowInsets();
        return r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ActionBarOverlayLayout.onApplyWindowInsets(android.view.WindowInsets):android.view.WindowInsets");
    }

    protected final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        init(getContext());
        ViewCompat.requestApplyInsets(this);
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        haltActionBarHideOffsetAnimations();
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        i = getPaddingLeft();
        i2 = getPaddingTop();
        for (i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int i5 = layoutParams.leftMargin + i;
                int i6 = layoutParams.topMargin + i2;
                childAt.layout(i5, i6, childAt.getMeasuredWidth() + i5, childAt.getMeasuredHeight() + i6);
            }
        }
    }

    protected final void onMeasure(int i, int i2) {
        pullChildren();
        measureChildWithMargins(this.mActionBarTop, i, 0, i2, 0);
        LayoutParams layoutParams = (LayoutParams) this.mActionBarTop.getLayoutParams();
        int max = Math.max(0, (this.mActionBarTop.getMeasuredWidth() + layoutParams.leftMargin) + layoutParams.rightMargin);
        int max2 = Math.max(0, (this.mActionBarTop.getMeasuredHeight() + layoutParams.topMargin) + layoutParams.bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.mActionBarTop.getMeasuredState());
        int windowSystemUiVisibility = ViewCompat.getWindowSystemUiVisibility(this) & 256;
        int measuredHeight = windowSystemUiVisibility != 0 ? this.mActionBarHeight : this.mActionBarTop.getVisibility() != 8 ? this.mActionBarTop.getMeasuredHeight() : 0;
        this.mContentInsets.set(this.mBaseContentInsets);
        WindowInsetsCompat windowInsetsCompat = this.mBaseInnerInsets;
        this.mInnerInsets = windowInsetsCompat;
        if (this.mOverlayMode || windowSystemUiVisibility != 0) {
            Insets of = Insets.m0of(windowInsetsCompat.getSystemWindowInsetLeft(), this.mInnerInsets.getSystemWindowInsetTop() + measuredHeight, this.mInnerInsets.getSystemWindowInsetRight(), this.mInnerInsets.getSystemWindowInsetBottom());
            BuilderImpl builderImpl30 = new BuilderImpl30(this.mInnerInsets);
            Builder.setSystemWindowInsets$ar$ds$ar$objectUnboxing(of, builderImpl30);
            this.mInnerInsets = Builder.build$ar$objectUnboxing$d0a2c6a9_0(builderImpl30);
        } else {
            Rect rect = this.mContentInsets;
            rect.top += measuredHeight;
            rect = this.mContentInsets;
            rect.bottom = rect.bottom;
            this.mInnerInsets = this.mInnerInsets.inset(0, measuredHeight, 0, 0);
        }
        ActionBarOverlayLayout.applyInsets$ar$ds(this.mContent, this.mContentInsets, true);
        if (!this.mLastInnerInsets.equals(this.mInnerInsets)) {
            WindowInsetsCompat windowInsetsCompat2 = this.mInnerInsets;
            this.mLastInnerInsets = windowInsetsCompat2;
            ViewCompat.dispatchApplyWindowInsets(this.mContent, windowInsetsCompat2);
        }
        measureChildWithMargins(this.mContent, i, 0, i2, 0);
        LayoutParams layoutParams2 = (LayoutParams) this.mContent.getLayoutParams();
        max = Math.max(max, (this.mContent.getMeasuredWidth() + layoutParams2.leftMargin) + layoutParams2.rightMargin);
        max2 = Math.max(max2, (this.mContent.getMeasuredHeight() + layoutParams2.topMargin) + layoutParams2.bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.mContent.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(max + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i, combineMeasuredStates2), View.resolveSizeAndState(Math.max(max2 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i2, combineMeasuredStates2 << 16));
    }

    public final boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public final void onNestedPreScroll$ar$ds(int i, int i2, int[] iArr, int i3) {
    }

    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.mHideOnContentScrollReference + i2;
        this.mHideOnContentScrollReference = i5;
        setActionBarHideOffset(i5);
    }

    public final void onNestedScrollAccepted(View view, View view2, int i) {
        int i2;
        this.mParentHelper.onNestedScrollAccepted$ar$ds$aeb476d8_0(i);
        ActionBarContainer actionBarContainer = this.mActionBarTop;
        if (actionBarContainer != null) {
            i2 = -((int) actionBarContainer.getTranslationY());
        } else {
            i2 = 0;
        }
        this.mHideOnContentScrollReference = i2;
        haltActionBarHideOffsetAnimations();
        ActionBarVisibilityCallback actionBarVisibilityCallback = this.mActionBarVisibilityCallback;
        if (actionBarVisibilityCallback != null) {
            WindowDecorActionBar windowDecorActionBar = (WindowDecorActionBar) actionBarVisibilityCallback;
            ViewPropertyAnimatorCompatSet viewPropertyAnimatorCompatSet = windowDecorActionBar.mCurrentShowAnim;
            if (viewPropertyAnimatorCompatSet != null) {
                viewPropertyAnimatorCompatSet.cancel();
                windowDecorActionBar.mCurrentShowAnim = null;
            }
        }
    }

    public final boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) != 0) {
            if (this.mActionBarTop.getVisibility() == 0) {
                return this.mHideOnContentScroll;
            }
        }
        return false;
    }

    public final void onStopNestedScroll(View view) {
        if (this.mHideOnContentScroll && !this.mAnimatingForFling) {
            if (this.mHideOnContentScrollReference <= this.mActionBarTop.getHeight()) {
                haltActionBarHideOffsetAnimations();
                postDelayed(this.mRemoveActionBarHideOffset, 600);
                return;
            }
            haltActionBarHideOffsetAnimations();
            postDelayed(this.mAddActionBarHideOffset, 600);
        }
    }

    @Deprecated
    public final void onWindowSystemUiVisibilityChanged(int i) {
        super.onWindowSystemUiVisibilityChanged(i);
        pullChildren();
        int i2 = this.mLastSystemUiVisibility ^ i;
        this.mLastSystemUiVisibility = i;
        int i3 = i & 4;
        i &= 256;
        ActionBarVisibilityCallback actionBarVisibilityCallback = this.mActionBarVisibilityCallback;
        if (actionBarVisibilityCallback != null) {
            boolean z;
            if (i == 0) {
                z = true;
            } else {
                z = false;
            }
            WindowDecorActionBar windowDecorActionBar = (WindowDecorActionBar) actionBarVisibilityCallback;
            windowDecorActionBar.mContentAnimations = z;
            if (i3 != 0) {
                if (i != 0) {
                    if (!windowDecorActionBar.mHiddenBySystem) {
                        windowDecorActionBar.mHiddenBySystem = true;
                        windowDecorActionBar.updateVisibility(true);
                    }
                }
            }
            if (windowDecorActionBar.mHiddenBySystem) {
                windowDecorActionBar.mHiddenBySystem = false;
                windowDecorActionBar.updateVisibility(true);
            }
        }
        if ((i2 & 256) != 0 && this.mActionBarVisibilityCallback != null) {
            ViewCompat.requestApplyInsets(this);
        }
    }

    protected final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.mWindowVisibility = i;
        ActionBarVisibilityCallback actionBarVisibilityCallback = this.mActionBarVisibilityCallback;
        if (actionBarVisibilityCallback != null) {
            ((WindowDecorActionBar) actionBarVisibilityCallback).mCurWindowVisibility = i;
        }
    }

    final void pullChildren() {
        if (this.mContent == null) {
            DecorToolbar decorToolbar;
            this.mContent = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.mActionBarTop = (ActionBarContainer) findViewById(R.id.action_bar_container);
            View findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof DecorToolbar) {
                decorToolbar = (DecorToolbar) findViewById;
            } else if (findViewById instanceof Toolbar) {
                decorToolbar = ((Toolbar) findViewById).getWrapper();
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Can't make a decor toolbar out of ");
                stringBuilder.append(findViewById.getClass().getSimpleName());
                throw new IllegalStateException(stringBuilder.toString());
            }
            this.mDecorToolbar = decorToolbar;
        }
    }

    public final void setActionBarHideOffset(int i) {
        haltActionBarHideOffsetAnimations();
        this.mActionBarTop.setTranslationY((float) (-Math.max(0, Math.min(i, this.mActionBarTop.getHeight()))));
    }

    public final void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.mHideOnContentScroll) {
            this.mHideOnContentScroll = z;
            if (!z) {
                haltActionBarHideOffsetAnimations();
                setActionBarHideOffset(0);
            }
        }
    }

    public final void setMenu(Menu menu, Callback callback) {
        pullChildren();
        this.mDecorToolbar.setMenu(menu, callback);
    }

    public final void setMenuPrepared() {
        pullChildren();
        this.mDecorToolbar.setMenuPrepared();
    }

    public final void setWindowCallback(Window.Callback callback) {
        pullChildren();
        this.mDecorToolbar.setWindowCallback(callback);
    }

    public final void setWindowTitle(CharSequence charSequence) {
        pullChildren();
        this.mDecorToolbar.setWindowTitle(charSequence);
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public final boolean showOverflowMenu() {
        pullChildren();
        return this.mDecorToolbar.showOverflowMenu();
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mWindowVisibility = 0;
        this.mBaseContentInsets = new Rect();
        this.mLastBaseContentInsets = new Rect();
        this.mContentInsets = new Rect();
        Rect rect = new Rect();
        rect = new Rect();
        rect = new Rect();
        rect = new Rect();
        this.mBaseInnerInsets = WindowInsetsCompat.CONSUMED;
        this.mLastBaseInnerInsets = WindowInsetsCompat.CONSUMED;
        this.mInnerInsets = WindowInsetsCompat.CONSUMED;
        this.mLastInnerInsets = WindowInsetsCompat.CONSUMED;
        this.mTopAnimatorListener = new PG();
        this.mRemoveActionBarHideOffset = new C00892();
        this.mAddActionBarHideOffset = new C00903();
        init(context);
        this.mParentHelper = new NestedScrollingParentHelper();
    }

    protected final /* bridge */ /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams();
    }

    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (this.mHideOnContentScroll) {
            if (z) {
                this.mFlingEstimator.fling(0, 0, 0, (int) f2, 0, 0, LinearLayoutManager.INVALID_OFFSET, Integer.MAX_VALUE);
                if (this.mFlingEstimator.getFinalY() > this.mActionBarTop.getHeight()) {
                    haltActionBarHideOffsetAnimations();
                    this.mAddActionBarHideOffset.run();
                } else {
                    haltActionBarHideOffsetAnimations();
                    this.mRemoveActionBarHideOffset.run();
                }
                this.mAnimatingForFling = true;
                return true;
            }
        }
        return false;
    }

    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    public final boolean onStartNestedScroll(View view, View view2, int i, int i2) {
        return i2 == 0 && onStartNestedScroll(view, view2, i);
    }

    protected final LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        onNestedScroll(view, i, i2, i3, i4, i5);
    }

    public final void onStopNestedScroll(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    public final void onNestedScrollAccepted(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }
}
