package android.support.p002v7.widget;

import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.content.res.AppCompatResources;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatImageHelper */
public final class AppCompatImageHelper {
    private final ImageView mView;

    public AppCompatImageHelper(ImageView imageView) {
        this.mView = imageView;
    }

    final void applySupportImageTint() {
        if (this.mView.getDrawable() != null) {
            Rect rect = DrawableUtils.INSETS_NONE;
        }
    }

    final boolean hasOverlappingRendering() {
        return !(this.mView.getBackground() instanceof RippleDrawable);
    }

    public final void loadFromAttributes(AttributeSet attributeSet, int i) {
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(this.mView.getContext(), attributeSet, R$styleable.AppCompatImageView, i);
        View view = this.mView;
        ViewCompat.saveAttributeDataForStyleable(view, view.getContext(), R$styleable.AppCompatImageView, attributeSet, obtainStyledAttributes$ar$ds.mWrapped, i, 0);
        try {
            Drawable drawable = this.mView.getDrawable();
            if (drawable == null) {
                int resourceId = obtainStyledAttributes$ar$ds.getResourceId(1, -1);
                if (resourceId != -1) {
                    drawable = AppCompatResources.getDrawable(this.mView.getContext(), resourceId);
                    if (drawable != null) {
                        this.mView.setImageDrawable(drawable);
                    }
                }
            }
            if (drawable != null) {
                Rect rect = DrawableUtils.INSETS_NONE;
            }
            if (obtainStyledAttributes$ar$ds.hasValue(2)) {
                this.mView.setImageTintList(obtainStyledAttributes$ar$ds.getColorStateList(2));
            }
            if (obtainStyledAttributes$ar$ds.hasValue(3)) {
                this.mView.setImageTintMode(DrawableUtils.parseTintMode(obtainStyledAttributes$ar$ds.getInt(3, -1), null));
            }
            obtainStyledAttributes$ar$ds.recycle();
        } catch (Throwable th) {
            obtainStyledAttributes$ar$ds.recycle();
        }
    }

    public final void setImageResource(int i) {
        if (i != 0) {
            Drawable drawable = AppCompatResources.getDrawable(this.mView.getContext(), i);
            if (drawable != null) {
                Rect rect = DrawableUtils.INSETS_NONE;
            }
            this.mView.setImageDrawable(drawable);
        } else {
            this.mView.setImageDrawable(null);
        }
        applySupportImageTint();
    }
}
