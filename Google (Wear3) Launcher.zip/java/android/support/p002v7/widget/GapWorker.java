package android.support.p002v7.widget;

import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.LayoutManager.LayoutPrefetchRegistry;
import android.support.p002v7.widget.RecyclerView.Recycler;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.GapWorker */
final class GapWorker implements Runnable {
    static final ThreadLocal sGapWorker = new ThreadLocal();
    static final Comparator sTaskComparator = new PG();
    long mFrameIntervalNs;
    long mPostTimeNs;
    final ArrayList mRecyclerViews = new ArrayList();
    private final ArrayList mTasks = new ArrayList();

    /* renamed from: android.support.v7.widget.GapWorker$1 */
    final class PG implements Comparator {
        public final /* bridge */ /* synthetic */ int compare(Object obj, Object obj2) {
            Object obj3;
            Object obj4;
            Task task = (Task) obj;
            Task task2 = (Task) obj2;
            RecyclerView recyclerView = task.view;
            int i = 1;
            if (recyclerView != null) {
                obj3 = null;
            } else {
                obj3 = 1;
            }
            if (task2.view != null) {
                obj4 = null;
            } else {
                obj4 = 1;
            }
            if (obj3 == obj4) {
                boolean z = task.immediate;
                if (z == task2.immediate) {
                    i = task2.viewVelocity - task.viewVelocity;
                    if (i == 0) {
                        i = task.distanceToItem - task2.distanceToItem;
                        if (i == 0) {
                            return 0;
                        }
                    }
                } else if (z) {
                    return -1;
                }
            } else if (recyclerView == null) {
                return 1;
            } else {
                i = -1;
            }
            return i;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.GapWorker$LayoutPrefetchRegistryImpl */
    final class LayoutPrefetchRegistryImpl implements LayoutPrefetchRegistry {
        int mCount;
        int[] mPrefetchArray;
        int mPrefetchDx;
        int mPrefetchDy;

        public final void addPosition(int i, int i2) {
            if (i < 0) {
                throw new IllegalArgumentException("Layout positions must be non-negative");
            } else if (i2 >= 0) {
                int[] iArr;
                int i3 = this.mCount;
                i3 += i3;
                Object obj = this.mPrefetchArray;
                if (obj == null) {
                    iArr = new int[4];
                    this.mPrefetchArray = iArr;
                    Arrays.fill(iArr, -1);
                } else {
                    int length = obj.length;
                    if (i3 >= length) {
                        Object obj2 = new int[(i3 + i3)];
                        this.mPrefetchArray = obj2;
                        System.arraycopy(obj, 0, obj2, 0, length);
                    }
                }
                iArr = this.mPrefetchArray;
                iArr[i3] = i;
                iArr[i3 + 1] = i2;
                this.mCount++;
            } else {
                throw new IllegalArgumentException("Pixel distance must be non-negative");
            }
        }

        final void clearPrefetchPositions() {
            int[] iArr = this.mPrefetchArray;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.mCount = 0;
        }

        final void collectPrefetchPositionsFromView(RecyclerView recyclerView, boolean z) {
            this.mCount = 0;
            int[] iArr = this.mPrefetchArray;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            LayoutManager layoutManager = recyclerView.mLayout;
            if (!(recyclerView.mAdapter == null || layoutManager == null || !layoutManager.isItemPrefetchEnabled())) {
                if (z) {
                    if (!recyclerView.mAdapterHelper.hasPendingUpdates()) {
                        layoutManager.collectInitialPrefetchPositions(recyclerView.mAdapter.getItemCount(), this);
                    }
                } else if (!recyclerView.hasPendingAdapterUpdates()) {
                    layoutManager.collectAdjacentPrefetchPositions(this.mPrefetchDx, this.mPrefetchDy, recyclerView.mState, this);
                }
                int i = this.mCount;
                if (i > layoutManager.mPrefetchMaxCountObserved) {
                    layoutManager.mPrefetchMaxCountObserved = i;
                    layoutManager.mPrefetchMaxObservedInInitialPrefetch = z;
                    recyclerView.mRecycler.updateViewCacheSize();
                }
            }
        }

        final boolean lastPrefetchIncludedPosition(int i) {
            if (this.mPrefetchArray != null) {
                int i2 = this.mCount;
                i2 += i2;
                for (int i3 = 0; i3 < i2; i3 += 2) {
                    if (this.mPrefetchArray[i3] == i) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.GapWorker$Task */
    final class Task {
        public int distanceToItem;
        public boolean immediate;
        public int position;
        public RecyclerView view;
        public int viewVelocity;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
        r17 = this;
        r1 = r17;
        r2 = 0;
        r0 = "RV Prefetch";
        android.os.Trace.beginSection(r0);	 Catch:{ all -> 0x0184 }
        r0 = r1.mRecyclerViews;	 Catch:{ all -> 0x0184 }
        r0 = r0.isEmpty();	 Catch:{ all -> 0x0184 }
        if (r0 == 0) goto L_0x0017;
    L_0x0011:
        r1.mPostTimeNs = r2;
    L_0x0013:
        android.os.Trace.endSection();
        return;
    L_0x0017:
        r0 = r1.mRecyclerViews;	 Catch:{ all -> 0x0184 }
        r0 = r0.size();	 Catch:{ all -> 0x0184 }
        r4 = 0;
        r6 = r2;
        r5 = 0;
    L_0x0020:
        if (r5 >= r0) goto L_0x003b;
    L_0x0022:
        r8 = r1.mRecyclerViews;	 Catch:{ all -> 0x0184 }
        r8 = r8.get(r5);	 Catch:{ all -> 0x0184 }
        r8 = (android.support.p002v7.widget.RecyclerView) r8;	 Catch:{ all -> 0x0184 }
        r9 = r8.getWindowVisibility();	 Catch:{ all -> 0x0184 }
        if (r9 != 0) goto L_0x0038;
    L_0x0030:
        r8 = r8.getDrawingTime();	 Catch:{ all -> 0x0184 }
        r6 = java.lang.Math.max(r8, r6);	 Catch:{ all -> 0x0184 }
    L_0x0038:
        r5 = r5 + 1;
        goto L_0x0020;
    L_0x003b:
        r0 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));
        if (r0 != 0) goto L_0x0042;
    L_0x003f:
        r1.mPostTimeNs = r2;
        goto L_0x0013;
    L_0x0042:
        r0 = java.util.concurrent.TimeUnit.MILLISECONDS;	 Catch:{ all -> 0x0184 }
        r5 = r0.toNanos(r6);	 Catch:{ all -> 0x0184 }
        r7 = r1.mFrameIntervalNs;	 Catch:{ all -> 0x0184 }
        r5 = r5 + r7;
        r0 = r1.mRecyclerViews;	 Catch:{ all -> 0x0184 }
        r0 = r0.size();	 Catch:{ all -> 0x0184 }
        r7 = 0;
        r8 = 0;
    L_0x0053:
        if (r7 >= r0) goto L_0x0070;
    L_0x0055:
        r9 = r1.mRecyclerViews;	 Catch:{ all -> 0x0184 }
        r9 = r9.get(r7);	 Catch:{ all -> 0x0184 }
        r9 = (android.support.p002v7.widget.RecyclerView) r9;	 Catch:{ all -> 0x0184 }
        r10 = r9.getWindowVisibility();	 Catch:{ all -> 0x0184 }
        if (r10 != 0) goto L_0x006d;
    L_0x0063:
        r10 = r9.mPrefetchRegistry;	 Catch:{ all -> 0x0184 }
        r10.collectPrefetchPositionsFromView(r9, r4);	 Catch:{ all -> 0x0184 }
        r9 = r9.mPrefetchRegistry;	 Catch:{ all -> 0x0184 }
        r9 = r9.mCount;	 Catch:{ all -> 0x0184 }
        r8 = r8 + r9;
    L_0x006d:
        r7 = r7 + 1;
        goto L_0x0053;
    L_0x0070:
        r7 = r1.mTasks;	 Catch:{ all -> 0x0184 }
        r7.ensureCapacity(r8);	 Catch:{ all -> 0x0184 }
        r7 = 0;
        r8 = 0;
    L_0x0077:
        r9 = 1;
        if (r7 >= r0) goto L_0x00db;
    L_0x007a:
        r10 = r1.mRecyclerViews;	 Catch:{ all -> 0x0184 }
        r10 = r10.get(r7);	 Catch:{ all -> 0x0184 }
        r10 = (android.support.p002v7.widget.RecyclerView) r10;	 Catch:{ all -> 0x0184 }
        r11 = r10.getWindowVisibility();	 Catch:{ all -> 0x0184 }
        if (r11 != 0) goto L_0x00d6;
    L_0x0088:
        r11 = r10.mPrefetchRegistry;	 Catch:{ all -> 0x0184 }
        r12 = r11.mPrefetchDx;	 Catch:{ all -> 0x0184 }
        r12 = java.lang.Math.abs(r12);	 Catch:{ all -> 0x0184 }
        r13 = r11.mPrefetchDy;	 Catch:{ all -> 0x0184 }
        r13 = java.lang.Math.abs(r13);	 Catch:{ all -> 0x0184 }
        r12 = r12 + r13;
        r13 = 0;
    L_0x0098:
        r14 = r11.mCount;	 Catch:{ all -> 0x0184 }
        r14 = r14 + r14;
        if (r13 >= r14) goto L_0x00d6;
    L_0x009d:
        r14 = r1.mTasks;	 Catch:{ all -> 0x0184 }
        r14 = r14.size();	 Catch:{ all -> 0x0184 }
        if (r8 < r14) goto L_0x00b0;
    L_0x00a5:
        r14 = new android.support.v7.widget.GapWorker$Task;	 Catch:{ all -> 0x0184 }
        r14.<init>();	 Catch:{ all -> 0x0184 }
        r15 = r1.mTasks;	 Catch:{ all -> 0x0184 }
        r15.add(r14);	 Catch:{ all -> 0x0184 }
        goto L_0x00b8;
    L_0x00b0:
        r14 = r1.mTasks;	 Catch:{ all -> 0x0184 }
        r14 = r14.get(r8);	 Catch:{ all -> 0x0184 }
        r14 = (android.support.p002v7.widget.GapWorker.Task) r14;	 Catch:{ all -> 0x0184 }
    L_0x00b8:
        r15 = r11.mPrefetchArray;	 Catch:{ all -> 0x0184 }
        r16 = r13 + 1;
        r2 = r15[r16];	 Catch:{ all -> 0x0184 }
        if (r2 > r12) goto L_0x00c2;
    L_0x00c0:
        r3 = 1;
        goto L_0x00c3;
    L_0x00c2:
        r3 = 0;
    L_0x00c3:
        r14.immediate = r3;	 Catch:{ all -> 0x0184 }
        r14.viewVelocity = r12;	 Catch:{ all -> 0x0184 }
        r14.distanceToItem = r2;	 Catch:{ all -> 0x0184 }
        r14.view = r10;	 Catch:{ all -> 0x0184 }
        r2 = r15[r13];	 Catch:{ all -> 0x0184 }
        r14.position = r2;	 Catch:{ all -> 0x0184 }
        r8 = r8 + 1;
        r13 = r13 + 2;
        r2 = 0;
        goto L_0x0098;
    L_0x00d6:
        r7 = r7 + 1;
        r2 = 0;
        goto L_0x0077;
    L_0x00db:
        r0 = r1.mTasks;	 Catch:{ all -> 0x0184 }
        r2 = sTaskComparator;	 Catch:{ all -> 0x0184 }
        java.util.Collections.sort(r0, r2);	 Catch:{ all -> 0x0184 }
        r0 = 0;
    L_0x00e3:
        r2 = r1.mTasks;	 Catch:{ all -> 0x0184 }
        r2 = r2.size();	 Catch:{ all -> 0x0184 }
        if (r0 >= r2) goto L_0x017e;
    L_0x00eb:
        r2 = r1.mTasks;	 Catch:{ all -> 0x0184 }
        r2 = r2.get(r0);	 Catch:{ all -> 0x0184 }
        r2 = (android.support.p002v7.widget.GapWorker.Task) r2;	 Catch:{ all -> 0x0184 }
        r3 = r2.view;	 Catch:{ all -> 0x0184 }
        if (r3 != 0) goto L_0x00f9;
    L_0x00f7:
        goto L_0x017e;
    L_0x00f9:
        r7 = r2.immediate;	 Catch:{ all -> 0x0184 }
        if (r9 == r7) goto L_0x00ff;
    L_0x00fd:
        r7 = r5;
        goto L_0x0104;
    L_0x00ff:
        r7 = 9223372036854775807; // 0x7fffffffffffffff float:NaN double:NaN;
    L_0x0104:
        r10 = r2.position;	 Catch:{ all -> 0x0184 }
        r3 = android.support.p002v7.widget.GapWorker.prefetchPositionWithDeadline$ar$ds(r3, r10, r7);	 Catch:{ all -> 0x0184 }
        if (r3 == 0) goto L_0x016f;
    L_0x010c:
        r7 = r3.mNestedRecyclerView;	 Catch:{ all -> 0x0184 }
        if (r7 == 0) goto L_0x016f;
    L_0x0110:
        r7 = r3.isBound();	 Catch:{ all -> 0x0184 }
        if (r7 == 0) goto L_0x016f;
    L_0x0116:
        r7 = r3.isInvalid();	 Catch:{ all -> 0x0184 }
        if (r7 != 0) goto L_0x016f;
    L_0x011c:
        r3 = r3.mNestedRecyclerView;	 Catch:{ all -> 0x0184 }
        r3 = r3.get();	 Catch:{ all -> 0x0184 }
        r3 = (android.support.p002v7.widget.RecyclerView) r3;	 Catch:{ all -> 0x0184 }
        if (r3 != 0) goto L_0x0127;
    L_0x0126:
        goto L_0x016f;
    L_0x0127:
        r7 = r3.mDataSetHasChangedAfterLayout;	 Catch:{ all -> 0x0184 }
        if (r7 == 0) goto L_0x0136;
    L_0x012b:
        r7 = r3.mChildHelper;	 Catch:{ all -> 0x0184 }
        r7 = r7.getUnfilteredChildCount();	 Catch:{ all -> 0x0184 }
        if (r7 == 0) goto L_0x0136;
    L_0x0133:
        r3.removeAndRecycleViews();	 Catch:{ all -> 0x0184 }
    L_0x0136:
        r7 = r3.mPrefetchRegistry;	 Catch:{ all -> 0x0184 }
        r7.collectPrefetchPositionsFromView(r3, r9);	 Catch:{ all -> 0x0184 }
        r8 = r7.mCount;	 Catch:{ all -> 0x0184 }
        if (r8 == 0) goto L_0x016f;
    L_0x013f:
        r8 = "RV Nested Prefetch";
        android.os.Trace.beginSection(r8);	 Catch:{ all -> 0x016a }
        r8 = r3.mState;	 Catch:{ all -> 0x016a }
        r10 = r3.mAdapter;	 Catch:{ all -> 0x016a }
        r8.mLayoutStep = r9;	 Catch:{ all -> 0x016a }
        r10 = r10.getItemCount();	 Catch:{ all -> 0x016a }
        r8.mItemCount = r10;	 Catch:{ all -> 0x016a }
        r8.mInPreLayout = r4;	 Catch:{ all -> 0x016a }
        r8.mTrackOldChangeHolders = r4;	 Catch:{ all -> 0x016a }
        r8.mIsMeasuring = r4;	 Catch:{ all -> 0x016a }
        r8 = 0;
    L_0x0157:
        r10 = r7.mCount;	 Catch:{ all -> 0x016a }
        r10 = r10 + r10;
        if (r8 >= r10) goto L_0x0166;
    L_0x015c:
        r10 = r7.mPrefetchArray;	 Catch:{ all -> 0x016a }
        r10 = r10[r8];	 Catch:{ all -> 0x016a }
        android.support.p002v7.widget.GapWorker.prefetchPositionWithDeadline$ar$ds(r3, r10, r5);	 Catch:{ all -> 0x016a }
        r8 = r8 + 2;
        goto L_0x0157;
    L_0x0166:
        android.os.Trace.endSection();	 Catch:{ all -> 0x0184 }
        goto L_0x016f;
    L_0x016a:
        r0 = move-exception;
        android.os.Trace.endSection();	 Catch:{ all -> 0x0184 }
        throw r0;	 Catch:{ all -> 0x0184 }
    L_0x016f:
        r2.immediate = r4;	 Catch:{ all -> 0x0184 }
        r2.viewVelocity = r4;	 Catch:{ all -> 0x0184 }
        r2.distanceToItem = r4;	 Catch:{ all -> 0x0184 }
        r3 = 0;
        r2.view = r3;	 Catch:{ all -> 0x0184 }
        r2.position = r4;	 Catch:{ all -> 0x0184 }
        r0 = r0 + 1;
        goto L_0x00e3;
    L_0x017e:
        r2 = 0;
        r1.mPostTimeNs = r2;
        goto L_0x0013;
    L_0x0184:
        r0 = move-exception;
        r2 = 0;
        r1.mPostTimeNs = r2;
        android.os.Trace.endSection();
        goto L_0x018e;
    L_0x018d:
        throw r0;
    L_0x018e:
        goto L_0x018d;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.GapWorker.run():void");
    }

    private static final ViewHolder prefetchPositionWithDeadline$ar$ds(RecyclerView recyclerView, int i, long j) {
        int unfilteredChildCount = recyclerView.mChildHelper.getUnfilteredChildCount();
        for (int i2 = 0; i2 < unfilteredChildCount; i2++) {
            ViewHolder childViewHolderInt = RecyclerView.getChildViewHolderInt(recyclerView.mChildHelper.getUnfilteredChildAt(i2));
            if (childViewHolderInt.mPosition == i) {
                if (!childViewHolderInt.isInvalid()) {
                    return null;
                }
            }
        }
        Recycler recycler = recyclerView.mRecycler;
        try {
            recyclerView.onEnterLayoutOrScroll();
            ViewHolder tryGetViewHolderForPositionByDeadline$ar$ds = recycler.tryGetViewHolderForPositionByDeadline$ar$ds(i, j);
            if (tryGetViewHolderForPositionByDeadline$ar$ds != null) {
                if (!tryGetViewHolderForPositionByDeadline$ar$ds.isBound() || tryGetViewHolderForPositionByDeadline$ar$ds.isInvalid()) {
                    recycler.addViewHolderToRecycledViewPool(tryGetViewHolderForPositionByDeadline$ar$ds, false);
                } else {
                    recycler.recycleView(tryGetViewHolderForPositionByDeadline$ar$ds.itemView);
                }
            }
            recyclerView.onExitLayoutOrScroll(false);
            return tryGetViewHolderForPositionByDeadline$ar$ds;
        } catch (Throwable th) {
            recyclerView.onExitLayoutOrScroll(false);
        }
    }

    final void postFromTraversal(RecyclerView recyclerView, int i, int i2) {
        if (recyclerView.mIsAttached && this.mPostTimeNs == 0) {
            this.mPostTimeNs = System.nanoTime();
            recyclerView.post(this);
        }
        LayoutPrefetchRegistryImpl layoutPrefetchRegistryImpl = recyclerView.mPrefetchRegistry;
        layoutPrefetchRegistryImpl.mPrefetchDx = i;
        layoutPrefetchRegistryImpl.mPrefetchDy = i2;
    }
}
