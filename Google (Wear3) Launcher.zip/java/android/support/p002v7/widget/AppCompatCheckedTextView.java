package android.support.p002v7.widget;

import android.content.Context;
import android.support.p002v7.content.res.AppCompatResources;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatCheckedTextView */
public final class AppCompatCheckedTextView extends CheckedTextView {
    private static final int[] TINT_ATTRS = new int[]{16843016};
    private final AppCompatTextHelper mTextHelper;

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        AppCompatTextHelper appCompatTextHelper = this.mTextHelper;
        if (appCompatTextHelper != null) {
            appCompatTextHelper.applyCompoundDrawablesTints();
        }
    }

    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        AppCompatHintHelper.onCreateInputConnection$ar$ds(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public final void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(AppCompatResources.getDrawable(getContext(), i));
    }

    public final void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        AppCompatTextHelper appCompatTextHelper = this.mTextHelper;
        if (appCompatTextHelper != null) {
            appCompatTextHelper.onSetTextAppearance(context, i);
        }
    }

    public AppCompatCheckedTextView(Context context, AttributeSet attributeSet) {
        TintContextWrapper.wrap$ar$ds$c2d4b793_0(context);
        super(context, attributeSet, 16843720);
        ThemeUtils.checkAppCompatTheme(this, getContext());
        AppCompatTextHelper appCompatTextHelper = new AppCompatTextHelper(this);
        this.mTextHelper = appCompatTextHelper;
        appCompatTextHelper.loadFromAttributes(attributeSet, 16843720);
        appCompatTextHelper.applyCompoundDrawablesTints();
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(getContext(), attributeSet, TINT_ATTRS, 16843720);
        setCheckMarkDrawable(obtainStyledAttributes$ar$ds.getDrawable(0));
        obtainStyledAttributes$ar$ds.recycle();
    }
}
