package android.support.p002v7.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.Resources.Theme;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.TintContextWrapper */
public final class TintContextWrapper extends ContextWrapper {
    public static void wrap$ar$ds$c2d4b793_0(Context context) {
        if (!(context instanceof TintContextWrapper) && !(context.getResources() instanceof TintResources)) {
            context.getResources();
        }
    }

    public final AssetManager getAssets() {
        throw null;
    }

    public final Resources getResources() {
        throw null;
    }

    public final Theme getTheme() {
        throw null;
    }

    public final void setTheme(int i) {
        throw null;
    }
}
