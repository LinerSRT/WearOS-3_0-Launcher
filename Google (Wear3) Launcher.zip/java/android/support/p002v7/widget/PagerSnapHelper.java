package android.support.p002v7.widget;

import android.graphics.PointF;
import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.SmoothScroller;
import android.support.p002v7.widget.RecyclerView.SmoothScroller.Action;
import android.support.p002v7.widget.RecyclerView.SmoothScroller.ScrollVectorProvider;
import android.support.p002v7.widget.RecyclerView.State;
import android.util.DisplayMetrics;
import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.PagerSnapHelper */
public class PagerSnapHelper extends SnapHelper {
    private OrientationHelper mHorizontalHelper;
    private OrientationHelper mVerticalHelper;

    private static final int distanceToCenter$ar$ds$f45aec62_0(View view, OrientationHelper orientationHelper) {
        return (orientationHelper.getDecoratedStart(view) + (orientationHelper.getDecoratedMeasurement(view) / 2)) - (orientationHelper.getStartAfterPadding() + (orientationHelper.getTotalSpace() / 2));
    }

    private static final View findCenterView$ar$ds$f805195d_0(LayoutManager layoutManager, OrientationHelper orientationHelper) {
        int childCount = layoutManager.getChildCount();
        View view = null;
        if (childCount == 0) {
            return null;
        }
        int startAfterPadding = orientationHelper.getStartAfterPadding() + (orientationHelper.getTotalSpace() / 2);
        int i = Integer.MAX_VALUE;
        int i2 = 0;
        while (i2 < childCount) {
            View childAt = layoutManager.getChildAt(i2);
            int abs = Math.abs((orientationHelper.getDecoratedStart(childAt) + (orientationHelper.getDecoratedMeasurement(childAt) / 2)) - startAfterPadding);
            int i3 = abs < i ? abs : i;
            if (abs < i) {
                view = childAt;
            }
            i2++;
            i = i3;
        }
        return view;
    }

    private final OrientationHelper getHorizontalHelper(LayoutManager layoutManager) {
        OrientationHelper orientationHelper = this.mHorizontalHelper;
        if (orientationHelper == null || orientationHelper.mLayoutManager != layoutManager) {
            this.mHorizontalHelper = OrientationHelper.createHorizontalHelper(layoutManager);
        }
        return this.mHorizontalHelper;
    }

    private final OrientationHelper getVerticalHelper(LayoutManager layoutManager) {
        OrientationHelper orientationHelper = this.mVerticalHelper;
        if (orientationHelper == null || orientationHelper.mLayoutManager != layoutManager) {
            this.mVerticalHelper = OrientationHelper.createVerticalHelper(layoutManager);
        }
        return this.mVerticalHelper;
    }

    public final int[] calculateDistanceToFinalSnap(LayoutManager layoutManager, View view) {
        int[] iArr = new int[2];
        if (layoutManager.canScrollHorizontally()) {
            iArr[0] = PagerSnapHelper.distanceToCenter$ar$ds$f45aec62_0(view, getHorizontalHelper(layoutManager));
        } else {
            iArr[0] = 0;
        }
        if (layoutManager.canScrollVertically()) {
            iArr[1] = PagerSnapHelper.distanceToCenter$ar$ds$f45aec62_0(view, getVerticalHelper(layoutManager));
        } else {
            iArr[1] = 0;
        }
        return iArr;
    }

    protected final SmoothScroller createScroller(LayoutManager layoutManager) {
        if (layoutManager instanceof ScrollVectorProvider) {
            return new LinearSmoothScroller(this.mRecyclerView.getContext()) {
                protected final float calculateSpeedPerPixel(DisplayMetrics displayMetrics) {
                    return 100.0f / ((float) displayMetrics.densityDpi);
                }

                protected final int calculateTimeForScrolling(int i) {
                    return Math.min(100, super.calculateTimeForScrolling(i));
                }

                protected final void onTargetFound(View view, State state, Action action) {
                    PagerSnapHelper pagerSnapHelper = PagerSnapHelper.this;
                    int[] calculateDistanceToFinalSnap = pagerSnapHelper.calculateDistanceToFinalSnap(pagerSnapHelper.mRecyclerView.mLayout, view);
                    int i = calculateDistanceToFinalSnap[0];
                    int i2 = calculateDistanceToFinalSnap[1];
                    int calculateTimeForDeceleration = calculateTimeForDeceleration(Math.max(Math.abs(i), Math.abs(i2)));
                    if (calculateTimeForDeceleration > 0) {
                        action.update(i, i2, calculateTimeForDeceleration, this.mDecelerateInterpolator);
                    }
                }
            };
        }
        return null;
    }

    public View findSnapView(LayoutManager layoutManager) {
        return layoutManager.canScrollVertically() ? PagerSnapHelper.findCenterView$ar$ds$f805195d_0(layoutManager, getVerticalHelper(layoutManager)) : layoutManager.canScrollHorizontally() ? PagerSnapHelper.findCenterView$ar$ds$f805195d_0(layoutManager, getHorizontalHelper(layoutManager)) : null;
    }

    public final int findTargetSnapPosition(LayoutManager layoutManager, int i, int i2) {
        int itemCount = layoutManager.getItemCount();
        if (itemCount == 0) {
            return -1;
        }
        View view = null;
        OrientationHelper verticalHelper = layoutManager.canScrollVertically() ? getVerticalHelper(layoutManager) : layoutManager.canScrollHorizontally() ? getHorizontalHelper(layoutManager) : null;
        if (verticalHelper == null) {
            return -1;
        }
        Object obj;
        int itemCount2;
        PointF computeScrollVectorForPosition;
        int childCount = layoutManager.getChildCount();
        Object obj2 = null;
        View view2 = null;
        int i3 = LinearLayoutManager.INVALID_OFFSET;
        int i4 = Integer.MAX_VALUE;
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = layoutManager.getChildAt(i5);
            if (childAt != null) {
                int distanceToCenter$ar$ds$f45aec62_0 = PagerSnapHelper.distanceToCenter$ar$ds$f45aec62_0(childAt, verticalHelper);
                if (distanceToCenter$ar$ds$f45aec62_0 <= 0 && distanceToCenter$ar$ds$f45aec62_0 > i3) {
                    view2 = childAt;
                    i3 = distanceToCenter$ar$ds$f45aec62_0;
                }
                if (distanceToCenter$ar$ds$f45aec62_0 >= 0) {
                    if (distanceToCenter$ar$ds$f45aec62_0 < i4) {
                        view = childAt;
                        i4 = distanceToCenter$ar$ds$f45aec62_0;
                    }
                }
            }
        }
        childCount = 1;
        if (layoutManager.canScrollHorizontally()) {
            if (i > 0) {
                obj = 1;
                if (obj != null) {
                    if (view == null) {
                        return layoutManager.getPosition(view);
                    }
                }
                if (obj == null) {
                    if (view2 == null) {
                        return layoutManager.getPosition(view2);
                    }
                }
                if (1 != obj) {
                    view = view2;
                }
                if (view != null) {
                    return -1;
                }
                i2 = layoutManager.getPosition(view);
                itemCount2 = layoutManager.getItemCount();
                if (layoutManager instanceof ScrollVectorProvider) {
                    computeScrollVectorForPosition = ((ScrollVectorProvider) layoutManager).computeScrollVectorForPosition(itemCount2 - 1);
                    if (computeScrollVectorForPosition != null && (computeScrollVectorForPosition.x < 0.0f || computeScrollVectorForPosition.y < 0.0f)) {
                        obj2 = 1;
                        if (obj2 == obj) {
                            childCount = -1;
                        }
                        i2 += childCount;
                        if (i2 >= 0) {
                            if (i2 >= itemCount) {
                                return i2;
                            }
                        }
                        return -1;
                    }
                }
                if (obj2 == obj) {
                    childCount = -1;
                }
                i2 += childCount;
                if (i2 >= 0) {
                    if (i2 >= itemCount) {
                        return i2;
                    }
                }
                return -1;
            }
        } else if (i2 > 0) {
            obj = 1;
            if (obj != null) {
                if (view == null) {
                    return layoutManager.getPosition(view);
                }
            }
            if (obj == null) {
                if (view2 == null) {
                    return layoutManager.getPosition(view2);
                }
            }
            if (1 != obj) {
                view = view2;
            }
            if (view != null) {
                return -1;
            }
            i2 = layoutManager.getPosition(view);
            itemCount2 = layoutManager.getItemCount();
            if (layoutManager instanceof ScrollVectorProvider) {
                computeScrollVectorForPosition = ((ScrollVectorProvider) layoutManager).computeScrollVectorForPosition(itemCount2 - 1);
                obj2 = 1;
                if (obj2 == obj) {
                    childCount = -1;
                }
                i2 += childCount;
                if (i2 >= 0) {
                    if (i2 >= itemCount) {
                        return i2;
                    }
                }
                return -1;
            }
            if (obj2 == obj) {
                childCount = -1;
            }
            i2 += childCount;
            if (i2 >= 0) {
                if (i2 >= itemCount) {
                    return i2;
                }
            }
            return -1;
        }
        obj = null;
        if (obj != null) {
            if (view == null) {
                return layoutManager.getPosition(view);
            }
        }
        if (obj == null) {
            if (view2 == null) {
                return layoutManager.getPosition(view2);
            }
        }
        if (1 != obj) {
            view = view2;
        }
        if (view != null) {
            return -1;
        }
        i2 = layoutManager.getPosition(view);
        itemCount2 = layoutManager.getItemCount();
        if (layoutManager instanceof ScrollVectorProvider) {
            computeScrollVectorForPosition = ((ScrollVectorProvider) layoutManager).computeScrollVectorForPosition(itemCount2 - 1);
            obj2 = 1;
            if (obj2 == obj) {
                childCount = -1;
            }
            i2 += childCount;
            if (i2 >= 0) {
                if (i2 >= itemCount) {
                    return i2;
                }
            }
            return -1;
        }
        if (obj2 == obj) {
            childCount = -1;
        }
        i2 += childCount;
        if (i2 >= 0) {
            if (i2 >= itemCount) {
                return i2;
            }
        }
        return -1;
    }
}
