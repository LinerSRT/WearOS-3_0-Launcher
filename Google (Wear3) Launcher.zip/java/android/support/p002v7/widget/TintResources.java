package android.support.p002v7.widget;

import android.graphics.drawable.Drawable;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.TintResources */
final class TintResources extends ResourcesWrapper {
    public final Drawable getDrawable(int i) {
        throw null;
    }
}
