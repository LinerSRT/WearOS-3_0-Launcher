package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.widget.LinearLayoutCompat.LayoutParams;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AlertDialogLayout */
public class AlertDialogLayout extends LinearLayoutCompat {
    public AlertDialogLayout(Context context) {
        super(context);
    }

    private static int resolveMinimumHeight(View view) {
        int minimumHeight = ViewCompat.getMinimumHeight(view);
        if (minimumHeight > 0) {
            return minimumHeight;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            if (viewGroup.getChildCount() == 1) {
                return AlertDialogLayout.resolveMinimumHeight(viewGroup.getChildAt(0));
            }
        }
        return 0;
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int paddingLeft = getPaddingLeft();
        i3 -= i;
        i = i3 - getPaddingRight();
        i3 = (i3 - paddingLeft) - getPaddingRight();
        int measuredHeight = getMeasuredHeight();
        int childCount = getChildCount();
        int i5 = this.mGravity;
        int i6 = 8388615 & i5;
        switch (i5 & 112) {
            case 16:
                i5 = getPaddingTop() + (((i4 - i2) - measuredHeight) / 2);
                break;
            case 80:
                i5 = ((getPaddingTop() + i4) - i2) - measuredHeight;
                break;
            default:
                i5 = getPaddingTop();
                break;
        }
        Drawable drawable = this.mDivider;
        if (drawable == null) {
            i2 = 0;
        } else {
            i2 = drawable.getIntrinsicHeight();
        }
        for (i4 = 0; i4 < childCount; i4++) {
            View childAt = getChildAt(i4);
            if (!(childAt == null || childAt.getVisibility() == 8)) {
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight2 = childAt.getMeasuredHeight();
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int i7 = layoutParams.gravity;
                if (i7 < 0) {
                    i7 = i6;
                }
                switch (Gravity.getAbsoluteGravity(i7, ViewCompat.getLayoutDirection(this)) & 7) {
                    case 1:
                        i7 = ((((i3 - measuredWidth) / 2) + paddingLeft) + layoutParams.leftMargin) - layoutParams.rightMargin;
                        break;
                    case 5:
                        i7 = (i - measuredWidth) - layoutParams.rightMargin;
                        break;
                    default:
                        i7 = layoutParams.leftMargin + paddingLeft;
                        break;
                }
                if (hasDividerBeforeChildAt(i4)) {
                    i5 += i2;
                }
                i5 += layoutParams.topMargin;
                childAt.layout(i7, i5, measuredWidth + i7, i5 + measuredHeight2);
                i5 += measuredHeight2 + layoutParams.bottomMargin;
            }
        }
    }

    public AlertDialogLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    protected final void onMeasure(int i, int i2) {
        int i3;
        int combineMeasuredStates;
        int resolveMinimumHeight;
        int measuredHeight;
        int i4;
        ViewGroup viewGroup = this;
        int i5 = i;
        int childCount = getChildCount();
        View view = null;
        View view2 = null;
        View view3 = view2;
        for (i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8) {
                int id = childAt.getId();
                if (id == R.id.topPanel) {
                    view = childAt;
                } else if (id == R.id.buttonPanel) {
                    view2 = childAt;
                } else if ((id == R.id.contentPanel || id == R.id.customPanel) && view3 == null) {
                    view3 = childAt;
                } else {
                    super.onMeasure(i, i2);
                    return;
                }
            }
        }
        i3 = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i2);
        int mode = MeasureSpec.getMode(i);
        int paddingTop = getPaddingTop() + getPaddingBottom();
        if (view != null) {
            view.measure(i5, 0);
            paddingTop += view.getMeasuredHeight();
            combineMeasuredStates = View.combineMeasuredStates(0, view.getMeasuredState());
        } else {
            combineMeasuredStates = 0;
        }
        if (view2 != null) {
            view2.measure(i5, 0);
            resolveMinimumHeight = AlertDialogLayout.resolveMinimumHeight(view2);
            measuredHeight = view2.getMeasuredHeight() - resolveMinimumHeight;
            paddingTop += resolveMinimumHeight;
            combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, view2.getMeasuredState());
        } else {
            resolveMinimumHeight = 0;
            measuredHeight = 0;
        }
        if (view3 != null) {
            if (i3 == 0) {
                i4 = 0;
            } else {
                i4 = MeasureSpec.makeMeasureSpec(Math.max(0, size - paddingTop), i3);
            }
            view3.measure(i5, i4);
            i4 = view3.getMeasuredHeight();
            paddingTop += i4;
            combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, view3.getMeasuredState());
        } else {
            i4 = 0;
        }
        size -= paddingTop;
        if (view2 != null) {
            paddingTop -= resolveMinimumHeight;
            measuredHeight = Math.min(size, measuredHeight);
            if (measuredHeight > 0) {
                size -= measuredHeight;
                resolveMinimumHeight += measuredHeight;
            }
            view2.measure(i5, MeasureSpec.makeMeasureSpec(resolveMinimumHeight, 1073741824));
            paddingTop += view2.getMeasuredHeight();
            combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, view2.getMeasuredState());
        }
        if (view3 != null && size > 0) {
            view3.measure(i5, MeasureSpec.makeMeasureSpec(size + i4, i3));
            paddingTop = (paddingTop - i4) + view3.getMeasuredHeight();
            combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, view3.getMeasuredState());
        }
        int i6 = 0;
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt2 = getChildAt(i7);
            if (childAt2.getVisibility() != 8) {
                i6 = Math.max(i6, childAt2.getMeasuredWidth());
            }
        }
        setMeasuredDimension(View.resolveSizeAndState(i6 + (getPaddingLeft() + getPaddingRight()), i5, combineMeasuredStates), View.resolveSizeAndState(paddingTop, i2, 0));
        if (mode != 1073741824) {
            mode = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
            for (paddingTop = 0; paddingTop < childCount; paddingTop++) {
                view = getChildAt(paddingTop);
                if (view.getVisibility() != 8) {
                    LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
                    if (layoutParams.width == -1) {
                        measuredHeight = layoutParams.height;
                        layoutParams.height = view.getMeasuredHeight();
                        measureChildWithMargins(view, mode, 0, i2, 0);
                        layoutParams.height = measuredHeight;
                    }
                }
            }
        }
    }
}
