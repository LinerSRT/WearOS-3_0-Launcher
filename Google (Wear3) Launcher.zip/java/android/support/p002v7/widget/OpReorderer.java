package android.support.p002v7.widget;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.OpReorderer */
final class OpReorderer {
    final AdapterHelper mCallback$ar$class_merging$f11fd352_0;

    public OpReorderer(AdapterHelper adapterHelper) {
        this.mCallback$ar$class_merging$f11fd352_0 = adapterHelper;
    }
}
