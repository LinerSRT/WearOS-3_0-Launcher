package android.support.p002v7.widget;

import android.content.Context;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.view.ActionMode;
import android.support.p002v7.view.menu.BaseMenuPresenter;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.p002v7.view.menu.MenuView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ActionBarContextView */
public class ActionBarContextView extends AbsActionBarView {
    public View mClose;
    private View mCloseButton;
    private int mCloseItemLayout;
    private View mCustomView;
    public CharSequence mSubtitle;
    private int mSubtitleStyleRes;
    private TextView mSubtitleView;
    public CharSequence mTitle;
    private LinearLayout mTitleLayout;
    public boolean mTitleOptional;
    private int mTitleStyleRes;
    private TextView mTitleView;

    /* renamed from: android.support.v7.widget.ActionBarContextView$1 */
    final class PG implements OnClickListener {
        final /* synthetic */ ActionMode val$mode;

        public PG(ActionMode actionMode) {
            this.val$mode = actionMode;
        }

        public final void onClick(View view) {
            this.val$mode.finish();
        }
    }

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    private final void initTitle() {
        if (this.mTitleLayout == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.mTitleLayout = linearLayout;
            this.mTitleView = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.mSubtitleView = (TextView) this.mTitleLayout.findViewById(R.id.action_bar_subtitle);
            if (this.mTitleStyleRes != 0) {
                this.mTitleView.setTextAppearance(getContext(), this.mTitleStyleRes);
            }
            if (this.mSubtitleStyleRes != 0) {
                this.mSubtitleView.setTextAppearance(getContext(), this.mSubtitleStyleRes);
            }
        }
        this.mTitleView.setText(this.mTitle);
        this.mSubtitleView.setText(this.mSubtitle);
        int isEmpty = TextUtils.isEmpty(this.mTitle) ^ 1;
        boolean isEmpty2 = TextUtils.isEmpty(this.mSubtitle);
        int i = isEmpty2 ^ 1;
        int i2 = 8;
        this.mSubtitleView.setVisibility(true != isEmpty2 ? 0 : 8);
        LinearLayout linearLayout2 = this.mTitleLayout;
        if (isEmpty != 0) {
            i2 = 0;
        } else if (i != 0) {
            i2 = 0;
        }
        linearLayout2.setVisibility(i2);
        if (this.mTitleLayout.getParent() == null) {
            addView(this.mTitleLayout);
        }
    }

    protected final LayoutParams generateDefaultLayoutParams() {
        return new MarginLayoutParams(-1, -2);
    }

    public final LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new MarginLayoutParams(getContext(), attributeSet);
    }

    public final void initForMode(ActionMode actionMode) {
        View view = this.mClose;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(this.mCloseItemLayout, this, false);
            this.mClose = view;
            addView(view);
        } else if (view.getParent() == null) {
            addView(this.mClose);
        }
        view = this.mClose.findViewById(R.id.action_mode_close_button);
        this.mCloseButton = view;
        view.setOnClickListener(new PG(actionMode));
        Menu menu = actionMode.getMenu();
        ActionMenuPresenter actionMenuPresenter = this.mActionMenuPresenter;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.dismissPopupMenus$ar$ds();
        }
        this.mActionMenuPresenter = new ActionMenuPresenter(getContext());
        this.mActionMenuPresenter.setReserveOverflow$ar$ds();
        LayoutParams layoutParams = new LayoutParams(-2, -1);
        ((MenuBuilder) menu).addMenuPresenter(this.mActionMenuPresenter, this.mPopupContext);
        BaseMenuPresenter baseMenuPresenter = this.mActionMenuPresenter;
        MenuView menuView = baseMenuPresenter.mMenuView;
        if (baseMenuPresenter.mMenuView == null) {
            baseMenuPresenter.mMenuView = (MenuView) baseMenuPresenter.mSystemInflater.inflate(R.layout.abc_action_menu_layout, this, false);
            baseMenuPresenter.mMenuView.initialize(baseMenuPresenter.mMenu);
            baseMenuPresenter.updateMenuView$ar$ds();
        }
        MenuView menuView2 = baseMenuPresenter.mMenuView;
        if (menuView != menuView2) {
            ((ActionMenuView) menuView2).setPresenter(baseMenuPresenter);
        }
        this.mMenuView = (ActionMenuView) menuView2;
        ViewCompat.setBackground(this.mMenuView, null);
        addView(this.mMenuView, layoutParams);
    }

    public final void killMode() {
        removeAllViews();
        this.mCustomView = null;
        this.mMenuView = null;
        this.mActionMenuPresenter = null;
        View view = this.mCloseButton;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ActionMenuPresenter actionMenuPresenter = this.mActionMenuPresenter;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.hideOverflowMenu();
            this.mActionMenuPresenter.hideSubMenus$ar$ds();
        }
    }

    public final /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource(this);
            accessibilityEvent.setClassName(getClass().getName());
            accessibilityEvent.setPackageName(getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.mTitle);
            return;
        }
        super.onInitializeAccessibilityEvent(accessibilityEvent);
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        z = ViewUtils.isLayoutRtl(this);
        int paddingRight = z ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        i4 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.mClose;
        if (!(view == null || view.getVisibility() == 8)) {
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.mClose.getLayoutParams();
            int i5 = z ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            i2 = z ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            paddingRight = AbsActionBarView.next(paddingRight, i5, z);
            paddingRight = AbsActionBarView.next(paddingRight + AbsActionBarView.positionChild$ar$ds(this.mClose, paddingRight, paddingTop, i4, z), i2, z);
        }
        LinearLayout linearLayout = this.mTitleLayout;
        if (!(linearLayout == null || this.mCustomView != null || linearLayout.getVisibility() == 8)) {
            paddingRight += AbsActionBarView.positionChild$ar$ds(this.mTitleLayout, paddingRight, paddingTop, i4, z);
        }
        view = this.mCustomView;
        if (view != null) {
            AbsActionBarView.positionChild$ar$ds(view, paddingRight, paddingTop, i4, z);
        }
        i = z ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        view = this.mMenuView;
        if (view != null) {
            AbsActionBarView.positionChild$ar$ds(view, i, paddingTop, i4, z ^ 1);
        }
    }

    protected final void onMeasure(int i, int i2) {
        int i3 = 1073741824;
        StringBuilder stringBuilder;
        if (MeasureSpec.getMode(i) != 1073741824) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(getClass().getSimpleName());
            stringBuilder.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
            throw new IllegalStateException(stringBuilder.toString());
        } else if (MeasureSpec.getMode(i2) != 0) {
            int i4;
            i = MeasureSpec.getSize(i);
            int i5 = this.mContentHeight;
            if (i5 <= 0) {
                i5 = MeasureSpec.getSize(i2);
            }
            i2 = getPaddingTop() + getPaddingBottom();
            int paddingLeft = (i - getPaddingLeft()) - getPaddingRight();
            int i6 = i5 - i2;
            int makeMeasureSpec = MeasureSpec.makeMeasureSpec(i6, LinearLayoutManager.INVALID_OFFSET);
            View view = this.mClose;
            if (view != null) {
                paddingLeft = AbsActionBarView.measureChildView$ar$ds(view, paddingLeft, makeMeasureSpec);
                MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.mClose.getLayoutParams();
                paddingLeft -= marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
            }
            ViewGroup viewGroup = this.mMenuView;
            if (viewGroup != null && viewGroup.getParent() == this) {
                paddingLeft = AbsActionBarView.measureChildView$ar$ds(this.mMenuView, paddingLeft, makeMeasureSpec);
            }
            view = this.mTitleLayout;
            int i7 = 0;
            if (view != null && this.mCustomView == null) {
                if (this.mTitleOptional) {
                    this.mTitleLayout.measure(MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    makeMeasureSpec = this.mTitleLayout.getMeasuredWidth();
                    if (makeMeasureSpec <= paddingLeft) {
                        i4 = paddingLeft - makeMeasureSpec;
                    } else {
                        i4 = paddingLeft;
                    }
                    LinearLayout linearLayout = this.mTitleLayout;
                    if (makeMeasureSpec > paddingLeft) {
                        paddingLeft = 8;
                    } else {
                        paddingLeft = 0;
                    }
                    linearLayout.setVisibility(paddingLeft);
                    paddingLeft = i4;
                } else {
                    paddingLeft = AbsActionBarView.measureChildView$ar$ds(view, paddingLeft, makeMeasureSpec);
                }
            }
            View view2 = this.mCustomView;
            if (view2 != null) {
                LayoutParams layoutParams = view2.getLayoutParams();
                if (layoutParams.width != -2) {
                    i4 = 1073741824;
                } else {
                    i4 = LinearLayoutManager.INVALID_OFFSET;
                }
                if (layoutParams.width >= 0) {
                    paddingLeft = Math.min(layoutParams.width, paddingLeft);
                }
                if (layoutParams.height == -2) {
                    i3 = LinearLayoutManager.INVALID_OFFSET;
                }
                if (layoutParams.height >= 0) {
                    i6 = Math.min(layoutParams.height, i6);
                }
                this.mCustomView.measure(MeasureSpec.makeMeasureSpec(paddingLeft, i4), MeasureSpec.makeMeasureSpec(i6, i3));
            }
            if (this.mContentHeight <= 0) {
                i5 = getChildCount();
                i3 = 0;
                while (i7 < i5) {
                    paddingLeft = getChildAt(i7).getMeasuredHeight() + i2;
                    if (paddingLeft > i3) {
                        i3 = paddingLeft;
                    }
                    i7++;
                }
                setMeasuredDimension(i, i3);
                return;
            }
            setMeasuredDimension(i, i5);
        } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append(getClass().getSimpleName());
            stringBuilder.append(" can only be used with android:layout_height=\"wrap_content\"");
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    public final /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public final void setContentHeight(int i) {
        this.mContentHeight = i;
    }

    public final void setCustomView(View view) {
        View view2 = this.mCustomView;
        if (view2 != null) {
            removeView(view2);
        }
        this.mCustomView = view;
        if (view != null) {
            view2 = this.mTitleLayout;
            if (view2 != null) {
                removeView(view2);
                this.mTitleLayout = null;
            }
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public final void setSubtitle(CharSequence charSequence) {
        this.mSubtitle = charSequence;
        initTitle();
    }

    public final void setTitle(CharSequence charSequence) {
        this.mTitle = charSequence;
        initTitle();
    }

    public final void setTitleOptional(boolean z) {
        if (z != this.mTitleOptional) {
            requestLayout();
        }
        this.mTitleOptional = z;
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public final void showOverflowMenu$ar$ds() {
        ActionMenuPresenter actionMenuPresenter = this.mActionMenuPresenter;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.showOverflowMenu();
        }
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.actionModeStyle);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(context, attributeSet, R$styleable.ActionMode, i);
        ViewCompat.setBackground(this, obtainStyledAttributes$ar$ds.getDrawable(0));
        this.mTitleStyleRes = obtainStyledAttributes$ar$ds.getResourceId(5, 0);
        this.mSubtitleStyleRes = obtainStyledAttributes$ar$ds.getResourceId(4, 0);
        this.mContentHeight = obtainStyledAttributes$ar$ds.getLayoutDimension(3, 0);
        this.mCloseItemLayout = obtainStyledAttributes$ar$ds.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        obtainStyledAttributes$ar$ds.recycle();
    }
}
