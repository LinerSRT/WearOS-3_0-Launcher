package android.support.p002v7.widget;

import android.content.Context;
import android.os.SystemClock;
import android.support.p002v7.view.menu.CascadingMenuPopup.CascadingMenuInfo;
import android.support.p002v7.view.menu.CascadingMenuPopup.PG.PG;
import android.support.p002v7.view.menu.ListMenuItemView;
import android.support.p002v7.view.menu.MenuAdapter;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.CascadingMenuPopup.C00873;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.MenuPopupWindow */
public final class MenuPopupWindow extends ListPopupWindow implements MenuItemHoverListener {
    public MenuItemHoverListener mHoverListener;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.MenuPopupWindow$MenuDropDownListView */
    public final class MenuDropDownListView extends DropDownListView {
        final int mAdvanceKey;
        public MenuItemHoverListener mHoverListener;
        private MenuItem mHoveredMenuItem;
        final int mRetreatKey;

        public MenuDropDownListView(Context context, boolean z) {
            super(context, z);
            if (context.getResources().getConfiguration().getLayoutDirection() == 1) {
                this.mAdvanceKey = 21;
                this.mRetreatKey = 22;
                return;
            }
            this.mAdvanceKey = 22;
            this.mRetreatKey = 21;
        }

        public final boolean onHoverEvent(MotionEvent motionEvent) {
            if (this.mHoverListener != null) {
                int headersCount;
                MenuAdapter menuAdapter;
                MenuItem item;
                MenuItem menuItem;
                MenuBuilder menuBuilder;
                MenuItemHoverListener menuItemHoverListener;
                C00873 c00873;
                int size;
                ListAdapter adapter = getAdapter();
                int i = 0;
                if (adapter instanceof HeaderViewListAdapter) {
                    HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                    headersCount = headerViewListAdapter.getHeadersCount();
                    menuAdapter = (MenuAdapter) headerViewListAdapter.getWrappedAdapter();
                } else {
                    menuAdapter = (MenuAdapter) adapter;
                    headersCount = 0;
                }
                CascadingMenuInfo cascadingMenuInfo = null;
                if (motionEvent.getAction() != 10) {
                    int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
                    if (pointToPosition != -1) {
                        pointToPosition -= headersCount;
                        if (pointToPosition >= 0 && pointToPosition < menuAdapter.getCount()) {
                            item = menuAdapter.getItem(pointToPosition);
                            menuItem = this.mHoveredMenuItem;
                            if (menuItem != item) {
                                menuBuilder = menuAdapter.mAdapterMenu;
                                if (menuItem != null) {
                                    menuItemHoverListener = ((MenuPopupWindow) this.mHoverListener).mHoverListener;
                                    if (menuItemHoverListener != null) {
                                        ((C00873) menuItemHoverListener).this$0.mSubMenuHoverHandler.removeCallbacksAndMessages(menuBuilder);
                                    }
                                }
                                this.mHoveredMenuItem = item;
                                if (item != null) {
                                    menuItemHoverListener = ((MenuPopupWindow) this.mHoverListener).mHoverListener;
                                    if (menuItemHoverListener != null) {
                                        c00873 = (C00873) menuItemHoverListener;
                                        c00873.this$0.mSubMenuHoverHandler.removeCallbacksAndMessages(null);
                                        size = c00873.this$0.mShowingMenus.size();
                                        while (i < size) {
                                            if (menuBuilder != ((CascadingMenuInfo) c00873.this$0.mShowingMenus.get(i)).menu) {
                                                break;
                                            }
                                            i++;
                                        }
                                        i = -1;
                                        if (i == -1) {
                                            i++;
                                            if (i < c00873.this$0.mShowingMenus.size()) {
                                                cascadingMenuInfo = (CascadingMenuInfo) c00873.this$0.mShowingMenus.get(i);
                                            }
                                            c00873.this$0.mSubMenuHoverHandler.postAtTime(new PG(cascadingMenuInfo, item, menuBuilder), menuBuilder, SystemClock.uptimeMillis() + 200);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                item = null;
                menuItem = this.mHoveredMenuItem;
                if (menuItem != item) {
                    menuBuilder = menuAdapter.mAdapterMenu;
                    if (menuItem != null) {
                        menuItemHoverListener = ((MenuPopupWindow) this.mHoverListener).mHoverListener;
                        if (menuItemHoverListener != null) {
                            ((C00873) menuItemHoverListener).this$0.mSubMenuHoverHandler.removeCallbacksAndMessages(menuBuilder);
                        }
                    }
                    this.mHoveredMenuItem = item;
                    if (item != null) {
                        menuItemHoverListener = ((MenuPopupWindow) this.mHoverListener).mHoverListener;
                        if (menuItemHoverListener != null) {
                            c00873 = (C00873) menuItemHoverListener;
                            c00873.this$0.mSubMenuHoverHandler.removeCallbacksAndMessages(null);
                            size = c00873.this$0.mShowingMenus.size();
                            while (i < size) {
                                if (menuBuilder != ((CascadingMenuInfo) c00873.this$0.mShowingMenus.get(i)).menu) {
                                    break;
                                }
                                i++;
                            }
                            i = -1;
                            if (i == -1) {
                                i++;
                                if (i < c00873.this$0.mShowingMenus.size()) {
                                    cascadingMenuInfo = (CascadingMenuInfo) c00873.this$0.mShowingMenus.get(i);
                                }
                                c00873.this$0.mSubMenuHoverHandler.postAtTime(new PG(cascadingMenuInfo, item, menuBuilder), menuBuilder, SystemClock.uptimeMillis() + 200);
                            }
                        }
                    }
                }
            }
            return super.onHoverEvent(motionEvent);
        }

        public final boolean onKeyDown(int i, KeyEvent keyEvent) {
            ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
            if (listMenuItemView != null && i == this.mAdvanceKey) {
                if (listMenuItemView.isEnabled() && listMenuItemView.mItemData.hasSubMenu()) {
                    performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
                }
                return true;
            } else if (listMenuItemView == null || i != this.mRetreatKey) {
                return super.onKeyDown(i, keyEvent);
            } else {
                MenuAdapter menuAdapter;
                setSelection(-1);
                ListAdapter adapter = getAdapter();
                if (adapter instanceof HeaderViewListAdapter) {
                    menuAdapter = (MenuAdapter) ((HeaderViewListAdapter) adapter).getWrappedAdapter();
                } else {
                    menuAdapter = (MenuAdapter) adapter;
                }
                menuAdapter.mAdapterMenu.close(false);
                return true;
            }
        }
    }

    public MenuPopupWindow(Context context, int i) {
        super(context, null, i);
    }

    public final DropDownListView createDropDownListView(Context context, boolean z) {
        DropDownListView menuDropDownListView = new MenuDropDownListView(context, z);
        menuDropDownListView.mHoverListener = this;
        return menuDropDownListView;
    }
}
