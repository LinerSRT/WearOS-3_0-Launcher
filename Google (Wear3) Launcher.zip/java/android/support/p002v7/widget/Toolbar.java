package android.support.p002v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.app.ActionBar;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.view.SupportMenuInflater;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.p002v7.view.menu.MenuItemImpl;
import android.support.p002v7.view.menu.MenuItemWrapperICS.CollapsibleActionViewWrapper;
import android.support.p002v7.view.menu.MenuPresenter;
import android.support.p002v7.view.menu.MenuPresenter.Callback;
import android.support.p002v7.view.menu.SubMenuBuilder;
import android.support.v7.widget.Toolbar.C01122;
import android.support.v7.widget.Toolbar.C01133;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.customview.view.AbsSavedState;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.Toolbar */
public class Toolbar extends ViewGroup {
    int mButtonGravity;
    ImageButton mCollapseButtonView;
    public CharSequence mCollapseDescription;
    public Drawable mCollapseIcon;
    private int mContentInsetEndWithActions;
    private int mContentInsetStartWithNavigation;
    public RtlSpacingHelper mContentInsets;
    private boolean mEatingHover;
    private boolean mEatingTouch;
    View mExpandedActionView;
    public ExpandedActionViewMenuPresenter mExpandedMenuPresenter;
    private int mGravity;
    public final ArrayList mHiddenViews;
    private ImageView mLogoView;
    private int mMaxButtonHeight;
    public ActionMenuView mMenuView;
    private final PG mMenuViewItemClickListener$ar$class_merging;
    public ImageButton mNavButtonView;
    public ActionMenuPresenter mOuterActionMenuPresenter;
    public Context mPopupContext;
    public int mPopupTheme;
    private final Runnable mShowOverflowMenuRunnable;
    public CharSequence mSubtitleText;
    public int mSubtitleTextAppearance;
    private ColorStateList mSubtitleTextColor;
    public TextView mSubtitleTextView;
    private final int[] mTempMargins;
    private final ArrayList mTempViews;
    private int mTitleMarginBottom;
    private int mTitleMarginEnd;
    private int mTitleMarginStart;
    private int mTitleMarginTop;
    public CharSequence mTitleText;
    public int mTitleTextAppearance;
    private ColorStateList mTitleTextColor;
    public TextView mTitleTextView;
    private ToolbarWidgetWrapper mWrapper;

    /* renamed from: android.support.v7.widget.Toolbar$1 */
    final class PG {
    }

    /* renamed from: android.support.v7.widget.Toolbar$2 */
    final class C01122 implements Runnable {
        public final void run() {
            android.support.p002v7.widget.Toolbar.this.showOverflowMenu();
        }
    }

    /* renamed from: android.support.v7.widget.Toolbar$3 */
    final class C01133 implements OnClickListener {
        public final void onClick(View view) {
            android.support.p002v7.widget.Toolbar.this.collapseActionView();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.Toolbar$ExpandedActionViewMenuPresenter */
    final class ExpandedActionViewMenuPresenter implements MenuPresenter {
        MenuItemImpl mCurrentExpandedItem;
        MenuBuilder mMenu;

        public final boolean collapseItemActionView$ar$ds(MenuItemImpl menuItemImpl) {
            View view = Toolbar.this.mExpandedActionView;
            if (view instanceof CollapsibleActionViewWrapper) {
                ((CollapsibleActionViewWrapper) view).mWrappedView.onActionViewCollapsed();
            }
            ViewGroup viewGroup = Toolbar.this;
            viewGroup.removeView(viewGroup.mExpandedActionView);
            viewGroup = Toolbar.this;
            viewGroup.removeView(viewGroup.mCollapseButtonView);
            viewGroup = Toolbar.this;
            viewGroup.mExpandedActionView = null;
            for (int size = viewGroup.mHiddenViews.size() - 1; size >= 0; size--) {
                viewGroup.addView((View) viewGroup.mHiddenViews.get(size));
            }
            viewGroup.mHiddenViews.clear();
            this.mCurrentExpandedItem = null;
            Toolbar.this.requestLayout();
            menuItemImpl.setActionViewExpanded(false);
            return true;
        }

        public final boolean flagActionItems() {
            return false;
        }

        public final void initForMenu(Context context, MenuBuilder menuBuilder) {
            MenuBuilder menuBuilder2 = this.mMenu;
            if (menuBuilder2 != null) {
                MenuItemImpl menuItemImpl = this.mCurrentExpandedItem;
                if (menuItemImpl != null) {
                    menuBuilder2.collapseItemActionView(menuItemImpl);
                }
            }
            this.mMenu = menuBuilder;
        }

        public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        }

        public final boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
            return false;
        }

        public final void setCallback(Callback callback) {
            throw null;
        }

        public final void updateMenuView$ar$ds() {
            if (this.mCurrentExpandedItem != null) {
                MenuBuilder menuBuilder = this.mMenu;
                if (menuBuilder != null) {
                    int size = menuBuilder.size();
                    int i = 0;
                    while (i < size) {
                        if (this.mMenu.getItem(i) != this.mCurrentExpandedItem) {
                            i++;
                        }
                    }
                }
                collapseItemActionView$ar$ds(this.mCurrentExpandedItem);
            }
        }

        public final boolean expandItemActionView$ar$ds(MenuItemImpl menuItemImpl) {
            ViewGroup viewGroup = Toolbar.this;
            if (viewGroup.mCollapseButtonView == null) {
                viewGroup.mCollapseButtonView = new AppCompatImageButton(viewGroup.getContext(), null, R.attr.toolbarNavigationButtonStyle);
                viewGroup.mCollapseButtonView.setImageDrawable(viewGroup.mCollapseIcon);
                viewGroup.mCollapseButtonView.setContentDescription(viewGroup.mCollapseDescription);
                LayoutParams generateDefaultLayoutParams$ar$ds$48fd875_0 = Toolbar.generateDefaultLayoutParams$ar$ds$48fd875_0();
                generateDefaultLayoutParams$ar$ds$48fd875_0.gravity = (viewGroup.mButtonGravity & 112) | 8388611;
                generateDefaultLayoutParams$ar$ds$48fd875_0.mViewType = 2;
                viewGroup.mCollapseButtonView.setLayoutParams(generateDefaultLayoutParams$ar$ds$48fd875_0);
                viewGroup.mCollapseButtonView.setOnClickListener(new C01133());
            }
            ViewParent parent = Toolbar.this.mCollapseButtonView.getParent();
            ViewParent viewParent = Toolbar.this;
            if (parent != viewParent) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(viewParent.mCollapseButtonView);
                }
                viewGroup = Toolbar.this;
                viewGroup.addView(viewGroup.mCollapseButtonView);
            }
            Toolbar.this.mExpandedActionView = menuItemImpl.getActionView();
            this.mCurrentExpandedItem = menuItemImpl;
            parent = Toolbar.this.mExpandedActionView.getParent();
            viewParent = Toolbar.this;
            if (parent != viewParent) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(viewParent.mExpandedActionView);
                }
                LayoutParams generateDefaultLayoutParams$ar$ds$48fd875_02 = Toolbar.generateDefaultLayoutParams$ar$ds$48fd875_0();
                Toolbar toolbar = Toolbar.this;
                generateDefaultLayoutParams$ar$ds$48fd875_02.gravity = 8388611 | (toolbar.mButtonGravity & 112);
                generateDefaultLayoutParams$ar$ds$48fd875_02.mViewType = 2;
                toolbar.mExpandedActionView.setLayoutParams(generateDefaultLayoutParams$ar$ds$48fd875_02);
                viewGroup = Toolbar.this;
                viewGroup.addView(viewGroup.mExpandedActionView);
            }
            viewGroup = Toolbar.this;
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (!(((LayoutParams) childAt.getLayoutParams()).mViewType == 2 || childAt == viewGroup.mMenuView)) {
                    viewGroup.removeViewAt(childCount);
                    viewGroup.mHiddenViews.add(childAt);
                }
            }
            Toolbar.this.requestLayout();
            menuItemImpl.setActionViewExpanded(true);
            View view = Toolbar.this.mExpandedActionView;
            if (view instanceof CollapsibleActionViewWrapper) {
                ((CollapsibleActionViewWrapper) view).mWrappedView.onActionViewExpanded();
            }
            return true;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.Toolbar$LayoutParams */
    public final class LayoutParams extends android.support.p002v7.app.ActionBar.LayoutParams {
        int mViewType;

        public LayoutParams() {
            this.mViewType = 0;
            this.gravity = 8388627;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.mViewType = 0;
        }

        public LayoutParams(android.support.p002v7.app.ActionBar.LayoutParams layoutParams) {
            super(layoutParams);
            this.mViewType = 0;
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((android.support.p002v7.app.ActionBar.LayoutParams) layoutParams);
            this.mViewType = 0;
            this.mViewType = layoutParams.mViewType;
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.mViewType = 0;
        }

        public LayoutParams(MarginLayoutParams marginLayoutParams) {
            super((android.view.ViewGroup.LayoutParams) marginLayoutParams);
            this.mViewType = 0;
            this.leftMargin = marginLayoutParams.leftMargin;
            this.topMargin = marginLayoutParams.topMargin;
            this.rightMargin = marginLayoutParams.rightMargin;
            this.bottomMargin = marginLayoutParams.bottomMargin;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.Toolbar$SavedState */
    public final class SavedState extends AbsSavedState {
        public static final Creator CREATOR = new PG();
        int expandedMenuItemId;
        boolean isOverflowOpen;

        /* renamed from: android.support.v7.widget.Toolbar$SavedState$1 */
        final class PG implements ClassLoaderCreator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new SavedState[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel, null);
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.expandedMenuItemId = parcel.readInt();
            this.isOverflowOpen = parcel.readInt() != 0;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.expandedMenuItemId);
            parcel.writeInt(this.isOverflowOpen);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public Toolbar(Context context) {
        this(context, null);
    }

    private final void addCustomViewsWithGravity(List list, int i) {
        int layoutDirection = ViewCompat.getLayoutDirection(this);
        int childCount = getChildCount();
        i = Gravity.getAbsoluteGravity(i, ViewCompat.getLayoutDirection(this));
        list.clear();
        if (layoutDirection == 1) {
            for (childCount--; childCount >= 0; childCount--) {
                View childAt = getChildAt(childCount);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.mViewType == 0 && shouldLayout(childAt) && getChildHorizontalGravity(layoutParams.gravity) == i) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (layoutDirection = 0; layoutDirection < childCount; layoutDirection++) {
            View childAt2 = getChildAt(layoutDirection);
            LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
            if (layoutParams2.mViewType == 0 && shouldLayout(childAt2) && getChildHorizontalGravity(layoutParams2.gravity) == i) {
                list.add(childAt2);
            }
        }
    }

    private final void addSystemView(View view, boolean z) {
        LayoutParams layoutParams = view.getLayoutParams();
        layoutParams = layoutParams == null ? Toolbar.generateDefaultLayoutParams$ar$ds$48fd875_0() : !checkLayoutParams(layoutParams) ? Toolbar.generateLayoutParams$ar$ds(layoutParams) : (LayoutParams) layoutParams;
        layoutParams.mViewType = 1;
        if (!z || this.mExpandedActionView == null) {
            addView(view, layoutParams);
            return;
        }
        view.setLayoutParams(layoutParams);
        this.mHiddenViews.add(view);
    }

    private final void ensureLogoView() {
        if (this.mLogoView == null) {
            this.mLogoView = new AppCompatImageView(getContext());
        }
    }

    protected static final LayoutParams generateDefaultLayoutParams$ar$ds$48fd875_0() {
        return new LayoutParams();
    }

    protected static final LayoutParams generateLayoutParams$ar$ds(LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            return new LayoutParams((LayoutParams) layoutParams);
        }
        if (layoutParams instanceof ActionBar.LayoutParams) {
            return new LayoutParams((ActionBar.LayoutParams) layoutParams);
        }
        if (layoutParams instanceof MarginLayoutParams) {
            return new LayoutParams((MarginLayoutParams) layoutParams);
        }
        return new LayoutParams(layoutParams);
    }

    private final int getChildHorizontalGravity(int i) {
        int layoutDirection = ViewCompat.getLayoutDirection(this);
        i = Gravity.getAbsoluteGravity(i, layoutDirection) & 7;
        switch (i) {
            case 1:
            case 3:
            case 5:
                break;
            default:
                if (layoutDirection == 1) {
                    i = 5;
                    break;
                }
                return 3;
        }
        return i;
    }

    private final int getChildTop(View view, int i) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        if (i > 0) {
            i = (measuredHeight - i) / 2;
        } else {
            i = 0;
        }
        int i2 = layoutParams.gravity & 112;
        switch (i2) {
            case 16:
            case 48:
            case 80:
                break;
            default:
                i2 = this.mGravity & 112;
                break;
        }
        switch (i2) {
            case 48:
                return getPaddingTop() - i;
            case 80:
                return (((getHeight() - getPaddingBottom()) - measuredHeight) - layoutParams.bottomMargin) - i;
            default:
                i = getPaddingTop();
                i2 = getPaddingBottom();
                int height = getHeight();
                int i3 = (((height - i) - i2) - measuredHeight) / 2;
                if (i3 < layoutParams.topMargin) {
                    i3 = layoutParams.topMargin;
                } else {
                    height = (((height - i2) - measuredHeight) - i3) - i;
                    if (height < layoutParams.bottomMargin) {
                        i3 = Math.max(0, i3 - (layoutParams.bottomMargin - height));
                    }
                }
                return i + i3;
        }
    }

    private static final int getHorizontalMargins$ar$ds(View view) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    private static final int getVerticalMargins$ar$ds(View view) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    private final boolean isChildOrHidden(View view) {
        if (view.getParent() != this) {
            if (!this.mHiddenViews.contains(view)) {
                return false;
            }
        }
        return true;
    }

    private final int layoutChildLeft(View view, int i, int[] iArr, int i2) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i3 = layoutParams.leftMargin - iArr[0];
        i += Math.max(0, i3);
        iArr[0] = Math.max(0, -i3);
        int childTop = getChildTop(view, i2);
        i2 = view.getMeasuredWidth();
        view.layout(i, childTop, i + i2, view.getMeasuredHeight() + childTop);
        return i + (i2 + layoutParams.rightMargin);
    }

    private final int layoutChildRight(View view, int i, int[] iArr, int i2) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i3 = layoutParams.rightMargin - iArr[1];
        i -= Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        int childTop = getChildTop(view, i2);
        i2 = view.getMeasuredWidth();
        view.layout(i - i2, childTop, i, view.getMeasuredHeight() + childTop);
        return i - (i2 + layoutParams.leftMargin);
    }

    private final int measureChildCollapseMargins(View view, int i, int i2, int i3, int i4, int[] iArr) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i5) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(ViewGroup.getChildMeasureSpec(i, ((getPaddingLeft() + getPaddingRight()) + max) + i2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i3, (((getPaddingTop() + getPaddingBottom()) + marginLayoutParams.topMargin) + marginLayoutParams.bottomMargin) + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    private final void measureChildConstrained$ar$ds(View view, int i, int i2, int i3, int i4) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        i = ViewGroup.getChildMeasureSpec(i, (((getPaddingLeft() + getPaddingRight()) + marginLayoutParams.leftMargin) + marginLayoutParams.rightMargin) + i2, marginLayoutParams.width);
        i2 = ViewGroup.getChildMeasureSpec(i3, ((getPaddingTop() + getPaddingBottom()) + marginLayoutParams.topMargin) + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        i3 = MeasureSpec.getMode(i2);
        if (i3 != 1073741824 && i4 >= 0) {
            if (i3 != 0) {
                i4 = Math.min(MeasureSpec.getSize(i2), i4);
            }
            i2 = MeasureSpec.makeMeasureSpec(i4, 1073741824);
        }
        view.measure(i, i2);
    }

    private final boolean shouldLayout(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    protected final boolean checkLayoutParams(LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof LayoutParams);
    }

    public final void collapseActionView() {
        ExpandedActionViewMenuPresenter expandedActionViewMenuPresenter = this.mExpandedMenuPresenter;
        MenuItemImpl menuItemImpl = expandedActionViewMenuPresenter == null ? null : expandedActionViewMenuPresenter.mCurrentExpandedItem;
        if (menuItemImpl != null) {
            menuItemImpl.collapseActionView();
        }
    }

    public final void ensureContentInsets() {
        if (this.mContentInsets == null) {
            this.mContentInsets = new RtlSpacingHelper();
        }
    }

    public final void ensureMenuView() {
        if (this.mMenuView == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.mMenuView = actionMenuView;
            actionMenuView.setPopupTheme(this.mPopupTheme);
            this.mMenuView.mOnMenuItemClickListener$ar$class_merging = this.mMenuViewItemClickListener$ar$class_merging;
            LayoutParams generateDefaultLayoutParams$ar$ds$48fd875_0 = Toolbar.generateDefaultLayoutParams$ar$ds$48fd875_0();
            generateDefaultLayoutParams$ar$ds$48fd875_0.gravity = (this.mButtonGravity & 112) | 8388613;
            this.mMenuView.setLayoutParams(generateDefaultLayoutParams$ar$ds$48fd875_0);
            addSystemView(this.mMenuView, false);
        }
    }

    public final void ensureNavButtonView() {
        if (this.mNavButtonView == null) {
            this.mNavButtonView = new AppCompatImageButton(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            LayoutParams generateDefaultLayoutParams$ar$ds$48fd875_0 = Toolbar.generateDefaultLayoutParams$ar$ds$48fd875_0();
            generateDefaultLayoutParams$ar$ds$48fd875_0.gravity = (this.mButtonGravity & 112) | 8388611;
            this.mNavButtonView.setLayoutParams(generateDefaultLayoutParams$ar$ds$48fd875_0);
        }
    }

    protected final /* bridge */ /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return Toolbar.generateDefaultLayoutParams$ar$ds$48fd875_0();
    }

    public final int getContentInsetEnd() {
        RtlSpacingHelper rtlSpacingHelper = this.mContentInsets;
        if (rtlSpacingHelper == null) {
            return 0;
        }
        return rtlSpacingHelper.mIsRtl ? rtlSpacingHelper.mLeft : rtlSpacingHelper.mRight;
    }

    public final int getContentInsetStart() {
        RtlSpacingHelper rtlSpacingHelper = this.mContentInsets;
        if (rtlSpacingHelper == null) {
            return 0;
        }
        return rtlSpacingHelper.mIsRtl ? rtlSpacingHelper.mRight : rtlSpacingHelper.mLeft;
    }

    public final int getCurrentContentInsetEnd() {
        ActionMenuView actionMenuView = this.mMenuView;
        if (actionMenuView != null) {
            MenuBuilder menuBuilder = actionMenuView.mMenu;
            if (menuBuilder != null && menuBuilder.hasVisibleItems()) {
                return Math.max(getContentInsetEnd(), Math.max(this.mContentInsetEndWithActions, 0));
            }
        }
        return getContentInsetEnd();
    }

    public final int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.mContentInsetStartWithNavigation, 0)) : getContentInsetStart();
    }

    public final CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.mNavButtonView;
        return imageButton != null ? imageButton.getContentDescription() : null;
    }

    public final Drawable getNavigationIcon() {
        ImageButton imageButton = this.mNavButtonView;
        return imageButton != null ? imageButton.getDrawable() : null;
    }

    public final DecorToolbar getWrapper() {
        if (this.mWrapper == null) {
            this.mWrapper = new ToolbarWidgetWrapper(this);
        }
        return this.mWrapper;
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.mShowOverflowMenuRunnable);
    }

    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        int i = 9;
        if (actionMasked == 9) {
            this.mEatingHover = false;
            actionMasked = 9;
        }
        if (!this.mEatingHover) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9) {
                if (!onHoverEvent) {
                    this.mEatingHover = true;
                }
                if (i == 10 || i == 3) {
                    this.mEatingHover = false;
                }
                return true;
            }
        }
        i = actionMasked;
        this.mEatingHover = false;
        return true;
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int layoutChildRight;
        int currentContentInsetEnd;
        int currentContentInsetStart;
        int max;
        boolean shouldLayout;
        boolean shouldLayout2;
        int i6;
        LayoutParams layoutParams;
        int i7;
        List list;
        View view;
        LayoutParams layoutParams2;
        View view2;
        View view3;
        LayoutParams layoutParams3;
        Object obj;
        LayoutParams layoutParams4;
        int layoutDirection = ViewCompat.getLayoutDirection(this);
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i8 = width - paddingRight;
        int[] iArr = this.mTempMargins;
        iArr[1] = 0;
        iArr[0] = 0;
        int minimumHeight = ViewCompat.getMinimumHeight(this);
        if (minimumHeight >= 0) {
            minimumHeight = Math.min(minimumHeight, i4 - i2);
        } else {
            minimumHeight = 0;
        }
        if (!shouldLayout(r0.mNavButtonView)) {
            i5 = paddingLeft;
        } else if (layoutDirection == 1) {
            layoutChildRight = layoutChildRight(r0.mNavButtonView, i8, iArr, minimumHeight);
            i5 = paddingLeft;
            if (shouldLayout(r0.mCollapseButtonView)) {
                if (layoutDirection != 1) {
                    layoutChildRight = layoutChildRight(r0.mCollapseButtonView, layoutChildRight, iArr, minimumHeight);
                } else {
                    i5 = layoutChildLeft(r0.mCollapseButtonView, i5, iArr, minimumHeight);
                }
            }
            if (shouldLayout(r0.mMenuView)) {
                if (layoutDirection != 1) {
                    i5 = layoutChildLeft(r0.mMenuView, i5, iArr, minimumHeight);
                } else {
                    layoutChildRight = layoutChildRight(r0.mMenuView, layoutChildRight, iArr, minimumHeight);
                }
            }
            currentContentInsetEnd = ViewCompat.getLayoutDirection(this) != 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
            currentContentInsetStart = ViewCompat.getLayoutDirection(this) != 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
            i3 = paddingRight;
            iArr[0] = Math.max(0, currentContentInsetEnd - i5);
            iArr[1] = Math.max(0, currentContentInsetStart - (i8 - layoutChildRight));
            max = Math.max(i5, currentContentInsetEnd);
            i8 = Math.min(layoutChildRight, i8 - currentContentInsetStart);
            if (shouldLayout(r0.mExpandedActionView)) {
                if (layoutDirection != 1) {
                    i8 = layoutChildRight(r0.mExpandedActionView, i8, iArr, minimumHeight);
                } else {
                    max = layoutChildLeft(r0.mExpandedActionView, max, iArr, minimumHeight);
                }
            }
            if (shouldLayout(r0.mLogoView)) {
                if (layoutDirection != 1) {
                    i8 = layoutChildRight(r0.mLogoView, i8, iArr, minimumHeight);
                } else {
                    max = layoutChildLeft(r0.mLogoView, max, iArr, minimumHeight);
                }
            }
            shouldLayout = shouldLayout(r0.mTitleTextView);
            shouldLayout2 = shouldLayout(r0.mSubtitleTextView);
            if (shouldLayout) {
                i5 = 0;
            } else {
                LayoutParams layoutParams5 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                i5 = layoutParams5.bottomMargin + (layoutParams5.topMargin + r0.mTitleTextView.getMeasuredHeight());
            }
            if (shouldLayout2) {
                i6 = width;
            } else {
                layoutParams = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                i6 = width;
                i5 += (layoutParams.topMargin + r0.mSubtitleTextView.getMeasuredHeight()) + layoutParams.bottomMargin;
            }
            if (!shouldLayout) {
                if (shouldLayout2) {
                    i7 = paddingLeft;
                    i2 = minimumHeight;
                    addCustomViewsWithGravity(r0.mTempViews, 3);
                    layoutDirection = r0.mTempViews.size();
                    for (width = 0; width < layoutDirection; width++) {
                        max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, i2);
                    }
                    currentContentInsetStart = i2;
                    addCustomViewsWithGravity(r0.mTempViews, 5);
                    layoutDirection = r0.mTempViews.size();
                    for (width = 0; width < layoutDirection; width++) {
                        i8 = layoutChildRight((View) r0.mTempViews.get(width), i8, iArr, currentContentInsetStart);
                    }
                    addCustomViewsWithGravity(r0.mTempViews, 1);
                    list = r0.mTempViews;
                    paddingLeft = iArr[0];
                    width = iArr[1];
                    height = list.size();
                    paddingRight = 0;
                    paddingTop = 0;
                    while (paddingRight < height) {
                        view = (View) list.get(paddingRight);
                        layoutParams2 = (LayoutParams) view.getLayoutParams();
                        i5 = layoutParams2.leftMargin - paddingLeft;
                        paddingLeft = layoutParams2.rightMargin - width;
                        minimumHeight = Math.max(0, i5);
                        layoutChildRight = Math.max(0, paddingLeft);
                        i5 = Math.max(0, -i5);
                        paddingTop += (minimumHeight + view.getMeasuredWidth()) + layoutChildRight;
                        paddingRight++;
                        width = Math.max(0, -paddingLeft);
                        paddingLeft = i5;
                    }
                    paddingLeft = (i7 + (((i6 - i7) - i3) / 2)) - (paddingTop / 2);
                    paddingTop += paddingLeft;
                    if (paddingLeft < max) {
                        max = paddingTop <= i8 ? paddingLeft - (paddingTop - i8) : paddingLeft;
                    }
                    layoutDirection = r0.mTempViews.size();
                    for (width = 0; width < layoutDirection; width++) {
                        max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, currentContentInsetStart);
                    }
                    r0.mTempViews.clear();
                }
            }
            if (shouldLayout) {
                view2 = r0.mSubtitleTextView;
            } else {
                view2 = r0.mTitleTextView;
            }
            if (shouldLayout2) {
                view3 = r0.mTitleTextView;
            } else {
                view3 = r0.mSubtitleTextView;
            }
            layoutParams3 = (LayoutParams) view2.getLayoutParams();
            layoutParams = (LayoutParams) view3.getLayoutParams();
            if (shouldLayout) {
                if (r0.mTitleTextView.getMeasuredWidth() <= 0) {
                    obj = 1;
                    i7 = paddingLeft;
                    switch (r0.mGravity & 112) {
                        case 48:
                            height = (getPaddingTop() + layoutParams3.topMargin) + r0.mTitleMarginTop;
                            i4 = max;
                            i2 = minimumHeight;
                            break;
                        case 80:
                            height = (((height - paddingBottom) - layoutParams.bottomMargin) - r0.mTitleMarginBottom) - i5;
                            i4 = max;
                            i2 = minimumHeight;
                            break;
                        default:
                            paddingLeft = (((height - paddingTop) - paddingBottom) - i5) / 2;
                            i2 = minimumHeight;
                            i4 = max;
                            if (paddingLeft >= layoutParams3.topMargin + r0.mTitleMarginTop) {
                                paddingLeft = layoutParams3.topMargin + r0.mTitleMarginTop;
                            } else {
                                height = (((height - paddingBottom) - i5) - paddingLeft) - paddingTop;
                                if (height >= layoutParams3.bottomMargin + r0.mTitleMarginBottom) {
                                    paddingLeft = Math.max(0, paddingLeft - ((layoutParams.bottomMargin + r0.mTitleMarginBottom) - height));
                                }
                            }
                            height = paddingTop + paddingLeft;
                            break;
                    }
                    if (layoutDirection != 1) {
                        layoutDirection = (obj == null ? r0.mTitleMarginStart : 0) - iArr[1];
                        i8 -= Math.max(0, layoutDirection);
                        iArr[1] = Math.max(0, -layoutDirection);
                        if (shouldLayout) {
                            width = i8;
                        } else {
                            layoutParams4 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                            width = i8 - r0.mTitleTextView.getMeasuredWidth();
                            paddingLeft = r0.mTitleTextView.getMeasuredHeight() + height;
                            r0.mTitleTextView.layout(width, height, i8, paddingLeft);
                            width -= r0.mTitleMarginEnd;
                            height = paddingLeft + layoutParams4.bottomMargin;
                        }
                        if (shouldLayout2) {
                            height = i8;
                        } else {
                            layoutParams4 = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                            height += layoutParams4.topMargin;
                            r0.mSubtitleTextView.layout(i8 - r0.mSubtitleTextView.getMeasuredWidth(), height, i8, r0.mSubtitleTextView.getMeasuredHeight() + height);
                            height = i8 - r0.mTitleMarginEnd;
                            layoutDirection = layoutParams4.bottomMargin;
                        }
                        if (obj == null) {
                            i8 = Math.min(width, height);
                        }
                        max = i4;
                    } else {
                        layoutDirection = (obj == null ? r0.mTitleMarginStart : 0) - iArr[0];
                        max = i4 + Math.max(0, layoutDirection);
                        iArr[0] = Math.max(0, -layoutDirection);
                        if (shouldLayout) {
                            width = max;
                        } else {
                            layoutParams4 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                            width = r0.mTitleTextView.getMeasuredWidth() + max;
                            paddingLeft = r0.mTitleTextView.getMeasuredHeight() + height;
                            r0.mTitleTextView.layout(max, height, width, paddingLeft);
                            width += r0.mTitleMarginEnd;
                            height = paddingLeft + layoutParams4.bottomMargin;
                        }
                        if (shouldLayout2) {
                            paddingLeft = max;
                        } else {
                            layoutParams4 = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                            height += layoutParams4.topMargin;
                            paddingLeft = r0.mSubtitleTextView.getMeasuredWidth() + max;
                            r0.mSubtitleTextView.layout(max, height, paddingLeft, r0.mSubtitleTextView.getMeasuredHeight() + height);
                            paddingLeft += r0.mTitleMarginEnd;
                            layoutDirection = layoutParams4.bottomMargin;
                        }
                        if (obj == null) {
                            max = Math.max(width, paddingLeft);
                        }
                    }
                    addCustomViewsWithGravity(r0.mTempViews, 3);
                    layoutDirection = r0.mTempViews.size();
                    for (width = 0; width < layoutDirection; width++) {
                        max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, i2);
                    }
                    currentContentInsetStart = i2;
                    addCustomViewsWithGravity(r0.mTempViews, 5);
                    layoutDirection = r0.mTempViews.size();
                    for (width = 0; width < layoutDirection; width++) {
                        i8 = layoutChildRight((View) r0.mTempViews.get(width), i8, iArr, currentContentInsetStart);
                    }
                    addCustomViewsWithGravity(r0.mTempViews, 1);
                    list = r0.mTempViews;
                    paddingLeft = iArr[0];
                    width = iArr[1];
                    height = list.size();
                    paddingRight = 0;
                    paddingTop = 0;
                    while (paddingRight < height) {
                        view = (View) list.get(paddingRight);
                        layoutParams2 = (LayoutParams) view.getLayoutParams();
                        i5 = layoutParams2.leftMargin - paddingLeft;
                        paddingLeft = layoutParams2.rightMargin - width;
                        minimumHeight = Math.max(0, i5);
                        layoutChildRight = Math.max(0, paddingLeft);
                        i5 = Math.max(0, -i5);
                        paddingTop += (minimumHeight + view.getMeasuredWidth()) + layoutChildRight;
                        paddingRight++;
                        width = Math.max(0, -paddingLeft);
                        paddingLeft = i5;
                    }
                    paddingLeft = (i7 + (((i6 - i7) - i3) / 2)) - (paddingTop / 2);
                    paddingTop += paddingLeft;
                    if (paddingLeft < max) {
                        if (paddingTop <= i8) {
                        }
                    }
                    layoutDirection = r0.mTempViews.size();
                    for (width = 0; width < layoutDirection; width++) {
                        max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, currentContentInsetStart);
                    }
                    r0.mTempViews.clear();
                }
            }
            obj = (shouldLayout2 || r0.mSubtitleTextView.getMeasuredWidth() <= 0) ? null : 1;
            i7 = paddingLeft;
            switch (r0.mGravity & 112) {
                case 48:
                    height = (getPaddingTop() + layoutParams3.topMargin) + r0.mTitleMarginTop;
                    i4 = max;
                    i2 = minimumHeight;
                    break;
                case 80:
                    height = (((height - paddingBottom) - layoutParams.bottomMargin) - r0.mTitleMarginBottom) - i5;
                    i4 = max;
                    i2 = minimumHeight;
                    break;
                default:
                    paddingLeft = (((height - paddingTop) - paddingBottom) - i5) / 2;
                    i2 = minimumHeight;
                    i4 = max;
                    if (paddingLeft >= layoutParams3.topMargin + r0.mTitleMarginTop) {
                        height = (((height - paddingBottom) - i5) - paddingLeft) - paddingTop;
                        if (height >= layoutParams3.bottomMargin + r0.mTitleMarginBottom) {
                            paddingLeft = Math.max(0, paddingLeft - ((layoutParams.bottomMargin + r0.mTitleMarginBottom) - height));
                        }
                    } else {
                        paddingLeft = layoutParams3.topMargin + r0.mTitleMarginTop;
                    }
                    height = paddingTop + paddingLeft;
                    break;
            }
            if (layoutDirection != 1) {
                if (obj == null) {
                }
                layoutDirection = (obj == null ? r0.mTitleMarginStart : 0) - iArr[0];
                max = i4 + Math.max(0, layoutDirection);
                iArr[0] = Math.max(0, -layoutDirection);
                if (shouldLayout) {
                    width = max;
                } else {
                    layoutParams4 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                    width = r0.mTitleTextView.getMeasuredWidth() + max;
                    paddingLeft = r0.mTitleTextView.getMeasuredHeight() + height;
                    r0.mTitleTextView.layout(max, height, width, paddingLeft);
                    width += r0.mTitleMarginEnd;
                    height = paddingLeft + layoutParams4.bottomMargin;
                }
                if (shouldLayout2) {
                    paddingLeft = max;
                } else {
                    layoutParams4 = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                    height += layoutParams4.topMargin;
                    paddingLeft = r0.mSubtitleTextView.getMeasuredWidth() + max;
                    r0.mSubtitleTextView.layout(max, height, paddingLeft, r0.mSubtitleTextView.getMeasuredHeight() + height);
                    paddingLeft += r0.mTitleMarginEnd;
                    layoutDirection = layoutParams4.bottomMargin;
                }
                if (obj == null) {
                    max = Math.max(width, paddingLeft);
                }
            } else {
                if (obj == null) {
                }
                layoutDirection = (obj == null ? r0.mTitleMarginStart : 0) - iArr[1];
                i8 -= Math.max(0, layoutDirection);
                iArr[1] = Math.max(0, -layoutDirection);
                if (shouldLayout) {
                    width = i8;
                } else {
                    layoutParams4 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                    width = i8 - r0.mTitleTextView.getMeasuredWidth();
                    paddingLeft = r0.mTitleTextView.getMeasuredHeight() + height;
                    r0.mTitleTextView.layout(width, height, i8, paddingLeft);
                    width -= r0.mTitleMarginEnd;
                    height = paddingLeft + layoutParams4.bottomMargin;
                }
                if (shouldLayout2) {
                    height = i8;
                } else {
                    layoutParams4 = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                    height += layoutParams4.topMargin;
                    r0.mSubtitleTextView.layout(i8 - r0.mSubtitleTextView.getMeasuredWidth(), height, i8, r0.mSubtitleTextView.getMeasuredHeight() + height);
                    height = i8 - r0.mTitleMarginEnd;
                    layoutDirection = layoutParams4.bottomMargin;
                }
                if (obj == null) {
                    i8 = Math.min(width, height);
                }
                max = i4;
            }
            addCustomViewsWithGravity(r0.mTempViews, 3);
            layoutDirection = r0.mTempViews.size();
            for (width = 0; width < layoutDirection; width++) {
                max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, i2);
            }
            currentContentInsetStart = i2;
            addCustomViewsWithGravity(r0.mTempViews, 5);
            layoutDirection = r0.mTempViews.size();
            for (width = 0; width < layoutDirection; width++) {
                i8 = layoutChildRight((View) r0.mTempViews.get(width), i8, iArr, currentContentInsetStart);
            }
            addCustomViewsWithGravity(r0.mTempViews, 1);
            list = r0.mTempViews;
            paddingLeft = iArr[0];
            width = iArr[1];
            height = list.size();
            paddingRight = 0;
            paddingTop = 0;
            while (paddingRight < height) {
                view = (View) list.get(paddingRight);
                layoutParams2 = (LayoutParams) view.getLayoutParams();
                i5 = layoutParams2.leftMargin - paddingLeft;
                paddingLeft = layoutParams2.rightMargin - width;
                minimumHeight = Math.max(0, i5);
                layoutChildRight = Math.max(0, paddingLeft);
                i5 = Math.max(0, -i5);
                paddingTop += (minimumHeight + view.getMeasuredWidth()) + layoutChildRight;
                paddingRight++;
                width = Math.max(0, -paddingLeft);
                paddingLeft = i5;
            }
            paddingLeft = (i7 + (((i6 - i7) - i3) / 2)) - (paddingTop / 2);
            paddingTop += paddingLeft;
            if (paddingLeft < max) {
                if (paddingTop <= i8) {
                }
            }
            layoutDirection = r0.mTempViews.size();
            for (width = 0; width < layoutDirection; width++) {
                max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, currentContentInsetStart);
            }
            r0.mTempViews.clear();
        } else {
            i5 = layoutChildLeft(r0.mNavButtonView, paddingLeft, iArr, minimumHeight);
        }
        layoutChildRight = i8;
        if (shouldLayout(r0.mCollapseButtonView)) {
            if (layoutDirection != 1) {
                i5 = layoutChildLeft(r0.mCollapseButtonView, i5, iArr, minimumHeight);
            } else {
                layoutChildRight = layoutChildRight(r0.mCollapseButtonView, layoutChildRight, iArr, minimumHeight);
            }
        }
        if (shouldLayout(r0.mMenuView)) {
            if (layoutDirection != 1) {
                layoutChildRight = layoutChildRight(r0.mMenuView, layoutChildRight, iArr, minimumHeight);
            } else {
                i5 = layoutChildLeft(r0.mMenuView, i5, iArr, minimumHeight);
            }
        }
        if (ViewCompat.getLayoutDirection(this) != 1) {
        }
        if (ViewCompat.getLayoutDirection(this) != 1) {
        }
        i3 = paddingRight;
        iArr[0] = Math.max(0, currentContentInsetEnd - i5);
        iArr[1] = Math.max(0, currentContentInsetStart - (i8 - layoutChildRight));
        max = Math.max(i5, currentContentInsetEnd);
        i8 = Math.min(layoutChildRight, i8 - currentContentInsetStart);
        if (shouldLayout(r0.mExpandedActionView)) {
            if (layoutDirection != 1) {
                max = layoutChildLeft(r0.mExpandedActionView, max, iArr, minimumHeight);
            } else {
                i8 = layoutChildRight(r0.mExpandedActionView, i8, iArr, minimumHeight);
            }
        }
        if (shouldLayout(r0.mLogoView)) {
            if (layoutDirection != 1) {
                max = layoutChildLeft(r0.mLogoView, max, iArr, minimumHeight);
            } else {
                i8 = layoutChildRight(r0.mLogoView, i8, iArr, minimumHeight);
            }
        }
        shouldLayout = shouldLayout(r0.mTitleTextView);
        shouldLayout2 = shouldLayout(r0.mSubtitleTextView);
        if (shouldLayout) {
            i5 = 0;
        } else {
            LayoutParams layoutParams52 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
            i5 = layoutParams52.bottomMargin + (layoutParams52.topMargin + r0.mTitleTextView.getMeasuredHeight());
        }
        if (shouldLayout2) {
            i6 = width;
        } else {
            layoutParams = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
            i6 = width;
            i5 += (layoutParams.topMargin + r0.mSubtitleTextView.getMeasuredHeight()) + layoutParams.bottomMargin;
        }
        if (shouldLayout) {
            if (shouldLayout2) {
                i7 = paddingLeft;
                i2 = minimumHeight;
                addCustomViewsWithGravity(r0.mTempViews, 3);
                layoutDirection = r0.mTempViews.size();
                for (width = 0; width < layoutDirection; width++) {
                    max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, i2);
                }
                currentContentInsetStart = i2;
                addCustomViewsWithGravity(r0.mTempViews, 5);
                layoutDirection = r0.mTempViews.size();
                for (width = 0; width < layoutDirection; width++) {
                    i8 = layoutChildRight((View) r0.mTempViews.get(width), i8, iArr, currentContentInsetStart);
                }
                addCustomViewsWithGravity(r0.mTempViews, 1);
                list = r0.mTempViews;
                paddingLeft = iArr[0];
                width = iArr[1];
                height = list.size();
                paddingRight = 0;
                paddingTop = 0;
                while (paddingRight < height) {
                    view = (View) list.get(paddingRight);
                    layoutParams2 = (LayoutParams) view.getLayoutParams();
                    i5 = layoutParams2.leftMargin - paddingLeft;
                    paddingLeft = layoutParams2.rightMargin - width;
                    minimumHeight = Math.max(0, i5);
                    layoutChildRight = Math.max(0, paddingLeft);
                    i5 = Math.max(0, -i5);
                    paddingTop += (minimumHeight + view.getMeasuredWidth()) + layoutChildRight;
                    paddingRight++;
                    width = Math.max(0, -paddingLeft);
                    paddingLeft = i5;
                }
                paddingLeft = (i7 + (((i6 - i7) - i3) / 2)) - (paddingTop / 2);
                paddingTop += paddingLeft;
                if (paddingLeft < max) {
                    if (paddingTop <= i8) {
                    }
                }
                layoutDirection = r0.mTempViews.size();
                for (width = 0; width < layoutDirection; width++) {
                    max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, currentContentInsetStart);
                }
                r0.mTempViews.clear();
            }
        }
        if (shouldLayout) {
            view2 = r0.mSubtitleTextView;
        } else {
            view2 = r0.mTitleTextView;
        }
        if (shouldLayout2) {
            view3 = r0.mTitleTextView;
        } else {
            view3 = r0.mSubtitleTextView;
        }
        layoutParams3 = (LayoutParams) view2.getLayoutParams();
        layoutParams = (LayoutParams) view3.getLayoutParams();
        if (shouldLayout) {
            if (r0.mTitleTextView.getMeasuredWidth() <= 0) {
                obj = 1;
                i7 = paddingLeft;
                switch (r0.mGravity & 112) {
                    case 48:
                        height = (getPaddingTop() + layoutParams3.topMargin) + r0.mTitleMarginTop;
                        i4 = max;
                        i2 = minimumHeight;
                        break;
                    case 80:
                        height = (((height - paddingBottom) - layoutParams.bottomMargin) - r0.mTitleMarginBottom) - i5;
                        i4 = max;
                        i2 = minimumHeight;
                        break;
                    default:
                        paddingLeft = (((height - paddingTop) - paddingBottom) - i5) / 2;
                        i2 = minimumHeight;
                        i4 = max;
                        if (paddingLeft >= layoutParams3.topMargin + r0.mTitleMarginTop) {
                            paddingLeft = layoutParams3.topMargin + r0.mTitleMarginTop;
                        } else {
                            height = (((height - paddingBottom) - i5) - paddingLeft) - paddingTop;
                            if (height >= layoutParams3.bottomMargin + r0.mTitleMarginBottom) {
                                paddingLeft = Math.max(0, paddingLeft - ((layoutParams.bottomMargin + r0.mTitleMarginBottom) - height));
                            }
                        }
                        height = paddingTop + paddingLeft;
                        break;
                }
                if (layoutDirection != 1) {
                    if (obj == null) {
                    }
                    layoutDirection = (obj == null ? r0.mTitleMarginStart : 0) - iArr[1];
                    i8 -= Math.max(0, layoutDirection);
                    iArr[1] = Math.max(0, -layoutDirection);
                    if (shouldLayout) {
                        layoutParams4 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                        width = i8 - r0.mTitleTextView.getMeasuredWidth();
                        paddingLeft = r0.mTitleTextView.getMeasuredHeight() + height;
                        r0.mTitleTextView.layout(width, height, i8, paddingLeft);
                        width -= r0.mTitleMarginEnd;
                        height = paddingLeft + layoutParams4.bottomMargin;
                    } else {
                        width = i8;
                    }
                    if (shouldLayout2) {
                        layoutParams4 = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                        height += layoutParams4.topMargin;
                        r0.mSubtitleTextView.layout(i8 - r0.mSubtitleTextView.getMeasuredWidth(), height, i8, r0.mSubtitleTextView.getMeasuredHeight() + height);
                        height = i8 - r0.mTitleMarginEnd;
                        layoutDirection = layoutParams4.bottomMargin;
                    } else {
                        height = i8;
                    }
                    if (obj == null) {
                        i8 = Math.min(width, height);
                    }
                    max = i4;
                } else {
                    if (obj == null) {
                    }
                    layoutDirection = (obj == null ? r0.mTitleMarginStart : 0) - iArr[0];
                    max = i4 + Math.max(0, layoutDirection);
                    iArr[0] = Math.max(0, -layoutDirection);
                    if (shouldLayout) {
                        layoutParams4 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                        width = r0.mTitleTextView.getMeasuredWidth() + max;
                        paddingLeft = r0.mTitleTextView.getMeasuredHeight() + height;
                        r0.mTitleTextView.layout(max, height, width, paddingLeft);
                        width += r0.mTitleMarginEnd;
                        height = paddingLeft + layoutParams4.bottomMargin;
                    } else {
                        width = max;
                    }
                    if (shouldLayout2) {
                        layoutParams4 = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                        height += layoutParams4.topMargin;
                        paddingLeft = r0.mSubtitleTextView.getMeasuredWidth() + max;
                        r0.mSubtitleTextView.layout(max, height, paddingLeft, r0.mSubtitleTextView.getMeasuredHeight() + height);
                        paddingLeft += r0.mTitleMarginEnd;
                        layoutDirection = layoutParams4.bottomMargin;
                    } else {
                        paddingLeft = max;
                    }
                    if (obj == null) {
                        max = Math.max(width, paddingLeft);
                    }
                }
                addCustomViewsWithGravity(r0.mTempViews, 3);
                layoutDirection = r0.mTempViews.size();
                for (width = 0; width < layoutDirection; width++) {
                    max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, i2);
                }
                currentContentInsetStart = i2;
                addCustomViewsWithGravity(r0.mTempViews, 5);
                layoutDirection = r0.mTempViews.size();
                for (width = 0; width < layoutDirection; width++) {
                    i8 = layoutChildRight((View) r0.mTempViews.get(width), i8, iArr, currentContentInsetStart);
                }
                addCustomViewsWithGravity(r0.mTempViews, 1);
                list = r0.mTempViews;
                paddingLeft = iArr[0];
                width = iArr[1];
                height = list.size();
                paddingRight = 0;
                paddingTop = 0;
                while (paddingRight < height) {
                    view = (View) list.get(paddingRight);
                    layoutParams2 = (LayoutParams) view.getLayoutParams();
                    i5 = layoutParams2.leftMargin - paddingLeft;
                    paddingLeft = layoutParams2.rightMargin - width;
                    minimumHeight = Math.max(0, i5);
                    layoutChildRight = Math.max(0, paddingLeft);
                    i5 = Math.max(0, -i5);
                    paddingTop += (minimumHeight + view.getMeasuredWidth()) + layoutChildRight;
                    paddingRight++;
                    width = Math.max(0, -paddingLeft);
                    paddingLeft = i5;
                }
                paddingLeft = (i7 + (((i6 - i7) - i3) / 2)) - (paddingTop / 2);
                paddingTop += paddingLeft;
                if (paddingLeft < max) {
                    if (paddingTop <= i8) {
                    }
                }
                layoutDirection = r0.mTempViews.size();
                for (width = 0; width < layoutDirection; width++) {
                    max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, currentContentInsetStart);
                }
                r0.mTempViews.clear();
            }
        }
        if (shouldLayout2) {
        }
        i7 = paddingLeft;
        switch (r0.mGravity & 112) {
            case 48:
                height = (getPaddingTop() + layoutParams3.topMargin) + r0.mTitleMarginTop;
                i4 = max;
                i2 = minimumHeight;
                break;
            case 80:
                height = (((height - paddingBottom) - layoutParams.bottomMargin) - r0.mTitleMarginBottom) - i5;
                i4 = max;
                i2 = minimumHeight;
                break;
            default:
                paddingLeft = (((height - paddingTop) - paddingBottom) - i5) / 2;
                i2 = minimumHeight;
                i4 = max;
                if (paddingLeft >= layoutParams3.topMargin + r0.mTitleMarginTop) {
                    height = (((height - paddingBottom) - i5) - paddingLeft) - paddingTop;
                    if (height >= layoutParams3.bottomMargin + r0.mTitleMarginBottom) {
                        paddingLeft = Math.max(0, paddingLeft - ((layoutParams.bottomMargin + r0.mTitleMarginBottom) - height));
                    }
                } else {
                    paddingLeft = layoutParams3.topMargin + r0.mTitleMarginTop;
                }
                height = paddingTop + paddingLeft;
                break;
        }
        if (layoutDirection != 1) {
            if (obj == null) {
            }
            layoutDirection = (obj == null ? r0.mTitleMarginStart : 0) - iArr[0];
            max = i4 + Math.max(0, layoutDirection);
            iArr[0] = Math.max(0, -layoutDirection);
            if (shouldLayout) {
                width = max;
            } else {
                layoutParams4 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                width = r0.mTitleTextView.getMeasuredWidth() + max;
                paddingLeft = r0.mTitleTextView.getMeasuredHeight() + height;
                r0.mTitleTextView.layout(max, height, width, paddingLeft);
                width += r0.mTitleMarginEnd;
                height = paddingLeft + layoutParams4.bottomMargin;
            }
            if (shouldLayout2) {
                paddingLeft = max;
            } else {
                layoutParams4 = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                height += layoutParams4.topMargin;
                paddingLeft = r0.mSubtitleTextView.getMeasuredWidth() + max;
                r0.mSubtitleTextView.layout(max, height, paddingLeft, r0.mSubtitleTextView.getMeasuredHeight() + height);
                paddingLeft += r0.mTitleMarginEnd;
                layoutDirection = layoutParams4.bottomMargin;
            }
            if (obj == null) {
                max = Math.max(width, paddingLeft);
            }
        } else {
            if (obj == null) {
            }
            layoutDirection = (obj == null ? r0.mTitleMarginStart : 0) - iArr[1];
            i8 -= Math.max(0, layoutDirection);
            iArr[1] = Math.max(0, -layoutDirection);
            if (shouldLayout) {
                width = i8;
            } else {
                layoutParams4 = (LayoutParams) r0.mTitleTextView.getLayoutParams();
                width = i8 - r0.mTitleTextView.getMeasuredWidth();
                paddingLeft = r0.mTitleTextView.getMeasuredHeight() + height;
                r0.mTitleTextView.layout(width, height, i8, paddingLeft);
                width -= r0.mTitleMarginEnd;
                height = paddingLeft + layoutParams4.bottomMargin;
            }
            if (shouldLayout2) {
                height = i8;
            } else {
                layoutParams4 = (LayoutParams) r0.mSubtitleTextView.getLayoutParams();
                height += layoutParams4.topMargin;
                r0.mSubtitleTextView.layout(i8 - r0.mSubtitleTextView.getMeasuredWidth(), height, i8, r0.mSubtitleTextView.getMeasuredHeight() + height);
                height = i8 - r0.mTitleMarginEnd;
                layoutDirection = layoutParams4.bottomMargin;
            }
            if (obj == null) {
                i8 = Math.min(width, height);
            }
            max = i4;
        }
        addCustomViewsWithGravity(r0.mTempViews, 3);
        layoutDirection = r0.mTempViews.size();
        for (width = 0; width < layoutDirection; width++) {
            max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, i2);
        }
        currentContentInsetStart = i2;
        addCustomViewsWithGravity(r0.mTempViews, 5);
        layoutDirection = r0.mTempViews.size();
        for (width = 0; width < layoutDirection; width++) {
            i8 = layoutChildRight((View) r0.mTempViews.get(width), i8, iArr, currentContentInsetStart);
        }
        addCustomViewsWithGravity(r0.mTempViews, 1);
        list = r0.mTempViews;
        paddingLeft = iArr[0];
        width = iArr[1];
        height = list.size();
        paddingRight = 0;
        paddingTop = 0;
        while (paddingRight < height) {
            view = (View) list.get(paddingRight);
            layoutParams2 = (LayoutParams) view.getLayoutParams();
            i5 = layoutParams2.leftMargin - paddingLeft;
            paddingLeft = layoutParams2.rightMargin - width;
            minimumHeight = Math.max(0, i5);
            layoutChildRight = Math.max(0, paddingLeft);
            i5 = Math.max(0, -i5);
            paddingTop += (minimumHeight + view.getMeasuredWidth()) + layoutChildRight;
            paddingRight++;
            width = Math.max(0, -paddingLeft);
            paddingLeft = i5;
        }
        paddingLeft = (i7 + (((i6 - i7) - i3) / 2)) - (paddingTop / 2);
        paddingTop += paddingLeft;
        if (paddingLeft < max) {
            if (paddingTop <= i8) {
            }
        }
        layoutDirection = r0.mTempViews.size();
        for (width = 0; width < layoutDirection; width++) {
            max = layoutChildLeft((View) r0.mTempViews.get(width), max, iArr, currentContentInsetStart);
        }
        r0.mTempViews.clear();
    }

    protected final void onMeasure(int i, int i2) {
        int measuredWidth;
        int max;
        int combineMeasuredStates;
        int i3;
        int combineMeasuredStates2;
        int[] iArr = this.mTempMargins;
        boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
        int i4 = isLayoutRtl ^ 1;
        int i5 = 0;
        if (shouldLayout(this.mNavButtonView)) {
            measureChildConstrained$ar$ds(r7.mNavButtonView, i, 0, i2, r7.mMaxButtonHeight);
            measuredWidth = r7.mNavButtonView.getMeasuredWidth() + Toolbar.getHorizontalMargins$ar$ds(r7.mNavButtonView);
            max = Math.max(0, r7.mNavButtonView.getMeasuredHeight() + Toolbar.getVerticalMargins$ar$ds(r7.mNavButtonView));
            combineMeasuredStates = View.combineMeasuredStates(0, r7.mNavButtonView.getMeasuredState());
        } else {
            measuredWidth = 0;
            max = 0;
            combineMeasuredStates = 0;
        }
        if (shouldLayout(r7.mCollapseButtonView)) {
            measureChildConstrained$ar$ds(r7.mCollapseButtonView, i, 0, i2, r7.mMaxButtonHeight);
            measuredWidth = r7.mCollapseButtonView.getMeasuredWidth() + Toolbar.getHorizontalMargins$ar$ds(r7.mCollapseButtonView);
            max = Math.max(max, r7.mCollapseButtonView.getMeasuredHeight() + Toolbar.getVerticalMargins$ar$ds(r7.mCollapseButtonView));
            combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, r7.mCollapseButtonView.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max2 = Math.max(currentContentInsetStart, measuredWidth);
        iArr[isLayoutRtl] = Math.max(0, currentContentInsetStart - measuredWidth);
        if (shouldLayout(r7.mMenuView)) {
            measureChildConstrained$ar$ds(r7.mMenuView, i, max2, i2, r7.mMaxButtonHeight);
            measuredWidth = r7.mMenuView.getMeasuredWidth() + Toolbar.getHorizontalMargins$ar$ds(r7.mMenuView);
            max = Math.max(max, r7.mMenuView.getMeasuredHeight() + Toolbar.getVerticalMargins$ar$ds(r7.mMenuView));
            combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, r7.mMenuView.getMeasuredState());
        } else {
            measuredWidth = 0;
        }
        currentContentInsetStart = getCurrentContentInsetEnd();
        max2 += Math.max(currentContentInsetStart, measuredWidth);
        iArr[i4] = Math.max(0, currentContentInsetStart - measuredWidth);
        if (shouldLayout(r7.mExpandedActionView)) {
            max2 += measureChildCollapseMargins(r7.mExpandedActionView, i, max2, i2, 0, iArr);
            max = Math.max(max, r7.mExpandedActionView.getMeasuredHeight() + Toolbar.getVerticalMargins$ar$ds(r7.mExpandedActionView));
            combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, r7.mExpandedActionView.getMeasuredState());
        }
        if (shouldLayout(r7.mLogoView)) {
            max2 += measureChildCollapseMargins(r7.mLogoView, i, max2, i2, 0, iArr);
            max = Math.max(max, r7.mLogoView.getMeasuredHeight() + Toolbar.getVerticalMargins$ar$ds(r7.mLogoView));
            combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, r7.mLogoView.getMeasuredState());
        }
        i4 = getChildCount();
        for (i3 = 0; i3 < i4; i3++) {
            View childAt = getChildAt(i3);
            if (((LayoutParams) childAt.getLayoutParams()).mViewType == 0) {
                if (shouldLayout(childAt)) {
                    max2 += measureChildCollapseMargins(childAt, i, max2, i2, 0, iArr);
                    max = Math.max(max, childAt.getMeasuredHeight() + Toolbar.getVerticalMargins$ar$ds(childAt));
                    combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, childAt.getMeasuredState());
                }
            }
        }
        i4 = r7.mTitleMarginTop + r7.mTitleMarginBottom;
        i3 = r7.mTitleMarginStart + r7.mTitleMarginEnd;
        if (shouldLayout(r7.mTitleTextView)) {
            measureChildCollapseMargins(r7.mTitleTextView, i, max2 + i3, i2, i4, iArr);
            i5 = r7.mTitleTextView.getMeasuredWidth() + Toolbar.getHorizontalMargins$ar$ds(r7.mTitleTextView);
            measuredWidth = r7.mTitleTextView.getMeasuredHeight() + Toolbar.getVerticalMargins$ar$ds(r7.mTitleTextView);
            combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, r7.mTitleTextView.getMeasuredState());
            combineMeasuredStates = measuredWidth;
        } else {
            combineMeasuredStates2 = combineMeasuredStates;
            combineMeasuredStates = 0;
        }
        if (shouldLayout(r7.mSubtitleTextView)) {
            i5 = Math.max(i5, measureChildCollapseMargins(r7.mSubtitleTextView, i, max2 + i3, i2, combineMeasuredStates + i4, iArr));
            combineMeasuredStates += r7.mSubtitleTextView.getMeasuredHeight() + Toolbar.getVerticalMargins$ar$ds(r7.mSubtitleTextView);
            combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates2, r7.mSubtitleTextView.getMeasuredState());
        }
        measuredWidth = Math.max(max, combineMeasuredStates);
        int i6 = i;
        int i7 = i2;
        setMeasuredDimension(View.resolveSizeAndState(Math.max((max2 + i5) + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i6, -16777216 & combineMeasuredStates2), View.resolveSizeAndState(Math.max(measuredWidth + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i7, combineMeasuredStates2 << 16));
    }

    protected final void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            Menu menu;
            SavedState savedState = (SavedState) parcelable;
            super.onRestoreInstanceState(savedState.mSuperState);
            ActionMenuView actionMenuView = this.mMenuView;
            if (actionMenuView != null) {
                menu = actionMenuView.mMenu;
            } else {
                menu = null;
            }
            int i = savedState.expandedMenuItemId;
            if (!(i == 0 || this.mExpandedMenuPresenter == null || menu == null)) {
                MenuItem findItem = menu.findItem(i);
                if (findItem != null) {
                    findItem.expandActionView();
                }
            }
            if (savedState.isOverflowOpen) {
                removeCallbacks(this.mShowOverflowMenuRunnable);
                post(this.mShowOverflowMenuRunnable);
            }
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        ensureContentInsets();
        RtlSpacingHelper rtlSpacingHelper = this.mContentInsets;
        boolean z = true;
        if (i != 1) {
            z = false;
        }
        if (z != rtlSpacingHelper.mIsRtl) {
            rtlSpacingHelper.mIsRtl = z;
            if (!rtlSpacingHelper.mIsRelative) {
                rtlSpacingHelper.mLeft = rtlSpacingHelper.mExplicitLeft;
                rtlSpacingHelper.mRight = rtlSpacingHelper.mExplicitRight;
            } else if (z) {
                r1 = rtlSpacingHelper.mEnd;
                if (r1 == LinearLayoutManager.INVALID_OFFSET) {
                    r1 = rtlSpacingHelper.mExplicitLeft;
                }
                rtlSpacingHelper.mLeft = r1;
                r1 = rtlSpacingHelper.mStart;
                if (r1 == LinearLayoutManager.INVALID_OFFSET) {
                    r1 = rtlSpacingHelper.mExplicitRight;
                }
                rtlSpacingHelper.mRight = r1;
            } else {
                r1 = rtlSpacingHelper.mStart;
                if (r1 == LinearLayoutManager.INVALID_OFFSET) {
                    r1 = rtlSpacingHelper.mExplicitLeft;
                }
                rtlSpacingHelper.mLeft = r1;
                r1 = rtlSpacingHelper.mEnd;
                if (r1 == LinearLayoutManager.INVALID_OFFSET) {
                    r1 = rtlSpacingHelper.mExplicitRight;
                }
                rtlSpacingHelper.mRight = r1;
            }
        }
    }

    protected final Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        ExpandedActionViewMenuPresenter expandedActionViewMenuPresenter = this.mExpandedMenuPresenter;
        if (expandedActionViewMenuPresenter != null) {
            MenuItemImpl menuItemImpl = expandedActionViewMenuPresenter.mCurrentExpandedItem;
            if (menuItemImpl != null) {
                savedState.expandedMenuItemId = menuItemImpl.mId;
            }
        }
        savedState.isOverflowOpen = isOverflowMenuShowing();
        return savedState;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.mEatingTouch = false;
            actionMasked = 0;
        }
        if (!this.mEatingTouch) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0) {
                if (!onTouchEvent) {
                    this.mEatingTouch = true;
                }
                actionMasked = 0;
                if (actionMasked == 1 || actionMasked == 3) {
                    this.mEatingTouch = false;
                }
                return true;
            }
        }
        this.mEatingTouch = false;
        return true;
    }

    public final void setLogo(Drawable drawable) {
        if (drawable != null) {
            ensureLogoView();
            if (!isChildOrHidden(this.mLogoView)) {
                addSystemView(this.mLogoView, true);
            }
        } else {
            View view = this.mLogoView;
            if (view != null && isChildOrHidden(view)) {
                removeView(this.mLogoView);
                this.mHiddenViews.remove(this.mLogoView);
            }
        }
        ImageView imageView = this.mLogoView;
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public final void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            ensureNavButtonView();
        }
        ImageButton imageButton = this.mNavButtonView;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public final void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            ensureNavButtonView();
            if (!isChildOrHidden(this.mNavButtonView)) {
                addSystemView(this.mNavButtonView, true);
            }
        } else {
            View view = this.mNavButtonView;
            if (view != null && isChildOrHidden(view)) {
                removeView(this.mNavButtonView);
                this.mHiddenViews.remove(this.mNavButtonView);
            }
        }
        ImageButton imageButton = this.mNavButtonView;
        if (imageButton != null) {
            imageButton.setImageDrawable(drawable);
        }
    }

    public final void setPopupTheme(int i) {
        if (this.mPopupTheme != i) {
            this.mPopupTheme = i;
            if (i == 0) {
                this.mPopupContext = getContext();
                return;
            }
            this.mPopupContext = new ContextThemeWrapper(getContext(), i);
        }
    }

    public final void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            View view = this.mSubtitleTextView;
            if (view != null && isChildOrHidden(view)) {
                removeView(this.mSubtitleTextView);
                this.mHiddenViews.remove(this.mSubtitleTextView);
            }
        } else {
            if (this.mSubtitleTextView == null) {
                Context context = getContext();
                TextView appCompatTextView = new AppCompatTextView(context);
                this.mSubtitleTextView = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.mSubtitleTextView.setEllipsize(TruncateAt.END);
                int i = this.mSubtitleTextAppearance;
                if (i != 0) {
                    this.mSubtitleTextView.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.mSubtitleTextColor;
                if (colorStateList != null) {
                    this.mSubtitleTextView.setTextColor(colorStateList);
                }
            }
            if (!isChildOrHidden(this.mSubtitleTextView)) {
                addSystemView(this.mSubtitleTextView, true);
            }
        }
        TextView textView = this.mSubtitleTextView;
        if (textView != null) {
            textView.setText(charSequence);
        }
        this.mSubtitleText = charSequence;
    }

    public final void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            View view = this.mTitleTextView;
            if (view != null && isChildOrHidden(view)) {
                removeView(this.mTitleTextView);
                this.mHiddenViews.remove(this.mTitleTextView);
            }
        } else {
            if (this.mTitleTextView == null) {
                Context context = getContext();
                TextView appCompatTextView = new AppCompatTextView(context);
                this.mTitleTextView = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.mTitleTextView.setEllipsize(TruncateAt.END);
                int i = this.mTitleTextAppearance;
                if (i != 0) {
                    this.mTitleTextView.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.mTitleTextColor;
                if (colorStateList != null) {
                    this.mTitleTextView.setTextColor(colorStateList);
                }
            }
            if (!isChildOrHidden(this.mTitleTextView)) {
                addSystemView(this.mTitleTextView, true);
            }
        }
        TextView textView = this.mTitleTextView;
        if (textView != null) {
            textView.setText(charSequence);
        }
        this.mTitleText = charSequence;
    }

    public final boolean showOverflowMenu() {
        ActionMenuView actionMenuView = this.mMenuView;
        if (actionMenuView != null) {
            ActionMenuPresenter actionMenuPresenter = actionMenuView.mPresenter;
            if (actionMenuPresenter != null && actionMenuPresenter.showOverflowMenu()) {
                return true;
            }
        }
        return false;
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.toolbarStyle);
    }

    public final boolean isOverflowMenuShowing() {
        ActionMenuView actionMenuView = this.mMenuView;
        if (actionMenuView != null) {
            ActionMenuPresenter actionMenuPresenter = actionMenuView.mPresenter;
            if (actionMenuPresenter != null && actionMenuPresenter.isOverflowMenuShowing()) {
                return true;
            }
        }
        return false;
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        ColorStateList colorStateList;
        TextView textView;
        super(context, attributeSet, i);
        this.mGravity = 8388627;
        this.mTempViews = new ArrayList();
        this.mHiddenViews = new ArrayList();
        this.mTempMargins = new int[2];
        this.mMenuViewItemClickListener$ar$class_merging = new PG();
        this.mShowOverflowMenuRunnable = new C01122();
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(getContext(), attributeSet, R$styleable.Toolbar, i);
        ViewCompat.saveAttributeDataForStyleable(this, context, R$styleable.Toolbar, attributeSet, obtainStyledAttributes$ar$ds.mWrapped, i, 0);
        this.mTitleTextAppearance = obtainStyledAttributes$ar$ds.getResourceId(28, 0);
        this.mSubtitleTextAppearance = obtainStyledAttributes$ar$ds.getResourceId(19, 0);
        this.mGravity = obtainStyledAttributes$ar$ds.getInteger(0, this.mGravity);
        this.mButtonGravity = obtainStyledAttributes$ar$ds.getInteger(2, 48);
        int dimensionPixelOffset = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(22, 0);
        if (obtainStyledAttributes$ar$ds.hasValue(27)) {
            dimensionPixelOffset = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(27, dimensionPixelOffset);
        }
        this.mTitleMarginBottom = dimensionPixelOffset;
        this.mTitleMarginTop = dimensionPixelOffset;
        this.mTitleMarginEnd = dimensionPixelOffset;
        this.mTitleMarginStart = dimensionPixelOffset;
        dimensionPixelOffset = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset >= 0) {
            this.mTitleMarginStart = dimensionPixelOffset;
        }
        dimensionPixelOffset = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset >= 0) {
            this.mTitleMarginEnd = dimensionPixelOffset;
        }
        dimensionPixelOffset = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset >= 0) {
            this.mTitleMarginTop = dimensionPixelOffset;
        }
        dimensionPixelOffset = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset >= 0) {
            this.mTitleMarginBottom = dimensionPixelOffset;
        }
        this.mMaxButtonHeight = obtainStyledAttributes$ar$ds.getDimensionPixelSize(13, -1);
        dimensionPixelOffset = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(9, LinearLayoutManager.INVALID_OFFSET);
        int dimensionPixelOffset2 = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(5, LinearLayoutManager.INVALID_OFFSET);
        int dimensionPixelSize = obtainStyledAttributes$ar$ds.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = obtainStyledAttributes$ar$ds.getDimensionPixelSize(8, 0);
        ensureContentInsets();
        RtlSpacingHelper rtlSpacingHelper = this.mContentInsets;
        rtlSpacingHelper.mIsRelative = false;
        if (dimensionPixelSize != LinearLayoutManager.INVALID_OFFSET) {
            rtlSpacingHelper.mExplicitLeft = dimensionPixelSize;
            rtlSpacingHelper.mLeft = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != LinearLayoutManager.INVALID_OFFSET) {
            rtlSpacingHelper.mExplicitRight = dimensionPixelSize2;
            rtlSpacingHelper.mRight = dimensionPixelSize2;
        }
        if (!(dimensionPixelOffset == LinearLayoutManager.INVALID_OFFSET && dimensionPixelOffset2 == LinearLayoutManager.INVALID_OFFSET)) {
            rtlSpacingHelper.setRelative(dimensionPixelOffset, dimensionPixelOffset2);
        }
        this.mContentInsetStartWithNavigation = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(10, LinearLayoutManager.INVALID_OFFSET);
        this.mContentInsetEndWithActions = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(6, LinearLayoutManager.INVALID_OFFSET);
        this.mCollapseIcon = obtainStyledAttributes$ar$ds.getDrawable(4);
        this.mCollapseDescription = obtainStyledAttributes$ar$ds.getText(3);
        CharSequence text = obtainStyledAttributes$ar$ds.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        text = obtainStyledAttributes$ar$ds.getText(18);
        if (!TextUtils.isEmpty(text)) {
            setSubtitle(text);
        }
        this.mPopupContext = getContext();
        setPopupTheme(obtainStyledAttributes$ar$ds.getResourceId(17, 0));
        Drawable drawable = obtainStyledAttributes$ar$ds.getDrawable(16);
        if (drawable != null) {
            setNavigationIcon(drawable);
        }
        text = obtainStyledAttributes$ar$ds.getText(15);
        if (!TextUtils.isEmpty(text)) {
            setNavigationContentDescription(text);
        }
        drawable = obtainStyledAttributes$ar$ds.getDrawable(11);
        if (drawable != null) {
            setLogo(drawable);
        }
        text = obtainStyledAttributes$ar$ds.getText(12);
        if (!TextUtils.isEmpty(text)) {
            if (!TextUtils.isEmpty(text)) {
                ensureLogoView();
            }
            ImageView imageView = this.mLogoView;
            if (imageView != null) {
                imageView.setContentDescription(text);
            }
        }
        if (obtainStyledAttributes$ar$ds.hasValue(29)) {
            colorStateList = obtainStyledAttributes$ar$ds.getColorStateList(29);
            this.mTitleTextColor = colorStateList;
            textView = this.mTitleTextView;
            if (textView != null) {
                textView.setTextColor(colorStateList);
            }
        }
        if (obtainStyledAttributes$ar$ds.hasValue(20)) {
            colorStateList = obtainStyledAttributes$ar$ds.getColorStateList(20);
            this.mSubtitleTextColor = colorStateList;
            textView = this.mSubtitleTextView;
            if (textView != null) {
                textView.setTextColor(colorStateList);
            }
        }
        if (obtainStyledAttributes$ar$ds.hasValue(14)) {
            dimensionPixelOffset = obtainStyledAttributes$ar$ds.getResourceId(14, 0);
            MenuInflater supportMenuInflater = new SupportMenuInflater(getContext());
            ensureMenuView();
            ActionMenuView actionMenuView = this.mMenuView;
            if (actionMenuView.mMenu == null) {
                Menu menu = actionMenuView.getMenu();
                if (this.mExpandedMenuPresenter == null) {
                    this.mExpandedMenuPresenter = new ExpandedActionViewMenuPresenter();
                }
                this.mMenuView.mPresenter.setExpandedActionViewsExclusive$ar$ds();
                ((MenuBuilder) menu).addMenuPresenter(this.mExpandedMenuPresenter, this.mPopupContext);
            }
            supportMenuInflater.inflate(dimensionPixelOffset, this.mMenuView.getMenu());
        }
        obtainStyledAttributes$ar$ds.recycle();
    }
}
