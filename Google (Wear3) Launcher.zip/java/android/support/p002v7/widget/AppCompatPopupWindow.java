package android.support.p002v7.widget;

import android.content.Context;
import android.support.p000v4.widget.PopupWindowCompat$Api23Impl;
import android.support.p002v7.appcompat.R$styleable;
import android.util.AttributeSet;
import android.widget.PopupWindow;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatPopupWindow */
final class AppCompatPopupWindow extends PopupWindow {
    public AppCompatPopupWindow(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i, 0);
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(context, attributeSet, R$styleable.PopupWindow, i);
        if (obtainStyledAttributes$ar$ds.hasValue(2)) {
            PopupWindowCompat$Api23Impl.setOverlapAnchor(this, obtainStyledAttributes$ar$ds.getBoolean(2, false));
        }
        setBackgroundDrawable(obtainStyledAttributes$ar$ds.getDrawable(0));
        obtainStyledAttributes$ar$ds.recycle();
    }
}
