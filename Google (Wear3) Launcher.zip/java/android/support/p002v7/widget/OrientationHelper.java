package android.support.p002v7.widget;

import android.graphics.Rect;
import android.support.p002v7.widget.RecyclerView.LayoutManager;
import android.support.p002v7.widget.RecyclerView.LayoutParams;
import android.support.v7.widget.OrientationHelper.C01042;
import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.OrientationHelper */
public abstract class OrientationHelper {
    public int mLastTotalSpace = LinearLayoutManager.INVALID_OFFSET;
    protected final LayoutManager mLayoutManager;
    final Rect mTmpRect = new Rect();

    /* renamed from: android.support.v7.widget.OrientationHelper$1 */
    final class PG extends OrientationHelper {
        public final int getDecoratedEnd(View view) {
            return this.mLayoutManager.getDecoratedRight(view) + ((LayoutParams) view.getLayoutParams()).rightMargin;
        }

        public final int getDecoratedMeasurement(View view) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            return (this.mLayoutManager.getDecoratedMeasuredWidth(view) + layoutParams.leftMargin) + layoutParams.rightMargin;
        }

        public final int getDecoratedMeasurementInOther(View view) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            return (this.mLayoutManager.getDecoratedMeasuredHeight(view) + layoutParams.topMargin) + layoutParams.bottomMargin;
        }

        public final int getDecoratedStart(View view) {
            return this.mLayoutManager.getDecoratedLeft(view) - ((LayoutParams) view.getLayoutParams()).leftMargin;
        }

        public final int getEnd() {
            return this.mLayoutManager.getWidth();
        }

        public final int getEndAfterPadding() {
            return this.mLayoutManager.getWidth() - this.mLayoutManager.getPaddingRight();
        }

        public final int getEndPadding() {
            return this.mLayoutManager.getPaddingRight();
        }

        public final int getMode() {
            return this.mLayoutManager.getWidthMode();
        }

        public final int getModeInOther() {
            return this.mLayoutManager.getHeightMode();
        }

        public final int getStartAfterPadding() {
            return this.mLayoutManager.getPaddingLeft();
        }

        public final int getTotalSpace() {
            return (this.mLayoutManager.getWidth() - this.mLayoutManager.getPaddingLeft()) - this.mLayoutManager.getPaddingRight();
        }

        public final int getTransformedEndWithDecoration(View view) {
            this.mLayoutManager.getTransformedBoundingBox(view, true, this.mTmpRect);
            return this.mTmpRect.right;
        }

        public final int getTransformedStartWithDecoration(View view) {
            this.mLayoutManager.getTransformedBoundingBox(view, true, this.mTmpRect);
            return this.mTmpRect.left;
        }

        public final void offsetChildren(int i) {
            this.mLayoutManager.offsetChildrenHorizontal(i);
        }

        public PG(LayoutManager layoutManager) {
            super(layoutManager);
        }
    }

    /* renamed from: android.support.v7.widget.OrientationHelper$2 */
    final class C01042 extends android.support.p002v7.widget.OrientationHelper {
        public final int getDecoratedEnd(View view) {
            return this.mLayoutManager.getDecoratedBottom(view) + ((LayoutParams) view.getLayoutParams()).bottomMargin;
        }

        public final int getDecoratedMeasurement(View view) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            return (this.mLayoutManager.getDecoratedMeasuredHeight(view) + layoutParams.topMargin) + layoutParams.bottomMargin;
        }

        public final int getDecoratedMeasurementInOther(View view) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            return (this.mLayoutManager.getDecoratedMeasuredWidth(view) + layoutParams.leftMargin) + layoutParams.rightMargin;
        }

        public final int getDecoratedStart(View view) {
            return this.mLayoutManager.getDecoratedTop(view) - ((LayoutParams) view.getLayoutParams()).topMargin;
        }

        public final int getEnd() {
            return this.mLayoutManager.getHeight();
        }

        public final int getEndAfterPadding() {
            return this.mLayoutManager.getHeight() - this.mLayoutManager.getPaddingBottom();
        }

        public final int getEndPadding() {
            return this.mLayoutManager.getPaddingBottom();
        }

        public final int getMode() {
            return this.mLayoutManager.getHeightMode();
        }

        public final int getModeInOther() {
            return this.mLayoutManager.getWidthMode();
        }

        public final int getStartAfterPadding() {
            return this.mLayoutManager.getPaddingTop();
        }

        public final int getTotalSpace() {
            return (this.mLayoutManager.getHeight() - this.mLayoutManager.getPaddingTop()) - this.mLayoutManager.getPaddingBottom();
        }

        public final int getTransformedEndWithDecoration(View view) {
            this.mLayoutManager.getTransformedBoundingBox(view, true, this.mTmpRect);
            return this.mTmpRect.bottom;
        }

        public final int getTransformedStartWithDecoration(View view) {
            this.mLayoutManager.getTransformedBoundingBox(view, true, this.mTmpRect);
            return this.mTmpRect.top;
        }

        public final void offsetChildren(int i) {
            this.mLayoutManager.offsetChildrenVertical(i);
        }

        public C01042(LayoutManager layoutManager) {
            super(layoutManager);
        }
    }

    public OrientationHelper(LayoutManager layoutManager) {
        this.mLayoutManager = layoutManager;
    }

    public static OrientationHelper createHorizontalHelper(LayoutManager layoutManager) {
        return new PG(layoutManager);
    }

    public static OrientationHelper createOrientationHelper(LayoutManager layoutManager, int i) {
        switch (i) {
            case 0:
                return OrientationHelper.createHorizontalHelper(layoutManager);
            default:
                return OrientationHelper.createVerticalHelper(layoutManager);
        }
    }

    public static OrientationHelper createVerticalHelper(LayoutManager layoutManager) {
        return new C01042(layoutManager);
    }

    public abstract int getDecoratedEnd(View view);

    public abstract int getDecoratedMeasurement(View view);

    public abstract int getDecoratedMeasurementInOther(View view);

    public abstract int getDecoratedStart(View view);

    public abstract int getEnd();

    public abstract int getEndAfterPadding();

    public abstract int getEndPadding();

    public abstract int getMode();

    public abstract int getModeInOther();

    public abstract int getStartAfterPadding();

    public abstract int getTotalSpace();

    public final int getTotalSpaceChange() {
        return this.mLastTotalSpace == LinearLayoutManager.INVALID_OFFSET ? 0 : getTotalSpace() - this.mLastTotalSpace;
    }

    public abstract int getTransformedEndWithDecoration(View view);

    public abstract int getTransformedStartWithDecoration(View view);

    public abstract void offsetChildren(int i);
}
