package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.LinearLayoutCompat */
public class LinearLayoutCompat extends ViewGroup {
    private boolean mBaselineAligned;
    private int mBaselineAlignedChildIndex;
    private int mBaselineChildTop;
    public Drawable mDivider;
    private int mDividerHeight;
    private int mDividerPadding;
    public int mDividerWidth;
    public int mGravity;
    private int[] mMaxAscent;
    private int[] mMaxDescent;
    private int mOrientation;
    private int mShowDividers;
    private int mTotalLength;
    private boolean mUseLargestChild;
    private float mWeightSum;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.LinearLayoutCompat$LayoutParams */
    public class LayoutParams extends android.widget.LinearLayout.LayoutParams {
        public LayoutParams(int i) {
            super(i, -2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public LinearLayoutCompat(Context context) {
        this(context, null);
    }

    private static void setChildFrame$ar$ds(View view, int i, int i2, int i3, int i4) {
        view.layout(i, i2, i3 + i, i4 + i2);
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    final void drawHorizontalDivider(Canvas canvas, int i) {
        this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, i, (getWidth() - getPaddingRight()) - this.mDividerPadding, this.mDividerHeight + i);
        this.mDivider.draw(canvas);
    }

    final void drawVerticalDivider(Canvas canvas, int i) {
        this.mDivider.setBounds(i, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + i, (getHeight() - getPaddingBottom()) - this.mDividerPadding);
        this.mDivider.draw(canvas);
    }

    protected LayoutParams generateDefaultLayoutParams() {
        int i = this.mOrientation;
        if (i == 0) {
            return new LayoutParams(-2);
        }
        return i == 1 ? new LayoutParams(-1) : null;
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public final int getBaseline() {
        if (this.mBaselineAlignedChildIndex < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i = this.mBaselineAlignedChildIndex;
        if (childCount > i) {
            View childAt = getChildAt(i);
            i = childAt.getBaseline();
            if (i != -1) {
                int i2 = this.mBaselineChildTop;
                if (this.mOrientation == 1) {
                    int i3 = this.mGravity & 112;
                    if (i3 != 48) {
                        switch (i3) {
                            case 16:
                                i2 += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.mTotalLength) / 2;
                                break;
                            case 80:
                                i2 = ((getBottom() - getTop()) - getPaddingBottom()) - this.mTotalLength;
                                break;
                            default:
                                break;
                        }
                    }
                }
                return (i2 + ((LayoutParams) childAt.getLayoutParams()).topMargin) + i;
            } else if (this.mBaselineAlignedChildIndex == 0) {
                return -1;
            } else {
                throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
        }
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
    }

    protected final boolean hasDividerBeforeChildAt(int i) {
        boolean z = false;
        if (i == 0) {
            return (this.mShowDividers & 1) != 0;
        } else {
            if (i == getChildCount()) {
                return (this.mShowDividers & 4) != 0;
            } else {
                if ((this.mShowDividers & 2) != 0) {
                    for (i--; i >= 0; i--) {
                        if (getChildAt(i).getVisibility() != 8) {
                            z = true;
                            break;
                        }
                    }
                }
                return z;
            }
        }
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.support.v7.widget.LinearLayoutCompat");
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.support.v7.widget.LinearLayoutCompat");
    }

    public final void setBaselineAligned$ar$ds() {
        this.mBaselineAligned = false;
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        boolean z = true;
        this.mBaselineAligned = true;
        this.mBaselineAlignedChildIndex = -1;
        this.mBaselineChildTop = 0;
        this.mGravity = 8388659;
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(context, attributeSet, R$styleable.LinearLayoutCompat, i);
        ViewCompat.saveAttributeDataForStyleable(this, context, R$styleable.LinearLayoutCompat, attributeSet, obtainStyledAttributes$ar$ds.mWrapped, i, 0);
        int i2 = obtainStyledAttributes$ar$ds.getInt(1, -1);
        if (i2 >= 0 && this.mOrientation != i2) {
            this.mOrientation = i2;
            requestLayout();
        }
        i2 = obtainStyledAttributes$ar$ds.getInt(0, -1);
        if (i2 >= 0 && this.mGravity != i2) {
            if ((8388615 & i2) == 0) {
                i2 |= 8388611;
            }
            if ((i2 & 112) == 0) {
                i2 |= 48;
            }
            this.mGravity = i2;
            requestLayout();
        }
        if (!obtainStyledAttributes$ar$ds.getBoolean(2, true)) {
            setBaselineAligned$ar$ds();
        }
        this.mWeightSum = obtainStyledAttributes$ar$ds.mWrapped.getFloat(4, -1.0f);
        this.mBaselineAlignedChildIndex = obtainStyledAttributes$ar$ds.getInt(3, -1);
        this.mUseLargestChild = obtainStyledAttributes$ar$ds.getBoolean(7, false);
        Drawable drawable = obtainStyledAttributes$ar$ds.getDrawable(5);
        if (drawable != this.mDivider) {
            this.mDivider = drawable;
            if (drawable != null) {
                this.mDividerWidth = drawable.getIntrinsicWidth();
                this.mDividerHeight = drawable.getIntrinsicHeight();
            } else {
                this.mDividerWidth = 0;
                this.mDividerHeight = 0;
            }
            if (drawable != null) {
                z = false;
            }
            setWillNotDraw(z);
            requestLayout();
        }
        this.mShowDividers = obtainStyledAttributes$ar$ds.getInt(8, 0);
        this.mDividerPadding = obtainStyledAttributes$ar$ds.getDimensionPixelSize(6, 0);
        obtainStyledAttributes$ar$ds.recycle();
    }

    protected final void onDraw(Canvas canvas) {
        if (this.mDivider != null) {
            int i = 0;
            int childCount;
            View childAt;
            if (this.mOrientation == 1) {
                childCount = getChildCount();
                while (i < childCount) {
                    View childAt2 = getChildAt(i);
                    if (!(childAt2 == null || childAt2.getVisibility() == 8 || !hasDividerBeforeChildAt(i))) {
                        drawHorizontalDivider(canvas, (childAt2.getTop() - ((LayoutParams) childAt2.getLayoutParams()).topMargin) - this.mDividerHeight);
                    }
                    i++;
                }
                if (hasDividerBeforeChildAt(childCount)) {
                    childAt = getChildAt(childCount - 1);
                    if (childAt == null) {
                        childCount = (getHeight() - getPaddingBottom()) - this.mDividerHeight;
                    } else {
                        childCount = childAt.getBottom() + ((LayoutParams) childAt.getLayoutParams()).bottomMargin;
                    }
                    drawHorizontalDivider(canvas, childCount);
                    return;
                }
            }
            childCount = getChildCount();
            boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
            while (i < childCount) {
                View childAt3 = getChildAt(i);
                if (!(childAt3 == null || childAt3.getVisibility() == 8 || !hasDividerBeforeChildAt(i))) {
                    int right;
                    LayoutParams layoutParams = (LayoutParams) childAt3.getLayoutParams();
                    if (isLayoutRtl) {
                        right = childAt3.getRight() + layoutParams.rightMargin;
                    } else {
                        right = (childAt3.getLeft() - layoutParams.leftMargin) - this.mDividerWidth;
                    }
                    drawVerticalDivider(canvas, right);
                }
                i++;
            }
            if (hasDividerBeforeChildAt(childCount)) {
                childAt = getChildAt(childCount - 1);
                if (childAt != null) {
                    LayoutParams layoutParams2 = (LayoutParams) childAt.getLayoutParams();
                    if (isLayoutRtl) {
                        childCount = (childAt.getLeft() - layoutParams2.leftMargin) - this.mDividerWidth;
                    } else {
                        childCount = childAt.getRight() + layoutParams2.rightMargin;
                    }
                } else if (isLayoutRtl) {
                    childCount = getPaddingLeft();
                } else {
                    childCount = (getWidth() - getPaddingRight()) - this.mDividerWidth;
                }
                drawVerticalDivider(canvas, childCount);
            }
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = 8;
        int paddingLeft;
        int i6;
        int paddingRight;
        int childCount;
        int i7;
        int i8;
        int measuredWidth;
        if (this.mOrientation == 1) {
            paddingLeft = getPaddingLeft();
            i6 = i3 - i;
            paddingRight = i6 - getPaddingRight();
            i6 = (i6 - paddingLeft) - getPaddingRight();
            childCount = getChildCount();
            i7 = r0.mGravity;
            i8 = 8388615 & i7;
            switch (i7 & 112) {
                case 16:
                    i7 = getPaddingTop() + (((i4 - i2) - r0.mTotalLength) / 2);
                    break;
                case 80:
                    i7 = ((getPaddingTop() + i4) - i2) - r0.mTotalLength;
                    break;
                default:
                    i7 = getPaddingTop();
                    break;
            }
            for (int i9 = 0; i9 < childCount; i9++) {
                View childAt = getChildAt(i9);
                if (childAt != null) {
                    if (childAt.getVisibility() != 8) {
                        measuredWidth = childAt.getMeasuredWidth();
                        int measuredHeight = childAt.getMeasuredHeight();
                        LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                        int i10 = layoutParams.gravity;
                        if (i10 < 0) {
                            i10 = i8;
                        }
                        switch (Gravity.getAbsoluteGravity(i10, ViewCompat.getLayoutDirection(this)) & 7) {
                            case 1:
                                i10 = ((((i6 - measuredWidth) / 2) + paddingLeft) + layoutParams.leftMargin) - layoutParams.rightMargin;
                                break;
                            case 5:
                                i10 = (paddingRight - measuredWidth) - layoutParams.rightMargin;
                                break;
                            default:
                                i10 = layoutParams.leftMargin + paddingLeft;
                                break;
                        }
                        if (hasDividerBeforeChildAt(i9)) {
                            i7 += r0.mDividerHeight;
                        }
                        i7 += layoutParams.topMargin;
                        LinearLayoutCompat.setChildFrame$ar$ds(childAt, i10, i7, measuredWidth, measuredHeight);
                        i7 += measuredHeight + layoutParams.bottomMargin;
                    }
                }
            }
            return;
        }
        boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
        paddingRight = getPaddingTop();
        childCount = i4 - i2;
        i7 = childCount - getPaddingBottom();
        childCount = (childCount - paddingRight) - getPaddingBottom();
        int childCount2 = getChildCount();
        measuredWidth = r0.mGravity;
        measuredHeight = measuredWidth & 112;
        boolean z2 = r0.mBaselineAligned;
        int[] iArr = r0.mMaxAscent;
        int[] iArr2 = r0.mMaxDescent;
        switch (Gravity.getAbsoluteGravity(8388615 & measuredWidth, ViewCompat.getLayoutDirection(this))) {
            case 1:
                i8 = getPaddingLeft() + (((i3 - i) - r0.mTotalLength) / 2);
                break;
            case 5:
                i8 = ((getPaddingLeft() + i3) - i) - r0.mTotalLength;
                break;
            default:
                i8 = getPaddingLeft();
                break;
        }
        if (isLayoutRtl) {
            paddingLeft = childCount2 - 1;
            measuredWidth = -1;
        } else {
            paddingLeft = 0;
            measuredWidth = 1;
        }
        i6 = 0;
        while (i6 < childCount2) {
            int i11;
            int i12;
            int i13 = paddingLeft + (measuredWidth * i6);
            View childAt2 = getChildAt(i13);
            if (childAt2 == null) {
                i2 = paddingLeft;
                i11 = i7;
                i4 = childCount2;
                i3 = measuredWidth;
                i12 = measuredHeight;
            } else {
                i2 = paddingLeft;
                if (childAt2.getVisibility() != i5) {
                    paddingLeft = childAt2.getMeasuredWidth();
                    i5 = childAt2.getMeasuredHeight();
                    i4 = childCount2;
                    LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                    if (z2) {
                        i3 = measuredWidth;
                        i12 = measuredHeight;
                        if (layoutParams2.height != -1) {
                            measuredHeight = childAt2.getBaseline();
                            measuredWidth = layoutParams2.gravity;
                            if (measuredWidth < 0) {
                                measuredWidth = i12;
                            }
                            switch (measuredWidth & 112) {
                                case 16:
                                    i11 = i7;
                                    measuredWidth = ((((childCount - i5) / 2) + paddingRight) + layoutParams2.topMargin) - layoutParams2.bottomMargin;
                                    break;
                                case 48:
                                    i11 = i7;
                                    measuredWidth = paddingRight + layoutParams2.topMargin;
                                    if (measuredHeight != -1) {
                                        measuredWidth += iArr[1] - measuredHeight;
                                    }
                                    break;
                                case 80:
                                    i11 = i7;
                                    measuredWidth = (i7 - i5) - layoutParams2.bottomMargin;
                                    if (measuredHeight != -1) {
                                        measuredWidth -= iArr2[2] - (childAt2.getMeasuredHeight() - measuredHeight);
                                    }
                                    break;
                                default:
                                    i11 = i7;
                                    measuredWidth = paddingRight;
                                    break;
                            }
                            if (hasDividerBeforeChildAt(i13)) {
                                i8 += r0.mDividerWidth;
                            }
                            i8 += layoutParams2.leftMargin;
                            LinearLayoutCompat.setChildFrame$ar$ds(childAt2, i8, measuredWidth, paddingLeft, i5);
                            i8 += paddingLeft + layoutParams2.rightMargin;
                        }
                    } else {
                        i3 = measuredWidth;
                        i12 = measuredHeight;
                    }
                    measuredHeight = -1;
                    measuredWidth = layoutParams2.gravity;
                    if (measuredWidth < 0) {
                        measuredWidth = i12;
                    }
                    switch (measuredWidth & 112) {
                        case 16:
                            i11 = i7;
                            measuredWidth = ((((childCount - i5) / 2) + paddingRight) + layoutParams2.topMargin) - layoutParams2.bottomMargin;
                            break;
                        case 48:
                            i11 = i7;
                            measuredWidth = paddingRight + layoutParams2.topMargin;
                            if (measuredHeight != -1) {
                                measuredWidth += iArr[1] - measuredHeight;
                            }
                            break;
                        case 80:
                            i11 = i7;
                            measuredWidth = (i7 - i5) - layoutParams2.bottomMargin;
                            if (measuredHeight != -1) {
                                measuredWidth -= iArr2[2] - (childAt2.getMeasuredHeight() - measuredHeight);
                            }
                            break;
                        default:
                            i11 = i7;
                            measuredWidth = paddingRight;
                            break;
                    }
                    if (hasDividerBeforeChildAt(i13)) {
                        i8 += r0.mDividerWidth;
                    }
                    i8 += layoutParams2.leftMargin;
                    LinearLayoutCompat.setChildFrame$ar$ds(childAt2, i8, measuredWidth, paddingLeft, i5);
                    i8 += paddingLeft + layoutParams2.rightMargin;
                } else {
                    i11 = i7;
                    i4 = childCount2;
                    i3 = measuredWidth;
                    i12 = measuredHeight;
                }
            }
            i6++;
            paddingLeft = i2;
            measuredWidth = i3;
            childCount2 = i4;
            measuredHeight = i12;
            i7 = i11;
            i5 = 8;
        }
    }

    protected void onMeasure(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        int i5 = -2;
        int i6 = 8;
        float f = 0.0f;
        int i7 = 1073741824;
        int childCount;
        int mode;
        int mode2;
        int i8;
        Object obj;
        int i9;
        int i10;
        LayoutParams layoutParams;
        int i11;
        int i12;
        int combineMeasuredStates;
        View childAt;
        LayoutParams layoutParams2;
        int i13;
        int i14;
        int i15;
        View childAt2;
        if (this.mOrientation == 1) {
            int i16;
            View childAt3;
            float f2;
            int i17;
            LayoutParams layoutParams3;
            int i18;
            Object obj2;
            r6.mTotalLength = 0;
            childCount = getChildCount();
            mode = MeasureSpec.getMode(i);
            mode2 = MeasureSpec.getMode(i2);
            i8 = r6.mBaselineAlignedChildIndex;
            boolean z = r6.mUseLargestChild;
            int i19 = 0;
            Object obj3 = 1;
            Object obj4 = null;
            obj = null;
            int i20 = 0;
            int i21 = 0;
            int i22 = 0;
            float f3 = 0.0f;
            i9 = 0;
            i10 = 0;
            while (i19 < childCount) {
                View childAt4 = getChildAt(i19);
                if (childAt4 != null) {
                    if (childAt4.getVisibility() != i6) {
                        int i23;
                        LayoutParams layoutParams4;
                        Object obj5;
                        if (hasDividerBeforeChildAt(i19)) {
                            r6.mTotalLength += r6.mDividerHeight;
                        }
                        layoutParams = (LayoutParams) childAt4.getLayoutParams();
                        f3 += layoutParams.weight;
                        if (mode2 == i7 && layoutParams.height == 0 && layoutParams.weight > f) {
                            i11 = r6.mTotalLength;
                            r6.mTotalLength = Math.max(i11, (layoutParams.topMargin + i11) + layoutParams.bottomMargin);
                            i5 = i8;
                            i12 = mode2;
                            i23 = mode;
                            i16 = childCount;
                            layoutParams4 = layoutParams;
                            obj = 1;
                        } else {
                            Object obj6;
                            if (layoutParams.height != 0 || layoutParams.weight <= f) {
                                obj6 = LinearLayoutManager.INVALID_OFFSET;
                            } else {
                                layoutParams.height = i5;
                                obj6 = null;
                            }
                            if (f3 == f) {
                                i7 = r6.mTotalLength;
                            } else {
                                i7 = 0;
                            }
                            i5 = i8;
                            i12 = mode2;
                            i23 = mode;
                            i16 = childCount;
                            layoutParams4 = layoutParams;
                            measureChildWithMargins(childAt4, i, 0, i2, i7);
                            if (obj6 != -2147483648) {
                                layoutParams4.height = 0;
                            }
                            i8 = childAt4.getMeasuredHeight();
                            mode2 = r6.mTotalLength;
                            r6.mTotalLength = Math.max(mode2, ((mode2 + i8) + layoutParams4.topMargin) + layoutParams4.bottomMargin);
                            if (z) {
                                i9 = Math.max(i8, i9);
                            } else {
                                i11 = i9;
                            }
                        }
                        if (i5 >= 0 && i5 == i19 + 1) {
                            r6.mBaselineChildTop = r6.mTotalLength;
                        }
                        if (i19 < i5) {
                            if (layoutParams4.weight > 0.0f) {
                                throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
                            }
                        }
                        i8 = i23;
                        if (i8 != 1073741824) {
                            i6 = -1;
                            if (layoutParams4.width == -1) {
                                i11 = 1;
                                obj4 = 1;
                                mode2 = layoutParams4.leftMargin + layoutParams4.rightMargin;
                                mode = childAt4.getMeasuredWidth() + mode2;
                                childCount = Math.max(i10, mode);
                                combineMeasuredStates = View.combineMeasuredStates(i20, childAt4.getMeasuredState());
                                if (obj3 == null && layoutParams4.width == r12) {
                                    obj5 = 1;
                                } else {
                                    obj5 = null;
                                }
                                if (layoutParams4.weight <= 0.0f) {
                                    if (1 != i11) {
                                        mode2 = mode;
                                    }
                                    i22 = Math.max(i22, mode2);
                                } else {
                                    i6 = i22;
                                    if (1 != i11) {
                                        mode2 = mode;
                                    }
                                    i21 = Math.max(i21, mode2);
                                    i22 = i6;
                                }
                                i10 = childCount;
                                i20 = combineMeasuredStates;
                                obj3 = obj5;
                                i19++;
                                mode = i8;
                                i8 = i5;
                                mode2 = i12;
                                childCount = i16;
                                i5 = -2;
                                i6 = 8;
                                f = 0.0f;
                                i7 = 1073741824;
                            }
                        } else {
                            i6 = -1;
                        }
                        i11 = 0;
                        mode2 = layoutParams4.leftMargin + layoutParams4.rightMargin;
                        mode = childAt4.getMeasuredWidth() + mode2;
                        childCount = Math.max(i10, mode);
                        combineMeasuredStates = View.combineMeasuredStates(i20, childAt4.getMeasuredState());
                        if (obj3 == null) {
                        }
                        obj5 = null;
                        if (layoutParams4.weight <= 0.0f) {
                            i6 = i22;
                            if (1 != i11) {
                                mode2 = mode;
                            }
                            i21 = Math.max(i21, mode2);
                            i22 = i6;
                        } else {
                            if (1 != i11) {
                                mode2 = mode;
                            }
                            i22 = Math.max(i22, mode2);
                        }
                        i10 = childCount;
                        i20 = combineMeasuredStates;
                        obj3 = obj5;
                        i19++;
                        mode = i8;
                        i8 = i5;
                        mode2 = i12;
                        childCount = i16;
                        i5 = -2;
                        i6 = 8;
                        f = 0.0f;
                        i7 = 1073741824;
                    }
                }
                i5 = i8;
                i12 = mode2;
                i8 = mode;
                i16 = childCount;
                i19++;
                mode = i8;
                i8 = i5;
                mode2 = i12;
                childCount = i16;
                i5 = -2;
                i6 = 8;
                f = 0.0f;
                i7 = 1073741824;
            }
            i12 = mode2;
            i8 = mode;
            i16 = childCount;
            i7 = i20;
            mode = i21;
            i6 = i22;
            i11 = i9;
            childCount = i10;
            if (r6.mTotalLength > 0) {
                i5 = i16;
                if (hasDividerBeforeChildAt(i5)) {
                    r6.mTotalLength += r6.mDividerHeight;
                }
            } else {
                i5 = i16;
            }
            if (z) {
                mode2 = i12;
                if (mode2 != Integer.MIN_VALUE) {
                    if (mode2 == 0) {
                        mode2 = 0;
                    }
                }
                r6.mTotalLength = 0;
                for (combineMeasuredStates = 0; combineMeasuredStates < i5; combineMeasuredStates++) {
                    childAt = getChildAt(combineMeasuredStates);
                    if (childAt != null) {
                        if (childAt.getVisibility() != 8) {
                            layoutParams2 = (LayoutParams) childAt.getLayoutParams();
                            i13 = r6.mTotalLength;
                            r6.mTotalLength = Math.max(i13, ((i13 + i11) + layoutParams2.topMargin) + layoutParams2.bottomMargin);
                        }
                    }
                }
                combineMeasuredStates = r6.mTotalLength + (getPaddingTop() + getPaddingBottom());
                r6.mTotalLength = combineMeasuredStates;
                combineMeasuredStates = View.resolveSizeAndState(Math.max(combineMeasuredStates, getSuggestedMinimumHeight()), i4, 0);
                i14 = (16777215 & combineMeasuredStates) - r6.mTotalLength;
                if (obj == null) {
                    if (i14 != 0 || f3 <= 0.0f) {
                        mode = Math.max(mode, i6);
                        if (z && r1 != 1073741824) {
                            for (mode2 = 0; mode2 < i5; mode2++) {
                                childAt3 = getChildAt(mode2);
                                if (childAt3 == null) {
                                    if (childAt3.getVisibility() == 8) {
                                        if (((LayoutParams) childAt3.getLayoutParams()).weight > 0.0f) {
                                            childAt3.measure(MeasureSpec.makeMeasureSpec(childAt3.getMeasuredWidth(), 1073741824), MeasureSpec.makeMeasureSpec(i11, 1073741824));
                                        }
                                    }
                                }
                            }
                        }
                        i10 = childCount;
                        if (obj3 == null || i8 == 1073741824) {
                            mode = i10;
                        }
                        setMeasuredDimension(View.resolveSizeAndState(Math.max(mode + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i3, i7), combineMeasuredStates);
                        if (obj4 == null) {
                            i3 = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
                            for (i15 = 0; i15 < i5; i15++) {
                                childAt2 = getChildAt(i15);
                                if (childAt2.getVisibility() == 8) {
                                    layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                                    if (layoutParams2.width != -1) {
                                        i6 = layoutParams2.height;
                                        layoutParams2.height = childAt2.getMeasuredHeight();
                                        measureChildWithMargins(childAt2, i3, 0, i2, 0);
                                        layoutParams2.height = i6;
                                    }
                                }
                            }
                            return;
                        }
                        return;
                    }
                }
                f2 = r6.mWeightSum;
                if (f2 <= 0.0f) {
                    f3 = f2;
                }
                r6.mTotalLength = 0;
                i11 = 0;
                while (i11 < i5) {
                    childAt3 = getChildAt(i11);
                    if (childAt3.getVisibility() != 8) {
                        i17 = mode2;
                    } else {
                        layoutParams3 = (LayoutParams) childAt3.getLayoutParams();
                        f = layoutParams3.weight;
                        if (f > 0.0f) {
                            i19 = (int) ((((float) i14) * f) / f3);
                            f3 -= f;
                            i17 = i14 - i19;
                            i14 = ViewGroup.getChildMeasureSpec(i3, ((getPaddingLeft() + getPaddingRight()) + layoutParams3.leftMargin) + layoutParams3.rightMargin, layoutParams3.width);
                            if (layoutParams3.height == 0) {
                                if (mode2 != 1073741824) {
                                    if (i19 > 0) {
                                        i19 = 0;
                                    }
                                    childAt3.measure(i14, MeasureSpec.makeMeasureSpec(i19, 1073741824));
                                    i7 = View.combineMeasuredStates(i7, childAt3.getMeasuredState() & -256);
                                    i14 = i17;
                                }
                            }
                            i13 = childAt3.getMeasuredHeight() + i19;
                            if (i13 < 0) {
                                i13 = 0;
                            }
                            childAt3.measure(i14, MeasureSpec.makeMeasureSpec(i13, 1073741824));
                            i7 = View.combineMeasuredStates(i7, childAt3.getMeasuredState() & -256);
                            i14 = i17;
                        }
                        i13 = layoutParams3.leftMargin + layoutParams3.rightMargin;
                        i19 = childAt3.getMeasuredWidth() + i13;
                        childCount = Math.max(childCount, i19);
                        i17 = mode2;
                        if (i8 == 1073741824) {
                            i18 = childCount;
                            if (layoutParams3.width == -1) {
                                mode2 = Math.max(mode, i13);
                                if (obj3 == null && layoutParams3.width == -1) {
                                    obj2 = 1;
                                } else {
                                    obj2 = null;
                                }
                                childCount = r6.mTotalLength;
                                r6.mTotalLength = Math.max(childCount, ((childAt3.getMeasuredHeight() + childCount) + layoutParams3.topMargin) + layoutParams3.bottomMargin);
                                obj3 = obj2;
                                childCount = i18;
                                mode = mode2;
                            }
                        } else {
                            i18 = childCount;
                        }
                        i13 = i19;
                        mode2 = Math.max(mode, i13);
                        if (obj3 == null) {
                        }
                        obj2 = null;
                        childCount = r6.mTotalLength;
                        r6.mTotalLength = Math.max(childCount, ((childAt3.getMeasuredHeight() + childCount) + layoutParams3.topMargin) + layoutParams3.bottomMargin);
                        obj3 = obj2;
                        childCount = i18;
                        mode = mode2;
                    }
                    i11++;
                    mode2 = i17;
                }
                r6.mTotalLength += getPaddingTop() + getPaddingBottom();
                i10 = childCount;
                if (obj3 == null) {
                }
                mode = i10;
                setMeasuredDimension(View.resolveSizeAndState(Math.max(mode + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i3, i7), combineMeasuredStates);
                if (obj4 == null) {
                    i3 = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
                    for (i15 = 0; i15 < i5; i15++) {
                        childAt2 = getChildAt(i15);
                        if (childAt2.getVisibility() == 8) {
                            layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                            if (layoutParams2.width != -1) {
                                i6 = layoutParams2.height;
                                layoutParams2.height = childAt2.getMeasuredHeight();
                                measureChildWithMargins(childAt2, i3, 0, i2, 0);
                                layoutParams2.height = i6;
                            }
                        }
                    }
                    return;
                }
                return;
            }
            mode2 = i12;
            combineMeasuredStates = r6.mTotalLength + (getPaddingTop() + getPaddingBottom());
            r6.mTotalLength = combineMeasuredStates;
            combineMeasuredStates = View.resolveSizeAndState(Math.max(combineMeasuredStates, getSuggestedMinimumHeight()), i4, 0);
            i14 = (16777215 & combineMeasuredStates) - r6.mTotalLength;
            if (obj == null) {
                if (i14 != 0) {
                }
                mode = Math.max(mode, i6);
                for (mode2 = 0; mode2 < i5; mode2++) {
                    childAt3 = getChildAt(mode2);
                    if (childAt3 == null) {
                        if (childAt3.getVisibility() == 8) {
                            if (((LayoutParams) childAt3.getLayoutParams()).weight > 0.0f) {
                                childAt3.measure(MeasureSpec.makeMeasureSpec(childAt3.getMeasuredWidth(), 1073741824), MeasureSpec.makeMeasureSpec(i11, 1073741824));
                            }
                        }
                    }
                }
                i10 = childCount;
                if (obj3 == null) {
                }
                mode = i10;
                setMeasuredDimension(View.resolveSizeAndState(Math.max(mode + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i3, i7), combineMeasuredStates);
                if (obj4 == null) {
                    i3 = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
                    for (i15 = 0; i15 < i5; i15++) {
                        childAt2 = getChildAt(i15);
                        if (childAt2.getVisibility() == 8) {
                            layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                            if (layoutParams2.width != -1) {
                                i6 = layoutParams2.height;
                                layoutParams2.height = childAt2.getMeasuredHeight();
                                measureChildWithMargins(childAt2, i3, 0, i2, 0);
                                layoutParams2.height = i6;
                            }
                        }
                    }
                    return;
                }
                return;
            }
            f2 = r6.mWeightSum;
            if (f2 <= 0.0f) {
                f3 = f2;
            }
            r6.mTotalLength = 0;
            i11 = 0;
            while (i11 < i5) {
                childAt3 = getChildAt(i11);
                if (childAt3.getVisibility() != 8) {
                    layoutParams3 = (LayoutParams) childAt3.getLayoutParams();
                    f = layoutParams3.weight;
                    if (f > 0.0f) {
                        i19 = (int) ((((float) i14) * f) / f3);
                        f3 -= f;
                        i17 = i14 - i19;
                        i14 = ViewGroup.getChildMeasureSpec(i3, ((getPaddingLeft() + getPaddingRight()) + layoutParams3.leftMargin) + layoutParams3.rightMargin, layoutParams3.width);
                        if (layoutParams3.height == 0) {
                            if (mode2 != 1073741824) {
                                if (i19 > 0) {
                                    i19 = 0;
                                }
                                childAt3.measure(i14, MeasureSpec.makeMeasureSpec(i19, 1073741824));
                                i7 = View.combineMeasuredStates(i7, childAt3.getMeasuredState() & -256);
                                i14 = i17;
                            }
                        }
                        i13 = childAt3.getMeasuredHeight() + i19;
                        if (i13 < 0) {
                            i13 = 0;
                        }
                        childAt3.measure(i14, MeasureSpec.makeMeasureSpec(i13, 1073741824));
                        i7 = View.combineMeasuredStates(i7, childAt3.getMeasuredState() & -256);
                        i14 = i17;
                    }
                    i13 = layoutParams3.leftMargin + layoutParams3.rightMargin;
                    i19 = childAt3.getMeasuredWidth() + i13;
                    childCount = Math.max(childCount, i19);
                    i17 = mode2;
                    if (i8 == 1073741824) {
                        i18 = childCount;
                    } else {
                        i18 = childCount;
                        if (layoutParams3.width == -1) {
                            mode2 = Math.max(mode, i13);
                            if (obj3 == null) {
                            }
                            obj2 = null;
                            childCount = r6.mTotalLength;
                            r6.mTotalLength = Math.max(childCount, ((childAt3.getMeasuredHeight() + childCount) + layoutParams3.topMargin) + layoutParams3.bottomMargin);
                            obj3 = obj2;
                            childCount = i18;
                            mode = mode2;
                        }
                    }
                    i13 = i19;
                    mode2 = Math.max(mode, i13);
                    if (obj3 == null) {
                    }
                    obj2 = null;
                    childCount = r6.mTotalLength;
                    r6.mTotalLength = Math.max(childCount, ((childAt3.getMeasuredHeight() + childCount) + layoutParams3.topMargin) + layoutParams3.bottomMargin);
                    obj3 = obj2;
                    childCount = i18;
                    mode = mode2;
                } else {
                    i17 = mode2;
                }
                i11++;
                mode2 = i17;
            }
            r6.mTotalLength += getPaddingTop() + getPaddingBottom();
            i10 = childCount;
            if (obj3 == null) {
            }
            mode = i10;
            setMeasuredDimension(View.resolveSizeAndState(Math.max(mode + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i3, i7), combineMeasuredStates);
            if (obj4 == null) {
                i3 = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
                for (i15 = 0; i15 < i5; i15++) {
                    childAt2 = getChildAt(i15);
                    if (childAt2.getVisibility() == 8) {
                        layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                        if (layoutParams2.width != -1) {
                            i6 = layoutParams2.height;
                            layoutParams2.height = childAt2.getMeasuredHeight();
                            measureChildWithMargins(childAt2, i3, 0, i2, 0);
                            layoutParams2.height = i6;
                        }
                    }
                }
                return;
            }
            return;
        }
        boolean z2;
        int i24;
        boolean z3;
        int i25;
        float f4;
        r6.mTotalLength = 0;
        i5 = getChildCount();
        i15 = MeasureSpec.getMode(i);
        i6 = MeasureSpec.getMode(i2);
        if (r6.mMaxAscent == null || r6.mMaxDescent == null) {
            r6.mMaxAscent = new int[4];
            r6.mMaxDescent = new int[4];
        }
        int[] iArr = r6.mMaxAscent;
        int[] iArr2 = r6.mMaxDescent;
        iArr[3] = -1;
        iArr[2] = -1;
        iArr[1] = -1;
        iArr[0] = -1;
        iArr2[3] = -1;
        iArr2[2] = -1;
        iArr2[1] = -1;
        iArr2[0] = -1;
        boolean z4 = r6.mBaselineAligned;
        boolean z5 = r6.mUseLargestChild;
        i8 = 0;
        float f5 = 0.0f;
        mode = 0;
        childCount = 0;
        i13 = 0;
        obj = null;
        Object obj7 = null;
        Object obj8 = 1;
        int i26 = 0;
        int i27 = 0;
        while (childCount < i5) {
            float f6;
            int i28;
            childAt = getChildAt(childCount);
            if (childAt == null) {
                i9 = i8;
                i10 = mode;
            } else {
                i9 = i8;
                i10 = mode;
                if (childAt.getVisibility() != 8) {
                    LayoutParams layoutParams5;
                    int i29;
                    Object obj9;
                    int i30;
                    int i31;
                    LayoutParams layoutParams6;
                    int i32;
                    if (hasDividerBeforeChildAt(childCount)) {
                        r6.mTotalLength += r6.mDividerWidth;
                    }
                    LayoutParams layoutParams7 = (LayoutParams) childAt.getLayoutParams();
                    f6 = f5 + layoutParams7.weight;
                    if (i15 != 1073741824) {
                        i28 = childCount;
                        childCount = i15;
                    } else if (layoutParams7.width != 0) {
                        i28 = childCount;
                        childCount = 1073741824;
                    } else if (layoutParams7.weight > 0.0f) {
                        i28 = childCount;
                        r6.mTotalLength += layoutParams7.leftMargin + layoutParams7.rightMargin;
                        if (z4) {
                            mode2 = MeasureSpec.makeMeasureSpec(0, 0);
                            childAt.measure(mode2, mode2);
                            layoutParams5 = layoutParams7;
                            z2 = z4;
                            i29 = i9;
                            i24 = i10;
                            i10 = i28;
                            z3 = z5;
                        } else {
                            layoutParams5 = layoutParams7;
                            z2 = z4;
                            i29 = i9;
                            i24 = i10;
                            i10 = i28;
                            obj7 = 1;
                            z3 = z5;
                        }
                        if (i6 == 1073741824 && layoutParams5.height == -1) {
                            i11 = 1;
                            obj = 1;
                        } else {
                            i11 = 0;
                        }
                        mode2 = layoutParams5.topMargin + layoutParams5.bottomMargin;
                        mode = childAt.getMeasuredHeight() + mode2;
                        childCount = View.combineMeasuredStates(i24, childAt.getMeasuredState());
                        if (z2) {
                            combineMeasuredStates = childAt.getBaseline();
                            if (combineMeasuredStates != -1) {
                                i14 = (((layoutParams5.gravity < 0 ? r6.mGravity : layoutParams5.gravity) & 112) >> 4) >> 1;
                                i12 = mode2;
                                iArr[i14] = Math.max(iArr[i14], combineMeasuredStates);
                                iArr2[i14] = Math.max(iArr2[i14], mode - combineMeasuredStates);
                            } else {
                                i12 = mode2;
                            }
                        } else {
                            i12 = mode2;
                        }
                        mode2 = Math.max(i27, mode);
                        if (obj8 == null && layoutParams5.height == -1) {
                            obj9 = 1;
                        } else {
                            obj9 = null;
                        }
                        if (layoutParams5.weight > 0.0f) {
                            if (1 != i11) {
                                mode = i12;
                            }
                            i26 = Math.max(i26, mode);
                            i8 = i29;
                        } else {
                            i14 = i26;
                            if (1 != i11) {
                                mode = i12;
                            }
                            i8 = Math.max(i29, mode);
                            i26 = i14;
                        }
                        i27 = mode2;
                        mode = childCount;
                        obj8 = obj9;
                        f5 = f6;
                        childCount = i10 + 1;
                        z5 = z3;
                        z4 = z2;
                    } else {
                        i28 = childCount;
                        childCount = 1073741824;
                    }
                    if (layoutParams7.width == 0) {
                        f5 = 0.0f;
                        if (layoutParams7.weight > 0.0f) {
                            layoutParams7.width = -2;
                            i30 = 0;
                            if (f6 != f5) {
                                i31 = r6.mTotalLength;
                            } else {
                                i31 = 0;
                            }
                            i29 = i9;
                            layoutParams6 = layoutParams7;
                            i24 = i10;
                            i32 = childCount;
                            i10 = i28;
                            z3 = z5;
                            z2 = z4;
                            measureChildWithMargins(childAt, i, i31, i2, 0);
                            if (i30 == Integer.MIN_VALUE) {
                                layoutParams5 = layoutParams6;
                                layoutParams5.width = 0;
                            } else {
                                layoutParams5 = layoutParams6;
                            }
                            mode2 = childAt.getMeasuredWidth();
                            if (i32 != 1073741824) {
                                r6.mTotalLength += (layoutParams5.leftMargin + mode2) + layoutParams5.rightMargin;
                            } else {
                                mode = r6.mTotalLength;
                                r6.mTotalLength = Math.max(mode, ((mode + mode2) + layoutParams5.leftMargin) + layoutParams5.rightMargin);
                            }
                            if (z3) {
                                i13 = Math.max(mode2, i13);
                            }
                            if (i6 == 1073741824) {
                            }
                            i11 = 0;
                            mode2 = layoutParams5.topMargin + layoutParams5.bottomMargin;
                            mode = childAt.getMeasuredHeight() + mode2;
                            childCount = View.combineMeasuredStates(i24, childAt.getMeasuredState());
                            if (z2) {
                                i12 = mode2;
                            } else {
                                combineMeasuredStates = childAt.getBaseline();
                                if (combineMeasuredStates != -1) {
                                    i12 = mode2;
                                } else {
                                    if (layoutParams5.gravity < 0) {
                                    }
                                    i14 = (((layoutParams5.gravity < 0 ? r6.mGravity : layoutParams5.gravity) & 112) >> 4) >> 1;
                                    i12 = mode2;
                                    iArr[i14] = Math.max(iArr[i14], combineMeasuredStates);
                                    iArr2[i14] = Math.max(iArr2[i14], mode - combineMeasuredStates);
                                }
                            }
                            mode2 = Math.max(i27, mode);
                            if (obj8 == null) {
                            }
                            obj9 = null;
                            if (layoutParams5.weight > 0.0f) {
                                i14 = i26;
                                if (1 != i11) {
                                    mode = i12;
                                }
                                i8 = Math.max(i29, mode);
                                i26 = i14;
                            } else {
                                if (1 != i11) {
                                    mode = i12;
                                }
                                i26 = Math.max(i26, mode);
                                i8 = i29;
                            }
                            i27 = mode2;
                            mode = childCount;
                            obj8 = obj9;
                            f5 = f6;
                            childCount = i10 + 1;
                            z5 = z3;
                            z4 = z2;
                        }
                    } else {
                        f5 = 0.0f;
                    }
                    i30 = LinearLayoutManager.INVALID_OFFSET;
                    if (f6 != f5) {
                        i31 = 0;
                    } else {
                        i31 = r6.mTotalLength;
                    }
                    i29 = i9;
                    layoutParams6 = layoutParams7;
                    i24 = i10;
                    i32 = childCount;
                    i10 = i28;
                    z3 = z5;
                    z2 = z4;
                    measureChildWithMargins(childAt, i, i31, i2, 0);
                    if (i30 == Integer.MIN_VALUE) {
                        layoutParams5 = layoutParams6;
                    } else {
                        layoutParams5 = layoutParams6;
                        layoutParams5.width = 0;
                    }
                    mode2 = childAt.getMeasuredWidth();
                    if (i32 != 1073741824) {
                        mode = r6.mTotalLength;
                        r6.mTotalLength = Math.max(mode, ((mode + mode2) + layoutParams5.leftMargin) + layoutParams5.rightMargin);
                    } else {
                        r6.mTotalLength += (layoutParams5.leftMargin + mode2) + layoutParams5.rightMargin;
                    }
                    if (z3) {
                        i13 = Math.max(mode2, i13);
                    }
                    if (i6 == 1073741824) {
                    }
                    i11 = 0;
                    mode2 = layoutParams5.topMargin + layoutParams5.bottomMargin;
                    mode = childAt.getMeasuredHeight() + mode2;
                    childCount = View.combineMeasuredStates(i24, childAt.getMeasuredState());
                    if (z2) {
                        combineMeasuredStates = childAt.getBaseline();
                        if (combineMeasuredStates != -1) {
                            if (layoutParams5.gravity < 0) {
                            }
                            i14 = (((layoutParams5.gravity < 0 ? r6.mGravity : layoutParams5.gravity) & 112) >> 4) >> 1;
                            i12 = mode2;
                            iArr[i14] = Math.max(iArr[i14], combineMeasuredStates);
                            iArr2[i14] = Math.max(iArr2[i14], mode - combineMeasuredStates);
                        } else {
                            i12 = mode2;
                        }
                    } else {
                        i12 = mode2;
                    }
                    mode2 = Math.max(i27, mode);
                    if (obj8 == null) {
                    }
                    obj9 = null;
                    if (layoutParams5.weight > 0.0f) {
                        if (1 != i11) {
                            mode = i12;
                        }
                        i26 = Math.max(i26, mode);
                        i8 = i29;
                    } else {
                        i14 = i26;
                        if (1 != i11) {
                            mode = i12;
                        }
                        i8 = Math.max(i29, mode);
                        i26 = i14;
                    }
                    i27 = mode2;
                    mode = childCount;
                    obj8 = obj9;
                    f5 = f6;
                    childCount = i10 + 1;
                    z5 = z3;
                    z4 = z2;
                }
            }
            z3 = z5;
            z2 = z4;
            i8 = i9;
            mode = i10;
            i10 = childCount;
            childCount = i10 + 1;
            z5 = z3;
            z4 = z2;
        }
        z3 = z5;
        z2 = z4;
        i14 = i27;
        combineMeasuredStates = mode;
        mode = i26;
        if (r6.mTotalLength > 0 && hasDividerBeforeChildAt(i5)) {
            r6.mTotalLength += r6.mDividerWidth;
        }
        i11 = iArr[1];
        View childAt5;
        View childAt6;
        View childAt7;
        LayoutParams layoutParams8;
        float f7;
        float f8;
        int i33;
        Object obj10;
        if (i11 == -1) {
            i24 = combineMeasuredStates;
            if (iArr[0] != -1 || iArr[2] != -1) {
                combineMeasuredStates = -1;
            } else if (iArr[3] != -1) {
                combineMeasuredStates = -1;
            } else {
                i27 = i14;
                i9 = i6;
                if (z3) {
                    if (i15 != LinearLayoutManager.INVALID_OFFSET) {
                        i11 = i15;
                    } else if (i15 == 0) {
                        i11 = 0;
                        i15 = 0;
                    }
                    r6.mTotalLength = 0;
                    for (childCount = 0; childCount < i5; childCount++) {
                        childAt5 = getChildAt(childCount);
                        if (childAt5 == null) {
                            if (childAt5.getVisibility() != 8) {
                                layoutParams = (LayoutParams) childAt5.getLayoutParams();
                                i4 = r6.mTotalLength;
                                r6.mTotalLength = Math.max(i4, ((i4 + i13) + layoutParams.leftMargin) + layoutParams.rightMargin);
                            }
                        }
                    }
                    childCount = i15;
                    i15 = i11;
                    i11 = r6.mTotalLength + (getPaddingLeft() + getPaddingRight());
                    r6.mTotalLength = i11;
                    i11 = View.resolveSizeAndState(Math.max(i11, getSuggestedMinimumWidth()), i3, 0);
                    combineMeasuredStates = (16777215 & i11) - r6.mTotalLength;
                    if (obj7 == null) {
                        if (combineMeasuredStates != 0 || f5 <= 0.0f) {
                            i8 = Math.max(i8, mode);
                            if (z3 && i15 != 1073741824) {
                                for (mode2 = 0; mode2 < i5; mode2++) {
                                    childAt6 = getChildAt(mode2);
                                    if (childAt6 == null) {
                                        if (childAt6.getVisibility() != 8) {
                                            if (((LayoutParams) childAt6.getLayoutParams()).weight <= 0.0f) {
                                                childAt6.measure(MeasureSpec.makeMeasureSpec(i13, 1073741824), MeasureSpec.makeMeasureSpec(childAt6.getMeasuredHeight(), 1073741824));
                                            }
                                        }
                                    }
                                }
                            }
                            i14 = i2;
                            i25 = i5;
                            i5 = i9;
                            mode = i24;
                            if (obj8 == null || r9 == 1073741824) {
                                i8 = i27;
                            }
                            setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
                            if (obj != null) {
                                i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                                i4 = 0;
                                while (true) {
                                    i5 = i25;
                                    if (i4 < i5) {
                                        childAt2 = getChildAt(i4);
                                        if (childAt2.getVisibility() != 8) {
                                            layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                                            if (layoutParams2.height == -1) {
                                                i13 = layoutParams2.width;
                                                layoutParams2.width = childAt2.getMeasuredWidth();
                                                measureChildWithMargins(childAt2, i, 0, i3, 0);
                                                layoutParams2.width = i13;
                                            }
                                        }
                                        i4++;
                                        i25 = i5;
                                    } else {
                                        return;
                                    }
                                }
                            }
                        }
                    }
                    f4 = r6.mWeightSum;
                    if (f4 > 0.0f) {
                        f5 = f4;
                    }
                    iArr[3] = -1;
                    iArr[2] = -1;
                    iArr[1] = -1;
                    iArr[0] = -1;
                    iArr2[3] = -1;
                    iArr2[2] = -1;
                    iArr2[1] = -1;
                    iArr2[0] = -1;
                    r6.mTotalLength = 0;
                    i14 = combineMeasuredStates;
                    mode = i24;
                    combineMeasuredStates = 0;
                    i6 = -1;
                    while (combineMeasuredStates < i5) {
                        childAt7 = getChildAt(combineMeasuredStates);
                        if (childAt7 == null) {
                            i25 = i5;
                            i4 = i14;
                            i5 = i9;
                            i14 = i2;
                            i9 = childCount;
                        } else if (childAt7.getVisibility() != 8) {
                            i25 = i5;
                            i4 = i14;
                            i5 = i9;
                            i14 = i2;
                            i9 = childCount;
                        } else {
                            layoutParams8 = (LayoutParams) childAt7.getLayoutParams();
                            f7 = layoutParams8.weight;
                            if (f7 <= 0.0f) {
                                i25 = i5;
                                i5 = (int) ((((float) i14) * f7) / f5);
                                f8 = f5 - f7;
                                i33 = i14 - i5;
                                mode2 = ViewGroup.getChildMeasureSpec(i2, ((getPaddingTop() + getPaddingBottom()) + layoutParams8.topMargin) + layoutParams8.bottomMargin, layoutParams8.height);
                                if (layoutParams8.width == 0) {
                                    if (i15 == 1073741824) {
                                        if (i5 <= 0) {
                                            i5 = 0;
                                        }
                                        childAt7.measure(MeasureSpec.makeMeasureSpec(i5, 1073741824), mode2);
                                        mode = View.combineMeasuredStates(mode, childAt7.getMeasuredState() & -16777216);
                                        f5 = f8;
                                        i4 = i33;
                                    }
                                }
                                i4 = childAt7.getMeasuredWidth() + i5;
                                if (i4 < 0) {
                                    i4 = 0;
                                }
                                childAt7.measure(MeasureSpec.makeMeasureSpec(i4, 1073741824), mode2);
                                mode = View.combineMeasuredStates(mode, childAt7.getMeasuredState() & -16777216);
                                f5 = f8;
                                i4 = i33;
                            } else {
                                i25 = i5;
                                i4 = i14;
                                i14 = i2;
                            }
                            if (childCount != 1073741824) {
                                f6 = f5;
                                r6.mTotalLength += (childAt7.getMeasuredWidth() + layoutParams8.leftMargin) + layoutParams8.rightMargin;
                                i10 = mode;
                            } else {
                                f6 = f5;
                                mode2 = r6.mTotalLength;
                                i10 = mode;
                                r6.mTotalLength = Math.max(mode2, ((childAt7.getMeasuredWidth() + mode2) + layoutParams8.leftMargin) + layoutParams8.rightMargin);
                            }
                            i5 = i9;
                            if (i5 == 1073741824 && layoutParams8.height == -1) {
                                mode2 = 1;
                            } else {
                                mode2 = 0;
                            }
                            i9 = childCount;
                            mode = layoutParams8.topMargin + layoutParams8.bottomMargin;
                            childCount = childAt7.getMeasuredHeight() + mode;
                            i6 = Math.max(i6, childCount);
                            i28 = mode;
                            if (1 == mode2) {
                                mode = childCount;
                            } else {
                                mode = i28;
                            }
                            i8 = Math.max(i8, mode);
                            if (obj8 == null) {
                                mode = -1;
                                if (layoutParams8.height == -1) {
                                    obj10 = 1;
                                    if (z2) {
                                        i13 = childAt7.getBaseline();
                                        if (i13 != mode) {
                                            mode = (((layoutParams8.gravity >= 0 ? r6.mGravity : layoutParams8.gravity) & 112) >> 4) >> 1;
                                            iArr[mode] = Math.max(iArr[mode], i13);
                                            iArr2[mode] = Math.max(iArr2[mode], childCount - i13);
                                            obj8 = obj10;
                                            mode = i10;
                                            f5 = f6;
                                        }
                                    }
                                    obj8 = obj10;
                                    mode = i10;
                                    f5 = f6;
                                }
                            } else {
                                mode = -1;
                            }
                            obj10 = null;
                            if (z2) {
                                i13 = childAt7.getBaseline();
                                if (i13 != mode) {
                                    if (layoutParams8.gravity >= 0) {
                                    }
                                    mode = (((layoutParams8.gravity >= 0 ? r6.mGravity : layoutParams8.gravity) & 112) >> 4) >> 1;
                                    iArr[mode] = Math.max(iArr[mode], i13);
                                    iArr2[mode] = Math.max(iArr2[mode], childCount - i13);
                                    obj8 = obj10;
                                    mode = i10;
                                    f5 = f6;
                                }
                            }
                            obj8 = obj10;
                            mode = i10;
                            f5 = f6;
                        }
                        combineMeasuredStates++;
                        i3 = i;
                        i14 = i4;
                        childCount = i9;
                        i9 = i5;
                        i5 = i25;
                    }
                    i14 = i2;
                    i25 = i5;
                    i5 = i9;
                    r6.mTotalLength += getPaddingLeft() + getPaddingRight();
                    combineMeasuredStates = iArr[1];
                    if (combineMeasuredStates == -1) {
                        if (iArr[0] == -1 || iArr[2] != -1) {
                            combineMeasuredStates = -1;
                        } else if (iArr[3] != -1) {
                            combineMeasuredStates = -1;
                        } else {
                            i27 = i6;
                            if (obj8 == null) {
                            }
                            i8 = i27;
                            setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
                            if (obj != null) {
                                i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                                i4 = 0;
                                while (true) {
                                    i5 = i25;
                                    if (i4 < i5) {
                                        childAt2 = getChildAt(i4);
                                        if (childAt2.getVisibility() != 8) {
                                            layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                                            if (layoutParams2.height == -1) {
                                                i13 = layoutParams2.width;
                                                layoutParams2.width = childAt2.getMeasuredWidth();
                                                measureChildWithMargins(childAt2, i, 0, i3, 0);
                                                layoutParams2.width = i13;
                                            }
                                        }
                                        i4++;
                                        i25 = i5;
                                    } else {
                                        return;
                                    }
                                }
                            }
                        }
                    }
                    i27 = Math.max(i6, Math.max(iArr[3], Math.max(iArr[0], Math.max(combineMeasuredStates, iArr[2]))) + Math.max(iArr2[3], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))));
                    if (obj8 == null) {
                    }
                    i8 = i27;
                    setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
                    if (obj != null) {
                        i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                        i4 = 0;
                        while (true) {
                            i5 = i25;
                            if (i4 < i5) {
                                childAt2 = getChildAt(i4);
                                if (childAt2.getVisibility() != 8) {
                                    layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                                    if (layoutParams2.height == -1) {
                                        i13 = layoutParams2.width;
                                        layoutParams2.width = childAt2.getMeasuredWidth();
                                        measureChildWithMargins(childAt2, i, 0, i3, 0);
                                        layoutParams2.width = i13;
                                    }
                                }
                                i4++;
                                i25 = i5;
                            } else {
                                return;
                            }
                        }
                    }
                }
                childCount = i15;
                i11 = r6.mTotalLength + (getPaddingLeft() + getPaddingRight());
                r6.mTotalLength = i11;
                i11 = View.resolveSizeAndState(Math.max(i11, getSuggestedMinimumWidth()), i3, 0);
                combineMeasuredStates = (16777215 & i11) - r6.mTotalLength;
                if (obj7 == null) {
                    if (combineMeasuredStates != 0) {
                    }
                    i8 = Math.max(i8, mode);
                    for (mode2 = 0; mode2 < i5; mode2++) {
                        childAt6 = getChildAt(mode2);
                        if (childAt6 == null) {
                            if (childAt6.getVisibility() != 8) {
                                if (((LayoutParams) childAt6.getLayoutParams()).weight <= 0.0f) {
                                    childAt6.measure(MeasureSpec.makeMeasureSpec(i13, 1073741824), MeasureSpec.makeMeasureSpec(childAt6.getMeasuredHeight(), 1073741824));
                                }
                            }
                        }
                    }
                    i14 = i2;
                    i25 = i5;
                    i5 = i9;
                    mode = i24;
                    if (obj8 == null) {
                    }
                    i8 = i27;
                    setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
                    if (obj != null) {
                        i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                        i4 = 0;
                        while (true) {
                            i5 = i25;
                            if (i4 < i5) {
                                childAt2 = getChildAt(i4);
                                if (childAt2.getVisibility() != 8) {
                                    layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                                    if (layoutParams2.height == -1) {
                                        i13 = layoutParams2.width;
                                        layoutParams2.width = childAt2.getMeasuredWidth();
                                        measureChildWithMargins(childAt2, i, 0, i3, 0);
                                        layoutParams2.width = i13;
                                    }
                                }
                                i4++;
                                i25 = i5;
                            } else {
                                return;
                            }
                        }
                    }
                }
                f4 = r6.mWeightSum;
                if (f4 > 0.0f) {
                    f5 = f4;
                }
                iArr[3] = -1;
                iArr[2] = -1;
                iArr[1] = -1;
                iArr[0] = -1;
                iArr2[3] = -1;
                iArr2[2] = -1;
                iArr2[1] = -1;
                iArr2[0] = -1;
                r6.mTotalLength = 0;
                i14 = combineMeasuredStates;
                mode = i24;
                combineMeasuredStates = 0;
                i6 = -1;
                while (combineMeasuredStates < i5) {
                    childAt7 = getChildAt(combineMeasuredStates);
                    if (childAt7 == null) {
                        i25 = i5;
                        i4 = i14;
                        i5 = i9;
                        i14 = i2;
                        i9 = childCount;
                    } else if (childAt7.getVisibility() != 8) {
                        layoutParams8 = (LayoutParams) childAt7.getLayoutParams();
                        f7 = layoutParams8.weight;
                        if (f7 <= 0.0f) {
                            i25 = i5;
                            i4 = i14;
                            i14 = i2;
                        } else {
                            i25 = i5;
                            i5 = (int) ((((float) i14) * f7) / f5);
                            f8 = f5 - f7;
                            i33 = i14 - i5;
                            mode2 = ViewGroup.getChildMeasureSpec(i2, ((getPaddingTop() + getPaddingBottom()) + layoutParams8.topMargin) + layoutParams8.bottomMargin, layoutParams8.height);
                            if (layoutParams8.width == 0) {
                                if (i15 == 1073741824) {
                                    if (i5 <= 0) {
                                        i5 = 0;
                                    }
                                    childAt7.measure(MeasureSpec.makeMeasureSpec(i5, 1073741824), mode2);
                                    mode = View.combineMeasuredStates(mode, childAt7.getMeasuredState() & -16777216);
                                    f5 = f8;
                                    i4 = i33;
                                }
                            }
                            i4 = childAt7.getMeasuredWidth() + i5;
                            if (i4 < 0) {
                                i4 = 0;
                            }
                            childAt7.measure(MeasureSpec.makeMeasureSpec(i4, 1073741824), mode2);
                            mode = View.combineMeasuredStates(mode, childAt7.getMeasuredState() & -16777216);
                            f5 = f8;
                            i4 = i33;
                        }
                        if (childCount != 1073741824) {
                            f6 = f5;
                            mode2 = r6.mTotalLength;
                            i10 = mode;
                            r6.mTotalLength = Math.max(mode2, ((childAt7.getMeasuredWidth() + mode2) + layoutParams8.leftMargin) + layoutParams8.rightMargin);
                        } else {
                            f6 = f5;
                            r6.mTotalLength += (childAt7.getMeasuredWidth() + layoutParams8.leftMargin) + layoutParams8.rightMargin;
                            i10 = mode;
                        }
                        i5 = i9;
                        if (i5 == 1073741824) {
                        }
                        mode2 = 0;
                        i9 = childCount;
                        mode = layoutParams8.topMargin + layoutParams8.bottomMargin;
                        childCount = childAt7.getMeasuredHeight() + mode;
                        i6 = Math.max(i6, childCount);
                        i28 = mode;
                        if (1 == mode2) {
                            mode = i28;
                        } else {
                            mode = childCount;
                        }
                        i8 = Math.max(i8, mode);
                        if (obj8 == null) {
                            mode = -1;
                        } else {
                            mode = -1;
                            if (layoutParams8.height == -1) {
                                obj10 = 1;
                                if (z2) {
                                    i13 = childAt7.getBaseline();
                                    if (i13 != mode) {
                                        if (layoutParams8.gravity >= 0) {
                                        }
                                        mode = (((layoutParams8.gravity >= 0 ? r6.mGravity : layoutParams8.gravity) & 112) >> 4) >> 1;
                                        iArr[mode] = Math.max(iArr[mode], i13);
                                        iArr2[mode] = Math.max(iArr2[mode], childCount - i13);
                                        obj8 = obj10;
                                        mode = i10;
                                        f5 = f6;
                                    }
                                }
                                obj8 = obj10;
                                mode = i10;
                                f5 = f6;
                            }
                        }
                        obj10 = null;
                        if (z2) {
                            i13 = childAt7.getBaseline();
                            if (i13 != mode) {
                                if (layoutParams8.gravity >= 0) {
                                }
                                mode = (((layoutParams8.gravity >= 0 ? r6.mGravity : layoutParams8.gravity) & 112) >> 4) >> 1;
                                iArr[mode] = Math.max(iArr[mode], i13);
                                iArr2[mode] = Math.max(iArr2[mode], childCount - i13);
                                obj8 = obj10;
                                mode = i10;
                                f5 = f6;
                            }
                        }
                        obj8 = obj10;
                        mode = i10;
                        f5 = f6;
                    } else {
                        i25 = i5;
                        i4 = i14;
                        i5 = i9;
                        i14 = i2;
                        i9 = childCount;
                    }
                    combineMeasuredStates++;
                    i3 = i;
                    i14 = i4;
                    childCount = i9;
                    i9 = i5;
                    i5 = i25;
                }
                i14 = i2;
                i25 = i5;
                i5 = i9;
                r6.mTotalLength += getPaddingLeft() + getPaddingRight();
                combineMeasuredStates = iArr[1];
                if (combineMeasuredStates == -1) {
                    if (iArr[0] == -1) {
                    }
                    combineMeasuredStates = -1;
                }
                i27 = Math.max(i6, Math.max(iArr[3], Math.max(iArr[0], Math.max(combineMeasuredStates, iArr[2]))) + Math.max(iArr2[3], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))));
                if (obj8 == null) {
                }
                i8 = i27;
                setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
                if (obj != null) {
                    i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                    i4 = 0;
                    while (true) {
                        i5 = i25;
                        if (i4 < i5) {
                            childAt2 = getChildAt(i4);
                            if (childAt2.getVisibility() != 8) {
                                layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                                if (layoutParams2.height == -1) {
                                    i13 = layoutParams2.width;
                                    layoutParams2.width = childAt2.getMeasuredWidth();
                                    measureChildWithMargins(childAt2, i, 0, i3, 0);
                                    layoutParams2.width = i13;
                                }
                            }
                            i4++;
                            i25 = i5;
                        } else {
                            return;
                        }
                    }
                }
            }
        }
        i24 = combineMeasuredStates;
        combineMeasuredStates = i11;
        i9 = i6;
        i27 = Math.max(i14, Math.max(iArr[3], Math.max(iArr[0], Math.max(combineMeasuredStates, iArr[2]))) + Math.max(iArr2[3], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))));
        if (z3) {
            if (i15 != LinearLayoutManager.INVALID_OFFSET) {
                i11 = i15;
            } else if (i15 == 0) {
                i11 = 0;
                i15 = 0;
            }
            r6.mTotalLength = 0;
            for (childCount = 0; childCount < i5; childCount++) {
                childAt5 = getChildAt(childCount);
                if (childAt5 == null) {
                    if (childAt5.getVisibility() != 8) {
                        layoutParams = (LayoutParams) childAt5.getLayoutParams();
                        i4 = r6.mTotalLength;
                        r6.mTotalLength = Math.max(i4, ((i4 + i13) + layoutParams.leftMargin) + layoutParams.rightMargin);
                    }
                }
            }
            childCount = i15;
            i15 = i11;
            i11 = r6.mTotalLength + (getPaddingLeft() + getPaddingRight());
            r6.mTotalLength = i11;
            i11 = View.resolveSizeAndState(Math.max(i11, getSuggestedMinimumWidth()), i3, 0);
            combineMeasuredStates = (16777215 & i11) - r6.mTotalLength;
            if (obj7 == null) {
                if (combineMeasuredStates != 0) {
                }
                i8 = Math.max(i8, mode);
                for (mode2 = 0; mode2 < i5; mode2++) {
                    childAt6 = getChildAt(mode2);
                    if (childAt6 == null) {
                        if (childAt6.getVisibility() != 8) {
                            if (((LayoutParams) childAt6.getLayoutParams()).weight <= 0.0f) {
                                childAt6.measure(MeasureSpec.makeMeasureSpec(i13, 1073741824), MeasureSpec.makeMeasureSpec(childAt6.getMeasuredHeight(), 1073741824));
                            }
                        }
                    }
                }
                i14 = i2;
                i25 = i5;
                i5 = i9;
                mode = i24;
                if (obj8 == null) {
                }
                i8 = i27;
                setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
                if (obj != null) {
                    i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                    i4 = 0;
                    while (true) {
                        i5 = i25;
                        if (i4 < i5) {
                            childAt2 = getChildAt(i4);
                            if (childAt2.getVisibility() != 8) {
                                layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                                if (layoutParams2.height == -1) {
                                    i13 = layoutParams2.width;
                                    layoutParams2.width = childAt2.getMeasuredWidth();
                                    measureChildWithMargins(childAt2, i, 0, i3, 0);
                                    layoutParams2.width = i13;
                                }
                            }
                            i4++;
                            i25 = i5;
                        } else {
                            return;
                        }
                    }
                }
            }
            f4 = r6.mWeightSum;
            if (f4 > 0.0f) {
                f5 = f4;
            }
            iArr[3] = -1;
            iArr[2] = -1;
            iArr[1] = -1;
            iArr[0] = -1;
            iArr2[3] = -1;
            iArr2[2] = -1;
            iArr2[1] = -1;
            iArr2[0] = -1;
            r6.mTotalLength = 0;
            i14 = combineMeasuredStates;
            mode = i24;
            combineMeasuredStates = 0;
            i6 = -1;
            while (combineMeasuredStates < i5) {
                childAt7 = getChildAt(combineMeasuredStates);
                if (childAt7 == null) {
                    i25 = i5;
                    i4 = i14;
                    i5 = i9;
                    i14 = i2;
                    i9 = childCount;
                } else if (childAt7.getVisibility() != 8) {
                    i25 = i5;
                    i4 = i14;
                    i5 = i9;
                    i14 = i2;
                    i9 = childCount;
                } else {
                    layoutParams8 = (LayoutParams) childAt7.getLayoutParams();
                    f7 = layoutParams8.weight;
                    if (f7 <= 0.0f) {
                        i25 = i5;
                        i5 = (int) ((((float) i14) * f7) / f5);
                        f8 = f5 - f7;
                        i33 = i14 - i5;
                        mode2 = ViewGroup.getChildMeasureSpec(i2, ((getPaddingTop() + getPaddingBottom()) + layoutParams8.topMargin) + layoutParams8.bottomMargin, layoutParams8.height);
                        if (layoutParams8.width == 0) {
                            if (i15 == 1073741824) {
                                if (i5 <= 0) {
                                    i5 = 0;
                                }
                                childAt7.measure(MeasureSpec.makeMeasureSpec(i5, 1073741824), mode2);
                                mode = View.combineMeasuredStates(mode, childAt7.getMeasuredState() & -16777216);
                                f5 = f8;
                                i4 = i33;
                            }
                        }
                        i4 = childAt7.getMeasuredWidth() + i5;
                        if (i4 < 0) {
                            i4 = 0;
                        }
                        childAt7.measure(MeasureSpec.makeMeasureSpec(i4, 1073741824), mode2);
                        mode = View.combineMeasuredStates(mode, childAt7.getMeasuredState() & -16777216);
                        f5 = f8;
                        i4 = i33;
                    } else {
                        i25 = i5;
                        i4 = i14;
                        i14 = i2;
                    }
                    if (childCount != 1073741824) {
                        f6 = f5;
                        r6.mTotalLength += (childAt7.getMeasuredWidth() + layoutParams8.leftMargin) + layoutParams8.rightMargin;
                        i10 = mode;
                    } else {
                        f6 = f5;
                        mode2 = r6.mTotalLength;
                        i10 = mode;
                        r6.mTotalLength = Math.max(mode2, ((childAt7.getMeasuredWidth() + mode2) + layoutParams8.leftMargin) + layoutParams8.rightMargin);
                    }
                    i5 = i9;
                    if (i5 == 1073741824) {
                    }
                    mode2 = 0;
                    i9 = childCount;
                    mode = layoutParams8.topMargin + layoutParams8.bottomMargin;
                    childCount = childAt7.getMeasuredHeight() + mode;
                    i6 = Math.max(i6, childCount);
                    i28 = mode;
                    if (1 == mode2) {
                        mode = childCount;
                    } else {
                        mode = i28;
                    }
                    i8 = Math.max(i8, mode);
                    if (obj8 == null) {
                        mode = -1;
                        if (layoutParams8.height == -1) {
                            obj10 = 1;
                            if (z2) {
                                i13 = childAt7.getBaseline();
                                if (i13 != mode) {
                                    if (layoutParams8.gravity >= 0) {
                                    }
                                    mode = (((layoutParams8.gravity >= 0 ? r6.mGravity : layoutParams8.gravity) & 112) >> 4) >> 1;
                                    iArr[mode] = Math.max(iArr[mode], i13);
                                    iArr2[mode] = Math.max(iArr2[mode], childCount - i13);
                                    obj8 = obj10;
                                    mode = i10;
                                    f5 = f6;
                                }
                            }
                            obj8 = obj10;
                            mode = i10;
                            f5 = f6;
                        }
                    } else {
                        mode = -1;
                    }
                    obj10 = null;
                    if (z2) {
                        i13 = childAt7.getBaseline();
                        if (i13 != mode) {
                            if (layoutParams8.gravity >= 0) {
                            }
                            mode = (((layoutParams8.gravity >= 0 ? r6.mGravity : layoutParams8.gravity) & 112) >> 4) >> 1;
                            iArr[mode] = Math.max(iArr[mode], i13);
                            iArr2[mode] = Math.max(iArr2[mode], childCount - i13);
                            obj8 = obj10;
                            mode = i10;
                            f5 = f6;
                        }
                    }
                    obj8 = obj10;
                    mode = i10;
                    f5 = f6;
                }
                combineMeasuredStates++;
                i3 = i;
                i14 = i4;
                childCount = i9;
                i9 = i5;
                i5 = i25;
            }
            i14 = i2;
            i25 = i5;
            i5 = i9;
            r6.mTotalLength += getPaddingLeft() + getPaddingRight();
            combineMeasuredStates = iArr[1];
            if (combineMeasuredStates == -1) {
                if (iArr[0] == -1) {
                }
                combineMeasuredStates = -1;
            }
            i27 = Math.max(i6, Math.max(iArr[3], Math.max(iArr[0], Math.max(combineMeasuredStates, iArr[2]))) + Math.max(iArr2[3], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))));
            if (obj8 == null) {
            }
            i8 = i27;
            setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
            if (obj != null) {
                i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                i4 = 0;
                while (true) {
                    i5 = i25;
                    if (i4 < i5) {
                        childAt2 = getChildAt(i4);
                        if (childAt2.getVisibility() != 8) {
                            layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                            if (layoutParams2.height == -1) {
                                i13 = layoutParams2.width;
                                layoutParams2.width = childAt2.getMeasuredWidth();
                                measureChildWithMargins(childAt2, i, 0, i3, 0);
                                layoutParams2.width = i13;
                            }
                        }
                        i4++;
                        i25 = i5;
                    } else {
                        return;
                    }
                }
            }
        }
        childCount = i15;
        i11 = r6.mTotalLength + (getPaddingLeft() + getPaddingRight());
        r6.mTotalLength = i11;
        i11 = View.resolveSizeAndState(Math.max(i11, getSuggestedMinimumWidth()), i3, 0);
        combineMeasuredStates = (16777215 & i11) - r6.mTotalLength;
        if (obj7 == null) {
            if (combineMeasuredStates != 0) {
            }
            i8 = Math.max(i8, mode);
            for (mode2 = 0; mode2 < i5; mode2++) {
                childAt6 = getChildAt(mode2);
                if (childAt6 == null) {
                    if (childAt6.getVisibility() != 8) {
                        if (((LayoutParams) childAt6.getLayoutParams()).weight <= 0.0f) {
                            childAt6.measure(MeasureSpec.makeMeasureSpec(i13, 1073741824), MeasureSpec.makeMeasureSpec(childAt6.getMeasuredHeight(), 1073741824));
                        }
                    }
                }
            }
            i14 = i2;
            i25 = i5;
            i5 = i9;
            mode = i24;
            if (obj8 == null) {
            }
            i8 = i27;
            setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
            if (obj != null) {
                i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                i4 = 0;
                while (true) {
                    i5 = i25;
                    if (i4 < i5) {
                        childAt2 = getChildAt(i4);
                        if (childAt2.getVisibility() != 8) {
                            layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                            if (layoutParams2.height == -1) {
                                i13 = layoutParams2.width;
                                layoutParams2.width = childAt2.getMeasuredWidth();
                                measureChildWithMargins(childAt2, i, 0, i3, 0);
                                layoutParams2.width = i13;
                            }
                        }
                        i4++;
                        i25 = i5;
                    } else {
                        return;
                    }
                }
            }
        }
        f4 = r6.mWeightSum;
        if (f4 > 0.0f) {
            f5 = f4;
        }
        iArr[3] = -1;
        iArr[2] = -1;
        iArr[1] = -1;
        iArr[0] = -1;
        iArr2[3] = -1;
        iArr2[2] = -1;
        iArr2[1] = -1;
        iArr2[0] = -1;
        r6.mTotalLength = 0;
        i14 = combineMeasuredStates;
        mode = i24;
        combineMeasuredStates = 0;
        i6 = -1;
        while (combineMeasuredStates < i5) {
            childAt7 = getChildAt(combineMeasuredStates);
            if (childAt7 == null) {
                i25 = i5;
                i4 = i14;
                i5 = i9;
                i14 = i2;
                i9 = childCount;
            } else if (childAt7.getVisibility() != 8) {
                layoutParams8 = (LayoutParams) childAt7.getLayoutParams();
                f7 = layoutParams8.weight;
                if (f7 <= 0.0f) {
                    i25 = i5;
                    i4 = i14;
                    i14 = i2;
                } else {
                    i25 = i5;
                    i5 = (int) ((((float) i14) * f7) / f5);
                    f8 = f5 - f7;
                    i33 = i14 - i5;
                    mode2 = ViewGroup.getChildMeasureSpec(i2, ((getPaddingTop() + getPaddingBottom()) + layoutParams8.topMargin) + layoutParams8.bottomMargin, layoutParams8.height);
                    if (layoutParams8.width == 0) {
                        if (i15 == 1073741824) {
                            if (i5 <= 0) {
                                i5 = 0;
                            }
                            childAt7.measure(MeasureSpec.makeMeasureSpec(i5, 1073741824), mode2);
                            mode = View.combineMeasuredStates(mode, childAt7.getMeasuredState() & -16777216);
                            f5 = f8;
                            i4 = i33;
                        }
                    }
                    i4 = childAt7.getMeasuredWidth() + i5;
                    if (i4 < 0) {
                        i4 = 0;
                    }
                    childAt7.measure(MeasureSpec.makeMeasureSpec(i4, 1073741824), mode2);
                    mode = View.combineMeasuredStates(mode, childAt7.getMeasuredState() & -16777216);
                    f5 = f8;
                    i4 = i33;
                }
                if (childCount != 1073741824) {
                    f6 = f5;
                    mode2 = r6.mTotalLength;
                    i10 = mode;
                    r6.mTotalLength = Math.max(mode2, ((childAt7.getMeasuredWidth() + mode2) + layoutParams8.leftMargin) + layoutParams8.rightMargin);
                } else {
                    f6 = f5;
                    r6.mTotalLength += (childAt7.getMeasuredWidth() + layoutParams8.leftMargin) + layoutParams8.rightMargin;
                    i10 = mode;
                }
                i5 = i9;
                if (i5 == 1073741824) {
                }
                mode2 = 0;
                i9 = childCount;
                mode = layoutParams8.topMargin + layoutParams8.bottomMargin;
                childCount = childAt7.getMeasuredHeight() + mode;
                i6 = Math.max(i6, childCount);
                i28 = mode;
                if (1 == mode2) {
                    mode = i28;
                } else {
                    mode = childCount;
                }
                i8 = Math.max(i8, mode);
                if (obj8 == null) {
                    mode = -1;
                } else {
                    mode = -1;
                    if (layoutParams8.height == -1) {
                        obj10 = 1;
                        if (z2) {
                            i13 = childAt7.getBaseline();
                            if (i13 != mode) {
                                if (layoutParams8.gravity >= 0) {
                                }
                                mode = (((layoutParams8.gravity >= 0 ? r6.mGravity : layoutParams8.gravity) & 112) >> 4) >> 1;
                                iArr[mode] = Math.max(iArr[mode], i13);
                                iArr2[mode] = Math.max(iArr2[mode], childCount - i13);
                                obj8 = obj10;
                                mode = i10;
                                f5 = f6;
                            }
                        }
                        obj8 = obj10;
                        mode = i10;
                        f5 = f6;
                    }
                }
                obj10 = null;
                if (z2) {
                    i13 = childAt7.getBaseline();
                    if (i13 != mode) {
                        if (layoutParams8.gravity >= 0) {
                        }
                        mode = (((layoutParams8.gravity >= 0 ? r6.mGravity : layoutParams8.gravity) & 112) >> 4) >> 1;
                        iArr[mode] = Math.max(iArr[mode], i13);
                        iArr2[mode] = Math.max(iArr2[mode], childCount - i13);
                        obj8 = obj10;
                        mode = i10;
                        f5 = f6;
                    }
                }
                obj8 = obj10;
                mode = i10;
                f5 = f6;
            } else {
                i25 = i5;
                i4 = i14;
                i5 = i9;
                i14 = i2;
                i9 = childCount;
            }
            combineMeasuredStates++;
            i3 = i;
            i14 = i4;
            childCount = i9;
            i9 = i5;
            i5 = i25;
        }
        i14 = i2;
        i25 = i5;
        i5 = i9;
        r6.mTotalLength += getPaddingLeft() + getPaddingRight();
        combineMeasuredStates = iArr[1];
        if (combineMeasuredStates == -1) {
            if (iArr[0] == -1) {
            }
            combineMeasuredStates = -1;
        }
        i27 = Math.max(i6, Math.max(iArr[3], Math.max(iArr[0], Math.max(combineMeasuredStates, iArr[2]))) + Math.max(iArr2[3], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))));
        if (obj8 == null) {
        }
        i8 = i27;
        setMeasuredDimension((-16777216 & mode) | i11, View.resolveSizeAndState(Math.max(i8 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i14, mode << 16));
        if (obj != null) {
            i3 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
            i4 = 0;
            while (true) {
                i5 = i25;
                if (i4 < i5) {
                    childAt2 = getChildAt(i4);
                    if (childAt2.getVisibility() != 8) {
                        layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                        if (layoutParams2.height == -1) {
                            i13 = layoutParams2.width;
                            layoutParams2.width = childAt2.getMeasuredWidth();
                            measureChildWithMargins(childAt2, i, 0, i3, 0);
                            layoutParams2.width = i13;
                        }
                    }
                    i4++;
                    i25 = i5;
                } else {
                    return;
                }
            }
        }
    }
}
