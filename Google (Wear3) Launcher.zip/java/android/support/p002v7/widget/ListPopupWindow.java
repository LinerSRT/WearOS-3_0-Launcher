package android.support.p002v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.widget.PopupWindowCompat$Api19Impl;
import android.support.p000v4.widget.PopupWindowCompat$Api23Impl;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.view.menu.ShowableListMenu;
import android.support.p002v7.widget.DropDownListView;
import android.support.v7.widget.ListPopupWindow.C01033;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import com.google.android.libraries.wear.wcs.contract.deeplink.DeepLinkServiceResult;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ListPopupWindow */
public class ListPopupWindow implements ShowableListMenu {
    private ListAdapter mAdapter;
    private final Context mContext;
    public View mDropDownAnchorView;
    public int mDropDownGravity = 0;
    public int mDropDownHorizontalOffset;
    public DropDownListView mDropDownList;
    private int mDropDownVerticalOffset;
    private boolean mDropDownVerticalOffsetSet;
    public int mDropDownWidth = -2;
    private Rect mEpicenterBounds;
    final Handler mHandler;
    private final ListSelectorHider mHideSelector = new ListSelectorHider();
    public OnItemClickListener mItemClickListener;
    public boolean mModal;
    private DataSetObserver mObserver;
    public boolean mOverlapAnchor;
    public boolean mOverlapAnchorSet;
    public final PopupWindow mPopup;
    final ResizePopupRunnable mResizePopupRunnable = new ResizePopupRunnable();
    private final PopupScrollListener mScrollListener = new PopupScrollListener();
    private final Rect mTempRect = new Rect();
    private final PopupTouchInterceptor mTouchInterceptor = new PopupTouchInterceptor();

    /* renamed from: android.support.v7.widget.ListPopupWindow$2 */
    final class PG implements Runnable {
        public final void run() {
            View view = ListPopupWindow.this.mDropDownAnchorView;
            if (view != null && view.getWindowToken() != null) {
                ListPopupWindow.this.show();
            }
        }
    }

    /* renamed from: android.support.v7.widget.ListPopupWindow$3 */
    final class C01033 implements OnItemSelectedListener {
        public final void onItemSelected(AdapterView adapterView, View view, int i, long j) {
            if (i != -1) {
                DropDownListView dropDownListView = android.support.p002v7.widget.ListPopupWindow.this.mDropDownList;
                if (dropDownListView != null) {
                    dropDownListView.mListSelectionHidden = false;
                }
            }
        }

        public final void onNothingSelected(AdapterView adapterView) {
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ListPopupWindow$ListSelectorHider */
    final class ListSelectorHider implements Runnable {
        public final void run() {
            ListPopupWindow.this.clearListSelection();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ListPopupWindow$PopupDataSetObserver */
    final class PopupDataSetObserver extends DataSetObserver {
        public final void onChanged() {
            if (ListPopupWindow.this.isShowing()) {
                ListPopupWindow.this.show();
            }
        }

        public final void onInvalidated() {
            ListPopupWindow.this.dismiss();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ListPopupWindow$PopupScrollListener */
    final class PopupScrollListener implements OnScrollListener {
        public final void onScroll(AbsListView absListView, int i, int i2, int i3) {
        }

        public final void onScrollStateChanged(AbsListView absListView, int i) {
            if (i == 1 && !ListPopupWindow.this.isInputMethodNotNeeded() && ListPopupWindow.this.mPopup.getContentView() != null) {
                ListPopupWindow listPopupWindow = ListPopupWindow.this;
                listPopupWindow.mHandler.removeCallbacks(listPopupWindow.mResizePopupRunnable);
                ListPopupWindow.this.mResizePopupRunnable.run();
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ListPopupWindow$PopupTouchInterceptor */
    final class PopupTouchInterceptor implements OnTouchListener {
        public final boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            ListPopupWindow listPopupWindow;
            if (action == 0) {
                PopupWindow popupWindow = ListPopupWindow.this.mPopup;
                if (popupWindow != null && popupWindow.isShowing() && x >= 0 && x < ListPopupWindow.this.mPopup.getWidth() && y >= 0 && y < ListPopupWindow.this.mPopup.getHeight()) {
                    listPopupWindow = ListPopupWindow.this;
                    listPopupWindow.mHandler.postDelayed(listPopupWindow.mResizePopupRunnable, 250);
                }
            } else if (action == 1) {
                listPopupWindow = ListPopupWindow.this;
                listPopupWindow.mHandler.removeCallbacks(listPopupWindow.mResizePopupRunnable);
            }
            return false;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ListPopupWindow$ResizePopupRunnable */
    final class ResizePopupRunnable implements Runnable {
        public final void run() {
            View view = ListPopupWindow.this.mDropDownList;
            if (view != null && ViewCompat.isAttachedToWindow(view) && ListPopupWindow.this.mDropDownList.getCount() > ListPopupWindow.this.mDropDownList.getChildCount()) {
                ListPopupWindow.this.mDropDownList.getChildCount();
                ListPopupWindow.this.mPopup.setInputMethodMode(2);
                ListPopupWindow.this.show();
            }
        }
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i) {
        this.mContext = context;
        this.mHandler = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ListPopupWindow, i, 0);
        this.mDropDownHorizontalOffset = obtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.mDropDownVerticalOffset = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.mDropDownVerticalOffsetSet = true;
        }
        obtainStyledAttributes.recycle();
        PopupWindow appCompatPopupWindow = new AppCompatPopupWindow(context, attributeSet, i);
        this.mPopup = appCompatPopupWindow;
        appCompatPopupWindow.setInputMethodMode(1);
    }

    public final void clearListSelection() {
        DropDownListView dropDownListView = this.mDropDownList;
        if (dropDownListView != null) {
            dropDownListView.mListSelectionHidden = true;
            dropDownListView.requestLayout();
        }
    }

    public DropDownListView createDropDownListView(Context context, boolean z) {
        return new DropDownListView(context, z);
    }

    public final void dismiss() {
        this.mPopup.dismiss();
        this.mPopup.setContentView(null);
        this.mDropDownList = null;
        this.mHandler.removeCallbacks(this.mResizePopupRunnable);
    }

    public final Drawable getBackground() {
        return this.mPopup.getBackground();
    }

    public final int getHorizontalOffset() {
        return this.mDropDownHorizontalOffset;
    }

    public final ListView getListView() {
        return this.mDropDownList;
    }

    public final int getVerticalOffset() {
        return !this.mDropDownVerticalOffsetSet ? 0 : this.mDropDownVerticalOffset;
    }

    public final boolean isInputMethodNotNeeded() {
        return this.mPopup.getInputMethodMode() == 2;
    }

    public final boolean isShowing() {
        return this.mPopup.isShowing();
    }

    public void setAdapter(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.mObserver;
        if (dataSetObserver == null) {
            this.mObserver = new PopupDataSetObserver();
        } else {
            ListAdapter listAdapter2 = this.mAdapter;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.mAdapter = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.mObserver);
        }
        ListView listView = this.mDropDownList;
        if (listView != null) {
            listView.setAdapter(this.mAdapter);
        }
    }

    public final void setBackgroundDrawable(Drawable drawable) {
        this.mPopup.setBackgroundDrawable(drawable);
    }

    public final void setContentWidth(int i) {
        Drawable background = this.mPopup.getBackground();
        if (background != null) {
            background.getPadding(this.mTempRect);
            this.mDropDownWidth = (this.mTempRect.left + this.mTempRect.right) + i;
            return;
        }
        this.mDropDownWidth = i;
    }

    public final void setEpicenterBounds(Rect rect) {
        this.mEpicenterBounds = rect != null ? new Rect(rect) : null;
    }

    public final void setHorizontalOffset(int i) {
        this.mDropDownHorizontalOffset = i;
    }

    public final void setInputMethodMode$ar$ds() {
        this.mPopup.setInputMethodMode(2);
    }

    public final void setModal$ar$ds() {
        this.mModal = true;
        this.mPopup.setFocusable(true);
    }

    public final void setOnDismissListener(OnDismissListener onDismissListener) {
        this.mPopup.setOnDismissListener(onDismissListener);
    }

    public final void setVerticalOffset(int i) {
        this.mDropDownVerticalOffset = i;
        this.mDropDownVerticalOffsetSet = true;
    }

    public final void show() {
        int i;
        boolean z;
        if (this.mDropDownList == null) {
            Context context = this.mContext;
            PG pg = new PG();
            ListView createDropDownListView = createDropDownListView(context, this.mModal ^ true);
            this.mDropDownList = createDropDownListView;
            createDropDownListView.setAdapter(this.mAdapter);
            this.mDropDownList.setOnItemClickListener(this.mItemClickListener);
            this.mDropDownList.setFocusable(true);
            this.mDropDownList.setFocusableInTouchMode(true);
            this.mDropDownList.setOnItemSelectedListener(new C01033());
            this.mDropDownList.setOnScrollListener(this.mScrollListener);
            this.mPopup.setContentView(this.mDropDownList);
        } else {
            ViewGroup viewGroup = (ViewGroup) this.mPopup.getContentView();
        }
        Drawable background = this.mPopup.getBackground();
        int i2 = 0;
        if (background != null) {
            background.getPadding(this.mTempRect);
            i = this.mTempRect.top + this.mTempRect.bottom;
            if (!this.mDropDownVerticalOffsetSet) {
                this.mDropDownVerticalOffset = -this.mTempRect.top;
            }
        } else {
            this.mTempRect.setEmpty();
            i = 0;
        }
        if (this.mPopup.getInputMethodMode() == 2) {
            z = true;
        } else {
            z = false;
        }
        int maxAvailableHeight = this.mPopup.getMaxAvailableHeight(this.mDropDownAnchorView, this.mDropDownVerticalOffset, z);
        int i3 = this.mDropDownWidth;
        switch (i3) {
            case DeepLinkServiceResult.RPC_SEND_FAILURE /*-2*/:
                i3 = MeasureSpec.makeMeasureSpec(this.mContext.getResources().getDisplayMetrics().widthPixels - (this.mTempRect.left + this.mTempRect.right), LinearLayoutManager.INVALID_OFFSET);
                break;
            case -1:
                i3 = MeasureSpec.makeMeasureSpec(this.mContext.getResources().getDisplayMetrics().widthPixels - (this.mTempRect.left + this.mTempRect.right), 1073741824);
                break;
            default:
                i3 = MeasureSpec.makeMeasureSpec(i3, 1073741824);
                break;
        }
        maxAvailableHeight = this.mDropDownList.measureHeightOfChildrenCompat$ar$ds(i3, maxAvailableHeight);
        if (maxAvailableHeight > 0) {
            i2 = (this.mDropDownList.getPaddingTop() + this.mDropDownList.getPaddingBottom()) + i;
        }
        maxAvailableHeight += i2;
        isInputMethodNotNeeded();
        PopupWindowCompat$Api23Impl.setWindowLayoutType(this.mPopup, 1002);
        if (!this.mPopup.isShowing()) {
            i = this.mDropDownWidth;
            if (i == -1) {
                i = -1;
            } else if (i == -2) {
                i = this.mDropDownAnchorView.getWidth();
            }
            this.mPopup.setWidth(i);
            this.mPopup.setHeight(maxAvailableHeight);
            this.mPopup.setIsClippedToScreen(true);
            this.mPopup.setOutsideTouchable(true);
            this.mPopup.setTouchInterceptor(this.mTouchInterceptor);
            if (this.mOverlapAnchorSet) {
                PopupWindowCompat$Api23Impl.setOverlapAnchor(this.mPopup, this.mOverlapAnchor);
            }
            this.mPopup.setEpicenterBounds(this.mEpicenterBounds);
            PopupWindowCompat$Api19Impl.showAsDropDown(this.mPopup, this.mDropDownAnchorView, this.mDropDownHorizontalOffset, this.mDropDownVerticalOffset, this.mDropDownGravity);
            this.mDropDownList.setSelection(-1);
            if (!this.mModal || this.mDropDownList.isInTouchMode()) {
                clearListSelection();
            }
            if (!this.mModal) {
                this.mHandler.post(this.mHideSelector);
            }
        } else if (ViewCompat.isAttachedToWindow(this.mDropDownAnchorView)) {
            int i4;
            int i5;
            i = this.mDropDownWidth;
            if (i == -1) {
                i = -1;
            } else if (i == -2) {
                i = this.mDropDownAnchorView.getWidth();
            }
            this.mPopup.setOutsideTouchable(true);
            PopupWindow popupWindow = this.mPopup;
            View view = this.mDropDownAnchorView;
            int i6 = this.mDropDownHorizontalOffset;
            int i7 = this.mDropDownVerticalOffset;
            if (i < 0) {
                i4 = -1;
            } else {
                i4 = i;
            }
            if (maxAvailableHeight < 0) {
                i5 = -1;
            } else {
                i5 = maxAvailableHeight;
            }
            popupWindow.update(view, i6, i7, i4, i5);
        }
    }
}
