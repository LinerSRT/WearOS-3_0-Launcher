package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AppCompatSeekBar */
public final class AppCompatSeekBar extends SeekBar {
    private final AppCompatSeekBarHelper mAppCompatSeekBarHelper;

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        AppCompatSeekBarHelper appCompatSeekBarHelper = this.mAppCompatSeekBarHelper;
        Drawable drawable = appCompatSeekBarHelper.mTickMark;
        if (drawable != null && drawable.isStateful() && drawable.setState(appCompatSeekBarHelper.mView.getDrawableState())) {
            appCompatSeekBarHelper.mView.invalidateDrawable(drawable);
        }
    }

    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.mAppCompatSeekBarHelper.mTickMark;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    protected final synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        AppCompatSeekBarHelper appCompatSeekBarHelper = this.mAppCompatSeekBarHelper;
        if (appCompatSeekBarHelper.mTickMark != null) {
            int max = appCompatSeekBarHelper.mView.getMax();
            int i = 1;
            if (max > 1) {
                int intrinsicWidth = appCompatSeekBarHelper.mTickMark.getIntrinsicWidth();
                int intrinsicHeight = appCompatSeekBarHelper.mTickMark.getIntrinsicHeight();
                if (intrinsicWidth >= 0) {
                    intrinsicWidth >>= 1;
                } else {
                    intrinsicWidth = 1;
                }
                if (intrinsicHeight >= 0) {
                    i = intrinsicHeight >> 1;
                }
                appCompatSeekBarHelper.mTickMark.setBounds(-intrinsicWidth, -i, intrinsicWidth, i);
                float width = ((float) ((appCompatSeekBarHelper.mView.getWidth() - appCompatSeekBarHelper.mView.getPaddingLeft()) - appCompatSeekBarHelper.mView.getPaddingRight())) / ((float) max);
                intrinsicWidth = canvas.save();
                canvas.translate((float) appCompatSeekBarHelper.mView.getPaddingLeft(), (float) (appCompatSeekBarHelper.mView.getHeight() / 2));
                for (intrinsicHeight = 0; intrinsicHeight <= max; intrinsicHeight++) {
                    appCompatSeekBarHelper.mTickMark.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(intrinsicWidth);
            }
        }
    }

    public AppCompatSeekBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.seekBarStyle);
        ThemeUtils.checkAppCompatTheme(this, getContext());
        AppCompatProgressBarHelper appCompatSeekBarHelper = new AppCompatSeekBarHelper(this);
        this.mAppCompatSeekBarHelper = appCompatSeekBarHelper;
        appCompatSeekBarHelper.loadFromAttributes(attributeSet, R.attr.seekBarStyle);
    }
}
