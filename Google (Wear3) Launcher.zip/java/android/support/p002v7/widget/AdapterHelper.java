package android.support.p002v7.widget;

import android.support.p000v4.util.Pools$SimplePool;
import android.support.v7.widget.RecyclerView.C01096;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.AdapterHelper */
final class AdapterHelper {
    final C01096 mCallback$ar$class_merging;
    public int mExistingUpdateTypes = 0;
    final OpReorderer mOpReorderer;
    final ArrayList mPendingUpdates = new ArrayList();
    final ArrayList mPostponedList = new ArrayList();
    private final Pools$SimplePool mUpdateOpPool$ar$class_merging = new Pools$SimplePool(30);

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.AdapterHelper$UpdateOp */
    final class UpdateOp {
        int cmd;
        int itemCount;
        Object payload;
        int positionStart;

        public UpdateOp(int i, int i2, int i3, Object obj) {
            this.cmd = i;
            this.positionStart = i2;
            this.itemCount = i3;
            this.payload = obj;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof UpdateOp)) {
                return false;
            }
            UpdateOp updateOp = (UpdateOp) obj;
            int i = this.cmd;
            if (i != updateOp.cmd) {
                return false;
            }
            if (i == 8 && Math.abs(this.itemCount - this.positionStart) == 1 && this.itemCount == updateOp.positionStart) {
                if (this.positionStart == updateOp.itemCount) {
                    return true;
                }
            }
            if (this.itemCount != updateOp.itemCount || this.positionStart != updateOp.positionStart) {
                return false;
            }
            Object obj2 = this.payload;
            if (obj2 != null) {
                if (!obj2.equals(updateOp.payload)) {
                    return false;
                }
            } else if (updateOp.payload != null) {
                return false;
            }
            return true;
        }

        public final int hashCode() {
            return (((this.cmd * 31) + this.positionStart) * 31) + this.itemCount;
        }

        public final String toString() {
            String str;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append("[");
            switch (this.cmd) {
                case 1:
                    str = "add";
                    break;
                case 2:
                    str = "rm";
                    break;
                case 4:
                    str = "up";
                    break;
                case 8:
                    str = "mv";
                    break;
                default:
                    str = "??";
                    break;
            }
            stringBuilder.append(str);
            stringBuilder.append(",s:");
            stringBuilder.append(this.positionStart);
            stringBuilder.append("c:");
            stringBuilder.append(this.itemCount);
            stringBuilder.append(",p:");
            stringBuilder.append(this.payload);
            stringBuilder.append("]");
            return stringBuilder.toString();
        }
    }

    private final boolean canFindInPreLayout(int i) {
        int size = this.mPostponedList.size();
        for (int i2 = 0; i2 < size; i2++) {
            UpdateOp updateOp = (UpdateOp) this.mPostponedList.get(i2);
            int i3 = updateOp.cmd;
            if (i3 == 8) {
                if (findPositionOffset(updateOp.itemCount, i2 + 1) == i) {
                    return true;
                }
            } else if (i3 == 1) {
                i3 = updateOp.positionStart;
                int i4 = updateOp.itemCount + i3;
                while (i3 < i4) {
                    if (findPositionOffset(i3, i2 + 1) == i) {
                        return true;
                    }
                    i3++;
                }
                continue;
            } else {
                continue;
            }
        }
        return false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void dispatchAndUpdateViewHolders(android.support.p002v7.widget.AdapterHelper.UpdateOp r11) {
        /*
        r10 = this;
        r0 = r11.cmd;
        r1 = 1;
        if (r0 == r1) goto L_0x0082;
    L_0x0005:
        r2 = 8;
        if (r0 == r2) goto L_0x0082;
    L_0x0009:
        r2 = r11.positionStart;
        r0 = r10.updatePositionWithPostponed(r2, r0);
        r2 = r11.positionStart;
        r3 = r11.cmd;
        r4 = 0;
        switch(r3) {
            case 2: goto L_0x0030;
            case 3: goto L_0x0017;
            case 4: goto L_0x002e;
            default: goto L_0x0017;
        };
    L_0x0017:
        r0 = new java.lang.IllegalArgumentException;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "op should be remove or update.";
        r1.append(r2);
        r1.append(r11);
        r11 = r1.toString();
        r0.<init>(r11);
        throw r0;
    L_0x002e:
        r3 = 1;
        goto L_0x0031;
    L_0x0030:
        r3 = 0;
    L_0x0031:
        r5 = 1;
        r6 = 1;
    L_0x0033:
        r7 = r11.itemCount;
        if (r5 >= r7) goto L_0x006e;
    L_0x0037:
        r7 = r11.positionStart;
        r8 = r3 * r5;
        r7 = r7 + r8;
        r8 = r11.cmd;
        r7 = r10.updatePositionWithPostponed(r7, r8);
        r8 = r11.cmd;
        switch(r8) {
            case 2: goto L_0x004d;
            case 3: goto L_0x0047;
            case 4: goto L_0x0048;
            default: goto L_0x0047;
        };
    L_0x0047:
        goto L_0x0057;
    L_0x0048:
        r9 = r0 + 1;
        if (r7 != r9) goto L_0x0051;
    L_0x004c:
        goto L_0x004f;
    L_0x004d:
        if (r7 != r0) goto L_0x0051;
    L_0x004f:
        r9 = 1;
        goto L_0x0052;
    L_0x0051:
        r9 = 0;
    L_0x0052:
        if (r9 == 0) goto L_0x0057;
    L_0x0054:
        r6 = r6 + 1;
        goto L_0x006b;
    L_0x0057:
        r9 = r11.payload;
        r0 = r10.obtainUpdateOp(r8, r0, r6, r9);
        r10.dispatchFirstPassAndUpdateViewHolders(r0, r2);
        r10.recycleUpdateOp(r0);
        r0 = r11.cmd;
        r8 = 4;
        if (r0 != r8) goto L_0x0069;
    L_0x0068:
        r2 = r2 + r6;
    L_0x0069:
        r0 = r7;
        r6 = 1;
    L_0x006b:
        r5 = r5 + 1;
        goto L_0x0033;
    L_0x006e:
        r1 = r11.payload;
        r10.recycleUpdateOp(r11);
        if (r6 <= 0) goto L_0x0081;
    L_0x0075:
        r11 = r11.cmd;
        r11 = r10.obtainUpdateOp(r11, r0, r6, r1);
        r10.dispatchFirstPassAndUpdateViewHolders(r11, r2);
        r10.recycleUpdateOp(r11);
    L_0x0081:
        return;
    L_0x0082:
        r11 = new java.lang.IllegalArgumentException;
        r0 = "should not dispatch add or move for pre layout";
        r11.<init>(r0);
        goto L_0x008b;
    L_0x008a:
        throw r11;
    L_0x008b:
        goto L_0x008a;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.AdapterHelper.dispatchAndUpdateViewHolders(android.support.v7.widget.AdapterHelper$UpdateOp):void");
    }

    private final void postponeAndUpdateViewHolders(UpdateOp updateOp) {
        this.mPostponedList.add(updateOp);
        switch (updateOp.cmd) {
            case 1:
                this.mCallback$ar$class_merging.offsetPositionsForAdd(updateOp.positionStart, updateOp.itemCount);
                return;
            case 2:
                C01096 c01096 = this.mCallback$ar$class_merging;
                c01096.this$0.offsetPositionRecordsForRemove(updateOp.positionStart, updateOp.itemCount, false);
                c01096.this$0.mItemsAddedOrRemoved = true;
                return;
            case 4:
                this.mCallback$ar$class_merging.markViewHoldersUpdated(updateOp.positionStart, updateOp.itemCount, updateOp.payload);
                return;
            case 8:
                this.mCallback$ar$class_merging.offsetPositionsForMove(updateOp.positionStart, updateOp.itemCount);
                return;
            default:
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unknown update op type for ");
                stringBuilder.append(updateOp);
                throw new IllegalArgumentException(stringBuilder.toString());
        }
    }

    private final int updatePositionWithPostponed(int i, int i2) {
        for (int size = this.mPostponedList.size() - 1; size >= 0; size--) {
            UpdateOp updateOp = (UpdateOp) this.mPostponedList.get(size);
            int i3 = updateOp.cmd;
            int i4;
            if (i3 == 8) {
                int i5;
                i4 = updateOp.positionStart;
                i3 = updateOp.itemCount;
                int i6;
                if (i4 < i3) {
                    i6 = i3;
                } else {
                    i6 = i4;
                }
                if (i4 < i3) {
                    i5 = i4;
                } else {
                    i5 = i3;
                }
                if (i < i5 || i > i6) {
                    if (i < i4) {
                        if (i2 == 1) {
                            updateOp.positionStart = i4 + 1;
                            updateOp.itemCount = i3 + 1;
                        } else if (i2 == 2) {
                            updateOp.positionStart = i4 - 1;
                            updateOp.itemCount = i3 - 1;
                        }
                    }
                } else if (i5 == i4) {
                    if (i2 == 1) {
                        updateOp.itemCount = i3 + 1;
                    } else if (i2 == 2) {
                        updateOp.itemCount = i3 - 1;
                    }
                    i++;
                } else {
                    if (i2 == 1) {
                        updateOp.positionStart = i4 + 1;
                    } else if (i2 == 2) {
                        updateOp.positionStart = i4 - 1;
                    }
                    i--;
                }
            } else {
                i4 = updateOp.positionStart;
                if (i4 <= i) {
                    if (i3 == 1) {
                        i -= updateOp.itemCount;
                    } else if (i3 == 2) {
                        i += updateOp.itemCount;
                    }
                } else if (i2 == 1) {
                    updateOp.positionStart = i4 + 1;
                } else if (i2 == 2) {
                    updateOp.positionStart = i4 - 1;
                }
            }
        }
        for (i2 = this.mPostponedList.size() - 1; i2 >= 0; i2--) {
            UpdateOp updateOp2 = (UpdateOp) this.mPostponedList.get(i2);
            if (updateOp2.cmd == 8) {
                int i7 = updateOp2.itemCount;
                if (i7 == updateOp2.positionStart || i7 < 0) {
                    this.mPostponedList.remove(i2);
                    recycleUpdateOp(updateOp2);
                }
            } else if (updateOp2.itemCount <= 0) {
                this.mPostponedList.remove(i2);
                recycleUpdateOp(updateOp2);
            }
        }
        return i;
    }

    final void consumePostponedUpdates() {
        int size = this.mPostponedList.size();
        for (int i = 0; i < size; i++) {
            this.mCallback$ar$class_merging.dispatchUpdate((UpdateOp) this.mPostponedList.get(i));
        }
        recycleUpdateOpsAndClearList(this.mPostponedList);
        this.mExistingUpdateTypes = 0;
    }

    final void consumeUpdatesInOnePass() {
        consumePostponedUpdates();
        int size = this.mPendingUpdates.size();
        for (int i = 0; i < size; i++) {
            UpdateOp updateOp = (UpdateOp) this.mPendingUpdates.get(i);
            switch (updateOp.cmd) {
                case 1:
                    this.mCallback$ar$class_merging.dispatchUpdate(updateOp);
                    this.mCallback$ar$class_merging.offsetPositionsForAdd(updateOp.positionStart, updateOp.itemCount);
                    break;
                case 2:
                    this.mCallback$ar$class_merging.dispatchUpdate(updateOp);
                    this.mCallback$ar$class_merging.offsetPositionsForRemovingInvisible(updateOp.positionStart, updateOp.itemCount);
                    break;
                case 4:
                    this.mCallback$ar$class_merging.dispatchUpdate(updateOp);
                    this.mCallback$ar$class_merging.markViewHoldersUpdated(updateOp.positionStart, updateOp.itemCount, updateOp.payload);
                    break;
                case 8:
                    this.mCallback$ar$class_merging.dispatchUpdate(updateOp);
                    this.mCallback$ar$class_merging.offsetPositionsForMove(updateOp.positionStart, updateOp.itemCount);
                    break;
                default:
                    break;
            }
        }
        recycleUpdateOpsAndClearList(this.mPendingUpdates);
        this.mExistingUpdateTypes = 0;
    }

    final int findPositionOffset(int i) {
        return findPositionOffset(i, 0);
    }

    final boolean hasAnyUpdateTypes(int i) {
        return (i & this.mExistingUpdateTypes) != 0;
    }

    final boolean hasPendingUpdates() {
        return this.mPendingUpdates.size() > 0;
    }

    public final UpdateOp obtainUpdateOp(int i, int i2, int i3, Object obj) {
        UpdateOp updateOp = (UpdateOp) this.mUpdateOpPool$ar$class_merging.acquire();
        if (updateOp == null) {
            return new UpdateOp(i, i2, i3, obj);
        }
        updateOp.cmd = i;
        updateOp.positionStart = i2;
        updateOp.itemCount = i3;
        updateOp.payload = obj;
        return updateOp;
    }

    public final void recycleUpdateOp(UpdateOp updateOp) {
        updateOp.payload = null;
        this.mUpdateOpPool$ar$class_merging.release(updateOp);
    }

    final void recycleUpdateOpsAndClearList(List list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            recycleUpdateOp((UpdateOp) list.get(i));
        }
        list.clear();
    }

    final void reset() {
        recycleUpdateOpsAndClearList(this.mPendingUpdates);
        recycleUpdateOpsAndClearList(this.mPostponedList);
        this.mExistingUpdateTypes = 0;
    }

    public AdapterHelper(C01096 c01096) {
        this.mCallback$ar$class_merging = c01096;
        this.mOpReorderer = new OpReorderer(this);
    }

    final void dispatchFirstPassAndUpdateViewHolders(UpdateOp updateOp, int i) {
        this.mCallback$ar$class_merging.dispatchUpdate(updateOp);
        switch (updateOp.cmd) {
            case 2:
                this.mCallback$ar$class_merging.offsetPositionsForRemovingInvisible(i, updateOp.itemCount);
                return;
            case 4:
                this.mCallback$ar$class_merging.markViewHoldersUpdated(i, updateOp.itemCount, updateOp.payload);
                return;
            default:
                throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
        }
    }

    final int findPositionOffset(int i, int i2) {
        int size = this.mPostponedList.size();
        while (i2 < size) {
            UpdateOp updateOp = (UpdateOp) this.mPostponedList.get(i2);
            int i3 = updateOp.cmd;
            if (i3 == 8) {
                i3 = updateOp.positionStart;
                if (i3 == i) {
                    i = updateOp.itemCount;
                } else {
                    if (i3 < i) {
                        i--;
                    }
                    if (updateOp.itemCount <= i) {
                        i++;
                    }
                }
            } else {
                int i4 = updateOp.positionStart;
                if (i4 > i) {
                    continue;
                } else if (i3 == 2) {
                    int i5 = updateOp.itemCount;
                    if (i < i4 + i5) {
                        return -1;
                    }
                    i -= i5;
                } else if (i3 == 1) {
                    i += updateOp.itemCount;
                }
            }
            i2++;
        }
        return i;
    }

    final void preProcess() {
        OpReorderer opReorderer = this.mOpReorderer;
        List list = this.mPendingUpdates;
        while (true) {
            UpdateOp updateOp;
            int i = -1;
            int size = list.size() - 1;
            Object obj = null;
            Object obj2 = null;
            while (size >= 0) {
                int i2;
                UpdateOp updateOp2;
                UpdateOp updateOp3;
                int i3;
                int i4;
                int i5;
                int i6;
                Object obj3;
                int i7;
                int i8;
                Object obtainUpdateOp;
                int size2;
                int i9;
                UpdateOp updateOp4;
                int i10;
                int i11;
                Object obj4;
                Object obj5;
                if (((UpdateOp) list.get(size)).cmd != 8) {
                    obj2 = 1;
                } else if (obj2 != null) {
                    updateOp = null;
                    if (size != -1) {
                        i2 = size + 1;
                        updateOp2 = (UpdateOp) list.get(size);
                        updateOp3 = (UpdateOp) list.get(i2);
                        switch (updateOp3.cmd) {
                            case 1:
                                i3 = updateOp2.itemCount;
                                i4 = updateOp3.positionStart;
                                if (i3 < i4) {
                                    i = 0;
                                }
                                i5 = updateOp2.positionStart;
                                if (i5 < i4) {
                                    i++;
                                }
                                if (i4 <= i5) {
                                    updateOp2.positionStart = i5 + updateOp3.itemCount;
                                }
                                i5 = updateOp3.positionStart;
                                if (i5 <= i3) {
                                    updateOp2.itemCount = i3 + updateOp3.itemCount;
                                }
                                updateOp3.positionStart = i5 + i;
                                list.set(size, updateOp3);
                                list.set(i2, updateOp2);
                                break;
                            case 2:
                                i = updateOp2.positionStart;
                                i6 = updateOp2.itemCount;
                                if (i >= i6) {
                                    if (updateOp3.positionStart == i || updateOp3.itemCount != i6 - i) {
                                        obj3 = null;
                                    } else {
                                        obj3 = null;
                                        obj = 1;
                                    }
                                } else if (updateOp3.positionStart == i6 + 1 || updateOp3.itemCount != i - i6) {
                                    obj3 = 1;
                                } else {
                                    obj3 = 1;
                                    obj = 1;
                                }
                                i7 = updateOp3.positionStart;
                                if (i6 >= i7) {
                                    i7--;
                                    updateOp3.positionStart = i7;
                                } else {
                                    i8 = updateOp3.itemCount;
                                    if (i6 < i7 + i8) {
                                        updateOp3.itemCount = i8 - 1;
                                        updateOp2.cmd = 2;
                                        updateOp2.itemCount = 1;
                                        if (updateOp3.itemCount != 0) {
                                            break;
                                        }
                                        list.remove(i2);
                                        opReorderer.mCallback$ar$class_merging$f11fd352_0.recycleUpdateOp(updateOp3);
                                        break;
                                    }
                                }
                                i4 = updateOp2.positionStart;
                                if (i4 > i7) {
                                    updateOp3.positionStart = i7 + 1;
                                } else {
                                    i7 += updateOp3.itemCount;
                                    if (i4 < i7) {
                                        updateOp = opReorderer.mCallback$ar$class_merging$f11fd352_0.obtainUpdateOp(2, i4 + 1, i7 - i4, null);
                                        updateOp3.itemCount = updateOp2.positionStart - updateOp3.positionStart;
                                    }
                                }
                                if (obj == null) {
                                    if (obj3 == null) {
                                        if (updateOp != null) {
                                            i = updateOp2.positionStart;
                                            if (i > updateOp.positionStart) {
                                                updateOp2.positionStart = i - updateOp.itemCount;
                                            }
                                            i = updateOp2.itemCount;
                                            if (i > updateOp.positionStart) {
                                                updateOp2.itemCount = i - updateOp.itemCount;
                                            }
                                        }
                                        i = updateOp2.positionStart;
                                        if (i > updateOp3.positionStart) {
                                            updateOp2.positionStart = i - updateOp3.itemCount;
                                        }
                                        i = updateOp2.itemCount;
                                        if (i > updateOp3.positionStart) {
                                            updateOp2.itemCount = i - updateOp3.itemCount;
                                        }
                                    } else {
                                        if (updateOp != null) {
                                            i = updateOp2.positionStart;
                                            if (i >= updateOp.positionStart) {
                                                updateOp2.positionStart = i - updateOp.itemCount;
                                            }
                                            i = updateOp2.itemCount;
                                            if (i >= updateOp.positionStart) {
                                                updateOp2.itemCount = i - updateOp.itemCount;
                                            }
                                        }
                                        i = updateOp2.positionStart;
                                        if (i >= updateOp3.positionStart) {
                                            updateOp2.positionStart = i - updateOp3.itemCount;
                                        }
                                        i = updateOp2.itemCount;
                                        if (i >= updateOp3.positionStart) {
                                            updateOp2.itemCount = i - updateOp3.itemCount;
                                        }
                                    }
                                    list.set(size, updateOp3);
                                    if (updateOp2.positionStart == updateOp2.itemCount) {
                                        list.set(i2, updateOp2);
                                    } else {
                                        list.remove(i2);
                                    }
                                    if (updateOp == null) {
                                        break;
                                    }
                                    list.add(size, updateOp);
                                    break;
                                }
                                list.set(size, updateOp3);
                                list.remove(i2);
                                opReorderer.mCallback$ar$class_merging$f11fd352_0.recycleUpdateOp(updateOp2);
                                break;
                            case 4:
                                i = updateOp2.itemCount;
                                i5 = updateOp3.positionStart;
                                if (i >= i5) {
                                    updateOp3.positionStart = i5 - 1;
                                    obj3 = null;
                                } else {
                                    i3 = updateOp3.itemCount;
                                    if (i >= i5 + i3) {
                                        updateOp3.itemCount = i3 - 1;
                                        obj3 = opReorderer.mCallback$ar$class_merging$f11fd352_0.obtainUpdateOp(4, updateOp2.positionStart, 1, updateOp3.payload);
                                    } else {
                                        obj3 = null;
                                    }
                                }
                                i5 = updateOp2.positionStart;
                                i3 = updateOp3.positionStart;
                                if (i5 > i3) {
                                    updateOp3.positionStart = i3 + 1;
                                } else {
                                    i3 += updateOp3.itemCount;
                                    if (i5 < i3) {
                                        i3 -= i5;
                                        obtainUpdateOp = opReorderer.mCallback$ar$class_merging$f11fd352_0.obtainUpdateOp(4, i5 + 1, i3, updateOp3.payload);
                                        updateOp3.itemCount -= i3;
                                    }
                                }
                                list.set(i2, updateOp2);
                                if (updateOp3.itemCount <= 0) {
                                    list.set(size, updateOp3);
                                } else {
                                    list.remove(size);
                                    opReorderer.mCallback$ar$class_merging$f11fd352_0.recycleUpdateOp(updateOp3);
                                }
                                if (obj3 != null) {
                                    list.add(size, obj3);
                                }
                                if (obtainUpdateOp == null) {
                                    break;
                                }
                                list.add(size, obtainUpdateOp);
                                break;
                            default:
                                break;
                        }
                    }
                    size2 = this.mPendingUpdates.size();
                    for (i9 = 0; i9 < size2; i9++) {
                        updateOp4 = (UpdateOp) this.mPendingUpdates.get(i9);
                        switch (updateOp4.cmd) {
                            case 1:
                                postponeAndUpdateViewHolders(updateOp4);
                                break;
                            case 2:
                                i2 = updateOp4.positionStart;
                                i10 = updateOp4.itemCount + i2;
                                i11 = i2;
                                i7 = 0;
                                obj4 = -1;
                                while (i11 < i10) {
                                    if (this.mCallback$ar$class_merging.findViewHolder(i11) == null) {
                                        if (canFindInPreLayout(i11)) {
                                            if (obj4 != 1) {
                                                postponeAndUpdateViewHolders(obtainUpdateOp(2, i2, i7, null));
                                                obj4 = 1;
                                            } else {
                                                obj4 = null;
                                            }
                                            obj5 = null;
                                            if (obj4 == null) {
                                                i11 -= i7;
                                                i10 -= i7;
                                                i7 = 1;
                                            } else {
                                                i7++;
                                            }
                                            i11++;
                                            obj4 = obj5;
                                        }
                                    }
                                    if (obj4 != null) {
                                        dispatchAndUpdateViewHolders(obtainUpdateOp(2, i2, i7, null));
                                        obj4 = 1;
                                    } else {
                                        obj4 = null;
                                    }
                                    obj5 = 1;
                                    if (obj4 == null) {
                                        i7++;
                                    } else {
                                        i11 -= i7;
                                        i10 -= i7;
                                        i7 = 1;
                                    }
                                    i11++;
                                    obj4 = obj5;
                                }
                                if (i7 != updateOp4.itemCount) {
                                    recycleUpdateOp(updateOp4);
                                    updateOp4 = obtainUpdateOp(2, i2, i7, null);
                                }
                                if (obj4 != null) {
                                    postponeAndUpdateViewHolders(updateOp4);
                                    break;
                                } else {
                                    dispatchAndUpdateViewHolders(updateOp4);
                                    break;
                                }
                            case 4:
                                i2 = updateOp4.positionStart;
                                i10 = updateOp4.itemCount + i2;
                                i11 = i2;
                                i7 = 0;
                                obj4 = -1;
                                while (i2 < i10) {
                                    if (this.mCallback$ar$class_merging.findViewHolder(i2) == null) {
                                        if (canFindInPreLayout(i2)) {
                                            if (obj4 == 1) {
                                                postponeAndUpdateViewHolders(obtainUpdateOp(4, i11, i7, updateOp4.payload));
                                                i11 = i2;
                                                i7 = 0;
                                            }
                                            obj4 = null;
                                            i7++;
                                            i2++;
                                        }
                                    }
                                    if (obj4 == null) {
                                        dispatchAndUpdateViewHolders(obtainUpdateOp(4, i11, i7, updateOp4.payload));
                                        i11 = i2;
                                        i7 = 0;
                                    }
                                    obj4 = 1;
                                    i7++;
                                    i2++;
                                }
                                if (i7 != updateOp4.itemCount) {
                                    Object obj6 = updateOp4.payload;
                                    recycleUpdateOp(updateOp4);
                                    updateOp4 = obtainUpdateOp(4, i11, i7, obj6);
                                }
                                if (obj4 != null) {
                                    postponeAndUpdateViewHolders(updateOp4);
                                    break;
                                } else {
                                    dispatchAndUpdateViewHolders(updateOp4);
                                    break;
                                }
                            case 8:
                                postponeAndUpdateViewHolders(updateOp4);
                                break;
                            default:
                                break;
                        }
                    }
                    this.mPendingUpdates.clear();
                    return;
                } else {
                    obj2 = null;
                }
                size--;
            }
            size = -1;
            updateOp = null;
            if (size != -1) {
                i2 = size + 1;
                updateOp2 = (UpdateOp) list.get(size);
                updateOp3 = (UpdateOp) list.get(i2);
                switch (updateOp3.cmd) {
                    case 1:
                        i3 = updateOp2.itemCount;
                        i4 = updateOp3.positionStart;
                        if (i3 < i4) {
                            i = 0;
                        }
                        i5 = updateOp2.positionStart;
                        if (i5 < i4) {
                            i++;
                        }
                        if (i4 <= i5) {
                            updateOp2.positionStart = i5 + updateOp3.itemCount;
                        }
                        i5 = updateOp3.positionStart;
                        if (i5 <= i3) {
                            updateOp2.itemCount = i3 + updateOp3.itemCount;
                        }
                        updateOp3.positionStart = i5 + i;
                        list.set(size, updateOp3);
                        list.set(i2, updateOp2);
                        break;
                    case 2:
                        i = updateOp2.positionStart;
                        i6 = updateOp2.itemCount;
                        if (i >= i6) {
                            if (updateOp3.positionStart == i6 + 1) {
                                break;
                            }
                            obj3 = 1;
                        } else {
                            if (updateOp3.positionStart == i) {
                                break;
                            }
                            obj3 = null;
                        }
                        i7 = updateOp3.positionStart;
                        if (i6 >= i7) {
                            i8 = updateOp3.itemCount;
                            if (i6 < i7 + i8) {
                                updateOp3.itemCount = i8 - 1;
                                updateOp2.cmd = 2;
                                updateOp2.itemCount = 1;
                                if (updateOp3.itemCount != 0) {
                                    list.remove(i2);
                                    opReorderer.mCallback$ar$class_merging$f11fd352_0.recycleUpdateOp(updateOp3);
                                    break;
                                }
                                break;
                            }
                        } else {
                            i7--;
                            updateOp3.positionStart = i7;
                        }
                        i4 = updateOp2.positionStart;
                        if (i4 > i7) {
                            i7 += updateOp3.itemCount;
                            if (i4 < i7) {
                                updateOp = opReorderer.mCallback$ar$class_merging$f11fd352_0.obtainUpdateOp(2, i4 + 1, i7 - i4, null);
                                updateOp3.itemCount = updateOp2.positionStart - updateOp3.positionStart;
                            }
                        } else {
                            updateOp3.positionStart = i7 + 1;
                        }
                        if (obj == null) {
                            list.set(size, updateOp3);
                            list.remove(i2);
                            opReorderer.mCallback$ar$class_merging$f11fd352_0.recycleUpdateOp(updateOp2);
                            break;
                        }
                        if (obj3 == null) {
                            if (updateOp != null) {
                                i = updateOp2.positionStart;
                                if (i >= updateOp.positionStart) {
                                    updateOp2.positionStart = i - updateOp.itemCount;
                                }
                                i = updateOp2.itemCount;
                                if (i >= updateOp.positionStart) {
                                    updateOp2.itemCount = i - updateOp.itemCount;
                                }
                            }
                            i = updateOp2.positionStart;
                            if (i >= updateOp3.positionStart) {
                                updateOp2.positionStart = i - updateOp3.itemCount;
                            }
                            i = updateOp2.itemCount;
                            if (i >= updateOp3.positionStart) {
                                updateOp2.itemCount = i - updateOp3.itemCount;
                            }
                        } else {
                            if (updateOp != null) {
                                i = updateOp2.positionStart;
                                if (i > updateOp.positionStart) {
                                    updateOp2.positionStart = i - updateOp.itemCount;
                                }
                                i = updateOp2.itemCount;
                                if (i > updateOp.positionStart) {
                                    updateOp2.itemCount = i - updateOp.itemCount;
                                }
                            }
                            i = updateOp2.positionStart;
                            if (i > updateOp3.positionStart) {
                                updateOp2.positionStart = i - updateOp3.itemCount;
                            }
                            i = updateOp2.itemCount;
                            if (i > updateOp3.positionStart) {
                                updateOp2.itemCount = i - updateOp3.itemCount;
                            }
                        }
                        list.set(size, updateOp3);
                        if (updateOp2.positionStart == updateOp2.itemCount) {
                            list.remove(i2);
                        } else {
                            list.set(i2, updateOp2);
                        }
                        if (updateOp == null) {
                            list.add(size, updateOp);
                            break;
                        }
                        break;
                    case 4:
                        i = updateOp2.itemCount;
                        i5 = updateOp3.positionStart;
                        if (i >= i5) {
                            i3 = updateOp3.itemCount;
                            if (i >= i5 + i3) {
                                obj3 = null;
                            } else {
                                updateOp3.itemCount = i3 - 1;
                                obj3 = opReorderer.mCallback$ar$class_merging$f11fd352_0.obtainUpdateOp(4, updateOp2.positionStart, 1, updateOp3.payload);
                            }
                        } else {
                            updateOp3.positionStart = i5 - 1;
                            obj3 = null;
                        }
                        i5 = updateOp2.positionStart;
                        i3 = updateOp3.positionStart;
                        if (i5 > i3) {
                            i3 += updateOp3.itemCount;
                            if (i5 < i3) {
                                i3 -= i5;
                                obtainUpdateOp = opReorderer.mCallback$ar$class_merging$f11fd352_0.obtainUpdateOp(4, i5 + 1, i3, updateOp3.payload);
                                updateOp3.itemCount -= i3;
                            }
                        } else {
                            updateOp3.positionStart = i3 + 1;
                        }
                        list.set(i2, updateOp2);
                        if (updateOp3.itemCount <= 0) {
                            list.remove(size);
                            opReorderer.mCallback$ar$class_merging$f11fd352_0.recycleUpdateOp(updateOp3);
                        } else {
                            list.set(size, updateOp3);
                        }
                        if (obj3 != null) {
                            list.add(size, obj3);
                        }
                        if (obtainUpdateOp == null) {
                            list.add(size, obtainUpdateOp);
                            break;
                        }
                        break;
                    default:
                        break;
                }
            }
            size2 = this.mPendingUpdates.size();
            for (i9 = 0; i9 < size2; i9++) {
                updateOp4 = (UpdateOp) this.mPendingUpdates.get(i9);
                switch (updateOp4.cmd) {
                    case 1:
                        postponeAndUpdateViewHolders(updateOp4);
                        break;
                    case 2:
                        i2 = updateOp4.positionStart;
                        i10 = updateOp4.itemCount + i2;
                        i11 = i2;
                        i7 = 0;
                        obj4 = -1;
                        while (i11 < i10) {
                            if (this.mCallback$ar$class_merging.findViewHolder(i11) == null) {
                                if (canFindInPreLayout(i11)) {
                                    if (obj4 != 1) {
                                        obj4 = null;
                                    } else {
                                        postponeAndUpdateViewHolders(obtainUpdateOp(2, i2, i7, null));
                                        obj4 = 1;
                                    }
                                    obj5 = null;
                                    if (obj4 == null) {
                                        i11 -= i7;
                                        i10 -= i7;
                                        i7 = 1;
                                    } else {
                                        i7++;
                                    }
                                    i11++;
                                    obj4 = obj5;
                                }
                            }
                            if (obj4 != null) {
                                obj4 = null;
                            } else {
                                dispatchAndUpdateViewHolders(obtainUpdateOp(2, i2, i7, null));
                                obj4 = 1;
                            }
                            obj5 = 1;
                            if (obj4 == null) {
                                i7++;
                            } else {
                                i11 -= i7;
                                i10 -= i7;
                                i7 = 1;
                            }
                            i11++;
                            obj4 = obj5;
                        }
                        if (i7 != updateOp4.itemCount) {
                            recycleUpdateOp(updateOp4);
                            updateOp4 = obtainUpdateOp(2, i2, i7, null);
                        }
                        if (obj4 != null) {
                            dispatchAndUpdateViewHolders(updateOp4);
                            break;
                        } else {
                            postponeAndUpdateViewHolders(updateOp4);
                            break;
                        }
                    case 4:
                        i2 = updateOp4.positionStart;
                        i10 = updateOp4.itemCount + i2;
                        i11 = i2;
                        i7 = 0;
                        obj4 = -1;
                        while (i2 < i10) {
                            if (this.mCallback$ar$class_merging.findViewHolder(i2) == null) {
                                if (canFindInPreLayout(i2)) {
                                    if (obj4 == 1) {
                                        postponeAndUpdateViewHolders(obtainUpdateOp(4, i11, i7, updateOp4.payload));
                                        i11 = i2;
                                        i7 = 0;
                                    }
                                    obj4 = null;
                                    i7++;
                                    i2++;
                                }
                            }
                            if (obj4 == null) {
                                dispatchAndUpdateViewHolders(obtainUpdateOp(4, i11, i7, updateOp4.payload));
                                i11 = i2;
                                i7 = 0;
                            }
                            obj4 = 1;
                            i7++;
                            i2++;
                        }
                        if (i7 != updateOp4.itemCount) {
                            Object obj62 = updateOp4.payload;
                            recycleUpdateOp(updateOp4);
                            updateOp4 = obtainUpdateOp(4, i11, i7, obj62);
                        }
                        if (obj4 != null) {
                            dispatchAndUpdateViewHolders(updateOp4);
                            break;
                        } else {
                            postponeAndUpdateViewHolders(updateOp4);
                            break;
                        }
                    case 8:
                        postponeAndUpdateViewHolders(updateOp4);
                        break;
                    default:
                        break;
                }
            }
            this.mPendingUpdates.clear();
            return;
        }
    }
}
