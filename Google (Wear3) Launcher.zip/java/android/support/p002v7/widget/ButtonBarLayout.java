package android.support.p002v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.p000v4.view.ViewCompat;
import android.support.p002v7.appcompat.R$styleable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ButtonBarLayout */
public class ButtonBarLayout extends LinearLayout {
    private boolean mAllowStacking;
    private int mLastWidthSize = -1;

    public ButtonBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ButtonBarLayout);
        ViewCompat.saveAttributeDataForStyleable(this, context, R$styleable.ButtonBarLayout, attributeSet, obtainStyledAttributes, 0, 0);
        this.mAllowStacking = obtainStyledAttributes.getBoolean(0, true);
        obtainStyledAttributes.recycle();
    }

    private final int getNextVisibleChildIndex(int i) {
        int childCount = getChildCount();
        while (i < childCount) {
            if (getChildAt(i).getVisibility() == 0) {
                return i;
            }
            i++;
        }
        return -1;
    }

    private final boolean isStacked() {
        return getOrientation() == 1;
    }

    private final void setStacked(boolean z) {
        int i;
        int i2;
        setOrientation(z);
        if (true != z) {
            i = 80;
        } else {
            i = 8388613;
        }
        setGravity(i);
        View findViewById = findViewById(R.id.spacer);
        if (findViewById != null) {
            if (true != z) {
                i2 = 4;
            } else {
                i2 = 8;
            }
            findViewById.setVisibility(i2);
        }
        for (i2 = getChildCount() - 2; i2 >= 0; i2--) {
            bringChildToFront(getChildAt(i2));
        }
    }

    public final int getMinimumHeight() {
        return Math.max(0, super.getMinimumHeight());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected final void onMeasure(int r6, int r7) {
        /*
        r5 = this;
        r0 = android.view.View.MeasureSpec.getSize(r6);
        r1 = r5.mAllowStacking;
        r2 = 0;
        if (r1 == 0) goto L_0x0018;
    L_0x0009:
        r1 = r5.mLastWidthSize;
        if (r0 <= r1) goto L_0x0016;
    L_0x000d:
        r1 = r5.isStacked();
        if (r1 == 0) goto L_0x0016;
    L_0x0013:
        r5.setStacked(r2);
    L_0x0016:
        r5.mLastWidthSize = r0;
    L_0x0018:
        r1 = r5.isStacked();
        r3 = 1;
        if (r1 != 0) goto L_0x002f;
    L_0x001f:
        r1 = android.view.View.MeasureSpec.getMode(r6);
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r1 != r4) goto L_0x002f;
    L_0x0027:
        r1 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r1);
        r1 = 1;
        goto L_0x0031;
    L_0x002f:
        r0 = r6;
        r1 = 0;
    L_0x0031:
        super.onMeasure(r0, r7);
        r0 = r5.mAllowStacking;
        if (r0 == 0) goto L_0x004d;
    L_0x0038:
        r0 = r5.isStacked();
        if (r0 != 0) goto L_0x004d;
    L_0x003e:
        r0 = r5.getMeasuredWidthAndState();
        r4 = -16777216; // 0xffffffffff000000 float:-1.7014118E38 double:NaN;
        r0 = r0 & r4;
        r4 = 16777216; // 0x1000000 float:2.3509887E-38 double:8.289046E-317;
        if (r0 != r4) goto L_0x004d;
    L_0x0049:
        r5.setStacked(r3);
        goto L_0x004f;
    L_0x004d:
        if (r1 == 0) goto L_0x0052;
    L_0x004f:
        super.onMeasure(r6, r7);
        r6 = r5.getNextVisibleChildIndex(r2);
        if (r6 < 0) goto L_0x00a1;
    L_0x0059:
        r7 = r5.getChildAt(r6);
        r0 = r7.getLayoutParams();
        r0 = (android.widget.LinearLayout.LayoutParams) r0;
        r1 = r5.getPaddingTop();
        r7 = r7.getMeasuredHeight();
        r1 = r1 + r7;
        r7 = r0.topMargin;
        r1 = r1 + r7;
        r7 = r0.bottomMargin;
        r2 = r1 + r7;
        r7 = r5.isStacked();
        if (r7 == 0) goto L_0x009b;
    L_0x0079:
        r6 = r6 + r3;
        r6 = r5.getNextVisibleChildIndex(r6);
        if (r6 < 0) goto L_0x009a;
    L_0x0080:
        r6 = r5.getChildAt(r6);
        r6 = r6.getPaddingTop();
        r7 = r5.getResources();
        r7 = r7.getDisplayMetrics();
        r7 = r7.density;
        r0 = 1098907648; // 0x41800000 float:16.0 double:5.42932517E-315;
        r7 = r7 * r0;
        r7 = (int) r7;
        r6 = r6 + r7;
        r2 = r2 + r6;
        goto L_0x00a2;
    L_0x009a:
        goto L_0x00a2;
    L_0x009b:
        r6 = r5.getPaddingBottom();
        r2 = r2 + r6;
        goto L_0x00a2;
    L_0x00a2:
        r6 = android.support.p000v4.view.ViewCompat.getMinimumHeight(r5);
        if (r6 == r2) goto L_0x00ab;
    L_0x00a8:
        r5.setMinimumHeight(r2);
    L_0x00ab:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ButtonBarLayout.onMeasure(int, int):void");
    }
}
