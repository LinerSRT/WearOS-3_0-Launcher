package android.support.p002v7.widget;

import android.os.SystemClock;
import android.support.p002v7.view.menu.ShowableListMenu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.ViewParent;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ForwardingListener */
public abstract class ForwardingListener implements OnTouchListener, OnAttachStateChangeListener {
    private int mActivePointerId;
    private Runnable mDisallowIntercept;
    public boolean mForwarding;
    private final int mLongPressTimeout;
    private final float mScaledTouchSlop;
    final View mSrc;
    private final int mTapTimeout;
    private final int[] mTmpLocation = new int[2];
    private Runnable mTriggerLongPress;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ForwardingListener$DisallowIntercept */
    final class DisallowIntercept implements Runnable {
        public final void run() {
            ViewParent parent = ForwardingListener.this.mSrc.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ForwardingListener$TriggerLongPress */
    final class TriggerLongPress implements Runnable {
        public final void run() {
            ForwardingListener forwardingListener = ForwardingListener.this;
            forwardingListener.clearCallbacks();
            View view = forwardingListener.mSrc;
            if (view.isEnabled()) {
                if (!view.isLongClickable()) {
                    if (forwardingListener.onForwardingStarted()) {
                        view.getParent().requestDisallowInterceptTouchEvent(true);
                        long uptimeMillis = SystemClock.uptimeMillis();
                        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                        view.onTouchEvent(obtain);
                        obtain.recycle();
                        forwardingListener.mForwarding = true;
                    }
                }
            }
        }
    }

    public ForwardingListener(View view) {
        this.mSrc = view;
        view.setLongClickable(true);
        view.addOnAttachStateChangeListener(this);
        this.mScaledTouchSlop = (float) ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        int tapTimeout = ViewConfiguration.getTapTimeout();
        this.mTapTimeout = tapTimeout;
        this.mLongPressTimeout = (tapTimeout + ViewConfiguration.getLongPressTimeout()) / 2;
    }

    public final void clearCallbacks() {
        Runnable runnable = this.mTriggerLongPress;
        if (runnable != null) {
            this.mSrc.removeCallbacks(runnable);
        }
        runnable = this.mDisallowIntercept;
        if (runnable != null) {
            this.mSrc.removeCallbacks(runnable);
        }
    }

    public abstract ShowableListMenu getPopup();

    protected boolean onForwardingStarted() {
        throw null;
    }

    protected boolean onForwardingStopped() {
        ShowableListMenu popup = getPopup();
        if (popup != null && popup.isShowing()) {
            popup.dismiss();
        }
        return true;
    }

    public final void onViewAttachedToWindow(View view) {
    }

    public final void onViewDetachedFromWindow(View view) {
        this.mForwarding = false;
        this.mActivePointerId = -1;
        Runnable runnable = this.mDisallowIntercept;
        if (runnable != null) {
            this.mSrc.removeCallbacks(runnable);
        }
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        boolean z;
        boolean z2 = this.mForwarding;
        View view2;
        if (z2) {
            view2 = this.mSrc;
            ShowableListMenu popup = getPopup();
            if (popup != null) {
                if (popup.isShowing()) {
                    View listView = popup.getListView();
                    if (listView != null) {
                        DropDownListView dropDownListView = (DropDownListView) listView;
                        if (dropDownListView.isShown()) {
                            MotionEvent obtainNoHistory = MotionEvent.obtainNoHistory(motionEvent);
                            int[] iArr = this.mTmpLocation;
                            view2.getLocationOnScreen(iArr);
                            obtainNoHistory.offsetLocation((float) iArr[0], (float) iArr[1]);
                            int[] iArr2 = this.mTmpLocation;
                            listView.getLocationOnScreen(iArr2);
                            obtainNoHistory.offsetLocation((float) (-iArr2[0]), (float) (-iArr2[1]));
                            boolean onForwardedEvent = dropDownListView.onForwardedEvent(obtainNoHistory, this.mActivePointerId);
                            obtainNoHistory.recycle();
                            int actionMasked = motionEvent.getActionMasked();
                            Object obj = (actionMasked == 1 || actionMasked == 3) ? null : 1;
                            if (onForwardedEvent && obj != null) {
                                z = true;
                            }
                        }
                    }
                }
            }
            z = !onForwardingStopped();
        } else {
            view2 = this.mSrc;
            if (view2.isEnabled()) {
                switch (motionEvent.getActionMasked()) {
                    case 0:
                        this.mActivePointerId = motionEvent.getPointerId(0);
                        if (this.mDisallowIntercept == null) {
                            this.mDisallowIntercept = new DisallowIntercept();
                        }
                        view2.postDelayed(this.mDisallowIntercept, (long) this.mTapTimeout);
                        if (this.mTriggerLongPress == null) {
                            this.mTriggerLongPress = new TriggerLongPress();
                        }
                        view2.postDelayed(this.mTriggerLongPress, (long) this.mLongPressTimeout);
                        z = false;
                        break;
                    case 1:
                    case 3:
                        clearCallbacks();
                        z = false;
                        break;
                    case 2:
                        int findPointerIndex = motionEvent.findPointerIndex(this.mActivePointerId);
                        if (findPointerIndex >= 0) {
                            float x = motionEvent.getX(findPointerIndex);
                            float y = motionEvent.getY(findPointerIndex);
                            float f = this.mScaledTouchSlop;
                            float f2 = -f;
                            if (x >= f2 && y >= f2 && x < ((float) (view2.getRight() - view2.getLeft())) + f && y < ((float) (view2.getBottom() - view2.getTop())) + f) {
                                z = false;
                                break;
                            }
                            clearCallbacks();
                            view2.getParent().requestDisallowInterceptTouchEvent(true);
                            if (onForwardingStarted()) {
                                z = true;
                                break;
                            }
                        }
                        z = false;
                        break;
                    default:
                        z = false;
                        break;
                }
            }
            z = false;
            if (z) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                this.mSrc.onTouchEvent(obtain);
                obtain.recycle();
            }
        }
        this.mForwarding = z;
        if (!z) {
            if (!z2) {
                return false;
            }
        }
        return true;
    }
}
