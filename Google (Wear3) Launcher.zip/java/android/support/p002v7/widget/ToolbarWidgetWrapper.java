package android.support.p002v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.ViewPropertyAnimatorCompat;
import android.support.p000v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.view.menu.ActionMenuItem;
import android.support.p002v7.view.menu.BaseMenuPresenter;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.p002v7.view.menu.MenuPresenter;
import android.support.p002v7.widget.Toolbar.ExpandedActionViewMenuPresenter;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window.Callback;
import android.widget.TextView;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ToolbarWidgetWrapper */
public final class ToolbarWidgetWrapper implements DecorToolbar {
    private ActionMenuPresenter mActionMenuPresenter;
    private View mCustomView;
    private int mDefaultNavigationContentDescription = 0;
    private final Drawable mDefaultNavigationIcon;
    private int mDisplayOpts;
    private CharSequence mHomeDescription;
    private Drawable mIcon;
    private Drawable mLogo;
    boolean mMenuPrepared;
    private Drawable mNavIcon;
    private CharSequence mSubtitle;
    CharSequence mTitle;
    private boolean mTitleSet;
    final Toolbar mToolbar;
    Callback mWindowCallback;

    /* renamed from: android.support.v7.widget.ToolbarWidgetWrapper$1 */
    final class PG implements OnClickListener {
        final ActionMenuItem mNavItem;

        public PG() {
            this.mNavItem = new ActionMenuItem(ToolbarWidgetWrapper.this.mToolbar.getContext(), ToolbarWidgetWrapper.this.mTitle);
        }

        public final void onClick(View view) {
            ToolbarWidgetWrapper toolbarWidgetWrapper = ToolbarWidgetWrapper.this;
            Callback callback = toolbarWidgetWrapper.mWindowCallback;
            if (callback != null && toolbarWidgetWrapper.mMenuPrepared) {
                callback.onMenuItemSelected(0, this.mNavItem);
            }
        }
    }

    private final void setTitleInt(CharSequence charSequence) {
        this.mTitle = charSequence;
        if ((this.mDisplayOpts & 8) != 0) {
            this.mToolbar.setTitle(charSequence);
        }
    }

    private final void updateHomeAccessibility() {
        if ((this.mDisplayOpts & 4) != 0) {
            if (TextUtils.isEmpty(this.mHomeDescription)) {
                CharSequence text;
                ViewGroup viewGroup = this.mToolbar;
                int i = this.mDefaultNavigationContentDescription;
                if (i != 0) {
                    text = viewGroup.getContext().getText(i);
                } else {
                    text = null;
                }
                viewGroup.setNavigationContentDescription(text);
                return;
            }
            this.mToolbar.setNavigationContentDescription(this.mHomeDescription);
        }
    }

    private final void updateNavigationIcon() {
        if ((this.mDisplayOpts & 4) != 0) {
            Toolbar toolbar = this.mToolbar;
            Drawable drawable = this.mNavIcon;
            if (drawable == null) {
                drawable = this.mDefaultNavigationIcon;
            }
            toolbar.setNavigationIcon(drawable);
            return;
        }
        this.mToolbar.setNavigationIcon(null);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void updateToolbarLogo() {
        /*
        r2 = this;
        r0 = r2.mDisplayOpts;
        r1 = r0 & 2;
        if (r1 == 0) goto L_0x0011;
    L_0x0006:
        r0 = r0 & 1;
        if (r0 == 0) goto L_0x000e;
    L_0x000a:
        r0 = r2.mLogo;
        if (r0 != 0) goto L_0x0012;
    L_0x000e:
        r0 = r2.mIcon;
        goto L_0x0012;
    L_0x0011:
        r0 = 0;
    L_0x0012:
        r1 = r2.mToolbar;
        r1.setLogo(r0);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.ToolbarWidgetWrapper.updateToolbarLogo():void");
    }

    public final boolean canShowOverflowMenu() {
        ViewGroup viewGroup = this.mToolbar;
        if (viewGroup.getVisibility() == 0) {
            ActionMenuView actionMenuView = viewGroup.mMenuView;
            if (actionMenuView != null && actionMenuView.mReserveOverflow) {
                return true;
            }
        }
        return false;
    }

    public final void collapseActionView() {
        this.mToolbar.collapseActionView();
    }

    public final Context getContext() {
        return this.mToolbar.getContext();
    }

    public final int getDisplayOptions() {
        return this.mDisplayOpts;
    }

    public final void getNavigationMode$ar$ds() {
    }

    public final ViewGroup getViewGroup() {
        return this.mToolbar;
    }

    public final boolean hasExpandedActionView() {
        ExpandedActionViewMenuPresenter expandedActionViewMenuPresenter = this.mToolbar.mExpandedMenuPresenter;
        return (expandedActionViewMenuPresenter == null || expandedActionViewMenuPresenter.mCurrentExpandedItem == null) ? false : true;
    }

    public final void initIndeterminateProgress() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public final void initProgress() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public final boolean isOverflowMenuShowing() {
        return this.mToolbar.isOverflowMenuShowing();
    }

    public final void setCollapsible$ar$ds() {
        this.mToolbar.requestLayout();
    }

    public final void setDisplayOptions(int i) {
        int i2 = this.mDisplayOpts ^ i;
        this.mDisplayOpts = i;
        if (i2 != 0) {
            if ((i2 & 4) != 0) {
                if ((i & 4) != 0) {
                    updateHomeAccessibility();
                }
                updateNavigationIcon();
            }
            if ((i2 & 3) != 0) {
                updateToolbarLogo();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    this.mToolbar.setTitle(this.mTitle);
                    this.mToolbar.setSubtitle(this.mSubtitle);
                } else {
                    this.mToolbar.setTitle(null);
                    this.mToolbar.setSubtitle(null);
                }
            }
            if ((i2 & 16) != 0) {
                View view = this.mCustomView;
                if (view != null) {
                    if ((i & 16) != 0) {
                        this.mToolbar.addView(view);
                    } else {
                        this.mToolbar.removeView(view);
                    }
                }
            }
        }
    }

    public final void setEmbeddedTabView$ar$ds() {
    }

    public final void setHomeButtonEnabled$ar$ds() {
    }

    public final void setMenu(Menu menu, MenuPresenter.Callback callback) {
        if (this.mActionMenuPresenter == null) {
            this.mActionMenuPresenter = new ActionMenuPresenter(this.mToolbar.getContext());
        }
        BaseMenuPresenter baseMenuPresenter = this.mActionMenuPresenter;
        baseMenuPresenter.mCallback = callback;
        Toolbar toolbar = this.mToolbar;
        if (!(menu == null && toolbar.mMenuView == null)) {
            toolbar.ensureMenuView();
            Menu menu2 = toolbar.mMenuView.mMenu;
            if (menu2 != menu) {
                if (menu2 != null) {
                    menu2.removeMenuPresenter(toolbar.mOuterActionMenuPresenter);
                    menu2.removeMenuPresenter(toolbar.mExpandedMenuPresenter);
                }
                if (toolbar.mExpandedMenuPresenter == null) {
                    toolbar.mExpandedMenuPresenter = new ExpandedActionViewMenuPresenter();
                }
                baseMenuPresenter.setExpandedActionViewsExclusive$ar$ds();
                if (menu != null) {
                    MenuBuilder menuBuilder = (MenuBuilder) menu;
                    menuBuilder.addMenuPresenter(baseMenuPresenter, toolbar.mPopupContext);
                    menuBuilder.addMenuPresenter(toolbar.mExpandedMenuPresenter, toolbar.mPopupContext);
                } else {
                    baseMenuPresenter.initForMenu(toolbar.mPopupContext, null);
                    toolbar.mExpandedMenuPresenter.initForMenu(toolbar.mPopupContext, null);
                    baseMenuPresenter.updateMenuView$ar$ds();
                    toolbar.mExpandedMenuPresenter.updateMenuView$ar$ds();
                }
                toolbar.mMenuView.setPopupTheme(toolbar.mPopupTheme);
                toolbar.mMenuView.setPresenter(baseMenuPresenter);
                toolbar.mOuterActionMenuPresenter = baseMenuPresenter;
            }
        }
    }

    public final void setMenuPrepared() {
        this.mMenuPrepared = true;
    }

    public final void setVisibility(int i) {
        this.mToolbar.setVisibility(i);
    }

    public final void setWindowCallback(Callback callback) {
        this.mWindowCallback = callback;
    }

    public final void setWindowTitle(CharSequence charSequence) {
        if (!this.mTitleSet) {
            setTitleInt(charSequence);
        }
    }

    public final ViewPropertyAnimatorCompat setupAnimatorToVisibility(final int i, long j) {
        ViewPropertyAnimatorCompat animate = ViewCompat.animate(this.mToolbar);
        animate.alpha$ar$ds(i == 0 ? 1.0f : 0.0f);
        animate.setDuration$ar$ds(j);
        animate.setListener$ar$ds(new ViewPropertyAnimatorListenerAdapter() {
            private boolean mCanceled = false;

            public final void onAnimationCancel$ar$ds() {
                this.mCanceled = true;
            }

            public final void onAnimationEnd$ar$ds() {
                if (!this.mCanceled) {
                    android.support.p002v7.widget.ToolbarWidgetWrapper.this.mToolbar.setVisibility(i);
                }
            }

            public final void onAnimationStart$ar$ds() {
                android.support.p002v7.widget.ToolbarWidgetWrapper.this.mToolbar.setVisibility(0);
            }
        });
        return animate;
    }

    public final boolean showOverflowMenu() {
        return this.mToolbar.showOverflowMenu();
    }

    public ToolbarWidgetWrapper(Toolbar toolbar) {
        Context context;
        TextView textView;
        this.mToolbar = toolbar;
        this.mTitle = toolbar.mTitleText;
        this.mSubtitle = toolbar.mSubtitleText;
        this.mTitleSet = this.mTitle != null;
        this.mNavIcon = toolbar.getNavigationIcon();
        CharSequence charSequence = null;
        TintTypedArray obtainStyledAttributes$ar$ds = TintTypedArray.obtainStyledAttributes$ar$ds(toolbar.getContext(), null, R$styleable.ActionBar, R.attr.actionBarStyle);
        Drawable drawable = obtainStyledAttributes$ar$ds.getDrawable(15);
        this.mDefaultNavigationIcon = drawable;
        CharSequence text = obtainStyledAttributes$ar$ds.getText(27);
        if (!TextUtils.isEmpty(text)) {
            this.mTitleSet = true;
            setTitleInt(text);
        }
        CharSequence text2 = obtainStyledAttributes$ar$ds.getText(25);
        if (!TextUtils.isEmpty(text2)) {
            this.mSubtitle = text2;
            if ((this.mDisplayOpts & 8) != 0) {
                toolbar.setSubtitle(text2);
            }
        }
        Drawable drawable2 = obtainStyledAttributes$ar$ds.getDrawable(20);
        if (drawable2 != null) {
            this.mLogo = drawable2;
            updateToolbarLogo();
        }
        drawable2 = obtainStyledAttributes$ar$ds.getDrawable(17);
        if (drawable2 != null) {
            this.mIcon = drawable2;
            updateToolbarLogo();
        }
        if (this.mNavIcon == null && drawable != null) {
            this.mNavIcon = drawable;
            updateNavigationIcon();
        }
        setDisplayOptions(obtainStyledAttributes$ar$ds.getInt(10, 0));
        int resourceId = obtainStyledAttributes$ar$ds.getResourceId(9, 0);
        if (resourceId != 0) {
            View inflate = LayoutInflater.from(toolbar.getContext()).inflate(resourceId, toolbar, false);
            View view = this.mCustomView;
            if (!(view == null || (this.mDisplayOpts & 16) == 0)) {
                toolbar.removeView(view);
            }
            this.mCustomView = inflate;
            if (!(inflate == null || (this.mDisplayOpts & 16) == 0)) {
                toolbar.addView(inflate);
            }
            setDisplayOptions(this.mDisplayOpts | 16);
        }
        resourceId = obtainStyledAttributes$ar$ds.getLayoutDimension(13, 0);
        if (resourceId > 0) {
            LayoutParams layoutParams = toolbar.getLayoutParams();
            layoutParams.height = resourceId;
            toolbar.setLayoutParams(layoutParams);
        }
        resourceId = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(7, -1);
        int dimensionPixelOffset = obtainStyledAttributes$ar$ds.getDimensionPixelOffset(3, -1);
        if (resourceId >= 0 || dimensionPixelOffset >= 0) {
            resourceId = Math.max(resourceId, 0);
            dimensionPixelOffset = Math.max(dimensionPixelOffset, 0);
            toolbar.ensureContentInsets();
            toolbar.mContentInsets.setRelative(resourceId, dimensionPixelOffset);
        }
        resourceId = obtainStyledAttributes$ar$ds.getResourceId(28, 0);
        if (resourceId != 0) {
            context = toolbar.getContext();
            toolbar.mTitleTextAppearance = resourceId;
            textView = toolbar.mTitleTextView;
            if (textView != null) {
                textView.setTextAppearance(context, resourceId);
            }
        }
        resourceId = obtainStyledAttributes$ar$ds.getResourceId(26, 0);
        if (resourceId != 0) {
            context = toolbar.getContext();
            toolbar.mSubtitleTextAppearance = resourceId;
            textView = toolbar.mSubtitleTextView;
            if (textView != null) {
                textView.setTextAppearance(context, resourceId);
            }
        }
        int resourceId2 = obtainStyledAttributes$ar$ds.getResourceId(22, 0);
        if (resourceId2 != 0) {
            toolbar.setPopupTheme(resourceId2);
        }
        obtainStyledAttributes$ar$ds.recycle();
        if (this.mDefaultNavigationContentDescription != R.string.abc_action_bar_up_description) {
            this.mDefaultNavigationContentDescription = R.string.abc_action_bar_up_description;
            if (TextUtils.isEmpty(toolbar.getNavigationContentDescription())) {
                resourceId2 = this.mDefaultNavigationContentDescription;
                if (resourceId2 != 0) {
                    charSequence = getContext().getString(resourceId2);
                }
                this.mHomeDescription = charSequence;
                updateHomeAccessibility();
            }
        }
        this.mHomeDescription = toolbar.getNavigationContentDescription();
        OnClickListener pg = new PG();
        toolbar.ensureNavButtonView();
        toolbar.mNavButtonView.setOnClickListener(pg);
    }

    public final void dismissPopupMenus() {
        ActionMenuView actionMenuView = this.mToolbar.mMenuView;
        if (actionMenuView != null) {
            actionMenuView.dismissPopupMenus();
        }
    }

    public final boolean hideOverflowMenu() {
        ActionMenuView actionMenuView = this.mToolbar.mMenuView;
        if (actionMenuView != null) {
            ActionMenuPresenter actionMenuPresenter = actionMenuView.mPresenter;
            if (actionMenuPresenter != null && actionMenuPresenter.hideOverflowMenu()) {
                return true;
            }
        }
        return false;
    }

    public final boolean isOverflowMenuShowPending() {
        ActionMenuView actionMenuView = this.mToolbar.mMenuView;
        boolean z = true;
        if (actionMenuView != null) {
            ActionMenuPresenter actionMenuPresenter = actionMenuView.mPresenter;
            if (actionMenuPresenter != null) {
                if (actionMenuPresenter.mPostedOpenRunnable == null) {
                    if (!actionMenuPresenter.isOverflowMenuShowing()) {
                        return false;
                    }
                }
                return z;
            }
        }
        z = false;
        return z;
    }
}
