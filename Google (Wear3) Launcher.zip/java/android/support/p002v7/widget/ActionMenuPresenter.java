package android.support.p002v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ActionProvider;
import android.support.p002v7.view.ActionBarPolicy;
import android.support.p002v7.view.menu.ActionMenuItemView;
import android.support.p002v7.view.menu.ActionMenuItemView.PopupCallback;
import android.support.p002v7.view.menu.BaseMenuPresenter;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.p002v7.view.menu.MenuBuilder.Callback;
import android.support.p002v7.view.menu.MenuItemImpl;
import android.support.p002v7.view.menu.MenuPopupHelper;
import android.support.p002v7.view.menu.MenuPresenter;
import android.support.p002v7.view.menu.MenuView;
import android.support.p002v7.view.menu.MenuView.ItemView;
import android.support.p002v7.view.menu.ShowableListMenu;
import android.support.p002v7.view.menu.SubMenuBuilder;
import android.support.p002v7.widget.ActionMenuView.ActionMenuChildView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v7.widget.ActionMenuPresenter */
public final class ActionMenuPresenter extends BaseMenuPresenter {
    private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
    public ActionButtonSubmenu mActionButtonPopup;
    private int mActionItemWidthLimit;
    private boolean mExpandedActionViewsExclusive;
    public int mMaxItems;
    OverflowMenuButton mOverflowButton;
    OverflowPopup mOverflowPopup;
    private ActionMenuPopupCallback mPopupCallback;
    final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback();
    OpenOverflowRunnable mPostedOpenRunnable;
    private boolean mReserveOverflow;
    private boolean mReserveOverflowSet;
    private int mWidthLimit;

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuPresenter$ActionButtonSubmenu */
    public final class ActionButtonSubmenu extends MenuPopupHelper {
        public ActionButtonSubmenu(Context context, SubMenuBuilder subMenuBuilder, View view) {
            super(context, subMenuBuilder, view, false);
            if (!subMenuBuilder.mItem.isActionButton()) {
                View view2 = ActionMenuPresenter.this.mOverflowButton;
                if (view2 == null) {
                    view2 = (View) ActionMenuPresenter.this.mMenuView;
                }
                this.mAnchorView = view2;
            }
            setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
        }

        protected final void onDismiss() {
            ActionMenuPresenter.this.mActionButtonPopup = null;
            super.onDismiss();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuPresenter$ActionMenuPopupCallback */
    public final class ActionMenuPopupCallback extends PopupCallback {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuPresenter$OpenOverflowRunnable */
    final class OpenOverflowRunnable implements Runnable {
        private final OverflowPopup mPopup;

        public OpenOverflowRunnable(OverflowPopup overflowPopup) {
            this.mPopup = overflowPopup;
        }

        public final void run() {
            MenuBuilder menuBuilder = ActionMenuPresenter.this.mMenu;
            if (menuBuilder != null) {
                Callback callback = menuBuilder.mCallback;
                if (callback != null) {
                    callback.onMenuModeChange$ar$ds();
                }
            }
            View view = (View) ActionMenuPresenter.this.mMenuView;
            if (!(view == null || view.getWindowToken() == null || !this.mPopup.tryShow())) {
                ActionMenuPresenter.this.mOverflowPopup = this.mPopup;
            }
            ActionMenuPresenter.this.mPostedOpenRunnable = null;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuPresenter$OverflowMenuButton */
    final class OverflowMenuButton extends AppCompatImageView implements ActionMenuChildView {
        public OverflowMenuButton(Context context) {
            super(context, null, R.attr.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            setTooltipText(getContentDescription());
            setOnTouchListener(new ForwardingListener(this) {
                public final ShowableListMenu getPopup() {
                    MenuPopupHelper menuPopupHelper = ActionMenuPresenter.this.mOverflowPopup;
                    return menuPopupHelper == null ? null : menuPopupHelper.getPopup();
                }

                public final boolean onForwardingStarted() {
                    ActionMenuPresenter.this.showOverflowMenu();
                    return true;
                }

                public final boolean onForwardingStopped() {
                    ActionMenuPresenter actionMenuPresenter = ActionMenuPresenter.this;
                    if (actionMenuPresenter.mPostedOpenRunnable != null) {
                        return false;
                    }
                    actionMenuPresenter.hideOverflowMenu();
                    return true;
                }
            });
        }

        public final boolean needsDividerAfter() {
            return false;
        }

        public final boolean needsDividerBefore() {
            return false;
        }

        public final boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            ActionMenuPresenter.this.showOverflowMenu();
            return true;
        }

        protected final boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (!(drawable == null || background == null)) {
                i2 = getWidth();
                i4 = getHeight();
                int max = Math.max(i2, i4) / 2;
                i2 = (i2 + (getPaddingLeft() - getPaddingRight())) / 2;
                i4 = (i4 + (getPaddingTop() - getPaddingBottom())) / 2;
                background.setHotspotBounds(i2 - max, i4 - max, i2 + max, i4 + max);
            }
            return frame;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuPresenter$OverflowPopup */
    final class OverflowPopup extends MenuPopupHelper {
        public OverflowPopup(Context context, MenuBuilder menuBuilder, View view) {
            super(context, menuBuilder, view, true);
            setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
        }

        protected final void onDismiss() {
            MenuBuilder menuBuilder = ActionMenuPresenter.this.mMenu;
            if (menuBuilder != null) {
                menuBuilder.close();
            }
            ActionMenuPresenter.this.mOverflowPopup = null;
            super.onDismiss();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.widget.ActionMenuPresenter$PopupPresenterCallback */
    final class PopupPresenterCallback implements MenuPresenter.Callback {
        public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
            if (menuBuilder instanceof SubMenuBuilder) {
                menuBuilder.getRootMenu().close(false);
            }
            MenuPresenter.Callback callback = ActionMenuPresenter.this.mCallback;
            if (callback != null) {
                callback.onCloseMenu(menuBuilder, z);
            }
        }

        public final boolean onOpenSubMenu(MenuBuilder menuBuilder) {
            BaseMenuPresenter baseMenuPresenter = ActionMenuPresenter.this;
            if (menuBuilder == baseMenuPresenter.mMenu) {
                return false;
            }
            MenuItemImpl menuItemImpl = ((SubMenuBuilder) menuBuilder).mItem;
            MenuPresenter.Callback callback = baseMenuPresenter.mCallback;
            if (callback != null) {
                return callback.onOpenSubMenu(menuBuilder);
            }
            return false;
        }
    }

    public ActionMenuPresenter(Context context) {
        super(context);
    }

    public final void dismissPopupMenus$ar$ds() {
        hideOverflowMenu();
        hideSubMenus$ar$ds();
    }

    public final boolean flagActionItems() {
        ArrayList visibleItems;
        int size;
        MenuBuilder menuBuilder = this.mMenu;
        View view = null;
        if (menuBuilder != null) {
            visibleItems = menuBuilder.getVisibleItems();
            size = visibleItems.size();
        } else {
            visibleItems = null;
            size = 0;
        }
        int i = r0.mMaxItems;
        int i2 = r0.mActionItemWidthLimit;
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) r0.mMenuView;
        int i3 = 0;
        Object obj = null;
        int i4 = 0;
        int i5 = 0;
        while (true) {
            boolean z = true;
            if (i3 >= size) {
                break;
            }
            MenuItemImpl menuItemImpl = (MenuItemImpl) visibleItems.get(i3);
            if (menuItemImpl.requiresActionButton()) {
                i4++;
            } else if (menuItemImpl.requestsActionButton()) {
                i5++;
            } else {
                obj = 1;
            }
            if (r0.mExpandedActionViewsExclusive && menuItemImpl.mIsActionViewExpanded) {
                i = 0;
            }
            i3++;
        }
        if (r0.mReserveOverflow && (obj != null || i5 + i4 > i)) {
            i--;
        }
        i -= i4;
        SparseBooleanArray sparseBooleanArray = r0.mActionButtonGroups;
        sparseBooleanArray.clear();
        int i6 = 0;
        i4 = 0;
        while (i6 < size) {
            MenuItemImpl menuItemImpl2 = (MenuItemImpl) visibleItems.get(i6);
            int measuredWidth;
            if (menuItemImpl2.requiresActionButton()) {
                View itemView = getItemView(menuItemImpl2, view, viewGroup);
                itemView.measure(makeMeasureSpec, makeMeasureSpec);
                measuredWidth = itemView.getMeasuredWidth();
                i2 -= measuredWidth;
                if (i4 == 0) {
                    i4 = measuredWidth;
                }
                measuredWidth = menuItemImpl2.mGroup;
                if (measuredWidth != 0) {
                    sparseBooleanArray.put(measuredWidth, z);
                }
                menuItemImpl2.setIsActionButton(z);
            } else if (menuItemImpl2.requestsActionButton()) {
                boolean z2;
                boolean z3;
                measuredWidth = menuItemImpl2.mGroup;
                boolean z4 = sparseBooleanArray.get(measuredWidth);
                if ((i > 0 || z4) && i2 > 0) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (z2) {
                    View itemView2 = getItemView(menuItemImpl2, view, viewGroup);
                    itemView2.measure(makeMeasureSpec, makeMeasureSpec);
                    int measuredWidth2 = itemView2.getMeasuredWidth();
                    i2 -= measuredWidth2;
                    if (i4 == 0) {
                        i4 = measuredWidth2;
                    }
                    if (i2 + i4 > 0) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    z3 = z2;
                } else {
                    z3 = z2;
                }
                if (z3 && measuredWidth != 0) {
                    sparseBooleanArray.put(measuredWidth, z);
                } else if (z4) {
                    sparseBooleanArray.put(measuredWidth, false);
                    for (int i7 = 0; i7 < i6; i7++) {
                        MenuItemImpl menuItemImpl3 = (MenuItemImpl) visibleItems.get(i7);
                        if (menuItemImpl3.mGroup == measuredWidth) {
                            if (menuItemImpl3.isActionButton()) {
                                i++;
                            }
                            menuItemImpl3.setIsActionButton(false);
                        }
                    }
                }
                if (z3) {
                    i--;
                }
                menuItemImpl2.setIsActionButton(z3);
            } else {
                menuItemImpl2.setIsActionButton(false);
            }
            i6++;
            view = null;
            z = true;
        }
        return true;
    }

    public final View getItemView(MenuItemImpl menuItemImpl, View view, ViewGroup viewGroup) {
        ActionMenuView actionMenuView;
        LayoutParams layoutParams;
        ItemView itemView;
        View actionView = menuItemImpl.getActionView();
        int i = 0;
        if (actionView != null) {
            if (!menuItemImpl.hasCollapsibleActionView()) {
                if (true != menuItemImpl.mIsActionViewExpanded) {
                    i = 8;
                }
                actionView.setVisibility(i);
                actionMenuView = (ActionMenuView) viewGroup;
                layoutParams = actionView.getLayoutParams();
                if (!(layoutParams instanceof ActionMenuView.LayoutParams)) {
                    actionView.setLayoutParams(ActionMenuView.generateLayoutParams$ar$ds$b524489_0(layoutParams));
                }
                return actionView;
            }
        }
        if (view instanceof ItemView) {
            itemView = (ItemView) view;
        } else {
            itemView = (ItemView) this.mSystemInflater.inflate(R.layout.abc_action_menu_item_layout, viewGroup, false);
        }
        itemView.initialize$ar$ds(menuItemImpl);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) itemView;
        actionMenuItemView.mItemInvoker = (ActionMenuView) this.mMenuView;
        if (this.mPopupCallback == null) {
            this.mPopupCallback = new ActionMenuPopupCallback();
        }
        actionMenuItemView.mPopupCallback = this.mPopupCallback;
        actionView = (View) itemView;
        if (true != menuItemImpl.mIsActionViewExpanded) {
            i = 8;
        }
        actionView.setVisibility(i);
        actionMenuView = (ActionMenuView) viewGroup;
        layoutParams = actionView.getLayoutParams();
        if (layoutParams instanceof ActionMenuView.LayoutParams) {
            actionView.setLayoutParams(ActionMenuView.generateLayoutParams$ar$ds$b524489_0(layoutParams));
        }
        return actionView;
    }

    public final boolean hideOverflowMenu() {
        Runnable runnable = this.mPostedOpenRunnable;
        if (runnable != null) {
            MenuView menuView = this.mMenuView;
            if (menuView != null) {
                ((View) menuView).removeCallbacks(runnable);
                this.mPostedOpenRunnable = null;
                return true;
            }
        }
        MenuPopupHelper menuPopupHelper = this.mOverflowPopup;
        if (menuPopupHelper == null) {
            return false;
        }
        menuPopupHelper.dismiss();
        return true;
    }

    public final void hideSubMenus$ar$ds() {
        MenuPopupHelper menuPopupHelper = this.mActionButtonPopup;
        if (menuPopupHelper != null) {
            menuPopupHelper.dismiss();
        }
    }

    public final boolean isOverflowMenuShowing() {
        MenuPopupHelper menuPopupHelper = this.mOverflowPopup;
        return menuPopupHelper != null && menuPopupHelper.isShowing();
    }

    public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        dismissPopupMenus$ar$ds();
        MenuPresenter.Callback callback = this.mCallback;
        if (callback != null) {
            callback.onCloseMenu(menuBuilder, z);
        }
    }

    public final boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
        boolean z = false;
        if (!subMenuBuilder.hasVisibleItems()) {
            return false;
        }
        SubMenuBuilder subMenuBuilder2 = subMenuBuilder;
        while (true) {
            MenuBuilder menuBuilder = subMenuBuilder2.mParentMenu;
            if (menuBuilder == this.mMenu) {
                break;
            }
            subMenuBuilder2 = (SubMenuBuilder) menuBuilder;
        }
        MenuItemImpl menuItemImpl = subMenuBuilder2.mItem;
        ViewGroup viewGroup = (ViewGroup) this.mMenuView;
        View view = null;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = viewGroup.getChildAt(i);
                if ((childAt instanceof ItemView) && ((ItemView) childAt).getItemData() == menuItemImpl) {
                    view = childAt;
                    break;
                }
            }
        }
        if (view == null) {
            return false;
        }
        menuItemImpl = subMenuBuilder.mItem;
        int size = subMenuBuilder.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = subMenuBuilder.getItem(i2);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
        }
        MenuPopupHelper actionButtonSubmenu = new ActionButtonSubmenu(this.mContext, subMenuBuilder, view);
        this.mActionButtonPopup = actionButtonSubmenu;
        actionButtonSubmenu.setForceShowIcon(z);
        if (this.mActionButtonPopup.tryShow()) {
            MenuPresenter.Callback callback = this.mCallback;
            if (callback != null) {
                MenuBuilder subMenuBuilder3;
                if (subMenuBuilder3 == null) {
                    subMenuBuilder3 = this.mMenu;
                }
                callback.onOpenSubMenu(subMenuBuilder3);
            }
            return true;
        }
        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
    }

    public final void setExpandedActionViewsExclusive$ar$ds() {
        this.mExpandedActionViewsExclusive = true;
    }

    public final void setMenuView(ActionMenuView actionMenuView) {
        this.mMenuView = actionMenuView;
        actionMenuView.mMenu = this.mMenu;
    }

    public final void setReserveOverflow$ar$ds() {
        this.mReserveOverflow = true;
        this.mReserveOverflowSet = true;
    }

    public final boolean showOverflowMenu() {
        if (this.mReserveOverflow && !isOverflowMenuShowing()) {
            MenuBuilder menuBuilder = this.mMenu;
            if (!(menuBuilder == null || this.mMenuView == null || this.mPostedOpenRunnable != null || menuBuilder.getNonActionItems().isEmpty())) {
                this.mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(this.mContext, this.mMenu, this.mOverflowButton));
                ((View) this.mMenuView).post(this.mPostedOpenRunnable);
                return true;
            }
        }
        return false;
    }

    public final void initForMenu(Context context, MenuBuilder menuBuilder) {
        this.mContext = context;
        LayoutInflater.from(this.mContext);
        this.mMenu = menuBuilder;
        Resources resources = context.getResources();
        if (!this.mReserveOverflowSet) {
            this.mReserveOverflow = true;
        }
        this.mWidthLimit = context.getResources().getDisplayMetrics().widthPixels / 2;
        this.mMaxItems = ActionBarPolicy.getMaxActionButtons$ar$objectUnboxing(context);
        int i = this.mWidthLimit;
        if (this.mReserveOverflow) {
            if (this.mOverflowButton == null) {
                this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
                int makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
                this.mOverflowButton.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i -= this.mOverflowButton.getMeasuredWidth();
        } else {
            this.mOverflowButton = null;
        }
        this.mActionItemWidthLimit = i;
        float f = resources.getDisplayMetrics().density;
    }

    public final void updateMenuView$ar$ds() {
        int size;
        ViewGroup viewGroup = (ViewGroup) this.mMenuView;
        ArrayList arrayList = null;
        int i = 0;
        if (viewGroup != null) {
            int i2;
            MenuBuilder menuBuilder = this.mMenu;
            if (menuBuilder != null) {
                menuBuilder.flagActionItems();
                ArrayList visibleItems = this.mMenu.getVisibleItems();
                size = visibleItems.size();
                i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    MenuItemImpl menuItemImpl = (MenuItemImpl) visibleItems.get(i3);
                    if (menuItemImpl.isActionButton()) {
                        MenuItemImpl itemData;
                        View childAt = viewGroup.getChildAt(i2);
                        if (childAt instanceof ItemView) {
                            itemData = ((ItemView) childAt).getItemData();
                        } else {
                            itemData = null;
                        }
                        View itemView = getItemView(menuItemImpl, childAt, viewGroup);
                        if (menuItemImpl != itemData) {
                            itemView.setPressed(false);
                            itemView.jumpDrawablesToCurrentState();
                        }
                        if (itemView != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) itemView.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(itemView);
                            }
                            ((ViewGroup) this.mMenuView).addView(itemView, i2);
                        }
                        i2++;
                    }
                }
            } else {
                i2 = 0;
            }
            while (i2 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i2) == this.mOverflowButton) {
                    i2++;
                } else {
                    viewGroup.removeViewAt(i2);
                }
            }
        }
        ((View) this.mMenuView).requestLayout();
        MenuBuilder menuBuilder2 = this.mMenu;
        if (menuBuilder2 != null) {
            menuBuilder2.flagActionItems();
            ArrayList arrayList2 = menuBuilder2.mActionItems;
            int size2 = arrayList2.size();
            for (size = 0; size < size2; size++) {
                ActionProvider actionProvider = ((MenuItemImpl) arrayList2.get(size)).mActionProvider;
            }
        }
        menuBuilder2 = this.mMenu;
        if (menuBuilder2 != null) {
            arrayList = menuBuilder2.getNonActionItems();
        }
        if (this.mReserveOverflow && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                i = ((MenuItemImpl) arrayList.get(0)).mIsActionViewExpanded ^ 1;
            } else if (size3 > 0) {
                i = 1;
            }
            if (i != 0) {
                if (this.mOverflowButton == null) {
                    this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
                }
                viewGroup = (ViewGroup) this.mOverflowButton.getParent();
                if (viewGroup != this.mMenuView) {
                    if (viewGroup != null) {
                        viewGroup.removeView(this.mOverflowButton);
                    }
                    ActionMenuView actionMenuView = (ActionMenuView) this.mMenuView;
                    View view = this.mOverflowButton;
                    LayoutParams generateDefaultLayoutParams$ar$ds = ActionMenuView.generateDefaultLayoutParams$ar$ds();
                    generateDefaultLayoutParams$ar$ds.isOverflowButton = true;
                    actionMenuView.addView(view, generateDefaultLayoutParams$ar$ds);
                }
                ((ActionMenuView) this.mMenuView).mReserveOverflow = this.mReserveOverflow;
            }
        }
        OverflowMenuButton overflowMenuButton = this.mOverflowButton;
        if (overflowMenuButton != null) {
            ViewParent parent = overflowMenuButton.getParent();
            ViewParent viewParent = this.mMenuView;
            if (parent == viewParent) {
                ((ViewGroup) viewParent).removeView(this.mOverflowButton);
            }
        }
        ((ActionMenuView) this.mMenuView).mReserveOverflow = this.mReserveOverflow;
    }
}
