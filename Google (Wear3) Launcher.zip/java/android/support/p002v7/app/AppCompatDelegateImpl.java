package android.support.p002v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.support.p000v4.app.NavUtils;
import android.support.p000v4.view.OnApplyWindowInsetsListener;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.ViewPropertyAnimatorCompat;
import android.support.p000v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.p000v4.view.WindowInsetsCompat;
import android.support.p000v4.widget.PopupWindowCompat$Api23Impl;
import android.support.p002v7.app.WindowDecorActionBar.ActionModeImpl;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.content.res.AppCompatResources;
import android.support.p002v7.view.ActionMode;
import android.support.p002v7.view.StandaloneActionMode;
import android.support.p002v7.view.SupportActionModeWrapper.CallbackWrapper;
import android.support.p002v7.view.WindowCallbackWrapper;
import android.support.p002v7.view.menu.ListMenuPresenter;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.p002v7.view.menu.MenuBuilder.Callback;
import android.support.p002v7.view.menu.MenuItemWrapperICS;
import android.support.p002v7.view.menu.MenuPresenter;
import android.support.p002v7.widget.ActionBarContextView;
import android.support.p002v7.widget.AppCompatDrawableManager;
import android.support.p002v7.widget.ContentFrameLayout;
import android.support.p002v7.widget.DecorContentParent;
import android.support.p002v7.widget.TintTypedArray;
import android.support.p002v7.widget.ViewStubCompat;
import android.support.p002v7.widget.ViewUtils;
import android.support.v7.app.AppCompatDelegateImpl.C00803;
import android.support.v7.app.AppCompatDelegateImpl.C00815;
import android.support.v7.app.AppCompatDelegateImpl.C00826;
import android.support.v7.app.AppCompatDelegateImpl.C00837;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory2;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.collection.SimpleArrayMap;
import androidx.core.content.ContextCompat.Api23Impl;
import androidx.lifecycle.Lifecycle.State;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import com.google.android.wearable.sysui.R;
import java.lang.ref.WeakReference;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v7.app.AppCompatDelegateImpl */
public final class AppCompatDelegateImpl extends AppCompatDelegate implements Callback, Factory2 {
    public static final boolean sCanApplyOverrideConfiguration = true;
    public static final boolean sCanReturnDifferentContext = ("robolectric".equals(Build.FINGERPRINT) ^ true);
    private static final SimpleArrayMap sLocalNightModes = new SimpleArrayMap();
    private static final int[] sWindowBackgroundStyleable = new int[]{16842836};
    ActionBar mActionBar;
    private ActionMenuPresenterCallback mActionMenuPresenterCallback;
    ActionMode mActionMode;
    public PopupWindow mActionModePopup;
    ActionBarContextView mActionModeView;
    private boolean mActivityHandlesUiMode;
    private boolean mActivityHandlesUiModeChecked;
    private AppCompatViewInflater mAppCompatViewInflater;
    private AppCompatWindowCallback mAppCompatWindowCallback;
    private AutoNightModeManager mAutoBatteryNightModeManager;
    private AutoNightModeManager mAutoTimeNightModeManager;
    public boolean mBaseContextAttached;
    private boolean mClosingActionMenu;
    final Context mContext;
    private boolean mCreated;
    public DecorContentParent mDecorContentParent;
    private boolean mEnableDefaultActionBarUp;
    ViewPropertyAnimatorCompat mFadeAnim = null;
    private boolean mFeatureIndeterminateProgress;
    private boolean mFeatureProgress;
    public boolean mHandleNativeActionModes = true;
    boolean mHasActionBar;
    final Object mHost;
    int mInvalidatePanelMenuFeatures;
    boolean mInvalidatePanelMenuPosted;
    private final Runnable mInvalidatePanelMenuRunnable = new PG();
    boolean mIsDestroyed;
    boolean mIsFloating;
    private int mLocalNightMode = -100;
    private boolean mLongPressBackDown;
    MenuInflater mMenuInflater;
    boolean mOverlayActionBar;
    boolean mOverlayActionMode;
    private PanelMenuPresenterCallback mPanelMenuPresenterCallback;
    private PanelFeatureState[] mPanels;
    public PanelFeatureState mPreparedPanel;
    public Runnable mShowActionModePopup;
    public boolean mStarted;
    public View mStatusGuard;
    ViewGroup mSubDecor;
    public boolean mSubDecorInstalled;
    public Rect mTempRect1;
    public Rect mTempRect2;
    public int mThemeResId;
    private CharSequence mTitle;
    private TextView mTitleView;
    public Window mWindow;
    boolean mWindowNoTitle;

    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$2 */
    final class PG implements Runnable {
        public final void run() {
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if ((appCompatDelegateImpl.mInvalidatePanelMenuFeatures & 1) != 0) {
                appCompatDelegateImpl.doInvalidatePanelMenu(0);
            }
            appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if ((appCompatDelegateImpl.mInvalidatePanelMenuFeatures & 4096) != 0) {
                appCompatDelegateImpl.doInvalidatePanelMenu(108);
            }
            appCompatDelegateImpl = AppCompatDelegateImpl.this;
            appCompatDelegateImpl.mInvalidatePanelMenuPosted = false;
            appCompatDelegateImpl.mInvalidatePanelMenuFeatures = 0;
        }
    }

    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$3 */
    final class C00803 implements OnApplyWindowInsetsListener {
        public final WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
            Object obj;
            View view2;
            WindowInsetsCompat replaceSystemWindowInsets;
            int systemWindowInsetTop = windowInsetsCompat.getSystemWindowInsetTop();
            android.support.p002v7.app.AppCompatDelegateImpl appCompatDelegateImpl = android.support.p002v7.app.AppCompatDelegateImpl.this;
            int systemWindowInsetTop2 = windowInsetsCompat.getSystemWindowInsetTop();
            ViewGroup viewGroup = appCompatDelegateImpl.mActionModeView;
            int i = 8;
            if (viewGroup == null || !(viewGroup.getLayoutParams() instanceof MarginLayoutParams)) {
                obj = null;
            } else {
                Object obj2;
                MarginLayoutParams marginLayoutParams = (MarginLayoutParams) appCompatDelegateImpl.mActionModeView.getLayoutParams();
                if (appCompatDelegateImpl.mActionModeView.isShown()) {
                    int i2;
                    int i3;
                    MarginLayoutParams marginLayoutParams2;
                    if (appCompatDelegateImpl.mTempRect1 == null) {
                        appCompatDelegateImpl.mTempRect1 = new Rect();
                        appCompatDelegateImpl.mTempRect2 = new Rect();
                    }
                    Rect rect = appCompatDelegateImpl.mTempRect1;
                    Rect rect2 = appCompatDelegateImpl.mTempRect2;
                    rect.set(windowInsetsCompat.getSystemWindowInsetLeft(), windowInsetsCompat.getSystemWindowInsetTop(), windowInsetsCompat.getSystemWindowInsetRight(), windowInsetsCompat.getSystemWindowInsetBottom());
                    ViewGroup viewGroup2 = appCompatDelegateImpl.mSubDecor;
                    if (ViewUtils.sComputeFitSystemWindowsMethod != null) {
                        try {
                            ViewUtils.sComputeFitSystemWindowsMethod.invoke(viewGroup2, new Object[]{rect, rect2});
                        } catch (Throwable e) {
                            Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", e);
                        }
                    }
                    int i4 = rect.top;
                    int i5 = rect.left;
                    int i6 = rect.right;
                    WindowInsetsCompat rootWindowInsets = ViewCompat.getRootWindowInsets(appCompatDelegateImpl.mSubDecor);
                    if (rootWindowInsets == null) {
                        i2 = 0;
                    } else {
                        i2 = rootWindowInsets.getSystemWindowInsetLeft();
                    }
                    if (rootWindowInsets == null) {
                        i3 = 0;
                    } else {
                        i3 = rootWindowInsets.getSystemWindowInsetRight();
                    }
                    if (marginLayoutParams.topMargin == i4 && marginLayoutParams.leftMargin == i5) {
                        if (marginLayoutParams.rightMargin == i6) {
                            obj2 = null;
                            if (i4 > 0 || appCompatDelegateImpl.mStatusGuard != null) {
                                view2 = appCompatDelegateImpl.mStatusGuard;
                                if (view2 != null) {
                                    marginLayoutParams2 = (MarginLayoutParams) view2.getLayoutParams();
                                    if (!(marginLayoutParams2.height == marginLayoutParams.topMargin && marginLayoutParams2.leftMargin == i2 && marginLayoutParams2.rightMargin == i3)) {
                                        marginLayoutParams2.height = marginLayoutParams.topMargin;
                                        marginLayoutParams2.leftMargin = i2;
                                        marginLayoutParams2.rightMargin = i3;
                                        appCompatDelegateImpl.mStatusGuard.setLayoutParams(marginLayoutParams2);
                                    }
                                }
                            } else {
                                appCompatDelegateImpl.mStatusGuard = new View(appCompatDelegateImpl.mContext);
                                appCompatDelegateImpl.mStatusGuard.setVisibility(8);
                                LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                                layoutParams.leftMargin = i2;
                                layoutParams.rightMargin = i3;
                                appCompatDelegateImpl.mSubDecor.addView(appCompatDelegateImpl.mStatusGuard, -1, layoutParams);
                            }
                            view2 = appCompatDelegateImpl.mStatusGuard;
                            if (view2 == null) {
                                obj = 1;
                            } else {
                                obj = null;
                            }
                            if (!(obj == null || view2.getVisibility() == 0)) {
                                view2 = appCompatDelegateImpl.mStatusGuard;
                                if ((ViewCompat.getWindowSystemUiVisibility(view2) & 8192) == 0) {
                                    i3 = Api23Impl.getColor(appCompatDelegateImpl.mContext, R.color.abc_decor_view_status_guard_light);
                                } else {
                                    i3 = Api23Impl.getColor(appCompatDelegateImpl.mContext, R.color.abc_decor_view_status_guard);
                                }
                                view2.setBackgroundColor(i3);
                            }
                            if (appCompatDelegateImpl.mOverlayActionMode && obj != null) {
                                systemWindowInsetTop2 = 0;
                            }
                        }
                    }
                    marginLayoutParams.topMargin = i4;
                    marginLayoutParams.leftMargin = i5;
                    marginLayoutParams.rightMargin = i6;
                    obj2 = 1;
                    if (i4 > 0) {
                    }
                    view2 = appCompatDelegateImpl.mStatusGuard;
                    if (view2 != null) {
                        marginLayoutParams2 = (MarginLayoutParams) view2.getLayoutParams();
                        marginLayoutParams2.height = marginLayoutParams.topMargin;
                        marginLayoutParams2.leftMargin = i2;
                        marginLayoutParams2.rightMargin = i3;
                        appCompatDelegateImpl.mStatusGuard.setLayoutParams(marginLayoutParams2);
                    }
                    view2 = appCompatDelegateImpl.mStatusGuard;
                    if (view2 == null) {
                        obj = null;
                    } else {
                        obj = 1;
                    }
                    view2 = appCompatDelegateImpl.mStatusGuard;
                    if ((ViewCompat.getWindowSystemUiVisibility(view2) & 8192) == 0) {
                        i3 = Api23Impl.getColor(appCompatDelegateImpl.mContext, R.color.abc_decor_view_status_guard);
                    } else {
                        i3 = Api23Impl.getColor(appCompatDelegateImpl.mContext, R.color.abc_decor_view_status_guard_light);
                    }
                    view2.setBackgroundColor(i3);
                    if (appCompatDelegateImpl.mOverlayActionMode) {
                    }
                } else {
                    if (marginLayoutParams.topMargin != 0) {
                        marginLayoutParams.topMargin = 0;
                        obj2 = 1;
                    } else {
                        obj2 = null;
                    }
                    obj = null;
                }
                if (obj2 != null) {
                    appCompatDelegateImpl.mActionModeView.setLayoutParams(marginLayoutParams);
                }
            }
            view2 = appCompatDelegateImpl.mStatusGuard;
            if (view2 != null) {
                if (1 == obj) {
                    i = 0;
                }
                view2.setVisibility(i);
            }
            if (systemWindowInsetTop != systemWindowInsetTop2) {
                replaceSystemWindowInsets = windowInsetsCompat.replaceSystemWindowInsets(windowInsetsCompat.getSystemWindowInsetLeft(), systemWindowInsetTop2, windowInsetsCompat.getSystemWindowInsetRight(), windowInsetsCompat.getSystemWindowInsetBottom());
            } else {
                replaceSystemWindowInsets = windowInsetsCompat;
            }
            return ViewCompat.onApplyWindowInsets(view, replaceSystemWindowInsets);
        }
    }

    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$5 */
    public final class C00815 {
    }

    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$6 */
    final class C00826 implements Runnable {

        /* renamed from: android.support.v7.app.AppCompatDelegateImpl$6$1 */
        final class PG extends ViewPropertyAnimatorListenerAdapter {
            public final void onAnimationEnd$ar$ds() {
                AppCompatDelegateImpl.this.mActionModeView.setAlpha(1.0f);
                AppCompatDelegateImpl.this.mFadeAnim.setListener$ar$ds(null);
                AppCompatDelegateImpl.this.mFadeAnim = null;
            }

            public final void onAnimationStart$ar$ds() {
                AppCompatDelegateImpl.this.mActionModeView.setVisibility(0);
            }
        }

        public final void run() {
            android.support.p002v7.app.AppCompatDelegateImpl appCompatDelegateImpl = android.support.p002v7.app.AppCompatDelegateImpl.this;
            appCompatDelegateImpl.mActionModePopup.showAtLocation(appCompatDelegateImpl.mActionModeView, 55, 0, 0);
            android.support.p002v7.app.AppCompatDelegateImpl.this.endOnGoingFadeAnimation();
            if (android.support.p002v7.app.AppCompatDelegateImpl.this.shouldAnimateActionModeView()) {
                android.support.p002v7.app.AppCompatDelegateImpl.this.mActionModeView.setAlpha(0.0f);
                appCompatDelegateImpl = android.support.p002v7.app.AppCompatDelegateImpl.this;
                ViewPropertyAnimatorCompat animate = ViewCompat.animate(appCompatDelegateImpl.mActionModeView);
                animate.alpha$ar$ds(1.0f);
                appCompatDelegateImpl.mFadeAnim = animate;
                android.support.p002v7.app.AppCompatDelegateImpl.this.mFadeAnim.setListener$ar$ds(new android.support.p002v7.app.AppCompatDelegateImpl.PG.PG());
                return;
            }
            android.support.p002v7.app.AppCompatDelegateImpl.this.mActionModeView.setAlpha(1.0f);
            android.support.p002v7.app.AppCompatDelegateImpl.this.mActionModeView.setVisibility(0);
        }
    }

    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$7 */
    final class C00837 extends ViewPropertyAnimatorListenerAdapter {
        public final void onAnimationEnd$ar$ds() {
            android.support.p002v7.app.AppCompatDelegateImpl.this.mActionModeView.setAlpha(1.0f);
            android.support.p002v7.app.AppCompatDelegateImpl.this.mFadeAnim.setListener$ar$ds(null);
            android.support.p002v7.app.AppCompatDelegateImpl.this.mFadeAnim = null;
        }

        public final void onAnimationStart$ar$ds() {
            android.support.p002v7.app.AppCompatDelegateImpl.this.mActionModeView.setVisibility(0);
            android.support.p002v7.app.AppCompatDelegateImpl.this.mActionModeView.sendAccessibilityEvent(32);
            if (android.support.p002v7.app.AppCompatDelegateImpl.this.mActionModeView.getParent() instanceof View) {
                ViewCompat.requestApplyInsets((View) android.support.p002v7.app.AppCompatDelegateImpl.this.mActionModeView.getParent());
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$ActionMenuPresenterCallback */
    final class ActionMenuPresenterCallback implements MenuPresenter.Callback {
        public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
            AppCompatDelegateImpl.this.checkCloseActionMenu(menuBuilder);
        }

        public final boolean onOpenSubMenu(MenuBuilder menuBuilder) {
            Window.Callback windowCallback = AppCompatDelegateImpl.this.getWindowCallback();
            if (windowCallback != null) {
                windowCallback.onMenuOpened(108, menuBuilder);
            }
            return true;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$ActionModeCallbackWrapperV9 */
    final class ActionModeCallbackWrapperV9 implements ActionMode.Callback {
        private final ActionMode.Callback mWrapped;

        /* renamed from: android.support.v7.app.AppCompatDelegateImpl$ActionModeCallbackWrapperV9$1 */
        final class PG extends ViewPropertyAnimatorListenerAdapter {
            public final void onAnimationEnd$ar$ds() {
                AppCompatDelegateImpl.this.mActionModeView.setVisibility(8);
                AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
                PopupWindow popupWindow = appCompatDelegateImpl.mActionModePopup;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (appCompatDelegateImpl.mActionModeView.getParent() instanceof View) {
                    ViewCompat.requestApplyInsets((View) AppCompatDelegateImpl.this.mActionModeView.getParent());
                }
                AppCompatDelegateImpl.this.mActionModeView.killMode();
                AppCompatDelegateImpl.this.mFadeAnim.setListener$ar$ds(null);
                appCompatDelegateImpl = AppCompatDelegateImpl.this;
                appCompatDelegateImpl.mFadeAnim = null;
                ViewCompat.requestApplyInsets(appCompatDelegateImpl.mSubDecor);
            }
        }

        public ActionModeCallbackWrapperV9(ActionMode.Callback callback) {
            this.mWrapped = callback;
        }

        public final void onPrepareActionMode$ar$ds(ActionMode actionMode, Menu menu) {
            ViewCompat.requestApplyInsets(AppCompatDelegateImpl.this.mSubDecor);
            CallbackWrapper callbackWrapper = (CallbackWrapper) this.mWrapped;
            callbackWrapper.mWrappedCallback.onPrepareActionMode(callbackWrapper.getActionModeWrapper(actionMode), callbackWrapper.getMenuWrapper(menu));
        }

        public final boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            CallbackWrapper callbackWrapper = (CallbackWrapper) this.mWrapped;
            return callbackWrapper.mWrappedCallback.onActionItemClicked(callbackWrapper.getActionModeWrapper(actionMode), new MenuItemWrapperICS(callbackWrapper.mContext, menuItem));
        }

        public final boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            CallbackWrapper callbackWrapper = (CallbackWrapper) this.mWrapped;
            return callbackWrapper.mWrappedCallback.onCreateActionMode(callbackWrapper.getActionModeWrapper(actionMode), callbackWrapper.getMenuWrapper(menu));
        }

        public final void onDestroyActionMode(ActionMode actionMode) {
            CallbackWrapper callbackWrapper = (CallbackWrapper) this.mWrapped;
            callbackWrapper.mWrappedCallback.onDestroyActionMode(callbackWrapper.getActionModeWrapper(actionMode));
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (appCompatDelegateImpl.mActionModePopup != null) {
                appCompatDelegateImpl.mWindow.getDecorView().removeCallbacks(AppCompatDelegateImpl.this.mShowActionModePopup);
            }
            appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (appCompatDelegateImpl.mActionModeView != null) {
                appCompatDelegateImpl.endOnGoingFadeAnimation();
                appCompatDelegateImpl = AppCompatDelegateImpl.this;
                ViewPropertyAnimatorCompat animate = ViewCompat.animate(appCompatDelegateImpl.mActionModeView);
                animate.alpha$ar$ds(0.0f);
                appCompatDelegateImpl.mFadeAnim = animate;
                AppCompatDelegateImpl.this.mFadeAnim.setListener$ar$ds(new PG());
            }
            appCompatDelegateImpl = AppCompatDelegateImpl.this;
            appCompatDelegateImpl.mActionMode = null;
            ViewCompat.requestApplyInsets(appCompatDelegateImpl.mSubDecor);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$AppCompatWindowCallback */
    final class AppCompatWindowCallback extends WindowCallbackWrapper {
        public AppCompatWindowCallback(Window.Callback callback) {
            super(callback);
        }

        public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
            if (!AppCompatDelegateImpl.this.dispatchKeyEvent(keyEvent)) {
                if (!super.dispatchKeyEvent(keyEvent)) {
                    return false;
                }
            }
            return true;
        }

        public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            if (!super.dispatchKeyShortcutEvent(keyEvent)) {
                AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
                int keyCode = keyEvent.getKeyCode();
                ActionBar supportActionBar = appCompatDelegateImpl.getSupportActionBar();
                if (supportActionBar != null) {
                    ActionModeImpl actionModeImpl = ((WindowDecorActionBar) supportActionBar).mActionMode;
                    if (actionModeImpl != null) {
                        int deviceId;
                        Menu menu = actionModeImpl.mMenu;
                        if (keyEvent != null) {
                            deviceId = keyEvent.getDeviceId();
                        } else {
                            deviceId = -1;
                        }
                        menu.setQwertyMode(KeyCharacterMap.load(deviceId).getKeyboardType() != 1);
                        if (menu.performShortcut(keyCode, keyEvent, 0)) {
                        }
                    }
                }
                PanelFeatureState panelFeatureState = appCompatDelegateImpl.mPreparedPanel;
                if (panelFeatureState == null || !appCompatDelegateImpl.performPanelShortcut$ar$ds(panelFeatureState, keyEvent.getKeyCode(), keyEvent)) {
                    if (appCompatDelegateImpl.mPreparedPanel == null) {
                        panelFeatureState = appCompatDelegateImpl.getPanelState$ar$ds(0);
                        appCompatDelegateImpl.preparePanel(panelFeatureState, keyEvent);
                        boolean performPanelShortcut$ar$ds = appCompatDelegateImpl.performPanelShortcut$ar$ds(panelFeatureState, keyEvent.getKeyCode(), keyEvent);
                        panelFeatureState.isPrepared = false;
                        if (!performPanelShortcut$ar$ds) {
                            return false;
                        }
                    }
                    return false;
                }
                PanelFeatureState panelFeatureState2 = appCompatDelegateImpl.mPreparedPanel;
                if (panelFeatureState2 != null) {
                    panelFeatureState2.isHandled = true;
                }
            }
            return true;
        }

        public final void onContentChanged() {
        }

        public final boolean onCreatePanelMenu(int i, Menu menu) {
            if (i == 0) {
                if (!(menu instanceof MenuBuilder)) {
                    return false;
                }
                i = 0;
            }
            return super.onCreatePanelMenu(i, menu);
        }

        public final boolean onMenuOpened(int i, Menu menu) {
            super.onMenuOpened(i, menu);
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (i == 108) {
                ActionBar supportActionBar = appCompatDelegateImpl.getSupportActionBar();
                if (supportActionBar != null) {
                    supportActionBar.dispatchMenuVisibilityChanged(true);
                }
            }
            return true;
        }

        public final void onPanelClosed(int i, Menu menu) {
            super.onPanelClosed(i, menu);
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (i == 108) {
                ActionBar supportActionBar = appCompatDelegateImpl.getSupportActionBar();
                if (supportActionBar != null) {
                    supportActionBar.dispatchMenuVisibilityChanged(false);
                }
            } else if (i == 0) {
                PanelFeatureState panelState$ar$ds = appCompatDelegateImpl.getPanelState$ar$ds(0);
                if (panelState$ar$ds.isOpen) {
                    appCompatDelegateImpl.closePanel(panelState$ar$ds, false);
                }
            }
        }

        public final boolean onPreparePanel(int i, View view, Menu menu) {
            MenuBuilder menuBuilder;
            if (menu instanceof MenuBuilder) {
                menuBuilder = (MenuBuilder) menu;
            } else {
                menuBuilder = null;
            }
            if (i == 0) {
                if (menuBuilder == null) {
                    return false;
                }
                i = 0;
            }
            if (menuBuilder != null) {
                menuBuilder.mOverrideVisibleItems = true;
            }
            boolean onPreparePanel = super.onPreparePanel(i, view, menu);
            if (menuBuilder != null) {
                menuBuilder.mOverrideVisibleItems = false;
            }
            return onPreparePanel;
        }

        public final void onProvideKeyboardShortcuts(List list, Menu menu, int i) {
            Menu menu2 = AppCompatDelegateImpl.this.getPanelState$ar$ds(0).menu;
            if (menu2 != null) {
                super.onProvideKeyboardShortcuts(list, menu2, i);
            } else {
                super.onProvideKeyboardShortcuts(list, menu, i);
            }
        }

        public final android.view.ActionMode onWindowStartingActionMode(android.view.ActionMode.Callback callback) {
            return null;
        }

        public final android.view.ActionMode onWindowStartingActionMode(android.view.ActionMode.Callback callback, int i) {
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (appCompatDelegateImpl.mHandleNativeActionModes) {
                switch (i) {
                    case 0:
                        CallbackWrapper callbackWrapper = new CallbackWrapper(appCompatDelegateImpl.mContext, callback);
                        AppCompatDelegateImpl appCompatDelegateImpl2 = AppCompatDelegateImpl.this;
                        ActionMode actionMode = appCompatDelegateImpl2.mActionMode;
                        if (actionMode != null) {
                            actionMode.finish();
                        }
                        ActionMode.Callback actionModeCallbackWrapperV9 = new ActionModeCallbackWrapperV9(callbackWrapper);
                        ActionBar supportActionBar = appCompatDelegateImpl2.getSupportActionBar();
                        if (supportActionBar != null) {
                            WindowDecorActionBar windowDecorActionBar = (WindowDecorActionBar) supportActionBar;
                            ActionModeImpl actionModeImpl = windowDecorActionBar.mActionMode;
                            if (actionModeImpl != null) {
                                actionModeImpl.finish();
                            }
                            windowDecorActionBar.mOverlayLayout.setHideOnContentScrollEnabled(false);
                            windowDecorActionBar.mContextView.killMode();
                            ActionMode actionModeImpl2 = new ActionModeImpl(windowDecorActionBar.mContextView.getContext(), actionModeCallbackWrapperV9);
                            MenuBuilder menuBuilder = actionModeImpl2.mMenu;
                            menuBuilder.stopDispatchingItemsChanged();
                            try {
                                menuBuilder = actionModeImpl2.mCallback.onCreateActionMode(actionModeImpl2, actionModeImpl2.mMenu);
                                if (menuBuilder != null) {
                                    windowDecorActionBar.mActionMode = actionModeImpl2;
                                    actionModeImpl2.invalidate();
                                    windowDecorActionBar.mContextView.initForMode(actionModeImpl2);
                                    windowDecorActionBar.animateToMode(true);
                                    windowDecorActionBar.mContextView.sendAccessibilityEvent(32);
                                } else {
                                    actionModeImpl2 = null;
                                }
                                appCompatDelegateImpl2.mActionMode = actionModeImpl2;
                            } finally {
                                callbackWrapper = actionModeImpl2.mMenu;
                                callbackWrapper.startDispatchingItemsChanged();
                            }
                        }
                        ActionMode actionMode2 = appCompatDelegateImpl2.mActionMode;
                        if (actionMode2 == null) {
                            appCompatDelegateImpl2.endOnGoingFadeAnimation();
                            actionMode2 = appCompatDelegateImpl2.mActionMode;
                            if (actionMode2 != null) {
                                actionMode2.finish();
                            }
                            if (appCompatDelegateImpl2.mActionModeView == null) {
                                if (appCompatDelegateImpl2.mIsFloating) {
                                    Context contextThemeWrapper;
                                    TypedValue typedValue = new TypedValue();
                                    Theme theme = appCompatDelegateImpl2.mContext.getTheme();
                                    theme.resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                                    if (typedValue.resourceId != 0) {
                                        Theme newTheme = appCompatDelegateImpl2.mContext.getResources().newTheme();
                                        newTheme.setTo(theme);
                                        newTheme.applyStyle(typedValue.resourceId, true);
                                        contextThemeWrapper = new ContextThemeWrapper(appCompatDelegateImpl2.mContext, 0);
                                        contextThemeWrapper.getTheme().setTo(newTheme);
                                    } else {
                                        contextThemeWrapper = appCompatDelegateImpl2.mContext;
                                    }
                                    appCompatDelegateImpl2.mActionModeView = new ActionBarContextView(contextThemeWrapper);
                                    appCompatDelegateImpl2.mActionModePopup = new PopupWindow(contextThemeWrapper, null, R.attr.actionModePopupWindowStyle);
                                    PopupWindowCompat$Api23Impl.setWindowLayoutType(appCompatDelegateImpl2.mActionModePopup, 2);
                                    appCompatDelegateImpl2.mActionModePopup.setContentView(appCompatDelegateImpl2.mActionModeView);
                                    appCompatDelegateImpl2.mActionModePopup.setWidth(-1);
                                    contextThemeWrapper.getTheme().resolveAttribute(R.attr.actionBarSize, typedValue, true);
                                    appCompatDelegateImpl2.mActionModeView.mContentHeight = TypedValue.complexToDimensionPixelSize(typedValue.data, contextThemeWrapper.getResources().getDisplayMetrics());
                                    appCompatDelegateImpl2.mActionModePopup.setHeight(-2);
                                    appCompatDelegateImpl2.mShowActionModePopup = new C00826();
                                } else {
                                    ViewStubCompat viewStubCompat = (ViewStubCompat) appCompatDelegateImpl2.mSubDecor.findViewById(R.id.action_mode_bar_stub);
                                    if (viewStubCompat != null) {
                                        viewStubCompat.mInflater = LayoutInflater.from(appCompatDelegateImpl2.getActionBarThemedContext());
                                        appCompatDelegateImpl2.mActionModeView = (ActionBarContextView) viewStubCompat.inflate();
                                    }
                                }
                            }
                            if (appCompatDelegateImpl2.mActionModeView != null) {
                                appCompatDelegateImpl2.endOnGoingFadeAnimation();
                                appCompatDelegateImpl2.mActionModeView.killMode();
                                actionMode2 = new StandaloneActionMode(appCompatDelegateImpl2.mActionModeView.getContext(), appCompatDelegateImpl2.mActionModeView, actionModeCallbackWrapperV9);
                                if (actionModeCallbackWrapperV9.onCreateActionMode(actionMode2, actionMode2.mMenu)) {
                                    actionMode2.invalidate();
                                    appCompatDelegateImpl2.mActionModeView.initForMode(actionMode2);
                                    appCompatDelegateImpl2.mActionMode = actionMode2;
                                    if (appCompatDelegateImpl2.shouldAnimateActionModeView()) {
                                        appCompatDelegateImpl2.mActionModeView.setAlpha(0.0f);
                                        ViewPropertyAnimatorCompat animate = ViewCompat.animate(appCompatDelegateImpl2.mActionModeView);
                                        animate.alpha$ar$ds(1.0f);
                                        appCompatDelegateImpl2.mFadeAnim = animate;
                                        appCompatDelegateImpl2.mFadeAnim.setListener$ar$ds(new C00837());
                                    } else {
                                        appCompatDelegateImpl2.mActionModeView.setAlpha(1.0f);
                                        appCompatDelegateImpl2.mActionModeView.setVisibility(0);
                                        appCompatDelegateImpl2.mActionModeView.sendAccessibilityEvent(32);
                                        if (appCompatDelegateImpl2.mActionModeView.getParent() instanceof View) {
                                            ViewCompat.requestApplyInsets((View) appCompatDelegateImpl2.mActionModeView.getParent());
                                        }
                                    }
                                    if (appCompatDelegateImpl2.mActionModePopup != null) {
                                        appCompatDelegateImpl2.mWindow.getDecorView().post(appCompatDelegateImpl2.mShowActionModePopup);
                                    }
                                } else {
                                    appCompatDelegateImpl2.mActionMode = null;
                                }
                            }
                            actionMode2 = appCompatDelegateImpl2.mActionMode;
                        }
                        if (actionMode2 != null) {
                            return callbackWrapper.getActionModeWrapper(actionMode2);
                        }
                        return null;
                    default:
                        break;
                }
            }
            return super.onWindowStartingActionMode(callback, i);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$AutoBatteryNightModeManager */
    final class AutoBatteryNightModeManager extends AutoNightModeManager {
        public final PowerManager mPowerManager;

        public AutoBatteryNightModeManager(Context context) {
            super();
            this.mPowerManager = (PowerManager) context.getApplicationContext().getSystemService("power");
        }

        public final IntentFilter createIntentFilterForBroadcastReceiver() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
            return intentFilter;
        }

        public final void onChange() {
            AppCompatDelegateImpl.this.applyDayNight$ar$ds();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$AutoNightModeManager */
    abstract class AutoNightModeManager {
        private BroadcastReceiver mReceiver;

        /* renamed from: android.support.v7.app.AppCompatDelegateImpl$AutoNightModeManager$1 */
        final class PG extends BroadcastReceiver {
            public final void onReceive(Context context, Intent intent) {
                AutoNightModeManager.this.onChange();
            }
        }

        final void cleanup() {
            BroadcastReceiver broadcastReceiver = this.mReceiver;
            if (broadcastReceiver != null) {
                try {
                    AppCompatDelegateImpl.this.mContext.unregisterReceiver(broadcastReceiver);
                } catch (IllegalArgumentException e) {
                }
                this.mReceiver = null;
            }
        }

        public abstract IntentFilter createIntentFilterForBroadcastReceiver();

        public abstract void onChange();

        final void setup() {
            cleanup();
            IntentFilter createIntentFilterForBroadcastReceiver = createIntentFilterForBroadcastReceiver();
            if (createIntentFilterForBroadcastReceiver.countActions() != 0) {
                if (this.mReceiver == null) {
                    this.mReceiver = new PG();
                }
                AppCompatDelegateImpl.this.mContext.registerReceiver(this.mReceiver, createIntentFilterForBroadcastReceiver);
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$AutoTimeNightModeManager */
    final class AutoTimeNightModeManager extends AutoNightModeManager {
        public final TwilightManager mTwilightManager;

        public AutoTimeNightModeManager(TwilightManager twilightManager) {
            super();
            this.mTwilightManager = twilightManager;
        }

        public final IntentFilter createIntentFilterForBroadcastReceiver() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_TICK");
            return intentFilter;
        }

        public final void onChange() {
            AppCompatDelegateImpl.this.applyDayNight$ar$ds();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$ListMenuDecorView */
    final class ListMenuDecorView extends ContentFrameLayout {
        public ListMenuDecorView(Context context) {
            super(context);
        }

        public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
            if (!AppCompatDelegateImpl.this.dispatchKeyEvent(keyEvent)) {
                if (!super.dispatchKeyEvent(keyEvent)) {
                    return false;
                }
            }
            return true;
        }

        public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() == 0) {
                int x = (int) motionEvent.getX();
                int y = (int) motionEvent.getY();
                if (x < -5 || y < -5 || x > getWidth() + 5 || y > getHeight() + 5) {
                    AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
                    appCompatDelegateImpl.closePanel(appCompatDelegateImpl.getPanelState$ar$ds(0), true);
                    return true;
                }
            }
            return super.onInterceptTouchEvent(motionEvent);
        }

        public final void setBackgroundResource(int i) {
            setBackgroundDrawable(AppCompatResources.getDrawable(getContext(), i));
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$PanelFeatureState */
    public final class PanelFeatureState {
        int background;
        View createdPanelView;
        ViewGroup decorView;
        final int featureId;
        Bundle frozenActionViewState;
        int gravity;
        boolean isHandled;
        boolean isOpen;
        boolean isPrepared;
        ListMenuPresenter listMenuPresenter;
        Context listPresenterContext;
        public MenuBuilder menu;
        boolean refreshDecorView = false;
        boolean refreshMenuContent;
        View shownPanelView;
        int windowAnimations;

        public PanelFeatureState(int i) {
            this.featureId = i;
        }

        final void setMenu(MenuBuilder menuBuilder) {
            MenuBuilder menuBuilder2 = this.menu;
            if (menuBuilder != menuBuilder2) {
                if (menuBuilder2 != null) {
                    menuBuilder2.removeMenuPresenter(this.listMenuPresenter);
                }
                this.menu = menuBuilder;
                if (menuBuilder != null) {
                    MenuPresenter menuPresenter = this.listMenuPresenter;
                    if (menuPresenter != null) {
                        menuBuilder.addMenuPresenter(menuPresenter);
                    }
                }
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatDelegateImpl$PanelMenuPresenterCallback */
    final class PanelMenuPresenterCallback implements MenuPresenter.Callback {
        public final void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
            Menu menu;
            MenuBuilder rootMenu = menuBuilder.getRootMenu();
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (rootMenu != menuBuilder) {
                menu = rootMenu;
            } else {
                menu = menuBuilder;
            }
            PanelFeatureState findMenuPanel = appCompatDelegateImpl.findMenuPanel(menu);
            if (findMenuPanel != null) {
                if (rootMenu != menuBuilder) {
                    AppCompatDelegateImpl.this.callOnPanelClosed(findMenuPanel.featureId, findMenuPanel, rootMenu);
                    AppCompatDelegateImpl.this.closePanel(findMenuPanel, true);
                    return;
                }
                AppCompatDelegateImpl.this.closePanel(findMenuPanel, z);
            }
        }

        public final boolean onOpenSubMenu(MenuBuilder menuBuilder) {
            if (menuBuilder == menuBuilder.getRootMenu()) {
                AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
                if (appCompatDelegateImpl.mHasActionBar) {
                    Window.Callback windowCallback = appCompatDelegateImpl.getWindowCallback();
                    if (!(windowCallback == null || AppCompatDelegateImpl.this.mIsDestroyed)) {
                        windowCallback.onMenuOpened(108, menuBuilder);
                    }
                }
            }
            return true;
        }
    }

    public AppCompatDelegateImpl(Context context, Window window, Object obj) {
        AppCompatActivity appCompatActivity = null;
        this.mContext = context;
        this.mHost = obj;
        if (this.mLocalNightMode == -100 && (obj instanceof Dialog)) {
            while (context != null) {
                if (!(context instanceof AppCompatActivity)) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    }
                    context = ((ContextWrapper) context).getBaseContext();
                } else {
                    appCompatActivity = (AppCompatActivity) context;
                    break;
                }
            }
            if (appCompatActivity != null) {
                this.mLocalNightMode = ((AppCompatDelegateImpl) appCompatActivity.getDelegate()).mLocalNightMode;
            }
        }
        if (this.mLocalNightMode == -100) {
            SimpleArrayMap simpleArrayMap = sLocalNightModes;
            Integer num = (Integer) simpleArrayMap.get(this.mHost.getClass().getName());
            if (num != null) {
                this.mLocalNightMode = num.intValue();
                simpleArrayMap.remove(this.mHost.getClass().getName());
            }
        }
        if (window != null) {
            attachToWindow(window);
        }
        AppCompatDrawableManager.preload();
    }

    private final void attachToWindow(Window window) {
        String str = "AppCompat has already installed itself into the Window";
        if (this.mWindow == null) {
            Window.Callback callback = window.getCallback();
            if (callback instanceof AppCompatWindowCallback) {
                throw new IllegalStateException(str);
            }
            Window.Callback appCompatWindowCallback = new AppCompatWindowCallback(callback);
            this.mAppCompatWindowCallback = appCompatWindowCallback;
            window.setCallback(appCompatWindowCallback);
            TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(this.mContext, null, sWindowBackgroundStyleable);
            Drawable drawableIfKnown = obtainStyledAttributes.getDrawableIfKnown(0);
            if (drawableIfKnown != null) {
                window.setBackgroundDrawable(drawableIfKnown);
            }
            obtainStyledAttributes.recycle();
            this.mWindow = window;
            return;
        }
        throw new IllegalStateException(str);
    }

    private final void ensureWindow() {
        if (this.mWindow == null) {
            Object obj = this.mHost;
            if (obj instanceof Activity) {
                attachToWindow(((Activity) obj).getWindow());
            }
        }
        if (this.mWindow == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    private final AutoNightModeManager getAutoBatteryNightModeManager(Context context) {
        if (this.mAutoBatteryNightModeManager == null) {
            this.mAutoBatteryNightModeManager = new AutoBatteryNightModeManager(context);
        }
        return this.mAutoBatteryNightModeManager;
    }

    private final void invalidatePanelMenu(int i) {
        this.mInvalidatePanelMenuFeatures = (1 << i) | this.mInvalidatePanelMenuFeatures;
        if (!this.mInvalidatePanelMenuPosted) {
            ViewCompat.postOnAnimation(this.mWindow.getDecorView(), this.mInvalidatePanelMenuRunnable);
            this.mInvalidatePanelMenuPosted = true;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void openPanel(android.support.p002v7.app.AppCompatDelegateImpl.PanelFeatureState r14, android.view.KeyEvent r15) {
        /*
        r13 = this;
        r0 = r14.isOpen;
        if (r0 != 0) goto L_0x01cf;
    L_0x0004:
        r0 = r13.mIsDestroyed;
        if (r0 == 0) goto L_0x000a;
    L_0x0008:
        goto L_0x01cf;
    L_0x000a:
        r0 = r14.featureId;
        if (r0 != 0) goto L_0x0021;
    L_0x000e:
        r0 = r13.mContext;
        r0 = r0.getResources();
        r0 = r0.getConfiguration();
        r0 = r0.screenLayout;
        r0 = r0 & 15;
        r1 = 4;
        if (r0 == r1) goto L_0x0020;
    L_0x001f:
        goto L_0x0021;
    L_0x0020:
        return;
    L_0x0021:
        r0 = r13.getWindowCallback();
        r1 = 1;
        if (r0 == 0) goto L_0x0038;
    L_0x0028:
        r2 = r14.featureId;
        r3 = r14.menu;
        r0 = r0.onMenuOpened(r2, r3);
        if (r0 == 0) goto L_0x0033;
    L_0x0032:
        goto L_0x0038;
        r13.closePanel(r14, r1);
        return;
    L_0x0038:
        r0 = r13.mContext;
        r2 = "window";
        r0 = r0.getSystemService(r2);
        r0 = (android.view.WindowManager) r0;
        if (r0 != 0) goto L_0x0045;
    L_0x0044:
        return;
    L_0x0045:
        r15 = r13.preparePanel(r14, r15);
        if (r15 != 0) goto L_0x004c;
    L_0x004b:
        return;
    L_0x004c:
        r15 = r14.decorView;
        r2 = -1;
        r3 = 0;
        r4 = -2;
        if (r15 == 0) goto L_0x006c;
    L_0x0053:
        r5 = r14.refreshDecorView;
        if (r5 == 0) goto L_0x0058;
    L_0x0057:
        goto L_0x006c;
    L_0x0058:
        r15 = r14.createdPanelView;
        if (r15 == 0) goto L_0x0069;
    L_0x005c:
        r15 = r15.getLayoutParams();
        if (r15 == 0) goto L_0x0069;
    L_0x0062:
        r15 = r15.width;
        if (r15 != r2) goto L_0x0069;
    L_0x0066:
        r6 = -1;
        goto L_0x01ac;
    L_0x0069:
        r6 = -2;
        goto L_0x01ac;
    L_0x006c:
        if (r15 != 0) goto L_0x00e3;
    L_0x006e:
        r15 = r13.getActionBarThemedContext();
        r2 = new android.util.TypedValue;
        r2.<init>();
        r5 = r15.getResources();
        r5 = r5.newTheme();
        r6 = r15.getTheme();
        r5.setTo(r6);
        r6 = 2130968602; // 0x7f04001a float:1.7545862E38 double:1.0528383786E-314;
        r5.resolveAttribute(r6, r2, r1);
        r6 = r2.resourceId;
        if (r6 == 0) goto L_0x0095;
    L_0x0090:
        r6 = r2.resourceId;
        r5.applyStyle(r6, r1);
    L_0x0095:
        r6 = 2130969248; // 0x7f0402a0 float:1.7547173E38 double:1.052838698E-314;
        r5.resolveAttribute(r6, r2, r1);
        r6 = r2.resourceId;
        if (r6 == 0) goto L_0x00a5;
    L_0x009f:
        r2 = r2.resourceId;
        r5.applyStyle(r2, r1);
        goto L_0x00ab;
    L_0x00a5:
        r2 = 2132017573; // 0x7f1401a5 float:1.9673428E38 double:1.053356639E-314;
        r5.applyStyle(r2, r1);
    L_0x00ab:
        r2 = new androidx.appcompat.view.ContextThemeWrapper;
        r2.<init>(r15, r3);
        r15 = r2.getTheme();
        r15.setTo(r5);
        r14.listPresenterContext = r2;
        r15 = android.support.p002v7.appcompat.R$styleable.AppCompatTheme;
        r15 = r2.obtainStyledAttributes(r15);
        r2 = 86;
        r2 = r15.getResourceId(r2, r3);
        r14.background = r2;
        r2 = r15.getResourceId(r1, r3);
        r14.windowAnimations = r2;
        r15.recycle();
        r15 = new android.support.v7.app.AppCompatDelegateImpl$ListMenuDecorView;
        r2 = r14.listPresenterContext;
        r15.<init>(r2);
        r14.decorView = r15;
        r15 = 81;
        r14.gravity = r15;
        r15 = r14.decorView;
        if (r15 == 0) goto L_0x00e2;
    L_0x00e1:
        goto L_0x00f2;
    L_0x00e2:
        return;
    L_0x00e3:
        r2 = r14.refreshDecorView;
        if (r2 == 0) goto L_0x00f2;
    L_0x00e7:
        r15 = r15.getChildCount();
        if (r15 <= 0) goto L_0x00f2;
    L_0x00ed:
        r15 = r14.decorView;
        r15.removeAllViews();
    L_0x00f2:
        r15 = r14.createdPanelView;
        if (r15 == 0) goto L_0x00f9;
    L_0x00f6:
        r14.shownPanelView = r15;
        goto L_0x015a;
    L_0x00f9:
        r15 = r14.menu;
        if (r15 == 0) goto L_0x01cc;
    L_0x00fd:
        r15 = r13.mPanelMenuPresenterCallback;
        if (r15 != 0) goto L_0x0108;
    L_0x0101:
        r15 = new android.support.v7.app.AppCompatDelegateImpl$PanelMenuPresenterCallback;
        r15.<init>();
        r13.mPanelMenuPresenterCallback = r15;
    L_0x0108:
        r15 = r13.mPanelMenuPresenterCallback;
        r2 = r14.menu;
        if (r2 != 0) goto L_0x0110;
    L_0x010e:
        r15 = 0;
        goto L_0x0154;
    L_0x0110:
        r2 = r14.listMenuPresenter;
        if (r2 != 0) goto L_0x0126;
    L_0x0114:
        r2 = new android.support.v7.view.menu.ListMenuPresenter;
        r5 = r14.listPresenterContext;
        r2.<init>(r5);
        r14.listMenuPresenter = r2;
        r2 = r14.listMenuPresenter;
        r2.mCallback = r15;
        r15 = r14.menu;
        r15.addMenuPresenter(r2);
    L_0x0126:
        r15 = r14.listMenuPresenter;
        r2 = r14.decorView;
        r5 = r15.mMenuView;
        if (r5 != 0) goto L_0x0152;
    L_0x012e:
        r5 = r15.mInflater;
        r6 = 2131623949; // 0x7f0e000d float:1.8875064E38 double:1.053162163E-314;
        r2 = r5.inflate(r6, r2, r3);
        r2 = (android.support.p002v7.view.menu.ExpandedMenuView) r2;
        r15.mMenuView = r2;
        r2 = r15.mAdapter;
        if (r2 != 0) goto L_0x0146;
    L_0x013f:
        r2 = new android.support.v7.view.menu.ListMenuPresenter$MenuAdapter;
        r2.<init>();
        r15.mAdapter = r2;
    L_0x0146:
        r2 = r15.mMenuView;
        r5 = r15.mAdapter;
        r2.setAdapter(r5);
        r2 = r15.mMenuView;
        r2.setOnItemClickListener(r15);
    L_0x0152:
        r15 = r15.mMenuView;
    L_0x0154:
        r14.shownPanelView = r15;
        r15 = r14.shownPanelView;
        if (r15 == 0) goto L_0x01cc;
    L_0x015a:
        r15 = r14.shownPanelView;
        if (r15 != 0) goto L_0x015f;
    L_0x015e:
        goto L_0x01cc;
    L_0x015f:
        r15 = r14.createdPanelView;
        if (r15 == 0) goto L_0x0164;
    L_0x0163:
        goto L_0x0170;
    L_0x0164:
        r15 = r14.listMenuPresenter;
        r15 = r15.getAdapter();
        r15 = r15.getCount();
        if (r15 <= 0) goto L_0x01cc;
    L_0x0170:
        r15 = r14.shownPanelView;
        r15 = r15.getLayoutParams();
        if (r15 != 0) goto L_0x017d;
    L_0x0178:
        r15 = new android.view.ViewGroup$LayoutParams;
        r15.<init>(r4, r4);
    L_0x017d:
        r2 = r14.background;
        r5 = r14.decorView;
        r5.setBackgroundResource(r2);
        r2 = r14.shownPanelView;
        r2 = r2.getParent();
        r5 = r2 instanceof android.view.ViewGroup;
        if (r5 == 0) goto L_0x0195;
    L_0x018e:
        r2 = (android.view.ViewGroup) r2;
        r5 = r14.shownPanelView;
        r2.removeView(r5);
    L_0x0195:
        r2 = r14.decorView;
        r5 = r14.shownPanelView;
        r2.addView(r5, r15);
        r15 = r14.shownPanelView;
        r15 = r15.hasFocus();
        if (r15 != 0) goto L_0x01ab;
    L_0x01a4:
        r15 = r14.shownPanelView;
        r15.requestFocus();
        r6 = -2;
        goto L_0x01ac;
    L_0x01ab:
        r6 = -2;
    L_0x01ac:
        r14.isHandled = r3;
        r15 = new android.view.WindowManager$LayoutParams;
        r7 = -2;
        r8 = 0;
        r9 = 0;
        r10 = 1002; // 0x3ea float:1.404E-42 double:4.95E-321;
        r11 = 8519680; // 0x820000 float:1.1938615E-38 double:4.209281E-317;
        r12 = -3;
        r5 = r15;
        r5.<init>(r6, r7, r8, r9, r10, r11, r12);
        r2 = r14.gravity;
        r15.gravity = r2;
        r2 = r14.windowAnimations;
        r15.windowAnimations = r2;
        r2 = r14.decorView;
        r0.addView(r2, r15);
        r14.isOpen = r1;
        return;
    L_0x01cc:
        r14.refreshDecorView = r1;
        return;
    L_0x01cf:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.openPanel(android.support.v7.app.AppCompatDelegateImpl$PanelFeatureState, android.view.KeyEvent):void");
    }

    private final void throwFeatureRequestIfSubDecorInstalled() {
        if (this.mSubDecorInstalled) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    public final void addContentView(View view, LayoutParams layoutParams) {
        ensureSubDecor();
        ((ViewGroup) this.mSubDecor.findViewById(16908290)).addView(view, layoutParams);
        this.mAppCompatWindowCallback.mWrapped.onContentChanged();
    }

    public final void applyDayNight$ar$ds() {
        applyDayNight$ar$ds$35f8ca22_0(true);
    }

    public final void applyDayNight$ar$ds$35f8ca22_0(boolean z) {
        if (!this.mIsDestroyed) {
            int i;
            int i2;
            Object obj;
            AppCompatActivity appCompatActivity;
            AutoNightModeManager autoNightModeManager;
            int calculateNightMode = calculateNightMode();
            Configuration createOverrideConfigurationForDayNight = createOverrideConfigurationForDayNight(this.mContext, mapNightMode(this.mContext, calculateNightMode), null);
            boolean z2 = false;
            if (!this.mActivityHandlesUiModeChecked && (this.mHost instanceof Activity)) {
                PackageManager packageManager = this.mContext.getPackageManager();
                if (packageManager == null) {
                    i = this.mContext.getResources().getConfiguration().uiMode & 48;
                    i2 = createOverrideConfigurationForDayNight.uiMode & 48;
                    if (i != i2 && z && !z2 && this.mBaseContextAttached && (sCanReturnDifferentContext || this.mCreated)) {
                        obj = this.mHost;
                        if ((obj instanceof Activity) && !((Activity) obj).isChild()) {
                            ((Activity) this.mHost).recreate();
                            obj = this.mHost;
                            if (obj instanceof AppCompatActivity) {
                                appCompatActivity = (AppCompatActivity) obj;
                            }
                            if (calculateNightMode == 0) {
                                getAutoTimeNightModeManager(this.mContext).setup();
                            } else {
                                autoNightModeManager = this.mAutoTimeNightModeManager;
                                if (autoNightModeManager != null) {
                                    autoNightModeManager.cleanup();
                                }
                                if (calculateNightMode == 3) {
                                    getAutoBatteryNightModeManager(this.mContext).setup();
                                    return;
                                }
                            }
                            autoNightModeManager = this.mAutoBatteryNightModeManager;
                            if (autoNightModeManager != null) {
                                autoNightModeManager.cleanup();
                            }
                        }
                    }
                    if (i != i2) {
                        Resources resources = this.mContext.getResources();
                        Configuration configuration = new Configuration(resources.getConfiguration());
                        configuration.uiMode = i2 | (resources.getConfiguration().uiMode & -49);
                        resources.updateConfiguration(configuration, null);
                        int i3 = this.mThemeResId;
                        if (i3 != 0) {
                            this.mContext.setTheme(i3);
                            this.mContext.getTheme().applyStyle(this.mThemeResId, true);
                        }
                        if (z2) {
                            obj = this.mHost;
                            if (obj instanceof Activity) {
                                Activity activity = (Activity) obj;
                                if (activity instanceof LifecycleOwner) {
                                    if (((LifecycleRegistry) ((LifecycleOwner) activity).getLifecycle()).mState.isAtLeast(State.STARTED)) {
                                        activity.onConfigurationChanged(configuration);
                                    }
                                } else if (this.mStarted) {
                                    activity.onConfigurationChanged(configuration);
                                }
                            }
                        }
                        obj = this.mHost;
                        if (obj instanceof AppCompatActivity) {
                            appCompatActivity = (AppCompatActivity) obj;
                        }
                    }
                    if (calculateNightMode == 0) {
                        autoNightModeManager = this.mAutoTimeNightModeManager;
                        if (autoNightModeManager != null) {
                            autoNightModeManager.cleanup();
                        }
                        if (calculateNightMode == 3) {
                            getAutoBatteryNightModeManager(this.mContext).setup();
                            return;
                        }
                    }
                    getAutoTimeNightModeManager(this.mContext).setup();
                    autoNightModeManager = this.mAutoBatteryNightModeManager;
                    if (autoNightModeManager != null) {
                        autoNightModeManager.cleanup();
                    }
                }
                try {
                    ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(this.mContext, this.mHost.getClass()), 269221888);
                    boolean z3 = (activityInfo == null || (activityInfo.configChanges & 512) == 0) ? false : true;
                    this.mActivityHandlesUiMode = z3;
                } catch (Throwable e) {
                    Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e);
                    this.mActivityHandlesUiMode = false;
                }
            }
            this.mActivityHandlesUiModeChecked = true;
            z2 = this.mActivityHandlesUiMode;
            i = this.mContext.getResources().getConfiguration().uiMode & 48;
            i2 = createOverrideConfigurationForDayNight.uiMode & 48;
            obj = this.mHost;
            ((Activity) this.mHost).recreate();
            obj = this.mHost;
            if (obj instanceof AppCompatActivity) {
                appCompatActivity = (AppCompatActivity) obj;
            }
            if (calculateNightMode == 0) {
                getAutoTimeNightModeManager(this.mContext).setup();
            } else {
                autoNightModeManager = this.mAutoTimeNightModeManager;
                if (autoNightModeManager != null) {
                    autoNightModeManager.cleanup();
                }
                if (calculateNightMode == 3) {
                    getAutoBatteryNightModeManager(this.mContext).setup();
                    return;
                }
            }
            autoNightModeManager = this.mAutoBatteryNightModeManager;
            if (autoNightModeManager != null) {
                autoNightModeManager.cleanup();
            }
        }
    }

    public final int calculateNightMode() {
        int i = this.mLocalNightMode;
        return i != -100 ? i : -100;
    }

    final void callOnPanelClosed(int i, PanelFeatureState panelFeatureState, Menu menu) {
        if (menu == null) {
            menu = panelFeatureState.menu;
        }
        if (panelFeatureState.isOpen && !this.mIsDestroyed) {
            this.mAppCompatWindowCallback.mWrapped.onPanelClosed(i, menu);
        }
    }

    final void checkCloseActionMenu(MenuBuilder menuBuilder) {
        if (!this.mClosingActionMenu) {
            this.mClosingActionMenu = true;
            this.mDecorContentParent.dismissPopups();
            Window.Callback windowCallback = getWindowCallback();
            if (!(windowCallback == null || this.mIsDestroyed)) {
                windowCallback.onPanelClosed(108, menuBuilder);
            }
            this.mClosingActionMenu = false;
        }
    }

    final void closePanel(PanelFeatureState panelFeatureState, boolean z) {
        if (z && panelFeatureState.featureId == 0) {
            DecorContentParent decorContentParent = this.mDecorContentParent;
            if (decorContentParent != null) {
                if (decorContentParent.isOverflowMenuShowing()) {
                    checkCloseActionMenu(panelFeatureState.menu);
                    return;
                }
            }
        }
        WindowManager windowManager = (WindowManager) this.mContext.getSystemService("window");
        if (windowManager != null && panelFeatureState.isOpen) {
            View view = panelFeatureState.decorView;
            if (view != null) {
                windowManager.removeView(view);
                if (z) {
                    callOnPanelClosed(panelFeatureState.featureId, panelFeatureState, null);
                }
            }
        }
        panelFeatureState.isPrepared = false;
        panelFeatureState.isHandled = false;
        panelFeatureState.isOpen = false;
        panelFeatureState.shownPanelView = null;
        panelFeatureState.refreshDecorView = true;
        if (this.mPreparedPanel == panelFeatureState) {
            this.mPreparedPanel = null;
        }
    }

    public final Configuration createOverrideConfigurationForDayNight(Context context, int i, Configuration configuration) {
        int i2;
        switch (i) {
            case 1:
                i2 = 16;
                break;
            case 2:
                i2 = 32;
                break;
            default:
                i2 = context.getApplicationContext().getResources().getConfiguration().uiMode & 48;
                break;
        }
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i2 | (configuration2.uiMode & -49);
        return configuration2;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View createView$ar$ds(java.lang.String r10, android.content.Context r11, android.util.AttributeSet r12) {
        /*
        r9 = this;
        r0 = r9.mAppCompatViewInflater;
        r1 = 0;
        if (r0 != 0) goto L_0x0055;
    L_0x0005:
        r0 = r9.mContext;
        r2 = android.support.p002v7.appcompat.R$styleable.AppCompatTheme;
        r0 = r0.obtainStyledAttributes(r2);
        r2 = 116; // 0x74 float:1.63E-43 double:5.73E-322;
        r0 = r0.getString(r2);
        if (r0 != 0) goto L_0x001d;
    L_0x0015:
        r0 = new android.support.v7.app.AppCompatViewInflater;
        r0.<init>();
        r9.mAppCompatViewInflater = r0;
        goto L_0x0055;
    L_0x001d:
        r2 = java.lang.Class.forName(r0);	 Catch:{ all -> 0x0032 }
        r3 = new java.lang.Class[r1];	 Catch:{ all -> 0x0032 }
        r2 = r2.getDeclaredConstructor(r3);	 Catch:{ all -> 0x0032 }
        r3 = new java.lang.Object[r1];	 Catch:{ all -> 0x0032 }
        r2 = r2.newInstance(r3);	 Catch:{ all -> 0x0032 }
        r2 = (android.support.p002v7.app.AppCompatViewInflater) r2;	 Catch:{ all -> 0x0032 }
        r9.mAppCompatViewInflater = r2;	 Catch:{ all -> 0x0032 }
        goto L_0x0055;
    L_0x0032:
        r2 = move-exception;
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r4 = "Failed to instantiate custom view inflater ";
        r3.append(r4);
        r3.append(r0);
        r0 = ". Falling back to default.";
        r3.append(r0);
        r0 = r3.toString();
        r3 = "AppCompatDelegate";
        android.util.Log.i(r3, r0, r2);
        r0 = new android.support.v7.app.AppCompatViewInflater;
        r0.<init>();
        r9.mAppCompatViewInflater = r0;
    L_0x0055:
        r0 = r9.mAppCompatViewInflater;
        r2 = android.support.p002v7.appcompat.R$styleable.View;
        r2 = r11.obtainStyledAttributes(r12, r2, r1, r1);
        r3 = 4;
        r4 = r2.getResourceId(r3, r1);
        if (r4 == 0) goto L_0x006b;
    L_0x0064:
        r5 = "AppCompatViewInflater";
        r6 = "app:theme is now deprecated. Please move to using android:theme instead.";
        android.util.Log.i(r5, r6);
    L_0x006b:
        r2.recycle();
        if (r4 == 0) goto L_0x0081;
    L_0x0070:
        r2 = r11 instanceof androidx.appcompat.view.ContextThemeWrapper;
        if (r2 == 0) goto L_0x007b;
    L_0x0074:
        r2 = r11;
        r2 = (androidx.appcompat.view.ContextThemeWrapper) r2;
        r2 = r2.mThemeResource;
        if (r2 == r4) goto L_0x0081;
    L_0x007b:
        r2 = new androidx.appcompat.view.ContextThemeWrapper;
        r2.<init>(r11, r4);
        goto L_0x0082;
    L_0x0081:
        r2 = r11;
    L_0x0082:
        r4 = r10.hashCode();
        r5 = 3;
        r6 = -1;
        r7 = 1;
        switch(r4) {
            case -1946472170: goto L_0x0119;
            case -1455429095: goto L_0x010e;
            case -1346021293: goto L_0x0103;
            case -938935918: goto L_0x00f9;
            case -937446323: goto L_0x00ef;
            case -658531749: goto L_0x00e4;
            case -339785223: goto L_0x00db;
            case 776382189: goto L_0x00d1;
            case 799298502: goto L_0x00c6;
            case 1125864064: goto L_0x00bc;
            case 1413872058: goto L_0x00b0;
            case 1601505219: goto L_0x00a5;
            case 1666676343: goto L_0x009a;
            case 2001146706: goto L_0x008e;
            default: goto L_0x008c;
        };
    L_0x008c:
        goto L_0x0124;
        r3 = "Button";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x0097:
        r3 = 2;
        goto L_0x0125;
    L_0x009a:
        r3 = "EditText";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x00a2:
        r3 = 3;
        goto L_0x0125;
    L_0x00a5:
        r3 = "CheckBox";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x00ad:
        r3 = 6;
        goto L_0x0125;
    L_0x00b0:
        r3 = "AutoCompleteTextView";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x00b8:
        r3 = 9;
        goto L_0x0125;
    L_0x00bc:
        r3 = "ImageView";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x00c4:
        r3 = 1;
        goto L_0x0125;
    L_0x00c6:
        r3 = "ToggleButton";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x00ce:
        r3 = 13;
        goto L_0x0125;
    L_0x00d1:
        r3 = "RadioButton";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x00d9:
        r3 = 7;
        goto L_0x0125;
    L_0x00db:
        r4 = "Spinner";
        r4 = r10.equals(r4);
        if (r4 == 0) goto L_0x008c;
    L_0x00e3:
        goto L_0x0125;
    L_0x00e4:
        r3 = "SeekBar";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x00ec:
        r3 = 12;
        goto L_0x0125;
    L_0x00ef:
        r3 = "ImageButton";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x00f7:
        r3 = 5;
        goto L_0x0125;
    L_0x00f9:
        r3 = "TextView";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x0101:
        r3 = 0;
        goto L_0x0125;
    L_0x0103:
        r3 = "MultiAutoCompleteTextView";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x010b:
        r3 = 10;
        goto L_0x0125;
    L_0x010e:
        r3 = "CheckedTextView";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x0116:
        r3 = 8;
        goto L_0x0125;
    L_0x0119:
        r3 = "RatingBar";
        r3 = r10.equals(r3);
        if (r3 == 0) goto L_0x008c;
    L_0x0121:
        r3 = 11;
        goto L_0x0125;
    L_0x0124:
        r3 = -1;
    L_0x0125:
        r4 = 0;
        switch(r3) {
            case 0: goto L_0x017c;
            case 1: goto L_0x0176;
            case 2: goto L_0x0170;
            case 3: goto L_0x016a;
            case 4: goto L_0x0164;
            case 5: goto L_0x015b;
            case 6: goto L_0x0155;
            case 7: goto L_0x014f;
            case 8: goto L_0x0149;
            case 9: goto L_0x0143;
            case 10: goto L_0x013d;
            case 11: goto L_0x0137;
            case 12: goto L_0x0131;
            case 13: goto L_0x012b;
            default: goto L_0x0129;
        };
    L_0x0129:
        r3 = r4;
        goto L_0x0181;
    L_0x012b:
        r3 = new android.support.v7.widget.AppCompatToggleButton;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x0131:
        r3 = new android.support.v7.widget.AppCompatSeekBar;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x0137:
        r3 = new android.support.v7.widget.AppCompatRatingBar;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x013d:
        r3 = new android.support.v7.widget.AppCompatMultiAutoCompleteTextView;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x0143:
        r3 = new android.support.v7.widget.AppCompatAutoCompleteTextView;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x0149:
        r3 = new android.support.v7.widget.AppCompatCheckedTextView;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x014f:
        r3 = new android.support.v7.widget.AppCompatRadioButton;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x0155:
        r3 = new android.support.v7.widget.AppCompatCheckBox;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x015b:
        r3 = new android.support.v7.widget.AppCompatImageButton;
        r8 = 2130968991; // 0x7f04019f float:1.7546651E38 double:1.052838571E-314;
        r3.<init>(r2, r12, r8);
        goto L_0x0181;
    L_0x0164:
        r3 = new android.support.v7.widget.AppCompatSpinner;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x016a:
        r3 = new android.support.v7.widget.AppCompatEditText;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x0170:
        r3 = new android.support.v7.widget.AppCompatButton;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x0176:
        r3 = new android.support.v7.widget.AppCompatImageView;
        r3.<init>(r2, r12);
        goto L_0x0181;
    L_0x017c:
        r3 = new android.support.v7.widget.AppCompatTextView;
        r3.<init>(r2, r12);
    L_0x0181:
        if (r3 != 0) goto L_0x01dc;
    L_0x0183:
        if (r11 == r2) goto L_0x01dc;
    L_0x0185:
        r11 = "view";
        r11 = r10.equals(r11);
        if (r11 == 0) goto L_0x0193;
    L_0x018d:
        r10 = "class";
        r10 = r12.getAttributeValue(r4, r10);
    L_0x0193:
        r11 = r0.mConstructorArgs;	 Catch:{ Exception -> 0x01d4, all -> 0x01cc }
        r11[r1] = r2;	 Catch:{ Exception -> 0x01d4, all -> 0x01cc }
        r11[r7] = r12;	 Catch:{ Exception -> 0x01d4, all -> 0x01cc }
        r11 = 46;
        r11 = r10.indexOf(r11);	 Catch:{ Exception -> 0x01d4, all -> 0x01cc }
        if (r11 != r6) goto L_0x01bf;
    L_0x01a1:
        r11 = 0;
    L_0x01a2:
        if (r11 >= r5) goto L_0x01b8;
    L_0x01a4:
        r3 = android.support.p002v7.app.AppCompatViewInflater.sClassPrefixList;	 Catch:{ Exception -> 0x01d4, all -> 0x01cc }
        r3 = r3[r11];	 Catch:{ Exception -> 0x01d4, all -> 0x01cc }
        r3 = r0.createViewByPrefix(r2, r10, r3);	 Catch:{ Exception -> 0x01d4, all -> 0x01cc }
        if (r3 == 0) goto L_0x01b5;
    L_0x01ae:
        r10 = r0.mConstructorArgs;
        r10[r1] = r4;
        r10[r7] = r4;
        goto L_0x01dd;
    L_0x01b5:
        r11 = r11 + 1;
        goto L_0x01a2;
    L_0x01b8:
        r10 = r0.mConstructorArgs;
        r10[r1] = r4;
        r10[r7] = r4;
        goto L_0x01de;
        r10 = r0.createViewByPrefix(r2, r10, r4);	 Catch:{ Exception -> 0x01d4, all -> 0x01cc }
        r11 = r0.mConstructorArgs;
        r11[r1] = r4;
        r11[r7] = r4;
        r4 = r10;
        goto L_0x01de;
    L_0x01cc:
        r10 = move-exception;
        r11 = r0.mConstructorArgs;
        r11[r1] = r4;
        r11[r7] = r4;
        throw r10;
    L_0x01d4:
        r10 = move-exception;
        r10 = r0.mConstructorArgs;
        r10[r1] = r4;
        r10[r7] = r4;
        goto L_0x01de;
    L_0x01dd:
        r4 = r3;
    L_0x01de:
        if (r4 == 0) goto L_0x0206;
    L_0x01e0:
        r10 = r4.getContext();
        r11 = r10 instanceof android.content.ContextWrapper;
        if (r11 == 0) goto L_0x0206;
    L_0x01e8:
        r11 = android.support.p000v4.view.ViewCompat.hasOnClickListeners(r4);
        if (r11 != 0) goto L_0x01ef;
    L_0x01ee:
        goto L_0x0206;
    L_0x01ef:
        r11 = android.support.p002v7.app.AppCompatViewInflater.sOnClickAttrs;
        r10 = r10.obtainStyledAttributes(r12, r11);
        r11 = r10.getString(r1);
        if (r11 == 0) goto L_0x0203;
    L_0x01fb:
        r12 = new android.support.v7.app.AppCompatViewInflater$DeclaredOnClickListener;
        r12.<init>(r4, r11);
        r4.setOnClickListener(r12);
    L_0x0203:
        r10.recycle();
    L_0x0206:
        return r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.createView$ar$ds(java.lang.String, android.content.Context, android.util.AttributeSet):android.view.View");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final boolean dispatchKeyEvent(android.view.KeyEvent r6) {
        /*
        r5 = this;
        r0 = r5.mHost;
        r1 = r0 instanceof android.support.p000v4.view.KeyEventDispatcher.Component;
        if (r1 != 0) goto L_0x000a;
    L_0x0006:
        r0 = r0 instanceof android.support.p002v7.app.AppCompatDialog;
        if (r0 == 0) goto L_0x0014;
    L_0x000a:
        r0 = r5.mWindow;
        r0 = r0.getDecorView();
        if (r0 == 0) goto L_0x0014;
    L_0x0012:
        r0 = android.support.p000v4.view.ViewCompat.ViewCompat$ar$NoOp;
    L_0x0014:
        r0 = r6.getKeyCode();
        r1 = 82;
        r2 = 1;
        if (r0 != r1) goto L_0x0029;
    L_0x001d:
        r0 = r5.mAppCompatWindowCallback;
        r0 = r0.mWrapped;
        r0 = r0.dispatchKeyEvent(r6);
        if (r0 != 0) goto L_0x0028;
    L_0x0027:
        goto L_0x0029;
    L_0x0028:
        return r2;
    L_0x0029:
        r0 = r6.getKeyCode();
        r1 = r6.getAction();
        r3 = 0;
        if (r1 != 0) goto L_0x005e;
    L_0x0034:
        switch(r0) {
            case 4: goto L_0x004f;
            case 82: goto L_0x003a;
            default: goto L_0x0037;
        };
    L_0x0037:
        r2 = 0;
        goto L_0x011a;
    L_0x003a:
        r0 = r6.getRepeatCount();
        if (r0 != 0) goto L_0x004d;
    L_0x0040:
        r0 = r5.getPanelState$ar$ds(r3);
        r1 = r0.isOpen;
        if (r1 != 0) goto L_0x004d;
    L_0x0048:
        r5.preparePanel(r0, r6);
        goto L_0x011a;
    L_0x004d:
        goto L_0x011a;
    L_0x004f:
        r6 = r6.getFlags();
        r6 = r6 & 128;
        if (r6 == 0) goto L_0x0058;
    L_0x0057:
        goto L_0x0059;
    L_0x0058:
        r2 = 0;
    L_0x0059:
        r5.mLongPressBackDown = r2;
        r2 = 0;
        goto L_0x011a;
    L_0x005e:
        switch(r0) {
            case 4: goto L_0x00e6;
            case 82: goto L_0x0064;
            default: goto L_0x0061;
        };
    L_0x0061:
        r2 = 0;
        goto L_0x011a;
    L_0x0064:
        r0 = r5.mActionMode;
        if (r0 == 0) goto L_0x006a;
    L_0x0068:
        goto L_0x011a;
    L_0x006a:
        r0 = r5.getPanelState$ar$ds(r3);
        r1 = r5.mDecorContentParent;
        if (r1 == 0) goto L_0x00a4;
    L_0x0072:
        r1 = r1.canShowOverflowMenu();
        if (r1 == 0) goto L_0x00a4;
    L_0x0078:
        r1 = r5.mContext;
        r1 = android.view.ViewConfiguration.get(r1);
        r1 = r1.hasPermanentMenuKey();
        if (r1 != 0) goto L_0x00a4;
    L_0x0084:
        r1 = r5.mDecorContentParent;
        r1 = r1.isOverflowMenuShowing();
        if (r1 != 0) goto L_0x009d;
    L_0x008c:
        r1 = r5.mIsDestroyed;
        if (r1 != 0) goto L_0x00e5;
    L_0x0090:
        r6 = r5.preparePanel(r0, r6);
        if (r6 == 0) goto L_0x00e5;
    L_0x0096:
        r6 = r5.mDecorContentParent;
        r6 = r6.showOverflowMenu();
        goto L_0x00c6;
    L_0x009d:
        r6 = r5.mDecorContentParent;
        r6 = r6.hideOverflowMenu();
        goto L_0x00c6;
    L_0x00a4:
        r1 = r0.isOpen;
        if (r1 != 0) goto L_0x00c2;
    L_0x00a8:
        r4 = r0.isHandled;
        if (r4 == 0) goto L_0x00ad;
    L_0x00ac:
        goto L_0x00c2;
    L_0x00ad:
        r1 = r0.isPrepared;
        if (r1 == 0) goto L_0x00c1;
    L_0x00b1:
        r1 = r0.refreshMenuContent;
        if (r1 == 0) goto L_0x00bd;
    L_0x00b5:
        r0.isPrepared = r3;
        r1 = r5.preparePanel(r0, r6);
        if (r1 == 0) goto L_0x00c1;
    L_0x00bd:
        r5.openPanel(r0, r6);
        goto L_0x00c8;
    L_0x00c1:
        goto L_0x011a;
    L_0x00c2:
        r5.closePanel(r0, r2);
        r6 = r1;
    L_0x00c6:
        if (r6 == 0) goto L_0x00e5;
    L_0x00c8:
        r6 = r5.mContext;
        r6 = r6.getApplicationContext();
        r0 = "audio";
        r6 = r6.getSystemService(r0);
        r6 = (android.media.AudioManager) r6;
        if (r6 == 0) goto L_0x00dc;
    L_0x00d8:
        r6.playSoundEffect(r3);
        goto L_0x011a;
        r6 = "AppCompatDelegate";
        r0 = "Couldn't get audio manager";
        android.util.Log.w(r6, r0);
        goto L_0x011a;
    L_0x00e5:
        goto L_0x011a;
    L_0x00e6:
        r6 = r5.mLongPressBackDown;
        r5.mLongPressBackDown = r3;
        r0 = r5.getPanelState$ar$ds(r3);
        r1 = r0.isOpen;
        if (r1 == 0) goto L_0x00f9;
    L_0x00f2:
        if (r6 != 0) goto L_0x00f8;
    L_0x00f4:
        r5.closePanel(r0, r2);
        goto L_0x011a;
    L_0x00f8:
        goto L_0x011a;
    L_0x00f9:
        r6 = r5.mActionMode;
        if (r6 == 0) goto L_0x0101;
    L_0x00fd:
        r6.finish();
        goto L_0x011a;
    L_0x0101:
        r6 = r5.getSupportActionBar();
        if (r6 == 0) goto L_0x0119;
    L_0x0107:
        r6 = (android.support.p002v7.app.WindowDecorActionBar) r6;
        r0 = r6.mDecorToolbar;
        if (r0 == 0) goto L_0x0119;
    L_0x010d:
        r0 = r0.hasExpandedActionView();
        if (r0 == 0) goto L_0x0119;
    L_0x0113:
        r6 = r6.mDecorToolbar;
        r6.collapseActionView();
        goto L_0x011a;
    L_0x0119:
        r2 = 0;
    L_0x011a:
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.dispatchKeyEvent(android.view.KeyEvent):boolean");
    }

    final void doInvalidatePanelMenu(int i) {
        PanelFeatureState panelState$ar$ds = getPanelState$ar$ds(i);
        if (panelState$ar$ds.menu != null) {
            Bundle bundle = new Bundle();
            panelState$ar$ds.menu.saveActionViewStates(bundle);
            if (bundle.size() > 0) {
                panelState$ar$ds.frozenActionViewState = bundle;
            }
            panelState$ar$ds.menu.stopDispatchingItemsChanged();
            panelState$ar$ds.menu.clear();
        }
        panelState$ar$ds.refreshMenuContent = true;
        panelState$ar$ds.refreshDecorView = true;
        if ((i == 108 || i == 0) && this.mDecorContentParent != null) {
            panelState$ar$ds = getPanelState$ar$ds(0);
            panelState$ar$ds.isPrepared = false;
            preparePanel(panelState$ar$ds, null);
        }
    }

    public final void endOnGoingFadeAnimation() {
        ViewPropertyAnimatorCompat viewPropertyAnimatorCompat = this.mFadeAnim;
        if (viewPropertyAnimatorCompat != null) {
            viewPropertyAnimatorCompat.cancel();
        }
    }

    final PanelFeatureState findMenuPanel(Menu menu) {
        PanelFeatureState[] panelFeatureStateArr = this.mPanels;
        int i = 0;
        int length = panelFeatureStateArr != null ? panelFeatureStateArr.length : 0;
        while (i < length) {
            PanelFeatureState panelFeatureState = panelFeatureStateArr[i];
            if (panelFeatureState != null) {
                if (panelFeatureState.menu == menu) {
                    return panelFeatureState;
                }
            }
            i++;
        }
        return null;
    }

    public final View findViewById(int i) {
        ensureSubDecor();
        return this.mWindow.findViewById(i);
    }

    final Context getActionBarThemedContext() {
        ActionBar supportActionBar = getSupportActionBar();
        Context themedContext = supportActionBar != null ? supportActionBar.getThemedContext() : null;
        return themedContext == null ? this.mContext : themedContext;
    }

    public final PanelFeatureState getPanelState$ar$ds(int i) {
        PanelFeatureState panelFeatureState;
        Object obj = this.mPanels;
        if (obj != null) {
            if (obj.length > i) {
                panelFeatureState = obj[i];
                if (panelFeatureState == null) {
                    return panelFeatureState;
                }
                panelFeatureState = new PanelFeatureState(i);
                obj[i] = panelFeatureState;
                return panelFeatureState;
            }
        }
        Object obj2 = new PanelFeatureState[(i + 1)];
        if (obj != null) {
            System.arraycopy(obj, 0, obj2, 0, obj.length);
        }
        this.mPanels = obj2;
        obj = obj2;
        panelFeatureState = obj[i];
        if (panelFeatureState == null) {
            return panelFeatureState;
        }
        panelFeatureState = new PanelFeatureState(i);
        obj[i] = panelFeatureState;
        return panelFeatureState;
    }

    public final ActionBar getSupportActionBar() {
        initWindowDecorActionBar();
        return this.mActionBar;
    }

    final Window.Callback getWindowCallback() {
        return this.mWindow.getCallback();
    }

    public final void initWindowDecorActionBar() {
        ensureSubDecor();
        if (this.mHasActionBar) {
            if (this.mActionBar == null) {
                Object obj = this.mHost;
                if (obj instanceof Activity) {
                    this.mActionBar = new WindowDecorActionBar((Activity) obj, this.mOverlayActionBar);
                } else if (obj instanceof Dialog) {
                    this.mActionBar = new WindowDecorActionBar((Dialog) obj);
                }
                ActionBar actionBar = this.mActionBar;
                if (actionBar != null) {
                    actionBar.setDefaultDisplayHomeAsUpEnabled(this.mEnableDefaultActionBarUp);
                }
            }
        }
    }

    public final void invalidateOptionsMenu() {
        getSupportActionBar();
        invalidatePanelMenu(0);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final int mapNightMode(android.content.Context r22, int r23) {
        /*
        r21 = this;
        r0 = -1;
        r1 = 2;
        r2 = 1;
        switch(r23) {
            case -100: goto L_0x0122;
            case -1: goto L_0x0121;
            case 0: goto L_0x001e;
            case 1: goto L_0x0121;
            case 2: goto L_0x0121;
            case 3: goto L_0x000e;
            default: goto L_0x0006;
        };
    L_0x0006:
        r0 = new java.lang.IllegalStateException;
        r1 = "Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.";
        r0.<init>(r1);
        throw r0;
    L_0x000e:
        r0 = r21.getAutoBatteryNightModeManager(r22);
        r0 = (android.support.p002v7.app.AppCompatDelegateImpl.AutoBatteryNightModeManager) r0;
        r0 = r0.mPowerManager;
        r0 = r0.isPowerSaveMode();
        if (r0 == 0) goto L_0x001d;
    L_0x001c:
        return r1;
    L_0x001d:
        return r2;
    L_0x001e:
        r3 = r22.getApplicationContext();
        r4 = "uimode";
        r3 = r3.getSystemService(r4);
        r3 = (android.app.UiModeManager) r3;
        r3 = r3.getNightMode();
        if (r3 == 0) goto L_0x0120;
    L_0x0030:
        r0 = r21.getAutoTimeNightModeManager(r22);
        r0 = (android.support.p002v7.app.AppCompatDelegateImpl.AutoTimeNightModeManager) r0;
        r0 = r0.mTwilightManager;
        r3 = r0.mTwilightState;
        r4 = r3.nextUpdate;
        r6 = java.lang.System.currentTimeMillis();
        r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r8 <= 0) goto L_0x0048;
    L_0x0044:
        r0 = r3.isNight;
        goto L_0x00fc;
    L_0x0048:
        r4 = r0.mContext;
        r5 = "android.permission.ACCESS_COARSE_LOCATION";
        r4 = android.support.p000v4.content.PermissionChecker.checkSelfPermission(r4, r5);
        r5 = 0;
        if (r4 != 0) goto L_0x005a;
    L_0x0053:
        r4 = "network";
        r4 = r0.getLastKnownLocationForProvider(r4);
        goto L_0x005b;
    L_0x005a:
        r4 = r5;
    L_0x005b:
        r6 = r0.mContext;
        r7 = "android.permission.ACCESS_FINE_LOCATION";
        r6 = android.support.p000v4.content.PermissionChecker.checkSelfPermission(r6, r7);
        if (r6 != 0) goto L_0x006c;
    L_0x0065:
        r5 = "gps";
        r5 = r0.getLastKnownLocationForProvider(r5);
        goto L_0x006d;
    L_0x006d:
        if (r5 == 0) goto L_0x007e;
    L_0x006f:
        if (r4 == 0) goto L_0x007e;
    L_0x0071:
        r6 = r5.getTime();
        r8 = r4.getTime();
        r10 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1));
        if (r10 <= 0) goto L_0x0081;
    L_0x007d:
        goto L_0x0080;
    L_0x007e:
        if (r5 == 0) goto L_0x0081;
    L_0x0080:
        r4 = r5;
    L_0x0081:
        if (r4 == 0) goto L_0x0100;
    L_0x0083:
        r0 = r0.mTwilightState;
        r12 = java.lang.System.currentTimeMillis();
        r5 = android.support.p002v7.app.TwilightCalculator.sInstance;
        if (r5 != 0) goto L_0x0094;
    L_0x008d:
        r5 = new android.support.v7.app.TwilightCalculator;
        r5.<init>();
        android.support.p002v7.app.TwilightCalculator.sInstance = r5;
    L_0x0094:
        r10 = android.support.p002v7.app.TwilightCalculator.sInstance;
        r5 = -86400000; // 0xfffffffffad9a400 float:-5.6502737E35 double:NaN;
        r15 = r12 + r5;
        r17 = r4.getLatitude();
        r19 = r4.getLongitude();
        r14 = r10;
        r14.calculateTwilight(r15, r17, r19);
        r5 = r10.sunset;
        r8 = r4.getLatitude();
        r14 = r4.getLongitude();
        r5 = r10;
        r6 = r12;
        r1 = r10;
        r10 = r14;
        r5.calculateTwilight(r6, r8, r10);
        r5 = r1.state;
        r6 = r1.sunrise;
        r8 = r1.sunset;
        r10 = 86400000; // 0x5265c00 float:7.82218E-36 double:4.2687272E-316;
        r15 = r12 + r10;
        r17 = r4.getLatitude();
        r19 = r4.getLongitude();
        r14 = r1;
        r14.calculateTwilight(r15, r17, r19);
        r10 = r1.sunrise;
        r14 = -1;
        r1 = (r6 > r14 ? 1 : (r6 == r14 ? 0 : -1));
        if (r1 == 0) goto L_0x00ec;
    L_0x00d7:
        r1 = (r8 > r14 ? 1 : (r8 == r14 ? 0 : -1));
        if (r1 != 0) goto L_0x00dc;
    L_0x00db:
        goto L_0x00ec;
    L_0x00dc:
        r1 = (r12 > r8 ? 1 : (r12 == r8 ? 0 : -1));
        if (r1 <= 0) goto L_0x00e2;
    L_0x00e0:
        r6 = r10;
        goto L_0x00e7;
    L_0x00e2:
        r1 = (r12 > r6 ? 1 : (r12 == r6 ? 0 : -1));
        if (r1 <= 0) goto L_0x00e7;
    L_0x00e6:
        r6 = r8;
    L_0x00e7:
        r8 = 60000; // 0xea60 float:8.4078E-41 double:2.9644E-319;
        r6 = r6 + r8;
        goto L_0x00f0;
    L_0x00ec:
        r6 = 43200000; // 0x2932e00 float:2.1626111E-37 double:2.1343636E-316;
        r6 = r6 + r12;
        if (r2 == r5) goto L_0x00f5;
    L_0x00f3:
        r1 = 0;
        goto L_0x00f6;
    L_0x00f5:
        r1 = 1;
    L_0x00f6:
        r0.isNight = r1;
        r0.nextUpdate = r6;
        r0 = r3.isNight;
    L_0x00fc:
        if (r0 != 0) goto L_0x011b;
    L_0x00fe:
        r1 = 1;
        goto L_0x011f;
        r0 = "TwilightManager";
        r1 = "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.";
        android.util.Log.i(r0, r1);
        r0 = java.util.Calendar.getInstance();
        r1 = 11;
        r0 = r0.get(r1);
        r1 = 6;
        if (r0 < r1) goto L_0x011d;
    L_0x0115:
        r1 = 22;
        if (r0 >= r1) goto L_0x011b;
    L_0x0119:
        r1 = 1;
        goto L_0x011f;
    L_0x011b:
        r0 = 2;
        return r0;
    L_0x011d:
        r0 = 2;
        r1 = 2;
    L_0x011f:
        return r1;
    L_0x0120:
        return r0;
    L_0x0121:
        return r23;
    L_0x0122:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AppCompatDelegateImpl.mapNightMode(android.content.Context, int):int");
    }

    public final void onCreate$ar$ds() {
        this.mBaseContextAttached = true;
        applyDayNight$ar$ds$35f8ca22_0(false);
        ensureWindow();
        Object obj = this.mHost;
        if (obj instanceof Activity) {
            String parentActivityName;
            try {
                parentActivityName = NavUtils.getParentActivityName((Activity) obj);
            } catch (IllegalArgumentException e) {
                parentActivityName = null;
            }
            if (parentActivityName != null) {
                ActionBar actionBar = this.mActionBar;
                if (actionBar == null) {
                    this.mEnableDefaultActionBarUp = true;
                } else {
                    actionBar.setDefaultDisplayHomeAsUpEnabled(true);
                }
            }
            synchronized (AppCompatDelegate.sActivityDelegatesLock) {
                AppCompatDelegate.removeDelegateFromActives(this);
                AppCompatDelegate.sActivityDelegates.add(new WeakReference(this));
            }
        }
        this.mCreated = true;
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return createView$ar$ds(str, context, attributeSet);
    }

    public final void onDestroy() {
        AutoNightModeManager autoNightModeManager;
        if (this.mHost instanceof Activity) {
            synchronized (AppCompatDelegate.sActivityDelegatesLock) {
                AppCompatDelegate.removeDelegateFromActives(this);
            }
        }
        if (this.mInvalidatePanelMenuPosted) {
            this.mWindow.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable);
        }
        this.mStarted = false;
        this.mIsDestroyed = true;
        if (this.mLocalNightMode != -100) {
            Object obj = this.mHost;
            if ((obj instanceof Activity) && ((Activity) obj).isChangingConfigurations()) {
                sLocalNightModes.put(this.mHost.getClass().getName(), Integer.valueOf(this.mLocalNightMode));
                autoNightModeManager = this.mAutoTimeNightModeManager;
                if (autoNightModeManager != null) {
                    autoNightModeManager.cleanup();
                }
                autoNightModeManager = this.mAutoBatteryNightModeManager;
                if (autoNightModeManager != null) {
                    autoNightModeManager.cleanup();
                }
            }
        }
        sLocalNightModes.remove(this.mHost.getClass().getName());
        autoNightModeManager = this.mAutoTimeNightModeManager;
        if (autoNightModeManager != null) {
            autoNightModeManager.cleanup();
        }
        autoNightModeManager = this.mAutoBatteryNightModeManager;
        if (autoNightModeManager != null) {
            autoNightModeManager.cleanup();
        }
    }

    public final boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
        Window.Callback windowCallback = getWindowCallback();
        if (!(windowCallback == null || this.mIsDestroyed)) {
            PanelFeatureState findMenuPanel = findMenuPanel(menuBuilder.getRootMenu());
            if (findMenuPanel != null) {
                return windowCallback.onMenuItemSelected(findMenuPanel.featureId, menuItem);
            }
        }
        return false;
    }

    public final void onStop() {
        this.mStarted = false;
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.setShowHideAnimationEnabled(false);
        }
    }

    public final boolean performPanelShortcut$ar$ds(PanelFeatureState panelFeatureState, int i, KeyEvent keyEvent) {
        if (keyEvent.isSystem()) {
            return false;
        }
        if (panelFeatureState.isPrepared || preparePanel(panelFeatureState, keyEvent)) {
            MenuBuilder menuBuilder = panelFeatureState.menu;
            if (menuBuilder != null) {
                return menuBuilder.performShortcut(i, keyEvent, 1);
            }
        }
        return false;
    }

    public final boolean preparePanel(PanelFeatureState panelFeatureState, KeyEvent keyEvent) {
        if (this.mIsDestroyed) {
            return false;
        }
        if (panelFeatureState.isPrepared) {
            return true;
        }
        PanelFeatureState panelFeatureState2 = this.mPreparedPanel;
        if (!(panelFeatureState2 == null || panelFeatureState2 == panelFeatureState)) {
            closePanel(panelFeatureState2, false);
        }
        Window.Callback windowCallback = getWindowCallback();
        if (windowCallback != null) {
            panelFeatureState.createdPanelView = windowCallback.onCreatePanelView(panelFeatureState.featureId);
        }
        int i = panelFeatureState.featureId;
        Object obj = i != 0 ? i == 108 ? 1 : null : 1;
        if (obj != null) {
            DecorContentParent decorContentParent = this.mDecorContentParent;
            if (decorContentParent != null) {
                decorContentParent.setMenuPrepared();
            }
        }
        if (panelFeatureState.createdPanelView == null) {
            MenuBuilder menuBuilder = panelFeatureState.menu;
            if (menuBuilder == null || panelFeatureState.refreshMenuContent) {
                if (menuBuilder == null) {
                    Context context = this.mContext;
                    int i2 = panelFeatureState.featureId;
                    if ((i2 == 0 || i2 == 108) && this.mDecorContentParent != null) {
                        Theme newTheme;
                        TypedValue typedValue = new TypedValue();
                        Theme theme = context.getTheme();
                        theme.resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                        if (typedValue.resourceId != 0) {
                            newTheme = context.getResources().newTheme();
                            newTheme.setTo(theme);
                            newTheme.applyStyle(typedValue.resourceId, true);
                            newTheme.resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
                        } else {
                            theme.resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
                            newTheme = null;
                        }
                        if (typedValue.resourceId != 0) {
                            if (newTheme == null) {
                                newTheme = context.getResources().newTheme();
                                newTheme.setTo(theme);
                            }
                            newTheme.applyStyle(typedValue.resourceId, true);
                        }
                        if (newTheme != null) {
                            Context contextThemeWrapper = new ContextThemeWrapper(context, 0);
                            contextThemeWrapper.getTheme().setTo(newTheme);
                            context = contextThemeWrapper;
                        }
                    }
                    MenuBuilder menuBuilder2 = new MenuBuilder(context);
                    menuBuilder2.mCallback = this;
                    panelFeatureState.setMenu(menuBuilder2);
                    if (panelFeatureState.menu == null) {
                        return false;
                    }
                }
                if (!(obj == null || this.mDecorContentParent == null)) {
                    if (this.mActionMenuPresenterCallback == null) {
                        this.mActionMenuPresenterCallback = new ActionMenuPresenterCallback();
                    }
                    this.mDecorContentParent.setMenu(panelFeatureState.menu, this.mActionMenuPresenterCallback);
                }
                panelFeatureState.menu.stopDispatchingItemsChanged();
                if (windowCallback.onCreatePanelMenu(panelFeatureState.featureId, panelFeatureState.menu)) {
                    panelFeatureState.refreshMenuContent = false;
                } else {
                    panelFeatureState.setMenu(null);
                    if (obj != null) {
                        DecorContentParent decorContentParent2 = this.mDecorContentParent;
                        if (decorContentParent2 != null) {
                            decorContentParent2.setMenu(null, this.mActionMenuPresenterCallback);
                        }
                    }
                    return false;
                }
            }
            panelFeatureState.menu.stopDispatchingItemsChanged();
            Bundle bundle = panelFeatureState.frozenActionViewState;
            if (bundle != null) {
                panelFeatureState.menu.restoreActionViewStates(bundle);
                panelFeatureState.frozenActionViewState = null;
            }
            if (windowCallback.onPreparePanel(0, panelFeatureState.createdPanelView, panelFeatureState.menu)) {
                int deviceId;
                if (keyEvent != null) {
                    deviceId = keyEvent.getDeviceId();
                } else {
                    deviceId = -1;
                }
                panelFeatureState.menu.setQwertyMode(KeyCharacterMap.load(deviceId).getKeyboardType() != 1);
                panelFeatureState.menu.startDispatchingItemsChanged();
            } else {
                if (obj != null) {
                    DecorContentParent decorContentParent3 = this.mDecorContentParent;
                    if (decorContentParent3 != null) {
                        decorContentParent3.setMenu(null, this.mActionMenuPresenterCallback);
                    }
                }
                panelFeatureState.menu.startDispatchingItemsChanged();
                return false;
            }
        }
        panelFeatureState.isPrepared = true;
        panelFeatureState.isHandled = false;
        this.mPreparedPanel = panelFeatureState;
        return true;
    }

    public final void setContentView(int i) {
        ensureSubDecor();
        ViewGroup viewGroup = (ViewGroup) this.mSubDecor.findViewById(16908290);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.mContext).inflate(i, viewGroup);
        this.mAppCompatWindowCallback.mWrapped.onContentChanged();
    }

    public final void setTitle(CharSequence charSequence) {
        this.mTitle = charSequence;
        DecorContentParent decorContentParent = this.mDecorContentParent;
        if (decorContentParent == null) {
            ActionBar actionBar = this.mActionBar;
            if (actionBar != null) {
                actionBar.setWindowTitle(charSequence);
                return;
            }
            TextView textView = this.mTitleView;
            if (textView != null) {
                textView.setText(charSequence);
            }
            return;
        }
        decorContentParent.setWindowTitle(charSequence);
    }

    final boolean shouldAnimateActionModeView() {
        if (this.mSubDecorInstalled) {
            View view = this.mSubDecor;
            if (view != null && ViewCompat.isLaidOut(view)) {
                return true;
            }
        }
        return false;
    }

    private final AutoNightModeManager getAutoTimeNightModeManager(Context context) {
        if (this.mAutoTimeNightModeManager == null) {
            if (TwilightManager.sInstance == null) {
                context = context.getApplicationContext();
                TwilightManager.sInstance = new TwilightManager(context, (LocationManager) context.getSystemService("location"));
            }
            this.mAutoTimeNightModeManager = new AutoTimeNightModeManager(TwilightManager.sInstance);
        }
        return this.mAutoTimeNightModeManager;
    }

    public final void ensureSubDecor() {
        if (!this.mSubDecorInstalled) {
            TypedArray obtainStyledAttributes = this.mContext.obtainStyledAttributes(R$styleable.AppCompatTheme);
            if (obtainStyledAttributes.hasValue(117)) {
                View view;
                DecorContentParent decorContentParent;
                if (obtainStyledAttributes.getBoolean(126, false)) {
                    requestWindowFeature$ar$ds(1);
                } else if (obtainStyledAttributes.getBoolean(117, false)) {
                    requestWindowFeature$ar$ds(108);
                }
                if (obtainStyledAttributes.getBoolean(118, false)) {
                    requestWindowFeature$ar$ds(109);
                }
                if (obtainStyledAttributes.getBoolean(119, false)) {
                    requestWindowFeature$ar$ds(10);
                }
                this.mIsFloating = obtainStyledAttributes.getBoolean(0, false);
                obtainStyledAttributes.recycle();
                ensureWindow();
                this.mWindow.getDecorView();
                LayoutInflater from = LayoutInflater.from(this.mContext);
                if (this.mWindowNoTitle) {
                    view = this.mOverlayActionMode ? (ViewGroup) from.inflate(R.layout.abc_screen_simple_overlay_action_mode, null) : (ViewGroup) from.inflate(R.layout.abc_screen_simple, null);
                } else if (this.mIsFloating) {
                    view = (ViewGroup) from.inflate(R.layout.abc_dialog_title_material, null);
                    this.mOverlayActionBar = false;
                    this.mHasActionBar = false;
                } else if (this.mHasActionBar) {
                    Context contextThemeWrapper;
                    TypedValue typedValue = new TypedValue();
                    this.mContext.getTheme().resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                    if (typedValue.resourceId != 0) {
                        contextThemeWrapper = new ContextThemeWrapper(this.mContext, typedValue.resourceId);
                    } else {
                        contextThemeWrapper = this.mContext;
                    }
                    view = (ViewGroup) LayoutInflater.from(contextThemeWrapper).inflate(R.layout.abc_screen_toolbar, null);
                    decorContentParent = (DecorContentParent) view.findViewById(R.id.decor_content_parent);
                    this.mDecorContentParent = decorContentParent;
                    decorContentParent.setWindowCallback(getWindowCallback());
                    if (this.mOverlayActionBar) {
                        this.mDecorContentParent.initFeature(109);
                    }
                    if (this.mFeatureProgress) {
                        this.mDecorContentParent.initFeature(2);
                    }
                    if (this.mFeatureIndeterminateProgress) {
                        this.mDecorContentParent.initFeature(5);
                    }
                } else {
                    view = null;
                }
                if (view != null) {
                    CharSequence title;
                    ViewCompat.setOnApplyWindowInsetsListener(view, new C00803());
                    if (this.mDecorContentParent == null) {
                        this.mTitleView = (TextView) view.findViewById(R.id.title);
                    }
                    ViewUtils.makeOptionalFitsSystemWindows(view);
                    ContentFrameLayout contentFrameLayout = (ContentFrameLayout) view.findViewById(R.id.action_bar_activity_content);
                    ViewGroup viewGroup = (ViewGroup) this.mWindow.findViewById(16908290);
                    if (viewGroup != null) {
                        while (viewGroup.getChildCount() > 0) {
                            View childAt = viewGroup.getChildAt(0);
                            viewGroup.removeViewAt(0);
                            contentFrameLayout.addView(childAt);
                        }
                        viewGroup.setId(-1);
                        contentFrameLayout.setId(16908290);
                        if (viewGroup instanceof FrameLayout) {
                            ((FrameLayout) viewGroup).setForeground(null);
                        }
                    }
                    this.mWindow.setContentView(view);
                    contentFrameLayout.mAttachListener$ar$class_merging = new C00815();
                    this.mSubDecor = view;
                    Object obj = this.mHost;
                    if (obj instanceof Activity) {
                        title = ((Activity) obj).getTitle();
                    } else {
                        title = this.mTitle;
                    }
                    if (!TextUtils.isEmpty(title)) {
                        decorContentParent = this.mDecorContentParent;
                        if (decorContentParent != null) {
                            decorContentParent.setWindowTitle(title);
                        } else {
                            ActionBar actionBar = this.mActionBar;
                            if (actionBar != null) {
                                actionBar.setWindowTitle(title);
                            } else {
                                TextView textView = this.mTitleView;
                                if (textView != null) {
                                    textView.setText(title);
                                }
                            }
                        }
                    }
                    ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.mSubDecor.findViewById(16908290);
                    View decorView = this.mWindow.getDecorView();
                    contentFrameLayout2.mDecorPadding.set(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
                    if (ViewCompat.isLaidOut(contentFrameLayout2)) {
                        contentFrameLayout2.requestLayout();
                    }
                    TypedArray obtainStyledAttributes2 = this.mContext.obtainStyledAttributes(R$styleable.AppCompatTheme);
                    if (contentFrameLayout2.mMinWidthMajor == null) {
                        contentFrameLayout2.mMinWidthMajor = new TypedValue();
                    }
                    obtainStyledAttributes2.getValue(124, contentFrameLayout2.mMinWidthMajor);
                    if (contentFrameLayout2.mMinWidthMinor == null) {
                        contentFrameLayout2.mMinWidthMinor = new TypedValue();
                    }
                    obtainStyledAttributes2.getValue(125, contentFrameLayout2.mMinWidthMinor);
                    if (obtainStyledAttributes2.hasValue(122)) {
                        if (contentFrameLayout2.mFixedWidthMajor == null) {
                            contentFrameLayout2.mFixedWidthMajor = new TypedValue();
                        }
                        obtainStyledAttributes2.getValue(122, contentFrameLayout2.mFixedWidthMajor);
                    }
                    if (obtainStyledAttributes2.hasValue(123)) {
                        if (contentFrameLayout2.mFixedWidthMinor == null) {
                            contentFrameLayout2.mFixedWidthMinor = new TypedValue();
                        }
                        obtainStyledAttributes2.getValue(123, contentFrameLayout2.mFixedWidthMinor);
                    }
                    if (obtainStyledAttributes2.hasValue(120)) {
                        if (contentFrameLayout2.mFixedHeightMajor == null) {
                            contentFrameLayout2.mFixedHeightMajor = new TypedValue();
                        }
                        obtainStyledAttributes2.getValue(120, contentFrameLayout2.mFixedHeightMajor);
                    }
                    if (obtainStyledAttributes2.hasValue(121)) {
                        if (contentFrameLayout2.mFixedHeightMinor == null) {
                            contentFrameLayout2.mFixedHeightMinor = new TypedValue();
                        }
                        obtainStyledAttributes2.getValue(121, contentFrameLayout2.mFixedHeightMinor);
                    }
                    obtainStyledAttributes2.recycle();
                    contentFrameLayout2.requestLayout();
                    this.mSubDecorInstalled = true;
                    PanelFeatureState panelState$ar$ds = getPanelState$ar$ds(0);
                    if (!this.mIsDestroyed && panelState$ar$ds.menu == null) {
                        invalidatePanelMenu(108);
                        return;
                    }
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
                stringBuilder.append(this.mHasActionBar);
                stringBuilder.append(", windowActionBarOverlay: ");
                stringBuilder.append(this.mOverlayActionBar);
                stringBuilder.append(", android:windowIsFloating: ");
                stringBuilder.append(this.mIsFloating);
                stringBuilder.append(", windowActionModeOverlay: ");
                stringBuilder.append(this.mOverlayActionMode);
                stringBuilder.append(", windowNoTitle: ");
                stringBuilder.append(this.mWindowNoTitle);
                stringBuilder.append(" }");
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            obtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
    }

    public final void onMenuModeChange$ar$ds() {
        DecorContentParent decorContentParent = this.mDecorContentParent;
        if (decorContentParent == null || !decorContentParent.canShowOverflowMenu() || (ViewConfiguration.get(this.mContext).hasPermanentMenuKey() && !this.mDecorContentParent.isOverflowMenuShowPending())) {
            PanelFeatureState panelState$ar$ds = getPanelState$ar$ds(0);
            panelState$ar$ds.refreshDecorView = true;
            closePanel(panelState$ar$ds, false);
            openPanel(panelState$ar$ds, null);
            return;
        }
        Window.Callback windowCallback = getWindowCallback();
        if (this.mDecorContentParent.isOverflowMenuShowing()) {
            this.mDecorContentParent.hideOverflowMenu();
            if (!this.mIsDestroyed) {
                windowCallback.onPanelClosed(108, getPanelState$ar$ds(0).menu);
            }
        } else if (!(windowCallback == null || this.mIsDestroyed)) {
            if (this.mInvalidatePanelMenuPosted && (1 & this.mInvalidatePanelMenuFeatures) != 0) {
                this.mWindow.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable);
                this.mInvalidatePanelMenuRunnable.run();
            }
            PanelFeatureState panelState$ar$ds2 = getPanelState$ar$ds(0);
            Menu menu = panelState$ar$ds2.menu;
            if (!(menu == null || panelState$ar$ds2.refreshMenuContent || !windowCallback.onPreparePanel(0, panelState$ar$ds2.createdPanelView, menu))) {
                windowCallback.onMenuOpened(108, panelState$ar$ds2.menu);
                this.mDecorContentParent.showOverflowMenu();
            }
        }
    }

    public final void requestWindowFeature$ar$ds(int i) {
        String str = "AppCompatDelegate";
        if (i == 8) {
            Log.i(str, "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            i = 108;
        } else if (i == 9) {
            Log.i(str, "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i = 109;
        }
        if (this.mWindowNoTitle) {
            if (i == 108) {
                return;
            }
        }
        if (this.mHasActionBar && i == 1) {
            this.mHasActionBar = false;
        }
        switch (i) {
            case 1:
                throwFeatureRequestIfSubDecorInstalled();
                this.mWindowNoTitle = true;
                return;
            case 2:
                throwFeatureRequestIfSubDecorInstalled();
                this.mFeatureProgress = true;
                return;
            case 5:
                throwFeatureRequestIfSubDecorInstalled();
                this.mFeatureIndeterminateProgress = true;
                return;
            case 10:
                throwFeatureRequestIfSubDecorInstalled();
                this.mOverlayActionMode = true;
                return;
            case 108:
                throwFeatureRequestIfSubDecorInstalled();
                this.mHasActionBar = true;
                return;
            case 109:
                throwFeatureRequestIfSubDecorInstalled();
                this.mOverlayActionBar = true;
                return;
            default:
                this.mWindow.requestFeature(i);
                return;
        }
    }

    public final void setContentView(View view) {
        ensureSubDecor();
        ViewGroup viewGroup = (ViewGroup) this.mSubDecor.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.mAppCompatWindowCallback.mWrapped.onContentChanged();
    }

    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return createView$ar$ds(str, context, attributeSet);
    }

    public final void setContentView(View view, LayoutParams layoutParams) {
        ensureSubDecor();
        ViewGroup viewGroup = (ViewGroup) this.mSubDecor.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.mAppCompatWindowCallback.mWrapped.onContentChanged();
    }
}
