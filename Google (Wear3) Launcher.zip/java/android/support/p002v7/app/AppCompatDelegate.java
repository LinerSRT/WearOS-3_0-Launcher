package android.support.p002v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import androidx.collection.ArraySet;
import java.lang.ref.WeakReference;
import java.util.Iterator;

/* compiled from: PG */
/* renamed from: android.support.v7.app.AppCompatDelegate */
public abstract class AppCompatDelegate {
    public static final ArraySet sActivityDelegates = new ArraySet();
    public static final Object sActivityDelegatesLock = new Object();

    public static AppCompatDelegate create$ar$ds$38628b0_0(Dialog dialog) {
        return new AppCompatDelegateImpl(dialog.getContext(), dialog.getWindow(), dialog);
    }

    public static AppCompatDelegate create$ar$ds$5f96c4e8_0(Activity activity) {
        return new AppCompatDelegateImpl(activity, null, activity);
    }

    public static void removeDelegateFromActives(AppCompatDelegate appCompatDelegate) {
        synchronized (sActivityDelegatesLock) {
            Iterator it = sActivityDelegates.iterator();
            while (it.hasNext()) {
                AppCompatDelegate appCompatDelegate2 = (AppCompatDelegate) ((WeakReference) it.next()).get();
                if (appCompatDelegate2 == appCompatDelegate || appCompatDelegate2 == null) {
                    it.remove();
                }
            }
        }
    }

    public abstract void addContentView(View view, LayoutParams layoutParams);

    public abstract View findViewById(int i);

    public abstract ActionBar getSupportActionBar();

    public abstract void invalidateOptionsMenu();

    public abstract void onCreate$ar$ds();

    public abstract void onDestroy();

    public abstract void onStop();

    public abstract void requestWindowFeature$ar$ds(int i);

    public abstract void setContentView(int i);

    public abstract void setContentView(View view);

    public abstract void setContentView(View view, LayoutParams layoutParams);

    public abstract void setTitle(CharSequence charSequence);
}
