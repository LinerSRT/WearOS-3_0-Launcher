package android.support.p002v7.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.p002v7.appcompat.R$styleable;
import android.util.AttributeSet;
import android.view.ViewGroup.MarginLayoutParams;

/* compiled from: PG */
/* renamed from: android.support.v7.app.ActionBar */
public class ActionBar {

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.ActionBar$LayoutParams */
    public class LayoutParams extends MarginLayoutParams {
        public int gravity = 8388627;

        public LayoutParams() {
            super(-2, -2);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ActionBarLayout);
            this.gravity = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.gravity = layoutParams.gravity;
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.ActionBar$OnMenuVisibilityListener */
    public interface OnMenuVisibilityListener {
        void onMenuVisibilityChanged$ar$ds();
    }

    public void dispatchMenuVisibilityChanged(boolean z) {
        throw null;
    }

    public Context getThemedContext() {
        throw null;
    }

    public void setDefaultDisplayHomeAsUpEnabled(boolean z) {
        throw null;
    }

    public void setShowHideAnimationEnabled(boolean z) {
        throw null;
    }

    public void setWindowTitle(CharSequence charSequence) {
        throw null;
    }
}
