package android.support.p002v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.widget.NestedScrollView;
import android.support.p002v7.app.AlertController.AlertParams;
import android.support.p002v7.app.AlertController.RecycleListView;
import android.support.p002v7.widget.LinearLayoutCompat;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.app.AlertDialog */
public final class AlertDialog extends AppCompatDialog implements DialogInterface {
    public final AlertController mAlert = new AlertController(getContext(), this, getWindow());

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AlertDialog$Builder */
    public final class Builder {
        /* renamed from: P */
        public final AlertParams f4P;
        private final int mTheme;

        public Builder(Context context) {
            int resolveDialogTheme = AlertDialog.resolveDialogTheme(context, 0);
            this.f4P = new AlertParams(new ContextThemeWrapper(context, AlertDialog.resolveDialogTheme(context, resolveDialogTheme)));
            this.mTheme = resolveDialogTheme;
        }

        public final android.support.p002v7.app.AlertDialog create() {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Unknown predecessor block by arg (r13_0 android.widget.ListAdapter) in PHI: PHI: (r13_3 android.widget.ListAdapter) = (r13_0 android.widget.ListAdapter), (r13_1 android.widget.ListAdapter), (r13_2 android.widget.ListAdapter) binds: {(r13_0 android.widget.ListAdapter)=B:28:0x006c, (r13_1 android.widget.ListAdapter)=B:35:0x0088, (r13_2 android.widget.ListAdapter)=B:36:0x0089}
	at jadx.core.dex.instructions.PhiInsn.replaceArg(PhiInsn.java:79)
	at jadx.core.dex.visitors.ModVisitor.processInvoke(ModVisitor.java:222)
	at jadx.core.dex.visitors.ModVisitor.replaceStep(ModVisitor.java:83)
	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:68)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
*/
            /*
            r14 = this;
            r0 = new android.support.v7.app.AlertDialog;
            r1 = r14.f4P;
            r1 = r1.mContext;
            r2 = r14.mTheme;
            r0.<init>(r1, r2);
            r1 = r14.f4P;
            r2 = r0.mAlert;
            r3 = r1.mCustomTitleView;
            r9 = 0;
            if (r3 == 0) goto L_0x0017;
        L_0x0014:
            r2.mCustomTitleView = r3;
            goto L_0x0032;
        L_0x0017:
            r3 = r1.mTitle;
            if (r3 == 0) goto L_0x001e;
        L_0x001b:
            r2.setTitle(r3);
        L_0x001e:
            r3 = r1.mIcon;
            if (r3 == 0) goto L_0x0032;
        L_0x0022:
            r2.mIcon = r3;
            r2.mIconId = r9;
            r4 = r2.mIconView;
            if (r4 == 0) goto L_0x0032;
        L_0x002a:
            r4.setVisibility(r9);
            r4 = r2.mIconView;
            r4.setImageDrawable(r3);
        L_0x0032:
            r3 = r1.mMessage;
            if (r3 == 0) goto L_0x003f;
        L_0x0036:
            r2.mMessage = r3;
            r4 = r2.mMessageView;
            if (r4 == 0) goto L_0x003f;
        L_0x003c:
            r4.setText(r3);
        L_0x003f:
            r3 = r1.mPositiveButtonText;
            if (r3 == 0) goto L_0x0049;
        L_0x0043:
            r4 = -1;
            r5 = r1.mPositiveButtonListener;
            r2.setButton$ar$ds(r4, r3, r5);
        L_0x0049:
            r3 = r1.mNegativeButtonText;
            if (r3 == 0) goto L_0x0053;
        L_0x004d:
            r4 = -2;
            r5 = r1.mNegativeButtonListener;
            r2.setButton$ar$ds(r4, r3, r5);
        L_0x0053:
            r3 = r1.mItems;
            r10 = 1;
            r11 = 0;
            if (r3 != 0) goto L_0x005d;
        L_0x0059:
            r3 = r1.mAdapter;
            if (r3 == 0) goto L_0x00c3;
        L_0x005d:
            r3 = r1.mInflater;
            r4 = r2.mListLayout;
            r3 = r3.inflate(r4, r11);
            r12 = r3;
            r12 = (android.support.p002v7.app.AlertController.RecycleListView) r12;
            r3 = r1.mIsMultiChoice;
            if (r3 == 0) goto L_0x007b;
        L_0x006c:
            r13 = new android.support.v7.app.AlertController$AlertParams$1;
            r5 = r1.mContext;
            r6 = r2.mMultiChoiceItemLayout;
            r7 = r1.mItems;
            r3 = r13;
            r4 = r1;
            r8 = r12;
            r3.<init>(r5, r6, r7, r8);
            goto L_0x0092;
        L_0x007b:
            r3 = r1.mIsSingleChoice;
            if (r3 == 0) goto L_0x0082;
        L_0x007f:
            r3 = r2.mSingleChoiceItemLayout;
            goto L_0x0084;
        L_0x0082:
            r3 = r2.mListItemLayout;
        L_0x0084:
            r13 = r1.mAdapter;
            if (r13 == 0) goto L_0x0089;
        L_0x0088:
            goto L_0x0092;
        L_0x0089:
            r13 = new android.support.v7.app.AlertController$CheckedItemAdapter;
            r4 = r1.mContext;
            r5 = r1.mItems;
            r13.<init>(r4, r3, r5);
        L_0x0092:
            r2.mAdapter = r13;
            r3 = r1.mCheckedItem;
            r2.mCheckedItem = r3;
            r3 = r1.mOnClickListener;
            if (r3 == 0) goto L_0x00a5;
        L_0x009c:
            r3 = new android.support.v7.app.AlertController$AlertParams$3;
            r3.<init>(r2);
            r12.setOnItemClickListener(r3);
            goto L_0x00b1;
        L_0x00a5:
            r3 = r1.mOnCheckboxClickListener;
            if (r3 == 0) goto L_0x00b1;
        L_0x00a9:
            r3 = new android.support.v7.app.AlertController$AlertParams$4;
            r3.<init>(r12, r2);
            r12.setOnItemClickListener(r3);
        L_0x00b1:
            r3 = r1.mIsSingleChoice;
            if (r3 == 0) goto L_0x00b9;
        L_0x00b5:
            r12.setChoiceMode(r10);
            goto L_0x00c1;
        L_0x00b9:
            r3 = r1.mIsMultiChoice;
            if (r3 == 0) goto L_0x00c1;
        L_0x00bd:
            r3 = 2;
            r12.setChoiceMode(r3);
        L_0x00c1:
            r2.mListView = r12;
        L_0x00c3:
            r1 = r1.mView;
            if (r1 == 0) goto L_0x00cb;
        L_0x00c7:
            r2.mView = r1;
            r2.mViewSpacingSpecified = r9;
        L_0x00cb:
            r0.setCancelable(r10);
            r0.setCanceledOnTouchOutside(r10);
            r0.setOnCancelListener(r11);
            r0.setOnDismissListener(r11);
            r1 = r14.f4P;
            r1 = r1.mOnKeyListener;
            if (r1 == 0) goto L_0x00e0;
        L_0x00dd:
            r0.setOnKeyListener(r1);
        L_0x00e0:
            return r0;
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.v7.app.AlertDialog.Builder.create():android.support.v7.app.AlertDialog");
        }

        public final void setIcon$ar$ds(Drawable drawable) {
            this.f4P.mIcon = drawable;
        }

        public final void setPositiveButton$ar$ds(CharSequence charSequence, OnClickListener onClickListener) {
            AlertParams alertParams = this.f4P;
            alertParams.mPositiveButtonText = charSequence;
            alertParams.mPositiveButtonListener = onClickListener;
        }

        public final void setTitle$ar$ds(CharSequence charSequence) {
            this.f4P.mTitle = charSequence;
        }
    }

    protected AlertDialog(Context context, int i) {
        super(context, AlertDialog.resolveDialogTheme(context, i));
    }

    static int resolveDialogTheme(Context context, int i) {
        if ((i >>> 24) > 0) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    protected final void onCreate(Bundle bundle) {
        int i;
        View findViewById;
        View findViewById2;
        View findViewById3;
        ViewGroup resolvePanel$ar$ds;
        ViewGroup resolvePanel$ar$ds2;
        ViewGroup resolvePanel$ar$ds3;
        int i2;
        TextView textView;
        CharSequence charSequence;
        int i3;
        CharSequence charSequence2;
        Context context;
        TypedValue typedValue;
        Button button;
        Object obj;
        Object obj2;
        NestedScrollView nestedScrollView;
        ListView listView;
        int i4;
        RecycleListView recycleListView;
        int paddingLeft;
        int paddingRight;
        int paddingBottom;
        ListView listView2;
        ListAdapter listAdapter;
        int i5;
        super.onCreate(bundle);
        AlertController alertController = this.mAlert;
        if (alertController.mButtonPanelSideLayout == 0) {
            i = alertController.mAlertDialogLayout;
        } else {
            i = alertController.mAlertDialogLayout;
        }
        alertController.mDialog.setContentView(i);
        View findViewById4 = alertController.mWindow.findViewById(R.id.parentPanel);
        View findViewById5 = findViewById4.findViewById(R.id.topPanel);
        View findViewById6 = findViewById4.findViewById(R.id.contentPanel);
        View findViewById7 = findViewById4.findViewById(R.id.buttonPanel);
        ViewGroup viewGroup = (ViewGroup) findViewById4.findViewById(R.id.customPanel);
        View view = alertController.mView;
        View view2 = null;
        if (view == null) {
            view = null;
        }
        if (view == null || !AlertController.canTextInput(view)) {
            alertController.mWindow.setFlags(131072, 131072);
            if (view == null) {
                viewGroup.setVisibility(8);
                findViewById = viewGroup.findViewById(R.id.topPanel);
                findViewById2 = viewGroup.findViewById(R.id.contentPanel);
                findViewById3 = viewGroup.findViewById(R.id.buttonPanel);
                resolvePanel$ar$ds = AlertController.resolvePanel$ar$ds(findViewById, findViewById5);
                resolvePanel$ar$ds2 = AlertController.resolvePanel$ar$ds(findViewById2, findViewById6);
                resolvePanel$ar$ds3 = AlertController.resolvePanel$ar$ds(findViewById3, findViewById7);
                alertController.mScrollView = (NestedScrollView) alertController.mWindow.findViewById(R.id.scrollView);
                i2 = 0;
                alertController.mScrollView.setFocusable(false);
                alertController.mScrollView.setNestedScrollingEnabled(false);
                alertController.mMessageView = (TextView) resolvePanel$ar$ds2.findViewById(16908299);
                textView = alertController.mMessageView;
                if (textView == null) {
                    charSequence = alertController.mMessage;
                    if (charSequence == null) {
                        textView.setText(charSequence);
                    } else {
                        textView.setVisibility(8);
                        alertController.mScrollView.removeView(alertController.mMessageView);
                        if (alertController.mListView == null) {
                            ViewGroup viewGroup2 = (ViewGroup) alertController.mScrollView.getParent();
                            int indexOfChild = viewGroup2.indexOfChild(alertController.mScrollView);
                            viewGroup2.removeViewAt(indexOfChild);
                            viewGroup2.addView(alertController.mListView, indexOfChild, new LayoutParams(-1, -1));
                        } else {
                            resolvePanel$ar$ds2.setVisibility(8);
                        }
                    }
                }
                alertController.mButtonPositive = (Button) resolvePanel$ar$ds3.findViewById(16908313);
                alertController.mButtonPositive.setOnClickListener(alertController.mButtonHandler);
                if (TextUtils.isEmpty(alertController.mButtonPositiveText)) {
                    alertController.mButtonPositive.setText(alertController.mButtonPositiveText);
                    alertController.mButtonPositive.setVisibility(0);
                    i3 = 1;
                } else {
                    alertController.mButtonPositive.setVisibility(8);
                    i3 = 0;
                }
                alertController.mButtonNegative = (Button) resolvePanel$ar$ds3.findViewById(16908314);
                alertController.mButtonNegative.setOnClickListener(alertController.mButtonHandler);
                if (TextUtils.isEmpty(alertController.mButtonNegativeText)) {
                    alertController.mButtonNegative.setText(alertController.mButtonNegativeText);
                    alertController.mButtonNegative.setVisibility(0);
                    i3 |= 2;
                } else {
                    alertController.mButtonNegative.setVisibility(8);
                }
                alertController.mButtonNeutral = (Button) resolvePanel$ar$ds3.findViewById(16908315);
                alertController.mButtonNeutral.setOnClickListener(alertController.mButtonHandler);
                charSequence2 = alertController.mButtonNeutralText;
                if (TextUtils.isEmpty(null)) {
                    Button button2 = alertController.mButtonNeutral;
                    CharSequence charSequence3 = alertController.mButtonNeutralText;
                    button2.setText(null);
                    alertController.mButtonNeutral.setVisibility(0);
                    i3 |= 4;
                } else {
                    alertController.mButtonNeutral.setVisibility(8);
                }
                context = alertController.mContext;
                typedValue = new TypedValue();
                context.getTheme().resolveAttribute(R.attr.alertDialogCenterButtons, typedValue, true);
                if (typedValue.data != 0) {
                    if (i3 == 1) {
                        button = alertController.mButtonPositive;
                    } else if (i3 == 2) {
                        button = alertController.mButtonNegative;
                    } else if (i3 == 4) {
                        button = alertController.mButtonNeutral;
                        AlertController.centerButton$ar$ds(button);
                        if (alertController.mCustomTitleView == null) {
                            resolvePanel$ar$ds.addView(alertController.mCustomTitleView, 0, new LayoutParams(-1, -2));
                            alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                        } else {
                            alertController.mIconView = (ImageView) alertController.mWindow.findViewById(16908294);
                            if (TextUtils.isEmpty(alertController.mTitle) && alertController.mShowTitle) {
                                alertController.mTitleView = (TextView) alertController.mWindow.findViewById(R.id.alertTitle);
                                alertController.mTitleView.setText(alertController.mTitle);
                                i3 = alertController.mIconId;
                                Drawable drawable = alertController.mIcon;
                                if (drawable != null) {
                                    alertController.mIconView.setImageDrawable(drawable);
                                } else {
                                    alertController.mTitleView.setPadding(alertController.mIconView.getPaddingLeft(), alertController.mIconView.getPaddingTop(), alertController.mIconView.getPaddingRight(), alertController.mIconView.getPaddingBottom());
                                    alertController.mIconView.setVisibility(8);
                                }
                            } else {
                                alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                                alertController.mIconView.setVisibility(8);
                                resolvePanel$ar$ds.setVisibility(8);
                            }
                        }
                        if (viewGroup != null || viewGroup.getVisibility() == 8) {
                            obj = null;
                        } else {
                            obj = 1;
                        }
                        if (resolvePanel$ar$ds != null || resolvePanel$ar$ds.getVisibility() == 8) {
                            i3 = 0;
                        } else {
                            i3 = 1;
                        }
                        if (resolvePanel$ar$ds3 != null || resolvePanel$ar$ds3.getVisibility() == 8) {
                            obj2 = null;
                        } else {
                            obj2 = 1;
                        }
                        if (obj2 == null && resolvePanel$ar$ds2 != null) {
                            view = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoButtons);
                            if (view != null) {
                                view.setVisibility(0);
                            }
                        }
                        if (i3 != 0) {
                            nestedScrollView = alertController.mScrollView;
                            if (nestedScrollView != null) {
                                nestedScrollView.setClipToPadding(true);
                            }
                            if (alertController.mMessage == null) {
                                if (alertController.mListView != null) {
                                    if (view2 != null) {
                                        view2.setVisibility(0);
                                    }
                                }
                            }
                            view2 = resolvePanel$ar$ds.findViewById(R.id.titleDividerNoCustom);
                            if (view2 != null) {
                                view2.setVisibility(0);
                            }
                        } else if (resolvePanel$ar$ds2 != null) {
                            findViewById = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoTitle);
                            if (findViewById != null) {
                                findViewById.setVisibility(0);
                            }
                        }
                        listView = alertController.mListView;
                        if (listView instanceof RecycleListView) {
                            if (obj2 != null) {
                                i4 = i3;
                            } else if (i3 == 0) {
                                i4 = 0;
                            }
                            recycleListView = (RecycleListView) listView;
                            paddingLeft = recycleListView.getPaddingLeft();
                            if (i4 == 0) {
                                i4 = recycleListView.getPaddingTop();
                            } else {
                                i4 = recycleListView.mPaddingTopNoTitle;
                            }
                            paddingRight = recycleListView.getPaddingRight();
                            if (obj2 == null) {
                                paddingBottom = recycleListView.getPaddingBottom();
                            } else {
                                paddingBottom = recycleListView.mPaddingBottomNoButtons;
                            }
                            recycleListView.setPadding(paddingLeft, i4, paddingRight, paddingBottom);
                        }
                        if (obj == null) {
                            findViewById4 = alertController.mListView;
                            if (findViewById4 == null) {
                                findViewById4 = alertController.mScrollView;
                            }
                            if (findViewById4 != null) {
                                if (1 != obj2) {
                                    i2 = 2;
                                }
                                findViewById = alertController.mWindow.findViewById(R.id.scrollIndicatorUp);
                                findViewById2 = alertController.mWindow.findViewById(R.id.scrollIndicatorDown);
                                ViewCompat.setScrollIndicators$ar$ds(findViewById4, i3 | i2);
                                if (findViewById != null) {
                                    resolvePanel$ar$ds2.removeView(findViewById);
                                }
                                if (findViewById2 != null) {
                                    resolvePanel$ar$ds2.removeView(findViewById2);
                                }
                            }
                        }
                        listView2 = alertController.mListView;
                        if (listView2 != null) {
                            listAdapter = alertController.mAdapter;
                            if (listAdapter != null) {
                                listView2.setAdapter(listAdapter);
                                i5 = alertController.mCheckedItem;
                                if (i5 >= 0) {
                                    listView2.setItemChecked(i5, true);
                                    listView2.setSelection(i5);
                                }
                            }
                        }
                    }
                    AlertController.centerButton$ar$ds(button);
                    if (alertController.mCustomTitleView == null) {
                        alertController.mIconView = (ImageView) alertController.mWindow.findViewById(16908294);
                        if (TextUtils.isEmpty(alertController.mTitle)) {
                        }
                        alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                        alertController.mIconView.setVisibility(8);
                        resolvePanel$ar$ds.setVisibility(8);
                    } else {
                        resolvePanel$ar$ds.addView(alertController.mCustomTitleView, 0, new LayoutParams(-1, -2));
                        alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                    }
                    if (viewGroup != null) {
                    }
                    obj = null;
                    if (resolvePanel$ar$ds != null) {
                    }
                    i3 = 0;
                    if (resolvePanel$ar$ds3 != null) {
                    }
                    obj2 = null;
                    view = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoButtons);
                    if (view != null) {
                        view.setVisibility(0);
                    }
                    if (i3 != 0) {
                        nestedScrollView = alertController.mScrollView;
                        if (nestedScrollView != null) {
                            nestedScrollView.setClipToPadding(true);
                        }
                        if (alertController.mMessage == null) {
                            if (alertController.mListView != null) {
                                if (view2 != null) {
                                    view2.setVisibility(0);
                                }
                            }
                        }
                        view2 = resolvePanel$ar$ds.findViewById(R.id.titleDividerNoCustom);
                        if (view2 != null) {
                            view2.setVisibility(0);
                        }
                    } else if (resolvePanel$ar$ds2 != null) {
                        findViewById = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoTitle);
                        if (findViewById != null) {
                            findViewById.setVisibility(0);
                        }
                    }
                    listView = alertController.mListView;
                    if (listView instanceof RecycleListView) {
                        if (obj2 != null) {
                            i4 = i3;
                        } else if (i3 == 0) {
                            i4 = 0;
                        }
                        recycleListView = (RecycleListView) listView;
                        paddingLeft = recycleListView.getPaddingLeft();
                        if (i4 == 0) {
                            i4 = recycleListView.mPaddingTopNoTitle;
                        } else {
                            i4 = recycleListView.getPaddingTop();
                        }
                        paddingRight = recycleListView.getPaddingRight();
                        if (obj2 == null) {
                            paddingBottom = recycleListView.mPaddingBottomNoButtons;
                        } else {
                            paddingBottom = recycleListView.getPaddingBottom();
                        }
                        recycleListView.setPadding(paddingLeft, i4, paddingRight, paddingBottom);
                    }
                    if (obj == null) {
                        findViewById4 = alertController.mListView;
                        if (findViewById4 == null) {
                            findViewById4 = alertController.mScrollView;
                        }
                        if (findViewById4 != null) {
                            if (1 != obj2) {
                                i2 = 2;
                            }
                            findViewById = alertController.mWindow.findViewById(R.id.scrollIndicatorUp);
                            findViewById2 = alertController.mWindow.findViewById(R.id.scrollIndicatorDown);
                            ViewCompat.setScrollIndicators$ar$ds(findViewById4, i3 | i2);
                            if (findViewById != null) {
                                resolvePanel$ar$ds2.removeView(findViewById);
                            }
                            if (findViewById2 != null) {
                                resolvePanel$ar$ds2.removeView(findViewById2);
                            }
                        }
                    }
                    listView2 = alertController.mListView;
                    if (listView2 != null) {
                        listAdapter = alertController.mAdapter;
                        if (listAdapter != null) {
                            listView2.setAdapter(listAdapter);
                            i5 = alertController.mCheckedItem;
                            if (i5 >= 0) {
                                listView2.setItemChecked(i5, true);
                                listView2.setSelection(i5);
                            }
                        }
                    }
                }
                if (i3 == 0) {
                    resolvePanel$ar$ds3.setVisibility(8);
                }
                if (alertController.mCustomTitleView == null) {
                    resolvePanel$ar$ds.addView(alertController.mCustomTitleView, 0, new LayoutParams(-1, -2));
                    alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                } else {
                    alertController.mIconView = (ImageView) alertController.mWindow.findViewById(16908294);
                    if (TextUtils.isEmpty(alertController.mTitle)) {
                    }
                    alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                    alertController.mIconView.setVisibility(8);
                    resolvePanel$ar$ds.setVisibility(8);
                }
                if (viewGroup != null) {
                }
                obj = null;
                if (resolvePanel$ar$ds != null) {
                }
                i3 = 0;
                if (resolvePanel$ar$ds3 != null) {
                }
                obj2 = null;
                view = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoButtons);
                if (view != null) {
                    view.setVisibility(0);
                }
                if (i3 != 0) {
                    nestedScrollView = alertController.mScrollView;
                    if (nestedScrollView != null) {
                        nestedScrollView.setClipToPadding(true);
                    }
                    if (alertController.mMessage == null) {
                        if (alertController.mListView != null) {
                            if (view2 != null) {
                                view2.setVisibility(0);
                            }
                        }
                    }
                    view2 = resolvePanel$ar$ds.findViewById(R.id.titleDividerNoCustom);
                    if (view2 != null) {
                        view2.setVisibility(0);
                    }
                } else if (resolvePanel$ar$ds2 != null) {
                    findViewById = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoTitle);
                    if (findViewById != null) {
                        findViewById.setVisibility(0);
                    }
                }
                listView = alertController.mListView;
                if (listView instanceof RecycleListView) {
                    if (obj2 != null) {
                        i4 = i3;
                    } else if (i3 == 0) {
                        i4 = 0;
                    }
                    recycleListView = (RecycleListView) listView;
                    paddingLeft = recycleListView.getPaddingLeft();
                    if (i4 == 0) {
                        i4 = recycleListView.getPaddingTop();
                    } else {
                        i4 = recycleListView.mPaddingTopNoTitle;
                    }
                    paddingRight = recycleListView.getPaddingRight();
                    if (obj2 == null) {
                        paddingBottom = recycleListView.getPaddingBottom();
                    } else {
                        paddingBottom = recycleListView.mPaddingBottomNoButtons;
                    }
                    recycleListView.setPadding(paddingLeft, i4, paddingRight, paddingBottom);
                }
                if (obj == null) {
                    findViewById4 = alertController.mListView;
                    if (findViewById4 == null) {
                        findViewById4 = alertController.mScrollView;
                    }
                    if (findViewById4 != null) {
                        if (1 != obj2) {
                            i2 = 2;
                        }
                        findViewById = alertController.mWindow.findViewById(R.id.scrollIndicatorUp);
                        findViewById2 = alertController.mWindow.findViewById(R.id.scrollIndicatorDown);
                        ViewCompat.setScrollIndicators$ar$ds(findViewById4, i3 | i2);
                        if (findViewById != null) {
                            resolvePanel$ar$ds2.removeView(findViewById);
                        }
                        if (findViewById2 != null) {
                            resolvePanel$ar$ds2.removeView(findViewById2);
                        }
                    }
                }
                listView2 = alertController.mListView;
                if (listView2 != null) {
                    listAdapter = alertController.mAdapter;
                    if (listAdapter != null) {
                        listView2.setAdapter(listAdapter);
                        i5 = alertController.mCheckedItem;
                        if (i5 >= 0) {
                            listView2.setItemChecked(i5, true);
                            listView2.setSelection(i5);
                        }
                    }
                }
            }
        }
        ((FrameLayout) alertController.mWindow.findViewById(R.id.custom)).addView(view, new LayoutParams(-1, -1));
        boolean z = alertController.mViewSpacingSpecified;
        if (alertController.mListView != null) {
            ((LinearLayoutCompat.LayoutParams) viewGroup.getLayoutParams()).weight = 0.0f;
        }
        findViewById = viewGroup.findViewById(R.id.topPanel);
        findViewById2 = viewGroup.findViewById(R.id.contentPanel);
        findViewById3 = viewGroup.findViewById(R.id.buttonPanel);
        resolvePanel$ar$ds = AlertController.resolvePanel$ar$ds(findViewById, findViewById5);
        resolvePanel$ar$ds2 = AlertController.resolvePanel$ar$ds(findViewById2, findViewById6);
        resolvePanel$ar$ds3 = AlertController.resolvePanel$ar$ds(findViewById3, findViewById7);
        alertController.mScrollView = (NestedScrollView) alertController.mWindow.findViewById(R.id.scrollView);
        i2 = 0;
        alertController.mScrollView.setFocusable(false);
        alertController.mScrollView.setNestedScrollingEnabled(false);
        alertController.mMessageView = (TextView) resolvePanel$ar$ds2.findViewById(16908299);
        textView = alertController.mMessageView;
        if (textView == null) {
            charSequence = alertController.mMessage;
            if (charSequence == null) {
                textView.setVisibility(8);
                alertController.mScrollView.removeView(alertController.mMessageView);
                if (alertController.mListView == null) {
                    resolvePanel$ar$ds2.setVisibility(8);
                } else {
                    ViewGroup viewGroup22 = (ViewGroup) alertController.mScrollView.getParent();
                    int indexOfChild2 = viewGroup22.indexOfChild(alertController.mScrollView);
                    viewGroup22.removeViewAt(indexOfChild2);
                    viewGroup22.addView(alertController.mListView, indexOfChild2, new LayoutParams(-1, -1));
                }
            } else {
                textView.setText(charSequence);
            }
        }
        alertController.mButtonPositive = (Button) resolvePanel$ar$ds3.findViewById(16908313);
        alertController.mButtonPositive.setOnClickListener(alertController.mButtonHandler);
        if (TextUtils.isEmpty(alertController.mButtonPositiveText)) {
            alertController.mButtonPositive.setText(alertController.mButtonPositiveText);
            alertController.mButtonPositive.setVisibility(0);
            i3 = 1;
        } else {
            alertController.mButtonPositive.setVisibility(8);
            i3 = 0;
        }
        alertController.mButtonNegative = (Button) resolvePanel$ar$ds3.findViewById(16908314);
        alertController.mButtonNegative.setOnClickListener(alertController.mButtonHandler);
        if (TextUtils.isEmpty(alertController.mButtonNegativeText)) {
            alertController.mButtonNegative.setText(alertController.mButtonNegativeText);
            alertController.mButtonNegative.setVisibility(0);
            i3 |= 2;
        } else {
            alertController.mButtonNegative.setVisibility(8);
        }
        alertController.mButtonNeutral = (Button) resolvePanel$ar$ds3.findViewById(16908315);
        alertController.mButtonNeutral.setOnClickListener(alertController.mButtonHandler);
        charSequence2 = alertController.mButtonNeutralText;
        if (TextUtils.isEmpty(null)) {
            Button button22 = alertController.mButtonNeutral;
            CharSequence charSequence32 = alertController.mButtonNeutralText;
            button22.setText(null);
            alertController.mButtonNeutral.setVisibility(0);
            i3 |= 4;
        } else {
            alertController.mButtonNeutral.setVisibility(8);
        }
        context = alertController.mContext;
        typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.alertDialogCenterButtons, typedValue, true);
        if (typedValue.data != 0) {
            if (i3 == 1) {
                button = alertController.mButtonPositive;
            } else if (i3 == 2) {
                button = alertController.mButtonNegative;
            } else if (i3 == 4) {
                button = alertController.mButtonNeutral;
                AlertController.centerButton$ar$ds(button);
                if (alertController.mCustomTitleView == null) {
                    alertController.mIconView = (ImageView) alertController.mWindow.findViewById(16908294);
                    if (TextUtils.isEmpty(alertController.mTitle)) {
                    }
                    alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                    alertController.mIconView.setVisibility(8);
                    resolvePanel$ar$ds.setVisibility(8);
                } else {
                    resolvePanel$ar$ds.addView(alertController.mCustomTitleView, 0, new LayoutParams(-1, -2));
                    alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                }
                if (viewGroup != null) {
                }
                obj = null;
                if (resolvePanel$ar$ds != null) {
                }
                i3 = 0;
                if (resolvePanel$ar$ds3 != null) {
                }
                obj2 = null;
                view = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoButtons);
                if (view != null) {
                    view.setVisibility(0);
                }
                if (i3 != 0) {
                    nestedScrollView = alertController.mScrollView;
                    if (nestedScrollView != null) {
                        nestedScrollView.setClipToPadding(true);
                    }
                    if (alertController.mMessage == null) {
                        if (alertController.mListView != null) {
                            if (view2 != null) {
                                view2.setVisibility(0);
                            }
                        }
                    }
                    view2 = resolvePanel$ar$ds.findViewById(R.id.titleDividerNoCustom);
                    if (view2 != null) {
                        view2.setVisibility(0);
                    }
                } else if (resolvePanel$ar$ds2 != null) {
                    findViewById = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoTitle);
                    if (findViewById != null) {
                        findViewById.setVisibility(0);
                    }
                }
                listView = alertController.mListView;
                if (listView instanceof RecycleListView) {
                    if (obj2 != null) {
                        i4 = i3;
                    } else if (i3 == 0) {
                        i4 = 0;
                    }
                    recycleListView = (RecycleListView) listView;
                    paddingLeft = recycleListView.getPaddingLeft();
                    if (i4 == 0) {
                        i4 = recycleListView.mPaddingTopNoTitle;
                    } else {
                        i4 = recycleListView.getPaddingTop();
                    }
                    paddingRight = recycleListView.getPaddingRight();
                    if (obj2 == null) {
                        paddingBottom = recycleListView.mPaddingBottomNoButtons;
                    } else {
                        paddingBottom = recycleListView.getPaddingBottom();
                    }
                    recycleListView.setPadding(paddingLeft, i4, paddingRight, paddingBottom);
                }
                if (obj == null) {
                    findViewById4 = alertController.mListView;
                    if (findViewById4 == null) {
                        findViewById4 = alertController.mScrollView;
                    }
                    if (findViewById4 != null) {
                        if (1 != obj2) {
                            i2 = 2;
                        }
                        findViewById = alertController.mWindow.findViewById(R.id.scrollIndicatorUp);
                        findViewById2 = alertController.mWindow.findViewById(R.id.scrollIndicatorDown);
                        ViewCompat.setScrollIndicators$ar$ds(findViewById4, i3 | i2);
                        if (findViewById != null) {
                            resolvePanel$ar$ds2.removeView(findViewById);
                        }
                        if (findViewById2 != null) {
                            resolvePanel$ar$ds2.removeView(findViewById2);
                        }
                    }
                }
                listView2 = alertController.mListView;
                if (listView2 != null) {
                    listAdapter = alertController.mAdapter;
                    if (listAdapter != null) {
                        listView2.setAdapter(listAdapter);
                        i5 = alertController.mCheckedItem;
                        if (i5 >= 0) {
                            listView2.setItemChecked(i5, true);
                            listView2.setSelection(i5);
                        }
                    }
                }
            }
            AlertController.centerButton$ar$ds(button);
            if (alertController.mCustomTitleView == null) {
                resolvePanel$ar$ds.addView(alertController.mCustomTitleView, 0, new LayoutParams(-1, -2));
                alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
            } else {
                alertController.mIconView = (ImageView) alertController.mWindow.findViewById(16908294);
                if (TextUtils.isEmpty(alertController.mTitle)) {
                }
                alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
                alertController.mIconView.setVisibility(8);
                resolvePanel$ar$ds.setVisibility(8);
            }
            if (viewGroup != null) {
            }
            obj = null;
            if (resolvePanel$ar$ds != null) {
            }
            i3 = 0;
            if (resolvePanel$ar$ds3 != null) {
            }
            obj2 = null;
            view = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoButtons);
            if (view != null) {
                view.setVisibility(0);
            }
            if (i3 != 0) {
                nestedScrollView = alertController.mScrollView;
                if (nestedScrollView != null) {
                    nestedScrollView.setClipToPadding(true);
                }
                if (alertController.mMessage == null) {
                    if (alertController.mListView != null) {
                        if (view2 != null) {
                            view2.setVisibility(0);
                        }
                    }
                }
                view2 = resolvePanel$ar$ds.findViewById(R.id.titleDividerNoCustom);
                if (view2 != null) {
                    view2.setVisibility(0);
                }
            } else if (resolvePanel$ar$ds2 != null) {
                findViewById = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoTitle);
                if (findViewById != null) {
                    findViewById.setVisibility(0);
                }
            }
            listView = alertController.mListView;
            if (listView instanceof RecycleListView) {
                if (obj2 != null) {
                    i4 = i3;
                } else if (i3 == 0) {
                    i4 = 0;
                }
                recycleListView = (RecycleListView) listView;
                paddingLeft = recycleListView.getPaddingLeft();
                if (i4 == 0) {
                    i4 = recycleListView.getPaddingTop();
                } else {
                    i4 = recycleListView.mPaddingTopNoTitle;
                }
                paddingRight = recycleListView.getPaddingRight();
                if (obj2 == null) {
                    paddingBottom = recycleListView.getPaddingBottom();
                } else {
                    paddingBottom = recycleListView.mPaddingBottomNoButtons;
                }
                recycleListView.setPadding(paddingLeft, i4, paddingRight, paddingBottom);
            }
            if (obj == null) {
                findViewById4 = alertController.mListView;
                if (findViewById4 == null) {
                    findViewById4 = alertController.mScrollView;
                }
                if (findViewById4 != null) {
                    if (1 != obj2) {
                        i2 = 2;
                    }
                    findViewById = alertController.mWindow.findViewById(R.id.scrollIndicatorUp);
                    findViewById2 = alertController.mWindow.findViewById(R.id.scrollIndicatorDown);
                    ViewCompat.setScrollIndicators$ar$ds(findViewById4, i3 | i2);
                    if (findViewById != null) {
                        resolvePanel$ar$ds2.removeView(findViewById);
                    }
                    if (findViewById2 != null) {
                        resolvePanel$ar$ds2.removeView(findViewById2);
                    }
                }
            }
            listView2 = alertController.mListView;
            if (listView2 != null) {
                listAdapter = alertController.mAdapter;
                if (listAdapter != null) {
                    listView2.setAdapter(listAdapter);
                    i5 = alertController.mCheckedItem;
                    if (i5 >= 0) {
                        listView2.setItemChecked(i5, true);
                        listView2.setSelection(i5);
                    }
                }
            }
        }
        if (i3 == 0) {
            resolvePanel$ar$ds3.setVisibility(8);
        }
        if (alertController.mCustomTitleView == null) {
            alertController.mIconView = (ImageView) alertController.mWindow.findViewById(16908294);
            if (TextUtils.isEmpty(alertController.mTitle)) {
            }
            alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
            alertController.mIconView.setVisibility(8);
            resolvePanel$ar$ds.setVisibility(8);
        } else {
            resolvePanel$ar$ds.addView(alertController.mCustomTitleView, 0, new LayoutParams(-1, -2));
            alertController.mWindow.findViewById(R.id.title_template).setVisibility(8);
        }
        if (viewGroup != null) {
        }
        obj = null;
        if (resolvePanel$ar$ds != null) {
        }
        i3 = 0;
        if (resolvePanel$ar$ds3 != null) {
        }
        obj2 = null;
        view = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoButtons);
        if (view != null) {
            view.setVisibility(0);
        }
        if (i3 != 0) {
            nestedScrollView = alertController.mScrollView;
            if (nestedScrollView != null) {
                nestedScrollView.setClipToPadding(true);
            }
            if (alertController.mMessage == null) {
                if (alertController.mListView != null) {
                    if (view2 != null) {
                        view2.setVisibility(0);
                    }
                }
            }
            view2 = resolvePanel$ar$ds.findViewById(R.id.titleDividerNoCustom);
            if (view2 != null) {
                view2.setVisibility(0);
            }
        } else if (resolvePanel$ar$ds2 != null) {
            findViewById = resolvePanel$ar$ds2.findViewById(R.id.textSpacerNoTitle);
            if (findViewById != null) {
                findViewById.setVisibility(0);
            }
        }
        listView = alertController.mListView;
        if (listView instanceof RecycleListView) {
            if (obj2 != null) {
                i4 = i3;
            } else if (i3 == 0) {
                i4 = 0;
            }
            recycleListView = (RecycleListView) listView;
            paddingLeft = recycleListView.getPaddingLeft();
            if (i4 == 0) {
                i4 = recycleListView.mPaddingTopNoTitle;
            } else {
                i4 = recycleListView.getPaddingTop();
            }
            paddingRight = recycleListView.getPaddingRight();
            if (obj2 == null) {
                paddingBottom = recycleListView.mPaddingBottomNoButtons;
            } else {
                paddingBottom = recycleListView.getPaddingBottom();
            }
            recycleListView.setPadding(paddingLeft, i4, paddingRight, paddingBottom);
        }
        if (obj == null) {
            findViewById4 = alertController.mListView;
            if (findViewById4 == null) {
                findViewById4 = alertController.mScrollView;
            }
            if (findViewById4 != null) {
                if (1 != obj2) {
                    i2 = 2;
                }
                findViewById = alertController.mWindow.findViewById(R.id.scrollIndicatorUp);
                findViewById2 = alertController.mWindow.findViewById(R.id.scrollIndicatorDown);
                ViewCompat.setScrollIndicators$ar$ds(findViewById4, i3 | i2);
                if (findViewById != null) {
                    resolvePanel$ar$ds2.removeView(findViewById);
                }
                if (findViewById2 != null) {
                    resolvePanel$ar$ds2.removeView(findViewById2);
                }
            }
        }
        listView2 = alertController.mListView;
        if (listView2 != null) {
            listAdapter = alertController.mAdapter;
            if (listAdapter != null) {
                listView2.setAdapter(listAdapter);
                i5 = alertController.mCheckedItem;
                if (i5 >= 0) {
                    listView2.setItemChecked(i5, true);
                    listView2.setSelection(i5);
                }
            }
        }
    }

    public final void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.mAlert.setTitle(charSequence);
    }

    public final boolean onKeyDown(int i, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.mAlert.mScrollView;
        if (nestedScrollView == null || !nestedScrollView.executeKeyEvent(keyEvent)) {
            return super.onKeyDown(i, keyEvent);
        }
        return true;
    }

    public final boolean onKeyUp(int i, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.mAlert.mScrollView;
        if (nestedScrollView == null || !nestedScrollView.executeKeyEvent(keyEvent)) {
            return super.onKeyUp(i, keyEvent);
        }
        return true;
    }
}
