package android.support.p002v7.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import androidx.collection.SimpleArrayMap;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/* compiled from: PG */
/* renamed from: android.support.v7.app.AppCompatViewInflater */
public class AppCompatViewInflater {
    public static final String[] sClassPrefixList = new String[]{"android.widget.", "android.view.", "android.webkit."};
    private static final SimpleArrayMap sConstructorMap = new SimpleArrayMap();
    private static final Class[] sConstructorSignature = new Class[]{Context.class, AttributeSet.class};
    public static final int[] sOnClickAttrs = new int[]{16843375};
    public final Object[] mConstructorArgs = new Object[2];

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AppCompatViewInflater$DeclaredOnClickListener */
    final class DeclaredOnClickListener implements OnClickListener {
        private final View mHostView;
        private final String mMethodName;
        private Context mResolvedContext;
        private Method mResolvedMethod;

        public DeclaredOnClickListener(View view, String str) {
            this.mHostView = view;
            this.mMethodName = str;
        }

        public final void onClick(View view) {
            if (this.mResolvedMethod == null) {
                String str;
                for (Context context = this.mHostView.getContext(); context != null; context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null) {
                    try {
                        if (!context.isRestricted()) {
                            Method method = context.getClass().getMethod(this.mMethodName, new Class[]{View.class});
                            if (method != null) {
                                this.mResolvedMethod = method;
                                this.mResolvedContext = context;
                            }
                        }
                    } catch (NoSuchMethodException e) {
                    }
                }
                int id = this.mHostView.getId();
                if (id == -1) {
                    str = "";
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(" with id '");
                    stringBuilder.append(this.mHostView.getContext().getResources().getResourceEntryName(id));
                    stringBuilder.append("'");
                    str = stringBuilder.toString();
                }
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Could not find method ");
                stringBuilder2.append(this.mMethodName);
                stringBuilder2.append("(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
                stringBuilder2.append(this.mHostView.getClass());
                stringBuilder2.append(str);
                throw new IllegalStateException(stringBuilder2.toString());
            }
            try {
                this.mResolvedMethod.invoke(this.mResolvedContext, new Object[]{view});
            } catch (Throwable e2) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e2);
            } catch (Throwable e22) {
                throw new IllegalStateException("Could not execute method for android:onClick", e22);
            }
        }
    }

    public final View createViewByPrefix(Context context, String str, String str2) {
        SimpleArrayMap simpleArrayMap = sConstructorMap;
        Constructor constructor = (Constructor) simpleArrayMap.get(str);
        if (constructor == null) {
            if (str2 != null) {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(str2);
                    stringBuilder.append(str);
                    str2 = stringBuilder.toString();
                } catch (Exception e) {
                    return null;
                }
            }
            str2 = str;
            constructor = Class.forName(str2, false, context.getClassLoader()).asSubclass(View.class).getConstructor(sConstructorSignature);
            simpleArrayMap.put(str, constructor);
        }
        constructor.setAccessible(true);
        return (View) constructor.newInstance(this.mConstructorArgs);
    }
}
