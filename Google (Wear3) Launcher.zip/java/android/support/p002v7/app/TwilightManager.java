package android.support.p002v7.app;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;

/* compiled from: PG */
/* renamed from: android.support.v7.app.TwilightManager */
final class TwilightManager {
    public static TwilightManager sInstance;
    public final Context mContext;
    private final LocationManager mLocationManager;
    public final TwilightState mTwilightState = new TwilightState();

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.TwilightManager$TwilightState */
    final class TwilightState {
        boolean isNight;
        long nextUpdate;
    }

    public TwilightManager(Context context, LocationManager locationManager) {
        this.mContext = context;
        this.mLocationManager = locationManager;
    }

    public final Location getLastKnownLocationForProvider(String str) {
        try {
            if (this.mLocationManager.isProviderEnabled(str)) {
                return this.mLocationManager.getLastKnownLocation(str);
            }
        } catch (Throwable e) {
            Log.d("TwilightManager", "Failed to get last known location", e);
        }
        return null;
    }
}
