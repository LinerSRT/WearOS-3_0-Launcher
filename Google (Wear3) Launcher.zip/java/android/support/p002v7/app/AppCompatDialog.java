package android.support.p002v7.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.p000v4.view.KeyEventDispatcher;
import android.support.p000v4.view.KeyEventDispatcher.Component;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v7.app.AppCompatDialog */
public class AppCompatDialog extends Dialog {
    private AppCompatDelegate mDelegate;
    private final Component mKeyDispatcher = new PG();

    /* renamed from: android.support.v7.app.AppCompatDialog$1 */
    final class PG implements Component {
        public final boolean superDispatchKeyEvent(KeyEvent keyEvent) {
            return AppCompatDialog.this.superDispatchKeyEvent(keyEvent);
        }
    }

    public AppCompatDialog(Context context, int i) {
        super(context, AppCompatDialog.getThemeResId(context, i));
        AppCompatDelegate delegate = getDelegate();
        ((AppCompatDelegateImpl) delegate).mThemeResId = AppCompatDialog.getThemeResId(context, i);
        delegate.onCreate$ar$ds();
    }

    private static int getThemeResId(Context context, int i) {
        if (i != 0) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    public final void addContentView(View view, LayoutParams layoutParams) {
        getDelegate().addContentView(view, layoutParams);
    }

    public final void dismiss() {
        super.dismiss();
        getDelegate().onDestroy();
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        getWindow().getDecorView();
        return KeyEventDispatcher.dispatchKeyEvent$ar$ds(this.mKeyDispatcher, keyEvent);
    }

    public final View findViewById(int i) {
        return getDelegate().findViewById(i);
    }

    public final AppCompatDelegate getDelegate() {
        if (this.mDelegate == null) {
            this.mDelegate = AppCompatDelegate.create$ar$ds$38628b0_0(this);
        }
        return this.mDelegate;
    }

    public final void invalidateOptionsMenu() {
        getDelegate().invalidateOptionsMenu();
    }

    protected void onCreate(Bundle bundle) {
        Object delegate = getDelegate();
        LayoutInflater from = LayoutInflater.from(((AppCompatDelegateImpl) delegate).mContext);
        if (from.getFactory() == null) {
            from.setFactory2(delegate);
        } else if (!(from.getFactory2() instanceof AppCompatDelegateImpl)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
        super.onCreate(bundle);
        getDelegate().onCreate$ar$ds();
    }

    protected final void onStop() {
        super.onStop();
        getDelegate().onStop();
    }

    public final void setContentView(int i) {
        getDelegate().setContentView(i);
    }

    public final void setTitle(int i) {
        super.setTitle(i);
        getDelegate().setTitle(getContext().getString(i));
    }

    final boolean superDispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public final void setContentView(View view) {
        getDelegate().setContentView(view);
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        getDelegate().setTitle(charSequence);
    }

    public final void setContentView(View view, LayoutParams layoutParams) {
        getDelegate().setContentView(view, layoutParams);
    }
}
