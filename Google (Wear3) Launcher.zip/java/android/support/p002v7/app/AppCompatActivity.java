package android.support.p002v7.app;

import android.arch.lifecycle.ViewTreeLifecycleOwner;
import android.arch.lifecycle.ViewTreeViewModelStoreOwner;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.LocaleList;
import android.support.p000v4.app.FragmentActivity;
import android.support.p000v4.app.NavUtils;
import android.support.p000v4.app.TaskStackBuilder;
import android.support.p000v4.content.res.ResourcesCompat$ThemeCompat$ImplApi29;
import android.support.p002v7.view.ActionBarPolicy;
import android.support.p002v7.view.SupportMenuInflater;
import android.support.p002v7.widget.AppCompatDrawableManager;
import android.support.v7.app.AppCompatActivity.C00792;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import androidx.activity.contextaware.OnContextAvailableListener;
import androidx.core.content.ContextCompat.Api16Impl;
import androidx.savedstate.SavedStateRegistry.SavedStateProvider;
import androidx.savedstate.ViewTreeSavedStateRegistryOwner;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v7.app.AppCompatActivity */
public final class AppCompatActivity extends FragmentActivity {
    private AppCompatDelegate mDelegate;

    /* renamed from: android.support.v7.app.AppCompatActivity$1 */
    final class PG implements SavedStateProvider {
        public final Bundle saveState() {
            Bundle bundle = new Bundle();
            throw null;
        }
    }

    /* renamed from: android.support.v7.app.AppCompatActivity$2 */
    final class C00792 implements OnContextAvailableListener {
        public final void onContextAvailable$ar$ds() {
            throw null;
        }
    }

    public AppCompatActivity() {
        getSavedStateRegistry().registerSavedStateProvider("androidx:appcompat", new PG());
        addOnContextAvailableListener(new C00792());
    }

    private final void initViewTreeOwners() {
        ViewTreeLifecycleOwner.set(getWindow().getDecorView(), this);
        ViewTreeViewModelStoreOwner.set(getWindow().getDecorView(), this);
        ViewTreeSavedStateRegistryOwner.set(getWindow().getDecorView(), this);
    }

    public final void addContentView(View view, LayoutParams layoutParams) {
        initViewTreeOwners();
        getDelegate().addContentView(view, layoutParams);
    }

    protected final void attachBaseContext(Context context) {
        AppCompatDelegateImpl appCompatDelegateImpl = (AppCompatDelegateImpl) getDelegate();
        appCompatDelegateImpl.mBaseContextAttached = true;
        int mapNightMode = appCompatDelegateImpl.mapNightMode(context, appCompatDelegateImpl.calculateNightMode());
        Configuration configuration = null;
        if (AppCompatDelegateImpl.sCanApplyOverrideConfiguration && (context instanceof ContextThemeWrapper)) {
            try {
                ((ContextThemeWrapper) context).applyOverrideConfiguration(appCompatDelegateImpl.createOverrideConfigurationForDayNight(context, mapNightMode, null));
            } catch (IllegalStateException e) {
            }
            super.attachBaseContext(context);
        }
        if (context instanceof androidx.appcompat.view.ContextThemeWrapper) {
            try {
                ((androidx.appcompat.view.ContextThemeWrapper) context).applyOverrideConfiguration(appCompatDelegateImpl.createOverrideConfigurationForDayNight(context, mapNightMode, null));
            } catch (IllegalStateException e2) {
            }
            super.attachBaseContext(context);
        }
        if (AppCompatDelegateImpl.sCanReturnDifferentContext) {
            Configuration createOverrideConfigurationForDayNight;
            Context contextThemeWrapper;
            Configuration configuration2 = new Configuration();
            configuration2.uiMode = -1;
            configuration2.fontScale = 0.0f;
            configuration2 = context.createConfigurationContext(configuration2).getResources().getConfiguration();
            Configuration configuration3 = context.getResources().getConfiguration();
            configuration2.uiMode = configuration3.uiMode;
            if (!configuration2.equals(configuration3)) {
                configuration = new Configuration();
                configuration.fontScale = 0.0f;
                if (configuration3 != null) {
                    if (configuration2.diff(configuration3) != 0) {
                        if (configuration2.fontScale != configuration3.fontScale) {
                            configuration.fontScale = configuration3.fontScale;
                        }
                        if (configuration2.mcc != configuration3.mcc) {
                            configuration.mcc = configuration3.mcc;
                        }
                        if (configuration2.mnc != configuration3.mnc) {
                            configuration.mnc = configuration3.mnc;
                        }
                        LocaleList locales = configuration2.getLocales();
                        LocaleList locales2 = configuration3.getLocales();
                        if (!locales.equals(locales2)) {
                            configuration.setLocales(locales2);
                            configuration.locale = configuration3.locale;
                        }
                        if (configuration2.touchscreen != configuration3.touchscreen) {
                            configuration.touchscreen = configuration3.touchscreen;
                        }
                        if (configuration2.keyboard != configuration3.keyboard) {
                            configuration.keyboard = configuration3.keyboard;
                        }
                        if (configuration2.keyboardHidden != configuration3.keyboardHidden) {
                            configuration.keyboardHidden = configuration3.keyboardHidden;
                        }
                        if (configuration2.navigation != configuration3.navigation) {
                            configuration.navigation = configuration3.navigation;
                        }
                        if (configuration2.navigationHidden != configuration3.navigationHidden) {
                            configuration.navigationHidden = configuration3.navigationHidden;
                        }
                        if (configuration2.orientation != configuration3.orientation) {
                            configuration.orientation = configuration3.orientation;
                        }
                        if ((configuration2.screenLayout & 15) != (configuration3.screenLayout & 15)) {
                            configuration.screenLayout |= configuration3.screenLayout & 15;
                        }
                        if ((configuration2.screenLayout & 192) != (configuration3.screenLayout & 192)) {
                            configuration.screenLayout |= configuration3.screenLayout & 192;
                        }
                        if ((configuration2.screenLayout & 48) != (configuration3.screenLayout & 48)) {
                            configuration.screenLayout |= configuration3.screenLayout & 48;
                        }
                        if ((configuration2.screenLayout & 768) != (configuration3.screenLayout & 768)) {
                            configuration.screenLayout |= configuration3.screenLayout & 768;
                        }
                        if ((configuration2.colorMode & 3) != (configuration3.colorMode & 3)) {
                            configuration.colorMode |= configuration3.colorMode & 3;
                        }
                        if ((configuration2.colorMode & 12) != (configuration3.colorMode & 12)) {
                            configuration.colorMode |= configuration3.colorMode & 12;
                        }
                        if ((configuration2.uiMode & 15) != (configuration3.uiMode & 15)) {
                            configuration.uiMode |= configuration3.uiMode & 15;
                        }
                        if ((configuration2.uiMode & 48) != (configuration3.uiMode & 48)) {
                            configuration.uiMode |= configuration3.uiMode & 48;
                        }
                        if (configuration2.screenWidthDp != configuration3.screenWidthDp) {
                            configuration.screenWidthDp = configuration3.screenWidthDp;
                        }
                        if (configuration2.screenHeightDp != configuration3.screenHeightDp) {
                            configuration.screenHeightDp = configuration3.screenHeightDp;
                        }
                        if (configuration2.smallestScreenWidthDp != configuration3.smallestScreenWidthDp) {
                            configuration.smallestScreenWidthDp = configuration3.smallestScreenWidthDp;
                        }
                        if (configuration2.densityDpi != configuration3.densityDpi) {
                            configuration.densityDpi = configuration3.densityDpi;
                        }
                    }
                    createOverrideConfigurationForDayNight = appCompatDelegateImpl.createOverrideConfigurationForDayNight(context, mapNightMode, configuration);
                    contextThemeWrapper = new androidx.appcompat.view.ContextThemeWrapper(context, R.style.Theme.AppCompat.Empty);
                    contextThemeWrapper.applyOverrideConfiguration(createOverrideConfigurationForDayNight);
                    if (context.getTheme() != null) {
                        ResourcesCompat$ThemeCompat$ImplApi29.rebase(contextThemeWrapper.getTheme());
                    }
                    context = contextThemeWrapper;
                }
            }
            createOverrideConfigurationForDayNight = appCompatDelegateImpl.createOverrideConfigurationForDayNight(context, mapNightMode, configuration);
            contextThemeWrapper = new androidx.appcompat.view.ContextThemeWrapper(context, R.style.Theme.AppCompat.Empty);
            contextThemeWrapper.applyOverrideConfiguration(createOverrideConfigurationForDayNight);
            try {
                if (context.getTheme() != null) {
                    ResourcesCompat$ThemeCompat$ImplApi29.rebase(contextThemeWrapper.getTheme());
                }
            } catch (NullPointerException e3) {
            }
            context = contextThemeWrapper;
        }
        super.attachBaseContext(context);
    }

    public final void closeOptionsMenu() {
        getSupportActionBar();
        if (getWindow().hasFeature(0)) {
            super.closeOptionsMenu();
        }
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        keyEvent.getKeyCode();
        getSupportActionBar();
        return super.dispatchKeyEvent(keyEvent);
    }

    public final View findViewById(int i) {
        return getDelegate().findViewById(i);
    }

    public final AppCompatDelegate getDelegate() {
        if (this.mDelegate == null) {
            this.mDelegate = AppCompatDelegate.create$ar$ds$5f96c4e8_0(this);
        }
        return this.mDelegate;
    }

    public final MenuInflater getMenuInflater() {
        AppCompatDelegateImpl appCompatDelegateImpl = (AppCompatDelegateImpl) getDelegate();
        if (appCompatDelegateImpl.mMenuInflater == null) {
            Context themedContext;
            appCompatDelegateImpl.initWindowDecorActionBar();
            ActionBar actionBar = appCompatDelegateImpl.mActionBar;
            if (actionBar != null) {
                themedContext = actionBar.getThemedContext();
            } else {
                themedContext = appCompatDelegateImpl.mContext;
            }
            appCompatDelegateImpl.mMenuInflater = new SupportMenuInflater(themedContext);
        }
        return appCompatDelegateImpl.mMenuInflater;
    }

    public final ActionBar getSupportActionBar() {
        return getDelegate().getSupportActionBar();
    }

    public final void invalidateOptionsMenu() {
        getDelegate().invalidateOptionsMenu();
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        AppCompatDelegateImpl appCompatDelegateImpl = (AppCompatDelegateImpl) getDelegate();
        if (appCompatDelegateImpl.mHasActionBar && appCompatDelegateImpl.mSubDecorInstalled) {
            ActionBar supportActionBar = appCompatDelegateImpl.getSupportActionBar();
            if (supportActionBar != null) {
                WindowDecorActionBar windowDecorActionBar = (WindowDecorActionBar) supportActionBar;
                windowDecorActionBar.setHasEmbeddedTabs(ActionBarPolicy.hasEmbeddedTabs$ar$objectUnboxing(windowDecorActionBar.mContext));
            }
        }
        AppCompatDrawableManager.get().onConfigurationChanged(appCompatDelegateImpl.mContext);
        appCompatDelegateImpl.applyDayNight$ar$ds$35f8ca22_0(false);
    }

    public final void onContentChanged() {
    }

    protected final void onDestroy() {
        super.onDestroy();
        getDelegate().onDestroy();
    }

    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        boolean z = true;
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        ActionBar supportActionBar = getSupportActionBar();
        if (menuItem.getItemId() != 16908332 || supportActionBar == null || (((WindowDecorActionBar) supportActionBar).mDecorToolbar.getDisplayOptions() & 4) == 0) {
            return false;
        }
        Intent parentActivityIntent = NavUtils.getParentActivityIntent(this);
        if (parentActivityIntent == null) {
            z = false;
        } else if (shouldUpRecreateTask(parentActivityIntent)) {
            TaskStackBuilder taskStackBuilder = new TaskStackBuilder(this);
            Intent parentActivityIntent2 = NavUtils.getParentActivityIntent(this);
            if (parentActivityIntent2 == null) {
                parentActivityIntent2 = NavUtils.getParentActivityIntent(this);
            }
            if (parentActivityIntent2 != null) {
                ComponentName component = parentActivityIntent2.getComponent();
                if (component == null) {
                    component = parentActivityIntent2.resolveActivity(taskStackBuilder.mSourceContext.getPackageManager());
                }
                int size = taskStackBuilder.mIntents.size();
                try {
                    for (Intent parentActivityIntent3 = NavUtils.getParentActivityIntent(taskStackBuilder.mSourceContext, component); parentActivityIntent3 != null; parentActivityIntent3 = NavUtils.getParentActivityIntent(taskStackBuilder.mSourceContext, parentActivityIntent3.getComponent())) {
                        taskStackBuilder.mIntents.add(size, parentActivityIntent3);
                    }
                    taskStackBuilder.mIntents.add(parentActivityIntent2);
                } catch (Throwable e) {
                    Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
                    throw new IllegalArgumentException(e);
                }
            }
            if (taskStackBuilder.mIntents.isEmpty()) {
                throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
            }
            ArrayList arrayList = taskStackBuilder.mIntents;
            Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[arrayList.size()]);
            intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
            Api16Impl.startActivities(taskStackBuilder.mSourceContext, intentArr, null);
            try {
                finishAffinity();
            } catch (IllegalStateException e2) {
                finish();
            }
        } else {
            navigateUpTo(parentActivityIntent);
        }
        return z;
    }

    protected final void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((AppCompatDelegateImpl) getDelegate()).ensureSubDecor();
    }

    protected final void onPostResume() {
        super.onPostResume();
        ActionBar supportActionBar = ((AppCompatDelegateImpl) getDelegate()).getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.setShowHideAnimationEnabled(true);
        }
    }

    protected final void onStart() {
        super.onStart();
        AppCompatDelegateImpl appCompatDelegateImpl = (AppCompatDelegateImpl) getDelegate();
        appCompatDelegateImpl.mStarted = true;
        appCompatDelegateImpl.applyDayNight$ar$ds();
    }

    protected final void onStop() {
        super.onStop();
        getDelegate().onStop();
    }

    protected final void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        getDelegate().setTitle(charSequence);
    }

    public final void openOptionsMenu() {
        getSupportActionBar();
        if (getWindow().hasFeature(0)) {
            super.openOptionsMenu();
        }
    }

    public final void setContentView(int i) {
        initViewTreeOwners();
        getDelegate().setContentView(i);
    }

    public final void setTheme(int i) {
        super.setTheme(i);
        ((AppCompatDelegateImpl) getDelegate()).mThemeResId = i;
    }

    public final void supportInvalidateOptionsMenu() {
        getDelegate().invalidateOptionsMenu();
    }

    public final void setContentView(View view) {
        initViewTreeOwners();
        getDelegate().setContentView(view);
    }

    public final void setContentView(View view, LayoutParams layoutParams) {
        initViewTreeOwners();
        getDelegate().setContentView(view, layoutParams);
    }
}
