package android.support.p002v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.ViewPropertyAnimatorCompat;
import android.support.p000v4.view.ViewPropertyAnimatorListener;
import android.support.p000v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.p002v7.app.ActionBar.OnMenuVisibilityListener;
import android.support.p002v7.appcompat.R$styleable;
import android.support.p002v7.view.ActionBarPolicy;
import android.support.p002v7.view.ActionMode;
import android.support.p002v7.view.ActionMode.Callback;
import android.support.p002v7.view.SupportMenuInflater;
import android.support.p002v7.view.ViewPropertyAnimatorCompatSet;
import android.support.p002v7.view.menu.MenuBuilder;
import android.support.p002v7.widget.ActionBarContainer;
import android.support.p002v7.widget.ActionBarContextView;
import android.support.p002v7.widget.ActionBarOverlayLayout;
import android.support.p002v7.widget.ActionBarOverlayLayout.ActionBarVisibilityCallback;
import android.support.p002v7.widget.DecorToolbar;
import android.support.p002v7.widget.Toolbar;
import android.support.v7.app.WindowDecorActionBar.C00842;
import android.support.v7.app.WindowDecorActionBar.C00853;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import com.google.android.wearable.sysui.R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v7.app.WindowDecorActionBar */
public final class WindowDecorActionBar extends ActionBar implements ActionBarVisibilityCallback {
    private static final Interpolator sHideInterpolator = new AccelerateInterpolator();
    private static final Interpolator sShowInterpolator = new DecelerateInterpolator();
    ActionModeImpl mActionMode;
    public ActionBarContainer mContainerView;
    public boolean mContentAnimations = true;
    View mContentView;
    Context mContext;
    ActionBarContextView mContextView;
    public int mCurWindowVisibility = 0;
    public ViewPropertyAnimatorCompatSet mCurrentShowAnim;
    DecorToolbar mDecorToolbar;
    ActionMode mDeferredDestroyActionMode;
    Callback mDeferredModeDestroyCallback;
    private boolean mDisplayHomeAsUpSet;
    public boolean mHiddenBySystem;
    final ViewPropertyAnimatorListener mHideListener = new PG();
    boolean mHideOnContentScroll;
    private boolean mLastMenuVisibility;
    private final ArrayList mMenuVisibilityListeners = new ArrayList();
    private boolean mNowShowing = true;
    ActionBarOverlayLayout mOverlayLayout;
    private boolean mShowHideAnimationEnabled;
    final ViewPropertyAnimatorListener mShowListener = new C00842();
    private boolean mShowingForMode;
    private Context mThemedContext;
    final C00853 mUpdateListener$ar$class_merging = new C00853();

    /* renamed from: android.support.v7.app.WindowDecorActionBar$1 */
    final class PG extends ViewPropertyAnimatorListenerAdapter {
        public final void onAnimationEnd$ar$ds() {
            View view;
            WindowDecorActionBar windowDecorActionBar = WindowDecorActionBar.this;
            if (windowDecorActionBar.mContentAnimations) {
                view = windowDecorActionBar.mContentView;
                if (view != null) {
                    view.setTranslationY(0.0f);
                    WindowDecorActionBar.this.mContainerView.setTranslationY(0.0f);
                }
            }
            WindowDecorActionBar.this.mContainerView.setVisibility(8);
            WindowDecorActionBar.this.mContainerView.setTransitioning(false);
            windowDecorActionBar = WindowDecorActionBar.this;
            windowDecorActionBar.mCurrentShowAnim = null;
            Callback callback = windowDecorActionBar.mDeferredModeDestroyCallback;
            if (callback != null) {
                callback.onDestroyActionMode(windowDecorActionBar.mDeferredDestroyActionMode);
                windowDecorActionBar.mDeferredDestroyActionMode = null;
                windowDecorActionBar.mDeferredModeDestroyCallback = null;
            }
            view = WindowDecorActionBar.this.mOverlayLayout;
            if (view != null) {
                ViewCompat.requestApplyInsets(view);
            }
        }
    }

    /* renamed from: android.support.v7.app.WindowDecorActionBar$2 */
    final class C00842 extends ViewPropertyAnimatorListenerAdapter {
        public final void onAnimationEnd$ar$ds() {
            android.support.p002v7.app.WindowDecorActionBar windowDecorActionBar = android.support.p002v7.app.WindowDecorActionBar.this;
            windowDecorActionBar.mCurrentShowAnim = null;
            windowDecorActionBar.mContainerView.requestLayout();
        }
    }

    /* renamed from: android.support.v7.app.WindowDecorActionBar$3 */
    public final class C00853 {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.WindowDecorActionBar$ActionModeImpl */
    public final class ActionModeImpl extends ActionMode implements MenuBuilder.Callback {
        private final Context mActionModeContext;
        public Callback mCallback;
        private WeakReference mCustomView;
        public final MenuBuilder mMenu;

        public ActionModeImpl(Context context, Callback callback) {
            this.mActionModeContext = context;
            this.mCallback = callback;
            MenuBuilder menuBuilder = new MenuBuilder(context);
            menuBuilder.setDefaultShowAsAction$ar$ds();
            this.mMenu = menuBuilder;
        }

        public final View getCustomView() {
            WeakReference weakReference = this.mCustomView;
            return weakReference != null ? (View) weakReference.get() : null;
        }

        public final Menu getMenu() {
            return this.mMenu;
        }

        public final MenuInflater getMenuInflater() {
            return new SupportMenuInflater(this.mActionModeContext);
        }

        public final CharSequence getSubtitle() {
            return WindowDecorActionBar.this.mContextView.mSubtitle;
        }

        public final CharSequence getTitle() {
            return WindowDecorActionBar.this.mContextView.mTitle;
        }

        public final void invalidate() {
            if (WindowDecorActionBar.this.mActionMode == this) {
                this.mMenu.stopDispatchingItemsChanged();
                try {
                    this.mCallback.onPrepareActionMode$ar$ds(this, this.mMenu);
                } finally {
                    this.mMenu.startDispatchingItemsChanged();
                }
            }
        }

        public final boolean isTitleOptional() {
            return WindowDecorActionBar.this.mContextView.mTitleOptional;
        }

        public final boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
            Callback callback = this.mCallback;
            return callback != null ? callback.onActionItemClicked(this, menuItem) : false;
        }

        public final void onMenuModeChange$ar$ds() {
            if (this.mCallback != null) {
                invalidate();
                WindowDecorActionBar.this.mContextView.showOverflowMenu$ar$ds();
            }
        }

        public final void setCustomView(View view) {
            WindowDecorActionBar.this.mContextView.setCustomView(view);
            this.mCustomView = new WeakReference(view);
        }

        public final void setSubtitle(int i) {
            setSubtitle(WindowDecorActionBar.this.mContext.getResources().getString(i));
        }

        public final void setTitle(int i) {
            setTitle(WindowDecorActionBar.this.mContext.getResources().getString(i));
        }

        public final void setTitleOptionalHint(boolean z) {
            this.mTitleOptionalHint = z;
            WindowDecorActionBar.this.mContextView.setTitleOptional(z);
        }

        public final void finish() {
            WindowDecorActionBar windowDecorActionBar = WindowDecorActionBar.this;
            if (windowDecorActionBar.mActionMode == this) {
                if (WindowDecorActionBar.checkShowingFlags$ar$ds(windowDecorActionBar.mHiddenBySystem, false)) {
                    this.mCallback.onDestroyActionMode(this);
                } else {
                    windowDecorActionBar = WindowDecorActionBar.this;
                    windowDecorActionBar.mDeferredDestroyActionMode = this;
                    windowDecorActionBar.mDeferredModeDestroyCallback = this.mCallback;
                }
                this.mCallback = null;
                WindowDecorActionBar.this.animateToMode(false);
                ActionBarContextView actionBarContextView = WindowDecorActionBar.this.mContextView;
                if (actionBarContextView.mClose == null) {
                    actionBarContextView.killMode();
                }
                WindowDecorActionBar.this.mDecorToolbar.getViewGroup().sendAccessibilityEvent(32);
                WindowDecorActionBar windowDecorActionBar2 = WindowDecorActionBar.this;
                windowDecorActionBar2.mOverlayLayout.setHideOnContentScrollEnabled(windowDecorActionBar2.mHideOnContentScroll);
                WindowDecorActionBar.this.mActionMode = null;
            }
        }

        public final void setSubtitle(CharSequence charSequence) {
            WindowDecorActionBar.this.mContextView.setSubtitle(charSequence);
        }

        public final void setTitle(CharSequence charSequence) {
            WindowDecorActionBar.this.mContextView.setTitle(charSequence);
        }
    }

    public WindowDecorActionBar(Activity activity, boolean z) {
        ArrayList arrayList = new ArrayList();
        View decorView = activity.getWindow().getDecorView();
        init(decorView);
        if (!z) {
            this.mContentView = decorView.findViewById(16908290);
        }
    }

    static boolean checkShowingFlags$ar$ds(boolean z, boolean z2) {
        return z2 || !z;
    }

    private final void init(View view) {
        DecorToolbar decorToolbar;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(R.id.decor_content_parent);
        this.mOverlayLayout = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.mActionBarVisibilityCallback = this;
            if (actionBarOverlayLayout.getWindowToken() != null) {
                ((WindowDecorActionBar) actionBarOverlayLayout.mActionBarVisibilityCallback).mCurWindowVisibility = actionBarOverlayLayout.mWindowVisibility;
                int i = actionBarOverlayLayout.mLastSystemUiVisibility;
                if (i != 0) {
                    actionBarOverlayLayout.onWindowSystemUiVisibilityChanged(i);
                    ViewCompat.requestApplyInsets(actionBarOverlayLayout);
                }
            }
        }
        View findViewById = view.findViewById(R.id.action_bar);
        if (findViewById instanceof DecorToolbar) {
            decorToolbar = (DecorToolbar) findViewById;
        } else if (findViewById instanceof Toolbar) {
            decorToolbar = ((Toolbar) findViewById).getWrapper();
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Can't make a decor toolbar out of ");
            stringBuilder.append(findViewById != null ? findViewById.getClass().getSimpleName() : "null");
            throw new IllegalStateException(stringBuilder.toString());
        }
        this.mDecorToolbar = decorToolbar;
        this.mContextView = (ActionBarContextView) view.findViewById(R.id.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(R.id.action_bar_container);
        this.mContainerView = actionBarContainer;
        decorToolbar = this.mDecorToolbar;
        if (decorToolbar == null || this.mContextView == null || actionBarContainer == null) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(getClass().getSimpleName());
            stringBuilder2.append(" can only be used with a compatible window decor layout");
            throw new IllegalStateException(stringBuilder2.toString());
        }
        this.mContext = decorToolbar.getContext();
        if ((this.mDecorToolbar.getDisplayOptions() & 4) != 0) {
            this.mDisplayHomeAsUpSet = true;
        }
        Context context = this.mContext;
        i = context.getApplicationInfo().targetSdkVersion;
        this.mDecorToolbar.setHomeButtonEnabled$ar$ds();
        setHasEmbeddedTabs(ActionBarPolicy.hasEmbeddedTabs$ar$objectUnboxing(context));
        TypedArray obtainStyledAttributes = this.mContext.obtainStyledAttributes(null, R$styleable.ActionBar, R.attr.actionBarStyle, 0);
        if (obtainStyledAttributes.getBoolean(14, false)) {
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.mOverlayLayout;
            if (actionBarOverlayLayout2.mOverlayMode) {
                this.mHideOnContentScroll = true;
                actionBarOverlayLayout2.setHideOnContentScrollEnabled(true);
            } else {
                throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
            }
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(12, 0);
        if (dimensionPixelSize != 0) {
            ViewCompat.setElevation(this.mContainerView, (float) dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    public final void dispatchMenuVisibilityChanged(boolean z) {
        if (z != this.mLastMenuVisibility) {
            this.mLastMenuVisibility = z;
            int size = this.mMenuVisibilityListeners.size();
            for (int i = 0; i < size; i++) {
                ((OnMenuVisibilityListener) this.mMenuVisibilityListeners.get(i)).onMenuVisibilityChanged$ar$ds();
            }
        }
    }

    public final Context getThemedContext() {
        if (this.mThemedContext == null) {
            TypedValue typedValue = new TypedValue();
            this.mContext.getTheme().resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
            int i = typedValue.resourceId;
            if (i != 0) {
                this.mThemedContext = new ContextThemeWrapper(this.mContext, i);
            } else {
                this.mThemedContext = this.mContext;
            }
        }
        return this.mThemedContext;
    }

    public final void setShowHideAnimationEnabled(boolean z) {
        this.mShowHideAnimationEnabled = z;
        if (!z) {
            ViewPropertyAnimatorCompatSet viewPropertyAnimatorCompatSet = this.mCurrentShowAnim;
            if (viewPropertyAnimatorCompatSet != null) {
                viewPropertyAnimatorCompatSet.cancel();
            }
        }
    }

    public final void setWindowTitle(CharSequence charSequence) {
        this.mDecorToolbar.setWindowTitle(charSequence);
    }

    public final void animateToMode(boolean z) {
        if (z) {
            if (!this.mShowingForMode) {
                this.mShowingForMode = true;
                updateVisibility(false);
            }
        } else if (this.mShowingForMode) {
            this.mShowingForMode = false;
            updateVisibility(false);
        }
        if (ViewCompat.isLaidOut(this.mContainerView)) {
            ViewPropertyAnimatorCompat viewPropertyAnimatorCompat;
            ViewPropertyAnimatorCompat viewPropertyAnimatorCompat2;
            long duration;
            if (z) {
                viewPropertyAnimatorCompat = this.mDecorToolbar.setupAnimatorToVisibility(4, 100);
                viewPropertyAnimatorCompat2 = this.mContextView.setupAnimatorToVisibility(0, 200);
            } else {
                viewPropertyAnimatorCompat2 = this.mDecorToolbar.setupAnimatorToVisibility(0, 200);
                viewPropertyAnimatorCompat = this.mContextView.setupAnimatorToVisibility(8, 100);
            }
            ViewPropertyAnimatorCompatSet viewPropertyAnimatorCompatSet = new ViewPropertyAnimatorCompatSet();
            viewPropertyAnimatorCompatSet.mAnimators.add(viewPropertyAnimatorCompat);
            View view = (View) viewPropertyAnimatorCompat.mView.get();
            if (view != null) {
                duration = view.animate().getDuration();
            } else {
                duration = 0;
            }
            view = (View) viewPropertyAnimatorCompat2.mView.get();
            if (view != null) {
                view.animate().setStartDelay(duration);
            }
            viewPropertyAnimatorCompatSet.mAnimators.add(viewPropertyAnimatorCompat2);
            viewPropertyAnimatorCompatSet.start();
        } else if (z) {
            this.mDecorToolbar.setVisibility(4);
            this.mContextView.setVisibility(0);
        } else {
            this.mDecorToolbar.setVisibility(0);
            this.mContextView.setVisibility(8);
        }
    }

    public final void setDefaultDisplayHomeAsUpEnabled(boolean z) {
        if (!this.mDisplayHomeAsUpSet) {
            int i;
            if (true != z) {
                i = 0;
            } else {
                i = 4;
            }
            int displayOptions = this.mDecorToolbar.getDisplayOptions();
            this.mDisplayHomeAsUpSet = true;
            this.mDecorToolbar.setDisplayOptions((i & 4) | (displayOptions & -5));
        }
    }

    public final void setHasEmbeddedTabs(boolean z) {
        if (z) {
            this.mDecorToolbar.setEmbeddedTabView$ar$ds();
        } else {
            this.mDecorToolbar.setEmbeddedTabView$ar$ds();
        }
        this.mDecorToolbar.getNavigationMode$ar$ds();
        this.mDecorToolbar.setCollapsible$ar$ds();
        this.mOverlayLayout.mHasNonEmbeddedTabs = false;
    }

    public final void updateVisibility(boolean z) {
        ViewPropertyAnimatorCompatSet viewPropertyAnimatorCompatSet;
        int[] iArr;
        View view;
        if (WindowDecorActionBar.checkShowingFlags$ar$ds(this.mHiddenBySystem, this.mShowingForMode)) {
            if (!this.mNowShowing) {
                this.mNowShowing = true;
                viewPropertyAnimatorCompatSet = this.mCurrentShowAnim;
                if (viewPropertyAnimatorCompatSet != null) {
                    viewPropertyAnimatorCompatSet.cancel();
                }
                this.mContainerView.setVisibility(0);
                if (this.mCurWindowVisibility == 0) {
                    if (!this.mShowHideAnimationEnabled) {
                        if (z) {
                            z = true;
                        }
                    }
                    this.mContainerView.setTranslationY(0.0f);
                    float f = (float) (-this.mContainerView.getHeight());
                    if (z) {
                        iArr = new int[]{0, 0};
                        this.mContainerView.getLocationInWindow(iArr);
                        f -= (float) iArr[1];
                    }
                    this.mContainerView.setTranslationY(f);
                    ViewPropertyAnimatorCompatSet viewPropertyAnimatorCompatSet2 = new ViewPropertyAnimatorCompatSet();
                    ViewPropertyAnimatorCompat animate = ViewCompat.animate(this.mContainerView);
                    animate.translationY$ar$ds(0.0f);
                    animate.setUpdateListener$ar$class_merging$ar$ds(this.mUpdateListener$ar$class_merging);
                    viewPropertyAnimatorCompatSet2.play$ar$ds(animate);
                    if (this.mContentAnimations) {
                        View view2 = this.mContentView;
                        if (view2 != null) {
                            view2.setTranslationY(f);
                            ViewPropertyAnimatorCompat animate2 = ViewCompat.animate(this.mContentView);
                            animate2.translationY$ar$ds(0.0f);
                            viewPropertyAnimatorCompatSet2.play$ar$ds(animate2);
                        }
                    }
                    viewPropertyAnimatorCompatSet2.setInterpolator$ar$ds(sShowInterpolator);
                    viewPropertyAnimatorCompatSet2.setDuration$ar$ds$382ef02f_0();
                    viewPropertyAnimatorCompatSet2.setListener$ar$ds$2e30dec0_0(this.mShowListener);
                    this.mCurrentShowAnim = viewPropertyAnimatorCompatSet2;
                    viewPropertyAnimatorCompatSet2.start();
                    view = this.mOverlayLayout;
                    if (view != null) {
                        ViewCompat.requestApplyInsets(view);
                    }
                }
                this.mContainerView.setAlpha(1.0f);
                this.mContainerView.setTranslationY(0.0f);
                if (this.mContentAnimations) {
                    view = this.mContentView;
                    if (view != null) {
                        view.setTranslationY(0.0f);
                    }
                }
                this.mShowListener.onAnimationEnd$ar$ds();
                view = this.mOverlayLayout;
                if (view != null) {
                    ViewCompat.requestApplyInsets(view);
                }
            }
        } else if (this.mNowShowing) {
            this.mNowShowing = false;
            viewPropertyAnimatorCompatSet = this.mCurrentShowAnim;
            if (viewPropertyAnimatorCompatSet != null) {
                viewPropertyAnimatorCompatSet.cancel();
            }
            if (this.mCurWindowVisibility == 0) {
                if (!this.mShowHideAnimationEnabled) {
                    if (z) {
                        z = true;
                    }
                }
                this.mContainerView.setAlpha(1.0f);
                this.mContainerView.setTransitioning(true);
                viewPropertyAnimatorCompatSet = new ViewPropertyAnimatorCompatSet();
                float f2 = (float) (-this.mContainerView.getHeight());
                if (z) {
                    iArr = new int[]{0, 0};
                    this.mContainerView.getLocationInWindow(iArr);
                    f2 -= (float) iArr[1];
                }
                ViewPropertyAnimatorCompat animate3 = ViewCompat.animate(this.mContainerView);
                animate3.translationY$ar$ds(f2);
                animate3.setUpdateListener$ar$class_merging$ar$ds(this.mUpdateListener$ar$class_merging);
                viewPropertyAnimatorCompatSet.play$ar$ds(animate3);
                if (this.mContentAnimations) {
                    view = this.mContentView;
                    if (view != null) {
                        animate3 = ViewCompat.animate(view);
                        animate3.translationY$ar$ds(f2);
                        viewPropertyAnimatorCompatSet.play$ar$ds(animate3);
                    }
                }
                viewPropertyAnimatorCompatSet.setInterpolator$ar$ds(sHideInterpolator);
                viewPropertyAnimatorCompatSet.setDuration$ar$ds$382ef02f_0();
                viewPropertyAnimatorCompatSet.setListener$ar$ds$2e30dec0_0(this.mHideListener);
                this.mCurrentShowAnim = viewPropertyAnimatorCompatSet;
                viewPropertyAnimatorCompatSet.start();
                return;
            }
            this.mHideListener.onAnimationEnd$ar$ds();
        }
    }

    public WindowDecorActionBar(Dialog dialog) {
        ArrayList arrayList = new ArrayList();
        init(dialog.getWindow().getDecorView());
    }
}
