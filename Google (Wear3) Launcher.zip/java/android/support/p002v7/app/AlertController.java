package android.support.p002v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.support.p000v4.widget.NestedScrollView;
import android.support.p002v7.app.AlertController.RecycleListView;
import android.support.p002v7.appcompat.R$styleable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.google.android.libraries.wear.wcs.contract.deeplink.DeepLinkServiceResult;
import com.google.android.wearable.sysui.R;
import java.lang.ref.WeakReference;

/* compiled from: PG */
/* renamed from: android.support.v7.app.AlertController */
public final class AlertController {
    ListAdapter mAdapter;
    public final int mAlertDialogLayout;
    public final OnClickListener mButtonHandler = new PG();
    Button mButtonNegative;
    Message mButtonNegativeMessage;
    public CharSequence mButtonNegativeText;
    Button mButtonNeutral;
    public CharSequence mButtonNeutralText;
    public final int mButtonPanelSideLayout;
    Button mButtonPositive;
    Message mButtonPositiveMessage;
    public CharSequence mButtonPositiveText;
    int mCheckedItem = -1;
    public final Context mContext;
    public View mCustomTitleView;
    final AppCompatDialog mDialog;
    final Handler mHandler;
    public Drawable mIcon;
    public int mIconId = 0;
    public ImageView mIconView;
    final int mListItemLayout;
    final int mListLayout;
    public ListView mListView;
    public CharSequence mMessage;
    public TextView mMessageView;
    final int mMultiChoiceItemLayout;
    NestedScrollView mScrollView;
    public final boolean mShowTitle;
    final int mSingleChoiceItemLayout;
    public CharSequence mTitle;
    public TextView mTitleView;
    public View mView;
    public boolean mViewSpacingSpecified = false;
    public final Window mWindow;

    /* renamed from: android.support.v7.app.AlertController$1 */
    final class PG implements OnClickListener {
        public final void onClick(View view) {
            AlertController alertController;
            AlertController alertController2 = AlertController.this;
            Message message = null;
            if (view == alertController2.mButtonPositive) {
                Message message2 = alertController2.mButtonPositiveMessage;
                if (message2 != null) {
                    message = Message.obtain(message2);
                    if (message != null) {
                        message.sendToTarget();
                    }
                    alertController = AlertController.this;
                    alertController.mHandler.obtainMessage(1, alertController.mDialog).sendToTarget();
                }
            }
            if (view == alertController2.mButtonNegative) {
                Message message3 = alertController2.mButtonNegativeMessage;
                if (message3 != null) {
                    message = Message.obtain(message3);
                    if (message != null) {
                        message.sendToTarget();
                    }
                    alertController = AlertController.this;
                    alertController.mHandler.obtainMessage(1, alertController.mDialog).sendToTarget();
                }
            }
            Button button = alertController2.mButtonNeutral;
            if (message != null) {
                message.sendToTarget();
            }
            alertController = AlertController.this;
            alertController.mHandler.obtainMessage(1, alertController.mDialog).sendToTarget();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AlertController$AlertParams */
    public final class AlertParams {
        public ListAdapter mAdapter;
        public int mCheckedItem = -1;
        public boolean[] mCheckedItems;
        public final Context mContext;
        public View mCustomTitleView;
        public Drawable mIcon;
        public final LayoutInflater mInflater;
        public boolean mIsMultiChoice;
        public boolean mIsSingleChoice;
        public CharSequence[] mItems;
        public CharSequence mMessage;
        public DialogInterface.OnClickListener mNegativeButtonListener;
        public CharSequence mNegativeButtonText;
        public OnMultiChoiceClickListener mOnCheckboxClickListener;
        public DialogInterface.OnClickListener mOnClickListener;
        public OnKeyListener mOnKeyListener;
        public DialogInterface.OnClickListener mPositiveButtonListener;
        public CharSequence mPositiveButtonText;
        public CharSequence mTitle;
        public View mView;

        /* renamed from: android.support.v7.app.AlertController$AlertParams$1 */
        final class PG extends ArrayAdapter {
            final /* synthetic */ RecycleListView val$listView;

            public PG(Context context, int i, CharSequence[] charSequenceArr, RecycleListView recycleListView) {
                this.val$listView = recycleListView;
                super(context, i, 16908308, charSequenceArr);
            }

            public final View getView(int i, View view, ViewGroup viewGroup) {
                view = super.getView(i, view, viewGroup);
                boolean[] zArr = AlertParams.this.mCheckedItems;
                if (zArr != null && zArr[i]) {
                    this.val$listView.setItemChecked(i, true);
                }
                return view;
            }
        }

        /* renamed from: android.support.v7.app.AlertController$AlertParams$3 */
        final class C00773 implements OnItemClickListener {
            final /* synthetic */ android.support.p002v7.app.AlertController val$dialog;

            public C00773(android.support.p002v7.app.AlertController alertController) {
                this.val$dialog = alertController;
            }

            public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                android.support.p002v7.app.AlertController.AlertParams.this.mOnClickListener.onClick(this.val$dialog.mDialog, i);
                if (!android.support.p002v7.app.AlertController.AlertParams.this.mIsSingleChoice) {
                    this.val$dialog.mDialog.dismiss();
                }
            }
        }

        /* renamed from: android.support.v7.app.AlertController$AlertParams$4 */
        final class C00784 implements OnItemClickListener {
            final /* synthetic */ android.support.p002v7.app.AlertController val$dialog;
            final /* synthetic */ RecycleListView val$listView;

            public C00784(RecycleListView recycleListView, android.support.p002v7.app.AlertController alertController) {
                this.val$listView = recycleListView;
                this.val$dialog = alertController;
            }

            public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                boolean[] zArr = android.support.p002v7.app.AlertController.AlertParams.this.mCheckedItems;
                if (zArr != null) {
                    zArr[i] = this.val$listView.isItemChecked(i);
                }
                android.support.p002v7.app.AlertController.AlertParams.this.mOnCheckboxClickListener.onClick(this.val$dialog.mDialog, i, this.val$listView.isItemChecked(i));
            }
        }

        public AlertParams(Context context) {
            this.mContext = context;
            this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AlertController$ButtonHandler */
    final class ButtonHandler extends Handler {
        private final WeakReference mDialog;

        public ButtonHandler(DialogInterface dialogInterface) {
            this.mDialog = new WeakReference(dialogInterface);
        }

        public final void handleMessage(Message message) {
            switch (message.what) {
                case -3:
                case DeepLinkServiceResult.RPC_SEND_FAILURE /*-2*/:
                case -1:
                    ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.mDialog.get(), message.what);
                    return;
                case 1:
                    ((DialogInterface) message.obj).dismiss();
                    return;
                default:
                    return;
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AlertController$CheckedItemAdapter */
    final class CheckedItemAdapter extends ArrayAdapter {
        public CheckedItemAdapter(Context context, int i, CharSequence[] charSequenceArr) {
            super(context, i, 16908308, charSequenceArr);
        }

        public final long getItemId(int i) {
            return (long) i;
        }

        public final boolean hasStableIds() {
            return true;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v7.app.AlertController$RecycleListView */
    public class RecycleListView extends ListView {
        public final int mPaddingBottomNoButtons;
        public final int mPaddingTopNoTitle;

        public RecycleListView(Context context) {
            this(context, null);
        }

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.RecycleListView);
            this.mPaddingBottomNoButtons = obtainStyledAttributes.getDimensionPixelOffset(0, -1);
            this.mPaddingTopNoTitle = obtainStyledAttributes.getDimensionPixelOffset(1, -1);
        }
    }

    public AlertController(Context context, AppCompatDialog appCompatDialog, Window window) {
        this.mContext = context;
        this.mDialog = appCompatDialog;
        this.mWindow = window;
        this.mHandler = new ButtonHandler(appCompatDialog);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(null, R$styleable.AlertDialog, R.attr.alertDialogStyle, 0);
        this.mAlertDialogLayout = obtainStyledAttributes.getResourceId(0, 0);
        this.mButtonPanelSideLayout = obtainStyledAttributes.getResourceId(2, 0);
        this.mListLayout = obtainStyledAttributes.getResourceId(4, 0);
        this.mMultiChoiceItemLayout = obtainStyledAttributes.getResourceId(5, 0);
        this.mSingleChoiceItemLayout = obtainStyledAttributes.getResourceId(7, 0);
        this.mListItemLayout = obtainStyledAttributes.getResourceId(3, 0);
        this.mShowTitle = obtainStyledAttributes.getBoolean(6, true);
        obtainStyledAttributes.getDimensionPixelSize(1, 0);
        obtainStyledAttributes.recycle();
        appCompatDialog.getDelegate().requestWindowFeature$ar$ds(1);
    }

    static boolean canTextInput(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (AlertController.canTextInput(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    public static final void centerButton$ar$ds(Button button) {
        LayoutParams layoutParams = (LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    public static final ViewGroup resolvePanel$ar$ds(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    public final void setButton$ar$ds(int i, CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
        Message obtainMessage = onClickListener != null ? this.mHandler.obtainMessage(i, onClickListener) : null;
        switch (i) {
            case DeepLinkServiceResult.RPC_SEND_FAILURE /*-2*/:
                this.mButtonNegativeText = charSequence;
                this.mButtonNegativeMessage = obtainMessage;
                return;
            default:
                this.mButtonPositiveText = charSequence;
                this.mButtonPositiveMessage = obtainMessage;
                return;
        }
    }

    public final void setTitle(CharSequence charSequence) {
        this.mTitle = charSequence;
        TextView textView = this.mTitleView;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }
}
