package android.support.p002v7.content.res;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.support.p002v7.widget.ResourceManagerInternal;
import java.util.WeakHashMap;

/* compiled from: PG */
/* renamed from: android.support.v7.content.res.AppCompatResources */
public final class AppCompatResources {
    static {
        ThreadLocal threadLocal = new ThreadLocal();
        WeakHashMap weakHashMap = new WeakHashMap(0);
    }

    public static ColorStateList getColorStateList(Context context, int i) {
        return context.getColorStateList(i);
    }

    public static Drawable getDrawable(Context context, int i) {
        return ResourceManagerInternal.get().getDrawable(context, i);
    }
}
