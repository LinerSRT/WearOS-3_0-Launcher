package android.support.p000v4.view;

import android.content.ClipData;
import android.net.Uri;
import android.os.Bundle;
import android.support.p000v4.util.Preconditions;
import android.view.ContentInfo;
import android.view.ContentInfo.Builder;

/* compiled from: PG */
/* renamed from: android.support.v4.view.ContentInfoCompat */
public final class ContentInfoCompat {
    public final Compat mCompat;

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ContentInfoCompat$Builder */
    public final class Builder {
        public static final ContentInfoCompat build$ar$objectUnboxing$9e7ca98a_0(BuilderCompat builderCompat) {
            return builderCompat.build();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ContentInfoCompat$BuilderCompat */
    public interface BuilderCompat {
        ContentInfoCompat build();

        void setExtras(Bundle bundle);

        void setFlags(int i);

        void setLinkUri(Uri uri);
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ContentInfoCompat$BuilderCompat31Impl */
    public final class BuilderCompat31Impl implements BuilderCompat {
        private final Builder mPlatformBuilder;

        public BuilderCompat31Impl(ClipData clipData, int i) {
            this.mPlatformBuilder = new Builder(clipData, i);
        }

        public final ContentInfoCompat build() {
            return new ContentInfoCompat(new Compat31Impl(this.mPlatformBuilder.build()));
        }

        public final void setExtras(Bundle bundle) {
            this.mPlatformBuilder.setExtras(bundle);
        }

        public final void setFlags(int i) {
            this.mPlatformBuilder.setFlags(i);
        }

        public final void setLinkUri(Uri uri) {
            this.mPlatformBuilder.setLinkUri(uri);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ContentInfoCompat$BuilderCompatImpl */
    public final class BuilderCompatImpl implements BuilderCompat {
        final ClipData mClip;
        Bundle mExtras;
        int mFlags;
        Uri mLinkUri;
        final int mSource;

        public BuilderCompatImpl(ClipData clipData, int i) {
            this.mClip = clipData;
            this.mSource = i;
        }

        public final ContentInfoCompat build() {
            return new ContentInfoCompat(new CompatImpl(this));
        }

        public final void setExtras(Bundle bundle) {
            this.mExtras = bundle;
        }

        public final void setFlags(int i) {
            this.mFlags = i;
        }

        public final void setLinkUri(Uri uri) {
            this.mLinkUri = uri;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ContentInfoCompat$Compat */
    public interface Compat {
        ClipData getClip();

        int getFlags();

        int getSource();

        ContentInfo getWrapped();
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ContentInfoCompat$Compat31Impl */
    final class Compat31Impl implements Compat {
        private final ContentInfo mWrapped;

        public Compat31Impl(ContentInfo contentInfo) {
            Preconditions.checkNotNull$ar$ds(contentInfo);
            this.mWrapped = contentInfo;
        }

        public final ClipData getClip() {
            return this.mWrapped.getClip();
        }

        public final int getFlags() {
            return this.mWrapped.getFlags();
        }

        public final int getSource() {
            return this.mWrapped.getSource();
        }

        public final ContentInfo getWrapped() {
            return this.mWrapped;
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("ContentInfoCompat{");
            stringBuilder.append(this.mWrapped);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ContentInfoCompat$CompatImpl */
    final class CompatImpl implements Compat {
        private final ClipData mClip;
        private final Bundle mExtras;
        private final int mFlags;
        private final Uri mLinkUri;
        private final int mSource;

        public CompatImpl(BuilderCompatImpl builderCompatImpl) {
            ClipData clipData = builderCompatImpl.mClip;
            Preconditions.checkNotNull$ar$ds(clipData);
            this.mClip = clipData;
            this.mSource = builderCompatImpl.mSource;
            this.mFlags = builderCompatImpl.mFlags;
            this.mLinkUri = builderCompatImpl.mLinkUri;
            this.mExtras = builderCompatImpl.mExtras;
        }

        public final ClipData getClip() {
            return this.mClip;
        }

        public final int getFlags() {
            return this.mFlags;
        }

        public final int getSource() {
            return this.mSource;
        }

        public final ContentInfo getWrapped() {
            return null;
        }

        public final String toString() {
            String str;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("ContentInfoCompat{clip=");
            stringBuilder.append(this.mClip.getDescription());
            stringBuilder.append(", source=");
            switch (this.mSource) {
                case 1:
                    str = "SOURCE_CLIPBOARD";
                    break;
                case 2:
                    str = "SOURCE_INPUT_METHOD";
                    break;
                default:
                    str = "SOURCE_DRAG_AND_DROP";
                    break;
            }
            stringBuilder.append(str);
            stringBuilder.append(", flags=");
            stringBuilder.append(1 != this.mFlags ? "0" : "FLAG_CONVERT_TO_PLAIN_TEXT");
            String str2 = "";
            if (this.mLinkUri == null) {
                str = str2;
            } else {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(", hasLinkUri(");
                stringBuilder2.append(this.mLinkUri.toString().length());
                stringBuilder2.append(")");
                str = stringBuilder2.toString();
            }
            stringBuilder.append(str);
            if (this.mExtras != null) {
                str2 = ", hasExtras";
            }
            stringBuilder.append(str2);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

    public ContentInfoCompat(Compat compat) {
        this.mCompat = compat;
    }

    public final String toString() {
        return this.mCompat.toString();
    }
}
