package android.support.p000v4.view;

import android.support.p000v4.graphics.Insets;
import android.support.p000v4.util.Preconditions;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsets.Builder;
import p020j$.util.Objects;

/* compiled from: PG */
/* renamed from: android.support.v4.view.WindowInsetsCompat */
public class WindowInsetsCompat {
    public static final WindowInsetsCompat CONSUMED = Impl30.CONSUMED;
    private final Impl mImpl;

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$Builder */
    public final class Builder {
        @Deprecated
        public static final void setSystemWindowInsets$ar$ds$ar$objectUnboxing(Insets insets, BuilderImpl builderImpl) {
            ((BuilderImpl29) builderImpl).mPlatBuilder.setSystemWindowInsets(insets.toPlatformInsets());
        }

        public static final WindowInsetsCompat build$ar$objectUnboxing$d0a2c6a9_0(BuilderImpl builderImpl) {
            WindowInsetsCompat toWindowInsetsCompat = WindowInsetsCompat.toWindowInsetsCompat(((BuilderImpl29) builderImpl).mPlatBuilder.build());
            toWindowInsetsCompat.setOverriddenInsets(null);
            return toWindowInsetsCompat;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$BuilderImpl */
    class BuilderImpl {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$BuilderImpl29 */
    class BuilderImpl29 extends BuilderImpl {
        final Builder mPlatBuilder;

        public BuilderImpl29() {
            WindowInsetsCompat windowInsetsCompat = new WindowInsetsCompat(null);
            this.mPlatBuilder = new Builder();
        }

        public BuilderImpl29(WindowInsetsCompat windowInsetsCompat) {
            WindowInsets toWindowInsets = windowInsetsCompat.toWindowInsets();
            this.mPlatBuilder = toWindowInsets != null ? new Builder(toWindowInsets) : new Builder();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$BuilderImpl30 */
    public final class BuilderImpl30 extends BuilderImpl29 {
        public BuilderImpl30(WindowInsetsCompat windowInsetsCompat) {
            super(windowInsetsCompat);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$Impl */
    class Impl {
        static final WindowInsetsCompat CONSUMED = Builder.build$ar$objectUnboxing$d0a2c6a9_0(new BuilderImpl30()).consumeDisplayCutout().consumeStableInsets().consumeSystemWindowInsets();
        final WindowInsetsCompat mHost;

        public Impl(WindowInsetsCompat windowInsetsCompat) {
            this.mHost = windowInsetsCompat;
        }

        public WindowInsetsCompat consumeDisplayCutout() {
            return this.mHost;
        }

        public WindowInsetsCompat consumeStableInsets() {
            return this.mHost;
        }

        public WindowInsetsCompat consumeSystemWindowInsets() {
            return this.mHost;
        }

        public void copyRootViewBounds$ar$ds() {
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Impl)) {
                return false;
            }
            Impl impl = (Impl) obj;
            return isRound() == impl.isRound() && isConsumed() == impl.isConsumed() && Objects.equals(getSystemWindowInsets(), impl.getSystemWindowInsets()) && Objects.equals(getStableInsets(), impl.getStableInsets()) && Objects.equals(getDisplayCutout(), impl.getDisplayCutout());
        }

        public DisplayCutoutCompat getDisplayCutout() {
            return null;
        }

        public Insets getStableInsets() {
            return Insets.NONE;
        }

        public Insets getSystemWindowInsets() {
            return Insets.NONE;
        }

        public int hashCode() {
            return Objects.hash(new Object[]{Boolean.valueOf(isRound()), Boolean.valueOf(isConsumed()), getSystemWindowInsets(), getStableInsets(), getDisplayCutout()});
        }

        public WindowInsetsCompat inset(int i, int i2, int i3, int i4) {
            return CONSUMED;
        }

        public boolean isConsumed() {
            return false;
        }

        public boolean isRound() {
            return false;
        }

        public void setOverriddenInsets$ar$ds() {
        }

        public void setRootWindowInsets$ar$ds() {
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$Impl20 */
    class Impl20 extends Impl {
        final WindowInsets mPlatformInsets;
        Insets mRootViewVisibleInsets;
        private Insets mSystemWindowInsets = null;

        public Impl20(WindowInsetsCompat windowInsetsCompat, WindowInsets windowInsets) {
            super(windowInsetsCompat);
            this.mPlatformInsets = windowInsets;
        }

        public boolean equals(Object obj) {
            if (!super.equals(obj)) {
                return false;
            }
            Insets insets = ((Impl20) obj).mRootViewVisibleInsets;
            return Objects.equals(null, null);
        }

        public final Insets getSystemWindowInsets() {
            if (this.mSystemWindowInsets == null) {
                this.mSystemWindowInsets = Insets.m0of(this.mPlatformInsets.getSystemWindowInsetLeft(), this.mPlatformInsets.getSystemWindowInsetTop(), this.mPlatformInsets.getSystemWindowInsetRight(), this.mPlatformInsets.getSystemWindowInsetBottom());
            }
            return this.mSystemWindowInsets;
        }

        public WindowInsetsCompat inset(int i, int i2, int i3, int i4) {
            BuilderImpl builderImpl30 = new BuilderImpl30(WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets));
            Builder.setSystemWindowInsets$ar$ds$ar$objectUnboxing(WindowInsetsCompat.insetInsets(getSystemWindowInsets(), i, i2, i3, i4), builderImpl30);
            builderImpl30.mPlatBuilder.setStableInsets(WindowInsetsCompat.insetInsets(getStableInsets(), i, i2, i3, i4).toPlatformInsets());
            return Builder.build$ar$objectUnboxing$d0a2c6a9_0(builderImpl30);
        }

        public final boolean isRound() {
            return this.mPlatformInsets.isRound();
        }

        public final void setOverriddenInsets$ar$ds() {
        }

        public final void setRootWindowInsets$ar$ds() {
        }

        public void copyRootViewBounds$ar$ds() {
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$Impl21 */
    class Impl21 extends Impl20 {
        private Insets mStableInsets = null;

        public Impl21(WindowInsetsCompat windowInsetsCompat, WindowInsets windowInsets) {
            super(windowInsetsCompat, windowInsets);
        }

        public final WindowInsetsCompat consumeStableInsets() {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeStableInsets());
        }

        public final WindowInsetsCompat consumeSystemWindowInsets() {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeSystemWindowInsets());
        }

        public final Insets getStableInsets() {
            if (this.mStableInsets == null) {
                this.mStableInsets = Insets.m0of(this.mPlatformInsets.getStableInsetLeft(), this.mPlatformInsets.getStableInsetTop(), this.mPlatformInsets.getStableInsetRight(), this.mPlatformInsets.getStableInsetBottom());
            }
            return this.mStableInsets;
        }

        public final boolean isConsumed() {
            return this.mPlatformInsets.isConsumed();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$Impl28 */
    class Impl28 extends Impl21 {
        public Impl28(WindowInsetsCompat windowInsetsCompat, WindowInsets windowInsets) {
            super(windowInsetsCompat, windowInsets);
        }

        public final WindowInsetsCompat consumeDisplayCutout() {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeDisplayCutout());
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Impl28)) {
                return false;
            }
            Impl28 impl28 = (Impl28) obj;
            if (Objects.equals(this.mPlatformInsets, impl28.mPlatformInsets)) {
                Insets insets = impl28.mRootViewVisibleInsets;
                if (Objects.equals(null, null)) {
                    return true;
                }
            }
            return false;
        }

        public final DisplayCutoutCompat getDisplayCutout() {
            DisplayCutout displayCutout = this.mPlatformInsets.getDisplayCutout();
            if (displayCutout == null) {
                return null;
            }
            return new DisplayCutoutCompat(displayCutout);
        }

        public final int hashCode() {
            return this.mPlatformInsets.hashCode();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$Impl29 */
    class Impl29 extends Impl28 {
        public Impl29(WindowInsetsCompat windowInsetsCompat, WindowInsets windowInsets) {
            super(windowInsetsCompat, windowInsets);
        }

        public final WindowInsetsCompat inset(int i, int i2, int i3, int i4) {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.inset(i, i2, i3, i4));
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$Impl30 */
    final class Impl30 extends Impl29 {
        static final WindowInsetsCompat CONSUMED = WindowInsetsCompat.toWindowInsetsCompat(WindowInsets.CONSUMED);

        public Impl30(WindowInsetsCompat windowInsetsCompat, WindowInsets windowInsets) {
            super(windowInsetsCompat, windowInsets);
        }

        public final void copyRootViewBounds$ar$ds() {
        }
    }

    public WindowInsetsCompat(WindowInsetsCompat windowInsetsCompat) {
        this.mImpl = new Impl(this);
    }

    static Insets insetInsets(Insets insets, int i, int i2, int i3, int i4) {
        int max = Math.max(0, insets.left - i);
        int max2 = Math.max(0, insets.top - i2);
        int max3 = Math.max(0, insets.right - i3);
        int max4 = Math.max(0, insets.bottom - i4);
        return (max == i && max2 == i2 && max3 == i3 && max4 == i4) ? insets : Insets.m0of(max, max2, max3, max4);
    }

    public static WindowInsetsCompat toWindowInsetsCompat(WindowInsets windowInsets) {
        return WindowInsetsCompat.toWindowInsetsCompat(windowInsets, null);
    }

    @Deprecated
    public WindowInsetsCompat consumeDisplayCutout() {
        return this.mImpl.consumeDisplayCutout();
    }

    @Deprecated
    public WindowInsetsCompat consumeStableInsets() {
        return this.mImpl.consumeStableInsets();
    }

    @Deprecated
    public WindowInsetsCompat consumeSystemWindowInsets() {
        return this.mImpl.consumeSystemWindowInsets();
    }

    public void copyRootViewBounds(View view) {
        this.mImpl.copyRootViewBounds$ar$ds();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof WindowInsetsCompat)) {
            return false;
        }
        return Objects.equals(this.mImpl, ((WindowInsetsCompat) obj).mImpl);
    }

    @Deprecated
    public int getSystemWindowInsetBottom() {
        return this.mImpl.getSystemWindowInsets().bottom;
    }

    @Deprecated
    public int getSystemWindowInsetLeft() {
        return this.mImpl.getSystemWindowInsets().left;
    }

    @Deprecated
    public int getSystemWindowInsetRight() {
        return this.mImpl.getSystemWindowInsets().right;
    }

    @Deprecated
    public int getSystemWindowInsetTop() {
        return this.mImpl.getSystemWindowInsets().top;
    }

    public int hashCode() {
        Impl impl = this.mImpl;
        return impl == null ? 0 : impl.hashCode();
    }

    public WindowInsetsCompat inset(int i, int i2, int i3, int i4) {
        return this.mImpl.inset(i, i2, i3, i4);
    }

    public boolean isConsumed() {
        return this.mImpl.isConsumed();
    }

    public void setOverriddenInsets(Insets[] insetsArr) {
        this.mImpl.setOverriddenInsets$ar$ds();
    }

    public void setRootWindowInsets(WindowInsetsCompat windowInsetsCompat) {
        this.mImpl.setRootWindowInsets$ar$ds();
    }

    public WindowInsets toWindowInsets() {
        Impl impl = this.mImpl;
        return impl instanceof Impl20 ? ((Impl20) impl).mPlatformInsets : null;
    }

    private WindowInsetsCompat(WindowInsets windowInsets) {
        this.mImpl = new Impl30(this, windowInsets);
    }

    public static WindowInsetsCompat toWindowInsetsCompat(WindowInsets windowInsets, View view) {
        Preconditions.checkNotNull$ar$ds(windowInsets);
        WindowInsetsCompat windowInsetsCompat = new WindowInsetsCompat(windowInsets);
        if (view != null && ViewCompat.isAttachedToWindow(view)) {
            windowInsetsCompat.setRootWindowInsets(ViewCompat.getRootWindowInsets(view));
            windowInsetsCompat.copyRootViewBounds(view.getRootView());
        }
        return windowInsetsCompat;
    }

    @Deprecated
    public WindowInsetsCompat replaceSystemWindowInsets(int i, int i2, int i3, int i4) {
        BuilderImpl builderImpl30 = new BuilderImpl30(this);
        Builder.setSystemWindowInsets$ar$ds$ar$objectUnboxing(Insets.m0of(i, i2, i3, i4), builderImpl30);
        return Builder.build$ar$objectUnboxing$d0a2c6a9_0(builderImpl30);
    }
}
