package android.support.p000v4.view;

import android.view.KeyEvent;

/* compiled from: PG */
/* renamed from: android.support.v4.view.KeyEventDispatcher */
public final class KeyEventDispatcher {

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.KeyEventDispatcher$Component */
    public interface Component {
        boolean superDispatchKeyEvent(KeyEvent keyEvent);
    }

    public static boolean dispatchKeyEvent$ar$ds(Component component, KeyEvent keyEvent) {
        return component == null ? false : component.superDispatchKeyEvent(keyEvent);
    }
}
