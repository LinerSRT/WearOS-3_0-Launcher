package android.support.p000v4.view;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p000v4.view.AccessibilityDelegateCompat.AccessibilityDelegateAdapter;
import android.support.p000v4.view.ContentInfoCompat.Compat31Impl;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityActionCompat;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand;
import android.support.p000v4.widget.TextViewOnReceiveContentListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContentInfo;
import android.view.Display;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewParent;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: PG */
/* renamed from: android.support.v4.view.ViewCompat */
public final class ViewCompat {
    public static final /* synthetic */ int ViewCompat$ar$NoOp = 0;
    private static WeakHashMap sViewPropertyAnimatorMap = null;

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$AccessibilityPaneVisibilityManager */
    final class AccessibilityPaneVisibilityManager implements OnGlobalLayoutListener, OnAttachStateChangeListener {
        public AccessibilityPaneVisibilityManager() {
            WeakHashMap weakHashMap = new WeakHashMap();
        }

        public final void onGlobalLayout() {
        }

        public final void onViewDetachedFromWindow(View view) {
        }

        public final void onViewAttachedToWindow(View view) {
            view.getViewTreeObserver().addOnGlobalLayoutListener(this);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api15Impl */
    final class Api15Impl {
        static boolean hasOnClickListeners(View view) {
            return view.hasOnClickListeners();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api16Impl */
    final class Api16Impl {
        static int getImportantForAccessibility(View view) {
            return view.getImportantForAccessibility();
        }

        static int getMinimumHeight(View view) {
            return view.getMinimumHeight();
        }

        static int getMinimumWidth(View view) {
            return view.getMinimumWidth();
        }

        static int getWindowSystemUiVisibility(View view) {
            return view.getWindowSystemUiVisibility();
        }

        static boolean hasTransientState(View view) {
            return view.hasTransientState();
        }

        static void postInvalidateOnAnimation(View view) {
            view.postInvalidateOnAnimation();
        }

        static void postOnAnimation(View view, Runnable runnable) {
            view.postOnAnimation(runnable);
        }

        static void postOnAnimationDelayed(View view, Runnable runnable, long j) {
            view.postOnAnimationDelayed(runnable, j);
        }

        static void setBackground(View view, Drawable drawable) {
            view.setBackground(drawable);
        }

        static void setImportantForAccessibility(View view, int i) {
            view.setImportantForAccessibility(i);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api17Impl */
    final class Api17Impl {
        static int generateViewId() {
            return View.generateViewId();
        }

        static Display getDisplay(View view) {
            return view.getDisplay();
        }

        static int getLayoutDirection(View view) {
            return view.getLayoutDirection();
        }

        static int getPaddingEnd(View view) {
            return view.getPaddingEnd();
        }

        static int getPaddingStart(View view) {
            return view.getPaddingStart();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api19Impl */
    final class Api19Impl {
        static int getAccessibilityLiveRegion(View view) {
            return view.getAccessibilityLiveRegion();
        }

        static boolean isAttachedToWindow(View view) {
            return view.isAttachedToWindow();
        }

        static boolean isLaidOut(View view) {
            return view.isLaidOut();
        }

        static void notifySubtreeAccessibilityStateChanged(ViewParent viewParent, View view, View view2, int i) {
            viewParent.notifySubtreeAccessibilityStateChanged(view, view2, 0);
        }

        static void setContentChangeTypes(AccessibilityEvent accessibilityEvent, int i) {
            accessibilityEvent.setContentChangeTypes(0);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api20Impl */
    final class Api20Impl {
        static WindowInsets dispatchApplyWindowInsets(View view, WindowInsets windowInsets) {
            return view.dispatchApplyWindowInsets(windowInsets);
        }

        static WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            return view.onApplyWindowInsets(windowInsets);
        }

        static void requestApplyInsets(View view) {
            view.requestApplyInsets();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api21Impl */
    final class Api21Impl {

        /* renamed from: android.support.v4.view.ViewCompat$Api21Impl$1 */
        final class PG implements OnApplyWindowInsetsListener {
            final /* synthetic */ OnApplyWindowInsetsListener val$listener;

            public PG(OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
                this.val$listener = onApplyWindowInsetsListener;
            }

            public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                return this.val$listener.onApplyWindowInsets(view, WindowInsetsCompat.toWindowInsetsCompat(windowInsets, view)).toWindowInsets();
            }
        }

        static WindowInsetsCompat computeSystemWindowInsets(View view, WindowInsetsCompat windowInsetsCompat, Rect rect) {
            WindowInsets toWindowInsets = windowInsetsCompat.toWindowInsets();
            if (toWindowInsets != null) {
                return WindowInsetsCompat.toWindowInsetsCompat(view.computeSystemWindowInsets(toWindowInsets, rect), view);
            }
            rect.setEmpty();
            return windowInsetsCompat;
        }

        static ColorStateList getBackgroundTintList(View view) {
            return view.getBackgroundTintList();
        }

        static Mode getBackgroundTintMode(View view) {
            return view.getBackgroundTintMode();
        }

        static float getElevation(View view) {
            return view.getElevation();
        }

        static String getTransitionName(View view) {
            return view.getTransitionName();
        }

        static void setBackgroundTintList(View view, ColorStateList colorStateList) {
            view.setBackgroundTintList(colorStateList);
        }

        static void setBackgroundTintMode(View view, Mode mode) {
            view.setBackgroundTintMode(mode);
        }

        static void setElevation(View view, float f) {
            view.setElevation(f);
        }

        static void setOnApplyWindowInsetsListener(View view, OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
            if (onApplyWindowInsetsListener == null) {
                view.setOnApplyWindowInsetsListener((OnApplyWindowInsetsListener) view.getTag(R.id.tag_window_insets_animation_callback));
            } else {
                view.setOnApplyWindowInsetsListener(new PG(onApplyWindowInsetsListener));
            }
        }

        static void setTransitionName(View view, String str) {
            view.setTransitionName(str);
        }

        static void stopNestedScroll(View view) {
            view.stopNestedScroll();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api23Impl */
    final class Api23Impl {
        static void setScrollIndicators(View view, int i, int i2) {
            view.setScrollIndicators(i, 3);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api26Impl */
    final class Api26Impl {
        static int getImportantForAutofill(View view) {
            return view.getImportantForAutofill();
        }

        static void setImportantForAutofill(View view, int i) {
            view.setImportantForAutofill(8);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api28Impl */
    final class Api28Impl {
        static CharSequence getAccessibilityPaneTitle(View view) {
            return view.getAccessibilityPaneTitle();
        }

        static boolean isAccessibilityHeading(View view) {
            return view.isAccessibilityHeading();
        }

        static boolean isScreenReaderFocusable(View view) {
            return view.isScreenReaderFocusable();
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api29Impl */
    final class Api29Impl {
        static AccessibilityDelegate getAccessibilityDelegate(View view) {
            return view.getAccessibilityDelegate();
        }

        static void saveAttributeDataForStyleable(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i, int i2) {
            view.saveAttributeDataForStyleable(context, iArr, attributeSet, typedArray, i, i2);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api30Impl */
    final class Api30Impl {
        static CharSequence getStateDescription(View view) {
            return view.getStateDescription();
        }

        static void setStateDescription(View view, CharSequence charSequence) {
            view.setStateDescription(charSequence);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.ViewCompat$Api31Impl */
    final class Api31Impl {
        public static String[] getReceiveContentMimeTypes(View view) {
            return view.getReceiveContentMimeTypes();
        }

        public static ContentInfoCompat performReceiveContent(View view, ContentInfoCompat contentInfoCompat) {
            ContentInfo wrapped = contentInfoCompat.mCompat.getWrapped();
            ContentInfo performReceiveContent = view.performReceiveContent(wrapped);
            if (performReceiveContent == null) {
                return null;
            }
            if (performReceiveContent == wrapped) {
                return contentInfoCompat;
            }
            return new ContentInfoCompat(new Compat31Impl(performReceiveContent));
        }
    }

    static {
        AtomicInteger atomicInteger = new AtomicInteger(1);
        AccessibilityPaneVisibilityManager accessibilityPaneVisibilityManager = new AccessibilityPaneVisibilityManager();
    }

    public static ViewPropertyAnimatorCompat animate(View view) {
        if (sViewPropertyAnimatorMap == null) {
            sViewPropertyAnimatorMap = new WeakHashMap();
        }
        ViewPropertyAnimatorCompat viewPropertyAnimatorCompat = (ViewPropertyAnimatorCompat) sViewPropertyAnimatorMap.get(view);
        if (viewPropertyAnimatorCompat != null) {
            return viewPropertyAnimatorCompat;
        }
        viewPropertyAnimatorCompat = new ViewPropertyAnimatorCompat(view);
        sViewPropertyAnimatorMap.put(view, viewPropertyAnimatorCompat);
        return viewPropertyAnimatorCompat;
    }

    public static void computeSystemWindowInsets$ar$ds(View view, WindowInsetsCompat windowInsetsCompat, Rect rect) {
        Api21Impl.computeSystemWindowInsets(view, windowInsetsCompat, rect);
    }

    public static WindowInsetsCompat dispatchApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
        WindowInsets toWindowInsets = windowInsetsCompat.toWindowInsets();
        if (toWindowInsets != null) {
            WindowInsets dispatchApplyWindowInsets = Api20Impl.dispatchApplyWindowInsets(view, toWindowInsets);
            if (!dispatchApplyWindowInsets.equals(toWindowInsets)) {
                return WindowInsetsCompat.toWindowInsetsCompat(dispatchApplyWindowInsets, view);
            }
        }
        return windowInsetsCompat;
    }

    public static int generateViewId() {
        return Api17Impl.generateViewId();
    }

    private static List getActionList(View view) {
        ArrayList arrayList = (ArrayList) view.getTag(R.id.tag_accessibility_actions);
        if (arrayList != null) {
            return arrayList;
        }
        List arrayList2 = new ArrayList();
        view.setTag(R.id.tag_accessibility_actions, arrayList2);
        return arrayList2;
    }

    public static ColorStateList getBackgroundTintList(View view) {
        return Api21Impl.getBackgroundTintList(view);
    }

    public static Mode getBackgroundTintMode(View view) {
        return Api21Impl.getBackgroundTintMode(view);
    }

    public static Display getDisplay(View view) {
        return Api17Impl.getDisplay(view);
    }

    public static float getElevation(View view) {
        return Api21Impl.getElevation(view);
    }

    public static int getImportantForAccessibility(View view) {
        return Api16Impl.getImportantForAccessibility(view);
    }

    public static int getImportantForAutofill(View view) {
        return Api26Impl.getImportantForAutofill(view);
    }

    public static int getLayoutDirection(View view) {
        return Api17Impl.getLayoutDirection(view);
    }

    public static int getMinimumHeight(View view) {
        return Api16Impl.getMinimumHeight(view);
    }

    public static int getMinimumWidth(View view) {
        return Api16Impl.getMinimumWidth(view);
    }

    public static String[] getOnReceiveContentMimeTypes(View view) {
        if (VERSION.SDK_INT >= 31) {
            return Api31Impl.getReceiveContentMimeTypes(view);
        }
        return (String[]) view.getTag(R.id.tag_on_receive_content_mime_types);
    }

    public static int getPaddingEnd(View view) {
        return Api17Impl.getPaddingEnd(view);
    }

    public static int getPaddingStart(View view) {
        return Api17Impl.getPaddingStart(view);
    }

    public static String getTransitionName(View view) {
        return Api21Impl.getTransitionName(view);
    }

    @Deprecated
    public static int getWindowSystemUiVisibility(View view) {
        return Api16Impl.getWindowSystemUiVisibility(view);
    }

    public static boolean hasOnClickListeners(View view) {
        return Api15Impl.hasOnClickListeners(view);
    }

    public static boolean hasTransientState(View view) {
        return Api16Impl.hasTransientState(view);
    }

    public static boolean isAttachedToWindow(View view) {
        return Api19Impl.isAttachedToWindow(view);
    }

    public static boolean isLaidOut(View view) {
        return Api19Impl.isLaidOut(view);
    }

    static void notifyViewAccessibilityStateChangedIfNeeded$ar$ds(View view) {
        if (((AccessibilityManager) view.getContext().getSystemService("accessibility")).isEnabled()) {
            int i;
            Object obj = (Api28Impl.getAccessibilityPaneTitle(view) == null || view.getVisibility() != 0) ? null : 1;
            if (Api19Impl.getAccessibilityLiveRegion(view) == 0) {
                if (obj == null) {
                    if (view.getParent() != null) {
                        try {
                            Api19Impl.notifySubtreeAccessibilityStateChanged(view.getParent(), view, view, 0);
                            return;
                        } catch (Throwable e) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(view.getParent().getClass().getSimpleName());
                            stringBuilder.append(" does not fully implement ViewParent");
                            Log.e("ViewCompat", stringBuilder.toString(), e);
                            return;
                        }
                    }
                    return;
                }
            }
            if (1 != obj) {
                i = 2048;
            } else {
                i = 32;
            }
            AccessibilityEvent obtain = AccessibilityEvent.obtain();
            obtain.setEventType(i);
            Api19Impl.setContentChangeTypes(obtain, 0);
            if (obj != null) {
                obtain.getText().add(Api28Impl.getAccessibilityPaneTitle(view));
                if (Api16Impl.getImportantForAccessibility(view) == 0) {
                    Api16Impl.setImportantForAccessibility(view, 1);
                }
                for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
                    if (Api16Impl.getImportantForAccessibility((View) parent) == 4) {
                        Api16Impl.setImportantForAccessibility(view, 2);
                        break;
                    }
                }
            }
            view.sendAccessibilityEventUnchecked(obtain);
        }
    }

    public static void offsetLeftAndRight(View view, int i) {
        view.offsetLeftAndRight(i);
    }

    public static void offsetTopAndBottom(View view, int i) {
        view.offsetTopAndBottom(i);
    }

    public static WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
        WindowInsets toWindowInsets = windowInsetsCompat.toWindowInsets();
        if (toWindowInsets != null) {
            WindowInsets onApplyWindowInsets = Api20Impl.onApplyWindowInsets(view, toWindowInsets);
            if (!onApplyWindowInsets.equals(toWindowInsets)) {
                return WindowInsetsCompat.toWindowInsetsCompat(onApplyWindowInsets, view);
            }
        }
        return windowInsetsCompat;
    }

    public static ContentInfoCompat performReceiveContent(View view, ContentInfoCompat contentInfoCompat) {
        String str = "ViewCompat";
        if (Log.isLoggable(str, 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("performReceiveContent: ");
            stringBuilder.append(contentInfoCompat);
            stringBuilder.append(", view=");
            stringBuilder.append(view.getClass().getSimpleName());
            stringBuilder.append("[");
            stringBuilder.append(view.getId());
            stringBuilder.append("]");
            Log.d(str, stringBuilder.toString());
        }
        if (VERSION.SDK_INT >= 31) {
            return Api31Impl.performReceiveContent(view, contentInfoCompat);
        }
        if (((TextViewOnReceiveContentListener) view.getTag(R.id.tag_on_receive_content_listener)) == null) {
            return TextViewOnReceiveContentListener.onReceiveContent$ar$ds(view, contentInfoCompat);
        }
        contentInfoCompat = TextViewOnReceiveContentListener.onReceiveContent$ar$ds(view, contentInfoCompat);
        if (contentInfoCompat == null) {
            return null;
        }
        return TextViewOnReceiveContentListener.onReceiveContent$ar$ds(view, contentInfoCompat);
    }

    public static void postInvalidateOnAnimation(View view) {
        Api16Impl.postInvalidateOnAnimation(view);
    }

    public static void postOnAnimation(View view, Runnable runnable) {
        Api16Impl.postOnAnimation(view, runnable);
    }

    public static void postOnAnimationDelayed(View view, Runnable runnable, long j) {
        Api16Impl.postOnAnimationDelayed(view, runnable, j);
    }

    public static void removeAccessibilityAction(View view, int i) {
        ViewCompat.removeActionWithId(i, view);
        ViewCompat.notifyViewAccessibilityStateChangedIfNeeded$ar$ds(view);
    }

    private static void removeActionWithId(int i, View view) {
        List actionList = ViewCompat.getActionList(view);
        for (int i2 = 0; i2 < actionList.size(); i2++) {
            if (((AccessibilityActionCompat) actionList.get(i2)).getId() == i) {
                actionList.remove(i2);
                return;
            }
        }
    }

    public static void requestApplyInsets(View view) {
        Api20Impl.requestApplyInsets(view);
    }

    public static void saveAttributeDataForStyleable(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i, int i2) {
        Api29Impl.saveAttributeDataForStyleable(view, context, iArr, attributeSet, typedArray, i, i2);
    }

    public static void setBackground(View view, Drawable drawable) {
        Api16Impl.setBackground(view, drawable);
    }

    public static void setBackgroundTintList(View view, ColorStateList colorStateList) {
        Api21Impl.setBackgroundTintList(view, colorStateList);
    }

    public static void setBackgroundTintMode(View view, Mode mode) {
        Api21Impl.setBackgroundTintMode(view, mode);
    }

    public static void setElevation(View view, float f) {
        Api21Impl.setElevation(view, f);
    }

    public static void setImportantForAccessibility(View view, int i) {
        Api16Impl.setImportantForAccessibility(view, i);
    }

    public static void setImportantForAutofill$ar$ds(View view) {
        Api26Impl.setImportantForAutofill(view, 8);
    }

    public static void setOnApplyWindowInsetsListener(View view, OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        Api21Impl.setOnApplyWindowInsetsListener(view, onApplyWindowInsetsListener);
    }

    public static void setScrollIndicators$ar$ds(View view, int i) {
        Api23Impl.setScrollIndicators(view, i, 3);
    }

    public static void setTransitionName(View view, String str) {
        Api21Impl.setTransitionName(view, str);
    }

    public static void stopNestedScroll(View view) {
        Api21Impl.stopNestedScroll(view);
    }

    public static AccessibilityDelegateCompat getAccessibilityDelegate(View view) {
        AccessibilityDelegate accessibilityDelegate = Api29Impl.getAccessibilityDelegate(view);
        if (accessibilityDelegate == null) {
            return null;
        }
        if (accessibilityDelegate instanceof AccessibilityDelegateAdapter) {
            return ((AccessibilityDelegateAdapter) accessibilityDelegate).mCompat;
        }
        return new AccessibilityDelegateCompat(accessibilityDelegate);
    }

    public static CharSequence getAccessibilityPaneTitle(View view) {
        return Api28Impl.getAccessibilityPaneTitle(view);
    }

    public static WindowInsetsCompat getRootWindowInsets(View view) {
        WindowInsets rootWindowInsets = view.getRootWindowInsets();
        if (rootWindowInsets == null) {
            return null;
        }
        WindowInsetsCompat toWindowInsetsCompat = WindowInsetsCompat.toWindowInsetsCompat(rootWindowInsets);
        toWindowInsetsCompat.setRootWindowInsets(toWindowInsetsCompat);
        toWindowInsetsCompat.copyRootViewBounds(view.getRootView());
        return toWindowInsetsCompat;
    }

    public static boolean isScreenReaderFocusable(View view) {
        return Boolean.valueOf(Api28Impl.isScreenReaderFocusable(view)).booleanValue();
    }

    public static void replaceAccessibilityAction$ar$ds(View view, AccessibilityActionCompat accessibilityActionCompat, AccessibilityViewCommand accessibilityViewCommand) {
        if (accessibilityViewCommand != null) {
            AccessibilityActionCompat accessibilityActionCompat2 = new AccessibilityActionCompat(null, accessibilityActionCompat.mId, accessibilityViewCommand, accessibilityActionCompat.mViewCommandArgumentClass);
            AccessibilityDelegateCompat accessibilityDelegate = ViewCompat.getAccessibilityDelegate(view);
            if (accessibilityDelegate == null) {
                accessibilityDelegate = new AccessibilityDelegateCompat();
            }
            ViewCompat.setAccessibilityDelegate(view, accessibilityDelegate);
            ViewCompat.removeActionWithId(accessibilityActionCompat2.getId(), view);
            ViewCompat.getActionList(view).add(accessibilityActionCompat2);
            ViewCompat.notifyViewAccessibilityStateChangedIfNeeded$ar$ds(view);
            return;
        }
        ViewCompat.removeAccessibilityAction(view, accessibilityActionCompat.getId());
    }

    public static void setAccessibilityDelegate(View view, AccessibilityDelegateCompat accessibilityDelegateCompat) {
        AccessibilityDelegate accessibilityDelegate;
        if (accessibilityDelegateCompat == null && (Api29Impl.getAccessibilityDelegate(view) instanceof AccessibilityDelegateAdapter)) {
            accessibilityDelegateCompat = new AccessibilityDelegateCompat();
        }
        if (accessibilityDelegateCompat == null) {
            accessibilityDelegate = null;
        } else {
            accessibilityDelegate = accessibilityDelegateCompat.mBridge;
        }
        view.setAccessibilityDelegate(accessibilityDelegate);
    }

    public static void setStateDescription(View view, CharSequence charSequence) {
        Api30Impl.setStateDescription(view, charSequence);
    }
}
