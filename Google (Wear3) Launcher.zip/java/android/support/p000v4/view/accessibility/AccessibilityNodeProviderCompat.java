package android.support.p000v4.view.accessibility;

import android.os.Build.VERSION;

/* compiled from: PG */
/* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompat */
public final class AccessibilityNodeProviderCompat {
    public final Object mProvider;

    public AccessibilityNodeProviderCompat() {
        int i = VERSION.SDK_INT;
        throw null;
    }

    public AccessibilityNodeProviderCompat(Object obj) {
        this.mProvider = obj;
    }
}
