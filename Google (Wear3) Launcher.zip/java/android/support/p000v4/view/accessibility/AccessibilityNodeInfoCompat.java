package android.support.p000v4.view.accessibility;

import android.graphics.Rect;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand.MoveAtGranularityArguments;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand.MoveHtmlArguments;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand.MoveWindowArguments;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand.ScrollToPositionArguments;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand.SetProgressArguments;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand.SetSelectionArguments;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand.SetTextArguments;
import android.text.SpannableString;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction;
import android.view.accessibility.AccessibilityNodeInfo.CollectionInfo;
import android.view.accessibility.AccessibilityNodeInfo.CollectionItemInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat */
public final class AccessibilityNodeInfoCompat {
    public final AccessibilityNodeInfo mInfo;

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityActionCompat */
    public final class AccessibilityActionCompat {
        public static final AccessibilityActionCompat ACTION_SCROLL_BACKWARD = new AccessibilityActionCompat(8192);
        public static final AccessibilityActionCompat ACTION_SCROLL_DOWN = new AccessibilityActionCompat(AccessibilityAction.ACTION_SCROLL_DOWN, 16908346, null, null);
        public static final AccessibilityActionCompat ACTION_SCROLL_FORWARD = new AccessibilityActionCompat(4096);
        public static final AccessibilityActionCompat ACTION_SCROLL_UP = new AccessibilityActionCompat(AccessibilityAction.ACTION_SCROLL_UP, 16908344, null, null);
        final Object mAction;
        public final AccessibilityViewCommand mCommand;
        public final int mId;
        public final Class mViewCommandArgumentClass;

        static {
            AccessibilityActionCompat accessibilityActionCompat = new AccessibilityActionCompat(1);
            accessibilityActionCompat = new AccessibilityActionCompat(2);
            accessibilityActionCompat = new AccessibilityActionCompat(4);
            accessibilityActionCompat = new AccessibilityActionCompat(8);
            accessibilityActionCompat = new AccessibilityActionCompat(16);
            accessibilityActionCompat = new AccessibilityActionCompat(32);
            accessibilityActionCompat = new AccessibilityActionCompat(64);
            accessibilityActionCompat = new AccessibilityActionCompat(128);
            accessibilityActionCompat = new AccessibilityActionCompat(256, MoveAtGranularityArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(512, MoveAtGranularityArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(1024, MoveHtmlArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(2048, MoveHtmlArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(16384);
            accessibilityActionCompat = new AccessibilityActionCompat(32768);
            accessibilityActionCompat = new AccessibilityActionCompat(65536);
            accessibilityActionCompat = new AccessibilityActionCompat(131072, SetSelectionArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(262144);
            accessibilityActionCompat = new AccessibilityActionCompat(524288);
            accessibilityActionCompat = new AccessibilityActionCompat(1048576);
            accessibilityActionCompat = new AccessibilityActionCompat(2097152, SetTextArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_SHOW_ON_SCREEN, 16908342, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_SCROLL_TO_POSITION, 16908343, null, ScrollToPositionArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_SCROLL_LEFT, 16908345, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_SCROLL_RIGHT, 16908347, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_PAGE_UP, 16908358, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_PAGE_DOWN, 16908359, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_PAGE_LEFT, 16908360, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_PAGE_RIGHT, 16908361, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_CONTEXT_CLICK, 16908348, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_SET_PROGRESS, 16908349, null, SetProgressArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_MOVE_WINDOW, 16908354, null, MoveWindowArguments.class);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_SHOW_TOOLTIP, 16908356, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_HIDE_TOOLTIP, 16908357, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_PRESS_AND_HOLD, 16908362, null, null);
            accessibilityActionCompat = new AccessibilityActionCompat(AccessibilityAction.ACTION_IME_ENTER, 16908372, null, null);
        }

        public AccessibilityActionCompat(int i) {
            this(null, i, null, null);
        }

        public final boolean equals(Object obj) {
            if (obj == null || !(obj instanceof AccessibilityActionCompat)) {
                return false;
            }
            if (this.mAction.equals(((AccessibilityActionCompat) obj).mAction)) {
                return true;
            }
            return false;
        }

        public final int getId() {
            return ((AccessibilityAction) this.mAction).getId();
        }

        public final CharSequence getLabel() {
            return ((AccessibilityAction) this.mAction).getLabel();
        }

        public final int hashCode() {
            return this.mAction.hashCode();
        }

        private AccessibilityActionCompat(int i, Class cls) {
            this(null, i, null, cls);
        }

        public AccessibilityActionCompat(Object obj, int i, AccessibilityViewCommand accessibilityViewCommand, Class cls) {
            this.mId = i;
            this.mCommand = accessibilityViewCommand;
            if (obj == null) {
                obj = new AccessibilityAction(i, null);
            }
            this.mAction = obj;
            this.mViewCommandArgumentClass = cls;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$CollectionInfoCompat */
    public final class CollectionInfoCompat {
        final Object mInfo;

        public CollectionInfoCompat(Object obj) {
            this.mInfo = obj;
        }

        public static CollectionInfoCompat obtain(int i, int i2, boolean z, int i3) {
            return new CollectionInfoCompat(CollectionInfo.obtain(i, i2, z, i3));
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$CollectionItemInfoCompat */
    public final class CollectionItemInfoCompat {
        final Object mInfo;

        public CollectionItemInfoCompat(Object obj) {
            this.mInfo = obj;
        }

        public static CollectionItemInfoCompat obtain$ar$ds(int i, int i2, int i3, int i4) {
            return new CollectionItemInfoCompat(CollectionItemInfo.obtain(i, i2, i3, i4, false, false));
        }
    }

    private AccessibilityNodeInfoCompat(AccessibilityNodeInfo accessibilityNodeInfo) {
        this.mInfo = accessibilityNodeInfo;
    }

    private final List extrasIntList(String str) {
        List integerArrayList = this.mInfo.getExtras().getIntegerArrayList(str);
        if (integerArrayList != null) {
            return integerArrayList;
        }
        integerArrayList = new ArrayList();
        this.mInfo.getExtras().putIntegerArrayList(str, integerArrayList);
        return integerArrayList;
    }

    public static AccessibilityNodeInfoCompat wrap(AccessibilityNodeInfo accessibilityNodeInfo) {
        return new AccessibilityNodeInfoCompat(accessibilityNodeInfo);
    }

    public final void addAction(int i) {
        this.mInfo.addAction(i);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof AccessibilityNodeInfoCompat)) {
            return false;
        }
        AccessibilityNodeInfoCompat accessibilityNodeInfoCompat = (AccessibilityNodeInfoCompat) obj;
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        AccessibilityNodeInfo accessibilityNodeInfo2 = accessibilityNodeInfoCompat.mInfo;
        if (accessibilityNodeInfo == null) {
            if (accessibilityNodeInfo2 != null) {
                return false;
            }
        } else if (!accessibilityNodeInfo.equals(accessibilityNodeInfo2)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        AccessibilityNodeInfo accessibilityNodeInfo = this.mInfo;
        return accessibilityNodeInfo == null ? 0 : accessibilityNodeInfo.hashCode();
    }

    public final void removeAction$ar$ds(AccessibilityActionCompat accessibilityActionCompat) {
        this.mInfo.removeAction((AccessibilityAction) accessibilityActionCompat.mAction);
    }

    public final void setClassName(CharSequence charSequence) {
        this.mInfo.setClassName(charSequence);
    }

    public final void setCollectionInfo(Object obj) {
        this.mInfo.setCollectionInfo((CollectionInfo) ((CollectionInfoCompat) obj).mInfo);
    }

    public final void setCollectionItemInfo(Object obj) {
        this.mInfo.setCollectionItemInfo((CollectionItemInfo) ((CollectionItemInfoCompat) obj).mInfo);
    }

    public final void setScrollable(boolean z) {
        this.mInfo.setScrollable(z);
    }

    public final String toString() {
        CharSequence text;
        List extrasIntList;
        List extrasIntList2;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        Rect rect = new Rect();
        this.mInfo.getBoundsInParent(rect);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("; boundsInParent: ");
        stringBuilder2.append(rect);
        stringBuilder.append(stringBuilder2.toString());
        this.mInfo.getBoundsInScreen(rect);
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("; boundsInScreen: ");
        stringBuilder2.append(rect);
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append("; packageName: ");
        stringBuilder.append(this.mInfo.getPackageName());
        stringBuilder.append("; className: ");
        stringBuilder.append(this.mInfo.getClassName());
        stringBuilder.append("; text: ");
        String str = "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY";
        int i = 0;
        if (extrasIntList(str).isEmpty()) {
            text = this.mInfo.getText();
        } else {
            extrasIntList = extrasIntList(str);
            extrasIntList2 = extrasIntList("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
            List extrasIntList3 = extrasIntList("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
            List extrasIntList4 = extrasIntList("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
            text = new SpannableString(TextUtils.substring(this.mInfo.getText(), 0, this.mInfo.getText().length()));
            for (int i2 = 0; i2 < extrasIntList.size(); i2++) {
                text.setSpan(new AccessibilityClickableSpanCompat(((Integer) extrasIntList4.get(i2)).intValue(), this, this.mInfo.getExtras().getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY")), ((Integer) extrasIntList.get(i2)).intValue(), ((Integer) extrasIntList2.get(i2)).intValue(), ((Integer) extrasIntList3.get(i2)).intValue());
            }
        }
        stringBuilder.append(text);
        stringBuilder.append("; contentDescription: ");
        stringBuilder.append(this.mInfo.getContentDescription());
        stringBuilder.append("; viewId: ");
        stringBuilder.append(this.mInfo.getViewIdResourceName());
        stringBuilder.append("; checkable: ");
        stringBuilder.append(this.mInfo.isCheckable());
        stringBuilder.append("; checked: ");
        stringBuilder.append(this.mInfo.isChecked());
        stringBuilder.append("; focusable: ");
        stringBuilder.append(this.mInfo.isFocusable());
        stringBuilder.append("; focused: ");
        stringBuilder.append(this.mInfo.isFocused());
        stringBuilder.append("; selected: ");
        stringBuilder.append(this.mInfo.isSelected());
        stringBuilder.append("; clickable: ");
        stringBuilder.append(this.mInfo.isClickable());
        stringBuilder.append("; longClickable: ");
        stringBuilder.append(this.mInfo.isLongClickable());
        stringBuilder.append("; enabled: ");
        stringBuilder.append(this.mInfo.isEnabled());
        stringBuilder.append("; password: ");
        stringBuilder.append(this.mInfo.isPassword());
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("; scrollable: ");
        stringBuilder3.append(this.mInfo.isScrollable());
        stringBuilder.append(stringBuilder3.toString());
        stringBuilder.append("; [");
        extrasIntList = this.mInfo.getActionList();
        if (extrasIntList != null) {
            extrasIntList2 = new ArrayList();
            int size = extrasIntList.size();
            for (int i3 = 0; i3 < size; i3++) {
                extrasIntList2.add(new AccessibilityActionCompat(extrasIntList.get(i3), 0, null, null));
            }
        } else {
            extrasIntList2 = Collections.emptyList();
        }
        while (i < extrasIntList2.size()) {
            String str2;
            AccessibilityActionCompat accessibilityActionCompat = (AccessibilityActionCompat) extrasIntList2.get(i);
            String str3 = "ACTION_UNKNOWN";
            switch (accessibilityActionCompat.getId()) {
                case 1:
                    str2 = "ACTION_FOCUS";
                    break;
                case 2:
                    str2 = "ACTION_CLEAR_FOCUS";
                    break;
                case 4:
                    str2 = "ACTION_SELECT";
                    break;
                case 8:
                    str2 = "ACTION_CLEAR_SELECTION";
                    break;
                case 16:
                    str2 = "ACTION_CLICK";
                    break;
                case 32:
                    str2 = "ACTION_LONG_CLICK";
                    break;
                case 64:
                    str2 = "ACTION_ACCESSIBILITY_FOCUS";
                    break;
                case 128:
                    str2 = "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
                    break;
                case 256:
                    str2 = "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
                    break;
                case 512:
                    str2 = "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
                    break;
                case 1024:
                    str2 = "ACTION_NEXT_HTML_ELEMENT";
                    break;
                case 2048:
                    str2 = "ACTION_PREVIOUS_HTML_ELEMENT";
                    break;
                case 4096:
                    str2 = "ACTION_SCROLL_FORWARD";
                    break;
                case 8192:
                    str2 = "ACTION_SCROLL_BACKWARD";
                    break;
                case 16384:
                    str2 = "ACTION_COPY";
                    break;
                case 32768:
                    str2 = "ACTION_PASTE";
                    break;
                case 65536:
                    str2 = "ACTION_CUT";
                    break;
                case 131072:
                    str2 = "ACTION_SET_SELECTION";
                    break;
                case 262144:
                    str2 = "ACTION_EXPAND";
                    break;
                case 524288:
                    str2 = "ACTION_COLLAPSE";
                    break;
                case 2097152:
                    str2 = "ACTION_SET_TEXT";
                    break;
                case 16908342:
                    str2 = "ACTION_SHOW_ON_SCREEN";
                    break;
                case 16908343:
                    str2 = "ACTION_SCROLL_TO_POSITION";
                    break;
                case 16908344:
                    str2 = "ACTION_SCROLL_UP";
                    break;
                case 16908345:
                    str2 = "ACTION_SCROLL_LEFT";
                    break;
                case 16908346:
                    str2 = "ACTION_SCROLL_DOWN";
                    break;
                case 16908347:
                    str2 = "ACTION_SCROLL_RIGHT";
                    break;
                case 16908348:
                    str2 = "ACTION_CONTEXT_CLICK";
                    break;
                case 16908349:
                    str2 = "ACTION_SET_PROGRESS";
                    break;
                case 16908354:
                    str2 = "ACTION_MOVE_WINDOW";
                    break;
                case 16908356:
                    str2 = "ACTION_SHOW_TOOLTIP";
                    break;
                case 16908357:
                    str2 = "ACTION_HIDE_TOOLTIP";
                    break;
                case 16908358:
                    str2 = "ACTION_PAGE_UP";
                    break;
                case 16908359:
                    str2 = "ACTION_PAGE_DOWN";
                    break;
                case 16908360:
                    str2 = "ACTION_PAGE_LEFT";
                    break;
                case 16908361:
                    str2 = "ACTION_PAGE_RIGHT";
                    break;
                case 16908362:
                    str2 = "ACTION_PRESS_AND_HOLD";
                    break;
                case 16908372:
                    str2 = "ACTION_IME_ENTER";
                    break;
                default:
                    str2 = str3;
                    break;
            }
            if (str2.equals(str3) && accessibilityActionCompat.getLabel() != null) {
                str2 = accessibilityActionCompat.getLabel().toString();
            }
            stringBuilder.append(str2);
            if (i != extrasIntList2.size() - 1) {
                stringBuilder.append(", ");
            }
            i++;
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public final void addAction(AccessibilityActionCompat accessibilityActionCompat) {
        this.mInfo.addAction((AccessibilityAction) accessibilityActionCompat.mAction);
    }
}
