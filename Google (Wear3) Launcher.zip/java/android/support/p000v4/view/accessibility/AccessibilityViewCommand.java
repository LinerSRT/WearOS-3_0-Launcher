package android.support.p000v4.view.accessibility;

import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand */
public interface AccessibilityViewCommand {

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand$CommandArguments */
    public class CommandArguments {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand$MoveAtGranularityArguments */
    public final class MoveAtGranularityArguments extends CommandArguments {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand$MoveHtmlArguments */
    public final class MoveHtmlArguments extends CommandArguments {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand$MoveWindowArguments */
    public final class MoveWindowArguments extends CommandArguments {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand$ScrollToPositionArguments */
    public final class ScrollToPositionArguments extends CommandArguments {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand$SetProgressArguments */
    public final class SetProgressArguments extends CommandArguments {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand$SetSelectionArguments */
    public final class SetSelectionArguments extends CommandArguments {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityViewCommand$SetTextArguments */
    public final class SetTextArguments extends CommandArguments {
    }

    void perform$ar$ds(View view);
}
