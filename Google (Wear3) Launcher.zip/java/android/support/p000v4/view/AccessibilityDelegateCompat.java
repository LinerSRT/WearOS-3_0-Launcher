package android.support.p000v4.view;

import android.os.Bundle;
import android.support.p000v4.view.ViewCompat.Api28Impl;
import android.support.p000v4.view.ViewCompat.Api30Impl;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityActionCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompat;
import android.support.p000v4.view.accessibility.AccessibilityViewCommand.CommandArguments;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import com.google.android.wearable.sysui.R;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.view.AccessibilityDelegateCompat */
public class AccessibilityDelegateCompat {
    private static final AccessibilityDelegate DEFAULT_DELEGATE = new AccessibilityDelegate();
    public final AccessibilityDelegate mBridge;
    private final AccessibilityDelegate mOriginalDelegate;

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateAdapter */
    final class AccessibilityDelegateAdapter extends AccessibilityDelegate {
        final AccessibilityDelegateCompat mCompat;

        public AccessibilityDelegateAdapter(AccessibilityDelegateCompat accessibilityDelegateCompat) {
            this.mCompat = accessibilityDelegateCompat;
        }

        public final boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.mCompat.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
        }

        public final AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
            AccessibilityNodeProviderCompat accessibilityNodeProvider = this.mCompat.getAccessibilityNodeProvider(view);
            return accessibilityNodeProvider != null ? (AccessibilityNodeProvider) accessibilityNodeProvider.mProvider : null;
        }

        public final void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.mCompat.onInitializeAccessibilityEvent(view, accessibilityEvent);
        }

        public final void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            AccessibilityNodeInfoCompat wrap = AccessibilityNodeInfoCompat.wrap(accessibilityNodeInfo);
            wrap.mInfo.setScreenReaderFocusable(ViewCompat.isScreenReaderFocusable(view));
            wrap.mInfo.setHeading(Boolean.valueOf(Api28Impl.isAccessibilityHeading(view)).booleanValue());
            wrap.mInfo.setPaneTitle(ViewCompat.getAccessibilityPaneTitle(view));
            wrap.mInfo.setStateDescription(Api30Impl.getStateDescription(view));
            this.mCompat.onInitializeAccessibilityNodeInfo(view, wrap);
            accessibilityNodeInfo.getText();
            List actionList = AccessibilityDelegateCompat.getActionList(view);
            for (int i = 0; i < actionList.size(); i++) {
                wrap.addAction((AccessibilityActionCompat) actionList.get(i));
            }
        }

        public final void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.mCompat.onPopulateAccessibilityEvent(view, accessibilityEvent);
        }

        public final boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return this.mCompat.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
        }

        public final boolean performAccessibilityAction(View view, int i, Bundle bundle) {
            return this.mCompat.performAccessibilityAction(view, i, bundle);
        }

        public final void sendAccessibilityEvent(View view, int i) {
            this.mCompat.sendAccessibilityEvent(view, i);
        }

        public final void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
            this.mCompat.sendAccessibilityEventUnchecked(view, accessibilityEvent);
        }
    }

    public AccessibilityDelegateCompat() {
        this(DEFAULT_DELEGATE);
    }

    static List getActionList(View view) {
        List list = (List) view.getTag(R.id.tag_accessibility_actions);
        return list == null ? Collections.emptyList() : list;
    }

    public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        return this.mOriginalDelegate.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public AccessibilityNodeProviderCompat getAccessibilityNodeProvider(View view) {
        AccessibilityNodeProvider accessibilityNodeProvider = this.mOriginalDelegate.getAccessibilityNodeProvider(view);
        return accessibilityNodeProvider != null ? new AccessibilityNodeProviderCompat(accessibilityNodeProvider) : null;
    }

    public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        this.mOriginalDelegate.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
        this.mOriginalDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfoCompat.mInfo);
    }

    public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        this.mOriginalDelegate.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.mOriginalDelegate.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    public boolean performAccessibilityAction(View view, int i, Bundle bundle) {
        boolean z;
        List actionList = AccessibilityDelegateCompat.getActionList(view);
        boolean z2 = false;
        for (int i2 = 0; i2 < actionList.size(); i2++) {
            AccessibilityActionCompat accessibilityActionCompat = (AccessibilityActionCompat) actionList.get(i2);
            if (accessibilityActionCompat.getId() == i) {
                if (accessibilityActionCompat.mCommand != null) {
                    Class cls = accessibilityActionCompat.mViewCommandArgumentClass;
                    if (cls != null) {
                        try {
                            CommandArguments commandArguments = (CommandArguments) cls.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                        } catch (Throwable e) {
                            Class cls2 = accessibilityActionCompat.mViewCommandArgumentClass;
                            String name = cls2 == null ? "null" : cls2.getName();
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Failed to execute command with argument class ViewCommandArgument: ");
                            stringBuilder.append(name);
                            Log.e("A11yActionCompat", stringBuilder.toString(), e);
                        }
                    }
                    accessibilityActionCompat.mCommand.perform$ar$ds(view);
                    z = true;
                    if (z) {
                        z = this.mOriginalDelegate.performAccessibilityAction(view, i, bundle);
                    }
                    if (z || i != R.id.accessibility_action_clickable_span) {
                        return z;
                    }
                    i = bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1);
                    SparseArray sparseArray = (SparseArray) view.getTag(R.id.tag_accessibility_clickable_spans);
                    if (sparseArray != null) {
                        WeakReference weakReference = (WeakReference) sparseArray.get(i);
                        if (weakReference != null) {
                            ClickableSpan clickableSpan = (ClickableSpan) weakReference.get();
                            if (clickableSpan != null) {
                                ClickableSpan[] clickableSpanArr;
                                CharSequence text = view.createAccessibilityNodeInfo().getText();
                                if (text instanceof Spanned) {
                                    clickableSpanArr = (ClickableSpan[]) ((Spanned) text).getSpans(0, text.length(), ClickableSpan.class);
                                } else {
                                    clickableSpanArr = null;
                                }
                                int i3 = 0;
                                while (clickableSpanArr != null && i3 < clickableSpanArr.length) {
                                    if (clickableSpan.equals(clickableSpanArr[i3])) {
                                        clickableSpan.onClick(view);
                                        z2 = true;
                                        break;
                                    }
                                    i3++;
                                }
                            }
                        }
                    }
                    return z2;
                }
                z = false;
                if (z) {
                    z = this.mOriginalDelegate.performAccessibilityAction(view, i, bundle);
                }
                if (!z) {
                }
                return z;
            }
        }
        z = false;
        if (z) {
            z = this.mOriginalDelegate.performAccessibilityAction(view, i, bundle);
        }
        if (z) {
        }
        return z;
    }

    public void sendAccessibilityEvent(View view, int i) {
        this.mOriginalDelegate.sendAccessibilityEvent(view, i);
    }

    public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
        this.mOriginalDelegate.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }

    public AccessibilityDelegateCompat(AccessibilityDelegate accessibilityDelegate) {
        this.mOriginalDelegate = accessibilityDelegate;
        this.mBridge = new AccessibilityDelegateAdapter(this);
    }
}
