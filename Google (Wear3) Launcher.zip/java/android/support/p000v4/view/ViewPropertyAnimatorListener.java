package android.support.p000v4.view;

/* compiled from: PG */
/* renamed from: android.support.v4.view.ViewPropertyAnimatorListener */
public interface ViewPropertyAnimatorListener {
    void onAnimationCancel$ar$ds();

    void onAnimationEnd$ar$ds();

    void onAnimationStart$ar$ds();
}
