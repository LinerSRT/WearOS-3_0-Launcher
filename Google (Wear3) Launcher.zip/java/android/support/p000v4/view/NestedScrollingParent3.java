package android.support.p000v4.view;

import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v4.view.NestedScrollingParent3 */
public interface NestedScrollingParent3 extends NestedScrollingParent2 {
    void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5, int[] iArr);
}
