package android.support.p000v4.view;

import android.content.Context;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;

/* compiled from: PG */
/* renamed from: android.support.v4.view.GestureDetectorCompat */
public final class GestureDetectorCompat {
    private final GestureDetectorCompatImplJellybeanMr2 mImpl$ar$class_merging;

    /* compiled from: PG */
    /* renamed from: android.support.v4.view.GestureDetectorCompat$GestureDetectorCompatImplJellybeanMr2 */
    final class GestureDetectorCompatImplJellybeanMr2 {
        public final GestureDetector mDetector;

        public GestureDetectorCompatImplJellybeanMr2(Context context, OnGestureListener onGestureListener) {
            this.mDetector = new GestureDetector(context, onGestureListener, null);
        }
    }

    public final void onTouchEvent$ar$ds(MotionEvent motionEvent) {
        this.mImpl$ar$class_merging.mDetector.onTouchEvent(motionEvent);
    }

    public GestureDetectorCompat(Context context, OnGestureListener onGestureListener) {
        this.mImpl$ar$class_merging = new GestureDetectorCompatImplJellybeanMr2(context, onGestureListener);
    }
}
