package android.support.p000v4.view;

import android.support.p002v7.view.menu.MenuItemImpl.PG;
import android.util.Log;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v4.view.ActionProvider */
public abstract class ActionProvider {
    public PG mVisibilityListener$ar$class_merging;

    public boolean hasSubMenu() {
        throw null;
    }

    public boolean isVisible() {
        return true;
    }

    public abstract View onCreateActionView();

    public View onCreateActionView(MenuItem menuItem) {
        return onCreateActionView();
    }

    public boolean onPerformDefaultAction() {
        throw null;
    }

    public void onPrepareSubMenu(SubMenu subMenu) {
        throw null;
    }

    public boolean overridesItemVisibility() {
        return false;
    }

    public void setVisibilityListener$ar$class_merging(PG pg) {
        if (this.mVisibilityListener$ar$class_merging != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this ");
            stringBuilder.append(getClass().getSimpleName());
            stringBuilder.append(" instance while it is still in use somewhere else?");
            Log.w("ActionProvider(support)", stringBuilder.toString());
        }
        this.mVisibilityListener$ar$class_merging = pg;
    }
}
