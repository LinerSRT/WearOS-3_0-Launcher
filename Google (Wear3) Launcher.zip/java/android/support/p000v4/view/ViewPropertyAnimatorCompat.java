package android.support.p000v4.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.support.v4.view.ViewPropertyAnimatorCompat.C00762;
import android.support.v7.app.WindowDecorActionBar.C00853;
import android.view.View;
import java.lang.ref.WeakReference;

/* compiled from: PG */
/* renamed from: android.support.v4.view.ViewPropertyAnimatorCompat */
public final class ViewPropertyAnimatorCompat {
    public final WeakReference mView;

    /* renamed from: android.support.v4.view.ViewPropertyAnimatorCompat$1 */
    final class PG extends AnimatorListenerAdapter {
        final /* synthetic */ ViewPropertyAnimatorListener val$listener;

        public PG(ViewPropertyAnimatorListener viewPropertyAnimatorListener) {
            this.val$listener = viewPropertyAnimatorListener;
        }

        public final void onAnimationCancel(Animator animator) {
            this.val$listener.onAnimationCancel$ar$ds();
        }

        public final void onAnimationEnd(Animator animator) {
            this.val$listener.onAnimationEnd$ar$ds();
        }

        public final void onAnimationStart(Animator animator) {
            this.val$listener.onAnimationStart$ar$ds();
        }
    }

    /* renamed from: android.support.v4.view.ViewPropertyAnimatorCompat$2 */
    final class C00762 implements AnimatorUpdateListener {
        final /* synthetic */ C00853 val$listener$ar$class_merging;

        public C00762(C00853 c00853) {
            this.val$listener$ar$class_merging = c00853;
        }

        public final void onAnimationUpdate(ValueAnimator valueAnimator) {
            ((View) this.val$listener$ar$class_merging.this$0.mContainerView.getParent()).invalidate();
        }
    }

    public ViewPropertyAnimatorCompat(View view) {
        this.mView = new WeakReference(view);
    }

    public final void alpha$ar$ds(float f) {
        View view = (View) this.mView.get();
        if (view != null) {
            view.animate().alpha(f);
        }
    }

    public final void cancel() {
        View view = (View) this.mView.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public final void setDuration$ar$ds(long j) {
        View view = (View) this.mView.get();
        if (view != null) {
            view.animate().setDuration(j);
        }
    }

    public final void setListener$ar$ds(ViewPropertyAnimatorListener viewPropertyAnimatorListener) {
        View view = (View) this.mView.get();
        if (view != null) {
            if (viewPropertyAnimatorListener != null) {
                view.animate().setListener(new PG(viewPropertyAnimatorListener));
                return;
            }
            view.animate().setListener(null);
        }
    }

    public final void setUpdateListener$ar$class_merging$ar$ds(C00853 c00853) {
        View view = (View) this.mView.get();
        if (view != null) {
            AnimatorUpdateListener c00762;
            if (c00853 != null) {
                c00762 = new C00762(c00853);
            } else {
                c00762 = null;
            }
            view.animate().setUpdateListener(c00762);
        }
    }

    public final void translationY$ar$ds(float f) {
        View view = (View) this.mView.get();
        if (view != null) {
            view.animate().translationY(f);
        }
    }
}
