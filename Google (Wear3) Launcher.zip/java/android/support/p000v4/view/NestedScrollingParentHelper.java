package android.support.p000v4.view;

/* compiled from: PG */
/* renamed from: android.support.v4.view.NestedScrollingParentHelper */
public final class NestedScrollingParentHelper {
    private int mNestedScrollAxesNonTouch;
    private int mNestedScrollAxesTouch;

    public final int getNestedScrollAxes() {
        return this.mNestedScrollAxesTouch | this.mNestedScrollAxesNonTouch;
    }

    public final void onNestedScrollAccepted$ar$ds(int i, int i2) {
        if (i2 == 1) {
            this.mNestedScrollAxesNonTouch = i;
        } else {
            this.mNestedScrollAxesTouch = i;
        }
    }

    public final void onNestedScrollAccepted$ar$ds$aeb476d8_0(int i) {
        onNestedScrollAccepted$ar$ds(i, 0);
    }

    public final void onStopNestedScroll$ar$ds(int i) {
        if (i == 1) {
            this.mNestedScrollAxesNonTouch = 0;
        } else {
            this.mNestedScrollAxesTouch = 0;
        }
    }
}
