package android.support.p000v4.view;

import android.view.View;
import android.view.ViewParent;

/* compiled from: PG */
/* renamed from: android.support.v4.view.NestedScrollingChildHelper */
public final class NestedScrollingChildHelper {
    public boolean mIsNestedScrollingEnabled;
    private ViewParent mNestedScrollingParentNonTouch;
    private ViewParent mNestedScrollingParentTouch;
    private int[] mTempNestedScrollConsumed;
    private final View mView;

    public NestedScrollingChildHelper(View view) {
        this.mView = view;
    }

    private final ViewParent getNestedScrollingParentForType(int i) {
        switch (i) {
            case 0:
                return this.mNestedScrollingParentTouch;
            default:
                return this.mNestedScrollingParentNonTouch;
        }
    }

    private final int[] getTempNestedScrollConsumed() {
        if (this.mTempNestedScrollConsumed == null) {
            this.mTempNestedScrollConsumed = new int[2];
        }
        return this.mTempNestedScrollConsumed;
    }

    private final void setNestedScrollingParentForType(int i, ViewParent viewParent) {
        switch (i) {
            case 0:
                this.mNestedScrollingParentTouch = viewParent;
                return;
            default:
                this.mNestedScrollingParentNonTouch = viewParent;
                return;
        }
    }

    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        if (this.mIsNestedScrollingEnabled) {
            ViewParent viewParent = this.mNestedScrollingParentTouch;
            if (viewParent != null) {
                return ViewParentCompat.onNestedFling(viewParent, this.mView, f, f2, z);
            }
        }
        return false;
    }

    public final boolean dispatchNestedPreFling(float f, float f2) {
        if (this.mIsNestedScrollingEnabled) {
            ViewParent viewParent = this.mNestedScrollingParentTouch;
            if (viewParent != null) {
                return ViewParentCompat.onNestedPreFling(viewParent, this.mView, f, f2);
            }
        }
        return false;
    }

    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        if (this.mIsNestedScrollingEnabled) {
            ViewParent nestedScrollingParentForType = getNestedScrollingParentForType(i3);
            if (nestedScrollingParentForType == null) {
                return false;
            }
            int i4;
            int i5;
            if (i != 0) {
                i4 = i;
            } else if (i2 != 0) {
                i4 = 0;
            } else if (iArr2 != null) {
                iArr2[0] = 0;
                iArr2[1] = 0;
            }
            if (iArr2 != null) {
                this.mView.getLocationInWindow(iArr2);
                i = iArr2[0];
                i5 = iArr2[1];
            } else {
                i = 0;
                i5 = 0;
            }
            if (iArr == null) {
                iArr = getTempNestedScrollConsumed();
            }
            iArr[0] = 0;
            iArr[1] = 0;
            ViewParentCompat.onNestedPreScroll(nestedScrollingParentForType, this.mView, i4, i2, iArr, i3);
            if (iArr2 != null) {
                this.mView.getLocationInWindow(iArr2);
                iArr2[0] = iArr2[0] - i;
                iArr2[1] = iArr2[1] - i5;
            }
            if (iArr[0] == 0) {
                if (iArr[1] == 0) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return dispatchNestedScrollInternal(i, i2, i3, i4, iArr, 0, null);
    }

    public final boolean dispatchNestedScrollInternal(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2) {
        int[] iArr3 = iArr;
        if (this.mIsNestedScrollingEnabled) {
            ViewParent nestedScrollingParentForType = getNestedScrollingParentForType(i5);
            if (nestedScrollingParentForType == null) {
                return false;
            }
            int i6;
            int i7;
            int i8;
            int i9;
            int i10;
            int[] iArr4;
            if (i != 0) {
                i6 = i;
                i7 = i2;
                i8 = i3;
            } else if (i2 != 0) {
                i7 = i2;
                i8 = i3;
                i6 = 0;
            } else if (i3 != 0) {
                i8 = i3;
                i6 = 0;
                i7 = 0;
            } else if (i4 != 0) {
                i6 = 0;
                i7 = 0;
                i8 = 0;
            } else if (iArr3 != null) {
                iArr3[0] = 0;
                iArr3[1] = 0;
            }
            if (iArr3 != null) {
                r0.mView.getLocationInWindow(iArr3);
                i9 = iArr3[0];
                i10 = iArr3[1];
            } else {
                i9 = 0;
                i10 = 0;
            }
            if (iArr2 == null) {
                int[] tempNestedScrollConsumed = getTempNestedScrollConsumed();
                tempNestedScrollConsumed[0] = 0;
                tempNestedScrollConsumed[1] = 0;
                iArr4 = tempNestedScrollConsumed;
            } else {
                iArr4 = iArr2;
            }
            ViewParentCompat.onNestedScroll(nestedScrollingParentForType, r0.mView, i6, i7, i8, i4, i5, iArr4);
            if (iArr3 != null) {
                r0.mView.getLocationInWindow(iArr3);
                iArr3[0] = iArr3[0] - i9;
                iArr3[1] = iArr3[1] - i10;
            }
            return true;
        }
        return false;
    }

    public final boolean hasNestedScrollingParent(int i) {
        return getNestedScrollingParentForType(i) != null;
    }

    public final void setNestedScrollingEnabled(boolean z) {
        if (this.mIsNestedScrollingEnabled) {
            ViewCompat.stopNestedScroll(this.mView);
        }
        this.mIsNestedScrollingEnabled = z;
    }

    public final boolean startNestedScroll(int i, int i2) {
        if (hasNestedScrollingParent(i2)) {
            return true;
        }
        if (this.mIsNestedScrollingEnabled) {
            View view = this.mView;
            for (ViewParent parent = this.mView.getParent(); parent != null; parent = parent.getParent()) {
                if (ViewParentCompat.onStartNestedScroll(parent, view, this.mView, i, i2)) {
                    setNestedScrollingParentForType(i2, parent);
                    ViewParentCompat.onNestedScrollAccepted(parent, view, this.mView, i, i2);
                    return true;
                }
                if (parent instanceof View) {
                    view = (View) parent;
                }
            }
        }
        return false;
    }

    public final void stopNestedScroll(int i) {
        ViewParent nestedScrollingParentForType = getNestedScrollingParentForType(i);
        if (nestedScrollingParentForType != null) {
            ViewParentCompat.onStopNestedScroll(nestedScrollingParentForType, this.mView, i);
            setNestedScrollingParentForType(i, null);
        }
    }
}
