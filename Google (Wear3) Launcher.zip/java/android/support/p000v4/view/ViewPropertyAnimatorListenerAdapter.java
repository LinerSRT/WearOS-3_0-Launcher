package android.support.p000v4.view;

/* compiled from: PG */
/* renamed from: android.support.v4.view.ViewPropertyAnimatorListenerAdapter */
public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
    public void onAnimationCancel$ar$ds() {
    }

    public void onAnimationEnd$ar$ds() {
    }

    public void onAnimationStart$ar$ds() {
    }
}
