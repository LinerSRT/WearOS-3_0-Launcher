package android.support.p000v4.content;

import android.content.LocusId;
import android.support.p000v4.util.Preconditions;

/* compiled from: PG */
/* renamed from: android.support.v4.content.LocusIdCompat */
public final class LocusIdCompat {
    public final String mId;

    public LocusIdCompat(String str) {
        Preconditions.checkStringNotEmpty$ar$ds(str);
        this.mId = str;
        LocusId locusId = new LocusId(str);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        LocusIdCompat locusIdCompat = (LocusIdCompat) obj;
        String str = this.mId;
        String str2 = locusIdCompat.mId;
        if (str == null) {
            return str2 == null;
        } else {
            return str.equals(str2);
        }
    }

    public final int hashCode() {
        String str = this.mId;
        return (str == null ? 0 : str.hashCode()) + 31;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("LocusIdCompat[");
        int length = this.mId.length();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(length);
        stringBuilder2.append("_chars");
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public static LocusIdCompat toLocusIdCompat(LocusId locusId) {
        if (locusId != null) {
            Object id = locusId.getId();
            Preconditions.checkStringNotEmpty$ar$ds(id);
            return new LocusIdCompat(id);
        }
        throw new NullPointerException("locusId cannot be null");
    }
}
