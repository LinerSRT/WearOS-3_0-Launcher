package android.support.p000v4.content.res;

import android.util.Base64;
import androidx.core.provider.FontRequest;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.FontResourcesParserCompat */
public final class FontResourcesParserCompat {

    /* compiled from: PG */
    /* renamed from: android.support.v4.content.res.FontResourcesParserCompat$FamilyResourceEntry */
    public interface FamilyResourceEntry {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.content.res.FontResourcesParserCompat$FontFamilyFilesResourceEntry */
    public final class FontFamilyFilesResourceEntry implements FamilyResourceEntry {
        public final FontFileResourceEntry[] mEntries;

        public FontFamilyFilesResourceEntry(FontFileResourceEntry[] fontFileResourceEntryArr) {
            this.mEntries = fontFileResourceEntryArr;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.content.res.FontResourcesParserCompat$FontFileResourceEntry */
    public final class FontFileResourceEntry {
        public final boolean mItalic;
        public final int mResourceId;
        public final int mTtcIndex;
        public final String mVariationSettings;
        public final int mWeight;

        public FontFileResourceEntry(int i, boolean z, String str, int i2, int i3) {
            this.mWeight = i;
            this.mItalic = z;
            this.mVariationSettings = str;
            this.mTtcIndex = i2;
            this.mResourceId = i3;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.content.res.FontResourcesParserCompat$ProviderResourceEntry */
    public final class ProviderResourceEntry implements FamilyResourceEntry {
        public final FontRequest mRequest;
        public final int mStrategy;
        public final String mSystemFontFamilyName;
        public final int mTimeoutMs;

        public ProviderResourceEntry(FontRequest fontRequest, int i, int i2, String str) {
            this.mRequest = fontRequest;
            this.mStrategy = i;
            this.mTimeoutMs = i2;
            this.mSystemFontFamilyName = str;
        }
    }

    public static void skip(XmlPullParser xmlPullParser) {
        int i = 1;
        while (i > 0) {
            switch (xmlPullParser.next()) {
                case 2:
                    i++;
                    break;
                case 3:
                    i--;
                    break;
                default:
                    break;
            }
        }
    }

    public static List toByteArrayList(String[] strArr) {
        List arrayList = new ArrayList();
        for (String decode : strArr) {
            arrayList.add(Base64.decode(decode, 0));
        }
        return arrayList;
    }
}
