package android.support.p000v4.content.res;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.Typeface.CustomFallbackBuilder;
import android.graphics.fonts.Font;
import android.graphics.fonts.Font.Builder;
import android.graphics.fonts.FontFamily;
import android.os.Handler;
import android.os.Looper;
import android.support.compat.R$styleable;
import android.support.p000v4.content.res.FontResourcesParserCompat.FamilyResourceEntry;
import android.support.p000v4.content.res.FontResourcesParserCompat.FontFamilyFilesResourceEntry;
import android.support.p000v4.content.res.FontResourcesParserCompat.FontFileResourceEntry;
import android.support.p000v4.content.res.FontResourcesParserCompat.ProviderResourceEntry;
import android.support.p000v4.graphics.TypefaceCompat;
import android.support.v4.content.res.ResourcesCompat.FontCallback.C00752;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import androidx.core.provider.FontRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.ResourcesCompat */
public final class ResourcesCompat {

    /* compiled from: PG */
    /* renamed from: android.support.v4.content.res.ResourcesCompat$FontCallback */
    public abstract class FontCallback {

        /* renamed from: android.support.v4.content.res.ResourcesCompat$FontCallback$2 */
        final class C00752 implements Runnable {
            public final void run() {
            }
        }

        public static final void callbackFailAsync$ar$ds$f10018_0() {
            FontCallback.getHandler$ar$ds().post(new C00752());
        }

        public static Handler getHandler$ar$ds() {
            return new Handler(Looper.getMainLooper());
        }

        public final void callbackSuccessAsync$ar$ds(final Typeface typeface) {
            FontCallback.getHandler$ar$ds().post(new Runnable() {
                public final void run() {
                    FontCallback.this.onFontRetrieved(typeface);
                }
            });
        }

        public abstract void onFontRetrieved(Typeface typeface);
    }

    static {
        ThreadLocal threadLocal = new ThreadLocal();
        WeakHashMap weakHashMap = new WeakHashMap(0);
    }

    public static int getColor$ar$ds(Resources resources, int i) {
        return resources.getColor(i, null);
    }

    public static Typeface getFont(Context context, int i, TypedValue typedValue, int i2, FontCallback fontCallback) {
        if (context.isRestricted()) {
            return null;
        }
        Resources resources = context.getResources();
        resources.getValue(i, typedValue, true);
        return ResourcesCompat.loadFont$ar$ds(context, resources, typedValue, i, i2, fontCallback);
    }

    private static Typeface loadFont$ar$ds(Context context, Resources resources, TypedValue typedValue, int i, int i2, FontCallback fontCallback) {
        String str;
        Throwable th;
        String str2;
        StringBuilder stringBuilder;
        Resources resources2 = resources;
        TypedValue typedValue2 = typedValue;
        int i3 = i;
        int i4 = i2;
        FontCallback fontCallback2 = fontCallback;
        String str3 = "font-family";
        String str4 = "ResourcesCompat";
        if (typedValue2.string != null) {
            String charSequence = typedValue2.string.toString();
            if (charSequence.startsWith("res/")) {
                Typeface typeface = (Typeface) TypefaceCompat.sTypefaceCache.get(TypefaceCompat.createResourceUid(resources2, i3, i4));
                if (typeface == null) {
                    try {
                        if (charSequence.toLowerCase().endsWith(".xml")) {
                            int next;
                            FamilyResourceEntry familyResourceEntry;
                            XmlPullParser xml = resources2.getXml(i3);
                            while (true) {
                                next = xml.next();
                                if (next == 2) {
                                    break;
                                } else if (next == 1) {
                                    throw new XmlPullParserException("No start tag found");
                                }
                            }
                            xml.require(2, null, str3);
                            if (xml.getName().equals(str3)) {
                                TypedArray obtainAttributes = resources2.obtainAttributes(Xml.asAttributeSet(xml), R$styleable.FontFamily);
                                String string = obtainAttributes.getString(0);
                                String string2 = obtainAttributes.getString(4);
                                String string3 = obtainAttributes.getString(5);
                                int resourceId = obtainAttributes.getResourceId(1, 0);
                                int integer = obtainAttributes.getInteger(2, 1);
                                int integer2 = obtainAttributes.getInteger(3, 500);
                                String string4 = obtainAttributes.getString(6);
                                obtainAttributes.recycle();
                                if (string == null || string2 == null || string3 == null) {
                                    str = charSequence;
                                    List arrayList = new ArrayList();
                                    while (xml.next() != 3) {
                                        if (xml.getEventType() == 2) {
                                            if (xml.getName().equals("font")) {
                                                boolean z;
                                                int i5;
                                                TypedArray obtainAttributes2 = resources2.obtainAttributes(Xml.asAttributeSet(xml), R$styleable.FontFamilyFont);
                                                integer2 = 8;
                                                if (true != obtainAttributes2.hasValue(8)) {
                                                    integer2 = 1;
                                                }
                                                int i6 = obtainAttributes2.getInt(integer2, 400);
                                                if (true != obtainAttributes2.hasValue(6)) {
                                                    integer2 = 2;
                                                } else {
                                                    integer2 = 6;
                                                }
                                                if (obtainAttributes2.getInt(integer2, 0) == 1) {
                                                    z = true;
                                                } else {
                                                    z = false;
                                                }
                                                integer2 = 9;
                                                if (true != obtainAttributes2.hasValue(9)) {
                                                    integer2 = 3;
                                                }
                                                int i7 = 7;
                                                if (true != obtainAttributes2.hasValue(7)) {
                                                    i7 = 4;
                                                }
                                                String string5 = obtainAttributes2.getString(i7);
                                                int i8 = obtainAttributes2.getInt(integer2, 0);
                                                if (true != obtainAttributes2.hasValue(5)) {
                                                    i5 = 0;
                                                } else {
                                                    i5 = 5;
                                                }
                                                int resourceId2 = obtainAttributes2.getResourceId(i5, 0);
                                                obtainAttributes2.getString(i5);
                                                obtainAttributes2.recycle();
                                                while (xml.next() != 3) {
                                                    FontResourcesParserCompat.skip(xml);
                                                }
                                                arrayList.add(new FontFileResourceEntry(i6, z, string5, i8, resourceId2));
                                            } else {
                                                FontResourcesParserCompat.skip(xml);
                                            }
                                        }
                                    }
                                    if (arrayList.isEmpty()) {
                                        familyResourceEntry = null;
                                    } else {
                                        familyResourceEntry = new FontFamilyFilesResourceEntry((FontFileResourceEntry[]) arrayList.toArray(new FontFileResourceEntry[arrayList.size()]));
                                    }
                                } else {
                                    List emptyList;
                                    while (xml.next() != 3) {
                                        FontResourcesParserCompat.skip(xml);
                                    }
                                    if (resourceId == 0) {
                                        emptyList = Collections.emptyList();
                                        str = charSequence;
                                    } else {
                                        obtainAttributes = resources2.obtainTypedArray(resourceId);
                                        try {
                                            if (obtainAttributes.length() == 0) {
                                                emptyList = Collections.emptyList();
                                                obtainAttributes.recycle();
                                                str = charSequence;
                                            } else {
                                                emptyList = new ArrayList();
                                                str = charSequence;
                                                try {
                                                    if (obtainAttributes.getType(0) == 1) {
                                                        for (next = 0; next < obtainAttributes.length(); next++) {
                                                            resourceId = obtainAttributes.getResourceId(next, 0);
                                                            if (resourceId != 0) {
                                                                emptyList.add(FontResourcesParserCompat.toByteArrayList(resources2.getStringArray(resourceId)));
                                                            }
                                                        }
                                                    } else {
                                                        emptyList.add(FontResourcesParserCompat.toByteArrayList(resources2.getStringArray(resourceId)));
                                                    }
                                                } catch (Throwable th2) {
                                                    th = th2;
                                                    obtainAttributes.recycle();
                                                    throw th;
                                                }
                                                try {
                                                    obtainAttributes.recycle();
                                                } catch (XmlPullParserException e) {
                                                    th = e;
                                                    str2 = str;
                                                    stringBuilder = new StringBuilder();
                                                    stringBuilder.append("Failed to parse xml resource ");
                                                    stringBuilder.append(str2);
                                                    Log.e(str4, stringBuilder.toString(), th);
                                                    FontCallback.callbackFailAsync$ar$ds$f10018_0();
                                                    return null;
                                                } catch (IOException e2) {
                                                    th = e2;
                                                    stringBuilder = new StringBuilder();
                                                    stringBuilder.append("Failed to read xml resource ");
                                                    stringBuilder.append(str);
                                                    Log.e(str4, stringBuilder.toString(), th);
                                                    FontCallback.callbackFailAsync$ar$ds$f10018_0();
                                                    return null;
                                                }
                                            }
                                        } catch (Throwable th3) {
                                            th = th3;
                                            str = charSequence;
                                            obtainAttributes.recycle();
                                            throw th;
                                        }
                                    }
                                    familyResourceEntry = new ProviderResourceEntry(new FontRequest(string, string2, string3, emptyList), integer, integer2, string4);
                                }
                            } else {
                                str = charSequence;
                                FontResourcesParserCompat.skip(xml);
                                familyResourceEntry = null;
                            }
                            if (familyResourceEntry != null) {
                                return TypefaceCompat.createFromResourcesFamilyXml$ar$ds(context, familyResourceEntry, resources, i, i2, fontCallback);
                            }
                            Log.e(str4, "Failed to find font-family tag");
                            FontCallback.callbackFailAsync$ar$ds$f10018_0();
                            return null;
                        }
                        Typeface build;
                        str = charSequence;
                        try {
                            Font build2 = new Builder(resources2, i3).build();
                            build = new CustomFallbackBuilder(new FontFamily.Builder(build2).build()).setStyle(build2.getStyle()).build();
                        } catch (Exception e3) {
                            build = null;
                        }
                        if (build != null) {
                            TypefaceCompat.sTypefaceCache.put(TypefaceCompat.createResourceUid(resources2, i3, i4), build);
                        }
                        if (build != null) {
                            fontCallback2.callbackSuccessAsync$ar$ds(build);
                        } else {
                            FontCallback.callbackFailAsync$ar$ds$f10018_0();
                        }
                        return build;
                    } catch (XmlPullParserException e4) {
                        th = e4;
                        str2 = charSequence;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("Failed to parse xml resource ");
                        stringBuilder.append(str2);
                        Log.e(str4, stringBuilder.toString(), th);
                        FontCallback.callbackFailAsync$ar$ds$f10018_0();
                        return null;
                    } catch (IOException e5) {
                        th = e5;
                        str = charSequence;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("Failed to read xml resource ");
                        stringBuilder.append(str);
                        Log.e(str4, stringBuilder.toString(), th);
                        FontCallback.callbackFailAsync$ar$ds$f10018_0();
                        return null;
                    }
                }
                fontCallback2.callbackSuccessAsync$ar$ds(typeface);
                return typeface;
            }
            FontCallback.callbackFailAsync$ar$ds$f10018_0();
            return null;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Resource \"");
        stringBuilder2.append(resources2.getResourceName(i3));
        stringBuilder2.append("\" (");
        stringBuilder2.append(Integer.toHexString(i));
        stringBuilder2.append(") is not a Font: ");
        stringBuilder2.append(typedValue2);
        throw new NotFoundException(stringBuilder2.toString());
    }

    public static float getFloat(Resources resources, int i) {
        return resources.getFloat(i);
    }
}
