package android.support.p000v4.content.res;

import android.content.res.Resources.Theme;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.ResourcesCompat$ThemeCompat$ImplApi29 */
public class ResourcesCompat$ThemeCompat$ImplApi29 {
    public static void rebase(Theme theme) {
        theme.rebase();
    }
}
