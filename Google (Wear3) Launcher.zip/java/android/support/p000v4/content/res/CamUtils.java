package android.support.p000v4.content.res;

import android.support.p000v4.graphics.ColorUtils;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.CamUtils */
final class CamUtils {
    static final float[][] CAM16RGB_TO_XYZ = new float[][]{new float[]{1.8620678f, -1.0112547f, 0.14918678f}, new float[]{0.38752654f, 0.62144744f, -0.00897398f}, new float[]{-0.0158415f, -0.03412294f, 1.0499644f}};
    static final float[][] SRGB_TO_XYZ = new float[][]{new float[]{0.41233894f, 0.35762063f, 0.18051042f}, new float[]{0.2126f, 0.7152f, 0.0722f}, new float[]{0.01932141f, 0.11916382f, 0.9503448f}};
    static final float[] WHITE_POINT_D65 = new float[]{95.047f, 100.0f, 108.883f};
    static final float[][] XYZ_TO_CAM16RGB = new float[][]{new float[]{0.401288f, 0.650173f, -0.051461f}, new float[]{-0.250268f, 1.204414f, 0.045854f}, new float[]{-0.002079f, 0.048952f, 0.953127f}};

    static int intFromLStar(float f) {
        if (f < 1.0f) {
            return -16777216;
        }
        if (f > 99.0f) {
            return -1;
        }
        float f2 = (16.0f + f) / 116.0f;
        f = f > 8.0f ? (f2 * f2) * f2 : f / 903.2963f;
        float f3 = (f2 * f2) * f2;
        float f4 = f3 > 0.008856452f ? f3 : ((f2 * 116.0f) - 0.25f) / 903.2963f;
        if (f3 <= 0.008856452f) {
            f3 = ((f2 * 116.0f) - 0.25f) / 903.2963f;
        }
        float[] fArr = WHITE_POINT_D65;
        return ColorUtils.XYZToColor((double) (f4 * fArr[0]), (double) (f * fArr[1]), (double) (f3 * fArr[2]));
    }

    static float linearized(int i) {
        float f = ((float) i) / 255.0f;
        return (f <= 0.04045f ? f / 12.92f : (float) Math.pow((double) ((f + 0.055f) / 1.055f), 2.4000000953674316d)) * 100.0f;
    }

    static float yFromLStar$ar$ds() {
        return ((float) Math.pow(0.5689655172413793d, 3.0d)) * 100.0f;
    }
}
