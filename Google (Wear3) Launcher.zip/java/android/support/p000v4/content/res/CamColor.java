package android.support.p000v4.content.res;

import android.graphics.Color;
import android.support.p000v4.graphics.ColorUtils;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.CamColor */
final class CamColor {
    public final float mAstar;
    public final float mBstar;
    public final float mChroma;
    public final float mHue;
    /* renamed from: mJ */
    public final float f0mJ;
    public final float mJstar;

    public CamColor(float f, float f2, float f3, float f4, float f5, float f6) {
        this.mHue = f;
        this.mChroma = f2;
        this.f0mJ = f3;
        this.mJstar = f4;
        this.mAstar = f5;
        this.mBstar = f6;
    }

    static CamColor fromColor(int i) {
        ViewingConditions viewingConditions = ViewingConditions.DEFAULT;
        float linearized = CamUtils.linearized(Color.red(i));
        float linearized2 = CamUtils.linearized(Color.green(i));
        float linearized3 = CamUtils.linearized(Color.blue(i));
        float[][] fArr = CamUtils.SRGB_TO_XYZ;
        float[] fArr2 = fArr[0];
        float f = fArr2[0];
        float f2 = fArr2[1];
        float f3 = fArr2[2];
        float[] fArr3 = fArr[1];
        float f4 = fArr3[0];
        float f5 = fArr3[1];
        float f6 = fArr3[2];
        float[] fArr4 = fArr[2];
        float f7 = fArr4[0];
        float f8 = fArr4[1];
        float f9 = fArr4[2];
        float[] fArr5 = new float[]{((f * linearized) + (f2 * linearized2)) + (f3 * linearized3), ((f4 * linearized) + (f5 * linearized2)) + (f6 * linearized3), ((linearized * f7) + (linearized2 * f8)) + (linearized3 * f9)};
        float[][] fArr6 = CamUtils.XYZ_TO_CAM16RGB;
        linearized3 = fArr5[0];
        fArr4 = fArr6[0];
        f3 = fArr4[0];
        f = fArr5[1];
        f2 = fArr4[1];
        float f10 = fArr5[2];
        f3 = ((f3 * linearized3) + (f2 * f)) + (fArr4[2] * f10);
        fArr4 = fArr6[1];
        f2 = (fArr4[0] * linearized3) + (fArr4[1] * f);
        f9 = fArr4[2];
        float[] fArr7 = fArr6[2];
        f6 = fArr7[0];
        f4 = fArr7[1];
        linearized = fArr7[2];
        float[] fArr8 = viewingConditions.mRgbD;
        float f11 = fArr8[0] * f3;
        f3 = fArr8[1] * (f2 + (f9 * f10));
        linearized2 = fArr8[2] * (((linearized3 * f6) + (f * f4)) + (f10 * linearized));
        double abs = (double) (viewingConditions.mFl * Math.abs(f11));
        Double.isNaN(abs);
        linearized = (float) Math.pow(abs / 100.0d, 0.42d);
        abs = (double) (viewingConditions.mFl * Math.abs(f3));
        Double.isNaN(abs);
        linearized3 = (float) Math.pow(abs / 100.0d, 0.42d);
        double abs2 = (double) (viewingConditions.mFl * Math.abs(linearized2));
        Double.isNaN(abs2);
        f9 = (float) Math.pow(abs2 / 100.0d, 0.42d);
        f11 = ((Math.signum(f11) * 400.0f) * linearized) / (linearized + 27.13f);
        linearized = ((Math.signum(f3) * 400.0f) * linearized3) / (linearized3 + 27.13f);
        linearized2 = ((Math.signum(linearized2) * 400.0f) * f9) / (f9 + 27.13f);
        abs = (double) linearized2;
        double d = (double) f11;
        Double.isNaN(d);
        d *= 11.0d;
        abs2 = (double) linearized;
        Double.isNaN(abs2);
        d += abs2 * -12.0d;
        Double.isNaN(abs);
        f3 = ((float) (d + abs)) / 11.0f;
        d = (double) (f11 + linearized);
        Double.isNaN(abs);
        Double.isNaN(abs);
        abs += abs;
        Double.isNaN(d);
        linearized3 = ((float) (d - abs)) / 9.0f;
        linearized *= 20.0f;
        f2 = (((f11 * 20.0f) + linearized) + (21.0f * linearized2)) / 20.0f;
        f11 = (((f11 * 40.0f) + linearized) + linearized2) / 20.0f;
        linearized = (((float) Math.atan2((double) linearized3, (double) f3)) * 180.0f) / 3.1415927f;
        if (linearized < 0.0f) {
            f4 = linearized + 360.0f;
        } else {
            if (linearized >= 360.0f) {
                linearized -= 0.012451172f;
            }
            f4 = linearized;
        }
        f9 = (3.1415927f * f4) / 180.0f;
        linearized = viewingConditions.mNbb;
        linearized2 = viewingConditions.mAw;
        f6 = viewingConditions.f1mC;
        f7 = ((float) Math.pow((double) ((f11 * linearized) / linearized2), (double) (viewingConditions.f3mZ * 0.69f))) * 100.0f;
        linearized = viewingConditions.f1mC;
        Math.sqrt((double) (f7 / 100.0f));
        linearized = viewingConditions.mAw;
        linearized = viewingConditions.mFlRoot;
        if (((double) f4) < 20.14d) {
            f10 = 360.0f + f4;
        } else {
            f10 = f4;
        }
        double d2 = (double) f10;
        Double.isNaN(d2);
        d2 = Math.cos(((d2 * 3.141592653589793d) / 180.0d) + 2.0d);
        f11 = viewingConditions.mNcb;
        float f12 = f4;
        double sqrt = Math.sqrt((double) ((f3 * f3) + (linearized3 * linearized3)));
        f3 = f9;
        linearized3 = ((float) Math.pow(1.64d - Math.pow(0.29d, (double) viewingConditions.f2mN), 0.73d)) * ((float) Math.pow((double) (((((((float) (d2 + 3.8d)) * 0.25f) * 3846.1538f) * f11) * ((float) sqrt)) / (f2 + 0.305f)), 0.9d));
        d2 = (double) f7;
        Double.isNaN(d2);
        f5 = linearized3 * ((float) Math.sqrt(d2 / 100.0d));
        linearized = viewingConditions.mFlRoot;
        linearized2 = viewingConditions.f1mC;
        Math.sqrt((double) ((linearized3 * 0.69f) / (viewingConditions.mAw + 4.0f)));
        linearized = ((float) Math.log((double) (((linearized * f5) * 0.0228f) + 1.0f))) * 43.85965f;
        double d3 = (double) f3;
        return new CamColor(f12, f5, f7, (1.7f * f7) / ((0.007f * f7) + 1.0f), linearized * ((float) Math.cos(d3)), linearized * ((float) Math.sin(d3)));
    }

    public static CamColor fromJch(float f, float f2, float f3) {
        ViewingConditions viewingConditions = ViewingConditions.DEFAULT;
        float f4 = viewingConditions.f1mC;
        double d = (double) f;
        Double.isNaN(d);
        d /= 100.0d;
        Math.sqrt(d);
        float f5 = viewingConditions.mAw;
        f5 = viewingConditions.mFlRoot;
        d = Math.sqrt(d);
        float f6 = viewingConditions.f1mC;
        Math.sqrt((double) (((f2 / ((float) d)) * 0.69f) / (viewingConditions.mAw + 4.0f)));
        double d2 = (double) (f5 * f2);
        Double.isNaN(d2);
        float log = ((float) Math.log((d2 * 0.0228d) + 1.0d)) * 43.85965f;
        d = (double) ((3.1415927f * f3) / 180.0f);
        return new CamColor(f3, f2, f, (1.7f * f) / ((0.007f * f) + 1.0f), log * ((float) Math.cos(d)), log * ((float) Math.sin(d)));
    }

    final int viewed(ViewingConditions viewingConditions) {
        double d;
        ViewingConditions viewingConditions2 = viewingConditions;
        float f = this.mChroma;
        float f2 = 0.0f;
        if (((double) f) != 0.0d) {
            d = (double) r0.f0mJ;
            if (d != 0.0d) {
                Double.isNaN(d);
                f2 = f / ((float) Math.sqrt(d / 100.0d));
            }
        }
        double d2 = (double) f2;
        double pow = Math.pow(1.64d - Math.pow(0.29d, (double) viewingConditions2.f2mN), 0.73d);
        Double.isNaN(d2);
        f = (float) Math.pow(d2 / pow, 1.1111111111111112d);
        d = (double) ((r0.mHue * 3.1415927f) / 180.0f);
        Double.isNaN(d);
        pow = Math.cos(2.0d + d);
        f2 = viewingConditions2.mAw;
        float f3 = r0.f0mJ;
        float f4 = viewingConditions2.f1mC;
        f4 = viewingConditions2.f3mZ;
        double d3 = (double) f3;
        Double.isNaN(d3);
        d3 /= 100.0d;
        double d4 = (double) f4;
        Double.isNaN(d4);
        double pow2 = Math.pow(d3, 1.4492753673265821d / d4);
        f2 = (f2 * ((float) pow2)) / viewingConditions2.mNbb;
        float sin = (float) Math.sin(d);
        float cos = (float) Math.cos(d);
        float f5 = (((0.305f + f2) * 23.0f) * f) / ((((((((float) (pow + 3.8d)) * 0.25f) * 3846.1538f) * viewingConditions2.mNcb) * 23.0f) + ((11.0f * f) * cos)) + ((f * 108.0f) * sin));
        cos *= f5;
        f5 *= sin;
        f2 *= 460.0f;
        f = (((451.0f * cos) + f2) + (288.0f * f5)) / 1403.0f;
        float f6 = ((f2 - (891.0f * cos)) - (261.0f * f5)) / 1403.0f;
        f2 = ((f2 - (cos * 220.0f)) - (f5 * 6300.0f)) / 1403.0f;
        cos = Math.abs(f);
        f5 = Math.abs(f);
        pow = (double) cos;
        Double.isNaN(pow);
        pow *= 27.13d;
        d = (double) f5;
        Double.isNaN(d);
        f = (Math.signum(f) * (100.0f / viewingConditions2.mFl)) * ((float) Math.pow((double) ((float) Math.max(0.0d, pow / (400.0d - d))), 2.380952380952381d));
        cos = Math.abs(f6);
        f5 = Math.abs(f6);
        pow = (double) cos;
        Double.isNaN(pow);
        pow *= 27.13d;
        d = (double) f5;
        Double.isNaN(d);
        f6 = (Math.signum(f6) * (100.0f / viewingConditions2.mFl)) * ((float) Math.pow((double) ((float) Math.max(0.0d, pow / (400.0d - d))), 2.380952380952381d));
        cos = Math.abs(f2);
        f5 = Math.abs(f2);
        pow = (double) cos;
        Double.isNaN(pow);
        pow *= 27.13d;
        d = (double) f5;
        Double.isNaN(d);
        d = Math.max(0.0d, pow / (400.0d - d));
        f2 = Math.signum(f2);
        float f7 = viewingConditions2.mFl;
        d = Math.pow((double) ((float) d), 2.380952380952381d);
        float[] fArr = viewingConditions2.mRgbD;
        f /= fArr[0];
        f6 /= fArr[1];
        f2 = ((f2 * (100.0f / f7)) * ((float) d)) / fArr[2];
        float[][] fArr2 = CamUtils.CAM16RGB_TO_XYZ;
        float[] fArr3 = fArr2[0];
        sin = fArr3[0];
        f7 = fArr3[1];
        f5 = fArr3[2];
        float[] fArr4 = fArr2[1];
        f3 = fArr4[0];
        f4 = fArr4[1];
        float f8 = fArr4[2];
        fArr = fArr2[2];
        return ColorUtils.XYZToColor((double) (((sin * f) + (f7 * f6)) + (f5 * f2)), (double) (((f3 * f) + (f4 * f6)) + (f8 * f2)), (double) (((f * fArr[0]) + (f6 * fArr[1])) + (f2 * fArr[2])));
    }
}
