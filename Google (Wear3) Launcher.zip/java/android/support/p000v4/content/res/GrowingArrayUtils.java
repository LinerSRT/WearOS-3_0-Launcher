package android.support.p000v4.content.res;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.GrowingArrayUtils */
final class GrowingArrayUtils {
    public static int growSize(int i) {
        return i <= 4 ? 8 : i + i;
    }
}
