package android.support.p000v4.content.res;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.ViewingConditions */
final class ViewingConditions {
    static final ViewingConditions DEFAULT;
    public final float mAw;
    /* renamed from: mC */
    public final float f1mC = 0.69f;
    public final float mFl;
    public final float mFlRoot;
    /* renamed from: mN */
    public final float f2mN;
    public final float mNbb;
    public final float mNcb;
    public final float[] mRgbD;
    /* renamed from: mZ */
    public final float f3mZ;

    static {
        float[] fArr = CamUtils.WHITE_POINT_D65;
        double yFromLStar$ar$ds = (double) CamUtils.yFromLStar$ar$ds();
        Double.isNaN(yFromLStar$ar$ds);
        float f = (float) ((yFromLStar$ar$ds * 63.66197723675813d) / 100.0d);
        float[][] fArr2 = CamUtils.XYZ_TO_CAM16RGB;
        float f2 = fArr[0];
        float[] fArr3 = fArr2[0];
        float f3 = fArr3[0];
        float f4 = fArr[1];
        float f5 = fArr3[1];
        float f6 = fArr[2];
        f3 = ((f3 * f2) + (f5 * f4)) + (fArr3[2] * f6);
        fArr3 = fArr2[1];
        f5 = ((fArr3[0] * f2) + (fArr3[1] * f4)) + (fArr3[2] * f6);
        float[] fArr4 = fArr2[2];
        f2 = ((f2 * fArr4[0]) + (f4 * fArr4[1])) + (f6 * fArr4[2]);
        float exp = 1.0f - (((float) Math.exp((double) (((-f) - 0.10546875f) / 92.0f))) * 0.2777778f);
        double d = (double) exp;
        if (d > 1.0d) {
            exp = 1.0f;
        } else if (d < 0.0d) {
            exp = 0.0f;
        }
        float[] fArr5 = new float[]{(((100.0f / f3) * exp) + 1.0f) - exp, (((100.0f / f5) * exp) + 1.0f) - exp, (((100.0f / f2) * exp) + 1.0f) - exp};
        exp = 1.0f / ((5.0f * f) + 1.0f);
        f6 = ((exp * exp) * exp) * exp;
        float f7 = 1.0f - f6;
        f6 *= f;
        exp = (0.1f * f7) * f7;
        double d2 = (double) f;
        Double.isNaN(d2);
        f = f6 + (exp * ((float) Math.cbrt(d2 * 5.0d)));
        float yFromLStar$ar$ds2 = CamUtils.yFromLStar$ar$ds() / fArr[1];
        double d3 = (double) yFromLStar$ar$ds2;
        double sqrt = Math.sqrt(d3);
        f7 = f;
        f = 0.725f / ((float) Math.pow(d3, 0.2d));
        fArr4 = new float[3];
        d2 = (double) ((fArr5[0] * f7) * f3);
        Double.isNaN(d2);
        float f8 = f5;
        fArr4[0] = (float) Math.pow(d2 / 100.0d, 0.42d);
        d2 = (double) ((fArr5[1] * f7) * f8);
        Double.isNaN(d2);
        fArr4[1] = (float) Math.pow(d2 / 100.0d, 0.42d);
        d2 = (double) ((fArr5[2] * f7) * f2);
        Double.isNaN(d2);
        float pow = (float) Math.pow(d2 / 100.0d, 0.42d);
        fArr4[2] = pow;
        float[] fArr6 = new float[3];
        f2 = fArr4[0];
        fArr6[0] = (f2 * 400.0f) / (f2 + 27.13f);
        exp = fArr4[1];
        fArr6[1] = (exp * 400.0f) / (exp + 27.13f);
        f3 = (400.0f * pow) / (pow + 27.13f);
        fArr6[2] = f3;
        f8 = fArr6[0];
        fArr6 = fArr5;
        DEFAULT = new ViewingConditions(yFromLStar$ar$ds2, (((f8 + f8) + fArr6[1]) + (f3 * 0.05f)) * f, f, f, fArr6, f7, (float) Math.pow((double) f7, 0.25d), ((float) sqrt) + 1.48f);
    }

    private ViewingConditions(float f, float f2, float f3, float f4, float[] fArr, float f5, float f6, float f7) {
        this.f2mN = f;
        this.mAw = f2;
        this.mNbb = f3;
        this.mNcb = f4;
        this.mRgbD = fArr;
        this.mFl = f5;
        this.mFlRoot = f6;
        this.f3mZ = f7;
    }
}
