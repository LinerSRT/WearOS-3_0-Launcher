package android.support.p000v4.content.res;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import org.xmlpull.v1.XmlPullParser;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.TypedArrayUtils */
public final class TypedArrayUtils {
    public static int getAttr(Context context, int i, int i2) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(i, typedValue, true);
        return typedValue.resourceId != 0 ? i : i2;
    }

    public static boolean getBoolean(TypedArray typedArray, int i, int i2, boolean z) {
        return typedArray.getBoolean(i, typedArray.getBoolean(i2, z));
    }

    public static int getInt$ar$ds(TypedArray typedArray, int i, int i2) {
        return typedArray.getInt(i, typedArray.getInt(i2, Integer.MAX_VALUE));
    }

    public static int getNamedColor$ar$ds(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i) {
        if (TypedArrayUtils.hasAttribute(xmlPullParser, str)) {
            return typedArray.getColor(i, 0);
        }
        return 0;
    }

    public static android.support.p000v4.content.res.ComplexColorCompat getNamedComplexColor$ar$ds(android.content.res.TypedArray r26, org.xmlpull.v1.XmlPullParser r27, android.content.res.Resources.Theme r28, java.lang.String r29, int r30) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Unknown predecessor block by arg (r1_8 android.graphics.Shader) in PHI: PHI: (r1_10 android.graphics.Shader) = (r1_4 android.graphics.Shader), (r1_5 android.graphics.Shader), (r1_8 android.graphics.Shader) binds: {(r1_4 android.graphics.Shader)=B:77:0x01d7, (r1_5 android.graphics.Shader)=B:71:0x01a8, (r1_8 android.graphics.Shader)=B:74:0x01b7}
	at jadx.core.dex.instructions.PhiInsn.replaceArg(PhiInsn.java:79)
	at jadx.core.dex.visitors.ModVisitor.processInvoke(ModVisitor.java:222)
	at jadx.core.dex.visitors.ModVisitor.replaceStep(ModVisitor.java:83)
	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:68)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
*/
        /*
        r0 = r26;
        r1 = r28;
        r2 = r30;
        r3 = "centerColor";
        r4 = r27;
        r5 = r29;
        r4 = android.support.p000v4.content.res.TypedArrayUtils.hasAttribute(r4, r5);
        r5 = 0;
        if (r4 == 0) goto L_0x0252;
    L_0x0013:
        r4 = new android.util.TypedValue;
        r4.<init>();
        r0.getValue(r2, r4);
        r6 = r4.type;
        r7 = 28;
        if (r6 < r7) goto L_0x002f;
    L_0x0021:
        r6 = r4.type;
        r7 = 31;
        if (r6 <= r7) goto L_0x0028;
    L_0x0027:
        goto L_0x002f;
    L_0x0028:
        r0 = r4.data;
        r0 = android.support.p000v4.content.res.ComplexColorCompat.from(r0);
        return r0;
    L_0x002f:
        r4 = r26.getResources();
        r0 = r0.getResourceId(r2, r5);
        r0 = r4.getXml(r0);	 Catch:{ Exception -> 0x0245 }
        r6 = android.util.Xml.asAttributeSet(r0);	 Catch:{ Exception -> 0x0245 }
    L_0x003f:
        r7 = r0.next();	 Catch:{ Exception -> 0x0245 }
        r8 = 2;	 Catch:{ Exception -> 0x0245 }
        r9 = 1;	 Catch:{ Exception -> 0x0245 }
        if (r7 == r8) goto L_0x0052;	 Catch:{ Exception -> 0x0245 }
    L_0x0047:
        if (r7 == r9) goto L_0x004a;	 Catch:{ Exception -> 0x0245 }
    L_0x0049:
        goto L_0x003f;	 Catch:{ Exception -> 0x0245 }
    L_0x004a:
        r0 = new org.xmlpull.v1.XmlPullParserException;	 Catch:{ Exception -> 0x0245 }
        r1 = "No start tag found";	 Catch:{ Exception -> 0x0245 }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0245 }
        throw r0;	 Catch:{ Exception -> 0x0245 }
    L_0x0052:
        r7 = r0.getName();	 Catch:{ Exception -> 0x0245 }
        r10 = r7.hashCode();	 Catch:{ Exception -> 0x0245 }
        r11 = "gradient";
        switch(r10) {
            case 89650992: goto L_0x006b;
            case 1191572447: goto L_0x0060;
            default: goto L_0x005f;
        };
    L_0x005f:
        goto L_0x0073;
        r10 = "selector";
        r10 = r7.equals(r10);
        if (r10 == 0) goto L_0x005f;
    L_0x0069:
        r10 = 0;
        goto L_0x0074;
    L_0x006b:
        r10 = r7.equals(r11);
        if (r10 == 0) goto L_0x005f;
    L_0x0071:
        r10 = 1;
        goto L_0x0074;
    L_0x0073:
        r10 = -1;
    L_0x0074:
        switch(r10) {
            case 0: goto L_0x0217;
            case 1: goto L_0x007c;
            default: goto L_0x0077;
        };
    L_0x0077:
        r3 = 0;
        r1 = new org.xmlpull.v1.XmlPullParserException;	 Catch:{ Exception -> 0x0243 }
        goto L_0x0227;
    L_0x007c:
        r7 = r0.getName();	 Catch:{ Exception -> 0x0245 }
        r10 = r7.equals(r11);	 Catch:{ Exception -> 0x0245 }
        if (r10 == 0) goto L_0x01f9;	 Catch:{ Exception -> 0x0245 }
    L_0x0086:
        r7 = android.support.compat.R$styleable.GradientColor;	 Catch:{ Exception -> 0x0245 }
        r7 = android.support.p000v4.content.res.TypedArrayUtils.obtainAttributes(r4, r1, r6, r7);	 Catch:{ Exception -> 0x0245 }
        r10 = "startX";	 Catch:{ Exception -> 0x0245 }
        r11 = 8;	 Catch:{ Exception -> 0x0245 }
        r12 = 0;	 Catch:{ Exception -> 0x0245 }
        r14 = android.support.p000v4.content.res.TypedArrayUtils.getNamedFloat(r7, r0, r10, r11, r12);	 Catch:{ Exception -> 0x0245 }
        r10 = "startY";	 Catch:{ Exception -> 0x0245 }
        r11 = 9;	 Catch:{ Exception -> 0x0245 }
        r15 = android.support.p000v4.content.res.TypedArrayUtils.getNamedFloat(r7, r0, r10, r11, r12);	 Catch:{ Exception -> 0x0245 }
        r10 = "endX";	 Catch:{ Exception -> 0x0245 }
        r11 = 10;	 Catch:{ Exception -> 0x0245 }
        r16 = android.support.p000v4.content.res.TypedArrayUtils.getNamedFloat(r7, r0, r10, r11, r12);	 Catch:{ Exception -> 0x0245 }
        r10 = "endY";	 Catch:{ Exception -> 0x0245 }
        r11 = 11;	 Catch:{ Exception -> 0x0245 }
        r17 = android.support.p000v4.content.res.TypedArrayUtils.getNamedFloat(r7, r0, r10, r11, r12);	 Catch:{ Exception -> 0x0245 }
        r10 = "centerX";	 Catch:{ Exception -> 0x0245 }
        r11 = 3;	 Catch:{ Exception -> 0x0245 }
        r10 = android.support.p000v4.content.res.TypedArrayUtils.getNamedFloat(r7, r0, r10, r11, r12);	 Catch:{ Exception -> 0x0245 }
        r13 = "centerY";	 Catch:{ Exception -> 0x0245 }
        r2 = 4;	 Catch:{ Exception -> 0x0245 }
        r2 = android.support.p000v4.content.res.TypedArrayUtils.getNamedFloat(r7, r0, r13, r2, r12);	 Catch:{ Exception -> 0x0245 }
        r13 = "type";	 Catch:{ Exception -> 0x0245 }
        r13 = android.support.p000v4.content.res.TypedArrayUtils.getNamedInt(r7, r0, r13, r8, r5);	 Catch:{ Exception -> 0x0245 }
        r8 = "startColor";	 Catch:{ Exception -> 0x0245 }
        r8 = android.support.p000v4.content.res.TypedArrayUtils.getNamedColor$ar$ds(r7, r0, r8, r5);	 Catch:{ Exception -> 0x0245 }
        r18 = android.support.p000v4.content.res.TypedArrayUtils.hasAttribute(r0, r3);	 Catch:{ Exception -> 0x0245 }
        r11 = 7;	 Catch:{ Exception -> 0x0245 }
        r3 = android.support.p000v4.content.res.TypedArrayUtils.getNamedColor$ar$ds(r7, r0, r3, r11);	 Catch:{ Exception -> 0x0245 }
        r11 = "endColor";	 Catch:{ Exception -> 0x0245 }
        r11 = android.support.p000v4.content.res.TypedArrayUtils.getNamedColor$ar$ds(r7, r0, r11, r9);	 Catch:{ Exception -> 0x0245 }
        r9 = "tileMode";	 Catch:{ Exception -> 0x0245 }
        r12 = 6;	 Catch:{ Exception -> 0x0245 }
        r9 = android.support.p000v4.content.res.TypedArrayUtils.getNamedInt(r7, r0, r9, r12, r5);	 Catch:{ Exception -> 0x0245 }
        r12 = "gradientRadius";	 Catch:{ Exception -> 0x0245 }
        r5 = 5;	 Catch:{ Exception -> 0x0245 }
        r20 = r15;	 Catch:{ Exception -> 0x0245 }
        r15 = 0;	 Catch:{ Exception -> 0x0245 }
        r21 = android.support.p000v4.content.res.TypedArrayUtils.getNamedFloat(r7, r0, r12, r5, r15);	 Catch:{ Exception -> 0x0245 }
        r7.recycle();	 Catch:{ Exception -> 0x0245 }
        r5 = r0.getDepth();	 Catch:{ Exception -> 0x0245 }
        r7 = 1;	 Catch:{ Exception -> 0x0245 }
        r5 = r5 + r7;	 Catch:{ Exception -> 0x0245 }
        r7 = new java.util.ArrayList;	 Catch:{ Exception -> 0x0245 }
        r12 = 20;	 Catch:{ Exception -> 0x0245 }
        r7.<init>(r12);	 Catch:{ Exception -> 0x0245 }
        r15 = new java.util.ArrayList;	 Catch:{ Exception -> 0x0245 }
        r15.<init>(r12);	 Catch:{ Exception -> 0x0245 }
    L_0x00fc:
        r12 = r0.next();	 Catch:{ Exception -> 0x0245 }
        r22 = r14;	 Catch:{ Exception -> 0x0245 }
        r14 = 1;	 Catch:{ Exception -> 0x0245 }
        if (r12 == r14) goto L_0x0183;	 Catch:{ Exception -> 0x0245 }
    L_0x0105:
        r14 = r0.getDepth();	 Catch:{ Exception -> 0x0245 }
        if (r14 >= r5) goto L_0x0111;	 Catch:{ Exception -> 0x0245 }
    L_0x010b:
        r23 = r9;	 Catch:{ Exception -> 0x0245 }
        r9 = 3;	 Catch:{ Exception -> 0x0245 }
        if (r12 == r9) goto L_0x0185;	 Catch:{ Exception -> 0x0245 }
    L_0x0110:
        goto L_0x0114;	 Catch:{ Exception -> 0x0245 }
    L_0x0111:
        r23 = r9;	 Catch:{ Exception -> 0x0245 }
        r9 = 3;	 Catch:{ Exception -> 0x0245 }
    L_0x0114:
        r9 = 2;	 Catch:{ Exception -> 0x0245 }
        if (r12 != r9) goto L_0x017c;	 Catch:{ Exception -> 0x0245 }
    L_0x0117:
        if (r14 > r5) goto L_0x017c;	 Catch:{ Exception -> 0x0245 }
    L_0x0119:
        r12 = r0.getName();	 Catch:{ Exception -> 0x0245 }
        r14 = "item";	 Catch:{ Exception -> 0x0245 }
        r12 = r12.equals(r14);	 Catch:{ Exception -> 0x0245 }
        if (r12 == 0) goto L_0x0176;	 Catch:{ Exception -> 0x0245 }
    L_0x0125:
        r12 = android.support.compat.R$styleable.GradientColorItem;	 Catch:{ Exception -> 0x0245 }
        r12 = android.support.p000v4.content.res.TypedArrayUtils.obtainAttributes(r4, r1, r6, r12);	 Catch:{ Exception -> 0x0245 }
        r14 = 0;	 Catch:{ Exception -> 0x0245 }
        r24 = r12.hasValue(r14);	 Catch:{ Exception -> 0x0245 }
        r14 = 1;	 Catch:{ Exception -> 0x0245 }
        r25 = r12.hasValue(r14);	 Catch:{ Exception -> 0x0245 }
        if (r24 == 0) goto L_0x015b;	 Catch:{ Exception -> 0x0245 }
    L_0x0137:
        if (r25 == 0) goto L_0x015b;	 Catch:{ Exception -> 0x0245 }
        r14 = 0;	 Catch:{ Exception -> 0x0245 }
        r24 = r12.getColor(r14, r14);	 Catch:{ Exception -> 0x0245 }
        r9 = 0;	 Catch:{ Exception -> 0x0245 }
        r14 = 1;	 Catch:{ Exception -> 0x0245 }
        r25 = r12.getFloat(r14, r9);	 Catch:{ Exception -> 0x0245 }
        r12.recycle();	 Catch:{ Exception -> 0x0245 }
        r9 = java.lang.Integer.valueOf(r24);	 Catch:{ Exception -> 0x0245 }
        r15.add(r9);	 Catch:{ Exception -> 0x0245 }
        r9 = java.lang.Float.valueOf(r25);	 Catch:{ Exception -> 0x0245 }
        r7.add(r9);	 Catch:{ Exception -> 0x0245 }
        r14 = r22;	 Catch:{ Exception -> 0x0245 }
        r9 = r23;	 Catch:{ Exception -> 0x0245 }
        goto L_0x00fc;	 Catch:{ Exception -> 0x0245 }
    L_0x015b:
        r1 = new org.xmlpull.v1.XmlPullParserException;	 Catch:{ Exception -> 0x0245 }
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0245 }
        r2.<init>();	 Catch:{ Exception -> 0x0245 }
        r0 = r0.getPositionDescription();	 Catch:{ Exception -> 0x0245 }
        r2.append(r0);	 Catch:{ Exception -> 0x0245 }
        r0 = ": <item> tag requires a 'color' attribute and a 'offset' attribute!";	 Catch:{ Exception -> 0x0245 }
        r2.append(r0);	 Catch:{ Exception -> 0x0245 }
        r0 = r2.toString();	 Catch:{ Exception -> 0x0245 }
        r1.<init>(r0);	 Catch:{ Exception -> 0x0245 }
        throw r1;	 Catch:{ Exception -> 0x0245 }
    L_0x0176:
        r14 = 1;	 Catch:{ Exception -> 0x0245 }
        r14 = r22;	 Catch:{ Exception -> 0x0245 }
        r9 = r23;	 Catch:{ Exception -> 0x0245 }
        goto L_0x00fc;	 Catch:{ Exception -> 0x0245 }
    L_0x017c:
        r14 = 1;	 Catch:{ Exception -> 0x0245 }
        r14 = r22;	 Catch:{ Exception -> 0x0245 }
        r9 = r23;	 Catch:{ Exception -> 0x0245 }
        goto L_0x00fc;	 Catch:{ Exception -> 0x0245 }
    L_0x0183:
        r23 = r9;	 Catch:{ Exception -> 0x0245 }
    L_0x0185:
        r0 = r15.size();	 Catch:{ Exception -> 0x0245 }
        if (r0 <= 0) goto L_0x0191;	 Catch:{ Exception -> 0x0245 }
    L_0x018b:
        r0 = new android.support.v4.content.res.GradientColorInflaterCompat$ColorStops;	 Catch:{ Exception -> 0x0245 }
        r0.<init>(r15, r7);	 Catch:{ Exception -> 0x0245 }
        goto L_0x0192;	 Catch:{ Exception -> 0x0245 }
    L_0x0191:
        r0 = 0;	 Catch:{ Exception -> 0x0245 }
    L_0x0192:
        if (r0 == 0) goto L_0x0195;	 Catch:{ Exception -> 0x0245 }
    L_0x0194:
        goto L_0x01a2;	 Catch:{ Exception -> 0x0245 }
    L_0x0195:
        if (r18 == 0) goto L_0x019d;	 Catch:{ Exception -> 0x0245 }
    L_0x0197:
        r0 = new android.support.v4.content.res.GradientColorInflaterCompat$ColorStops;	 Catch:{ Exception -> 0x0245 }
        r0.<init>(r8, r3, r11);	 Catch:{ Exception -> 0x0245 }
        goto L_0x01a2;	 Catch:{ Exception -> 0x0245 }
    L_0x019d:
        r0 = new android.support.v4.content.res.GradientColorInflaterCompat$ColorStops;	 Catch:{ Exception -> 0x0245 }
        r0.<init>(r8, r11);	 Catch:{ Exception -> 0x0245 }
    L_0x01a2:
        switch(r13) {
            case 1: goto L_0x01b2;
            case 2: goto L_0x01a8;
            default: goto L_0x01a5;
        };	 Catch:{ Exception -> 0x0245 }
    L_0x01a5:
        r1 = new android.graphics.LinearGradient;	 Catch:{ Exception -> 0x0245 }
        goto L_0x01d7;	 Catch:{ Exception -> 0x0245 }
    L_0x01a8:
        r1 = new android.graphics.SweepGradient;	 Catch:{ Exception -> 0x0245 }
        r3 = r0.mColors;	 Catch:{ Exception -> 0x0245 }
        r0 = r0.mOffsets;	 Catch:{ Exception -> 0x0245 }
        r1.<init>(r10, r2, r3, r0);	 Catch:{ Exception -> 0x0245 }
        goto L_0x01ed;	 Catch:{ Exception -> 0x0245 }
    L_0x01b2:
        r1 = 0;	 Catch:{ Exception -> 0x0245 }
        r1 = (r21 > r1 ? 1 : (r21 == r1 ? 0 : -1));	 Catch:{ Exception -> 0x0245 }
        if (r1 <= 0) goto L_0x01cf;	 Catch:{ Exception -> 0x0245 }
    L_0x01b7:
        r1 = new android.graphics.RadialGradient;	 Catch:{ Exception -> 0x0245 }
        r3 = r0.mColors;	 Catch:{ Exception -> 0x0245 }
        r0 = r0.mOffsets;	 Catch:{ Exception -> 0x0245 }
        r24 = android.support.p000v4.content.res.GradientColorInflaterCompat.parseTileMode(r23);	 Catch:{ Exception -> 0x0245 }
        r18 = r1;	 Catch:{ Exception -> 0x0245 }
        r19 = r10;	 Catch:{ Exception -> 0x0245 }
        r20 = r2;	 Catch:{ Exception -> 0x0245 }
        r22 = r3;	 Catch:{ Exception -> 0x0245 }
        r23 = r0;	 Catch:{ Exception -> 0x0245 }
        r18.<init>(r19, r20, r21, r22, r23, r24);	 Catch:{ Exception -> 0x0245 }
        goto L_0x01ed;	 Catch:{ Exception -> 0x0245 }
    L_0x01cf:
        r0 = new org.xmlpull.v1.XmlPullParserException;	 Catch:{ Exception -> 0x0245 }
        r1 = "<gradient> tag requires 'gradientRadius' attribute with radial type";	 Catch:{ Exception -> 0x0245 }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0245 }
        throw r0;	 Catch:{ Exception -> 0x0245 }
    L_0x01d7:
        r2 = r0.mColors;	 Catch:{ Exception -> 0x0245 }
        r0 = r0.mOffsets;	 Catch:{ Exception -> 0x0245 }
        r3 = android.support.p000v4.content.res.GradientColorInflaterCompat.parseTileMode(r23);	 Catch:{ Exception -> 0x0245 }
        r13 = r1;	 Catch:{ Exception -> 0x0245 }
        r14 = r22;	 Catch:{ Exception -> 0x0245 }
        r15 = r20;	 Catch:{ Exception -> 0x0245 }
        r18 = r2;	 Catch:{ Exception -> 0x0245 }
        r19 = r0;	 Catch:{ Exception -> 0x0245 }
        r20 = r3;	 Catch:{ Exception -> 0x0245 }
        r13.<init>(r14, r15, r16, r17, r18, r19, r20);	 Catch:{ Exception -> 0x0245 }
    L_0x01ed:
        r0 = new android.support.v4.content.res.ComplexColorCompat;	 Catch:{ Exception -> 0x0245 }
        r2 = 0;
        r3 = 0;
        r0.<init>(r1, r2, r3);	 Catch:{ Exception -> 0x01f6 }
        r2 = r0;
        goto L_0x024f;
    L_0x01f6:
        r0 = move-exception;
        r3 = r2;
        goto L_0x0247;
    L_0x01f9:
        r1 = new org.xmlpull.v1.XmlPullParserException;	 Catch:{ Exception -> 0x0245 }
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0245 }
        r2.<init>();	 Catch:{ Exception -> 0x0245 }
        r0 = r0.getPositionDescription();	 Catch:{ Exception -> 0x0245 }
        r2.append(r0);	 Catch:{ Exception -> 0x0245 }
        r0 = ": invalid gradient color tag ";	 Catch:{ Exception -> 0x0245 }
        r2.append(r0);	 Catch:{ Exception -> 0x0245 }
        r2.append(r7);	 Catch:{ Exception -> 0x0245 }
        r0 = r2.toString();	 Catch:{ Exception -> 0x0245 }
        r1.<init>(r0);	 Catch:{ Exception -> 0x0245 }
        throw r1;	 Catch:{ Exception -> 0x0245 }
    L_0x0217:
        r0 = android.support.p000v4.content.res.ColorStateListInflaterCompat.createFromXmlInner(r4, r0, r6, r1);	 Catch:{ Exception -> 0x0245 }
        r1 = new android.support.v4.content.res.ComplexColorCompat;	 Catch:{ Exception -> 0x0245 }
        r2 = r0.getDefaultColor();	 Catch:{ Exception -> 0x0245 }
        r3 = 0;
        r1.<init>(r3, r0, r2);	 Catch:{ Exception -> 0x0243 }
        r2 = r1;	 Catch:{ Exception -> 0x0243 }
        goto L_0x024f;	 Catch:{ Exception -> 0x0243 }
    L_0x0227:
        r2 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0243 }
        r2.<init>();	 Catch:{ Exception -> 0x0243 }
        r0 = r0.getPositionDescription();	 Catch:{ Exception -> 0x0243 }
        r2.append(r0);	 Catch:{ Exception -> 0x0243 }
        r0 = ": unsupported complex color tag ";	 Catch:{ Exception -> 0x0243 }
        r2.append(r0);	 Catch:{ Exception -> 0x0243 }
        r2.append(r7);	 Catch:{ Exception -> 0x0243 }
        r0 = r2.toString();	 Catch:{ Exception -> 0x0243 }
        r1.<init>(r0);	 Catch:{ Exception -> 0x0243 }
        throw r1;	 Catch:{ Exception -> 0x0243 }
    L_0x0243:
        r0 = move-exception;
        goto L_0x0247;
    L_0x0245:
        r0 = move-exception;
        r3 = 0;
    L_0x0247:
        r1 = "ComplexColorCompat";
        r2 = "Failed to inflate ComplexColor.";
        android.util.Log.e(r1, r2, r0);
        r2 = r3;
    L_0x024f:
        if (r2 == 0) goto L_0x0252;
    L_0x0251:
        return r2;
    L_0x0252:
        r1 = 0;
        r0 = android.support.p000v4.content.res.ComplexColorCompat.from(r1);
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.content.res.TypedArrayUtils.getNamedComplexColor$ar$ds(android.content.res.TypedArray, org.xmlpull.v1.XmlPullParser, android.content.res.Resources$Theme, java.lang.String, int):android.support.v4.content.res.ComplexColorCompat");
    }

    public static float getNamedFloat(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, float f) {
        if (TypedArrayUtils.hasAttribute(xmlPullParser, str)) {
            return typedArray.getFloat(i, f);
        }
        return f;
    }

    public static int getNamedInt(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, int i2) {
        if (TypedArrayUtils.hasAttribute(xmlPullParser, str)) {
            return typedArray.getInt(i, i2);
        }
        return i2;
    }

    public static int getResourceId(TypedArray typedArray, int i, int i2, int i3) {
        return typedArray.getResourceId(i, typedArray.getResourceId(i2, i3));
    }

    public static String getString(TypedArray typedArray, int i, int i2) {
        String string = typedArray.getString(i);
        return string == null ? typedArray.getString(i2) : string;
    }

    public static CharSequence getText(TypedArray typedArray, int i, int i2) {
        CharSequence text = typedArray.getText(i);
        return text == null ? typedArray.getText(i2) : text;
    }

    public static CharSequence[] getTextArray(TypedArray typedArray, int i, int i2) {
        CharSequence[] textArray = typedArray.getTextArray(i);
        return textArray == null ? typedArray.getTextArray(i2) : textArray;
    }

    public static boolean hasAttribute(XmlPullParser xmlPullParser, String str) {
        return xmlPullParser.getAttributeValue("http://schemas.android.com/apk/res/android", str) != null;
    }

    public static TypedArray obtainAttributes(Resources resources, Theme theme, AttributeSet attributeSet, int[] iArr) {
        if (theme == null) {
            return resources.obtainAttributes(attributeSet, iArr);
        }
        return theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
    }
}
