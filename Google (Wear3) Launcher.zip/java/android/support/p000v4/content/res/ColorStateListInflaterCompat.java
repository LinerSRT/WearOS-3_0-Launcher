package android.support.p000v4.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* compiled from: PG */
/* renamed from: android.support.v4.content.res.ColorStateListInflaterCompat */
public final class ColorStateListInflaterCompat {
    private static final ThreadLocal sTempTypedValue = new ThreadLocal();

    public static ColorStateList createFromXml(Resources resources, XmlPullParser xmlPullParser, Theme theme) {
        AttributeSet asAttributeSet = Xml.asAttributeSet(xmlPullParser);
        while (true) {
            int next = xmlPullParser.next();
            if (next == 2) {
                return ColorStateListInflaterCompat.createFromXmlInner(resources, xmlPullParser, asAttributeSet, theme);
            }
            if (next == 1) {
                throw new XmlPullParserException("No start tag found");
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.content.res.ColorStateList createFromXmlInner(android.content.res.Resources r34, org.xmlpull.v1.XmlPullParser r35, android.util.AttributeSet r36, android.content.res.Resources.Theme r37) {
        /*
        r1 = r34;
        r2 = r36;
        r3 = r37;
        r0 = r35.getName();
        r4 = "selector";
        r4 = r0.equals(r4);
        if (r4 == 0) goto L_0x0379;
    L_0x0012:
        r0 = r35.getDepth();
        r4 = 1;
        r5 = r0 + 1;
        r0 = 20;
        r6 = new int[r0][];
        r0 = new int[r0];
        r7 = 0;
        r8 = r6;
        r9 = 0;
        r6 = r0;
    L_0x0023:
        r0 = r35.next();
        if (r0 == r4) goto L_0x0367;
    L_0x0029:
        r10 = r35.getDepth();
        r11 = 3;
        if (r10 >= r5) goto L_0x0036;
    L_0x0030:
        if (r0 == r11) goto L_0x0033;
    L_0x0032:
        goto L_0x0036;
    L_0x0033:
        r2 = r8;
        goto L_0x0368;
    L_0x0036:
        r12 = 2;
        if (r0 != r12) goto L_0x0357;
    L_0x0039:
        if (r10 > r5) goto L_0x0357;
    L_0x003b:
        r0 = r35.getName();
        r10 = "item";
        r0 = r0.equals(r10);
        if (r0 == 0) goto L_0x0352;
    L_0x0047:
        r0 = android.support.compat.R$styleable.ColorStateListItem;
        if (r3 != 0) goto L_0x0051;
    L_0x004b:
        r0 = r1.obtainAttributes(r2, r0);
        r10 = r0;
        goto L_0x0057;
        r0 = r3.obtainStyledAttributes(r2, r0, r7, r7);
        r10 = r0;
        r0 = -1;
        r13 = r10.getResourceId(r7, r0);
        r14 = -65281; // 0xffffffffffff00ff float:NaN double:NaN;
        if (r13 == r0) goto L_0x0098;
    L_0x0062:
        r0 = sTempTypedValue;
        r15 = r0.get();
        r15 = (android.util.TypedValue) r15;
        if (r15 != 0) goto L_0x0074;
    L_0x006c:
        r15 = new android.util.TypedValue;
        r15.<init>();
        r0.set(r15);
        r1.getValue(r13, r15, r4);
        r0 = r15.type;
        r12 = 28;
        if (r0 < r12) goto L_0x0085;
    L_0x007e:
        r0 = r15.type;
        r12 = 31;
        if (r0 > r12) goto L_0x0085;
    L_0x0084:
        goto L_0x0098;
    L_0x0085:
        r0 = r1.getXml(r13);	 Catch:{ Exception -> 0x0092 }
        r0 = android.support.p000v4.content.res.ColorStateListInflaterCompat.createFromXml(r1, r0, r3);	 Catch:{ Exception -> 0x0092 }
        r0 = r0.getDefaultColor();	 Catch:{ Exception -> 0x0092 }
        goto L_0x009d;
    L_0x0092:
        r0 = move-exception;
        r0 = r10.getColor(r7, r14);
        goto L_0x009d;
        r0 = r10.getColor(r7, r14);
        r12 = r10.hasValue(r4);
        r13 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        if (r12 == 0) goto L_0x00ab;
    L_0x00a6:
        r11 = r10.getFloat(r4, r13);
        goto L_0x00b9;
        r12 = r10.hasValue(r11);
        if (r12 == 0) goto L_0x00b7;
    L_0x00b2:
        r11 = r10.getFloat(r11, r13);
        goto L_0x00b9;
    L_0x00b7:
        r11 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
    L_0x00b9:
        r12 = androidx.core.p003os.BuildCompat.isAtLeastS();
        r14 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        if (r12 == 0) goto L_0x00cd;
    L_0x00c1:
        r12 = 2;
        r15 = r10.hasValue(r12);
        if (r15 == 0) goto L_0x00cd;
    L_0x00c8:
        r14 = r10.getFloat(r12, r14);
        goto L_0x00d2;
    L_0x00cd:
        r12 = 4;
        r14 = r10.getFloat(r12, r14);
    L_0x00d2:
        r10.recycle();
        r10 = r36.getAttributeCount();
        r12 = new int[r10];
        r4 = 0;
        r15 = 0;
    L_0x00dd:
        if (r15 >= r10) goto L_0x010c;
    L_0x00df:
        r13 = r2.getAttributeNameResource(r15);
        r7 = 16843173; // 0x10101a5 float:2.3694738E-38 double:8.321633E-317;
        if (r13 == r7) goto L_0x0104;
    L_0x00e8:
        r7 = 16843551; // 0x101031f float:2.3695797E-38 double:8.32182E-317;
        if (r13 == r7) goto L_0x0104;
    L_0x00ed:
        r7 = 2130968650; // 0x7f04004a float:1.754596E38 double:1.0528384023E-314;
        if (r13 == r7) goto L_0x0104;
    L_0x00f2:
        r7 = 2130969021; // 0x7f0401bd float:1.7546712E38 double:1.0528385856E-314;
        if (r13 == r7) goto L_0x0104;
    L_0x00f7:
        r7 = r4 + 1;
        r1 = 0;
        r19 = r2.getAttributeBooleanValue(r15, r1);
        if (r19 != 0) goto L_0x0101;
    L_0x0100:
        r13 = -r13;
    L_0x0101:
        r12[r4] = r13;
        r4 = r7;
    L_0x0104:
        r15 = r15 + 1;
        r1 = r34;
        r7 = 0;
        r13 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        goto L_0x00dd;
    L_0x010c:
        r1 = android.util.StateSet.trimStateSet(r12, r4);
        r4 = 1120403456; // 0x42c80000 float:100.0 double:5.53552857E-315;
        r7 = 0;
        r10 = (r14 > r7 ? 1 : (r14 == r7 ? 0 : -1));
        if (r10 < 0) goto L_0x011d;
    L_0x0117:
        r10 = (r14 > r4 ? 1 : (r14 == r4 ? 0 : -1));
        if (r10 > 0) goto L_0x011d;
    L_0x011b:
        r10 = 1;
        goto L_0x011e;
    L_0x011d:
        r10 = 0;
    L_0x011e:
        r12 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r13 = (r11 > r12 ? 1 : (r11 == r12 ? 0 : -1));
        if (r13 != 0) goto L_0x012f;
    L_0x0124:
        if (r10 != 0) goto L_0x012e;
    L_0x0126:
        r13 = r5;
        r30 = r8;
        r17 = 1;
        r8 = r1;
        goto L_0x0312;
    L_0x012e:
        r10 = 1;
    L_0x012f:
        r12 = android.graphics.Color.alpha(r0);
        r12 = (float) r12;
        r12 = r12 * r11;
        r11 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r12 = r12 + r11;
        r11 = (int) r12;
        r12 = 255; // 0xff float:3.57E-43 double:1.26E-321;
        r13 = 0;
        r11 = androidx.core.math.MathUtils.clamp(r11, r13, r12);
        if (r10 == 0) goto L_0x0305;
    L_0x0143:
        r0 = android.support.p000v4.content.res.CamColor.fromColor(r0);
        r10 = r0.mHue;
        r0 = r0.mChroma;
        r12 = android.support.p000v4.content.res.ViewingConditions.DEFAULT;
        r13 = r5;
        r4 = (double) r0;
        r19 = 4607182418800017408; // 0x3ff0000000000000 float:0.0 double:1.0;
        r21 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1));
        if (r21 < 0) goto L_0x02fb;
    L_0x0155:
        r4 = java.lang.Math.round(r14);
        r4 = (double) r4;
        r19 = 0;
        r21 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1));
        if (r21 <= 0) goto L_0x02f5;
    L_0x0160:
        r4 = java.lang.Math.round(r14);
        r4 = (double) r4;
        r19 = 4636737291354636288; // 0x4059000000000000 float:0.0 double:100.0;
        r21 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1));
        if (r21 < 0) goto L_0x0172;
    L_0x016b:
        r30 = r8;
        r17 = 1;
        r8 = r1;
        goto L_0x0300;
    L_0x0172:
        r4 = (r10 > r7 ? 1 : (r10 == r7 ? 0 : -1));
        if (r4 >= 0) goto L_0x0178;
    L_0x0176:
        r4 = 0;
        goto L_0x017e;
    L_0x0178:
        r4 = 1135869952; // 0x43b40000 float:360.0 double:5.611943214E-315;
        r4 = java.lang.Math.min(r4, r10);
    L_0x017e:
        r10 = r0;
        r5 = 0;
        r19 = 1;
        r20 = 0;
    L_0x0184:
        r22 = r20 - r0;
        r22 = java.lang.Math.abs(r22);
        r23 = 1053609165; // 0x3ecccccd float:0.4 double:5.205520926E-315;
        r22 = (r22 > r23 ? 1 : (r22 == r23 ? 0 : -1));
        if (r22 < 0) goto L_0x02e4;
    L_0x0191:
        r22 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r23 = 1148846080; // 0x447a0000 float:1000.0 double:5.676053805E-315;
        r24 = 0;
        r25 = 1120403456; // 0x42c80000 float:100.0 double:5.53552857E-315;
        r26 = 0;
    L_0x019b:
        r27 = r24 - r25;
        r27 = java.lang.Math.abs(r27);
        r28 = 1008981770; // 0x3c23d70a float:0.01 double:4.9850323E-315;
        r29 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r27 = (r27 > r28 ? 1 : (r27 == r28 ? 0 : -1));
        if (r27 <= 0) goto L_0x0297;
    L_0x01aa:
        r27 = r25 - r24;
        r27 = r27 / r29;
        r15 = r24 + r27;
        r7 = android.support.p000v4.content.res.CamColor.fromJch(r15, r10, r4);
        r2 = android.support.p000v4.content.res.ViewingConditions.DEFAULT;
        r2 = r7.viewed(r2);
        r7 = android.graphics.Color.red(r2);
        r7 = android.support.p000v4.content.res.CamUtils.linearized(r7);
        r30 = android.graphics.Color.green(r2);
        r30 = android.support.p000v4.content.res.CamUtils.linearized(r30);
        r31 = android.graphics.Color.blue(r2);
        r31 = android.support.p000v4.content.res.CamUtils.linearized(r31);
        r32 = android.support.p000v4.content.res.CamUtils.SRGB_TO_XYZ;
        r17 = 1;
        r32 = r32[r17];
        r18 = 0;
        r33 = r32[r18];
        r7 = r7 * r33;
        r33 = r32[r17];
        r30 = r30 * r33;
        r7 = r7 + r30;
        r16 = 2;
        r30 = r32[r16];
        r31 = r31 * r30;
        r7 = r7 + r31;
        r28 = 1120403456; // 0x42c80000 float:100.0 double:5.53552857E-315;
        r7 = r7 / r28;
        r30 = 1007753895; // 0x3c111aa7 float:0.008856452 double:4.97896579E-315;
        r30 = (r7 > r30 ? 1 : (r7 == r30 ? 0 : -1));
        if (r30 > 0) goto L_0x01ff;
    L_0x01f7:
        r30 = 1147261687; // 0x4461d2f7 float:903.2963 double:5.668225863E-315;
        r7 = r7 * r30;
        r30 = r8;
        goto L_0x020e;
    L_0x01ff:
        r30 = r8;
        r7 = (double) r7;
        r7 = java.lang.Math.cbrt(r7);
        r7 = (float) r7;
        r8 = 1122500608; // 0x42e80000 float:116.0 double:5.54588988E-315;
        r7 = r7 * r8;
        r8 = -1048576000; // 0xffffffffc1800000 float:-16.0 double:NaN;
        r7 = r7 + r8;
    L_0x020e:
        r8 = r14 - r7;
        r8 = java.lang.Math.abs(r8);
        r31 = 1045220557; // 0x3e4ccccd float:0.2 double:5.164075695E-315;
        r31 = (r8 > r31 ? 1 : (r8 == r31 ? 0 : -1));
        if (r31 >= 0) goto L_0x0269;
    L_0x021b:
        r2 = android.support.p000v4.content.res.CamColor.fromColor(r2);
        r3 = r2.f0mJ;
        r31 = r8;
        r8 = r2.mChroma;
        r3 = android.support.p000v4.content.res.CamColor.fromJch(r3, r8, r4);
        r8 = r2.mJstar;
        r32 = r4;
        r4 = r3.mJstar;
        r8 = r8 - r4;
        r4 = r2.mAstar;
        r33 = r10;
        r10 = r3.mAstar;
        r4 = r4 - r10;
        r10 = r2.mBstar;
        r3 = r3.mBstar;
        r10 = r10 - r3;
        r8 = r8 * r8;
        r4 = r4 * r4;
        r8 = r8 + r4;
        r10 = r10 * r10;
        r8 = r8 + r10;
        r3 = (double) r8;
        r3 = java.lang.Math.sqrt(r3);
        r8 = r1;
        r10 = r2;
        r1 = 4603849755075763241; // 0x3fe428f5c28f5c29 float:-71.68 double:0.63;
        r1 = java.lang.Math.pow(r3, r1);
        r3 = 4609028894647239311; // 0x3ff68f5c28f5c28f float:2.728484E-14 double:1.41;
        r1 = r1 * r3;
        r1 = (float) r1;
        r2 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r3 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1));
        if (r3 > 0) goto L_0x0270;
    L_0x0262:
        r22 = r1;
        r26 = r10;
        r23 = r31;
        goto L_0x0271;
    L_0x0269:
        r8 = r1;
        r32 = r4;
        r33 = r10;
        r2 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
    L_0x0271:
        r1 = 0;
        r3 = (r23 > r1 ? 1 : (r23 == r1 ? 0 : -1));
        if (r3 != 0) goto L_0x027d;
    L_0x0276:
        r3 = (r22 > r1 ? 1 : (r22 == r1 ? 0 : -1));
        if (r3 != 0) goto L_0x027d;
    L_0x027a:
        r3 = r26;
        goto L_0x02a9;
    L_0x027d:
        r3 = (r7 > r14 ? 1 : (r7 == r14 ? 0 : -1));
        if (r3 < 0) goto L_0x0283;
    L_0x0281:
        r25 = r15;
    L_0x0283:
        r3 = (r7 > r14 ? 1 : (r7 == r14 ? 0 : -1));
        if (r3 >= 0) goto L_0x0289;
    L_0x0287:
        r24 = r15;
    L_0x0289:
        r2 = r36;
        r3 = r37;
        r1 = r8;
        r8 = r30;
        r4 = r32;
        r10 = r33;
        r7 = 0;
        goto L_0x019b;
    L_0x0297:
        r32 = r4;
        r30 = r8;
        r33 = r10;
        r2 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r16 = 2;
        r17 = 1;
        r28 = 1120403456; // 0x42c80000 float:100.0 double:5.53552857E-315;
        r8 = r1;
        r1 = 0;
        r3 = r26;
    L_0x02a9:
        if (r19 == 0) goto L_0x02c7;
    L_0x02ab:
        if (r3 == 0) goto L_0x02b3;
    L_0x02ad:
        r0 = r3.viewed(r12);
        goto L_0x030b;
    L_0x02b3:
        r3 = r0 - r20;
        r3 = r3 / r29;
        r10 = r20 + r3;
        r2 = r36;
        r3 = r37;
        r1 = r8;
        r8 = r30;
        r4 = r32;
        r7 = 0;
        r19 = 0;
        goto L_0x0184;
    L_0x02c7:
        if (r3 == 0) goto L_0x02ca;
    L_0x02c9:
        r5 = r3;
    L_0x02ca:
        if (r3 == 0) goto L_0x02ce;
    L_0x02cc:
        r20 = r33;
    L_0x02ce:
        if (r3 != 0) goto L_0x02d2;
    L_0x02d0:
        r0 = r33;
    L_0x02d2:
        r3 = r0 - r20;
        r3 = r3 / r29;
        r10 = r20 + r3;
        r2 = r36;
        r3 = r37;
        r1 = r8;
        r8 = r30;
        r4 = r32;
        r7 = 0;
        goto L_0x0184;
    L_0x02e4:
        r30 = r8;
        r17 = 1;
        r8 = r1;
        if (r5 != 0) goto L_0x02f0;
    L_0x02eb:
        r0 = android.support.p000v4.content.res.CamUtils.intFromLStar(r14);
        goto L_0x030b;
    L_0x02f0:
        r0 = r5.viewed(r12);
        goto L_0x030b;
    L_0x02f5:
        r30 = r8;
        r17 = 1;
        r8 = r1;
        goto L_0x0300;
    L_0x02fb:
        r30 = r8;
        r17 = 1;
        r8 = r1;
    L_0x0300:
        r0 = android.support.p000v4.content.res.CamUtils.intFromLStar(r14);
        goto L_0x030b;
    L_0x0305:
        r13 = r5;
        r30 = r8;
        r17 = 1;
        r8 = r1;
    L_0x030b:
        r1 = 16777215; // 0xffffff float:2.3509886E-38 double:8.2890456E-317;
        r0 = r0 & r1;
        r1 = r11 << 24;
        r0 = r0 | r1;
    L_0x0312:
        r1 = r9 + 1;
        r2 = r6.length;
        if (r1 <= r2) goto L_0x0322;
    L_0x0317:
        r2 = android.support.p000v4.content.res.GrowingArrayUtils.growSize(r9);
        r2 = new int[r2];
        r3 = 0;
        java.lang.System.arraycopy(r6, r3, r2, r3, r9);
        r6 = r2;
    L_0x0322:
        r6[r9] = r0;
        r2 = r30;
        r0 = r2.length;
        if (r1 <= r0) goto L_0x0340;
    L_0x0329:
        r0 = r2.getClass();
        r0 = r0.getComponentType();
        r3 = android.support.p000v4.content.res.GrowingArrayUtils.growSize(r9);
        r0 = java.lang.reflect.Array.newInstance(r0, r3);
        r0 = (java.lang.Object[]) r0;
        r3 = 0;
        java.lang.System.arraycopy(r2, r3, r0, r3, r9);
        goto L_0x0341;
    L_0x0340:
        r0 = r2;
    L_0x0341:
        r0[r9] = r8;
        r8 = r0;
        r8 = (int[][]) r8;
        r2 = r36;
        r3 = r37;
        r9 = r1;
        r5 = r13;
        r4 = 1;
        r7 = 0;
        r1 = r34;
        goto L_0x0023;
    L_0x0352:
        r13 = r5;
        r2 = r8;
        r17 = 1;
        goto L_0x035b;
    L_0x0357:
        r13 = r5;
        r2 = r8;
        r17 = 1;
    L_0x035b:
        r1 = r34;
        r3 = r37;
        r8 = r2;
        r5 = r13;
        r4 = 1;
        r7 = 0;
        r2 = r36;
        goto L_0x0023;
    L_0x0367:
        r2 = r8;
    L_0x0368:
        r0 = new int[r9];
        r1 = new int[r9][];
        r3 = 0;
        java.lang.System.arraycopy(r6, r3, r0, r3, r9);
        java.lang.System.arraycopy(r2, r3, r1, r3, r9);
        r2 = new android.content.res.ColorStateList;
        r2.<init>(r1, r0);
        return r2;
    L_0x0379:
        r1 = new org.xmlpull.v1.XmlPullParserException;
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = r35.getPositionDescription();
        r2.append(r3);
        r3 = ": invalid color state list tag ";
        r2.append(r3);
        r2.append(r0);
        r0 = r2.toString();
        r1.<init>(r0);
        goto L_0x0398;
    L_0x0397:
        throw r1;
    L_0x0398:
        goto L_0x0397;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.content.res.ColorStateListInflaterCompat.createFromXmlInner(android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):android.content.res.ColorStateList");
    }

    public static ColorStateList inflate(Resources resources, int i, Theme theme) {
        try {
            return ColorStateListInflaterCompat.createFromXml(resources, resources.getXml(i), theme);
        } catch (Throwable e) {
            Log.e("CSLCompat", "Failed to inflate ColorStateList.", e);
            return null;
        }
    }
}
