package android.support.p000v4.content;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Binder;
import android.os.Process;
import androidx.core.app.AppOpsManagerCompat$Api29Impl;
import p020j$.util.Objects;

/* compiled from: PG */
/* renamed from: android.support.v4.content.PermissionChecker */
public final class PermissionChecker {
    public static int checkSelfPermission(Context context, String str) {
        int myPid = Process.myPid();
        int myUid = Process.myUid();
        String packageName = context.getPackageName();
        int i = 0;
        if (context.checkPermission(str, myPid, myUid) == -1) {
            i = -1;
        } else {
            str = AppOpsManager.permissionToOp(str);
            if (str != null) {
                int checkOpNoThrow;
                if (packageName == null) {
                    String[] packagesForUid = context.getPackageManager().getPackagesForUid(myUid);
                    if (packagesForUid == null) {
                        i = -1;
                    } else if (packagesForUid.length <= 0) {
                        i = -1;
                    } else {
                        packageName = packagesForUid[0];
                    }
                }
                myPid = Process.myUid();
                String packageName2 = context.getPackageName();
                if (myPid == myUid && Objects.equals(packageName2, packageName)) {
                    AppOpsManager systemService = AppOpsManagerCompat$Api29Impl.getSystemService(context);
                    checkOpNoThrow = AppOpsManagerCompat$Api29Impl.checkOpNoThrow(systemService, str, Binder.getCallingUid(), packageName);
                    if (checkOpNoThrow == 0) {
                        checkOpNoThrow = AppOpsManagerCompat$Api29Impl.checkOpNoThrow(systemService, str, myUid, AppOpsManagerCompat$Api29Impl.getOpPackageName(context));
                    }
                } else {
                    checkOpNoThrow = ((AppOpsManager) context.getSystemService(AppOpsManager.class)).noteProxyOpNoThrow(str, packageName);
                }
                if (checkOpNoThrow == 0) {
                    return 0;
                }
                i = -2;
            }
        }
        return i;
    }
}
