package android.support.p000v4.p001os;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* compiled from: PG */
/* renamed from: android.support.v4.os.IResultReceiver */
public interface IResultReceiver extends IInterface {

    /* compiled from: PG */
    /* renamed from: android.support.v4.os.IResultReceiver$Stub */
    public abstract class Stub extends Binder implements IResultReceiver {

        /* compiled from: PG */
        /* renamed from: android.support.v4.os.IResultReceiver$Stub$Proxy */
        final class Proxy implements IResultReceiver {
            private final IBinder mRemote;

            public Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            public final IBinder asBinder() {
                return this.mRemote;
            }

            public final void send$ar$ds() {
                throw null;
            }
        }

        public Stub() {
            attachInterface(this, "android.support.v4.os.IResultReceiver");
        }

        public final IBinder asBinder() {
            return this;
        }

        public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
            String str = "android.support.v4.os.IResultReceiver";
            switch (i) {
                case 1:
                    parcel.enforceInterface(str);
                    parcel.readInt();
                    if (parcel.readInt() != 0) {
                        Bundle bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                    }
                    send$ar$ds();
                    return true;
                case 1598968902:
                    parcel2.writeString(str);
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void send$ar$ds();
}
