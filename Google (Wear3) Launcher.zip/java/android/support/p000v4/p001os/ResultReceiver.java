package android.support.p000v4.p001os;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p000v4.p001os.IResultReceiver.Stub;
import android.support.p000v4.p001os.IResultReceiver.Stub.Proxy;

/* compiled from: PG */
/* renamed from: android.support.v4.os.ResultReceiver */
public class ResultReceiver implements Parcelable {
    public static final Creator CREATOR = new PG();
    IResultReceiver mReceiver;

    /* renamed from: android.support.v4.os.ResultReceiver$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new ResultReceiver[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new ResultReceiver(parcel);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.os.ResultReceiver$MyResultReceiver */
    final class MyResultReceiver extends Stub {
        public final void send$ar$ds() {
            ResultReceiver.this.onReceiveResult$ar$ds();
        }
    }

    public ResultReceiver(Parcel parcel) {
        IResultReceiver iResultReceiver;
        IBinder readStrongBinder = parcel.readStrongBinder();
        if (readStrongBinder == null) {
            iResultReceiver = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("android.support.v4.os.IResultReceiver");
            if (queryLocalInterface == null || !(queryLocalInterface instanceof IResultReceiver)) {
                iResultReceiver = new Proxy(readStrongBinder);
            } else {
                iResultReceiver = (IResultReceiver) queryLocalInterface;
            }
        }
        this.mReceiver = iResultReceiver;
    }

    public final int describeContents() {
        return 0;
    }

    protected void onReceiveResult$ar$ds() {
    }

    public final void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            if (this.mReceiver == null) {
                this.mReceiver = new MyResultReceiver();
            }
            parcel.writeStrongBinder(this.mReceiver.asBinder());
        }
    }
}
