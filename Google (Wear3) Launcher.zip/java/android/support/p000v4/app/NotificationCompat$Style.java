package android.support.p000v4.app;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationCompat$Style */
public class NotificationCompat$Style {
    protected NotificationCompat$Builder mBuilder;

    public void apply(NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
        throw null;
    }

    protected String getClassName() {
        throw null;
    }
}
