package android.support.p000v4.app;

import android.support.p000v4.app.Fragment.InstantiationException;
import androidx.collection.SimpleArrayMap;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentFactory */
public class FragmentFactory {
    private static final SimpleArrayMap sClassCacheMap = new SimpleArrayMap();

    static boolean isFragmentClass(ClassLoader classLoader, String str) {
        try {
            return Fragment.class.isAssignableFrom(FragmentFactory.loadClass(classLoader, str));
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    private static Class loadClass(ClassLoader classLoader, String str) {
        SimpleArrayMap simpleArrayMap = sClassCacheMap;
        SimpleArrayMap simpleArrayMap2 = (SimpleArrayMap) simpleArrayMap.get(classLoader);
        if (simpleArrayMap2 == null) {
            simpleArrayMap2 = new SimpleArrayMap();
            simpleArrayMap.put(classLoader, simpleArrayMap2);
        }
        Class cls = (Class) simpleArrayMap2.get(str);
        if (cls != null) {
            return cls;
        }
        Class cls2 = Class.forName(str, false, classLoader);
        simpleArrayMap2.put(str, cls2);
        return cls2;
    }

    public static Class loadFragmentClass(ClassLoader classLoader, String str) {
        StringBuilder stringBuilder;
        String str2 = "Unable to instantiate fragment ";
        try {
            return FragmentFactory.loadClass(classLoader, str);
        } catch (Exception e) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str2);
            stringBuilder.append(str);
            stringBuilder.append(": make sure class name exists");
            throw new InstantiationException(stringBuilder.toString(), e);
        } catch (Exception e2) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str2);
            stringBuilder.append(str);
            stringBuilder.append(": make sure class is a valid subclass of Fragment");
            throw new InstantiationException(stringBuilder.toString(), e2);
        }
    }

    public Fragment instantiate$ar$ds$540c62b6_0(String str) {
        throw null;
    }
}
