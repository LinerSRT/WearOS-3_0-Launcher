package android.support.p000v4.app;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider.Factory;
import android.arch.lifecycle.ViewModelStore;
import android.util.Log;
import java.util.HashMap;
import java.util.Iterator;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentManagerViewModel */
final class FragmentManagerViewModel extends ViewModel {
    public static final Factory FACTORY = new PG();
    public final HashMap mChildNonConfigs = new HashMap();
    public boolean mHasBeenCleared = false;
    public boolean mIsStateSaved = false;
    public final HashMap mRetainedFragments = new HashMap();
    public final boolean mStateAutomaticallySaved;
    public final HashMap mViewModelStores = new HashMap();

    /* renamed from: android.support.v4.app.FragmentManagerViewModel$1 */
    final class PG implements Factory {
        public final ViewModel create(Class cls) {
            return new FragmentManagerViewModel(true);
        }
    }

    public FragmentManagerViewModel(boolean z) {
        this.mStateAutomaticallySaved = z;
    }

    final void clearNonConfigState(Fragment fragment) {
        if (FragmentManager.isLoggingEnabled(3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Clearing non-config state for ");
            stringBuilder.append(fragment);
            Log.d("FragmentManager", stringBuilder.toString());
        }
        clearNonConfigStateInternal(fragment.mWho);
    }

    public final void clearNonConfigStateInternal(String str) {
        FragmentManagerViewModel fragmentManagerViewModel = (FragmentManagerViewModel) this.mChildNonConfigs.get(str);
        if (fragmentManagerViewModel != null) {
            fragmentManagerViewModel.onCleared();
            this.mChildNonConfigs.remove(str);
        }
        ViewModelStore viewModelStore = (ViewModelStore) this.mViewModelStores.get(str);
        if (viewModelStore != null) {
            viewModelStore.clear();
            this.mViewModelStores.remove(str);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (getClass() == obj.getClass()) {
                FragmentManagerViewModel fragmentManagerViewModel = (FragmentManagerViewModel) obj;
                return this.mRetainedFragments.equals(fragmentManagerViewModel.mRetainedFragments) && this.mChildNonConfigs.equals(fragmentManagerViewModel.mChildNonConfigs) && this.mViewModelStores.equals(fragmentManagerViewModel.mViewModelStores);
            }
        }
        return false;
    }

    public final int hashCode() {
        return (((this.mRetainedFragments.hashCode() * 31) + this.mChildNonConfigs.hashCode()) * 31) + this.mViewModelStores.hashCode();
    }

    protected final void onCleared() {
        if (FragmentManager.isLoggingEnabled(3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onCleared called for ");
            stringBuilder.append(this);
            Log.d("FragmentManager", stringBuilder.toString());
        }
        this.mHasBeenCleared = true;
    }

    final void removeRetainedFragment(Fragment fragment) {
        String str = "FragmentManager";
        if (this.mIsStateSaved) {
            if (FragmentManager.isLoggingEnabled(2)) {
                Log.v(str, "Ignoring removeRetainedFragment as the state is already saved");
            }
            return;
        }
        if (this.mRetainedFragments.remove(fragment.mWho) != null && FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Updating retained Fragments: Removed ");
            stringBuilder.append(fragment);
            Log.v(str, stringBuilder.toString());
        }
    }

    final boolean shouldDestroy(Fragment fragment) {
        return (this.mRetainedFragments.containsKey(fragment.mWho) && this.mStateAutomaticallySaved) ? this.mHasBeenCleared : true;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("FragmentManagerViewModel{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append("} Fragments (");
        Iterator it = this.mRetainedFragments.values().iterator();
        while (true) {
            String str = ", ";
            if (!it.hasNext()) {
                break;
            }
            stringBuilder.append(it.next());
            if (it.hasNext()) {
                stringBuilder.append(str);
            }
        }
        stringBuilder.append(") Child Non Config (");
        it = this.mChildNonConfigs.keySet().iterator();
        while (it.hasNext()) {
            stringBuilder.append((String) it.next());
            if (it.hasNext()) {
                stringBuilder.append(str);
            }
        }
        stringBuilder.append(") ViewModelStores (");
        it = this.mViewModelStores.keySet().iterator();
        while (it.hasNext()) {
            stringBuilder.append((String) it.next());
            if (it.hasNext()) {
                stringBuilder.append(str);
            }
        }
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}
