package android.support.p000v4.app;

import android.arch.lifecycle.HasDefaultViewModelProviderFactory;
import android.arch.lifecycle.ViewModelProvider.Factory;
import android.arch.lifecycle.ViewModelStore;
import android.arch.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.Lifecycle.Event;
import androidx.lifecycle.LifecycleRegistry;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.SavedStateRegistryController;
import androidx.savedstate.SavedStateRegistryOwner;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentViewLifecycleOwner */
final class FragmentViewLifecycleOwner implements HasDefaultViewModelProviderFactory, SavedStateRegistryOwner, ViewModelStoreOwner {
    private final Fragment mFragment;
    public LifecycleRegistry mLifecycleRegistry = null;
    public SavedStateRegistryController mSavedStateRegistryController = null;
    private final ViewModelStore mViewModelStore;

    public FragmentViewLifecycleOwner(Fragment fragment, ViewModelStore viewModelStore) {
        this.mFragment = fragment;
        this.mViewModelStore = viewModelStore;
    }

    public final Factory getDefaultViewModelProviderFactory() {
        throw null;
    }

    public final Lifecycle getLifecycle() {
        initialize();
        return this.mLifecycleRegistry;
    }

    public final SavedStateRegistry getSavedStateRegistry() {
        initialize();
        return this.mSavedStateRegistryController.mRegistry;
    }

    public final ViewModelStore getViewModelStore() {
        initialize();
        return this.mViewModelStore;
    }

    final void handleLifecycleEvent(Event event) {
        this.mLifecycleRegistry.handleLifecycleEvent(event);
    }

    final void initialize() {
        if (this.mLifecycleRegistry == null) {
            this.mLifecycleRegistry = new LifecycleRegistry(this);
            this.mSavedStateRegistryController = SavedStateRegistryController.create(this);
        }
    }
}
