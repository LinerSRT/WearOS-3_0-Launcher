package android.support.p000v4.app;

import android.app.PendingIntent;
import android.support.p000v4.graphics.drawable.IconCompat;
import androidx.versionedparcelable.VersionedParcelable;

/* compiled from: PG */
/* renamed from: android.support.v4.app.RemoteActionCompat */
public final class RemoteActionCompat implements VersionedParcelable {
    public PendingIntent mActionIntent;
    public CharSequence mContentDescription;
    public boolean mEnabled;
    public IconCompat mIcon;
    public boolean mShouldShowIcon;
    public CharSequence mTitle;
}
