package android.support.p000v4.app;

import java.util.HashSet;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationManagerCompat */
public final class NotificationManagerCompat {
    public static final /* synthetic */ int NotificationManagerCompat$ar$NoOp = 0;

    static {
        HashSet hashSet = new HashSet();
    }
}
