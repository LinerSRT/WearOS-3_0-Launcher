package android.support.p000v4.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.support.fragment.R$styleable;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentContainerView */
public final class FragmentContainerView extends FrameLayout {
    private OnApplyWindowInsetsListener applyWindowInsetsListener;
    private final List disappearingFragmentChildren = new ArrayList();
    public boolean drawDisappearingViewsFirst = true;
    private final List transitioningFragmentViews = new ArrayList();

    public FragmentContainerView(Context context, AttributeSet attributeSet, FragmentManager fragmentManager) {
        context.getClass();
        attributeSet.getClass();
        super(context, attributeSet);
        String classAttribute = attributeSet.getClassAttribute();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.FragmentContainerView, 0, 0);
        if (classAttribute == null) {
            classAttribute = obtainStyledAttributes.getString(0);
        }
        String string = obtainStyledAttributes.getString(1);
        obtainStyledAttributes.recycle();
        int id = getId();
        Fragment findFragmentById = fragmentManager.findFragmentById(id);
        if (classAttribute != null && findFragmentById == null) {
            if (id <= 0) {
                String stringPlus;
                if (string != null) {
                    stringPlus = Intrinsics.stringPlus(" with tag ", string);
                } else {
                    stringPlus = "";
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("FragmentContainerView must have an android:id to add Fragment ");
                stringBuilder.append(classAttribute);
                stringBuilder.append(stringPlus);
                throw new IllegalStateException(stringBuilder.toString());
            }
            FragmentFactory fragmentFactory = fragmentManager.getFragmentFactory();
            context.getClassLoader();
            Fragment instantiate$ar$ds$540c62b6_0 = fragmentFactory.instantiate$ar$ds$540c62b6_0(classAttribute);
            instantiate$ar$ds$540c62b6_0.getClass();
            instantiate$ar$ds$540c62b6_0.onInflate$ar$ds();
            Object beginTransaction = fragmentManager.beginTransaction();
            beginTransaction.mReorderingAllowed = true;
            instantiate$ar$ds$540c62b6_0.mContainer = this;
            beginTransaction.add$ar$ds(getId(), instantiate$ar$ds$540c62b6_0, string);
            beginTransaction.disallowAddToBackStack$ar$ds();
            ((BackStackRecord) beginTransaction).mManager.execSingleAction(beginTransaction, true);
        }
        for (FragmentStateManager fragmentStateManager : fragmentManager.mFragmentStore.getActiveFragmentStateManagers()) {
            Fragment fragment = fragmentStateManager.mFragment;
            if (fragment.mContainerId == getId()) {
                View view = fragment.mView;
                if (view != null && view.getParent() == null) {
                    fragment.mContainer = this;
                    fragmentStateManager.addViewToContainer();
                }
            }
        }
    }

    private final void addDisappearingFragmentView(View view) {
        if (this.transitioningFragmentViews.contains(view)) {
            this.disappearingFragmentChildren.add(view);
        }
    }

    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        windowInsets.getClass();
        WindowInsetsCompat toWindowInsetsCompat = WindowInsetsCompat.toWindowInsetsCompat(windowInsets);
        OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.applyWindowInsetsListener;
        if (onApplyWindowInsetsListener != null) {
            WindowInsets onApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            onApplyWindowInsets.getClass();
            toWindowInsetsCompat = WindowInsetsCompat.toWindowInsetsCompat(onApplyWindowInsets);
        } else {
            toWindowInsetsCompat = ViewCompat.onApplyWindowInsets(this, toWindowInsetsCompat);
        }
        if (!toWindowInsetsCompat.isConsumed()) {
            int childCount = getChildCount();
            if (childCount > 0) {
                int i = 0;
                while (true) {
                    int i2 = i + 1;
                    ViewCompat.dispatchApplyWindowInsets(getChildAt(i), toWindowInsetsCompat);
                    if (i2 >= childCount) {
                        break;
                    }
                    i = i2;
                }
            }
        }
        return windowInsets;
    }

    protected final void dispatchDraw(Canvas canvas) {
        canvas.getClass();
        if (this.drawDisappearingViewsFirst) {
            for (View drawChild : this.disappearingFragmentChildren) {
                super.drawChild(canvas, drawChild, getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    protected final boolean drawChild(Canvas canvas, View view, long j) {
        canvas.getClass();
        view.getClass();
        if (this.drawDisappearingViewsFirst && !this.disappearingFragmentChildren.isEmpty() && this.disappearingFragmentChildren.contains(view)) {
            return false;
        }
        return super.drawChild(canvas, view, j);
    }

    public final void endViewTransition(View view) {
        view.getClass();
        this.transitioningFragmentViews.remove(view);
        if (this.disappearingFragmentChildren.remove(view)) {
            this.drawDisappearingViewsFirst = true;
        }
        super.endViewTransition(view);
    }

    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        windowInsets.getClass();
        return windowInsets;
    }

    public final void removeAllViewsInLayout() {
        int childCount = getChildCount() - 1;
        if (childCount >= 0) {
            while (true) {
                int i = childCount - 1;
                View childAt = getChildAt(childCount);
                childAt.getClass();
                addDisappearingFragmentView(childAt);
                if (i < 0) {
                    break;
                }
                childCount = i;
            }
        }
        super.removeAllViewsInLayout();
    }

    public final void removeView(View view) {
        view.getClass();
        addDisappearingFragmentView(view);
        super.removeView(view);
    }

    public final void removeViewAt(int i) {
        View childAt = getChildAt(i);
        childAt.getClass();
        addDisappearingFragmentView(childAt);
        super.removeViewAt(i);
    }

    public final void removeViewInLayout(View view) {
        view.getClass();
        addDisappearingFragmentView(view);
        super.removeViewInLayout(view);
    }

    public final void removeViews(int i, int i2) {
        int i3 = i + i2;
        if (i < i3) {
            int i4 = i;
            while (true) {
                int i5 = i4 + 1;
                View childAt = getChildAt(i4);
                childAt.getClass();
                addDisappearingFragmentView(childAt);
                if (i5 >= i3) {
                    break;
                }
                i4 = i5;
            }
        }
        super.removeViews(i, i2);
    }

    public final void removeViewsInLayout(int i, int i2) {
        int i3 = i + i2;
        if (i < i3) {
            int i4 = i;
            while (true) {
                int i5 = i4 + 1;
                View childAt = getChildAt(i4);
                childAt.getClass();
                addDisappearingFragmentView(childAt);
                if (i5 >= i3) {
                    break;
                }
                i4 = i5;
            }
        }
        super.removeViewsInLayout(i, i2);
    }

    public final void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    public final void setOnApplyWindowInsetsListener(OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        onApplyWindowInsetsListener.getClass();
        this.applyWindowInsetsListener = onApplyWindowInsetsListener;
    }

    public final void startViewTransition(View view) {
        view.getClass();
        if (view.getParent() == this) {
            this.transitioningFragmentViews.add(view);
        }
        super.startViewTransition(view);
    }

    public final void addView(View view, int i, LayoutParams layoutParams) {
        Fragment fragment;
        view.getClass();
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if (tag instanceof Fragment) {
            fragment = (Fragment) tag;
        } else {
            fragment = null;
        }
        if (fragment != null) {
            super.addView(view, i, layoutParams);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
        stringBuilder.append(view);
        stringBuilder.append(" is not associated with a Fragment.");
        throw new IllegalStateException(stringBuilder.toString().toString());
    }
}
