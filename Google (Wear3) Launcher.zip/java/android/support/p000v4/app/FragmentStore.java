package android.support.p000v4.app;

import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentStore */
final class FragmentStore {
    public final HashMap mActive = new HashMap();
    public final ArrayList mAdded = new ArrayList();
    public FragmentManagerViewModel mNonConfig;
    public final HashMap mSavedState = new HashMap();

    final void addFragment(Fragment fragment) {
        if (this.mAdded.contains(fragment)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Fragment already added: ");
            stringBuilder.append(fragment);
            throw new IllegalStateException(stringBuilder.toString());
        }
        synchronized (this.mAdded) {
            this.mAdded.add(fragment);
        }
        fragment.mAdded = true;
    }

    final void burpActive() {
        this.mActive.values().removeAll(Collections.singleton(null));
    }

    final boolean containsActiveFragment(String str) {
        return this.mActive.get(str) != null;
    }

    final Fragment findActiveFragment(String str) {
        FragmentStateManager fragmentStateManager = (FragmentStateManager) this.mActive.get(str);
        return fragmentStateManager != null ? fragmentStateManager.mFragment : null;
    }

    final Fragment findFragmentByWho(String str) {
        for (FragmentStateManager fragmentStateManager : this.mActive.values()) {
            if (fragmentStateManager != null) {
                Fragment fragment = fragmentStateManager.mFragment;
                if (!str.equals(fragment.mWho)) {
                    fragment = fragment.mChildFragmentManager.mFragmentStore.findFragmentByWho(str);
                }
                if (fragment != null) {
                    return fragment;
                }
            }
        }
        return null;
    }

    final List getActiveFragmentStateManagers() {
        List arrayList = new ArrayList();
        for (FragmentStateManager fragmentStateManager : this.mActive.values()) {
            if (fragmentStateManager != null) {
                arrayList.add(fragmentStateManager);
            }
        }
        return arrayList;
    }

    final FragmentStateManager getFragmentStateManager(String str) {
        return (FragmentStateManager) this.mActive.get(str);
    }

    final List getFragments() {
        if (this.mAdded.isEmpty()) {
            return Collections.emptyList();
        }
        List arrayList;
        synchronized (this.mAdded) {
            arrayList = new ArrayList(this.mAdded);
        }
        return arrayList;
    }

    final void makeActive(FragmentStateManager fragmentStateManager) {
        Fragment fragment = fragmentStateManager.mFragment;
        if (!containsActiveFragment(fragment.mWho)) {
            this.mActive.put(fragment.mWho, fragmentStateManager);
            boolean z = fragment.mRetainInstanceChangedWhileDetached;
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Added fragment to active set ");
                stringBuilder.append(fragment);
                Log.v("FragmentManager", stringBuilder.toString());
            }
        }
    }

    final void makeInactive(FragmentStateManager fragmentStateManager) {
        Fragment fragment = fragmentStateManager.mFragment;
        if (fragment.mRetainInstance) {
            this.mNonConfig.removeRetainedFragment(fragment);
        }
        if (((FragmentStateManager) this.mActive.put(fragment.mWho, null)) != null && FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Removed fragment from active set ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
        }
    }

    final void removeFragment(Fragment fragment) {
        synchronized (this.mAdded) {
            this.mAdded.remove(fragment);
        }
        fragment.mAdded = false;
    }

    final FragmentState setSavedState(String str, FragmentState fragmentState) {
        if (fragmentState != null) {
            return (FragmentState) this.mSavedState.put(str, fragmentState);
        }
        return (FragmentState) this.mSavedState.remove(str);
    }
}
