package android.support.p000v4.app;

import android.app.Activity;
import android.os.Bundle;
import android.support.p000v4.view.KeyEventDispatcher;
import android.support.p000v4.view.KeyEventDispatcher.Component;
import android.support.p000v4.view.ViewCompat;
import android.view.KeyEvent;
import androidx.collection.SimpleArrayMap;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.Lifecycle.State;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.ReportFragment;

/* compiled from: PG */
/* renamed from: android.support.v4.app.SupportActivity */
public class SupportActivity extends Activity implements LifecycleOwner, Component {
    private final LifecycleRegistry mLifecycleRegistry = new LifecycleRegistry(this);

    public SupportActivity() {
        SimpleArrayMap simpleArrayMap = new SimpleArrayMap();
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (getWindow().getDecorView() != null) {
            int i = ViewCompat.ViewCompat$ar$NoOp;
        }
        return KeyEventDispatcher.dispatchKeyEvent$ar$ds(this, keyEvent);
    }

    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        if (getWindow().getDecorView() != null) {
            int i = ViewCompat.ViewCompat$ar$NoOp;
        }
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    public Lifecycle getLifecycle() {
        return this.mLifecycleRegistry;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ReportFragment.injectIfNeededIn(this);
    }

    protected void onSaveInstanceState(Bundle bundle) {
        LifecycleRegistry lifecycleRegistry = this.mLifecycleRegistry;
        State state = State.CREATED;
        LifecycleRegistry.enforceMainThreadIfNeeded$ar$ds("markState");
        lifecycleRegistry.setCurrentState(state);
        super.onSaveInstanceState(bundle);
    }

    public final boolean superDispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }
}
