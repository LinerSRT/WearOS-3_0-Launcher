package android.support.p000v4.app;

import android.app.Dialog;
import android.arch.lifecycle.ViewTreeLifecycleOwner;
import android.arch.lifecycle.ViewTreeViewModelStoreOwner;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.p000v4.app.Fragment;
import android.support.p000v4.app.FragmentManager;
import android.support.p000v4.app.FragmentManager.PopBackStackState;
import android.support.p000v4.app.FragmentTransaction.PG;
import android.support.v4.app.DialogFragment.C00572;
import android.support.v4.app.DialogFragment.C00583;
import android.support.v4.app.DialogFragment.C00594;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import androidx.savedstate.ViewTreeSavedStateRegistryOwner;

/* compiled from: PG */
/* renamed from: android.support.v4.app.DialogFragment */
public class DialogFragment extends Fragment implements OnCancelListener, OnDismissListener {
    private int mBackStackId = -1;
    private boolean mCancelable = true;
    private boolean mCreatingDialog;
    public Dialog mDialog;
    public boolean mDialogCreated = false;
    private final Runnable mDismissRunnable = new PG();
    private boolean mDismissed;
    private Handler mHandler;
    private final Observer mObserver = new C00594();
    private final OnCancelListener mOnCancelListener = new C00572();
    public final OnDismissListener mOnDismissListener = new C00583();
    private boolean mShownByMe;
    public boolean mShowsDialog = true;
    private int mStyle = 0;
    public int mTheme = 0;
    private boolean mViewDestroyed;

    /* renamed from: android.support.v4.app.DialogFragment$1 */
    final class PG implements Runnable {
        public final void run() {
            DialogFragment dialogFragment = DialogFragment.this;
            dialogFragment.mOnDismissListener.onDismiss(dialogFragment.mDialog);
        }
    }

    /* renamed from: android.support.v4.app.DialogFragment$2 */
    final class C00572 implements OnCancelListener {
        public final void onCancel(DialogInterface dialogInterface) {
            android.support.p000v4.app.DialogFragment dialogFragment = android.support.p000v4.app.DialogFragment.this;
            DialogInterface dialogInterface2 = dialogFragment.mDialog;
            if (dialogInterface2 != null) {
                dialogFragment.onCancel(dialogInterface2);
            }
        }
    }

    /* renamed from: android.support.v4.app.DialogFragment$3 */
    final class C00583 implements OnDismissListener {
        public final void onDismiss(DialogInterface dialogInterface) {
            android.support.p000v4.app.DialogFragment dialogFragment = android.support.p000v4.app.DialogFragment.this;
            DialogInterface dialogInterface2 = dialogFragment.mDialog;
            if (dialogInterface2 != null) {
                dialogFragment.onDismiss(dialogInterface2);
            }
        }
    }

    /* renamed from: android.support.v4.app.DialogFragment$4 */
    final class C00594 implements Observer {
        public final /* bridge */ /* synthetic */ void onChanged(Object obj) {
            if (((LifecycleOwner) obj) != null) {
                Fragment fragment = android.support.p000v4.app.DialogFragment.this;
                if (fragment.mShowsDialog) {
                    View requireView = fragment.requireView();
                    if (requireView.getParent() != null) {
                        throw new IllegalStateException("DialogFragment can not be attached to a container view");
                    } else if (android.support.p000v4.app.DialogFragment.this.mDialog != null) {
                        if (FragmentManager.isLoggingEnabled(3)) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("DialogFragment ");
                            stringBuilder.append(this);
                            stringBuilder.append(" setting the content view on ");
                            stringBuilder.append(android.support.p000v4.app.DialogFragment.this.mDialog);
                            Log.d("FragmentManager", stringBuilder.toString());
                        }
                        android.support.p000v4.app.DialogFragment.this.mDialog.setContentView(requireView);
                    }
                }
            }
        }
    }

    public final FragmentContainer createFragmentContainer() {
        final FragmentContainer createFragmentContainer = super.createFragmentContainer();
        return new FragmentContainer() {
            public final View onFindViewById(int i) {
                if (createFragmentContainer.onHasView()) {
                    return createFragmentContainer.onFindViewById(i);
                }
                Dialog dialog = android.support.p000v4.app.DialogFragment.this.mDialog;
                return dialog != null ? dialog.findViewById(i) : null;
            }

            public final boolean onHasView() {
                if (!createFragmentContainer.onHasView()) {
                    if (!android.support.p000v4.app.DialogFragment.this.mDialogCreated) {
                        return false;
                    }
                }
                return true;
            }
        };
    }

    public final void dismissInternal(boolean z, boolean z2) {
        if (!this.mDismissed) {
            this.mDismissed = true;
            this.mShownByMe = false;
            Dialog dialog = this.mDialog;
            if (dialog != null) {
                dialog.setOnDismissListener(null);
                this.mDialog.dismiss();
                if (!z2) {
                    if (Looper.myLooper() == this.mHandler.getLooper()) {
                        onDismiss(this.mDialog);
                    } else {
                        this.mHandler.post(this.mDismissRunnable);
                    }
                }
            }
            this.mViewDestroyed = true;
            StringBuilder stringBuilder;
            if (this.mBackStackId >= 0) {
                FragmentManager parentFragmentManager = getParentFragmentManager();
                int i = this.mBackStackId;
                if (i >= 0) {
                    parentFragmentManager.enqueueAction(new PopBackStackState(i), z);
                    this.mBackStackId = -1;
                    return;
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append("Bad id: ");
                stringBuilder.append(i);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            FragmentTransaction beginTransaction = getParentFragmentManager().beginTransaction();
            FragmentManager fragmentManager = this.mFragmentManager;
            if (fragmentManager != null) {
                if (fragmentManager != ((BackStackRecord) beginTransaction).mManager) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
                    stringBuilder.append(toString());
                    stringBuilder.append(" is already attached to a FragmentManager.");
                    throw new IllegalStateException(stringBuilder.toString());
                }
            }
            beginTransaction.addOp(new PG(3, this));
            if (z) {
                ((BackStackRecord) beginTransaction).commitInternal$ar$ds(true);
            } else {
                beginTransaction.commit$ar$ds();
            }
        }
    }

    public int getTheme() {
        return this.mTheme;
    }

    public final void onAttach(Context context) {
        super.onAttach(context);
        this.mViewLifecycleOwnerLiveData.observeForever(this.mObserver);
        if (!this.mShownByMe) {
            this.mDismissed = false;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
    }

    public void onCreate(Bundle bundle) {
        boolean z;
        super.onCreate(bundle);
        this.mHandler = new Handler();
        if (this.mContainerId == 0) {
            z = true;
        } else {
            z = false;
        }
        this.mShowsDialog = z;
        if (bundle != null) {
            this.mStyle = bundle.getInt("android:style", 0);
            this.mTheme = bundle.getInt("android:theme", 0);
            this.mCancelable = bundle.getBoolean("android:cancelable", true);
            this.mShowsDialog = bundle.getBoolean("android:showsDialog", this.mShowsDialog);
            this.mBackStackId = bundle.getInt("android:backStackId", -1);
        }
    }

    public Dialog onCreateDialog(Bundle bundle) {
        if (FragmentManager.isLoggingEnabled(3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onCreateDialog called for DialogFragment ");
            stringBuilder.append(this);
            Log.d("FragmentManager", stringBuilder.toString());
        }
        return new Dialog(requireContext(), getTheme());
    }

    public final void onDestroyView() {
        super.onDestroyView();
        Dialog dialog = this.mDialog;
        if (dialog != null) {
            this.mViewDestroyed = true;
            dialog.setOnDismissListener(null);
            this.mDialog.dismiss();
            if (!this.mDismissed) {
                onDismiss(this.mDialog);
            }
            this.mDialog = null;
            this.mDialogCreated = false;
        }
    }

    public final void onDetach() {
        super.onDetach();
        if (!(this.mShownByMe || this.mDismissed)) {
            this.mDismissed = true;
        }
        this.mViewLifecycleOwnerLiveData.removeObserver(this.mObserver);
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.mViewDestroyed) {
            if (FragmentManager.isLoggingEnabled(3)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("onDismiss called for DialogFragment ");
                stringBuilder.append(this);
                Log.d("FragmentManager", stringBuilder.toString());
            }
            dismissInternal(true, true);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        Dialog dialog = this.mDialog;
        if (dialog != null) {
            Bundle onSaveInstanceState = dialog.onSaveInstanceState();
            onSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", onSaveInstanceState);
        }
        int i = this.mStyle;
        if (i != 0) {
            bundle.putInt("android:style", i);
        }
        i = this.mTheme;
        if (i != 0) {
            bundle.putInt("android:theme", i);
        }
        if (!this.mCancelable) {
            bundle.putBoolean("android:cancelable", false);
        }
        if (!this.mShowsDialog) {
            bundle.putBoolean("android:showsDialog", false);
        }
        i = this.mBackStackId;
        if (i != -1) {
            bundle.putInt("android:backStackId", i);
        }
    }

    public final void onStart() {
        super.onStart();
        Dialog dialog = this.mDialog;
        if (dialog != null) {
            this.mViewDestroyed = false;
            dialog.show();
            View decorView = this.mDialog.getWindow().getDecorView();
            ViewTreeLifecycleOwner.set(decorView, this);
            ViewTreeViewModelStoreOwner.set(decorView, this);
            ViewTreeSavedStateRegistryOwner.set(decorView, this);
        }
    }

    public final void onStop() {
        super.onStop();
        Dialog dialog = this.mDialog;
        if (dialog != null) {
            dialog.hide();
        }
    }

    public final void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
        if (this.mDialog != null && bundle != null) {
            bundle = bundle.getBundle("android:savedDialogState");
            if (bundle != null) {
                this.mDialog.onRestoreInstanceState(bundle);
            }
        }
    }

    public final void performCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.performCreateView(layoutInflater, viewGroup, bundle);
        if (this.mView == null && this.mDialog != null && bundle != null) {
            Bundle bundle2 = bundle.getBundle("android:savedDialogState");
            if (bundle2 != null) {
                this.mDialog.onRestoreInstanceState(bundle2);
            }
        }
    }

    public final void show(FragmentManager fragmentManager, String str) {
        this.mDismissed = false;
        this.mShownByMe = true;
        FragmentTransaction beginTransaction = fragmentManager.beginTransaction();
        beginTransaction.add$ar$ds$4410556b_0(this, str);
        beginTransaction.commit$ar$ds();
    }

    public final void showNow(FragmentManager fragmentManager, String str) {
        this.mDismissed = false;
        this.mShownByMe = true;
        FragmentTransaction beginTransaction = fragmentManager.beginTransaction();
        beginTransaction.add$ar$ds$4410556b_0(this, str);
        beginTransaction.commitNow();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.LayoutInflater onGetLayoutInflater(android.os.Bundle r8) {
        /*
        r7 = this;
        r0 = r7.getLayoutInflater$ar$ds();
        r1 = r7.mShowsDialog;
        r2 = 2;
        r3 = "FragmentManager";
        if (r1 == 0) goto L_0x0097;
    L_0x000b:
        r1 = r7.mCreatingDialog;
        if (r1 == 0) goto L_0x0011;
    L_0x000f:
        goto L_0x0097;
    L_0x0011:
        r1 = r7.mDialogCreated;
        if (r1 != 0) goto L_0x0069;
    L_0x0015:
        r1 = 0;
        r4 = 1;
        r7.mCreatingDialog = r4;	 Catch:{ all -> 0x0065 }
        r8 = r7.onCreateDialog(r8);	 Catch:{ all -> 0x0065 }
        r7.mDialog = r8;	 Catch:{ all -> 0x0065 }
        r5 = r7.mShowsDialog;	 Catch:{ all -> 0x0065 }
        if (r5 == 0) goto L_0x005f;
    L_0x0023:
        r5 = r7.mStyle;	 Catch:{ all -> 0x0065 }
        switch(r5) {
            case 1: goto L_0x0034;
            case 2: goto L_0x0034;
            case 3: goto L_0x0029;
            default: goto L_0x0028;
        };	 Catch:{ all -> 0x0065 }
    L_0x0028:
        goto L_0x0038;
    L_0x0029:
        r5 = r8.getWindow();	 Catch:{ all -> 0x0065 }
        if (r5 == 0) goto L_0x0034;
    L_0x002f:
        r6 = 24;
        r5.addFlags(r6);	 Catch:{ all -> 0x0065 }
        r8.requestWindowFeature(r4);	 Catch:{ all -> 0x0065 }
    L_0x0038:
        r8 = r7.getContext();	 Catch:{ all -> 0x0065 }
        r5 = r8 instanceof android.app.Activity;	 Catch:{ all -> 0x0065 }
        if (r5 == 0) goto L_0x0047;
    L_0x0040:
        r5 = r7.mDialog;	 Catch:{ all -> 0x0065 }
        r8 = (android.app.Activity) r8;	 Catch:{ all -> 0x0065 }
        r5.setOwnerActivity(r8);	 Catch:{ all -> 0x0065 }
    L_0x0047:
        r8 = r7.mDialog;	 Catch:{ all -> 0x0065 }
        r5 = r7.mCancelable;	 Catch:{ all -> 0x0065 }
        r8.setCancelable(r5);	 Catch:{ all -> 0x0065 }
        r8 = r7.mDialog;	 Catch:{ all -> 0x0065 }
        r5 = r7.mOnCancelListener;	 Catch:{ all -> 0x0065 }
        r8.setOnCancelListener(r5);	 Catch:{ all -> 0x0065 }
        r8 = r7.mDialog;	 Catch:{ all -> 0x0065 }
        r5 = r7.mOnDismissListener;	 Catch:{ all -> 0x0065 }
        r8.setOnDismissListener(r5);	 Catch:{ all -> 0x0065 }
        r7.mDialogCreated = r4;	 Catch:{ all -> 0x0065 }
        goto L_0x0062;
    L_0x005f:
        r8 = 0;
        r7.mDialog = r8;	 Catch:{ all -> 0x0065 }
    L_0x0062:
        r7.mCreatingDialog = r1;
        goto L_0x0069;
    L_0x0065:
        r8 = move-exception;
        r7.mCreatingDialog = r1;
        throw r8;
        r8 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r2);
        if (r8 == 0) goto L_0x0089;
    L_0x0070:
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r1 = "get layout inflater for DialogFragment ";
        r8.append(r1);
        r8.append(r7);
        r1 = " from dialog context";
        r8.append(r1);
        r8 = r8.toString();
        android.util.Log.d(r3, r8);
    L_0x0089:
        r8 = r7.mDialog;
        if (r8 == 0) goto L_0x0096;
    L_0x008d:
        r8 = r8.getContext();
        r8 = r0.cloneInContext(r8);
        return r8;
    L_0x0096:
        return r0;
    L_0x0097:
        r8 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r2);
        if (r8 == 0) goto L_0x00db;
    L_0x009d:
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r1 = "getting layout inflater for DialogFragment ";
        r8.append(r1);
        r8.append(r7);
        r8 = r8.toString();
        r1 = r7.mShowsDialog;
        if (r1 != 0) goto L_0x00c7;
    L_0x00b2:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "mShowsDialog = false: ";
        r1.append(r2);
        r1.append(r8);
        r8 = r1.toString();
        android.util.Log.d(r3, r8);
        goto L_0x00db;
    L_0x00c7:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "mCreatingDialog = true: ";
        r1.append(r2);
        r1.append(r8);
        r8 = r1.toString();
        android.util.Log.d(r3, r8);
    L_0x00db:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.DialogFragment.onGetLayoutInflater(android.os.Bundle):android.view.LayoutInflater");
    }
}
