package android.support.p000v4.app;

import androidx.lifecycle.Lifecycle.State;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentTransaction */
public abstract class FragmentTransaction {
    boolean mAddToBackStack;
    boolean mAllowAddToBackStack = true;
    int mBreadCrumbShortTitleRes;
    CharSequence mBreadCrumbShortTitleText;
    int mBreadCrumbTitleRes;
    CharSequence mBreadCrumbTitleText;
    int mEnterAnim;
    int mExitAnim;
    String mName;
    final ArrayList mOps = new ArrayList();
    int mPopEnterAnim;
    int mPopExitAnim;
    boolean mReorderingAllowed = false;
    ArrayList mSharedElementSourceNames;
    ArrayList mSharedElementTargetNames;
    int mTransition;

    /* renamed from: android.support.v4.app.FragmentTransaction$Op */
    final class PG {
        int mCmd;
        State mCurrentMaxState;
        int mEnterAnim;
        int mExitAnim;
        Fragment mFragment;
        boolean mFromExpandedOp;
        State mOldMaxState;
        int mPopEnterAnim;
        int mPopExitAnim;

        public PG(int i, Fragment fragment) {
            this.mCmd = i;
            this.mFragment = fragment;
            this.mFromExpandedOp = false;
            this.mOldMaxState = State.RESUMED;
            this.mCurrentMaxState = State.RESUMED;
        }

        public PG(int i, Fragment fragment, byte[] bArr) {
            this.mCmd = i;
            this.mFragment = fragment;
            this.mFromExpandedOp = true;
            this.mOldMaxState = State.RESUMED;
            this.mCurrentMaxState = State.RESUMED;
        }
    }

    public final void add$ar$ds(int i, Fragment fragment, String str) {
        doAddOp(i, fragment, str, 1);
    }

    public final void add$ar$ds$4410556b_0(Fragment fragment, String str) {
        doAddOp(0, fragment, str, 1);
    }

    final void addOp(PG pg) {
        this.mOps.add(pg);
        pg.mEnterAnim = this.mEnterAnim;
        pg.mExitAnim = this.mExitAnim;
        pg.mPopEnterAnim = this.mPopEnterAnim;
        pg.mPopExitAnim = this.mPopExitAnim;
    }

    public final void addToBackStack$ar$ds() {
        if (this.mAllowAddToBackStack) {
            this.mAddToBackStack = true;
            this.mName = null;
            return;
        }
        throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
    }

    public abstract void commit$ar$ds();

    public abstract void commitNow();

    public final void disallowAddToBackStack$ar$ds() {
        if (this.mAddToBackStack) {
            throw new IllegalStateException("This transaction is already being added to the back stack");
        }
        this.mAllowAddToBackStack = false;
    }

    public void doAddOp(int i, Fragment fragment, String str, int i2) {
        throw null;
    }

    public final void replace$ar$ds(int i, Fragment fragment) {
        if (i != 0) {
            doAddOp(i, fragment, null, 2);
            return;
        }
        throw new IllegalArgumentException("Must use non-zero containerViewId");
    }
}
