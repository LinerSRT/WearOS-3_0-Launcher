package android.support.p000v4.app;

import android.app.Activity;
import android.arch.lifecycle.HasDefaultViewModelProviderFactory;
import android.arch.lifecycle.ViewModelProvider.Factory;
import android.arch.lifecycle.ViewModelStore;
import android.arch.lifecycle.ViewModelStoreOwner;
import android.arch.lifecycle.ViewTreeLifecycleOwner;
import android.arch.lifecycle.ViewTreeViewModelStoreOwner;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.p000v4.app.FragmentActivity.HostCallbacks;
import android.support.p000v4.app.FragmentContainer;
import android.support.v4.app.Fragment.C00614;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import androidx.fragment.app.strictmode.FragmentStrictMode;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.Lifecycle.Event;
import androidx.lifecycle.Lifecycle.State;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.MutableLiveData;
import androidx.loader.app.LoaderManager;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.SavedStateRegistryController;
import androidx.savedstate.SavedStateRegistryOwner;
import androidx.savedstate.ViewTreeSavedStateRegistryOwner;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: PG */
/* renamed from: android.support.v4.app.Fragment */
public class Fragment implements ComponentCallbacks, OnCreateContextMenuListener, LifecycleOwner, ViewModelStoreOwner, HasDefaultViewModelProviderFactory, SavedStateRegistryOwner {
    static final Object USE_DEFAULT_TRANSITION = new Object();
    boolean mAdded;
    AnimationInfo mAnimationInfo;
    public Bundle mArguments;
    int mBackStackNesting;
    boolean mBeingSaved;
    public boolean mCalled;
    FragmentManager mChildFragmentManager = new FragmentManagerImpl();
    ViewGroup mContainer;
    int mContainerId;
    Factory mDefaultFactory;
    boolean mDeferStart;
    boolean mDetached;
    int mFragmentId;
    FragmentManager mFragmentManager;
    boolean mFromLayout;
    boolean mHasMenu;
    boolean mHidden;
    boolean mHiddenChanged;
    FragmentHostCallback mHost;
    boolean mInLayout;
    boolean mIsCreated;
    public Boolean mIsPrimaryNavigationFragment = null;
    public LayoutInflater mLayoutInflater;
    public LifecycleRegistry mLifecycleRegistry;
    State mMaxState;
    public final ArrayList mOnPreAttachedListeners;
    public Fragment mParentFragment;
    boolean mPerformedCreateView;
    public String mPreviousWho;
    boolean mRemoving;
    boolean mRestored;
    boolean mRetainInstance;
    boolean mRetainInstanceChangedWhileDetached;
    Bundle mSavedFragmentState;
    SavedStateRegistryController mSavedStateRegistryController;
    Boolean mSavedUserVisibleHint;
    Bundle mSavedViewRegistryState;
    SparseArray mSavedViewState;
    int mState = -1;
    String mTag;
    Fragment mTarget;
    int mTargetRequestCode;
    String mTargetWho = null;
    boolean mUserVisibleHint = true;
    public View mView;
    FragmentViewLifecycleOwner mViewLifecycleOwner;
    final MutableLiveData mViewLifecycleOwnerLiveData;
    String mWho = UUID.randomUUID().toString();

    /* renamed from: android.support.v4.app.Fragment$1 */
    final class PG implements Runnable {
        public final void run() {
            Fragment fragment = Fragment.this;
            if (fragment.mAnimationInfo != null) {
                boolean z = fragment.ensureAnimationInfo().mEnterTransitionPostponed;
            }
        }
    }

    /* renamed from: android.support.v4.app.Fragment$4 */
    final class C00614 extends FragmentContainer {
        public final View onFindViewById(int i) {
            View view = android.support.p000v4.app.Fragment.this.mView;
            if (view != null) {
                return view.findViewById(i);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Fragment ");
            stringBuilder.append(android.support.p000v4.app.Fragment.this);
            stringBuilder.append(" does not have a view");
            throw new IllegalStateException(stringBuilder.toString());
        }

        public final boolean onHasView() {
            return android.support.p000v4.app.Fragment.this.mView != null;
        }
    }

    /* renamed from: android.support.v4.app.Fragment$5 */
    class C00625 implements LifecycleEventObserver {
        public final void onStateChanged(LifecycleOwner lifecycleOwner, Event event) {
            if (event == Event.ON_STOP) {
                View view = android.support.p000v4.app.Fragment.this.mView;
                if (view != null) {
                    view.cancelPendingInputEvents();
                }
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.Fragment$AnimationInfo */
    public final class AnimationInfo {
        int mEnterAnim;
        public Object mEnterTransition = null;
        boolean mEnterTransitionPostponed;
        int mExitAnim;
        public Object mExitTransition = null;
        View mFocusedView = null;
        boolean mIsPop;
        int mNextTransition;
        int mPopEnterAnim;
        int mPopExitAnim;
        float mPostOnViewCreatedAlpha = 1.0f;
        final Object mReenterTransition = Fragment.USE_DEFAULT_TRANSITION;
        final Object mReturnTransition = Fragment.USE_DEFAULT_TRANSITION;
        final Object mSharedElementReturnTransition = Fragment.USE_DEFAULT_TRANSITION;
        ArrayList mSharedElementSourceNames;
        ArrayList mSharedElementTargetNames;
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.Fragment$InstantiationException */
    public final class InstantiationException extends RuntimeException {
        public InstantiationException(String str, Exception exception) {
            super(str, exception);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.Fragment$OnPreAttachedListener */
    abstract class OnPreAttachedListener {
        private OnPreAttachedListener() {
        }

        public abstract void onPreAttached();
    }

    public Fragment() {
        PG pg = new PG();
        this.mMaxState = State.RESUMED;
        this.mViewLifecycleOwnerLiveData = new MutableLiveData();
        AtomicInteger atomicInteger = new AtomicInteger();
        this.mOnPreAttachedListeners = new ArrayList();
        initLifecycle();
    }

    private final int getMinimumMaxLifecycleState() {
        if (this.mMaxState != State.INITIALIZED) {
            if (this.mParentFragment != null) {
                return Math.min(this.mMaxState.ordinal(), this.mParentFragment.getMinimumMaxLifecycleState());
            }
        }
        return this.mMaxState.ordinal();
    }

    private final Fragment getTargetFragment(boolean z) {
        if (z) {
            FragmentStrictMode.onGetTargetFragmentUsage(this);
        }
        Fragment fragment = this.mTarget;
        if (fragment != null) {
            return fragment;
        }
        FragmentManager fragmentManager = this.mFragmentManager;
        if (fragmentManager != null) {
            String str = this.mTargetWho;
            if (str != null) {
                return fragmentManager.findActiveFragment(str);
            }
        }
        return null;
    }

    private final void initLifecycle() {
        this.mLifecycleRegistry = new LifecycleRegistry(this);
        this.mSavedStateRegistryController = SavedStateRegistryController.create(this);
        this.mDefaultFactory = null;
    }

    @Deprecated
    public static Fragment instantiate$ar$ds(Context context, String str) {
        StringBuilder stringBuilder;
        StringBuilder stringBuilder2;
        String str2 = ": make sure class name exists, is public, and has an empty constructor that is public";
        String str3 = "Unable to instantiate fragment ";
        try {
            return (Fragment) FragmentFactory.loadFragmentClass(context.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception e) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str3);
            stringBuilder.append(str);
            stringBuilder.append(str2);
            throw new InstantiationException(stringBuilder.toString(), e);
        } catch (Exception e2) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str3);
            stringBuilder.append(str);
            stringBuilder.append(str2);
            throw new InstantiationException(stringBuilder.toString(), e2);
        } catch (Exception e22) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str3);
            stringBuilder2.append(str);
            stringBuilder2.append(": could not find Fragment constructor");
            throw new InstantiationException(stringBuilder2.toString(), e22);
        } catch (Exception e222) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str3);
            stringBuilder2.append(str);
            stringBuilder2.append(": calling Fragment constructor caused an exception");
            throw new InstantiationException(stringBuilder2.toString(), e222);
        }
    }

    public FragmentContainer createFragmentContainer() {
        return new C00614();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.mFragmentId));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.mContainerId));
        printWriter.print(" mTag=");
        printWriter.println(this.mTag);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.mState);
        printWriter.print(" mWho=");
        printWriter.print(this.mWho);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.mBackStackNesting);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.mAdded);
        printWriter.print(" mRemoving=");
        printWriter.print(this.mRemoving);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.mFromLayout);
        printWriter.print(" mInLayout=");
        printWriter.println(this.mInLayout);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.mHidden);
        printWriter.print(" mDetached=");
        printWriter.print(this.mDetached);
        printWriter.print(" mMenuVisible=");
        printWriter.print(true);
        printWriter.print(" mHasMenu=");
        printWriter.println(false);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.mRetainInstance);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.mUserVisibleHint);
        if (this.mFragmentManager != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.mFragmentManager);
        }
        if (this.mHost != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.mHost);
        }
        if (this.mParentFragment != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.mParentFragment);
        }
        if (this.mArguments != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.mArguments);
        }
        if (this.mSavedFragmentState != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.mSavedFragmentState);
        }
        if (this.mSavedViewState != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.mSavedViewState);
        }
        if (this.mSavedViewRegistryState != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewRegistryState=");
            printWriter.println(this.mSavedViewRegistryState);
        }
        Fragment targetFragment = getTargetFragment(false);
        if (targetFragment != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(targetFragment);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.mTargetRequestCode);
        }
        printWriter.print(str);
        printWriter.print("mPopDirection=");
        printWriter.println(getPopDirection());
        if (getEnterAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getEnterAnim=");
            printWriter.println(getEnterAnim());
        }
        if (getExitAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getExitAnim=");
            printWriter.println(getExitAnim());
        }
        if (getPopEnterAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getPopEnterAnim=");
            printWriter.println(getPopEnterAnim());
        }
        if (getPopExitAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getPopExitAnim=");
            printWriter.println(getPopExitAnim());
        }
        if (this.mContainer != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.mContainer);
        }
        if (this.mView != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.mView);
        }
        if (getContext() != null) {
            LoaderManager.getInstance(this).dump$ar$ds(str, printWriter);
        }
        printWriter.print(str);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Child ");
        stringBuilder.append(this.mChildFragmentManager);
        stringBuilder.append(":");
        printWriter.println(stringBuilder.toString());
        FragmentManager fragmentManager = this.mChildFragmentManager;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append("  ");
        fragmentManager.dump(stringBuilder2.toString(), fileDescriptor, printWriter, strArr);
    }

    public final AnimationInfo ensureAnimationInfo() {
        if (this.mAnimationInfo == null) {
            this.mAnimationInfo = new AnimationInfo();
        }
        return this.mAnimationInfo;
    }

    public final FragmentActivity getActivity() {
        FragmentHostCallback fragmentHostCallback = this.mHost;
        return fragmentHostCallback == null ? null : (FragmentActivity) fragmentHostCallback.mActivity;
    }

    public final FragmentManager getChildFragmentManager() {
        if (this.mHost != null) {
            return this.mChildFragmentManager;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this);
        stringBuilder.append(" has not been attached yet.");
        throw new IllegalStateException(stringBuilder.toString());
    }

    public Context getContext() {
        FragmentHostCallback fragmentHostCallback = this.mHost;
        return fragmentHostCallback == null ? null : fragmentHostCallback.mContext;
    }

    public final Factory getDefaultViewModelProviderFactory() {
        throw null;
    }

    final int getEnterAnim() {
        AnimationInfo animationInfo = this.mAnimationInfo;
        return animationInfo == null ? 0 : animationInfo.mEnterAnim;
    }

    public final Object getEnterTransition() {
        AnimationInfo animationInfo = this.mAnimationInfo;
        return animationInfo == null ? null : animationInfo.mEnterTransition;
    }

    final void getEnterTransitionCallback$ar$ds() {
    }

    final int getExitAnim() {
        AnimationInfo animationInfo = this.mAnimationInfo;
        return animationInfo == null ? 0 : animationInfo.mExitAnim;
    }

    public final void getExitTransition$ar$ds() {
    }

    final void getExitTransitionCallback$ar$ds() {
    }

    public final Object getHost() {
        FragmentHostCallback fragmentHostCallback = this.mHost;
        return fragmentHostCallback == null ? null : ((HostCallbacks) fragmentHostCallback).this$0;
    }

    @Deprecated
    public final LayoutInflater getLayoutInflater$ar$ds() {
        FragmentHostCallback fragmentHostCallback = this.mHost;
        if (fragmentHostCallback != null) {
            HostCallbacks hostCallbacks = (HostCallbacks) fragmentHostCallback;
            LayoutInflater cloneInContext = hostCallbacks.this$0.getLayoutInflater().cloneInContext(hostCallbacks.this$0);
            cloneInContext.setFactory2(this.mChildFragmentManager.mLayoutInflaterFactory);
            return cloneInContext;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    public final Lifecycle getLifecycle() {
        return this.mLifecycleRegistry;
    }

    public final FragmentManager getParentFragmentManager() {
        FragmentManager fragmentManager = this.mFragmentManager;
        if (fragmentManager != null) {
            return fragmentManager;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this);
        stringBuilder.append(" not associated with a fragment manager.");
        throw new IllegalStateException(stringBuilder.toString());
    }

    final boolean getPopDirection() {
        AnimationInfo animationInfo = this.mAnimationInfo;
        return animationInfo == null ? false : animationInfo.mIsPop;
    }

    final int getPopEnterAnim() {
        AnimationInfo animationInfo = this.mAnimationInfo;
        return animationInfo == null ? 0 : animationInfo.mPopEnterAnim;
    }

    final int getPopExitAnim() {
        AnimationInfo animationInfo = this.mAnimationInfo;
        return animationInfo == null ? 0 : animationInfo.mPopExitAnim;
    }

    public final Resources getResources() {
        return requireContext().getResources();
    }

    public final SavedStateRegistry getSavedStateRegistry() {
        return this.mSavedStateRegistryController.mRegistry;
    }

    public final void getSharedElementEnterTransition$ar$ds() {
    }

    final ArrayList getSharedElementSourceNames() {
        AnimationInfo animationInfo = this.mAnimationInfo;
        if (animationInfo != null) {
            ArrayList arrayList = animationInfo.mSharedElementSourceNames;
            if (arrayList != null) {
                return arrayList;
            }
        }
        return new ArrayList();
    }

    final ArrayList getSharedElementTargetNames() {
        AnimationInfo animationInfo = this.mAnimationInfo;
        if (animationInfo != null) {
            ArrayList arrayList = animationInfo.mSharedElementTargetNames;
            if (arrayList != null) {
                return arrayList;
            }
        }
        return new ArrayList();
    }

    public final String getString(int i) {
        return getResources().getString(i);
    }

    public final ViewModelStore getViewModelStore() {
        if (this.mFragmentManager == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        } else if (getMinimumMaxLifecycleState() != State.INITIALIZED.ordinal()) {
            FragmentManagerViewModel fragmentManagerViewModel = this.mFragmentManager.mNonConfig;
            ViewModelStore viewModelStore = (ViewModelStore) fragmentManagerViewModel.mViewModelStores.get(this.mWho);
            if (viewModelStore != null) {
                return viewModelStore;
            }
            viewModelStore = new ViewModelStore();
            fragmentManagerViewModel.mViewModelStores.put(this.mWho, viewModelStore);
            return viewModelStore;
        } else {
            throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
        }
    }

    final void initState() {
        initLifecycle();
        this.mPreviousWho = this.mWho;
        this.mWho = UUID.randomUUID().toString();
        this.mAdded = false;
        this.mRemoving = false;
        this.mFromLayout = false;
        this.mInLayout = false;
        this.mRestored = false;
        this.mBackStackNesting = 0;
        this.mFragmentManager = null;
        this.mChildFragmentManager = new FragmentManagerImpl();
        this.mHost = null;
        this.mFragmentId = 0;
        this.mContainerId = 0;
        this.mTag = null;
        this.mHidden = false;
        this.mDetached = false;
    }

    public final boolean isAdded() {
        return this.mHost != null && this.mAdded;
    }

    final boolean isInBackStack() {
        return this.mBackStackNesting > 0;
    }

    @Deprecated
    public void onActivityCreated(Bundle bundle) {
        this.mCalled = true;
    }

    @Deprecated
    public final void onActivityResult(int i, int i2, Intent intent) {
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Fragment ");
            stringBuilder.append(this);
            stringBuilder.append(" received the following in onActivityResult(): requestCode: ");
            stringBuilder.append(i);
            stringBuilder.append(" resultCode: ");
            stringBuilder.append(i2);
            stringBuilder.append(" data: ");
            stringBuilder.append(intent);
            Log.v("FragmentManager", stringBuilder.toString());
        }
    }

    @Deprecated
    public void onAttach(Activity activity) {
        this.mCalled = true;
    }

    public final void onConfigurationChanged(Configuration configuration) {
        this.mCalled = true;
    }

    public void onCreate(Bundle bundle) {
        this.mCalled = true;
        restoreChildFragmentState(bundle);
        FragmentManager fragmentManager = this.mChildFragmentManager;
        if (fragmentManager.mCurState <= 0) {
            fragmentManager.dispatchCreate();
        }
    }

    public final void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenuInfo contextMenuInfo) {
        requireActivity().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    public void onDestroy() {
        this.mCalled = true;
    }

    public void onDestroyView() {
        this.mCalled = true;
    }

    public void onDetach() {
        this.mCalled = true;
    }

    public LayoutInflater onGetLayoutInflater(Bundle bundle) {
        return getLayoutInflater$ar$ds();
    }

    public final void onInflate$ar$ds() {
        this.mCalled = true;
        FragmentHostCallback fragmentHostCallback = this.mHost;
        if ((fragmentHostCallback == null ? null : fragmentHostCallback.mActivity) != null) {
            this.mCalled = true;
        }
    }

    public final void onLowMemory() {
        this.mCalled = true;
    }

    public void onPause() {
        this.mCalled = true;
    }

    public void onResume() {
        this.mCalled = true;
    }

    public void onSaveInstanceState(Bundle bundle) {
    }

    public void onStart() {
        this.mCalled = true;
    }

    public void onStop() {
        this.mCalled = true;
    }

    public void onViewCreated(View view, Bundle bundle) {
    }

    public void onViewStateRestored(Bundle bundle) {
        this.mCalled = true;
    }

    public void performCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.mChildFragmentManager.noteStateNotSaved();
        this.mPerformedCreateView = true;
        this.mViewLifecycleOwner = new FragmentViewLifecycleOwner(this, getViewModelStore());
        View onCreateView = onCreateView(layoutInflater, viewGroup, bundle);
        this.mView = onCreateView;
        if (onCreateView != null) {
            this.mViewLifecycleOwner.initialize();
            ViewTreeLifecycleOwner.set(this.mView, this.mViewLifecycleOwner);
            ViewTreeViewModelStoreOwner.set(this.mView, this.mViewLifecycleOwner);
            ViewTreeSavedStateRegistryOwner.set(this.mView, this.mViewLifecycleOwner);
            this.mViewLifecycleOwnerLiveData.setValue(this.mViewLifecycleOwner);
        } else if (this.mViewLifecycleOwner.mLifecycleRegistry == null) {
            this.mViewLifecycleOwner = null;
        } else {
            throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
        }
    }

    public final LayoutInflater performGetLayoutInflater(Bundle bundle) {
        LayoutInflater onGetLayoutInflater = onGetLayoutInflater(bundle);
        this.mLayoutInflater = onGetLayoutInflater;
        return onGetLayoutInflater;
    }

    final void performViewCreated() {
        onViewCreated(this.mView, this.mSavedFragmentState);
        this.mChildFragmentManager.dispatchStateChange(2);
    }

    public final FragmentActivity requireActivity() {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            return activity;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this);
        stringBuilder.append(" not attached to an activity.");
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final Context requireContext() {
        Context context = getContext();
        if (context != null) {
            return context;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this);
        stringBuilder.append(" not attached to a context.");
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final View requireView() {
        View view = this.mView;
        if (view != null) {
            return view;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this);
        stringBuilder.append(" did not return a View from onCreateView() or this was called before onCreateView().");
        throw new IllegalStateException(stringBuilder.toString());
    }

    final void restoreChildFragmentState(Bundle bundle) {
        if (bundle != null) {
            Parcelable parcelable = bundle.getParcelable("android:support:fragments");
            if (parcelable != null) {
                this.mChildFragmentManager.restoreSaveStateInternal(parcelable);
                this.mChildFragmentManager.dispatchCreate();
            }
        }
    }

    final void setAnimations(int i, int i2, int i3, int i4) {
        if (this.mAnimationInfo == null && i == 0) {
            if (i2 != 0) {
                i = 0;
            } else if (i3 != 0) {
                i = 0;
                i2 = 0;
            } else if (i4 != 0) {
                i = 0;
                i2 = 0;
                i3 = 0;
            } else {
                return;
            }
        }
        ensureAnimationInfo().mEnterAnim = i;
        ensureAnimationInfo().mExitAnim = i2;
        ensureAnimationInfo().mPopEnterAnim = i3;
        ensureAnimationInfo().mPopExitAnim = i4;
    }

    public final void setArguments(Bundle bundle) {
        FragmentManager fragmentManager = this.mFragmentManager;
        if (fragmentManager != null) {
            if (fragmentManager.isStateSaved()) {
                throw new IllegalStateException("Fragment already added and state has been saved");
            }
        }
        this.mArguments = bundle;
    }

    final void setFocusedView(View view) {
        ensureAnimationInfo().mFocusedView = view;
    }

    final void setNextTransition(int i) {
        if (this.mAnimationInfo != null || i != 0) {
            ensureAnimationInfo();
            this.mAnimationInfo.mNextTransition = i;
        }
    }

    final void setPopDirection(boolean z) {
        if (this.mAnimationInfo != null) {
            ensureAnimationInfo().mIsPop = z;
        }
    }

    final void setSharedElementNames(ArrayList arrayList, ArrayList arrayList2) {
        ensureAnimationInfo();
        AnimationInfo animationInfo = this.mAnimationInfo;
        animationInfo.mSharedElementSourceNames = arrayList;
        animationInfo.mSharedElementTargetNames = arrayList2;
    }

    @Deprecated
    public final void setTargetFragment$ar$ds(Fragment fragment) {
        FragmentStrictMode.onSetTargetFragmentUsage$ar$ds(this, fragment);
        FragmentManager fragmentManager = this.mFragmentManager;
        FragmentManager fragmentManager2 = fragment.mFragmentManager;
        if (fragmentManager != null) {
            if (fragmentManager2 != null) {
                if (fragmentManager != fragmentManager2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Fragment ");
                    stringBuilder.append(fragment);
                    stringBuilder.append(" must share the same FragmentManager to be set as a target fragment");
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
            }
        }
        for (Fragment fragment2 = fragment; fragment2 != null; fragment2 = fragment2.getTargetFragment(false)) {
            if (fragment2.equals(this)) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("Setting ");
                stringBuilder.append(fragment);
                stringBuilder.append(" as the target of ");
                stringBuilder.append(this);
                stringBuilder.append(" would create a target cycle");
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        if (this.mFragmentManager == null || fragment.mFragmentManager == null) {
            this.mTargetWho = null;
            this.mTarget = fragment;
        } else {
            this.mTargetWho = fragment.mWho;
            this.mTarget = null;
        }
        this.mTargetRequestCode = 0;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append(getClass().getSimpleName());
        stringBuilder.append("{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append("} (");
        stringBuilder.append(this.mWho);
        if (this.mFragmentId != 0) {
            stringBuilder.append(" id=0x");
            stringBuilder.append(Integer.toHexString(this.mFragmentId));
        }
        if (this.mTag != null) {
            stringBuilder.append(" tag=");
            stringBuilder.append(this.mTag);
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void onAttach(Context context) {
        this.mCalled = true;
        FragmentHostCallback fragmentHostCallback = this.mHost;
        Activity activity = fragmentHostCallback == null ? null : fragmentHostCallback.mActivity;
        if (activity != null) {
            this.mCalled = false;
            onAttach(activity);
        }
    }

    @Deprecated
    public final Fragment getTargetFragment() {
        return getTargetFragment(true);
    }
}
