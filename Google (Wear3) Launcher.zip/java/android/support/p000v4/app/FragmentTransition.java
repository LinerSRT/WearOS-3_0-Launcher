package android.support.p000v4.app;

import android.view.View;
import androidx.collection.ArrayMap;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentTransition */
final class FragmentTransition {
    public static final /* synthetic */ int FragmentTransition$ar$NoOp = 0;
    static final FragmentTransitionImpl PLATFORM_IMPL = new FragmentTransitionCompat21();
    static final FragmentTransitionImpl SUPPORT_IMPL;

    static void callSharedElementStartEnd$ar$ds(Fragment fragment, Fragment fragment2, boolean z) {
        if (z) {
            fragment2.getEnterTransitionCallback$ar$ds();
        } else {
            fragment.getEnterTransitionCallback$ar$ds();
        }
    }

    static void retainValues(ArrayMap arrayMap, ArrayMap arrayMap2) {
        for (int i = arrayMap.mSize - 1; i >= 0; i--) {
            if (!arrayMap2.containsKey((String) arrayMap.valueAt(i))) {
                arrayMap.removeAt(i);
            }
        }
    }

    static void setViewVisibility(ArrayList arrayList, int i) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            ((View) arrayList.get(size)).setVisibility(i);
        }
    }

    static {
        FragmentTransitionImpl fragmentTransitionImpl;
        try {
            fragmentTransitionImpl = (FragmentTransitionImpl) Class.forName("androidx.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception e) {
            fragmentTransitionImpl = null;
        }
        SUPPORT_IMPL = fragmentTransitionImpl;
    }
}
