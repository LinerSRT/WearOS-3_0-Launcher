package android.support.p000v4.app;

import androidx.activity.contextaware.OnContextAvailableListener;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentActivity$$ExternalSyntheticLambda0 */
public final /* synthetic */ class FragmentActivity$$ExternalSyntheticLambda0 implements OnContextAvailableListener {
    public final /* synthetic */ FragmentActivity f$0;

    public /* synthetic */ FragmentActivity$$ExternalSyntheticLambda0(FragmentActivity fragmentActivity) {
        this.f$0 = fragmentActivity;
    }

    public final void onContextAvailable$ar$ds() {
        FragmentContainer fragmentContainer = this.f$0.mFragments.mHost;
        fragmentContainer.mFragmentManager.attachController(fragmentContainer, fragmentContainer, null);
    }
}
