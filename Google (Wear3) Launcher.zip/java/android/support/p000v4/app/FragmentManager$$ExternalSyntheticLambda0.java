package android.support.p000v4.app;

import android.os.Bundle;
import android.os.Parcelable;
import androidx.savedstate.SavedStateRegistry.SavedStateProvider;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentManager$$ExternalSyntheticLambda0 */
public final /* synthetic */ class FragmentManager$$ExternalSyntheticLambda0 implements SavedStateProvider {
    public final /* synthetic */ FragmentManager f$0;

    public /* synthetic */ FragmentManager$$ExternalSyntheticLambda0(FragmentManager fragmentManager) {
        this.f$0 = fragmentManager;
    }

    public final Bundle saveState() {
        FragmentManager fragmentManager = this.f$0;
        Bundle bundle = new Bundle();
        Parcelable saveAllStateInternal = fragmentManager.saveAllStateInternal();
        if (saveAllStateInternal != null) {
            bundle.putParcelable("android:support:fragments", saveAllStateInternal);
        }
        return bundle;
    }
}
