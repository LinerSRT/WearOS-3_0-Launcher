package android.support.p000v4.app;

import android.app.RemoteInput.Builder;
import android.os.Bundle;
import java.util.HashSet;
import java.util.Set;

/* compiled from: PG */
/* renamed from: android.support.v4.app.RemoteInput */
public final class RemoteInput {
    public final boolean mAllowFreeFormTextInput;
    public final Set mAllowedDataTypes;
    public final CharSequence[] mChoices;
    public final int mEditChoicesBeforeSending;
    public final Bundle mExtras;
    public final CharSequence mLabel;
    public final String mResultKey;

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.RemoteInput$Builder */
    public final class Builder {
        public boolean mAllowFreeFormTextInput = true;
        public final Set mAllowedDataTypes = new HashSet();
        public CharSequence[] mChoices;
        public final Bundle mExtras = new Bundle();
        public CharSequence mLabel;
        public final String mResultKey;

        public Builder(String str) {
            this.mResultKey = str;
        }
    }

    public RemoteInput(String str, CharSequence charSequence, CharSequence[] charSequenceArr, boolean z, int i, Bundle bundle, Set set) {
        this.mResultKey = str;
        this.mLabel = charSequence;
        this.mChoices = charSequenceArr;
        this.mAllowFreeFormTextInput = z;
        this.mEditChoicesBeforeSending = i;
        this.mExtras = bundle;
        this.mAllowedDataTypes = set;
        if (i != 2) {
            return;
        }
        if (!z) {
            throw new IllegalArgumentException("setEditChoicesBeforeSending requires setAllowFreeFormInput");
        }
    }

    public static android.app.RemoteInput[] fromCompat(RemoteInput[] remoteInputArr) {
        android.app.RemoteInput[] remoteInputArr2 = new android.app.RemoteInput[remoteInputArr.length];
        for (int i = 0; i < remoteInputArr.length; i++) {
            RemoteInput remoteInput = remoteInputArr[i];
            Builder addExtras = new Builder(remoteInput.mResultKey).setLabel(remoteInput.mLabel).setChoices(remoteInput.mChoices).setAllowFreeFormInput(remoteInput.mAllowFreeFormTextInput).addExtras(remoteInput.mExtras);
            for (String allowDataType : remoteInput.mAllowedDataTypes) {
                addExtras.setAllowDataType(allowDataType, true);
            }
            addExtras.setEditChoicesBeforeSending(remoteInput.mEditChoicesBeforeSending);
            remoteInputArr2[i] = addExtras.build();
        }
        return remoteInputArr2;
    }
}
