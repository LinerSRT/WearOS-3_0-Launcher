package android.support.p000v4.app;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentOnAttachListener */
public interface FragmentOnAttachListener {
    void onAttachFragment$ar$ds();
}
