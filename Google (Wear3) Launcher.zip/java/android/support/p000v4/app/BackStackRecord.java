package android.support.p000v4.app;

import android.support.p000v4.app.FragmentManager.OpGenerator;
import android.support.p000v4.app.FragmentTransaction.PG;
import android.util.Log;
import androidx.fragment.app.strictmode.FragmentStrictMode;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v4.app.BackStackRecord */
final class BackStackRecord extends FragmentTransaction implements OpGenerator {
    boolean mCommitted;
    int mIndex;
    final FragmentManager mManager;

    public BackStackRecord(FragmentManager fragmentManager) {
        fragmentManager.getFragmentFactory();
        FragmentHostCallback fragmentHostCallback = fragmentManager.mHost;
        if (fragmentHostCallback != null) {
            fragmentHostCallback.mContext.getClassLoader();
        }
        this.mIndex = -1;
        this.mManager = fragmentManager;
    }

    final void bumpBackStackNesting(int i) {
        if (this.mAddToBackStack) {
            String str = "FragmentManager";
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Bump nesting in ");
                stringBuilder.append(this);
                stringBuilder.append(" by ");
                stringBuilder.append(i);
                Log.v(str, stringBuilder.toString());
            }
            int size = this.mOps.size();
            for (int i2 = 0; i2 < size; i2++) {
                PG pg = (PG) this.mOps.get(i2);
                Fragment fragment = pg.mFragment;
                if (fragment != null) {
                    fragment.mBackStackNesting += i;
                    if (FragmentManager.isLoggingEnabled(2)) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("Bump nesting of ");
                        stringBuilder2.append(pg.mFragment);
                        stringBuilder2.append(" to ");
                        stringBuilder2.append(pg.mFragment.mBackStackNesting);
                        Log.v(str, stringBuilder2.toString());
                    }
                }
            }
        }
    }

    public final void commit$ar$ds() {
        commitInternal$ar$ds(false);
    }

    final void commitInternal$ar$ds(boolean z) {
        if (this.mCommitted) {
            throw new IllegalStateException("commit already called");
        }
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Commit: ");
            stringBuilder.append(this);
            Log.v("FragmentManager", stringBuilder.toString());
            PrintWriter printWriter = new PrintWriter(new LogWriter());
            dump("  ", printWriter);
            printWriter.close();
        }
        this.mCommitted = true;
        if (this.mAddToBackStack) {
            this.mIndex = this.mManager.mBackStackIndex.getAndIncrement();
        } else {
            this.mIndex = -1;
        }
        this.mManager.enqueueAction(this, z);
    }

    public final void commitNow() {
        disallowAddToBackStack$ar$ds();
        this.mManager.execSingleAction(this, false);
    }

    public final void dump(String str, PrintWriter printWriter) {
        dump(str, printWriter, true);
    }

    public final boolean generateOps(ArrayList arrayList, ArrayList arrayList2) {
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Run: ");
            stringBuilder.append(this);
            Log.v("FragmentManager", stringBuilder.toString());
        }
        arrayList.add(this);
        arrayList2.add(Boolean.valueOf(false));
        if (this.mAddToBackStack) {
            FragmentManager fragmentManager = this.mManager;
            if (fragmentManager.mBackStack == null) {
                fragmentManager.mBackStack = new ArrayList();
            }
            fragmentManager.mBackStack.add(this);
        }
        return true;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("BackStackEntry{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.mIndex >= 0) {
            stringBuilder.append(" #");
            stringBuilder.append(this.mIndex);
        }
        if (this.mName != null) {
            stringBuilder.append(" ");
            stringBuilder.append(this.mName);
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public final void doAddOp(int i, Fragment fragment, String str, int i2) {
        String str2 = fragment.mPreviousWho;
        if (str2 != null) {
            FragmentStrictMode.onFragmentReuse(fragment, str2);
        }
        Class cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Fragment ");
            stringBuilder.append(cls.getCanonicalName());
            stringBuilder.append(" must be a public static class to be  properly recreated from instance state.");
            throw new IllegalStateException(stringBuilder.toString());
        }
        str2 = " now ";
        String str3 = ": was ";
        if (str != null) {
            String str4 = fragment.mTag;
            if (str4 != null) {
                if (!str.equals(str4)) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Can't change tag of fragment ");
                    stringBuilder2.append(fragment);
                    stringBuilder2.append(str3);
                    stringBuilder2.append(fragment.mTag);
                    stringBuilder2.append(str2);
                    stringBuilder2.append(str);
                    throw new IllegalStateException(stringBuilder2.toString());
                }
            }
            fragment.mTag = str;
        }
        if (i != 0) {
            if (i != -1) {
                int i3 = fragment.mFragmentId;
                if (i3 != 0) {
                    if (i3 != i) {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("Can't change container ID of fragment ");
                        stringBuilder2.append(fragment);
                        stringBuilder2.append(str3);
                        stringBuilder2.append(fragment.mFragmentId);
                        stringBuilder2.append(str2);
                        stringBuilder2.append(i);
                        throw new IllegalStateException(stringBuilder2.toString());
                    }
                }
                fragment.mFragmentId = i;
                fragment.mContainerId = i;
            } else {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Can't add fragment ");
                stringBuilder2.append(fragment);
                stringBuilder2.append(" with tag ");
                stringBuilder2.append(str);
                stringBuilder2.append(" to container view with no id");
                throw new IllegalArgumentException(stringBuilder2.toString());
            }
        }
        addOp(new PG(i2, fragment));
        fragment.mFragmentManager = this.mManager;
    }

    public final void dump(String str, PrintWriter printWriter, boolean z) {
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.mName);
            printWriter.print(" mIndex=");
            printWriter.print(this.mIndex);
            printWriter.print(" mCommitted=");
            printWriter.println(this.mCommitted);
            if (this.mTransition != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.mTransition));
            }
            if (!(this.mEnterAnim == 0 && this.mExitAnim == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.mEnterAnim));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.mExitAnim));
            }
            if (!(this.mPopEnterAnim == 0 && this.mPopExitAnim == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.mPopEnterAnim));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.mPopExitAnim));
            }
            if (!(this.mBreadCrumbTitleRes == 0 && this.mBreadCrumbTitleText == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.mBreadCrumbTitleRes));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.mBreadCrumbTitleText);
            }
            if (!(this.mBreadCrumbShortTitleRes == 0 && this.mBreadCrumbShortTitleText == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.mBreadCrumbShortTitleRes));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.mBreadCrumbShortTitleText);
            }
        }
        if (!this.mOps.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            int size = this.mOps.size();
            for (int i = 0; i < size; i++) {
                String str2;
                PG pg = (PG) this.mOps.get(i);
                switch (pg.mCmd) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    case 8:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    case 10:
                        str2 = "OP_SET_MAX_LIFECYCLE";
                        break;
                    default:
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("cmd=");
                        stringBuilder.append(pg.mCmd);
                        str2 = stringBuilder.toString();
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(pg.mFragment);
                if (z) {
                    if (!(pg.mEnterAnim == 0 && pg.mExitAnim == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(pg.mEnterAnim));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(pg.mExitAnim));
                    }
                    if (pg.mPopEnterAnim != 0 || pg.mPopExitAnim != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(pg.mPopEnterAnim));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(pg.mPopExitAnim));
                    }
                }
            }
        }
    }
}
