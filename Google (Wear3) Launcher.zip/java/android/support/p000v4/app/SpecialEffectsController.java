package android.support.p000v4.app;

import android.support.p000v4.app.Fragment.AnimationInfo;
import android.support.p000v4.view.ViewCompat;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.p003os.CancellationSignal;
import androidx.core.p003os.CancellationSignal.OnCancelListener;
import com.google.android.wearable.sysui.R;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.app.SpecialEffectsController */
abstract class SpecialEffectsController {
    public final ViewGroup mContainer;
    boolean mOperationDirectionIsPop = false;
    final ArrayList mPendingOperations = new ArrayList();
    final ArrayList mRunningOperations = new ArrayList();

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.SpecialEffectsController$FragmentStateManagerOperation */
    final class FragmentStateManagerOperation extends Operation {
        private final FragmentStateManager mFragmentStateManager;

        public FragmentStateManagerOperation(int i, int i2, FragmentStateManager fragmentStateManager, CancellationSignal cancellationSignal) {
            super(i, i2, fragmentStateManager.mFragment, cancellationSignal);
            this.mFragmentStateManager = fragmentStateManager;
        }

        public final void complete() {
            super.complete();
            this.mFragmentStateManager.moveToExpectedState();
        }

        public final void onStart() {
            if (this.mLifecycleImpact$ar$edu == 2) {
                float f;
                Fragment fragment = this.mFragmentStateManager.mFragment;
                View findFocus = fragment.mView.findFocus();
                if (findFocus != null) {
                    fragment.setFocusedView(findFocus);
                    if (FragmentManager.isLoggingEnabled(2)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("requestFocus: Saved focused view ");
                        stringBuilder.append(findFocus);
                        stringBuilder.append(" for Fragment ");
                        stringBuilder.append(fragment);
                        Log.v("FragmentManager", stringBuilder.toString());
                    }
                }
                View requireView = this.mFragment.requireView();
                if (requireView.getParent() == null) {
                    this.mFragmentStateManager.addViewToContainer();
                    requireView.setAlpha(0.0f);
                }
                if (requireView.getAlpha() == 0.0f && requireView.getVisibility() == 0) {
                    requireView.setVisibility(4);
                }
                AnimationInfo animationInfo = fragment.mAnimationInfo;
                if (animationInfo == null) {
                    f = 1.0f;
                } else {
                    f = animationInfo.mPostOnViewCreatedAlpha;
                }
                requireView.setAlpha(f);
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.SpecialEffectsController$Operation */
    class Operation {
        private final List mCompletionListeners = new ArrayList();
        public int mFinalState$ar$edu;
        public final Fragment mFragment;
        public boolean mIsCanceled = false;
        public boolean mIsComplete = false;
        public int mLifecycleImpact$ar$edu;
        public final HashSet mSpecialEffectsSignals = new HashSet();

        /* renamed from: android.support.v4.app.SpecialEffectsController$Operation$1 */
        final class PG implements OnCancelListener {
            public final void onCancel() {
                Operation.this.cancel();
            }
        }

        /* compiled from: PG */
        /* renamed from: android.support.v4.app.SpecialEffectsController$Operation$LifecycleImpact */
        final class LifecycleImpact {
            public static /* synthetic */ String toStringGeneratedc4bc3d545aab1bc8(int i) {
                switch (i) {
                    case 1:
                        return "NONE";
                    case 2:
                        return "ADDING";
                    case 3:
                        return "REMOVING";
                    default:
                        return "null";
                }
            }
        }

        /* compiled from: PG */
        /* renamed from: android.support.v4.app.SpecialEffectsController$Operation$State */
        final class State {
            static void applyState$ar$edu(int i, View view) {
                String str = "SpecialEffectsController: Setting view ";
                String str2 = "FragmentManager";
                StringBuilder stringBuilder;
                switch (i - 1) {
                    case 0:
                        ViewGroup viewGroup = (ViewGroup) view.getParent();
                        if (viewGroup != null) {
                            if (FragmentManager.isLoggingEnabled(2)) {
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append("SpecialEffectsController: Removing view ");
                                stringBuilder2.append(view);
                                stringBuilder2.append(" from container ");
                                stringBuilder2.append(viewGroup);
                                Log.v(str2, stringBuilder2.toString());
                            }
                            viewGroup.removeView(view);
                        }
                        return;
                    case 1:
                        if (FragmentManager.isLoggingEnabled(2)) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str);
                            stringBuilder.append(view);
                            stringBuilder.append(" to VISIBLE");
                            Log.v(str2, stringBuilder.toString());
                        }
                        view.setVisibility(0);
                        return;
                    case 2:
                        if (FragmentManager.isLoggingEnabled(2)) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str);
                            stringBuilder.append(view);
                            stringBuilder.append(" to GONE");
                            Log.v(str2, stringBuilder.toString());
                        }
                        view.setVisibility(8);
                        return;
                    default:
                        if (FragmentManager.isLoggingEnabled(2)) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str);
                            stringBuilder.append(view);
                            stringBuilder.append(" to INVISIBLE");
                            Log.v(str2, stringBuilder.toString());
                        }
                        view.setVisibility(4);
                        return;
                }
            }

            static int from$ar$edu(int i) {
                switch (i) {
                    case 0:
                        return 2;
                    case 4:
                        return 4;
                    case 8:
                        return 3;
                    default:
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Unknown visibility ");
                        stringBuilder.append(i);
                        throw new IllegalArgumentException(stringBuilder.toString());
                }
            }

            static int from$ar$edu$b2310ebe_0(View view) {
                if (view.getAlpha() == 0.0f && view.getVisibility() == 0) {
                    return 4;
                }
                return State.from$ar$edu(view.getVisibility());
            }

            public static /* synthetic */ String toStringGenerated247055cdec681852(int i) {
                switch (i) {
                    case 1:
                        return "REMOVED";
                    case 2:
                        return "VISIBLE";
                    case 3:
                        return "GONE";
                    case 4:
                        return "INVISIBLE";
                    default:
                        return "null";
                }
            }
        }

        public Operation(int i, int i2, Fragment fragment, CancellationSignal cancellationSignal) {
            this.mFinalState$ar$edu = i;
            this.mLifecycleImpact$ar$edu = i2;
            this.mFragment = fragment;
            cancellationSignal.setOnCancelListener(new PG());
        }

        final void addCompletionListener(Runnable runnable) {
            this.mCompletionListeners.add(runnable);
        }

        final void cancel() {
            if (!this.mIsCanceled) {
                this.mIsCanceled = true;
                if (this.mSpecialEffectsSignals.isEmpty()) {
                    complete();
                    return;
                }
                List arrayList = new ArrayList(this.mSpecialEffectsSignals);
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    CancellationSignal cancellationSignal = (CancellationSignal) arrayList.get(i);
                    synchronized (cancellationSignal) {
                        if (cancellationSignal.mIsCanceled) {
                        } else {
                            cancellationSignal.mIsCanceled = true;
                            cancellationSignal.mCancelInProgress = true;
                            OnCancelListener onCancelListener = cancellationSignal.mOnCancelListener;
                            if (onCancelListener != null) {
                                try {
                                    onCancelListener.onCancel();
                                } catch (Throwable th) {
                                    synchronized (cancellationSignal) {
                                        cancellationSignal.mCancelInProgress = false;
                                        cancellationSignal.notifyAll();
                                    }
                                }
                            }
                            synchronized (cancellationSignal) {
                                cancellationSignal.mCancelInProgress = false;
                                cancellationSignal.notifyAll();
                            }
                        }
                    }
                }
            }
        }

        public void complete() {
            if (!this.mIsComplete) {
                if (FragmentManager.isLoggingEnabled(2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SpecialEffectsController: ");
                    stringBuilder.append(this);
                    stringBuilder.append(" has called complete.");
                    Log.v("FragmentManager", stringBuilder.toString());
                }
                this.mIsComplete = true;
                for (Runnable run : this.mCompletionListeners) {
                    run.run();
                }
            }
        }

        public final void markStartedSpecialEffect(CancellationSignal cancellationSignal) {
            onStart();
            this.mSpecialEffectsSignals.add(cancellationSignal);
        }

        final void mergeWith$ar$edu(int i, int i2) {
            String str = " mFinalState = ";
            String str2 = "FragmentManager";
            String str3 = "SpecialEffectsController: For fragment ";
            StringBuilder stringBuilder;
            switch (i2 - 1) {
                case 1:
                    if (this.mFinalState$ar$edu == 1) {
                        if (FragmentManager.isLoggingEnabled(2)) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str3);
                            stringBuilder.append(this.mFragment);
                            stringBuilder.append(" mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = ");
                            stringBuilder.append(LifecycleImpact.toStringGeneratedc4bc3d545aab1bc8(this.mLifecycleImpact$ar$edu));
                            stringBuilder.append(" to ADDING.");
                            Log.v(str2, stringBuilder.toString());
                        }
                        this.mFinalState$ar$edu = 2;
                        this.mLifecycleImpact$ar$edu = 2;
                        return;
                    }
                    break;
                case 2:
                    if (FragmentManager.isLoggingEnabled(2)) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(str3);
                        stringBuilder.append(this.mFragment);
                        stringBuilder.append(str);
                        stringBuilder.append(State.toStringGenerated247055cdec681852(this.mFinalState$ar$edu));
                        stringBuilder.append(" -> REMOVED. mLifecycleImpact  = ");
                        stringBuilder.append(LifecycleImpact.toStringGeneratedc4bc3d545aab1bc8(this.mLifecycleImpact$ar$edu));
                        stringBuilder.append(" to REMOVING.");
                        Log.v(str2, stringBuilder.toString());
                    }
                    this.mFinalState$ar$edu = 1;
                    this.mLifecycleImpact$ar$edu = 3;
                    return;
                default:
                    if (this.mFinalState$ar$edu != 1) {
                        if (FragmentManager.isLoggingEnabled(2)) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(str3);
                            stringBuilder2.append(this.mFragment);
                            stringBuilder2.append(str);
                            stringBuilder2.append(State.toStringGenerated247055cdec681852(this.mFinalState$ar$edu));
                            stringBuilder2.append(" -> ");
                            stringBuilder2.append(State.toStringGenerated247055cdec681852(i));
                            stringBuilder2.append(". ");
                            Log.v(str2, stringBuilder2.toString());
                        }
                        this.mFinalState$ar$edu = i;
                        break;
                    }
                    break;
            }
        }

        public void onStart() {
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Operation {");
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append("} {mFinalState = ");
            stringBuilder.append(State.toStringGenerated247055cdec681852(this.mFinalState$ar$edu));
            stringBuilder.append("} {mLifecycleImpact = ");
            stringBuilder.append(LifecycleImpact.toStringGeneratedc4bc3d545aab1bc8(this.mLifecycleImpact$ar$edu));
            stringBuilder.append("} {mFragment = ");
            stringBuilder.append(this.mFragment);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

    public SpecialEffectsController(ViewGroup viewGroup) {
        this.mContainer = viewGroup;
    }

    static SpecialEffectsController getOrCreateController(ViewGroup viewGroup, FragmentManager fragmentManager) {
        fragmentManager.getSpecialEffectsControllerFactory$ar$class_merging();
        return SpecialEffectsController.getOrCreateController$ar$class_merging$ar$ds(viewGroup);
    }

    static SpecialEffectsController getOrCreateController$ar$class_merging$ar$ds(ViewGroup viewGroup) {
        Object tag = viewGroup.getTag(R.id.special_effects_controller_view_tag);
        if (tag instanceof SpecialEffectsController) {
            return (SpecialEffectsController) tag;
        }
        SpecialEffectsController defaultSpecialEffectsController = new DefaultSpecialEffectsController(viewGroup);
        viewGroup.setTag(R.id.special_effects_controller_view_tag, defaultSpecialEffectsController);
        return defaultSpecialEffectsController;
    }

    public final void enqueue$ar$edu(int i, int i2, FragmentStateManager fragmentStateManager) {
        synchronized (this.mPendingOperations) {
            CancellationSignal cancellationSignal = new CancellationSignal();
            Operation findPendingOperation = findPendingOperation(fragmentStateManager.mFragment);
            if (findPendingOperation != null) {
                findPendingOperation.mergeWith$ar$edu(i, i2);
                return;
            }
            findPendingOperation = new FragmentStateManagerOperation(i, i2, fragmentStateManager, cancellationSignal);
            this.mPendingOperations.add(findPendingOperation);
            findPendingOperation.addCompletionListener(new Runnable() {
                public final void run() {
                    if (SpecialEffectsController.this.mPendingOperations.contains(findPendingOperation)) {
                        Operation operation = findPendingOperation;
                        State.applyState$ar$edu(operation.mFinalState$ar$edu, operation.mFragment.mView);
                    }
                }
            });
            findPendingOperation.addCompletionListener(new Runnable() {
                public final void run() {
                    android.support.p000v4.app.SpecialEffectsController.this.mPendingOperations.remove(findPendingOperation);
                    android.support.p000v4.app.SpecialEffectsController.this.mRunningOperations.remove(findPendingOperation);
                }
            });
        }
    }

    public abstract void executeOperations(List list, boolean z);

    public final Operation findPendingOperation(Fragment fragment) {
        List list = this.mPendingOperations;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            Operation operation = (Operation) list.get(i);
            if (operation.mFragment.equals(fragment)) {
                if (!operation.mIsCanceled) {
                    return operation;
                }
            }
        }
        return null;
    }

    final void forceCompleteAllOperations() {
        if (FragmentManager.isLoggingEnabled(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Forcing all operations to complete");
        }
        boolean isAttachedToWindow = ViewCompat.isAttachedToWindow(this.mContainer);
        synchronized (this.mPendingOperations) {
            updateFinalState();
            Iterator it = this.mPendingOperations.iterator();
            while (it.hasNext()) {
                ((Operation) it.next()).onStart();
            }
            it = new ArrayList(this.mRunningOperations).iterator();
            while (it.hasNext()) {
                String str;
                Operation operation = (Operation) it.next();
                if (FragmentManager.isLoggingEnabled(2)) {
                    String str2 = "FragmentManager";
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("SpecialEffectsController: ");
                    if (isAttachedToWindow) {
                        str = "";
                    } else {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("Container ");
                        stringBuilder2.append(this.mContainer);
                        stringBuilder2.append(" is not attached to window. ");
                        str = stringBuilder2.toString();
                    }
                    stringBuilder.append(str);
                    stringBuilder.append("Cancelling running operation ");
                    stringBuilder.append(operation);
                    Log.v(str2, stringBuilder.toString());
                }
                operation.cancel();
            }
            it = new ArrayList(this.mPendingOperations).iterator();
            while (it.hasNext()) {
                operation = (Operation) it.next();
                if (FragmentManager.isLoggingEnabled(2)) {
                    str2 = "FragmentManager";
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("SpecialEffectsController: ");
                    if (isAttachedToWindow) {
                        str = "";
                    } else {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("Container ");
                        stringBuilder2.append(this.mContainer);
                        stringBuilder2.append(" is not attached to window. ");
                        str = stringBuilder2.toString();
                    }
                    stringBuilder.append(str);
                    stringBuilder.append("Cancelling pending operation ");
                    stringBuilder.append(operation);
                    Log.v(str2, stringBuilder.toString());
                }
                operation.cancel();
            }
        }
    }

    public final void updateFinalState() {
        List list = this.mPendingOperations;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            Operation operation = (Operation) list.get(i);
            if (operation.mLifecycleImpact$ar$edu == 2) {
                operation.mergeWith$ar$edu(State.from$ar$edu(operation.mFragment.requireView().getVisibility()), 1);
            }
        }
    }
}
