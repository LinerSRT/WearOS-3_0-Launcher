package android.support.p000v4.app;

import android.content.Context;
import java.util.ArrayList;
import java.util.Iterator;

/* compiled from: PG */
/* renamed from: android.support.v4.app.TaskStackBuilder */
public final class TaskStackBuilder implements Iterable {
    public final ArrayList mIntents = new ArrayList();
    public final Context mSourceContext;

    public TaskStackBuilder(Context context) {
        this.mSourceContext = context;
    }

    @Deprecated
    public final Iterator iterator() {
        return this.mIntents.iterator();
    }
}
