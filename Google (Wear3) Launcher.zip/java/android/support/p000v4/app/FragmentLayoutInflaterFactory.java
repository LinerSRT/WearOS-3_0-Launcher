package android.support.p000v4.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.fragment.R$styleable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater.Factory2;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import androidx.fragment.app.strictmode.FragmentStrictMode;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentLayoutInflaterFactory */
final class FragmentLayoutInflaterFactory implements Factory2 {
    final FragmentManager mFragmentManager;

    public FragmentLayoutInflaterFactory(FragmentManager fragmentManager) {
        this.mFragmentManager = fragmentManager;
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        if (FragmentContainerView.class.getName().equals(str)) {
            return new FragmentContainerView(context, attributeSet, this.mFragmentManager);
        }
        Fragment fragment = null;
        if (!"fragment".equals(str)) {
            return null;
        }
        str = attributeSet.getAttributeValue(null, "class");
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.Fragment);
        int i = 0;
        if (str == null) {
            str = obtainStyledAttributes.getString(0);
        }
        int resourceId = obtainStyledAttributes.getResourceId(1, -1);
        String string = obtainStyledAttributes.getString(2);
        obtainStyledAttributes.recycle();
        if (str != null) {
            if (FragmentFactory.isFragmentClass(context.getClassLoader(), str)) {
                StringBuilder stringBuilder;
                FragmentStateManager addFragment;
                if (view != null) {
                    i = view.getId();
                }
                if (i == -1) {
                    if (resourceId != -1) {
                        i = -1;
                    } else if (string != null) {
                        i = -1;
                        resourceId = -1;
                    } else {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(attributeSet.getPositionDescription());
                        stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
                        stringBuilder.append(str);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                }
                if (resourceId != -1) {
                    fragment = this.mFragmentManager.findFragmentById(resourceId);
                }
                if (fragment == null && string != null) {
                    fragment = this.mFragmentManager.findFragmentByTag(string);
                }
                if (fragment == null && i != -1) {
                    fragment = this.mFragmentManager.findFragmentById(i);
                }
                String str2 = "Fragment ";
                String str3 = "FragmentManager";
                FragmentManager fragmentManager;
                StringBuilder stringBuilder2;
                if (fragment == null) {
                    FragmentFactory fragmentFactory = this.mFragmentManager.getFragmentFactory();
                    context.getClassLoader();
                    fragment = fragmentFactory.instantiate$ar$ds$540c62b6_0(str);
                    fragment.mFromLayout = true;
                    fragment.mFragmentId = resourceId != 0 ? resourceId : i;
                    fragment.mContainerId = i;
                    fragment.mTag = string;
                    fragment.mInLayout = true;
                    fragment.mFragmentManager = this.mFragmentManager;
                    fragmentManager = this.mFragmentManager;
                    fragment.mHost = fragmentManager.mHost;
                    context = fragmentManager.mHost.mContext;
                    Bundle bundle = fragment.mSavedFragmentState;
                    fragment.onInflate$ar$ds();
                    addFragment = this.mFragmentManager.addFragment(fragment);
                    if (FragmentManager.isLoggingEnabled(2)) {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(str2);
                        stringBuilder2.append(fragment);
                        stringBuilder2.append(" has been inflated via the <fragment> tag: id=0x");
                        stringBuilder2.append(Integer.toHexString(resourceId));
                        Log.v(str3, stringBuilder2.toString());
                    }
                } else if (fragment.mInLayout) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(attributeSet.getPositionDescription());
                    stringBuilder.append(": Duplicate id 0x");
                    stringBuilder.append(Integer.toHexString(resourceId));
                    stringBuilder.append(", tag ");
                    stringBuilder.append(string);
                    stringBuilder.append(", or parent id 0x");
                    stringBuilder.append(Integer.toHexString(i));
                    stringBuilder.append(" with another fragment for ");
                    stringBuilder.append(str);
                    throw new IllegalArgumentException(stringBuilder.toString());
                } else {
                    fragment.mInLayout = true;
                    fragment.mFragmentManager = this.mFragmentManager;
                    fragmentManager = this.mFragmentManager;
                    fragment.mHost = fragmentManager.mHost;
                    context = fragmentManager.mHost.mContext;
                    fragment.onInflate$ar$ds();
                    addFragment = this.mFragmentManager.createOrGetFragmentStateManager(fragment);
                    if (FragmentManager.isLoggingEnabled(2)) {
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("Retained Fragment ");
                        stringBuilder2.append(fragment);
                        stringBuilder2.append(" has been re-attached via the <fragment> tag: id=0x");
                        stringBuilder2.append(Integer.toHexString(resourceId));
                        Log.v(str3, stringBuilder2.toString());
                    }
                }
                ViewGroup viewGroup = (ViewGroup) view;
                FragmentStrictMode.onFragmentTagUsage(fragment, viewGroup);
                fragment.mContainer = viewGroup;
                addFragment.moveToExpectedState();
                addFragment.ensureInflatedView();
                view = fragment.mView;
                if (view != null) {
                    if (resourceId != 0) {
                        view.setId(resourceId);
                    }
                    if (fragment.mView.getTag() == null) {
                        fragment.mView.setTag(string);
                    }
                    fragment.mView.addOnAttachStateChangeListener(new OnAttachStateChangeListener() {
                        public final void onViewAttachedToWindow(View view) {
                            FragmentStateManager fragmentStateManager = addFragment;
                            Fragment fragment = fragmentStateManager.mFragment;
                            fragmentStateManager.moveToExpectedState();
                            SpecialEffectsController.getOrCreateController((ViewGroup) fragment.mView.getParent(), FragmentLayoutInflaterFactory.this.mFragmentManager).forceCompleteAllOperations();
                        }

                        public final void onViewDetachedFromWindow(View view) {
                        }
                    });
                    return fragment.mView;
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append(str2);
                stringBuilder.append(str);
                stringBuilder.append(" did not create a view.");
                throw new IllegalStateException(stringBuilder.toString());
            }
        }
        return null;
    }

    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
