package android.support.p000v4.app;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentController */
public final class FragmentController {
    public final FragmentHostCallback mHost;

    public FragmentController(FragmentHostCallback fragmentHostCallback) {
        this.mHost = fragmentHostCallback;
    }

    public final void execPendingActions$ar$ds() {
        this.mHost.mFragmentManager.execPendingActions$ar$ds$3011d4e5_0(true);
    }

    public final FragmentManager getSupportFragmentManager() {
        return this.mHost.mFragmentManager;
    }

    public final void noteStateNotSaved() {
        this.mHost.mFragmentManager.noteStateNotSaved();
    }
}
