package android.support.p000v4.app;

import android.content.res.Resources.NotFoundException;
import android.os.Bundle;
import android.support.p000v4.view.ViewCompat;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import androidx.fragment.app.strictmode.FragmentStrictMode;
import androidx.lifecycle.Lifecycle.State;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentStateManager */
final class FragmentStateManager {
    public final FragmentLifecycleCallbacksDispatcher mDispatcher;
    public final Fragment mFragment;
    public int mFragmentManagerState = -1;
    public final FragmentStore mFragmentStore;
    private boolean mMovingToState = false;

    /* renamed from: android.support.v4.app.FragmentStateManager$1 */
    final class PG implements OnAttachStateChangeListener {
        final /* synthetic */ View val$fragmentView;

        public PG(View view) {
            this.val$fragmentView = view;
        }

        public final void onViewAttachedToWindow(View view) {
            this.val$fragmentView.removeOnAttachStateChangeListener(this);
            ViewCompat.requestApplyInsets(this.val$fragmentView);
        }

        public final void onViewDetachedFromWindow(View view) {
        }
    }

    public FragmentStateManager(FragmentLifecycleCallbacksDispatcher fragmentLifecycleCallbacksDispatcher, FragmentStore fragmentStore, Fragment fragment) {
        this.mDispatcher = fragmentLifecycleCallbacksDispatcher;
        this.mFragmentStore = fragmentStore;
        this.mFragment = fragment;
    }

    final void createView() {
        if (!this.mFragment.mFromLayout) {
            String str = "FragmentManager";
            if (FragmentManager.isLoggingEnabled(3)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("moveto CREATE_VIEW: ");
                stringBuilder.append(this.mFragment);
                Log.d(str, stringBuilder.toString());
            }
            Fragment fragment = this.mFragment;
            LayoutInflater performGetLayoutInflater = fragment.performGetLayoutInflater(fragment.mSavedFragmentState);
            Fragment fragment2 = this.mFragment;
            ViewGroup viewGroup = fragment2.mContainer;
            if (viewGroup == null) {
                int i = fragment2.mContainerId;
                if (i == 0) {
                    viewGroup = null;
                } else if (i != -1) {
                    viewGroup = (ViewGroup) fragment2.mFragmentManager.mContainer.onFindViewById(i);
                    if (viewGroup == null) {
                        fragment2 = this.mFragment;
                        if (!fragment2.mRestored) {
                            String resourceName;
                            try {
                                resourceName = fragment2.getResources().getResourceName(this.mFragment.mContainerId);
                            } catch (NotFoundException e) {
                                resourceName = "unknown";
                            }
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("No view found for id 0x");
                            stringBuilder2.append(Integer.toHexString(this.mFragment.mContainerId));
                            stringBuilder2.append(" (");
                            stringBuilder2.append(resourceName);
                            stringBuilder2.append(") for fragment ");
                            stringBuilder2.append(this.mFragment);
                            throw new IllegalArgumentException(stringBuilder2.toString());
                        }
                    } else if (!(viewGroup instanceof FragmentContainerView)) {
                        FragmentStrictMode.onWrongFragmentContainer(this.mFragment, viewGroup);
                    }
                } else {
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("Cannot create fragment ");
                    stringBuilder3.append(this.mFragment);
                    stringBuilder3.append(" for a container view with no id");
                    throw new IllegalArgumentException(stringBuilder3.toString());
                }
            }
            fragment2 = this.mFragment;
            fragment2.mContainer = viewGroup;
            fragment2.performCreateView(performGetLayoutInflater, viewGroup, fragment2.mSavedFragmentState);
            View view = this.mFragment.mView;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                fragment = this.mFragment;
                fragment.mView.setTag(R.id.fragment_container_view_tag, fragment);
                if (viewGroup != null) {
                    addViewToContainer();
                }
                fragment = this.mFragment;
                if (fragment.mHidden) {
                    fragment.mView.setVisibility(8);
                }
                if (ViewCompat.isAttachedToWindow(this.mFragment.mView)) {
                    ViewCompat.requestApplyInsets(this.mFragment.mView);
                } else {
                    view = this.mFragment.mView;
                    view.addOnAttachStateChangeListener(new PG(view));
                }
                this.mFragment.performViewCreated();
                FragmentLifecycleCallbacksDispatcher fragmentLifecycleCallbacksDispatcher = this.mDispatcher;
                Fragment fragment3 = this.mFragment;
                fragmentLifecycleCallbacksDispatcher.dispatchOnFragmentViewCreated(fragment3, fragment3.mView, fragment3.mSavedFragmentState, false);
                int visibility = this.mFragment.mView.getVisibility();
                this.mFragment.ensureAnimationInfo().mPostOnViewCreatedAlpha = this.mFragment.mView.getAlpha();
                fragment3 = this.mFragment;
                if (fragment3.mContainer != null && visibility == 0) {
                    view = fragment3.mView.findFocus();
                    if (view != null) {
                        this.mFragment.setFocusedView(view);
                        if (FragmentManager.isLoggingEnabled(2)) {
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("requestFocus: Saved focused view ");
                            stringBuilder4.append(view);
                            stringBuilder4.append(" for Fragment ");
                            stringBuilder4.append(this.mFragment);
                            Log.v(str, stringBuilder4.toString());
                        }
                    }
                    this.mFragment.mView.setAlpha(0.0f);
                }
            }
            this.mFragment.mState = 2;
        }
    }

    final void ensureInflatedView() {
        Fragment fragment = this.mFragment;
        if (fragment.mFromLayout && fragment.mInLayout && !fragment.mPerformedCreateView) {
            if (FragmentManager.isLoggingEnabled(3)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("moveto CREATE_VIEW: ");
                stringBuilder.append(this.mFragment);
                Log.d("FragmentManager", stringBuilder.toString());
            }
            fragment = this.mFragment;
            fragment.performCreateView(fragment.performGetLayoutInflater(fragment.mSavedFragmentState), null, this.mFragment.mSavedFragmentState);
            View view = this.mFragment.mView;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                fragment = this.mFragment;
                fragment.mView.setTag(R.id.fragment_container_view_tag, fragment);
                fragment = this.mFragment;
                if (fragment.mHidden) {
                    fragment.mView.setVisibility(8);
                }
                this.mFragment.performViewCreated();
                FragmentLifecycleCallbacksDispatcher fragmentLifecycleCallbacksDispatcher = this.mDispatcher;
                Fragment fragment2 = this.mFragment;
                fragmentLifecycleCallbacksDispatcher.dispatchOnFragmentViewCreated(fragment2, fragment2.mView, fragment2.mSavedFragmentState, false);
                this.mFragment.mState = 2;
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final void moveToExpectedState() {
        /*
        r17 = this;
        r1 = r17;
        r2 = r1.mMovingToState;
        r3 = 2;
        r4 = "FragmentManager";
        if (r2 == 0) goto L_0x0026;
    L_0x0009:
        r2 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r3);
        if (r2 == 0) goto L_0x0025;
    L_0x000f:
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = "Ignoring re-entrant call to moveToExpectedState() for ";
        r2.append(r3);
        r3 = r1.mFragment;
        r2.append(r3);
        r2 = r2.toString();
        android.util.Log.v(r4, r2);
    L_0x0025:
        return;
    L_0x0026:
        r2 = 1;
        r5 = 0;
        r1.mMovingToState = r2;	 Catch:{ all -> 0x0a1c }
        r6 = 0;
    L_0x002b:
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r8 = r7.mFragmentManager;	 Catch:{ all -> 0x0a1c }
        r9 = 6;
        r10 = 4;
        r11 = 5;
        r12 = -1;
        r13 = 3;
        if (r8 != 0) goto L_0x003a;
    L_0x0036:
        r7 = r7.mState;	 Catch:{ all -> 0x0a1c }
        goto L_0x013e;
    L_0x003a:
        r8 = r1.mFragmentManagerState;	 Catch:{ all -> 0x0a1c }
        r15 = androidx.lifecycle.Lifecycle.State.DESTROYED;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mMaxState;	 Catch:{ all -> 0x0a1c }
        r7 = r7.ordinal();	 Catch:{ all -> 0x0a1c }
        switch(r7) {
            case 1: goto L_0x0059;
            case 2: goto L_0x0053;
            case 3: goto L_0x004d;
            case 4: goto L_0x004c;
            default: goto L_0x0047;
        };	 Catch:{ all -> 0x0a1c }
    L_0x0047:
        r8 = java.lang.Math.min(r8, r12);	 Catch:{ all -> 0x0a1c }
        goto L_0x005e;
    L_0x004c:
        goto L_0x005e;
        r8 = java.lang.Math.min(r8, r11);	 Catch:{ all -> 0x0a1c }
        goto L_0x005e;
        r8 = java.lang.Math.min(r8, r2);	 Catch:{ all -> 0x0a1c }
        goto L_0x005e;
        r8 = java.lang.Math.min(r8, r5);	 Catch:{ all -> 0x0a1c }
    L_0x005e:
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r15 = r7.mFromLayout;	 Catch:{ all -> 0x0a1c }
        if (r15 == 0) goto L_0x008f;
    L_0x0064:
        r15 = r7.mInLayout;	 Catch:{ all -> 0x0a1c }
        if (r15 == 0) goto L_0x007f;
    L_0x0068:
        r7 = r1.mFragmentManagerState;	 Catch:{ all -> 0x0a1c }
        r8 = java.lang.Math.max(r7, r3);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mView;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x008f;
    L_0x0074:
        r7 = r7.getParent();	 Catch:{ all -> 0x0a1c }
        if (r7 != 0) goto L_0x008f;
    L_0x007a:
        r8 = java.lang.Math.min(r8, r3);	 Catch:{ all -> 0x0a1c }
        goto L_0x008f;
    L_0x007f:
        r15 = r1.mFragmentManagerState;	 Catch:{ all -> 0x0a1c }
        if (r15 >= r10) goto L_0x008a;
    L_0x0083:
        r7 = r7.mState;	 Catch:{ all -> 0x0a1c }
        r8 = java.lang.Math.min(r8, r7);	 Catch:{ all -> 0x0a1c }
        goto L_0x008f;
        r8 = java.lang.Math.min(r8, r2);	 Catch:{ all -> 0x0a1c }
    L_0x008f:
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mAdded;	 Catch:{ all -> 0x0a1c }
        if (r7 != 0) goto L_0x0099;
    L_0x0095:
        r8 = java.lang.Math.min(r8, r2);	 Catch:{ all -> 0x0a1c }
    L_0x0099:
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r15 = r7.mContainer;	 Catch:{ all -> 0x0a1c }
        if (r15 == 0) goto L_0x00e2;
    L_0x009f:
        r7 = r7.getParentFragmentManager();	 Catch:{ all -> 0x0a1c }
        r7 = android.support.p000v4.app.SpecialEffectsController.getOrCreateController(r15, r7);	 Catch:{ all -> 0x0a1c }
        r15 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r15 = r7.findPendingOperation(r15);	 Catch:{ all -> 0x0a1c }
        if (r15 == 0) goto L_0x00b2;
    L_0x00af:
        r15 = r15.mLifecycleImpact$ar$edu;	 Catch:{ all -> 0x0a1c }
        goto L_0x00b3;
    L_0x00b2:
        r15 = 0;
    L_0x00b3:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mRunningOperations;	 Catch:{ all -> 0x0a1c }
        r14 = r7.size();	 Catch:{ all -> 0x0a1c }
        r10 = 0;
    L_0x00bc:
        if (r10 >= r14) goto L_0x00d8;
    L_0x00be:
        r16 = r7.get(r10);	 Catch:{ all -> 0x0a1c }
        r11 = r16;
        r11 = (android.support.p000v4.app.SpecialEffectsController.Operation) r11;	 Catch:{ all -> 0x0a1c }
        r12 = r11.mFragment;	 Catch:{ all -> 0x0a1c }
        r12 = r12.equals(r5);	 Catch:{ all -> 0x0a1c }
        if (r12 == 0) goto L_0x00d3;
    L_0x00ce:
        r12 = r11.mIsCanceled;	 Catch:{ all -> 0x0a1c }
        if (r12 != 0) goto L_0x00d3;
    L_0x00d2:
        goto L_0x00d9;
    L_0x00d3:
        r10 = r10 + 1;
        r11 = 5;
        r12 = -1;
        goto L_0x00bc;
    L_0x00d8:
        r11 = 0;
    L_0x00d9:
        if (r11 == 0) goto L_0x00e3;
    L_0x00db:
        if (r15 == 0) goto L_0x00df;
    L_0x00dd:
        if (r15 != r2) goto L_0x00e3;
    L_0x00df:
        r15 = r11.mLifecycleImpact$ar$edu;	 Catch:{ all -> 0x0a1c }
        goto L_0x00e3;
    L_0x00e2:
        r15 = 0;
    L_0x00e3:
        if (r15 != r3) goto L_0x00ea;
    L_0x00e5:
        r8 = java.lang.Math.min(r8, r9);	 Catch:{ all -> 0x0a1c }
        goto L_0x0108;
    L_0x00ea:
        if (r15 != r13) goto L_0x00f1;
    L_0x00ec:
        r8 = java.lang.Math.max(r8, r13);	 Catch:{ all -> 0x0a1c }
        goto L_0x0108;
    L_0x00f1:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mRemoving;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0108;
    L_0x00f7:
        r5 = r5.isInBackStack();	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0102;
    L_0x00fd:
        r8 = java.lang.Math.min(r8, r2);	 Catch:{ all -> 0x0a1c }
        goto L_0x0108;
        r5 = -1;
        r8 = java.lang.Math.min(r8, r5);	 Catch:{ all -> 0x0a1c }
    L_0x0108:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mDeferStart;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0119;
    L_0x010e:
        r5 = r5.mState;	 Catch:{ all -> 0x0a1c }
        r7 = 5;
        if (r5 >= r7) goto L_0x0119;
    L_0x0113:
        r5 = 4;
        r7 = java.lang.Math.min(r8, r5);	 Catch:{ all -> 0x0a1c }
        goto L_0x011a;
    L_0x0119:
        r7 = r8;
    L_0x011a:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r3);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x013e;
    L_0x0120:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r8 = "computeExpectedState() of ";
        r5.append(r8);	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r8 = " for ";
        r5.append(r8);	 Catch:{ all -> 0x0a1c }
        r8 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r8);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.v(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x013e:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r8 = r5.mState;	 Catch:{ all -> 0x0a1c }
        r10 = "initState called for fragment: ";
        if (r7 == r8) goto L_0x0946;
    L_0x0146:
        r6 = "Fragment ";
        if (r7 <= r8) goto L_0x0587;
    L_0x014a:
        r8 = r8 + 1;
        switch(r8) {
            case 0: goto L_0x045b;
            case 1: goto L_0x03cf;
            case 2: goto L_0x03c7;
            case 3: goto L_0x02fc;
            case 4: goto L_0x02b7;
            case 5: goto L_0x0245;
            case 6: goto L_0x023e;
            case 7: goto L_0x0153;
            default: goto L_0x014f;
        };
    L_0x014f:
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x0153:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x016f;
    L_0x0159:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "moveto RESUMED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x016f:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mAnimationInfo;	 Catch:{ all -> 0x0a1c }
        if (r7 != 0) goto L_0x0177;
    L_0x0175:
        r7 = 0;
        goto L_0x0179;
    L_0x0177:
        r7 = r7.mFocusedView;	 Catch:{ all -> 0x0a1c }
    L_0x0179:
        if (r7 != 0) goto L_0x017c;
    L_0x017b:
        goto L_0x01d9;
    L_0x017c:
        r5 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r7 != r5) goto L_0x0181;
    L_0x0180:
        goto L_0x0192;
    L_0x0181:
        r5 = r7.getParent();	 Catch:{ all -> 0x0a1c }
    L_0x0185:
        if (r5 == 0) goto L_0x01d9;
    L_0x0187:
        r8 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r8 = r8.mView;	 Catch:{ all -> 0x0a1c }
        if (r5 == r8) goto L_0x0192;
    L_0x018d:
        r5 = r5.getParent();	 Catch:{ all -> 0x0a1c }
        goto L_0x0185;
    L_0x0192:
        r5 = r7.requestFocus();	 Catch:{ all -> 0x0a1c }
        r8 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r3);	 Catch:{ all -> 0x0a1c }
        if (r8 == 0) goto L_0x01d9;
    L_0x019c:
        r8 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r8.<init>();	 Catch:{ all -> 0x0a1c }
        r9 = "requestFocus: Restoring focused view ";
        r8.append(r9);	 Catch:{ all -> 0x0a1c }
        r8.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = " ";
        r8.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = "succeeded";
        r9 = "failed";
        if (r2 == r5) goto L_0x01b5;
    L_0x01b4:
        r7 = r9;
    L_0x01b5:
        r8.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = " on Fragment ";
        r8.append(r5);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r8.append(r5);	 Catch:{ all -> 0x0a1c }
        r5 = " resulting in focused view ";
        r8.append(r5);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mView;	 Catch:{ all -> 0x0a1c }
        r5 = r5.findFocus();	 Catch:{ all -> 0x0a1c }
        r8.append(r5);	 Catch:{ all -> 0x0a1c }
        r5 = r8.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.v(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x01d9:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.setFocusedView(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7.noteStateNotSaved();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7.execPendingActions$ar$ds$3011d4e5_0(r2);	 Catch:{ all -> 0x0a1c }
        r7 = 7;
        r5.mState = r7;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r5.onResume();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0224;
    L_0x01f8:
        r6 = r5.mLifecycleRegistry;	 Catch:{ all -> 0x0a1c }
        r7 = androidx.lifecycle.Lifecycle.Event.ON_RESUME;	 Catch:{ all -> 0x0a1c }
        r6.handleLifecycleEvent(r7);	 Catch:{ all -> 0x0a1c }
        r6 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x020a;
    L_0x0203:
        r6 = r5.mViewLifecycleOwner;	 Catch:{ all -> 0x0a1c }
        r7 = androidx.lifecycle.Lifecycle.Event.ON_RESUME;	 Catch:{ all -> 0x0a1c }
        r6.handleLifecycleEvent(r7);	 Catch:{ all -> 0x0a1c }
    L_0x020a:
        r5 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r5.dispatchResume();	 Catch:{ all -> 0x0a1c }
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.dispatchOnFragmentResumed(r6, r7);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = 0;
        r5.mSavedFragmentState = r6;	 Catch:{ all -> 0x0a1c }
        r5.mSavedViewState = r6;	 Catch:{ all -> 0x0a1c }
        r5.mSavedViewRegistryState = r6;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x0224:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onResume()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
        r5.mState = r9;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x0245:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0261;
    L_0x024b:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "moveto STARTED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x0261:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7.noteStateNotSaved();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7.execPendingActions$ar$ds$3011d4e5_0(r2);	 Catch:{ all -> 0x0a1c }
        r7 = 5;
        r5.mState = r7;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r5.onStart();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x029d;
    L_0x027a:
        r6 = r5.mLifecycleRegistry;	 Catch:{ all -> 0x0a1c }
        r7 = androidx.lifecycle.Lifecycle.Event.ON_START;	 Catch:{ all -> 0x0a1c }
        r6.handleLifecycleEvent(r7);	 Catch:{ all -> 0x0a1c }
        r6 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x028c;
    L_0x0285:
        r6 = r5.mViewLifecycleOwner;	 Catch:{ all -> 0x0a1c }
        r7 = androidx.lifecycle.Lifecycle.Event.ON_START;	 Catch:{ all -> 0x0a1c }
        r6.handleLifecycleEvent(r7);	 Catch:{ all -> 0x0a1c }
    L_0x028c:
        r5 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r5.dispatchStart();	 Catch:{ all -> 0x0a1c }
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.dispatchOnFragmentStarted(r6, r7);	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x029d:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onStart()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x02b7:
        r6 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x02f3;
    L_0x02bb:
        r6 = r5.mContainer;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x02f3;
    L_0x02bf:
        r5 = r5.getParentFragmentManager();	 Catch:{ all -> 0x0a1c }
        r5 = android.support.p000v4.app.SpecialEffectsController.getOrCreateController(r6, r5);	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = r6.mView;	 Catch:{ all -> 0x0a1c }
        r6 = r6.getVisibility();	 Catch:{ all -> 0x0a1c }
        r6 = android.support.p000v4.app.SpecialEffectsController.Operation.State.from$ar$edu(r6);	 Catch:{ all -> 0x0a1c }
        r7 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r3);	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x02ef;
    L_0x02d9:
        r7 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r7.<init>();	 Catch:{ all -> 0x0a1c }
        r8 = "SpecialEffectsController: Enqueuing add operation for fragment ";
        r7.append(r8);	 Catch:{ all -> 0x0a1c }
        r8 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7.append(r8);	 Catch:{ all -> 0x0a1c }
        r7 = r7.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.v(r4, r7);	 Catch:{ all -> 0x0a1c }
        r5.enqueue$ar$edu(r6, r3, r1);	 Catch:{ all -> 0x0a1c }
    L_0x02f3:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = 4;
        r5.mState = r6;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x02fc:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0318;
    L_0x0302:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "moveto ACTIVITY_CREATED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x0318:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mSavedFragmentState;	 Catch:{ all -> 0x0a1c }
        r8 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r8.noteStateNotSaved();	 Catch:{ all -> 0x0a1c }
        r5.mState = r13;	 Catch:{ all -> 0x0a1c }
        r8 = 0;
        r5.mCalled = r8;	 Catch:{ all -> 0x0a1c }
        r5.onActivityCreated(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x03ad;
    L_0x032d:
        r7 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0347;
    L_0x0333:
        r7 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r7.<init>();	 Catch:{ all -> 0x0a1c }
        r8 = "moveto RESTORE_VIEW_STATE: ";
        r7.append(r8);	 Catch:{ all -> 0x0a1c }
        r7.append(r5);	 Catch:{ all -> 0x0a1c }
        r7 = r7.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r7);	 Catch:{ all -> 0x0a1c }
    L_0x0347:
        r7 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0397;
    L_0x034b:
        r8 = r5.mSavedFragmentState;	 Catch:{ all -> 0x0a1c }
        r9 = r5.mSavedViewState;	 Catch:{ all -> 0x0a1c }
        if (r9 == 0) goto L_0x0357;
    L_0x0351:
        r7.restoreHierarchyState(r9);	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mSavedViewState = r7;	 Catch:{ all -> 0x0a1c }
    L_0x0357:
        r7 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0367;
    L_0x035b:
        r7 = r5.mViewLifecycleOwner;	 Catch:{ all -> 0x0a1c }
        r9 = r5.mSavedViewRegistryState;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mSavedStateRegistryController;	 Catch:{ all -> 0x0a1c }
        r7.performRestore(r9);	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mSavedViewRegistryState = r7;	 Catch:{ all -> 0x0a1c }
    L_0x0367:
        r7 = 0;
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r5.onViewStateRestored(r8);	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x037d;
    L_0x0371:
        r6 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x0397;
    L_0x0375:
        r6 = r5.mViewLifecycleOwner;	 Catch:{ all -> 0x0a1c }
        r7 = androidx.lifecycle.Lifecycle.Event.ON_CREATE;	 Catch:{ all -> 0x0a1c }
        r6.handleLifecycleEvent(r7);	 Catch:{ all -> 0x0a1c }
        goto L_0x0397;
    L_0x037d:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onViewStateRestored()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x0397:
        r6 = 0;
        r5.mSavedFragmentState = r6;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r5.dispatchActivityCreated();	 Catch:{ all -> 0x0a1c }
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r6.mSavedFragmentState;	 Catch:{ all -> 0x0a1c }
        r8 = 0;
        r5.dispatchOnFragmentActivityCreated(r6, r7, r8);	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x03ad:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onActivityCreated()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x03c7:
        r17.ensureInflatedView();	 Catch:{ all -> 0x0a1c }
        r17.createView();	 Catch:{ all -> 0x0a1c }
        goto L_0x058c;
    L_0x03cf:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x03eb;
    L_0x03d5:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "moveto CREATED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x03eb:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mIsCreated;	 Catch:{ all -> 0x0a1c }
        if (r7 != 0) goto L_0x044e;
    L_0x03f1:
        r7 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r8 = r5.mSavedFragmentState;	 Catch:{ all -> 0x0a1c }
        r9 = 0;
        r7.dispatchOnFragmentPreCreated(r5, r8, r9);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mSavedFragmentState;	 Catch:{ all -> 0x0a1c }
        r8 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r8.noteStateNotSaved();	 Catch:{ all -> 0x0a1c }
        r5.mState = r2;	 Catch:{ all -> 0x0a1c }
        r8 = 0;
        r5.mCalled = r8;	 Catch:{ all -> 0x0a1c }
        r8 = r5.mLifecycleRegistry;	 Catch:{ all -> 0x0a1c }
        r9 = new android.support.v4.app.Fragment$5;	 Catch:{ all -> 0x0a1c }
        r9.<init>();	 Catch:{ all -> 0x0a1c }
        r8.addObserver(r9);	 Catch:{ all -> 0x0a1c }
        r8 = r5.mSavedStateRegistryController;	 Catch:{ all -> 0x0a1c }
        r8.performRestore(r7);	 Catch:{ all -> 0x0a1c }
        r5.onCreate(r7);	 Catch:{ all -> 0x0a1c }
        r5.mIsCreated = r2;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0434;
    L_0x041f:
        r5 = r5.mLifecycleRegistry;	 Catch:{ all -> 0x0a1c }
        r6 = androidx.lifecycle.Lifecycle.Event.ON_CREATE;	 Catch:{ all -> 0x0a1c }
        r5.handleLifecycleEvent(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r6.mSavedFragmentState;	 Catch:{ all -> 0x0a1c }
        r8 = 0;
        r5.dispatchOnFragmentCreated(r6, r7, r8);	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x0434:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onCreate()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x044e:
        r6 = r5.mSavedFragmentState;	 Catch:{ all -> 0x0a1c }
        r5.restoreChildFragmentState(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.mState = r2;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x045b:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0477;
    L_0x0461:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "moveto ATTACHED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x0477:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mTarget;	 Catch:{ all -> 0x0a1c }
        r8 = " that does not belong to this FragmentManager!";
        r9 = " declared target fragment ";
        if (r7 == 0) goto L_0x04bc;
    L_0x0481:
        r5 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mWho;	 Catch:{ all -> 0x0a1c }
        r5 = r5.getFragmentStateManager(r7);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0498;
    L_0x048b:
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r8 = r7.mTarget;	 Catch:{ all -> 0x0a1c }
        r8 = r8.mWho;	 Catch:{ all -> 0x0a1c }
        r7.mTargetWho = r8;	 Catch:{ all -> 0x0a1c }
        r8 = 0;
        r7.mTarget = r8;	 Catch:{ all -> 0x0a1c }
        r14 = r5;
        goto L_0x04ee;
    L_0x0498:
        r2 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r4 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3.append(r9);	 Catch:{ all -> 0x0a1c }
        r4 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r4 = r4.mTarget;	 Catch:{ all -> 0x0a1c }
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3.append(r8);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x04bc:
        r5 = r5.mTargetWho;	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x04ed;
    L_0x04c0:
        r7 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r14 = r7.getFragmentStateManager(r5);	 Catch:{ all -> 0x0a1c }
        if (r14 == 0) goto L_0x04c9;
    L_0x04c8:
        goto L_0x04ee;
    L_0x04c9:
        r2 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r4 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3.append(r9);	 Catch:{ all -> 0x0a1c }
        r4 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r4 = r4.mTargetWho;	 Catch:{ all -> 0x0a1c }
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3.append(r8);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x04ed:
        r14 = 0;
    L_0x04ee:
        if (r14 == 0) goto L_0x04f3;
    L_0x04f0:
        r14.moveToExpectedState();	 Catch:{ all -> 0x0a1c }
    L_0x04f3:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mFragmentManager;	 Catch:{ all -> 0x0a1c }
        r8 = r7.mHost;	 Catch:{ all -> 0x0a1c }
        r5.mHost = r8;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mParent;	 Catch:{ all -> 0x0a1c }
        r5.mParentFragment = r7;	 Catch:{ all -> 0x0a1c }
        r7 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r8 = 0;
        r7.dispatchOnFragmentPreAttached(r5, r8);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mOnPreAttachedListeners;	 Catch:{ all -> 0x0a1c }
        r8 = r7.size();	 Catch:{ all -> 0x0a1c }
        r9 = 0;
    L_0x050e:
        if (r9 >= r8) goto L_0x051c;
    L_0x0510:
        r10 = r7.get(r9);	 Catch:{ all -> 0x0a1c }
        r10 = (android.support.p000v4.app.Fragment.OnPreAttachedListener) r10;	 Catch:{ all -> 0x0a1c }
        r10.onPreAttached();	 Catch:{ all -> 0x0a1c }
        r9 = r9 + 1;
        goto L_0x050e;
    L_0x051c:
        r7 = r5.mOnPreAttachedListeners;	 Catch:{ all -> 0x0a1c }
        r7.clear();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r8 = r5.mHost;	 Catch:{ all -> 0x0a1c }
        r9 = r5.createFragmentContainer();	 Catch:{ all -> 0x0a1c }
        r7.attachController(r8, r9, r5);	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mState = r7;	 Catch:{ all -> 0x0a1c }
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mHost;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mContext;	 Catch:{ all -> 0x0a1c }
        r5.onAttach(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x056d;
    L_0x053c:
        r6 = r5.mFragmentManager;	 Catch:{ all -> 0x0a1c }
        r6 = r6.mOnAttachListeners;	 Catch:{ all -> 0x0a1c }
        r6 = r6.iterator();	 Catch:{ all -> 0x0a1c }
    L_0x0544:
        r7 = r6.hasNext();	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0554;
    L_0x054a:
        r7 = r6.next();	 Catch:{ all -> 0x0a1c }
        r7 = (android.support.p000v4.app.FragmentOnAttachListener) r7;	 Catch:{ all -> 0x0a1c }
        r7.onAttachFragment$ar$ds();	 Catch:{ all -> 0x0a1c }
        goto L_0x0544;
    L_0x0554:
        r5 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r6 = 0;
        r5.mStateSaved = r6;	 Catch:{ all -> 0x0a1c }
        r5.mStopped = r6;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mNonConfig;	 Catch:{ all -> 0x0a1c }
        r7.mIsStateSaved = r6;	 Catch:{ all -> 0x0a1c }
        r5.dispatchStateChange(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.dispatchOnFragmentAttached(r7, r6);	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x056d:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onAttach()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x0587:
        r8 = r8 + -1;
        switch(r8) {
            case -1: goto L_0x089b;
            case 0: goto L_0x0785;
            case 1: goto L_0x06d7;
            case 2: goto L_0x06cd;
            case 3: goto L_0x0667;
            case 4: goto L_0x05ff;
            case 5: goto L_0x05f7;
            case 6: goto L_0x0590;
            default: goto L_0x058c;
        };	 Catch:{ all -> 0x0a1c }
    L_0x058c:
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x0590:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x05ac;
    L_0x0596:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "movefrom RESUMED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x05ac:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7.dispatchPause();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x05be;
    L_0x05b7:
        r7 = r5.mViewLifecycleOwner;	 Catch:{ all -> 0x0a1c }
        r8 = androidx.lifecycle.Lifecycle.Event.ON_PAUSE;	 Catch:{ all -> 0x0a1c }
        r7.handleLifecycleEvent(r8);	 Catch:{ all -> 0x0a1c }
    L_0x05be:
        r7 = r5.mLifecycleRegistry;	 Catch:{ all -> 0x0a1c }
        r8 = androidx.lifecycle.Lifecycle.Event.ON_PAUSE;	 Catch:{ all -> 0x0a1c }
        r7.handleLifecycleEvent(r8);	 Catch:{ all -> 0x0a1c }
        r5.mState = r9;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r5.onPause();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x05dd;
    L_0x05d1:
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.dispatchOnFragmentPaused(r6, r7);	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x05dd:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onPause()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
        r6 = 5;
        r5.mState = r6;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x05ff:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x061b;
    L_0x0605:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "movefrom STARTED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x061b:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7.dispatchStop();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x062d;
    L_0x0626:
        r7 = r5.mViewLifecycleOwner;	 Catch:{ all -> 0x0a1c }
        r8 = androidx.lifecycle.Lifecycle.Event.ON_STOP;	 Catch:{ all -> 0x0a1c }
        r7.handleLifecycleEvent(r8);	 Catch:{ all -> 0x0a1c }
    L_0x062d:
        r7 = r5.mLifecycleRegistry;	 Catch:{ all -> 0x0a1c }
        r8 = androidx.lifecycle.Lifecycle.Event.ON_STOP;	 Catch:{ all -> 0x0a1c }
        r7.handleLifecycleEvent(r8);	 Catch:{ all -> 0x0a1c }
        r7 = 4;
        r5.mState = r7;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r5.onStop();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x064d;
    L_0x0641:
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.dispatchOnFragmentStopped(r6, r7);	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x064d:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onStop()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0684;
    L_0x066e:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r6 = "movefrom ACTIVITY_CREATED: ";
        r5.append(r6);	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x0684:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = r5.mBeingSaved;	 Catch:{ all -> 0x0a1c }
        r6 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x0693;
    L_0x068c:
        r5 = r5.mSavedViewState;	 Catch:{ all -> 0x0a1c }
        if (r5 != 0) goto L_0x0693;
    L_0x0690:
        r17.saveViewState();	 Catch:{ all -> 0x0a1c }
    L_0x0693:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x06c5;
    L_0x0699:
        r6 = r5.mContainer;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x06c5;
    L_0x069d:
        r5 = r5.getParentFragmentManager();	 Catch:{ all -> 0x0a1c }
        r5 = android.support.p000v4.app.SpecialEffectsController.getOrCreateController(r6, r5);	 Catch:{ all -> 0x0a1c }
        r6 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r3);	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x06c1;
    L_0x06ab:
        r6 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r6.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "SpecialEffectsController: Enqueuing remove operation for fragment ";
        r6.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6.append(r7);	 Catch:{ all -> 0x0a1c }
        r6 = r6.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.v(r4, r6);	 Catch:{ all -> 0x0a1c }
        r5.enqueue$ar$edu(r2, r13, r1);	 Catch:{ all -> 0x0a1c }
    L_0x06c5:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.mState = r13;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
        r6 = 0;
        r5.mInLayout = r6;	 Catch:{ all -> 0x0a1c }
        r5.mState = r3;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x06d7:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x06f3;
    L_0x06dd:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "movefrom CREATE_VIEW: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x06f3:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mContainer;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0700;
    L_0x06f9:
        r5 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0700;
    L_0x06fd:
        r7.removeView(r5);	 Catch:{ all -> 0x0a1c }
    L_0x0700:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7.dispatchStateChange(r2);	 Catch:{ all -> 0x0a1c }
        r7 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0724;
    L_0x070b:
        r7 = r5.mViewLifecycleOwner;	 Catch:{ all -> 0x0a1c }
        r7 = r7.getLifecycle();	 Catch:{ all -> 0x0a1c }
        r7 = (androidx.lifecycle.LifecycleRegistry) r7;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mState;	 Catch:{ all -> 0x0a1c }
        r8 = androidx.lifecycle.Lifecycle.State.CREATED;	 Catch:{ all -> 0x0a1c }
        r7 = r7.isAtLeast(r8);	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0724;
    L_0x071d:
        r7 = r5.mViewLifecycleOwner;	 Catch:{ all -> 0x0a1c }
        r8 = androidx.lifecycle.Lifecycle.Event.ON_DESTROY;	 Catch:{ all -> 0x0a1c }
        r7.handleLifecycleEvent(r8);	 Catch:{ all -> 0x0a1c }
    L_0x0724:
        r5.mState = r2;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r5.onDestroyView();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x076b;
    L_0x0730:
        r6 = androidx.loader.app.LoaderManager.getInstance(r5);	 Catch:{ all -> 0x0a1c }
        r6 = (androidx.loader.app.LoaderManagerImpl) r6;	 Catch:{ all -> 0x0a1c }
        r6 = r6.mLoaderViewModel;	 Catch:{ all -> 0x0a1c }
        r6 = r6.mLoaders;	 Catch:{ all -> 0x0a1c }
        r7 = r6.mSize;	 Catch:{ all -> 0x0a1c }
        if (r7 > 0) goto L_0x0761;
    L_0x073e:
        r6 = 0;
        r5.mPerformedCreateView = r6;	 Catch:{ all -> 0x0a1c }
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.dispatchOnFragmentViewDestroyed(r7, r6);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = 0;
        r5.mContainer = r6;	 Catch:{ all -> 0x0a1c }
        r5.mView = r6;	 Catch:{ all -> 0x0a1c }
        r5.mViewLifecycleOwner = r6;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mViewLifecycleOwnerLiveData;	 Catch:{ all -> 0x0a1c }
        r5.setValue(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = 0;
        r5.mInLayout = r6;	 Catch:{ all -> 0x0a1c }
        r5.mState = r2;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
        r2 = 0;
        r3 = r6.valueAt(r2);	 Catch:{ all -> 0x0a1c }
        r3 = (androidx.loader.app.LoaderManagerImpl.LoaderInfo) r3;	 Catch:{ all -> 0x0a1c }
        r2 = 0;
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x076b:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onDestroyView()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x0785:
        r5 = r5.mBeingSaved;	 Catch:{ all -> 0x0a1c }
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x07a3;
    L_0x078d:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "movefrom CREATED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x07a3:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mRemoving;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x07b1;
    L_0x07a9:
        r5 = r5.isInBackStack();	 Catch:{ all -> 0x0a1c }
        if (r5 != 0) goto L_0x07b1;
    L_0x07af:
        r5 = 1;
        goto L_0x07b2;
    L_0x07b1:
        r5 = 0;
    L_0x07b2:
        if (r5 == 0) goto L_0x07c0;
    L_0x07b4:
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r8 = r7.mBeingSaved;	 Catch:{ all -> 0x0a1c }
        r8 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mWho;	 Catch:{ all -> 0x0a1c }
        r9 = 0;
        r8.setSavedState(r7, r9);	 Catch:{ all -> 0x0a1c }
    L_0x07c0:
        if (r5 != 0) goto L_0x07ee;
    L_0x07c2:
        r7 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mNonConfig;	 Catch:{ all -> 0x0a1c }
        r8 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r7.shouldDestroy(r8);	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x07cf;
    L_0x07ce:
        goto L_0x07ee;
    L_0x07cf:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mTargetWho;	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x07e5;
    L_0x07d5:
        r6 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r5 = r6.findActiveFragment(r5);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x07e5;
    L_0x07dd:
        r6 = r5.mRetainInstance;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x07e5;
    L_0x07e1:
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6.mTarget = r5;	 Catch:{ all -> 0x0a1c }
    L_0x07e5:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = 0;
        r5.mState = r6;	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x07ee:
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mHost;	 Catch:{ all -> 0x0a1c }
        r8 = r7 instanceof android.arch.lifecycle.ViewModelStoreOwner;	 Catch:{ all -> 0x0a1c }
        if (r8 == 0) goto L_0x07fd;
    L_0x07f6:
        r7 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mNonConfig;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mHasBeenCleared;	 Catch:{ all -> 0x0a1c }
        goto L_0x0806;
    L_0x07fd:
        r7 = r7.mContext;	 Catch:{ all -> 0x0a1c }
        r7 = (android.app.Activity) r7;	 Catch:{ all -> 0x0a1c }
        r7 = r7.isChangingConfigurations();	 Catch:{ all -> 0x0a1c }
        r7 = r7 ^ r2;
    L_0x0806:
        if (r5 == 0) goto L_0x080d;
    L_0x0808:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mBeingSaved;	 Catch:{ all -> 0x0a1c }
        goto L_0x080f;
    L_0x080d:
        if (r7 == 0) goto L_0x0818;
    L_0x080f:
        r5 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mNonConfig;	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.clearNonConfigState(r7);	 Catch:{ all -> 0x0a1c }
    L_0x0818:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7.dispatchDestroy();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mLifecycleRegistry;	 Catch:{ all -> 0x0a1c }
        r8 = androidx.lifecycle.Lifecycle.Event.ON_DESTROY;	 Catch:{ all -> 0x0a1c }
        r7.handleLifecycleEvent(r8);	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mState = r7;	 Catch:{ all -> 0x0a1c }
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r5.mIsCreated = r7;	 Catch:{ all -> 0x0a1c }
        r5.onDestroy();	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0881;
    L_0x0834:
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.dispatchOnFragmentDestroyed(r6, r7);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r5 = r5.getActiveFragmentStateManagers();	 Catch:{ all -> 0x0a1c }
        r5 = r5.iterator();	 Catch:{ all -> 0x0a1c }
    L_0x0846:
        r6 = r5.hasNext();	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x086a;
    L_0x084c:
        r6 = r5.next();	 Catch:{ all -> 0x0a1c }
        r6 = (android.support.p000v4.app.FragmentStateManager) r6;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x0846;
    L_0x0854:
        r6 = r6.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = r7.mWho;	 Catch:{ all -> 0x0a1c }
        r8 = r6.mTargetWho;	 Catch:{ all -> 0x0a1c }
        r7 = r7.equals(r8);	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x0846;
    L_0x0862:
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6.mTarget = r7;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r6.mTargetWho = r7;	 Catch:{ all -> 0x0a1c }
        goto L_0x0846;
    L_0x086a:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = r5.mTargetWho;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x0878;
    L_0x0870:
        r7 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r6 = r7.findActiveFragment(r6);	 Catch:{ all -> 0x0a1c }
        r5.mTarget = r6;	 Catch:{ all -> 0x0a1c }
    L_0x0878:
        r5 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r5.makeInactive(r1);	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x0881:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onDestroy()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x089b:
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x08b7;
    L_0x08a1:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "movefrom ATTACHED: ";
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r7);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x08b7:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = -1;
        r5.mState = r7;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mCalled = r7;	 Catch:{ all -> 0x0a1c }
        r5.onDetach();	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.mLayoutInflater = r7;	 Catch:{ all -> 0x0a1c }
        r7 = r5.mCalled;	 Catch:{ all -> 0x0a1c }
        if (r7 == 0) goto L_0x092c;
    L_0x08c9:
        r6 = r5.mChildFragmentManager;	 Catch:{ all -> 0x0a1c }
        r7 = r6.mDestroyed;	 Catch:{ all -> 0x0a1c }
        if (r7 != 0) goto L_0x08d9;
    L_0x08cf:
        r6.dispatchDestroy();	 Catch:{ all -> 0x0a1c }
        r6 = new android.support.v4.app.FragmentManagerImpl;	 Catch:{ all -> 0x0a1c }
        r6.<init>();	 Catch:{ all -> 0x0a1c }
        r5.mChildFragmentManager = r6;	 Catch:{ all -> 0x0a1c }
    L_0x08d9:
        r5 = r1.mDispatcher;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r7 = 0;
        r5.dispatchOnFragmentDetached(r6, r7);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = -1;
        r5.mState = r6;	 Catch:{ all -> 0x0a1c }
        r6 = 0;
        r5.mHost = r6;	 Catch:{ all -> 0x0a1c }
        r5.mParentFragment = r6;	 Catch:{ all -> 0x0a1c }
        r5.mFragmentManager = r6;	 Catch:{ all -> 0x0a1c }
        r6 = r5.mRemoving;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x08f8;
    L_0x08f1:
        r5 = r5.isInBackStack();	 Catch:{ all -> 0x0a1c }
        if (r5 != 0) goto L_0x08f8;
    L_0x08f7:
        goto L_0x0908;
    L_0x08f8:
        r5 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mNonConfig;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5 = r5.shouldDestroy(r6);	 Catch:{ all -> 0x0a1c }
        if (r5 != 0) goto L_0x0908;
    L_0x0904:
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0923;
    L_0x090f:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r5.append(r10);	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x0923:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.initState();	 Catch:{ all -> 0x0a1c }
        r5 = 0;
        r6 = 1;
        goto L_0x002b;
    L_0x092c:
        r2 = new android.support.v4.app.SuperNotCalledException;	 Catch:{ all -> 0x0a1c }
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3.append(r5);	 Catch:{ all -> 0x0a1c }
        r4 = " did not call through to super.onDetach()";
        r3.append(r4);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        r2.<init>(r3);	 Catch:{ all -> 0x0a1c }
        throw r2;	 Catch:{ all -> 0x0a1c }
    L_0x0946:
        if (r6 != 0) goto L_0x09a2;
    L_0x0948:
        r6 = -1;
        if (r8 != r6) goto L_0x09a2;
    L_0x094b:
        r6 = r5.mRemoving;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x09a2;
    L_0x094f:
        r5 = r5.isInBackStack();	 Catch:{ all -> 0x0a1c }
        if (r5 != 0) goto L_0x09a2;
    L_0x0955:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mBeingSaved;	 Catch:{ all -> 0x0a1c }
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0975;
    L_0x095f:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r6 = "Cleaning up state of never attached fragment: ";
        r5.append(r6);	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x0975:
        r5 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r5 = r5.mNonConfig;	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.clearNonConfigState(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r1.mFragmentStore;	 Catch:{ all -> 0x0a1c }
        r5.makeInactive(r1);	 Catch:{ all -> 0x0a1c }
        r5 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r13);	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x099d;
    L_0x0989:
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r5.<init>();	 Catch:{ all -> 0x0a1c }
        r5.append(r10);	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.append(r6);	 Catch:{ all -> 0x0a1c }
        r5 = r5.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.d(r4, r5);	 Catch:{ all -> 0x0a1c }
    L_0x099d:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r5.initState();	 Catch:{ all -> 0x0a1c }
    L_0x09a2:
        r5 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = r5.mHiddenChanged;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x0a18;
    L_0x09a8:
        r6 = r5.mView;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x09ff;
    L_0x09ac:
        r6 = r5.mContainer;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x09ff;
    L_0x09b0:
        r5 = r5.getParentFragmentManager();	 Catch:{ all -> 0x0a1c }
        r5 = android.support.p000v4.app.SpecialEffectsController.getOrCreateController(r6, r5);	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6 = r6.mHidden;	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x09df;
    L_0x09be:
        r3 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r3);	 Catch:{ all -> 0x0a1c }
        if (r3 == 0) goto L_0x09da;
    L_0x09c4:
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r3.<init>();	 Catch:{ all -> 0x0a1c }
        r6 = "SpecialEffectsController: Enqueuing hide operation for fragment ";
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r6 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r3.append(r6);	 Catch:{ all -> 0x0a1c }
        r3 = r3.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.v(r4, r3);	 Catch:{ all -> 0x0a1c }
        r5.enqueue$ar$edu(r13, r2, r1);	 Catch:{ all -> 0x0a1c }
        goto L_0x09ff;
    L_0x09df:
        r6 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r3);	 Catch:{ all -> 0x0a1c }
        if (r6 == 0) goto L_0x09fb;
    L_0x09e5:
        r6 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0a1c }
        r6.<init>();	 Catch:{ all -> 0x0a1c }
        r7 = "SpecialEffectsController: Enqueuing show operation for fragment ";
        r6.append(r7);	 Catch:{ all -> 0x0a1c }
        r7 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r6.append(r7);	 Catch:{ all -> 0x0a1c }
        r6 = r6.toString();	 Catch:{ all -> 0x0a1c }
        android.util.Log.v(r4, r6);	 Catch:{ all -> 0x0a1c }
        r5.enqueue$ar$edu(r3, r2, r1);	 Catch:{ all -> 0x0a1c }
    L_0x09ff:
        r3 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r4 = r3.mFragmentManager;	 Catch:{ all -> 0x0a1c }
        if (r4 == 0) goto L_0x0a11;
    L_0x0a05:
        r5 = r3.mAdded;	 Catch:{ all -> 0x0a1c }
        if (r5 == 0) goto L_0x0a11;
    L_0x0a09:
        r3 = android.support.p000v4.app.FragmentManager.isMenuAvailable$ar$ds(r3);	 Catch:{ all -> 0x0a1c }
        if (r3 == 0) goto L_0x0a11;
    L_0x0a0f:
        r4.mNeedMenuInvalidate = r2;	 Catch:{ all -> 0x0a1c }
    L_0x0a11:
        r2 = r1.mFragment;	 Catch:{ all -> 0x0a1c }
        r3 = 0;
        r2.mHiddenChanged = r3;	 Catch:{ all -> 0x0a1c }
        r2 = r2.mHidden;	 Catch:{ all -> 0x0a1c }
    L_0x0a18:
        r2 = 0;
        r1.mMovingToState = r2;
        return;
    L_0x0a1c:
        r0 = move-exception;
        r2 = r0;
        r3 = 0;
        r1.mMovingToState = r3;
        goto L_0x0a23;
    L_0x0a22:
        throw r2;
    L_0x0a23:
        goto L_0x0a22;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.FragmentStateManager.moveToExpectedState():void");
    }

    final void restoreState(ClassLoader classLoader) {
        Bundle bundle = this.mFragment.mSavedFragmentState;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
            Fragment fragment = this.mFragment;
            fragment.mSavedViewState = fragment.mSavedFragmentState.getSparseParcelableArray("android:view_state");
            fragment = this.mFragment;
            fragment.mSavedViewRegistryState = fragment.mSavedFragmentState.getBundle("android:view_registry_state");
            fragment = this.mFragment;
            fragment.mTargetWho = fragment.mSavedFragmentState.getString("android:target_state");
            fragment = this.mFragment;
            if (fragment.mTargetWho != null) {
                fragment.mTargetRequestCode = fragment.mSavedFragmentState.getInt("android:target_req_state", 0);
            }
            fragment = this.mFragment;
            Boolean bool = fragment.mSavedUserVisibleHint;
            fragment.mUserVisibleHint = fragment.mSavedFragmentState.getBoolean("android:user_visible_hint", true);
            fragment = this.mFragment;
            if (!fragment.mUserVisibleHint) {
                fragment.mDeferStart = true;
            }
        }
    }

    final void saveViewState() {
        if (this.mFragment.mView != null) {
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Saving view state for fragment ");
                stringBuilder.append(this.mFragment);
                stringBuilder.append(" with view ");
                stringBuilder.append(this.mFragment.mView);
                Log.v("FragmentManager", stringBuilder.toString());
            }
            SparseArray sparseArray = new SparseArray();
            this.mFragment.mView.saveHierarchyState(sparseArray);
            if (sparseArray.size() > 0) {
                this.mFragment.mSavedViewState = sparseArray;
            }
            Bundle bundle = new Bundle();
            this.mFragment.mViewLifecycleOwner.mSavedStateRegistryController.performSave(bundle);
            if (!bundle.isEmpty()) {
                this.mFragment.mSavedViewRegistryState = bundle;
            }
        }
    }

    public FragmentStateManager(FragmentLifecycleCallbacksDispatcher fragmentLifecycleCallbacksDispatcher, FragmentStore fragmentStore, Fragment fragment, FragmentState fragmentState) {
        String str;
        this.mDispatcher = fragmentLifecycleCallbacksDispatcher;
        this.mFragmentStore = fragmentStore;
        this.mFragment = fragment;
        fragment.mSavedViewState = null;
        fragment.mSavedViewRegistryState = null;
        fragment.mBackStackNesting = 0;
        fragment.mInLayout = false;
        fragment.mAdded = false;
        Fragment fragment2 = fragment.mTarget;
        if (fragment2 != null) {
            str = fragment2.mWho;
        } else {
            str = null;
        }
        fragment.mTargetWho = str;
        fragment.mTarget = null;
        Bundle bundle = fragmentState.mSavedFragmentState;
        if (bundle != null) {
            fragment.mSavedFragmentState = bundle;
        } else {
            fragment.mSavedFragmentState = new Bundle();
        }
    }

    final void addViewToContainer() {
        FragmentStore fragmentStore = this.mFragmentStore;
        Fragment fragment = this.mFragment;
        ViewGroup viewGroup = fragment.mContainer;
        int i = -1;
        if (viewGroup != null) {
            int indexOf = fragmentStore.mAdded.indexOf(fragment);
            for (int i2 = indexOf - 1; i2 >= 0; i2--) {
                Fragment fragment2 = (Fragment) fragmentStore.mAdded.get(i2);
                if (fragment2.mContainer == viewGroup) {
                    View view = fragment2.mView;
                    if (view != null) {
                        i = viewGroup.indexOfChild(view) + 1;
                        break;
                    }
                }
            }
            for (indexOf++; indexOf < fragmentStore.mAdded.size(); indexOf++) {
                Fragment fragment3 = (Fragment) fragmentStore.mAdded.get(indexOf);
                if (fragment3.mContainer == viewGroup) {
                    View view2 = fragment3.mView;
                    if (view2 != null) {
                        i = viewGroup.indexOfChild(view2);
                        break;
                    }
                }
            }
        }
        Fragment fragment4 = this.mFragment;
        fragment4.mContainer.addView(fragment4.mView, i);
    }

    public FragmentStateManager(FragmentLifecycleCallbacksDispatcher fragmentLifecycleCallbacksDispatcher, FragmentStore fragmentStore, ClassLoader classLoader, FragmentFactory fragmentFactory, FragmentState fragmentState) {
        this.mDispatcher = fragmentLifecycleCallbacksDispatcher;
        this.mFragmentStore = fragmentStore;
        Fragment instantiate$ar$ds$540c62b6_0 = fragmentFactory.instantiate$ar$ds$540c62b6_0(fragmentState.mClassName);
        Bundle bundle = fragmentState.mArguments;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        instantiate$ar$ds$540c62b6_0.setArguments(fragmentState.mArguments);
        instantiate$ar$ds$540c62b6_0.mWho = fragmentState.mWho;
        instantiate$ar$ds$540c62b6_0.mFromLayout = fragmentState.mFromLayout;
        instantiate$ar$ds$540c62b6_0.mRestored = true;
        instantiate$ar$ds$540c62b6_0.mFragmentId = fragmentState.mFragmentId;
        instantiate$ar$ds$540c62b6_0.mContainerId = fragmentState.mContainerId;
        instantiate$ar$ds$540c62b6_0.mTag = fragmentState.mTag;
        instantiate$ar$ds$540c62b6_0.mRetainInstance = fragmentState.mRetainInstance;
        instantiate$ar$ds$540c62b6_0.mRemoving = fragmentState.mRemoving;
        instantiate$ar$ds$540c62b6_0.mDetached = fragmentState.mDetached;
        instantiate$ar$ds$540c62b6_0.mHidden = fragmentState.mHidden;
        instantiate$ar$ds$540c62b6_0.mMaxState = State.values()[fragmentState.mMaxLifecycleState];
        bundle = fragmentState.mSavedFragmentState;
        if (bundle != null) {
            instantiate$ar$ds$540c62b6_0.mSavedFragmentState = bundle;
        } else {
            instantiate$ar$ds$540c62b6_0.mSavedFragmentState = new Bundle();
        }
        this.mFragment = instantiate$ar$ds$540c62b6_0;
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Instantiated fragment ");
            stringBuilder.append(instantiate$ar$ds$540c62b6_0);
            Log.v("FragmentManager", stringBuilder.toString());
        }
    }
}
