package android.support.p000v4.app;

import android.app.Activity;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelStoreOwner;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p000v4.app.Fragment;
import android.support.p000v4.app.Fragment.AnimationInfo;
import android.support.p000v4.app.FragmentActivity.HostCallbacks;
import android.support.p000v4.app.FragmentFactory;
import android.support.p000v4.app.FragmentManager.LaunchedFragmentInfo;
import android.support.p000v4.app.FragmentOnAttachListener;
import android.support.p000v4.app.FragmentTransaction.PG;
import android.support.p000v4.app.SpecialEffectsController.Operation;
import android.support.p000v4.app.SpecialEffectsController.Operation.State;
import android.support.p000v4.view.ViewCompat;
import android.support.v4.app.FragmentManager.C00632;
import android.support.v4.app.FragmentManager.C00643;
import android.support.v4.app.FragmentManager.C00654;
import android.support.v4.app.FragmentManager.C00666;
import android.support.v4.app.FragmentManager.C00677;
import android.support.v4.app.FragmentManager.C00688;
import android.support.v4.app.FragmentManager.C00699;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.Cancellable;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcher.LifecycleOnBackPressedCancellable;
import androidx.activity.OnBackPressedDispatcherOwner;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.ActivityResultRegistryOwner;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts$RequestMultiplePermissions;
import androidx.activity.result.contract.ActivityResultContracts$StartActivityForResult;
import androidx.fragment.app.strictmode.FragmentStrictMode;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.SavedStateRegistryOwner;
import com.google.android.clockwork.common.wearable.view.FullscreenFragmentHelper;
import com.google.android.wearable.sysui.R;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import p020j$.util.DesugarCollections;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentManager */
public class FragmentManager {
    ArrayList mBackStack;
    public ArrayList mBackStackChangeListeners;
    public final AtomicInteger mBackStackIndex = new AtomicInteger();
    private final Map mBackStackStates = DesugarCollections.synchronizedMap(new HashMap());
    public FragmentContainer mContainer;
    private ArrayList mCreatedMenus;
    int mCurState;
    private final C00643 mDefaultSpecialEffectsControllerFactory$ar$class_merging;
    public boolean mDestroyed;
    private final Runnable mExecCommit;
    private boolean mExecutingActions;
    public final FragmentStore mFragmentStore = new FragmentStore();
    private boolean mHavePendingDeferredStart;
    public FragmentHostCallback mHost;
    private final FragmentFactory mHostFragmentFactory;
    ArrayDeque mLaunchedFragments;
    public final FragmentLayoutInflaterFactory mLayoutInflaterFactory = new FragmentLayoutInflaterFactory(this);
    public final FragmentLifecycleCallbacksDispatcher mLifecycleCallbacksDispatcher;
    public boolean mNeedMenuInvalidate;
    public FragmentManagerViewModel mNonConfig;
    public final CopyOnWriteArrayList mOnAttachListeners;
    public final OnBackPressedCallback mOnBackPressedCallback = new PG();
    public OnBackPressedDispatcher mOnBackPressedDispatcher;
    public Fragment mParent;
    private final ArrayList mPendingActions = new ArrayList();
    Fragment mPrimaryNav;
    private ActivityResultLauncher mRequestPermissions;
    private final Map mResults = DesugarCollections.synchronizedMap(new HashMap());
    private ActivityResultLauncher mStartActivityForResult;
    private ActivityResultLauncher mStartIntentSenderForResult;
    public boolean mStateSaved;
    public boolean mStopped;
    private ArrayList mTmpAddedFragments;
    private ArrayList mTmpIsPop;
    private ArrayList mTmpRecords;

    /* renamed from: android.support.v4.app.FragmentManager$1 */
    final class PG extends OnBackPressedCallback {
        public final void handleOnBackPressed() {
            FragmentManager fragmentManager = FragmentManager.this;
            fragmentManager.execPendingActions$ar$ds$3011d4e5_0(true);
            if (fragmentManager.mOnBackPressedCallback.mEnabled) {
                fragmentManager.popBackStackImmediate();
            } else {
                fragmentManager.mOnBackPressedDispatcher.onBackPressed();
            }
        }
    }

    /* renamed from: android.support.v4.app.FragmentManager$2 */
    final class C00632 extends FragmentFactory {
        public final Fragment instantiate$ar$ds$540c62b6_0(String str) {
            return Fragment.instantiate$ar$ds(android.support.p000v4.app.FragmentManager.this.mHost.mContext, str);
        }
    }

    /* renamed from: android.support.v4.app.FragmentManager$3 */
    final class C00643 {
    }

    /* renamed from: android.support.v4.app.FragmentManager$4 */
    final class C00654 implements Runnable {
        public final void run() {
            android.support.p000v4.app.FragmentManager.this.execPendingActions$ar$ds$3011d4e5_0(true);
        }
    }

    /* renamed from: android.support.v4.app.FragmentManager$6 */
    final class C00666 implements FragmentOnAttachListener {
        public final void onAttachFragment$ar$ds() {
        }
    }

    /* renamed from: android.support.v4.app.FragmentManager$7 */
    final class C00677 implements ActivityResultCallback {
        public final /* bridge */ /* synthetic */ void onActivityResult(Object obj) {
            ActivityResult activityResult = (ActivityResult) obj;
            LaunchedFragmentInfo launchedFragmentInfo = (LaunchedFragmentInfo) android.support.p000v4.app.FragmentManager.this.mLaunchedFragments.pollFirst();
            String str = "FragmentManager";
            if (launchedFragmentInfo == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("No Activities were started for result for ");
                stringBuilder.append(this);
                Log.w(str, stringBuilder.toString());
                return;
            }
            String str2 = launchedFragmentInfo.mWho;
            int i = launchedFragmentInfo.mRequestCode;
            Fragment findFragmentByWho = android.support.p000v4.app.FragmentManager.this.mFragmentStore.findFragmentByWho(str2);
            if (findFragmentByWho == null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("Activity result delivered for unknown Fragment ");
                stringBuilder.append(str2);
                Log.w(str, stringBuilder.toString());
                return;
            }
            findFragmentByWho.onActivityResult(i, activityResult.mResultCode, activityResult.mData);
        }
    }

    /* renamed from: android.support.v4.app.FragmentManager$8 */
    final class C00688 implements ActivityResultCallback {
        public final /* bridge */ /* synthetic */ void onActivityResult(Object obj) {
            ActivityResult activityResult = (ActivityResult) obj;
            LaunchedFragmentInfo launchedFragmentInfo = (LaunchedFragmentInfo) android.support.p000v4.app.FragmentManager.this.mLaunchedFragments.pollFirst();
            String str = "FragmentManager";
            if (launchedFragmentInfo == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("No IntentSenders were started for ");
                stringBuilder.append(this);
                Log.w(str, stringBuilder.toString());
                return;
            }
            String str2 = launchedFragmentInfo.mWho;
            int i = launchedFragmentInfo.mRequestCode;
            Fragment findFragmentByWho = android.support.p000v4.app.FragmentManager.this.mFragmentStore.findFragmentByWho(str2);
            if (findFragmentByWho == null) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("Intent Sender result delivered for unknown Fragment ");
                stringBuilder.append(str2);
                Log.w(str, stringBuilder.toString());
                return;
            }
            findFragmentByWho.onActivityResult(i, activityResult.mResultCode, activityResult.mData);
        }
    }

    /* renamed from: android.support.v4.app.FragmentManager$9 */
    final class C00699 implements ActivityResultCallback {
        public final /* bridge */ /* synthetic */ void onActivityResult(Object obj) {
            Map map = (Map) obj;
            String[] strArr = (String[]) map.keySet().toArray(new String[0]);
            ArrayList arrayList = new ArrayList(map.values());
            int[] iArr = new int[arrayList.size()];
            for (int i = 0; i < arrayList.size(); i++) {
                int i2;
                if (true != ((Boolean) arrayList.get(i)).booleanValue()) {
                    i2 = -1;
                } else {
                    i2 = 0;
                }
                iArr[i] = i2;
            }
            LaunchedFragmentInfo launchedFragmentInfo = (LaunchedFragmentInfo) android.support.p000v4.app.FragmentManager.this.mLaunchedFragments.pollFirst();
            String str = "FragmentManager";
            if (launchedFragmentInfo == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("No permissions were requested for ");
                stringBuilder.append(this);
                Log.w(str, stringBuilder.toString());
                return;
            }
            String str2 = launchedFragmentInfo.mWho;
            if (android.support.p000v4.app.FragmentManager.this.mFragmentStore.findFragmentByWho(str2) == null) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Permission request result delivered for unknown Fragment ");
                stringBuilder2.append(str2);
                Log.w(str, stringBuilder2.toString());
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.FragmentManager$FragmentIntentSenderContract */
    final class FragmentIntentSenderContract extends ActivityResultContract {
        public final /* bridge */ /* synthetic */ Object parseResult(int i, Intent intent) {
            return new ActivityResult(i, intent);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.FragmentManager$FragmentLifecycleCallbacks */
    public final class FragmentLifecycleCallbacks {
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.FragmentManager$LaunchedFragmentInfo */
    final class LaunchedFragmentInfo implements Parcelable {
        public static final Creator CREATOR = new PG();
        final int mRequestCode;
        final String mWho;

        /* renamed from: android.support.v4.app.FragmentManager$LaunchedFragmentInfo$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new LaunchedFragmentInfo[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new LaunchedFragmentInfo(parcel);
            }
        }

        public LaunchedFragmentInfo(Parcel parcel) {
            this.mWho = parcel.readString();
            this.mRequestCode = parcel.readInt();
        }

        public final int describeContents() {
            return 0;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.mWho);
            parcel.writeInt(this.mRequestCode);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.FragmentManager$OpGenerator */
    interface OpGenerator {
        boolean generateOps(ArrayList arrayList, ArrayList arrayList2);
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.FragmentManager$PopBackStackState */
    final class PopBackStackState implements OpGenerator {
        final int mId;

        public PopBackStackState(int i) {
            this.mId = i;
        }

        public final boolean generateOps(ArrayList arrayList, ArrayList arrayList2) {
            return FragmentManager.this.popBackStackState$ar$ds(arrayList, arrayList2, this.mId, 1);
        }
    }

    public FragmentManager() {
        DesugarCollections.synchronizedMap(new HashMap());
        this.mLifecycleCallbacksDispatcher = new FragmentLifecycleCallbacksDispatcher(this);
        this.mOnAttachListeners = new CopyOnWriteArrayList();
        this.mCurState = -1;
        this.mHostFragmentFactory = new C00632();
        this.mDefaultSpecialEffectsControllerFactory$ar$class_merging = new C00643();
        this.mLaunchedFragments = new ArrayDeque();
        this.mExecCommit = new C00654();
    }

    private final void checkStateLoss() {
        if (isStateSaved()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    private final void cleanupExec() {
        this.mExecutingActions = false;
        this.mTmpIsPop.clear();
        this.mTmpRecords.clear();
    }

    private final Set collectAllSpecialEffectsController() {
        Set hashSet = new HashSet();
        for (FragmentStateManager fragmentStateManager : this.mFragmentStore.getActiveFragmentStateManagers()) {
            ViewGroup viewGroup = fragmentStateManager.mFragment.mContainer;
            if (viewGroup != null) {
                getSpecialEffectsControllerFactory$ar$class_merging();
                hashSet.add(SpecialEffectsController.getOrCreateController$ar$class_merging$ar$ds(viewGroup));
            }
        }
        return hashSet;
    }

    private final void doPendingDeferredStart() {
        if (this.mHavePendingDeferredStart) {
            this.mHavePendingDeferredStart = false;
            startPendingDeferredFragments();
        }
    }

    private final void endAnimatingAwayFragments() {
        for (SpecialEffectsController forceCompleteAllOperations : collectAllSpecialEffectsController()) {
            forceCompleteAllOperations.forceCompleteAllOperations();
        }
    }

    private final void ensureExecReady(boolean z) {
        if (this.mExecutingActions) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        } else if (this.mHost == null) {
            if (this.mDestroyed) {
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            throw new IllegalStateException("FragmentManager has not been attached to a host.");
        } else if (Looper.myLooper() == this.mHost.mHandler.getLooper()) {
            if (!z) {
                checkStateLoss();
            }
            if (this.mTmpRecords == null) {
                this.mTmpRecords = new ArrayList();
                this.mTmpIsPop = new ArrayList();
            }
        } else {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
    }

    private final void executeOpsTogether(ArrayList arrayList, ArrayList arrayList2, int i, int i2) {
        ArrayList arrayList3 = arrayList;
        ArrayList arrayList4 = arrayList2;
        int i3 = i2;
        int i4 = i;
        boolean z = ((BackStackRecord) arrayList3.get(i4)).mReorderingAllowed;
        ArrayList arrayList5 = this.mTmpAddedFragments;
        if (arrayList5 == null) {
            r1.mTmpAddedFragments = new ArrayList();
        } else {
            arrayList5.clear();
        }
        r1.mTmpAddedFragments.addAll(r1.mFragmentStore.getFragments());
        Fragment fragment = r1.mPrimaryNav;
        int i5 = i4;
        Object obj = null;
        while (true) {
            byte[] bArr = null;
            int i6;
            int i7;
            if (i5 < i3) {
                BackStackRecord backStackRecord = (BackStackRecord) arrayList3.get(i5);
                if (((Boolean) arrayList4.get(i5)).booleanValue()) {
                    arrayList3 = r1.mTmpAddedFragments;
                    for (int size = backStackRecord.mOps.size() - 1; size >= 0; size--) {
                        PG pg = (PG) backStackRecord.mOps.get(size);
                        switch (pg.mCmd) {
                            case 1:
                            case 7:
                                arrayList3.remove(pg.mFragment);
                                break;
                            case 3:
                            case 6:
                                arrayList3.add(pg.mFragment);
                                break;
                            case 8:
                                fragment = null;
                                break;
                            case 9:
                                fragment = pg.mFragment;
                                break;
                            case 10:
                                pg.mCurrentMaxState = pg.mOldMaxState;
                                break;
                            default:
                                break;
                        }
                    }
                } else {
                    ArrayList arrayList6 = r1.mTmpAddedFragments;
                    i6 = 0;
                    while (i6 < backStackRecord.mOps.size()) {
                        PG pg2 = (PG) backStackRecord.mOps.get(i6);
                        Fragment fragment2;
                        switch (pg2.mCmd) {
                            case 1:
                            case 7:
                                arrayList6.add(pg2.mFragment);
                                break;
                            case 2:
                                fragment2 = pg2.mFragment;
                                i7 = fragment2.mContainerId;
                                int size2 = arrayList6.size() - 1;
                                Object obj2 = null;
                                while (size2 >= 0) {
                                    int i8;
                                    Fragment fragment3 = (Fragment) arrayList6.get(size2);
                                    if (fragment3.mContainerId != i7) {
                                        i8 = i7;
                                    } else if (fragment3 == fragment2) {
                                        i8 = i7;
                                        obj2 = 1;
                                    } else {
                                        byte[] bArr2;
                                        if (fragment3 == fragment) {
                                            i8 = i7;
                                            bArr2 = null;
                                            backStackRecord.mOps.add(i6, new PG(9, fragment3, null));
                                            i6++;
                                            fragment = null;
                                        } else {
                                            i8 = i7;
                                            bArr2 = null;
                                        }
                                        PG pg3 = new PG(3, fragment3, bArr2);
                                        pg3.mEnterAnim = pg2.mEnterAnim;
                                        pg3.mPopEnterAnim = pg2.mPopEnterAnim;
                                        pg3.mExitAnim = pg2.mExitAnim;
                                        pg3.mPopExitAnim = pg2.mPopExitAnim;
                                        backStackRecord.mOps.add(i6, pg3);
                                        arrayList6.remove(fragment3);
                                        i6++;
                                    }
                                    size2--;
                                    arrayList3 = arrayList;
                                    arrayList4 = arrayList2;
                                    i7 = i8;
                                }
                                if (obj2 == null) {
                                    pg2.mCmd = 1;
                                    pg2.mFromExpandedOp = true;
                                    arrayList6.add(fragment2);
                                    break;
                                }
                                backStackRecord.mOps.remove(i6);
                                i6--;
                                break;
                            case 3:
                            case 6:
                                arrayList6.remove(pg2.mFragment);
                                fragment2 = pg2.mFragment;
                                if (fragment2 != fragment) {
                                    break;
                                }
                                backStackRecord.mOps.add(i6, new PG(9, fragment2));
                                i6++;
                                fragment = bArr;
                                break;
                            case 8:
                                backStackRecord.mOps.add(i6, new PG(9, fragment, bArr));
                                pg2.mFromExpandedOp = true;
                                i6++;
                                fragment = pg2.mFragment;
                                break;
                            default:
                                break;
                        }
                        i6++;
                        arrayList3 = arrayList;
                        arrayList4 = arrayList2;
                        i4 = i;
                        bArr = null;
                    }
                }
                if (obj == null) {
                    if (!backStackRecord.mAddToBackStack) {
                        obj = null;
                        i5++;
                        arrayList3 = arrayList;
                        arrayList4 = arrayList2;
                        i4 = i;
                    }
                }
                obj = 1;
                i5++;
                arrayList3 = arrayList;
                arrayList4 = arrayList2;
                i4 = i;
            } else {
                int i9;
                int i10;
                BackStackRecord backStackRecord2;
                Fragment fragment4;
                int i11;
                Fragment fragment5;
                List list;
                r1.mTmpAddedFragments.clear();
                if (!z && r1.mCurState > 0) {
                    for (i9 = i; i9 < i3; i9++) {
                        List list2 = ((BackStackRecord) arrayList.get(i9)).mOps;
                        int size3 = list2.size();
                        for (i10 = 0; i10 < size3; i10++) {
                            Fragment fragment6 = ((PG) list2.get(i10)).mFragment;
                            if (!(fragment6 == null || fragment6.mFragmentManager == null)) {
                                r1.mFragmentStore.makeActive(createOrGetFragmentStateManager(fragment6));
                            }
                        }
                    }
                }
                arrayList4 = arrayList;
                for (i9 = i; i9 < i3; i9++) {
                    backStackRecord2 = (BackStackRecord) arrayList4.get(i9);
                    StringBuilder stringBuilder;
                    if (((Boolean) arrayList2.get(i9)).booleanValue()) {
                        backStackRecord2.bumpBackStackNesting(-1);
                        for (i6 = backStackRecord2.mOps.size() - 1; i6 >= 0; i6--) {
                            PG pg4 = (PG) backStackRecord2.mOps.get(i6);
                            fragment4 = pg4.mFragment;
                            if (fragment4 != null) {
                                fragment4.mBeingSaved = false;
                                fragment4.setPopDirection(true);
                                switch (backStackRecord2.mTransition) {
                                    case 4097:
                                        i11 = 8194;
                                        break;
                                    case 4099:
                                        i11 = 4099;
                                        break;
                                    case 4100:
                                        i11 = 8197;
                                        break;
                                    case 8194:
                                        i11 = 4097;
                                        break;
                                    case 8197:
                                        i11 = 4100;
                                        break;
                                    default:
                                        i11 = 0;
                                        break;
                                }
                                fragment4.setNextTransition(i11);
                                fragment4.setSharedElementNames(backStackRecord2.mSharedElementTargetNames, backStackRecord2.mSharedElementSourceNames);
                            }
                            switch (pg4.mCmd) {
                                case 1:
                                    fragment4.setAnimations(pg4.mEnterAnim, pg4.mExitAnim, pg4.mPopEnterAnim, pg4.mPopExitAnim);
                                    backStackRecord2.mManager.setExitAnimationOrder(fragment4, true);
                                    backStackRecord2.mManager.removeFragment(fragment4);
                                    break;
                                case 3:
                                    fragment4.setAnimations(pg4.mEnterAnim, pg4.mExitAnim, pg4.mPopEnterAnim, pg4.mPopExitAnim);
                                    backStackRecord2.mManager.addFragment(fragment4);
                                    break;
                                case 4:
                                    fragment4.setAnimations(pg4.mEnterAnim, pg4.mExitAnim, pg4.mPopEnterAnim, pg4.mPopExitAnim);
                                    FragmentManager fragmentManager = backStackRecord2.mManager;
                                    FragmentManager.showFragment$ar$ds(fragment4);
                                    break;
                                case 5:
                                    fragment4.setAnimations(pg4.mEnterAnim, pg4.mExitAnim, pg4.mPopEnterAnim, pg4.mPopExitAnim);
                                    backStackRecord2.mManager.setExitAnimationOrder(fragment4, true);
                                    backStackRecord2.mManager.hideFragment(fragment4);
                                    break;
                                case 6:
                                    fragment4.setAnimations(pg4.mEnterAnim, pg4.mExitAnim, pg4.mPopEnterAnim, pg4.mPopExitAnim);
                                    backStackRecord2.mManager.attachFragment(fragment4);
                                    break;
                                case 7:
                                    fragment4.setAnimations(pg4.mEnterAnim, pg4.mExitAnim, pg4.mPopEnterAnim, pg4.mPopExitAnim);
                                    backStackRecord2.mManager.setExitAnimationOrder(fragment4, true);
                                    backStackRecord2.mManager.detachFragment(fragment4);
                                    break;
                                case 8:
                                    backStackRecord2.mManager.setPrimaryNavigationFragment(null);
                                    break;
                                case 9:
                                    backStackRecord2.mManager.setPrimaryNavigationFragment(fragment4);
                                    break;
                                case 10:
                                    backStackRecord2.mManager.setMaxLifecycle(fragment4, pg4.mOldMaxState);
                                    break;
                                default:
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("Unknown cmd: ");
                                    stringBuilder.append(pg4.mCmd);
                                    throw new IllegalArgumentException(stringBuilder.toString());
                            }
                        }
                    } else {
                        backStackRecord2.bumpBackStackNesting(1);
                        i10 = backStackRecord2.mOps.size();
                        for (i6 = 0; i6 < i10; i6++) {
                            PG pg5 = (PG) backStackRecord2.mOps.get(i6);
                            fragment5 = pg5.mFragment;
                            if (fragment5 != null) {
                                fragment5.mBeingSaved = false;
                                fragment5.setPopDirection(false);
                                fragment5.setNextTransition(backStackRecord2.mTransition);
                                fragment5.setSharedElementNames(backStackRecord2.mSharedElementSourceNames, backStackRecord2.mSharedElementTargetNames);
                            }
                            switch (pg5.mCmd) {
                                case 1:
                                    fragment5.setAnimations(pg5.mEnterAnim, pg5.mExitAnim, pg5.mPopEnterAnim, pg5.mPopExitAnim);
                                    backStackRecord2.mManager.setExitAnimationOrder(fragment5, false);
                                    backStackRecord2.mManager.addFragment(fragment5);
                                    break;
                                case 3:
                                    fragment5.setAnimations(pg5.mEnterAnim, pg5.mExitAnim, pg5.mPopEnterAnim, pg5.mPopExitAnim);
                                    backStackRecord2.mManager.removeFragment(fragment5);
                                    break;
                                case 4:
                                    fragment5.setAnimations(pg5.mEnterAnim, pg5.mExitAnim, pg5.mPopEnterAnim, pg5.mPopExitAnim);
                                    backStackRecord2.mManager.hideFragment(fragment5);
                                    break;
                                case 5:
                                    fragment5.setAnimations(pg5.mEnterAnim, pg5.mExitAnim, pg5.mPopEnterAnim, pg5.mPopExitAnim);
                                    backStackRecord2.mManager.setExitAnimationOrder(fragment5, false);
                                    FragmentManager fragmentManager2 = backStackRecord2.mManager;
                                    FragmentManager.showFragment$ar$ds(fragment5);
                                    break;
                                case 6:
                                    fragment5.setAnimations(pg5.mEnterAnim, pg5.mExitAnim, pg5.mPopEnterAnim, pg5.mPopExitAnim);
                                    backStackRecord2.mManager.detachFragment(fragment5);
                                    break;
                                case 7:
                                    fragment5.setAnimations(pg5.mEnterAnim, pg5.mExitAnim, pg5.mPopEnterAnim, pg5.mPopExitAnim);
                                    backStackRecord2.mManager.setExitAnimationOrder(fragment5, false);
                                    backStackRecord2.mManager.attachFragment(fragment5);
                                    break;
                                case 8:
                                    backStackRecord2.mManager.setPrimaryNavigationFragment(fragment5);
                                    break;
                                case 9:
                                    backStackRecord2.mManager.setPrimaryNavigationFragment(null);
                                    break;
                                case 10:
                                    backStackRecord2.mManager.setMaxLifecycle(fragment5, pg5.mCurrentMaxState);
                                    break;
                                default:
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("Unknown cmd: ");
                                    stringBuilder.append(pg5.mCmd);
                                    throw new IllegalArgumentException(stringBuilder.toString());
                            }
                        }
                    }
                }
                ArrayList arrayList7 = arrayList2;
                boolean booleanValue = ((Boolean) arrayList7.get(i3 - 1)).booleanValue();
                for (i4 = i; i4 < i3; i4++) {
                    BackStackRecord backStackRecord3 = (BackStackRecord) arrayList4.get(i4);
                    if (booleanValue) {
                        for (i6 = backStackRecord3.mOps.size() - 1; i6 >= 0; i6--) {
                            fragment4 = ((PG) backStackRecord3.mOps.get(i6)).mFragment;
                            if (fragment4 != null) {
                                createOrGetFragmentStateManager(fragment4).moveToExpectedState();
                            }
                        }
                    } else {
                        List list3 = backStackRecord3.mOps;
                        i6 = list3.size();
                        for (i5 = 0; i5 < i6; i5++) {
                            fragment5 = ((PG) list3.get(i5)).mFragment;
                            if (fragment5 != null) {
                                createOrGetFragmentStateManager(fragment5).moveToExpectedState();
                            }
                        }
                    }
                }
                moveToState(r1.mCurState, true);
                Set<SpecialEffectsController> hashSet = new HashSet();
                for (i10 = i; i10 < i3; i10++) {
                    list = ((BackStackRecord) arrayList4.get(i10)).mOps;
                    i5 = list.size();
                    for (i11 = 0; i11 < i5; i11++) {
                        Fragment fragment7 = ((PG) list.get(i11)).mFragment;
                        if (fragment7 != null) {
                            ViewGroup viewGroup = fragment7.mContainer;
                            if (viewGroup != null) {
                                hashSet.add(SpecialEffectsController.getOrCreateController(viewGroup, r1));
                            }
                        }
                    }
                }
                for (SpecialEffectsController specialEffectsController : hashSet) {
                    Operation operation;
                    specialEffectsController.mOperationDirectionIsPop = booleanValue;
                    synchronized (specialEffectsController.mPendingOperations) {
                        specialEffectsController.updateFinalState();
                        i5 = specialEffectsController.mPendingOperations.size() - 1;
                        while (i5 >= 0) {
                            operation = (Operation) specialEffectsController.mPendingOperations.get(i5);
                            i7 = State.from$ar$edu$b2310ebe_0(operation.mFragment.mView);
                            if (operation.mFinalState$ar$edu != 2 || i7 == 2) {
                                i5--;
                            } else {
                                AnimationInfo animationInfo = operation.mFragment.mAnimationInfo;
                            }
                        }
                    }
                    if (ViewCompat.isAttachedToWindow(specialEffectsController.mContainer)) {
                        synchronized (specialEffectsController.mPendingOperations) {
                            if (!specialEffectsController.mPendingOperations.isEmpty()) {
                                ArrayList arrayList8 = new ArrayList(specialEffectsController.mRunningOperations);
                                specialEffectsController.mRunningOperations.clear();
                                Iterator it = arrayList8.iterator();
                                while (it.hasNext()) {
                                    operation = (Operation) it.next();
                                    if (FragmentManager.isLoggingEnabled(2)) {
                                        StringBuilder stringBuilder2 = new StringBuilder();
                                        stringBuilder2.append("SpecialEffectsController: Cancelling operation ");
                                        stringBuilder2.append(operation);
                                        Log.v("FragmentManager", stringBuilder2.toString());
                                    }
                                    operation.cancel();
                                    if (!operation.mIsComplete) {
                                        specialEffectsController.mRunningOperations.add(operation);
                                    }
                                }
                                specialEffectsController.updateFinalState();
                                list = new ArrayList(specialEffectsController.mPendingOperations);
                                specialEffectsController.mPendingOperations.clear();
                                specialEffectsController.mRunningOperations.addAll(list);
                                if (FragmentManager.isLoggingEnabled(2)) {
                                    Log.v("FragmentManager", "SpecialEffectsController: Executing pending operations");
                                }
                                Iterator it2 = list.iterator();
                                while (it2.hasNext()) {
                                    ((Operation) it2.next()).onStart();
                                }
                                specialEffectsController.executeOperations(list, specialEffectsController.mOperationDirectionIsPop);
                                specialEffectsController.mOperationDirectionIsPop = false;
                                if (FragmentManager.isLoggingEnabled(2)) {
                                    Log.v("FragmentManager", "SpecialEffectsController: Finished executing pending operations");
                                }
                            }
                        }
                    } else {
                        specialEffectsController.forceCompleteAllOperations();
                        specialEffectsController.mOperationDirectionIsPop = false;
                    }
                }
                for (i9 = i; i9 < i3; i9++) {
                    backStackRecord2 = (BackStackRecord) arrayList4.get(i9);
                    if (((Boolean) arrayList7.get(i9)).booleanValue()) {
                        if (backStackRecord2.mIndex >= 0) {
                            backStackRecord2.mIndex = -1;
                        }
                    }
                }
                if (obj != null && r1.mBackStackChangeListeners != null) {
                    for (i6 = 0; i6 < r1.mBackStackChangeListeners.size(); i6++) {
                        FullscreenFragmentHelper.PG pg6 = (FullscreenFragmentHelper.PG) r1.mBackStackChangeListeners.get(i6);
                        if (pg6.this$0.activity.getSupportFragmentManager().getBackStackEntryCount() == 0) {
                            pg6.this$0.activity.finish();
                        } else {
                            FullscreenFragmentHelper fullscreenFragmentHelper = pg6.this$0;
                            Fragment findFragmentById = fullscreenFragmentHelper.activity.getSupportFragmentManager().findFragmentById(16908290);
                            if (Log.isLoggable("FullscreenFragHelper", 3)) {
                                String valueOf = String.valueOf(findFragmentById);
                                StringBuilder stringBuilder3 = new StringBuilder(String.valueOf(valueOf).length() + 22);
                                stringBuilder3.append("focusCurrentFragment: ");
                                stringBuilder3.append(valueOf);
                                Log.d("FullscreenFragHelper", stringBuilder3.toString());
                            }
                            if (findFragmentById != null) {
                                View view = findFragmentById.mView;
                                if (view != null) {
                                    view.setImportantForAccessibility(1);
                                } else if (Log.isLoggable("FullscreenFragHelper", 5)) {
                                    Log.w("FullscreenFragHelper", "Could not load root view of fragment");
                                }
                            }
                            fullscreenFragmentHelper.activity.getWindow().getDecorView().sendAccessibilityEvent(32);
                        }
                    }
                    return;
                }
                return;
            }
        }
    }

    private final ViewGroup getFragmentContainer(Fragment fragment) {
        ViewGroup viewGroup = fragment.mContainer;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (fragment.mContainerId > 0 && this.mContainer.onHasView()) {
            View onFindViewById = this.mContainer.onFindViewById(fragment.mContainerId);
            if (onFindViewById instanceof ViewGroup) {
                return (ViewGroup) onFindViewById;
            }
        }
        return null;
    }

    public static boolean isLoggingEnabled(int i) {
        return Log.isLoggable("FragmentManager", i);
    }

    public static final boolean isMenuAvailable$ar$ds(Fragment fragment) {
        boolean z = fragment.mHasMenu;
        FragmentStore fragmentStore = fragment.mChildFragmentManager.mFragmentStore;
        List<Fragment> arrayList = new ArrayList();
        for (FragmentStateManager fragmentStateManager : fragmentStore.mActive.values()) {
            if (fragmentStateManager != null) {
                arrayList.add(fragmentStateManager.mFragment);
            } else {
                arrayList.add(null);
            }
        }
        boolean z2 = false;
        for (Fragment fragment2 : arrayList) {
            if (fragment2 != null) {
                z2 = FragmentManager.isMenuAvailable$ar$ds(fragment2);
                continue;
            }
            if (z2) {
                return true;
            }
        }
        return false;
    }

    static final boolean isParentMenuVisible$ar$ds(Fragment fragment) {
        boolean z = true;
        if (fragment == null) {
            return true;
        }
        if (!(fragment.mFragmentManager == null || FragmentManager.isParentMenuVisible$ar$ds(fragment.mParentFragment))) {
            z = false;
        }
        return z;
    }

    private final void removeRedundantOperationsAndExecute(ArrayList arrayList, ArrayList arrayList2) {
        if (!arrayList.isEmpty()) {
            if (arrayList.size() == arrayList2.size()) {
                int size = arrayList.size();
                int i = 0;
                int i2 = 0;
                while (i < size) {
                    if (!((BackStackRecord) arrayList.get(i)).mReorderingAllowed) {
                        if (i2 != i) {
                            executeOpsTogether(arrayList, arrayList2, i2, i);
                        }
                        i2 = i + 1;
                        if (((Boolean) arrayList2.get(i)).booleanValue()) {
                            while (i2 < size && ((Boolean) arrayList2.get(i2)).booleanValue() && !((BackStackRecord) arrayList.get(i2)).mReorderingAllowed) {
                                i2++;
                            }
                        }
                        executeOpsTogether(arrayList, arrayList2, i, i2);
                        i = i2 - 1;
                    }
                    i++;
                }
                if (i2 != size) {
                    executeOpsTogether(arrayList, arrayList2, i2, size);
                }
                return;
            }
            throw new IllegalStateException("Internal error with the back stack records");
        }
    }

    private final void setVisibleRemovingFragment(Fragment fragment) {
        ViewGroup fragmentContainer = getFragmentContainer(fragment);
        if (fragmentContainer != null && ((fragment.getEnterAnim() + fragment.getExitAnim()) + fragment.getPopEnterAnim()) + fragment.getPopExitAnim() > 0) {
            if (fragmentContainer.getTag(R.id.visible_removing_fragment_view_tag) == null) {
                fragmentContainer.setTag(R.id.visible_removing_fragment_view_tag, fragment);
            }
            ((Fragment) fragmentContainer.getTag(R.id.visible_removing_fragment_view_tag)).setPopDirection(fragment.getPopDirection());
        }
    }

    static final void showFragment$ar$ds(Fragment fragment) {
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("show: ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
        }
        if (fragment.mHidden) {
            fragment.mHidden = false;
            fragment.mHiddenChanged ^= 1;
        }
    }

    private final void startPendingDeferredFragments() {
        for (FragmentStateManager fragmentStateManager : this.mFragmentStore.getActiveFragmentStateManagers()) {
            Fragment fragment = fragmentStateManager.mFragment;
            if (fragment.mDeferStart) {
                if (this.mExecutingActions) {
                    this.mHavePendingDeferredStart = true;
                } else {
                    fragment.mDeferStart = false;
                    fragmentStateManager.moveToExpectedState();
                }
            }
        }
    }

    final FragmentStateManager addFragment(Fragment fragment) {
        String str = fragment.mPreviousWho;
        if (str != null) {
            FragmentStrictMode.onFragmentReuse(fragment, str);
        }
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add: ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
        }
        FragmentStateManager createOrGetFragmentStateManager = createOrGetFragmentStateManager(fragment);
        fragment.mFragmentManager = this;
        this.mFragmentStore.makeActive(createOrGetFragmentStateManager);
        if (!fragment.mDetached) {
            this.mFragmentStore.addFragment(fragment);
            fragment.mRemoving = false;
            if (fragment.mView == null) {
                fragment.mHiddenChanged = false;
            }
            if (FragmentManager.isMenuAvailable$ar$ds(fragment)) {
                this.mNeedMenuInvalidate = true;
            }
        }
        return createOrGetFragmentStateManager;
    }

    public final void addFragmentOnAttachListener(FragmentOnAttachListener fragmentOnAttachListener) {
        this.mOnAttachListeners.add(fragmentOnAttachListener);
    }

    final void attachController(FragmentHostCallback fragmentHostCallback, FragmentContainer fragmentContainer, Fragment fragment) {
        if (this.mHost == null) {
            this.mHost = fragmentHostCallback;
            this.mContainer = fragmentContainer;
            this.mParent = fragment;
            if (fragment != null) {
                addFragmentOnAttachListener(new C00666());
            } else if (fragmentHostCallback instanceof FragmentOnAttachListener) {
                addFragmentOnAttachListener(fragmentHostCallback);
            }
            if (this.mParent != null) {
                updateOnBackPressedCallbackEnabled();
            }
            if (fragmentHostCallback instanceof OnBackPressedDispatcherOwner) {
                LifecycleOwner lifecycleOwner;
                OnBackPressedDispatcher onBackPressedDispatcher = ((HostCallbacks) fragmentHostCallback).this$0.mOnBackPressedDispatcher;
                this.mOnBackPressedDispatcher = onBackPressedDispatcher;
                if (fragment != null) {
                    lifecycleOwner = fragment;
                } else {
                    lifecycleOwner = fragmentHostCallback;
                }
                OnBackPressedCallback onBackPressedCallback = this.mOnBackPressedCallback;
                Lifecycle lifecycle = lifecycleOwner.getLifecycle();
                if (((LifecycleRegistry) lifecycle).mState != Lifecycle.State.DESTROYED) {
                    onBackPressedCallback.addCancellable(new LifecycleOnBackPressedCancellable(lifecycle, onBackPressedCallback));
                }
            }
            if (fragment != null) {
                FragmentManagerViewModel fragmentManagerViewModel = fragment.mFragmentManager.mNonConfig;
                FragmentManagerViewModel fragmentManagerViewModel2 = (FragmentManagerViewModel) fragmentManagerViewModel.mChildNonConfigs.get(fragment.mWho);
                if (fragmentManagerViewModel2 == null) {
                    fragmentManagerViewModel2 = new FragmentManagerViewModel(fragmentManagerViewModel.mStateAutomaticallySaved);
                    fragmentManagerViewModel.mChildNonConfigs.put(fragment.mWho, fragmentManagerViewModel2);
                }
                this.mNonConfig = fragmentManagerViewModel2;
            } else if (fragmentHostCallback instanceof ViewModelStoreOwner) {
                this.mNonConfig = (FragmentManagerViewModel) new ViewModelProvider(fragmentHostCallback.getViewModelStore(), FragmentManagerViewModel.FACTORY).get(FragmentManagerViewModel.class);
            } else {
                this.mNonConfig = new FragmentManagerViewModel(false);
            }
            this.mNonConfig.mIsStateSaved = isStateSaved();
            this.mFragmentStore.mNonConfig = this.mNonConfig;
            Object obj = this.mHost;
            if ((obj instanceof SavedStateRegistryOwner) && fragment == null) {
                SavedStateRegistry savedStateRegistry = obj.getSavedStateRegistry();
                String str = "android:support:fragments";
                savedStateRegistry.registerSavedStateProvider(str, new FragmentManager$$ExternalSyntheticLambda0());
                Bundle consumeRestoredStateForKey = savedStateRegistry.consumeRestoredStateForKey(str);
                if (consumeRestoredStateForKey != null) {
                    restoreSaveStateInternal(consumeRestoredStateForKey.getParcelable(str));
                }
            }
            fragmentHostCallback = this.mHost;
            if (fragmentHostCallback instanceof ActivityResultRegistryOwner) {
                String stringBuilder;
                ActivityResultRegistry activityResultRegistry = ((HostCallbacks) fragmentHostCallback).this$0.mActivityResultRegistry;
                if (fragment != null) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(fragment.mWho);
                    stringBuilder2.append(":");
                    stringBuilder = stringBuilder2.toString();
                } else {
                    stringBuilder = "";
                }
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("FragmentManager:");
                stringBuilder3.append(stringBuilder);
                stringBuilder = stringBuilder3.toString();
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append(stringBuilder);
                stringBuilder3.append("StartActivityForResult");
                this.mStartActivityForResult = activityResultRegistry.register(stringBuilder3.toString(), new ActivityResultContracts$StartActivityForResult(), new C00677());
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append(stringBuilder);
                stringBuilder3.append("StartIntentSenderForResult");
                this.mStartIntentSenderForResult = activityResultRegistry.register(stringBuilder3.toString(), new FragmentIntentSenderContract(), new C00688());
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append(stringBuilder);
                stringBuilder3.append("RequestPermissions");
                this.mRequestPermissions = activityResultRegistry.register(stringBuilder3.toString(), new ActivityResultContracts$RequestMultiplePermissions(), new C00699());
                return;
            }
            return;
        }
        throw new IllegalStateException("Already attached");
    }

    final void attachFragment(Fragment fragment) {
        String str = "FragmentManager";
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("attach: ");
            stringBuilder.append(fragment);
            Log.v(str, stringBuilder.toString());
        }
        if (fragment.mDetached) {
            fragment.mDetached = false;
            if (!fragment.mAdded) {
                this.mFragmentStore.addFragment(fragment);
                if (FragmentManager.isLoggingEnabled(2)) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("add from attach: ");
                    stringBuilder2.append(fragment);
                    Log.v(str, stringBuilder2.toString());
                }
                if (FragmentManager.isMenuAvailable$ar$ds(fragment)) {
                    this.mNeedMenuInvalidate = true;
                }
            }
        }
    }

    public final FragmentTransaction beginTransaction() {
        return new BackStackRecord(this);
    }

    final FragmentStateManager createOrGetFragmentStateManager(Fragment fragment) {
        FragmentStateManager fragmentStateManager = this.mFragmentStore.getFragmentStateManager(fragment.mWho);
        if (fragmentStateManager != null) {
            return fragmentStateManager;
        }
        fragmentStateManager = new FragmentStateManager(this.mLifecycleCallbacksDispatcher, this.mFragmentStore, fragment);
        fragmentStateManager.restoreState(this.mHost.mContext.getClassLoader());
        fragmentStateManager.mFragmentManagerState = this.mCurState;
        return fragmentStateManager;
    }

    final void detachFragment(Fragment fragment) {
        String str = "FragmentManager";
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("detach: ");
            stringBuilder.append(fragment);
            Log.v(str, stringBuilder.toString());
        }
        if (!fragment.mDetached) {
            fragment.mDetached = true;
            if (fragment.mAdded) {
                if (FragmentManager.isLoggingEnabled(2)) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("remove from detach: ");
                    stringBuilder2.append(fragment);
                    Log.v(str, stringBuilder2.toString());
                }
                this.mFragmentStore.removeFragment(fragment);
                if (FragmentManager.isMenuAvailable$ar$ds(fragment)) {
                    this.mNeedMenuInvalidate = true;
                }
                setVisibleRemovingFragment(fragment);
            }
        }
    }

    final void dispatchActivityCreated() {
        this.mStateSaved = false;
        this.mStopped = false;
        this.mNonConfig.mIsStateSaved = false;
        dispatchStateChange(4);
    }

    final void dispatchConfigurationChanged(Configuration configuration) {
        for (Fragment fragment : this.mFragmentStore.getFragments()) {
            if (fragment != null) {
                fragment.onConfigurationChanged(configuration);
                fragment.mChildFragmentManager.dispatchConfigurationChanged(configuration);
            }
        }
    }

    final boolean dispatchContextItemSelected(MenuItem menuItem) {
        if (this.mCurState <= 0) {
            return false;
        }
        for (Fragment fragment : this.mFragmentStore.getFragments()) {
            if (fragment != null && !fragment.mHidden && fragment.mChildFragmentManager.dispatchContextItemSelected(menuItem)) {
                return true;
            }
        }
        return false;
    }

    final void dispatchCreate() {
        this.mStateSaved = false;
        this.mStopped = false;
        this.mNonConfig.mIsStateSaved = false;
        dispatchStateChange(1);
    }

    final boolean dispatchCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        int i = 0;
        if (this.mCurState <= 0) {
            return false;
        }
        ArrayList arrayList = null;
        boolean z = false;
        for (Fragment fragment : this.mFragmentStore.getFragments()) {
            if (fragment != null && FragmentManager.isParentMenuVisible$ar$ds(fragment) && !fragment.mHidden && fragment.mChildFragmentManager.dispatchCreateOptionsMenu(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(fragment);
                z = true;
            }
        }
        if (this.mCreatedMenus != null) {
            while (i < this.mCreatedMenus.size()) {
                Fragment fragment2 = (Fragment) this.mCreatedMenus.get(i);
                if (arrayList != null) {
                    arrayList.contains(fragment2);
                }
                i++;
            }
        }
        this.mCreatedMenus = arrayList;
        return z;
    }

    final void dispatchDestroy() {
        boolean z;
        Iterator it;
        this.mDestroyed = true;
        execPendingActions$ar$ds$3011d4e5_0(true);
        endAnimatingAwayFragments();
        FragmentHostCallback fragmentHostCallback = this.mHost;
        if (fragmentHostCallback instanceof ViewModelStoreOwner) {
            z = this.mFragmentStore.mNonConfig.mHasBeenCleared;
        } else {
            z = true ^ ((Activity) fragmentHostCallback.mContext).isChangingConfigurations();
        }
        if (z) {
            for (BackStackState backStackState : this.mBackStackStates.values()) {
                for (String str : backStackState.mFragments) {
                    FragmentManagerViewModel fragmentManagerViewModel = this.mFragmentStore.mNonConfig;
                    if (FragmentManager.isLoggingEnabled(3)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Clearing non-config state for saved state of Fragment ");
                        stringBuilder.append(str);
                        Log.d("FragmentManager", stringBuilder.toString());
                    }
                    fragmentManagerViewModel.clearNonConfigStateInternal(str);
                }
            }
        }
        dispatchStateChange(-1);
        this.mHost = null;
        this.mContainer = null;
        this.mParent = null;
        if (this.mOnBackPressedDispatcher != null) {
            it = this.mOnBackPressedCallback.mCancellables.iterator();
            while (it.hasNext()) {
                ((Cancellable) it.next()).cancel();
            }
            this.mOnBackPressedDispatcher = null;
        }
        ActivityResultLauncher activityResultLauncher = this.mStartActivityForResult;
        if (activityResultLauncher != null) {
            activityResultLauncher.unregister();
            this.mStartIntentSenderForResult.unregister();
            this.mRequestPermissions.unregister();
        }
    }

    final void dispatchLowMemory() {
        for (Fragment fragment : this.mFragmentStore.getFragments()) {
            if (fragment != null) {
                fragment.onLowMemory();
                fragment.mChildFragmentManager.dispatchLowMemory();
            }
        }
    }

    final void dispatchMultiWindowModeChanged(boolean z) {
        for (Fragment fragment : this.mFragmentStore.getFragments()) {
            if (fragment != null) {
                fragment.mChildFragmentManager.dispatchMultiWindowModeChanged(z);
            }
        }
    }

    final boolean dispatchOptionsItemSelected(MenuItem menuItem) {
        if (this.mCurState <= 0) {
            return false;
        }
        for (Fragment fragment : this.mFragmentStore.getFragments()) {
            if (fragment != null && !fragment.mHidden && fragment.mChildFragmentManager.dispatchOptionsItemSelected(menuItem)) {
                return true;
            }
        }
        return false;
    }

    final void dispatchOptionsMenuClosed(Menu menu) {
        if (this.mCurState > 0) {
            for (Fragment fragment : this.mFragmentStore.getFragments()) {
                if (!(fragment == null || fragment.mHidden)) {
                    fragment.mChildFragmentManager.dispatchOptionsMenuClosed(menu);
                }
            }
        }
    }

    public final void dispatchParentPrimaryNavigationFragmentChanged(Fragment fragment) {
        if (fragment != null && fragment.equals(findActiveFragment(fragment.mWho))) {
            boolean isPrimaryNavigation = fragment.mFragmentManager.isPrimaryNavigation(fragment);
            Boolean bool = fragment.mIsPrimaryNavigationFragment;
            if (bool == null || bool.booleanValue() != isPrimaryNavigation) {
                fragment.mIsPrimaryNavigationFragment = Boolean.valueOf(isPrimaryNavigation);
                FragmentManager fragmentManager = fragment.mChildFragmentManager;
                fragmentManager.updateOnBackPressedCallbackEnabled();
                fragmentManager.dispatchParentPrimaryNavigationFragmentChanged(fragmentManager.mPrimaryNav);
            }
        }
    }

    final void dispatchPause() {
        dispatchStateChange(5);
    }

    final void dispatchPictureInPictureModeChanged(boolean z) {
        for (Fragment fragment : this.mFragmentStore.getFragments()) {
            if (fragment != null) {
                fragment.mChildFragmentManager.dispatchPictureInPictureModeChanged(z);
            }
        }
    }

    final boolean dispatchPrepareOptionsMenu(Menu menu) {
        boolean z = false;
        if (this.mCurState <= 0) {
            return false;
        }
        for (Fragment fragment : this.mFragmentStore.getFragments()) {
            if (fragment != null && FragmentManager.isParentMenuVisible$ar$ds(fragment) && !fragment.mHidden && fragment.mChildFragmentManager.dispatchPrepareOptionsMenu(menu)) {
                z = true;
            }
        }
        return z;
    }

    final void dispatchResume() {
        this.mStateSaved = false;
        this.mStopped = false;
        this.mNonConfig.mIsStateSaved = false;
        dispatchStateChange(7);
    }

    final void dispatchStart() {
        this.mStateSaved = false;
        this.mStopped = false;
        this.mNonConfig.mIsStateSaved = false;
        dispatchStateChange(5);
    }

    final void dispatchStop() {
        this.mStopped = true;
        this.mNonConfig.mIsStateSaved = true;
        dispatchStateChange(4);
    }

    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int i;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("    ");
        String stringBuilder2 = stringBuilder.toString();
        FragmentStore fragmentStore = this.mFragmentStore;
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append("    ");
        String stringBuilder4 = stringBuilder3.toString();
        if (!fragmentStore.mActive.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Active Fragments:");
            for (FragmentStateManager fragmentStateManager : fragmentStore.mActive.values()) {
                printWriter.print(str);
                if (fragmentStateManager != null) {
                    Fragment fragment = fragmentStateManager.mFragment;
                    printWriter.println(fragment);
                    fragment.dump(stringBuilder4, fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size = fragmentStore.mAdded.size();
        if (size > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i2 = 0; i2 < size; i2++) {
                Fragment fragment2 = (Fragment) fragmentStore.mAdded.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(fragment2.toString());
            }
        }
        ArrayList arrayList = this.mCreatedMenus;
        if (arrayList != null) {
            size = arrayList.size();
            if (size > 0) {
                printWriter.print(str);
                printWriter.println("Fragments Created Menus:");
                for (i = 0; i < size; i++) {
                    Fragment fragment3 = (Fragment) this.mCreatedMenus.get(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i);
                    printWriter.print(": ");
                    printWriter.println(fragment3.toString());
                }
            }
        }
        arrayList = this.mBackStack;
        if (arrayList != null) {
            size = arrayList.size();
            if (size > 0) {
                printWriter.print(str);
                printWriter.println("Back Stack:");
                for (i = 0; i < size; i++) {
                    BackStackRecord backStackRecord = (BackStackRecord) this.mBackStack.get(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i);
                    printWriter.print(": ");
                    printWriter.println(backStackRecord.toString());
                    backStackRecord.dump(stringBuilder2, printWriter);
                }
            }
        }
        printWriter.print(str);
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append("Back Stack Index: ");
        stringBuilder5.append(this.mBackStackIndex.get());
        printWriter.println(stringBuilder5.toString());
        synchronized (this.mPendingActions) {
            int size2 = this.mPendingActions.size();
            if (size2 > 0) {
                printWriter.print(str);
                printWriter.println("Pending Actions:");
                for (int i3 = 0; i3 < size2; i3++) {
                    OpGenerator opGenerator = (OpGenerator) this.mPendingActions.get(i3);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i3);
                    printWriter.print(": ");
                    printWriter.println(opGenerator);
                }
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.mHost);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.mContainer);
        if (this.mParent != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.mParent);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.mCurState);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.mStateSaved);
        printWriter.print(" mStopped=");
        printWriter.print(this.mStopped);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.mDestroyed);
        if (this.mNeedMenuInvalidate) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.mNeedMenuInvalidate);
        }
    }

    final void enqueueAction(OpGenerator opGenerator, boolean z) {
        if (!z) {
            if (this.mHost != null) {
                checkStateLoss();
            } else if (this.mDestroyed) {
                throw new IllegalStateException("FragmentManager has been destroyed");
            } else {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
        }
        synchronized (this.mPendingActions) {
            if (this.mHost != null) {
                this.mPendingActions.add(opGenerator);
                synchronized (this.mPendingActions) {
                    if (this.mPendingActions.size() == 1) {
                        this.mHost.mHandler.removeCallbacks(this.mExecCommit);
                        this.mHost.mHandler.post(this.mExecCommit);
                        updateOnBackPressedCallbackEnabled();
                    }
                }
            } else if (z) {
            } else {
                throw new IllegalStateException("Activity has been destroyed");
            }
        }
    }

    final void execPendingActions$ar$ds$3011d4e5_0(boolean z) {
        ensureExecReady(z);
        while (true) {
            ArrayList arrayList = this.mTmpRecords;
            ArrayList arrayList2 = this.mTmpIsPop;
            synchronized (this.mPendingActions) {
                try {
                    if (!this.mPendingActions.isEmpty()) {
                        int i = 0;
                        for (int i2 = 0; i2 < this.mPendingActions.size(); i2++) {
                            i |= ((OpGenerator) this.mPendingActions.get(i2)).generateOps(arrayList, arrayList2);
                        }
                        this.mPendingActions.clear();
                        this.mHost.mHandler.removeCallbacks(this.mExecCommit);
                        if (i == 0) {
                            break;
                        }
                        this.mExecutingActions = true;
                        try {
                            removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
                            cleanupExec();
                        } catch (Throwable th) {
                            cleanupExec();
                            throw th;
                        }
                    }
                    break;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        updateOnBackPressedCallbackEnabled();
        doPendingDeferredStart();
        this.mFragmentStore.burpActive();
    }

    final void execSingleAction(OpGenerator opGenerator, boolean z) {
        if (z) {
            if (this.mHost == null || this.mDestroyed) {
                return;
            }
        }
        ensureExecReady(z);
        opGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop);
        this.mExecutingActions = true;
        try {
            removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
            updateOnBackPressedCallbackEnabled();
            doPendingDeferredStart();
            this.mFragmentStore.burpActive();
        } finally {
            cleanupExec();
        }
    }

    final Fragment findActiveFragment(String str) {
        return this.mFragmentStore.findActiveFragment(str);
    }

    public final int getBackStackEntryCount() {
        ArrayList arrayList = this.mBackStack;
        return arrayList != null ? arrayList.size() : 0;
    }

    public final FragmentFactory getFragmentFactory() {
        Fragment fragment = this.mParent;
        return fragment != null ? fragment.mFragmentManager.getFragmentFactory() : this.mHostFragmentFactory;
    }

    final C00643 getSpecialEffectsControllerFactory$ar$class_merging() {
        Fragment fragment = this.mParent;
        return fragment != null ? fragment.mFragmentManager.getSpecialEffectsControllerFactory$ar$class_merging() : this.mDefaultSpecialEffectsControllerFactory$ar$class_merging;
    }

    final void hideFragment(Fragment fragment) {
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("hide: ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
        }
        if (!fragment.mHidden) {
            fragment.mHidden = true;
            fragment.mHiddenChanged = true ^ fragment.mHiddenChanged;
            setVisibleRemovingFragment(fragment);
        }
    }

    final boolean isPrimaryNavigation(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        FragmentManager fragmentManager = fragment.mFragmentManager;
        return fragment.equals(fragmentManager.mPrimaryNav) && isPrimaryNavigation(fragmentManager.mParent);
    }

    public final boolean isStateSaved() {
        if (!this.mStateSaved) {
            if (!this.mStopped) {
                return false;
            }
        }
        return true;
    }

    final void noteStateNotSaved() {
        if (this.mHost != null) {
            this.mStateSaved = false;
            this.mStopped = false;
            this.mNonConfig.mIsStateSaved = false;
            for (Fragment fragment : this.mFragmentStore.getFragments()) {
                if (fragment != null) {
                    fragment.mChildFragmentManager.noteStateNotSaved();
                }
            }
        }
    }

    final void removeFragment(Fragment fragment) {
        if (FragmentManager.isLoggingEnabled(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("remove: ");
            stringBuilder.append(fragment);
            stringBuilder.append(" nesting=");
            stringBuilder.append(fragment.mBackStackNesting);
            Log.v("FragmentManager", stringBuilder.toString());
        }
        int isInBackStack = fragment.isInBackStack() ^ 1;
        if (fragment.mDetached) {
            if (isInBackStack == 0) {
                return;
            }
        }
        this.mFragmentStore.removeFragment(fragment);
        if (FragmentManager.isMenuAvailable$ar$ds(fragment)) {
            this.mNeedMenuInvalidate = true;
        }
        fragment.mRemoving = true;
        setVisibleRemovingFragment(fragment);
    }

    final void restoreSaveStateInternal(android.os.Parcelable r19) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Unknown predecessor block by arg (r11_6 android.support.v4.app.FragmentStateManager) in PHI: PHI: (r11_7 android.support.v4.app.FragmentStateManager) = (r11_5 android.support.v4.app.FragmentStateManager), (r11_6 android.support.v4.app.FragmentStateManager) binds: {(r11_5 android.support.v4.app.FragmentStateManager)=B:19:0x0079, (r11_6 android.support.v4.app.FragmentStateManager)=B:20:0x0083}
	at jadx.core.dex.instructions.PhiInsn.replaceArg(PhiInsn.java:79)
	at jadx.core.dex.visitors.ModVisitor.processInvoke(ModVisitor.java:222)
	at jadx.core.dex.visitors.ModVisitor.replaceStep(ModVisitor.java:83)
	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:68)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:60)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
*/
        /*
        r18 = this;
        r0 = r18;
        if (r19 != 0) goto L_0x0005;
    L_0x0004:
        return;
    L_0x0005:
        r1 = r19;
        r1 = (android.support.p000v4.app.FragmentManagerState) r1;
        r2 = r1.mSavedState;
        if (r2 != 0) goto L_0x000e;
    L_0x000d:
        return;
    L_0x000e:
        r3 = r0.mFragmentStore;
        r4 = r3.mSavedState;
        r4.clear();
        r4 = r2.size();
        r5 = 0;
        r6 = 0;
    L_0x001b:
        if (r6 >= r4) goto L_0x002d;
    L_0x001d:
        r7 = r2.get(r6);
        r7 = (android.support.p000v4.app.FragmentState) r7;
        r8 = r3.mSavedState;
        r9 = r7.mWho;
        r8.put(r9, r7);
        r6 = r6 + 1;
        goto L_0x001b;
    L_0x002d:
        r2 = r0.mFragmentStore;
        r2 = r2.mActive;
        r2.clear();
        r2 = r1.mActive;
        r3 = r2.size();
        r4 = 0;
    L_0x003b:
        r6 = 0;
        r7 = "): ";
        r8 = "FragmentManager";
        r9 = 2;
        if (r4 >= r3) goto L_0x00d9;
    L_0x0043:
        r10 = r2.get(r4);
        r10 = (java.lang.String) r10;
        r11 = r0.mFragmentStore;
        r6 = r11.setSavedState(r10, r6);
        if (r6 == 0) goto L_0x00d5;
    L_0x0051:
        r10 = r0.mNonConfig;
        r11 = r6.mWho;
        r10 = r10.mRetainedFragments;
        r10 = r10.get(r11);
        r10 = (android.support.p000v4.app.Fragment) r10;
        if (r10 == 0) goto L_0x0083;
    L_0x005f:
        r11 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r11 == 0) goto L_0x0079;
    L_0x0065:
        r11 = new java.lang.StringBuilder;
        r11.<init>();
        r12 = "restoreSaveState: re-attaching retained ";
        r11.append(r12);
        r11.append(r10);
        r11 = r11.toString();
        android.util.Log.v(r8, r11);
    L_0x0079:
        r11 = new android.support.v4.app.FragmentStateManager;
        r12 = r0.mLifecycleCallbacksDispatcher;
        r13 = r0.mFragmentStore;
        r11.<init>(r12, r13, r10, r6);
        goto L_0x009b;
    L_0x0083:
        r11 = new android.support.v4.app.FragmentStateManager;
        r13 = r0.mLifecycleCallbacksDispatcher;
        r14 = r0.mFragmentStore;
        r10 = r0.mHost;
        r10 = r10.mContext;
        r15 = r10.getClassLoader();
        r16 = r18.getFragmentFactory();
        r12 = r11;
        r17 = r6;
        r12.<init>(r13, r14, r15, r16, r17);
    L_0x009b:
        r6 = r11.mFragment;
        r6.mFragmentManager = r0;
        r9 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r9 == 0) goto L_0x00c1;
    L_0x00a5:
        r9 = new java.lang.StringBuilder;
        r9.<init>();
        r10 = "restoreSaveState: active (";
        r9.append(r10);
        r10 = r6.mWho;
        r9.append(r10);
        r9.append(r7);
        r9.append(r6);
        r6 = r9.toString();
        android.util.Log.v(r8, r6);
    L_0x00c1:
        r6 = r0.mHost;
        r6 = r6.mContext;
        r6 = r6.getClassLoader();
        r11.restoreState(r6);
        r6 = r0.mFragmentStore;
        r6.makeActive(r11);
        r6 = r0.mCurState;
        r11.mFragmentManagerState = r6;
    L_0x00d5:
        r4 = r4 + 1;
        goto L_0x003b;
    L_0x00d9:
        r2 = r0.mNonConfig;
        r3 = new java.util.ArrayList;
        r2 = r2.mRetainedFragments;
        r2 = r2.values();
        r3.<init>(r2);
        r2 = r3.iterator();
    L_0x00ea:
        r3 = r2.hasNext();
        r4 = 1;
        if (r3 == 0) goto L_0x0140;
    L_0x00f1:
        r3 = r2.next();
        r3 = (android.support.p000v4.app.Fragment) r3;
        r10 = r0.mFragmentStore;
        r11 = r3.mWho;
        r10 = r10.containsActiveFragment(r11);
        if (r10 != 0) goto L_0x00ea;
    L_0x0101:
        r10 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r10 == 0) goto L_0x0125;
    L_0x0107:
        r10 = new java.lang.StringBuilder;
        r10.<init>();
        r11 = "Discarding retained Fragment ";
        r10.append(r11);
        r10.append(r3);
        r11 = " that was not found in the set of active Fragments ";
        r10.append(r11);
        r11 = r1.mActive;
        r10.append(r11);
        r10 = r10.toString();
        android.util.Log.v(r8, r10);
    L_0x0125:
        r10 = r0.mNonConfig;
        r10.removeRetainedFragment(r3);
        r3.mFragmentManager = r0;
        r10 = new android.support.v4.app.FragmentStateManager;
        r11 = r0.mLifecycleCallbacksDispatcher;
        r12 = r0.mFragmentStore;
        r10.<init>(r11, r12, r3);
        r10.mFragmentManagerState = r4;
        r10.moveToExpectedState();
        r3.mRemoving = r4;
        r10.moveToExpectedState();
        goto L_0x00ea;
    L_0x0140:
        r2 = r0.mFragmentStore;
        r3 = r1.mAdded;
        r10 = r2.mAdded;
        r10.clear();
        if (r3 == 0) goto L_0x01a2;
    L_0x014b:
        r3 = r3.iterator();
    L_0x014f:
        r10 = r3.hasNext();
        if (r10 == 0) goto L_0x01a2;
    L_0x0155:
        r10 = r3.next();
        r10 = (java.lang.String) r10;
        r11 = r2.findActiveFragment(r10);
        if (r11 == 0) goto L_0x0186;
        r12 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r12 == 0) goto L_0x0182;
    L_0x0168:
        r12 = new java.lang.StringBuilder;
        r12.<init>();
        r13 = "restoreSaveState: added (";
        r12.append(r13);
        r12.append(r10);
        r12.append(r7);
        r12.append(r11);
        r10 = r12.toString();
        android.util.Log.v(r8, r10);
    L_0x0182:
        r2.addFragment(r11);
        goto L_0x014f;
    L_0x0186:
        r1 = new java.lang.IllegalStateException;
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = "No instantiated fragment for (";
        r2.append(r3);
        r2.append(r10);
        r3 = ")";
        r2.append(r3);
        r2 = r2.toString();
        r1.<init>(r2);
        throw r1;
    L_0x01a2:
        r2 = r1.mBackStack;
        if (r2 == 0) goto L_0x02e2;
    L_0x01a6:
        r2 = r2.length;
        r3 = new java.util.ArrayList;
        r3.<init>(r2);
        r0.mBackStack = r3;
        r2 = 0;
    L_0x01af:
        r3 = r1.mBackStack;
        r6 = r3.length;
        if (r2 >= r6) goto L_0x02e4;
    L_0x01b4:
        r3 = r3[r2];
        r6 = new android.support.v4.app.BackStackRecord;
        r6.<init>(r0);
        r10 = 0;
        r11 = 0;
    L_0x01bd:
        r12 = r3.mOps;
        r12 = r12.length;
        if (r10 >= r12) goto L_0x024b;
    L_0x01c2:
        r12 = new android.support.v4.app.FragmentTransaction$Op;
        r12.<init>();
        r13 = r10 + 1;
        r14 = r3.mOps;
        r10 = r14[r10];
        r12.mCmd = r10;
        r10 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r10 == 0) goto L_0x01fd;
    L_0x01d5:
        r10 = new java.lang.StringBuilder;
        r10.<init>();
        r14 = "Instantiate ";
        r10.append(r14);
        r10.append(r6);
        r14 = " op #";
        r10.append(r14);
        r10.append(r11);
        r14 = " base fragment #";
        r10.append(r14);
        r14 = r3.mOps;
        r14 = r14[r13];
        r10.append(r14);
        r10 = r10.toString();
        android.util.Log.v(r8, r10);
    L_0x01fd:
        r10 = androidx.lifecycle.Lifecycle.State.values();
        r14 = r3.mOldMaxLifecycleStates;
        r14 = r14[r11];
        r10 = r10[r14];
        r12.mOldMaxState = r10;
        r10 = androidx.lifecycle.Lifecycle.State.values();
        r14 = r3.mCurrentMaxLifecycleStates;
        r14 = r14[r11];
        r10 = r10[r14];
        r12.mCurrentMaxState = r10;
        r10 = r3.mOps;
        r14 = r13 + 1;
        r13 = r10[r13];
        if (r13 == 0) goto L_0x021f;
    L_0x021d:
        r13 = 1;
        goto L_0x0220;
    L_0x021f:
        r13 = 0;
    L_0x0220:
        r12.mFromExpandedOp = r13;
        r13 = r14 + 1;
        r14 = r10[r14];
        r12.mEnterAnim = r14;
        r15 = r13 + 1;
        r13 = r10[r13];
        r12.mExitAnim = r13;
        r16 = r15 + 1;
        r15 = r10[r15];
        r12.mPopEnterAnim = r15;
        r17 = r16 + 1;
        r10 = r10[r16];
        r12.mPopExitAnim = r10;
        r6.mEnterAnim = r14;
        r6.mExitAnim = r13;
        r6.mPopEnterAnim = r15;
        r6.mPopExitAnim = r10;
        r6.addOp(r12);
        r11 = r11 + 1;
        r10 = r17;
        goto L_0x01bd;
    L_0x024b:
        r10 = r3.mTransition;
        r6.mTransition = r10;
        r10 = r3.mName;
        r6.mName = r10;
        r6.mAddToBackStack = r4;
        r10 = r3.mBreadCrumbTitleRes;
        r6.mBreadCrumbTitleRes = r10;
        r10 = r3.mBreadCrumbTitleText;
        r6.mBreadCrumbTitleText = r10;
        r10 = r3.mBreadCrumbShortTitleRes;
        r6.mBreadCrumbShortTitleRes = r10;
        r10 = r3.mBreadCrumbShortTitleText;
        r6.mBreadCrumbShortTitleText = r10;
        r10 = r3.mSharedElementSourceNames;
        r6.mSharedElementSourceNames = r10;
        r10 = r3.mSharedElementTargetNames;
        r6.mSharedElementTargetNames = r10;
        r10 = r3.mReorderingAllowed;
        r6.mReorderingAllowed = r10;
        r10 = r3.mIndex;
        r6.mIndex = r10;
        r10 = 0;
    L_0x0276:
        r11 = r3.mFragmentWhos;
        r11 = r11.size();
        if (r10 >= r11) goto L_0x0299;
    L_0x027e:
        r11 = r3.mFragmentWhos;
        r11 = r11.get(r10);
        r11 = (java.lang.String) r11;
        if (r11 == 0) goto L_0x0296;
    L_0x0288:
        r12 = r6.mOps;
        r12 = r12.get(r10);
        r12 = (android.support.p000v4.app.FragmentTransaction.PG) r12;
        r11 = r0.findActiveFragment(r11);
        r12.mFragment = r11;
    L_0x0296:
        r10 = r10 + 1;
        goto L_0x0276;
        r6.bumpBackStackNesting(r4);
        r3 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r3 == 0) goto L_0x02d9;
    L_0x02a3:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r10 = "restoreAllState: back stack #";
        r3.append(r10);
        r3.append(r2);
        r10 = " (index ";
        r3.append(r10);
        r10 = r6.mIndex;
        r3.append(r10);
        r3.append(r7);
        r3.append(r6);
        r3 = r3.toString();
        android.util.Log.v(r8, r3);
        r3 = new android.support.v4.app.LogWriter;
        r3.<init>();
        r10 = new java.io.PrintWriter;
        r10.<init>(r3);
        r3 = "  ";
        r6.dump(r3, r10, r5);
        r10.close();
    L_0x02d9:
        r3 = r0.mBackStack;
        r3.add(r6);
        r2 = r2 + 1;
        goto L_0x01af;
    L_0x02e2:
        r0.mBackStack = r6;
    L_0x02e4:
        r2 = r0.mBackStackIndex;
        r3 = r1.mBackStackIndex;
        r2.set(r3);
        r2 = r1.mPrimaryNavActiveWho;
        if (r2 == 0) goto L_0x02f8;
    L_0x02ef:
        r2 = r0.findActiveFragment(r2);
        r0.mPrimaryNav = r2;
        r0.dispatchParentPrimaryNavigationFragmentChanged(r2);
    L_0x02f8:
        r2 = r1.mBackStackStateKeys;
        if (r2 == 0) goto L_0x0319;
    L_0x02fc:
        r3 = 0;
    L_0x02fd:
        r4 = r2.size();
        if (r3 >= r4) goto L_0x0319;
    L_0x0303:
        r4 = r0.mBackStackStates;
        r6 = r2.get(r3);
        r6 = (java.lang.String) r6;
        r7 = r1.mBackStackStates;
        r7 = r7.get(r3);
        r7 = (android.support.p000v4.app.BackStackState) r7;
        r4.put(r6, r7);
        r3 = r3 + 1;
        goto L_0x02fd;
    L_0x0319:
        r2 = r1.mResultKeys;
        if (r2 == 0) goto L_0x0344;
    L_0x031d:
        r3 = r2.size();
        if (r5 >= r3) goto L_0x0344;
    L_0x0323:
        r3 = r1.mResults;
        r3 = r3.get(r5);
        r3 = (android.os.Bundle) r3;
        r4 = r0.mHost;
        r4 = r4.mContext;
        r4 = r4.getClassLoader();
        r3.setClassLoader(r4);
        r4 = r0.mResults;
        r6 = r2.get(r5);
        r6 = (java.lang.String) r6;
        r4.put(r6, r3);
        r5 = r5 + 1;
        goto L_0x031d;
    L_0x0344:
        r2 = new java.util.ArrayDeque;
        r1 = r1.mLaunchedFragments;
        r2.<init>(r1);
        r0.mLaunchedFragments = r2;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.FragmentManager.restoreSaveStateInternal(android.os.Parcelable):void");
    }

    final void setExitAnimationOrder(Fragment fragment, boolean z) {
        ViewGroup fragmentContainer = getFragmentContainer(fragment);
        if (fragmentContainer != null && (fragmentContainer instanceof FragmentContainerView)) {
            ((FragmentContainerView) fragmentContainer).drawDisappearingViewsFirst = z ^ 1;
        }
    }

    final void setMaxLifecycle(Fragment fragment, Lifecycle.State state) {
        if (fragment.equals(findActiveFragment(fragment.mWho)) && (fragment.mHost == null || fragment.mFragmentManager == this)) {
            fragment.mMaxState = state;
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(fragment);
        stringBuilder.append(" is not an active fragment of FragmentManager ");
        stringBuilder.append(this);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    final void setPrimaryNavigationFragment(Fragment fragment) {
        if (fragment != null) {
            if (fragment.equals(findActiveFragment(fragment.mWho))) {
                if (fragment.mHost != null) {
                    if (fragment.mFragmentManager == this) {
                    }
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Fragment ");
            stringBuilder.append(fragment);
            stringBuilder.append(" is not an active fragment of FragmentManager ");
            stringBuilder.append(this);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        Fragment fragment2 = this.mPrimaryNav;
        this.mPrimaryNav = fragment;
        dispatchParentPrimaryNavigationFragmentChanged(fragment2);
        dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("FragmentManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        Fragment fragment = this.mParent;
        String str = "}";
        String str2 = "{";
        if (fragment != null) {
            stringBuilder.append(fragment.getClass().getSimpleName());
            stringBuilder.append(str2);
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this.mParent)));
            stringBuilder.append(str);
        } else {
            FragmentHostCallback fragmentHostCallback = this.mHost;
            if (fragmentHostCallback != null) {
                stringBuilder.append(fragmentHostCallback.getClass().getSimpleName());
                stringBuilder.append(str2);
                stringBuilder.append(Integer.toHexString(System.identityHashCode(this.mHost)));
                stringBuilder.append(str);
            } else {
                stringBuilder.append("null");
            }
        }
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void updateOnBackPressedCallbackEnabled() {
        /*
        r4 = this;
        r0 = r4.mPendingActions;
        monitor-enter(r0);
        r1 = r4.mPendingActions;	 Catch:{ all -> 0x0029 }
        r1 = r1.isEmpty();	 Catch:{ all -> 0x0029 }
        r2 = 1;
        if (r1 != 0) goto L_0x0012;
    L_0x000c:
        r1 = r4.mOnBackPressedCallback;	 Catch:{ all -> 0x0029 }
        r1.mEnabled = r2;	 Catch:{ all -> 0x0029 }
        monitor-exit(r0);	 Catch:{ all -> 0x0029 }
        return;
    L_0x0012:
        monitor-exit(r0);	 Catch:{ all -> 0x0029 }
        r0 = r4.mOnBackPressedCallback;
        r1 = r4.getBackStackEntryCount();
        r3 = 0;
        if (r1 <= 0) goto L_0x0025;
    L_0x001c:
        r1 = r4.mParent;
        r1 = r4.isPrimaryNavigation(r1);
        if (r1 == 0) goto L_0x0025;
    L_0x0024:
        goto L_0x0026;
    L_0x0025:
        r2 = 0;
    L_0x0026:
        r0.mEnabled = r2;
        return;
    L_0x0029:
        r1 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x0029 }
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.FragmentManager.updateOnBackPressedCallbackEnabled():void");
    }

    public final void dispatchStateChange(int i) {
        try {
            this.mExecutingActions = true;
            for (FragmentStateManager fragmentStateManager : this.mFragmentStore.mActive.values()) {
                if (fragmentStateManager != null) {
                    fragmentStateManager.mFragmentManagerState = i;
                }
            }
            moveToState(i, false);
            for (SpecialEffectsController forceCompleteAllOperations : collectAllSpecialEffectsController()) {
                forceCompleteAllOperations.forceCompleteAllOperations();
            }
            execPendingActions$ar$ds$3011d4e5_0(true);
        } finally {
            this.mExecutingActions = false;
        }
    }

    public final Fragment findFragmentById(int i) {
        FragmentStore fragmentStore = this.mFragmentStore;
        for (int size = fragmentStore.mAdded.size() - 1; size >= 0; size--) {
            Fragment fragment = (Fragment) fragmentStore.mAdded.get(size);
            if (fragment != null && fragment.mFragmentId == i) {
                return fragment;
            }
        }
        for (FragmentStateManager fragmentStateManager : fragmentStore.mActive.values()) {
            if (fragmentStateManager != null) {
                fragment = fragmentStateManager.mFragment;
                if (fragment.mFragmentId == i) {
                    return fragment;
                }
            }
        }
        return null;
    }

    public final Fragment findFragmentByTag(String str) {
        FragmentStore fragmentStore = this.mFragmentStore;
        for (int size = fragmentStore.mAdded.size() - 1; size >= 0; size--) {
            Fragment fragment = (Fragment) fragmentStore.mAdded.get(size);
            if (fragment != null && str.equals(fragment.mTag)) {
                return fragment;
            }
        }
        for (FragmentStateManager fragmentStateManager : fragmentStore.mActive.values()) {
            if (fragmentStateManager != null) {
                fragment = fragmentStateManager.mFragment;
                if (str.equals(fragment.mTag)) {
                    return fragment;
                }
            }
        }
        return null;
    }

    final void moveToState(int i, boolean z) {
        if (this.mHost == null) {
            if (i != -1) {
                throw new IllegalStateException("No activity");
            }
        }
        if (!z) {
            if (i == this.mCurState) {
                return;
            }
        }
        this.mCurState = i;
        FragmentStore fragmentStore = this.mFragmentStore;
        List list = fragmentStore.mAdded;
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            FragmentStateManager fragmentStateManager = (FragmentStateManager) fragmentStore.mActive.get(((Fragment) list.get(i2)).mWho);
            if (fragmentStateManager != null) {
                fragmentStateManager.moveToExpectedState();
            }
        }
        for (FragmentStateManager fragmentStateManager2 : fragmentStore.mActive.values()) {
            if (fragmentStateManager2 != null) {
                fragmentStateManager2.moveToExpectedState();
                Fragment fragment = fragmentStateManager2.mFragment;
                if (fragment.mRemoving && !fragment.isInBackStack()) {
                    boolean z2 = fragment.mBeingSaved;
                    fragmentStore.makeInactive(fragmentStateManager2);
                }
            }
        }
        startPendingDeferredFragments();
        if (this.mNeedMenuInvalidate) {
            FragmentHostCallback fragmentHostCallback = this.mHost;
            if (fragmentHostCallback != null && this.mCurState == 7) {
                ((HostCallbacks) fragmentHostCallback).this$0.supportInvalidateOptionsMenu();
                this.mNeedMenuInvalidate = false;
            }
        }
    }

    public final boolean popBackStackImmediate() {
        execPendingActions$ar$ds$3011d4e5_0(false);
        ensureExecReady(true);
        Fragment fragment = this.mPrimaryNav;
        if (fragment != null && fragment.getChildFragmentManager().popBackStackImmediate()) {
            return true;
        }
        boolean popBackStackState$ar$ds = popBackStackState$ar$ds(this.mTmpRecords, this.mTmpIsPop, -1, 0);
        if (popBackStackState$ar$ds) {
            this.mExecutingActions = true;
            try {
                removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
            } finally {
                cleanupExec();
            }
        }
        updateOnBackPressedCallbackEnabled();
        doPendingDeferredStart();
        this.mFragmentStore.burpActive();
        return popBackStackState$ar$ds;
    }

    final boolean popBackStackState$ar$ds(ArrayList arrayList, ArrayList arrayList2, int i, int i2) {
        ArrayList arrayList3 = this.mBackStack;
        if (arrayList3 != null) {
            if (arrayList3.isEmpty()) {
                i = -1;
            } else if (i < 0) {
                i = i2 != 0 ? 0 : this.mBackStack.size() - 1;
            } else {
                int size = this.mBackStack.size() - 1;
                while (size >= 0) {
                    if (i == ((BackStackRecord) this.mBackStack.get(size)).mIndex) {
                        break;
                    }
                    size--;
                }
                if (size < 0) {
                    i = size;
                } else if (i2 != 0) {
                    while (size > 0) {
                        i2 = size - 1;
                        if (i != ((BackStackRecord) this.mBackStack.get(i2)).mIndex) {
                            break;
                        }
                        size = i2;
                    }
                    i = size;
                } else if (size != this.mBackStack.size() - 1) {
                    i = size + 1;
                }
            }
            if (i < 0) {
                return false;
            }
            for (i2 = this.mBackStack.size() - 1; i2 >= i; i2--) {
                arrayList.add((BackStackRecord) this.mBackStack.remove(i2));
                arrayList2.add(Boolean.valueOf(true));
            }
            return true;
        }
        i = -1;
        if (i < 0) {
            return false;
        }
        for (i2 = this.mBackStack.size() - 1; i2 >= i; i2--) {
            arrayList.add((BackStackRecord) this.mBackStack.remove(i2));
            arrayList2.add(Boolean.valueOf(true));
        }
        return true;
    }

    final Parcelable saveAllStateInternal() {
        Iterator it;
        for (SpecialEffectsController specialEffectsController : collectAllSpecialEffectsController()) {
        }
        endAnimatingAwayFragments();
        execPendingActions$ar$ds$3011d4e5_0(true);
        this.mStateSaved = true;
        this.mNonConfig.mIsStateSaved = true;
        FragmentStore fragmentStore = this.mFragmentStore;
        ArrayList arrayList = new ArrayList(fragmentStore.mActive.size());
        Iterator it2 = fragmentStore.mActive.values().iterator();
        while (true) {
            int i = 0;
            BackStackRecordState[] backStackRecordStateArr = null;
            if (!it2.hasNext()) {
                break;
            }
            FragmentStateManager fragmentStateManager = (FragmentStateManager) it2.next();
            if (fragmentStateManager != null) {
                Fragment fragment = fragmentStateManager.mFragment;
                FragmentState fragmentState = new FragmentState(fragment);
                Fragment fragment2 = fragmentStateManager.mFragment;
                if (fragment2.mState < 0 || fragmentState.mSavedFragmentState != null) {
                    fragmentState.mSavedFragmentState = fragment2.mSavedFragmentState;
                } else {
                    Bundle bundle;
                    Bundle bundle2 = new Bundle();
                    Fragment fragment3 = fragmentStateManager.mFragment;
                    fragment3.onSaveInstanceState(bundle2);
                    fragment3.mSavedStateRegistryController.performSave(bundle2);
                    Parcelable saveAllStateInternal = fragment3.mChildFragmentManager.saveAllStateInternal();
                    if (saveAllStateInternal != null) {
                        bundle2.putParcelable("android:support:fragments", saveAllStateInternal);
                    }
                    fragmentStateManager.mDispatcher.dispatchOnFragmentSaveInstanceState(fragmentStateManager.mFragment, bundle2, false);
                    if (true != bundle2.isEmpty()) {
                        bundle = bundle2;
                    }
                    if (fragmentStateManager.mFragment.mView != null) {
                        fragmentStateManager.saveViewState();
                    }
                    if (fragmentStateManager.mFragment.mSavedViewState != null) {
                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putSparseParcelableArray("android:view_state", fragmentStateManager.mFragment.mSavedViewState);
                    }
                    if (fragmentStateManager.mFragment.mSavedViewRegistryState != null) {
                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putBundle("android:view_registry_state", fragmentStateManager.mFragment.mSavedViewRegistryState);
                    }
                    if (!fragmentStateManager.mFragment.mUserVisibleHint) {
                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putBoolean("android:user_visible_hint", fragmentStateManager.mFragment.mUserVisibleHint);
                    }
                    fragmentState.mSavedFragmentState = bundle;
                    if (fragmentStateManager.mFragment.mTargetWho != null) {
                        if (fragmentState.mSavedFragmentState == null) {
                            fragmentState.mSavedFragmentState = new Bundle();
                        }
                        fragmentState.mSavedFragmentState.putString("android:target_state", fragmentStateManager.mFragment.mTargetWho);
                        i = fragmentStateManager.mFragment.mTargetRequestCode;
                        if (i != 0) {
                            fragmentState.mSavedFragmentState.putInt("android:target_req_state", i);
                        }
                    }
                }
                fragmentStateManager.mFragmentStore.setSavedState(fragmentStateManager.mFragment.mWho, fragmentState);
                arrayList.add(fragment.mWho);
                if (FragmentManager.isLoggingEnabled(2)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Saved state of ");
                    stringBuilder.append(fragment);
                    stringBuilder.append(": ");
                    stringBuilder.append(fragment.mSavedFragmentState);
                    Log.v("FragmentManager", stringBuilder.toString());
                }
            }
        }
        ArrayList arrayList2 = new ArrayList(this.mFragmentStore.mSavedState.values());
        if (arrayList2.isEmpty()) {
            if (FragmentManager.isLoggingEnabled(2)) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        ArrayList arrayList3;
        Parcelable fragmentManagerState;
        Fragment fragment4;
        FragmentStore fragmentStore2 = this.mFragmentStore;
        synchronized (fragmentStore2.mAdded) {
            if (fragmentStore2.mAdded.isEmpty()) {
                arrayList3 = null;
            } else {
                arrayList3 = new ArrayList(fragmentStore2.mAdded.size());
                it = fragmentStore2.mAdded.iterator();
                while (it.hasNext()) {
                    Fragment fragment5 = (Fragment) it.next();
                    arrayList3.add(fragment5.mWho);
                    if (FragmentManager.isLoggingEnabled(2)) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("saveAllState: adding fragment (");
                        stringBuilder2.append(fragment5.mWho);
                        stringBuilder2.append("): ");
                        stringBuilder2.append(fragment5);
                        Log.v("FragmentManager", stringBuilder2.toString());
                    }
                }
            }
        }
        ArrayList arrayList4 = this.mBackStack;
        if (arrayList4 != null) {
            int size = arrayList4.size();
            if (size > 0) {
                backStackRecordStateArr = new BackStackRecordState[size];
                while (i < size) {
                    backStackRecordStateArr[i] = new BackStackRecordState((BackStackRecord) this.mBackStack.get(i));
                    if (FragmentManager.isLoggingEnabled(2)) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("saveAllState: adding back stack #");
                        stringBuilder.append(i);
                        stringBuilder.append(": ");
                        stringBuilder.append(this.mBackStack.get(i));
                        Log.v("FragmentManager", stringBuilder.toString());
                    }
                    i++;
                }
                fragmentManagerState = new FragmentManagerState();
                fragmentManagerState.mSavedState = arrayList2;
                fragmentManagerState.mActive = arrayList;
                fragmentManagerState.mAdded = arrayList3;
                fragmentManagerState.mBackStack = backStackRecordStateArr;
                fragmentManagerState.mBackStackIndex = this.mBackStackIndex.get();
                fragment4 = this.mPrimaryNav;
                if (fragment4 != null) {
                    fragmentManagerState.mPrimaryNavActiveWho = fragment4.mWho;
                }
                fragmentManagerState.mBackStackStateKeys.addAll(this.mBackStackStates.keySet());
                fragmentManagerState.mBackStackStates.addAll(this.mBackStackStates.values());
                fragmentManagerState.mResultKeys.addAll(this.mResults.keySet());
                fragmentManagerState.mResults.addAll(this.mResults.values());
                fragmentManagerState.mLaunchedFragments = new ArrayList(this.mLaunchedFragments);
                return fragmentManagerState;
            }
        }
        fragmentManagerState = new FragmentManagerState();
        fragmentManagerState.mSavedState = arrayList2;
        fragmentManagerState.mActive = arrayList;
        fragmentManagerState.mAdded = arrayList3;
        fragmentManagerState.mBackStack = backStackRecordStateArr;
        fragmentManagerState.mBackStackIndex = this.mBackStackIndex.get();
        fragment4 = this.mPrimaryNav;
        if (fragment4 != null) {
            fragmentManagerState.mPrimaryNavActiveWho = fragment4.mWho;
        }
        fragmentManagerState.mBackStackStateKeys.addAll(this.mBackStackStates.keySet());
        fragmentManagerState.mBackStackStates.addAll(this.mBackStackStates.values());
        fragmentManagerState.mResultKeys.addAll(this.mResults.keySet());
        fragmentManagerState.mResults.addAll(this.mResults.values());
        fragmentManagerState.mLaunchedFragments = new ArrayList(this.mLaunchedFragments);
        return fragmentManagerState;
    }
}
