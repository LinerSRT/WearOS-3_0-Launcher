package android.support.p000v4.app;

import android.app.Notification;
import android.app.Notification.Action;
import android.app.Notification.Builder;
import android.app.RemoteInput;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.p000v4.graphics.drawable.IconCompat;
import android.text.TextUtils;
import androidx.core.app.Person;
import androidx.core.p003os.BuildCompat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationCompatBuilder */
final class NotificationCompatBuilder implements NotificationBuilderWithBuilderAccessor {
    public final Builder mBuilder;
    public final NotificationCompat$Builder mBuilderCompat;
    private final Bundle mExtras = new Bundle();

    public NotificationCompatBuilder(NotificationCompat$Builder notificationCompat$Builder) {
        NotificationCompat$Builder notificationCompat$Builder2 = notificationCompat$Builder;
        ArrayList arrayList = new ArrayList();
        this.mBuilderCompat = notificationCompat$Builder2;
        Builder builder = new Builder(notificationCompat$Builder2.mContext, notificationCompat$Builder2.mChannelId);
        this.mBuilder = builder;
        Notification notification = notificationCompat$Builder2.mNotification;
        Object obj = null;
        boolean z = true;
        int i = 0;
        Builder deleteIntent = builder.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, null).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(notificationCompat$Builder2.mContentTitle).setContentText(notificationCompat$Builder2.mContentText).setContentInfo(null).setContentIntent(notificationCompat$Builder2.mContentIntent).setDeleteIntent(notification.deleteIntent);
        if ((notification.flags & 128) == 0) {
            z = false;
        }
        deleteIntent.setFullScreenIntent(null, z).setLargeIcon(null).setNumber(0).setProgress(0, 0, false);
        builder.setSubText(notificationCompat$Builder2.mSubText).setUsesChronometer(notificationCompat$Builder2.mUseChronometer).setPriority(notificationCompat$Builder2.mPriority);
        List list = notificationCompat$Builder2.mActions;
        int size = list.size();
        int i2 = 0;
        while (true) {
            String str = "android.support.allowGeneratedReplies";
            if (i2 >= size) {
                break;
            }
            int resId;
            NotificationCompat$Action notificationCompat$Action = (NotificationCompat$Action) list.get(i2);
            IconCompat iconCompat = notificationCompat$Action.getIconCompat();
            Action.Builder builder2 = new Action.Builder(iconCompat != null ? iconCompat.toIcon() : null, notificationCompat$Action.title, notificationCompat$Action.actionIntent);
            RemoteInput[] remoteInputArr = notificationCompat$Action.mRemoteInputs;
            if (remoteInputArr != null) {
                for (RemoteInput addRemoteInput : RemoteInput.fromCompat(remoteInputArr)) {
                    builder2.addRemoteInput(addRemoteInput);
                }
            }
            Bundle bundle = new Bundle(notificationCompat$Action.mExtras);
            bundle.putBoolean(str, notificationCompat$Action.mAllowGeneratedReplies);
            builder2.setAllowGeneratedReplies(notificationCompat$Action.mAllowGeneratedReplies);
            bundle.putInt("android.support.action.semanticAction", notificationCompat$Action.mSemanticAction);
            builder2.setSemanticAction(notificationCompat$Action.mSemanticAction);
            builder2.setContextual(notificationCompat$Action.mIsContextual);
            bundle.putBoolean("android.support.action.showsUserInterface", notificationCompat$Action.mShowsUserInterface);
            builder2.addExtras(bundle);
            r0.mBuilder.addAction(builder2.build());
            i2++;
        }
        Bundle bundle2 = notificationCompat$Builder2.mExtras;
        if (bundle2 != null) {
            r0.mExtras.putAll(bundle2);
        }
        r0.mBuilder.setShowWhen(notificationCompat$Builder2.mShowWhen);
        r0.mBuilder.setLocalOnly(notificationCompat$Builder2.mLocalOnly).setGroup(null).setGroupSummary(false).setSortKey(null);
        r0.mBuilder.setCategory(notificationCompat$Builder2.mCategory).setColor(notificationCompat$Builder2.mColor).setVisibility(0).setPublicVersion(null).setSound(notification.sound, notification.audioAttributes);
        List<String> list2 = notificationCompat$Builder2.mPeople;
        if (!(list2 == null || list2.isEmpty())) {
            for (String addPerson : list2) {
                String addPerson2;
                r0.mBuilder.addPerson(addPerson2);
            }
        }
        if (notificationCompat$Builder2.mInvisibleActions.size() > 0) {
            addPerson2 = "android.car.EXTENSIONS";
            bundle2 = notificationCompat$Builder.getExtras().getBundle(addPerson2);
            if (bundle2 == null) {
                bundle2 = new Bundle();
            }
            Bundle bundle3 = new Bundle(bundle2);
            Bundle bundle4 = new Bundle();
            int i3 = 0;
            while (i3 < notificationCompat$Builder2.mInvisibleActions.size()) {
                Parcelable[] parcelableArr;
                String str2;
                String num = Integer.toString(i3);
                NotificationCompat$Action notificationCompat$Action2 = (NotificationCompat$Action) notificationCompat$Builder2.mInvisibleActions.get(i3);
                bundle = new Bundle();
                IconCompat iconCompat2 = notificationCompat$Action2.getIconCompat();
                if (iconCompat2 != null) {
                    resId = iconCompat2.getResId();
                } else {
                    resId = 0;
                }
                bundle.putInt("icon", resId);
                bundle.putCharSequence("title", notificationCompat$Action2.title);
                bundle.putParcelable("actionIntent", notificationCompat$Action2.actionIntent);
                Bundle bundle5 = new Bundle(notificationCompat$Action2.mExtras);
                bundle5.putBoolean(str, notificationCompat$Action2.mAllowGeneratedReplies);
                String str3 = "extras";
                bundle.putBundle(str3, bundle5);
                RemoteInput[] remoteInputArr2 = notificationCompat$Action2.mRemoteInputs;
                if (remoteInputArr2 == null) {
                    parcelableArr = obj;
                    str2 = str;
                } else {
                    parcelableArr = new Bundle[remoteInputArr2.length];
                    while (i < remoteInputArr2.length) {
                        RemoteInput remoteInput = remoteInputArr2[i];
                        str2 = str;
                        Bundle bundle6 = new Bundle();
                        RemoteInput[] remoteInputArr3 = remoteInputArr2;
                        bundle6.putString("resultKey", remoteInput.mResultKey);
                        bundle6.putCharSequence("label", remoteInput.mLabel);
                        bundle6.putCharSequenceArray("choices", remoteInput.mChoices);
                        bundle6.putBoolean("allowFreeFormInput", remoteInput.mAllowFreeFormTextInput);
                        bundle6.putBundle(str3, remoteInput.mExtras);
                        Set<String> set = remoteInput.mAllowedDataTypes;
                        if (!set.isEmpty()) {
                            ArrayList arrayList2 = new ArrayList(set.size());
                            for (String add : set) {
                                arrayList2.add(add);
                            }
                            bundle6.putStringArrayList("allowedDataTypes", arrayList2);
                        }
                        parcelableArr[i] = bundle6;
                        i++;
                        notificationCompat$Builder2 = notificationCompat$Builder;
                        str = str2;
                        remoteInputArr2 = remoteInputArr3;
                    }
                    str2 = str;
                }
                bundle.putParcelableArray("remoteInputs", parcelableArr);
                bundle.putBoolean("showsUserInterface", notificationCompat$Action2.mShowsUserInterface);
                bundle.putInt("semanticAction", notificationCompat$Action2.mSemanticAction);
                bundle4.putBundle(num, bundle);
                i3++;
                notificationCompat$Builder2 = notificationCompat$Builder;
                str = str2;
                obj = null;
                i = 0;
            }
            String str4 = "invisible_actions";
            bundle2.putBundle(str4, bundle4);
            bundle3.putBundle(str4, bundle4);
            notificationCompat$Builder.getExtras().putBundle(addPerson2, bundle2);
            r0.mExtras.putBundle(addPerson2, bundle3);
        }
        NotificationCompat$Builder notificationCompat$Builder3 = notificationCompat$Builder;
        r0.mBuilder.setExtras(notificationCompat$Builder3.mExtras).setRemoteInputHistory(null);
        r0.mBuilder.setBadgeIconType(0).setSettingsText(null).setShortcutId(null).setTimeoutAfter(0).setGroupAlertBehavior(0);
        if (!TextUtils.isEmpty(notificationCompat$Builder3.mChannelId)) {
            r0.mBuilder.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null);
        }
        List list3 = notificationCompat$Builder3.mPersonList;
        int size2 = list3.size();
        for (i = 0; i < size2; i++) {
            r0.mBuilder.addPerson(((Person) list3.get(i)).toAndroidPerson());
        }
        r0.mBuilder.setAllowSystemGeneratedContextualActions(notificationCompat$Builder3.mAllowSystemGeneratedContextualActions);
        r0.mBuilder.setBubbleMetadata(null);
        BuildCompat.isAtLeastS();
    }
}
