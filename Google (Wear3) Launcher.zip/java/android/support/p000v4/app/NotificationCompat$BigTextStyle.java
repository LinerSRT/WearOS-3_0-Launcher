package android.support.p000v4.app;

import android.app.Notification.BigTextStyle;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationCompat$BigTextStyle */
public final class NotificationCompat$BigTextStyle extends NotificationCompat$Style {
    public CharSequence mBigText;

    public final void apply(NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
        new BigTextStyle(((NotificationCompatBuilder) notificationBuilderWithBuilderAccessor).mBuilder).setBigContentTitle(null).bigText(this.mBigText);
    }

    protected final String getClassName() {
        return "android.support.v4.app.NotificationCompat$BigTextStyle";
    }
}
