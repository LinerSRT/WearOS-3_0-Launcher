package android.support.p000v4.app;

import android.graphics.Rect;
import android.support.p000v4.view.ViewCompat;
import android.support.v4.app.FragmentTransitionCompat21.C00702;
import android.support.v4.app.FragmentTransitionCompat21.C00724;
import android.support.v4.app.FragmentTransitionCompat21.C00735;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;
import android.transition.Transition.TransitionListener;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentTransitionCompat21 */
final class FragmentTransitionCompat21 extends FragmentTransitionImpl {

    /* renamed from: android.support.v4.app.FragmentTransitionCompat21$1 */
    final class PG extends EpicenterCallback {
        final /* synthetic */ Rect val$epicenter;

        public PG(Rect rect) {
            this.val$epicenter = rect;
        }

        public final Rect onGetEpicenter(Transition transition) {
            return this.val$epicenter;
        }
    }

    /* renamed from: android.support.v4.app.FragmentTransitionCompat21$2 */
    final class C00702 implements TransitionListener {
        final /* synthetic */ ArrayList val$exitingViews;
        final /* synthetic */ View val$fragmentView;

        public C00702(View view, ArrayList arrayList) {
            this.val$fragmentView = view;
            this.val$exitingViews = arrayList;
        }

        public final void onTransitionCancel(Transition transition) {
        }

        public final void onTransitionPause(Transition transition) {
        }

        public final void onTransitionResume(Transition transition) {
        }

        public final void onTransitionEnd(Transition transition) {
            transition.removeListener(this);
            this.val$fragmentView.setVisibility(8);
            int size = this.val$exitingViews.size();
            for (int i = 0; i < size; i++) {
                ((View) this.val$exitingViews.get(i)).setVisibility(0);
            }
        }

        public final void onTransitionStart(Transition transition) {
            transition.removeListener(this);
            transition.addListener(this);
        }
    }

    /* renamed from: android.support.v4.app.FragmentTransitionCompat21$4 */
    final class C00724 implements TransitionListener {
        final /* synthetic */ Runnable val$transitionCompleteRunnable;

        public C00724(Runnable runnable) {
            this.val$transitionCompleteRunnable = runnable;
        }

        public final void onTransitionCancel(Transition transition) {
        }

        public final void onTransitionEnd(Transition transition) {
            this.val$transitionCompleteRunnable.run();
        }

        public final void onTransitionPause(Transition transition) {
        }

        public final void onTransitionResume(Transition transition) {
        }

        public final void onTransitionStart(Transition transition) {
        }
    }

    /* renamed from: android.support.v4.app.FragmentTransitionCompat21$5 */
    final class C00735 extends EpicenterCallback {
        final /* synthetic */ Rect val$epicenter;

        public C00735(Rect rect) {
            this.val$epicenter = rect;
        }

        public final Rect onGetEpicenter(Transition transition) {
            return this.val$epicenter.isEmpty() ? null : this.val$epicenter;
        }
    }

    private static boolean hasSimpleTarget(Transition transition) {
        if (FragmentTransitionImpl.isNullOrEmpty(transition.getTargetIds()) && FragmentTransitionImpl.isNullOrEmpty(transition.getTargetNames())) {
            if (FragmentTransitionImpl.isNullOrEmpty(transition.getTargetTypes())) {
                return false;
            }
        }
        return true;
    }

    public final void addTarget(Object obj, View view) {
        ((Transition) obj).addTarget(view);
    }

    public final void addTargets(Object obj, ArrayList arrayList) {
        if (obj != null) {
            int i = 0;
            int transitionCount;
            if (obj instanceof TransitionSet) {
                TransitionSet transitionSet = (TransitionSet) obj;
                transitionCount = transitionSet.getTransitionCount();
                while (i < transitionCount) {
                    addTargets(transitionSet.getTransitionAt(i), arrayList);
                    i++;
                }
            } else {
                Transition transition = (Transition) obj;
                if (!FragmentTransitionCompat21.hasSimpleTarget(transition) && FragmentTransitionImpl.isNullOrEmpty(transition.getTargets())) {
                    transitionCount = arrayList.size();
                    while (i < transitionCount) {
                        transition.addTarget((View) arrayList.get(i));
                        i++;
                    }
                }
            }
        }
    }

    public final void beginDelayedTransition(ViewGroup viewGroup, Object obj) {
        TransitionManager.beginDelayedTransition(viewGroup, (Transition) obj);
    }

    public final boolean canHandle(Object obj) {
        return obj instanceof Transition;
    }

    public final Object cloneTransition(Object obj) {
        return obj != null ? ((Transition) obj).clone() : null;
    }

    public final Object mergeTransitionsInSequence$ar$ds(Object obj, Object obj2) {
        if (obj == null) {
            obj = null;
        }
        if (obj2 == null) {
            return obj;
        }
        TransitionSet transitionSet = new TransitionSet();
        if (obj != null) {
            transitionSet.addTransition((Transition) obj);
        }
        transitionSet.addTransition((Transition) obj2);
        return transitionSet;
    }

    public final Object mergeTransitionsTogether$ar$ds(Object obj, Object obj2) {
        TransitionSet transitionSet = new TransitionSet();
        if (obj != null) {
            transitionSet.addTransition((Transition) obj);
        }
        transitionSet.addTransition((Transition) obj2);
        return transitionSet;
    }

    public final void replaceTargets(Object obj, ArrayList arrayList, ArrayList arrayList2) {
        int i = 0;
        int transitionCount;
        if (obj instanceof TransitionSet) {
            TransitionSet transitionSet = (TransitionSet) obj;
            transitionCount = transitionSet.getTransitionCount();
            while (i < transitionCount) {
                replaceTargets(transitionSet.getTransitionAt(i), arrayList, arrayList2);
                i++;
            }
            return;
        }
        Transition transition = (Transition) obj;
        if (!FragmentTransitionCompat21.hasSimpleTarget(transition)) {
            List targets = transition.getTargets();
            if (targets != null && targets.size() == arrayList.size() && targets.containsAll(arrayList)) {
                if (arrayList2 == null) {
                    transitionCount = 0;
                } else {
                    transitionCount = arrayList2.size();
                }
                while (i < transitionCount) {
                    transition.addTarget((View) arrayList2.get(i));
                    i++;
                }
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    transition.removeTarget((View) arrayList.get(size));
                }
            }
        }
    }

    public final void scheduleHideFragmentView(Object obj, View view, ArrayList arrayList) {
        ((Transition) obj).addListener(new C00702(view, arrayList));
    }

    public final void scheduleRemoveTargets$ar$ds(Object obj, Object obj2, ArrayList arrayList, Object obj3, ArrayList arrayList2) {
        final Object obj4 = obj2;
        final ArrayList arrayList3 = arrayList;
        final Object obj5 = obj3;
        final ArrayList arrayList4 = arrayList2;
        ((Transition) obj).addListener(new TransitionListener() {
            public final void onTransitionCancel(Transition transition) {
            }

            public final void onTransitionPause(Transition transition) {
            }

            public final void onTransitionResume(Transition transition) {
            }

            public final void onTransitionStart(Transition transition) {
                Object obj = obj4;
                if (obj != null) {
                    android.support.p000v4.app.FragmentTransitionCompat21.this.replaceTargets(obj, arrayList3, null);
                }
                obj = obj5;
                if (obj != null) {
                    android.support.p000v4.app.FragmentTransitionCompat21.this.replaceTargets(obj, arrayList4, null);
                }
            }

            public final void onTransitionEnd(Transition transition) {
                transition.removeListener(this);
            }
        });
    }

    public final void setEpicenter(Object obj, Rect rect) {
        ((Transition) obj).setEpicenterCallback(new C00735(rect));
    }

    public final void setListenerForTransitionEnd$ar$ds(Object obj, Runnable runnable) {
        ((Transition) obj).addListener(new C00724(runnable));
    }

    public final void setSharedElementTargets(Object obj, View view, ArrayList arrayList) {
        List targets = ((TransitionSet) obj).getTargets();
        targets.clear();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            View view2 = (View) arrayList.get(i);
            int size2 = targets.size();
            if (!FragmentTransitionImpl.containedBeforeIndex(targets, view2, size2)) {
                if (ViewCompat.getTransitionName(view2) != null) {
                    targets.add(view2);
                }
                for (int i2 = size2; i2 < targets.size(); i2++) {
                    View view3 = (View) targets.get(i2);
                    if (view3 instanceof ViewGroup) {
                        ViewGroup viewGroup = (ViewGroup) view3;
                        int childCount = viewGroup.getChildCount();
                        for (int i3 = 0; i3 < childCount; i3++) {
                            View childAt = viewGroup.getChildAt(i3);
                            if (!(FragmentTransitionImpl.containedBeforeIndex(targets, childAt, size2) || ViewCompat.getTransitionName(childAt) == null)) {
                                targets.add(childAt);
                            }
                        }
                    }
                }
            }
        }
        targets.add(view);
        arrayList.add(view);
        addTargets(obj, arrayList);
    }

    public final void swapSharedElementTargets(Object obj, ArrayList arrayList, ArrayList arrayList2) {
        if (obj != null) {
            TransitionSet transitionSet = (TransitionSet) obj;
            transitionSet.getTargets().clear();
            transitionSet.getTargets().addAll(arrayList2);
            replaceTargets(obj, arrayList, arrayList2);
        }
    }

    public final Object wrapTransitionInSet(Object obj) {
        if (obj == null) {
            return null;
        }
        TransitionSet transitionSet = new TransitionSet();
        transitionSet.addTransition((Transition) obj);
        return transitionSet;
    }

    public final void setEpicenter(Object obj, View view) {
        if (view != null) {
            Rect rect = new Rect();
            FragmentTransitionImpl.getBoundsOnScreen$ar$ds(view, rect);
            ((Transition) obj).setEpicenterCallback(new PG(rect));
        }
    }
}
