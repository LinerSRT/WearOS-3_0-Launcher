package android.support.p000v4.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.support.p000v4.app.DefaultSpecialEffectsController.AnimationInfo;
import android.support.p000v4.app.DefaultSpecialEffectsController.TransitionInfo;
import android.support.p000v4.app.FragmentAnim.AnimationOrAnimator;
import android.support.p000v4.app.FragmentManager;
import android.support.p000v4.app.FragmentTransition;
import android.support.p000v4.app.FragmentTransitionImpl;
import android.support.p000v4.app.SpecialEffectsController.Operation;
import android.support.p000v4.app.SpecialEffectsController.Operation.State;
import android.support.p000v4.view.ViewCompat;
import android.support.v4.app.DefaultSpecialEffectsController.C00514;
import android.transition.Transition;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import androidx.collection.ArrayMap;
import androidx.core.p003os.CancellationSignal;
import androidx.core.p003os.CancellationSignal.OnCancelListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/* compiled from: PG */
/* renamed from: android.support.v4.app.DefaultSpecialEffectsController */
final class DefaultSpecialEffectsController extends SpecialEffectsController {

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$1 */
    final class PG implements Runnable {
        final /* synthetic */ List val$awaitingContainerChanges;
        final /* synthetic */ Operation val$operation;

        public PG(List list, Operation operation) {
            this.val$awaitingContainerChanges = list;
            this.val$operation = operation;
        }

        public final void run() {
            if (this.val$awaitingContainerChanges.contains(this.val$operation)) {
                this.val$awaitingContainerChanges.remove(this.val$operation);
                DefaultSpecialEffectsController.applyContainerChanges$ar$ds(this.val$operation);
            }
        }
    }

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$2 */
    final class C00492 extends AnimatorListenerAdapter {
        final /* synthetic */ AnimationInfo val$animationInfo;
        final /* synthetic */ ViewGroup val$container;
        final /* synthetic */ boolean val$isHideOperation;
        final /* synthetic */ Operation val$operation;
        final /* synthetic */ View val$viewToAnimate;

        public C00492(ViewGroup viewGroup, View view, boolean z, Operation operation, AnimationInfo animationInfo) {
            this.val$container = viewGroup;
            this.val$viewToAnimate = view;
            this.val$isHideOperation = z;
            this.val$operation = operation;
            this.val$animationInfo = animationInfo;
        }

        public final void onAnimationEnd(Animator animator) {
            this.val$container.endViewTransition(this.val$viewToAnimate);
            if (this.val$isHideOperation) {
                State.applyState$ar$edu(this.val$operation.mFinalState$ar$edu, this.val$viewToAnimate);
            }
            this.val$animationInfo.completeSpecialEffect();
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Animator from operation ");
                stringBuilder.append(this.val$operation);
                stringBuilder.append(" has ended.");
                Log.v("FragmentManager", stringBuilder.toString());
            }
        }
    }

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$3 */
    final class C00503 implements OnCancelListener {
        final /* synthetic */ Animator val$animator;
        final /* synthetic */ Operation val$operation;

        public C00503(Animator animator, Operation operation) {
            this.val$animator = animator;
            this.val$operation = operation;
        }

        public final void onCancel() {
            this.val$animator.end();
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Animator from operation ");
                stringBuilder.append(this.val$operation);
                stringBuilder.append(" has been canceled.");
                Log.v("FragmentManager", stringBuilder.toString());
            }
        }
    }

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$4 */
    final class C00514 implements AnimationListener {
        final /* synthetic */ AnimationInfo val$animationInfo;
        final /* synthetic */ ViewGroup val$container;
        final /* synthetic */ Operation val$operation;
        final /* synthetic */ View val$viewToAnimate;

        /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$4$1 */
        final class PG implements Runnable {
            public final void run() {
                C00514 c00514 = C00514.this;
                c00514.val$container.endViewTransition(c00514.val$viewToAnimate);
                C00514.this.val$animationInfo.completeSpecialEffect();
            }
        }

        public C00514(Operation operation, ViewGroup viewGroup, View view, AnimationInfo animationInfo) {
            this.val$operation = operation;
            this.val$container = viewGroup;
            this.val$viewToAnimate = view;
            this.val$animationInfo = animationInfo;
        }

        public final void onAnimationEnd(Animation animation) {
            this.val$container.post(new android.support.p000v4.app.DefaultSpecialEffectsController.PG.PG());
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Animation from operation ");
                stringBuilder.append(this.val$operation);
                stringBuilder.append(" has ended.");
                Log.v("FragmentManager", stringBuilder.toString());
            }
        }

        public final void onAnimationRepeat(Animation animation) {
        }

        public final void onAnimationStart(Animation animation) {
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Animation from operation ");
                stringBuilder.append(this.val$operation);
                stringBuilder.append(" has reached onAnimationStart.");
                Log.v("FragmentManager", stringBuilder.toString());
            }
        }
    }

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$5 */
    final class C00525 implements OnCancelListener {
        final /* synthetic */ AnimationInfo val$animationInfo;
        final /* synthetic */ ViewGroup val$container;
        final /* synthetic */ Operation val$operation;
        final /* synthetic */ View val$viewToAnimate;

        public C00525(View view, ViewGroup viewGroup, AnimationInfo animationInfo, Operation operation) {
            this.val$viewToAnimate = view;
            this.val$container = viewGroup;
            this.val$animationInfo = animationInfo;
            this.val$operation = operation;
        }

        public final void onCancel() {
            this.val$viewToAnimate.clearAnimation();
            this.val$container.endViewTransition(this.val$viewToAnimate);
            this.val$animationInfo.completeSpecialEffect();
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Animation from operation ");
                stringBuilder.append(this.val$operation);
                stringBuilder.append(" has been cancelled.");
                Log.v("FragmentManager", stringBuilder.toString());
            }
        }
    }

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$6 */
    final class C00536 implements Runnable {
        final /* synthetic */ Operation val$firstOut;
        final /* synthetic */ boolean val$isPop;
        final /* synthetic */ Operation val$lastIn;

        public C00536(Operation operation, Operation operation2, boolean z) {
            this.val$lastIn = operation;
            this.val$firstOut = operation2;
            this.val$isPop = z;
        }

        public final void run() {
            FragmentTransition.callSharedElementStartEnd$ar$ds(this.val$lastIn.mFragment, this.val$firstOut.mFragment, this.val$isPop);
        }
    }

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$7 */
    final class C00547 implements Runnable {
        final /* synthetic */ Rect val$lastInEpicenterRect;
        final /* synthetic */ View val$lastInEpicenterView;

        public C00547(View view, Rect rect) {
            this.val$lastInEpicenterView = view;
            this.val$lastInEpicenterRect = rect;
        }

        public final void run() {
            FragmentTransitionImpl.getBoundsOnScreen$ar$ds(this.val$lastInEpicenterView, this.val$lastInEpicenterRect);
        }
    }

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$8 */
    final class C00558 implements Runnable {
        final /* synthetic */ ArrayList val$transitioningViews;

        public C00558(ArrayList arrayList) {
            this.val$transitioningViews = arrayList;
        }

        public final void run() {
            FragmentTransition.setViewVisibility(this.val$transitioningViews, 4);
        }
    }

    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$9 */
    final class C00569 implements Runnable {
        final /* synthetic */ Operation val$operation;
        final /* synthetic */ TransitionInfo val$transitionInfo;

        public C00569(TransitionInfo transitionInfo, Operation operation) {
            this.val$transitionInfo = transitionInfo;
            this.val$operation = operation;
        }

        public final void run() {
            this.val$transitionInfo.completeSpecialEffect();
            if (FragmentManager.isLoggingEnabled(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Transition for operation ");
                stringBuilder.append(this.val$operation);
                stringBuilder.append("has completed");
                Log.v("FragmentManager", stringBuilder.toString());
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$AnimationInfo */
    final class AnimationInfo extends SpecialEffectsInfo {
        private AnimationOrAnimator mAnimation;
        private final boolean mIsPop;
        private boolean mLoadedAnim = false;

        public AnimationInfo(Operation operation, CancellationSignal cancellationSignal, boolean z) {
            super(operation, cancellationSignal);
            this.mIsPop = z;
        }

        final AnimationOrAnimator getAnimation(Context context) {
            if (this.mLoadedAnim) {
                return this.mAnimation;
            }
            Operation operation = this.mOperation;
            AnimationOrAnimator loadAnimation = FragmentAnim.loadAnimation(context, operation.mFragment, operation.mFinalState$ar$edu == 2, this.mIsPop);
            this.mAnimation = loadAnimation;
            this.mLoadedAnim = true;
            return loadAnimation;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$SpecialEffectsInfo */
    class SpecialEffectsInfo {
        public final Operation mOperation;
        public final CancellationSignal mSignal;

        public SpecialEffectsInfo(Operation operation, CancellationSignal cancellationSignal) {
            this.mOperation = operation;
            this.mSignal = cancellationSignal;
        }

        final boolean isVisibilityUnchanged() {
            int from$ar$edu$b2310ebe_0 = State.from$ar$edu$b2310ebe_0(this.mOperation.mFragment.mView);
            int i = this.mOperation.mFinalState$ar$edu;
            boolean z = false;
            if (from$ar$edu$b2310ebe_0 != i) {
                if (from$ar$edu$b2310ebe_0 != 2) {
                    if (i == 2) {
                        return false;
                    }
                }
                return z;
            }
            z = true;
            return z;
        }

        final void completeSpecialEffect() {
            Operation operation = this.mOperation;
            if (operation.mSpecialEffectsSignals.remove(this.mSignal) && operation.mSpecialEffectsSignals.isEmpty()) {
                operation.complete();
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.DefaultSpecialEffectsController$TransitionInfo */
    final class TransitionInfo extends SpecialEffectsInfo {
        public final boolean mOverlapAllowed;
        public final Object mSharedElementTransition;
        public final Object mTransition;

        public TransitionInfo(Operation operation, CancellationSignal cancellationSignal, boolean z, boolean z2) {
            Fragment.AnimationInfo animationInfo;
            super(operation, cancellationSignal);
            Object obj = null;
            Fragment fragment;
            Fragment.AnimationInfo animationInfo2;
            Object obj2;
            if (operation.mFinalState$ar$edu == 2) {
                if (z) {
                    fragment = operation.mFragment;
                    animationInfo2 = fragment.mAnimationInfo;
                    if (animationInfo2 == null) {
                        obj2 = null;
                    } else if (animationInfo2.mReenterTransition == Fragment.USE_DEFAULT_TRANSITION) {
                        fragment.getExitTransition$ar$ds();
                        obj2 = null;
                    } else {
                        obj2 = fragment.mAnimationInfo.mReenterTransition;
                    }
                } else {
                    obj2 = operation.mFragment.getEnterTransition();
                }
                this.mTransition = obj2;
                if (z) {
                    animationInfo = operation.mFragment.mAnimationInfo;
                } else {
                    animationInfo = operation.mFragment.mAnimationInfo;
                }
                this.mOverlapAllowed = true;
            } else {
                if (z) {
                    fragment = operation.mFragment;
                    animationInfo2 = fragment.mAnimationInfo;
                    if (animationInfo2 == null) {
                        obj2 = null;
                    } else if (animationInfo2.mReturnTransition == Fragment.USE_DEFAULT_TRANSITION) {
                        obj2 = fragment.getEnterTransition();
                    } else {
                        obj2 = fragment.mAnimationInfo.mReturnTransition;
                    }
                } else {
                    operation.mFragment.getExitTransition$ar$ds();
                    obj2 = null;
                }
                this.mTransition = obj2;
                this.mOverlapAllowed = true;
            }
            if (z2) {
                if (z) {
                    Fragment fragment2 = operation.mFragment;
                    animationInfo = fragment2.mAnimationInfo;
                    if (animationInfo != null) {
                        if (animationInfo.mSharedElementReturnTransition == Fragment.USE_DEFAULT_TRANSITION) {
                            fragment2.getSharedElementEnterTransition$ar$ds();
                        } else {
                            obj = fragment2.mAnimationInfo.mSharedElementReturnTransition;
                        }
                    }
                    this.mSharedElementTransition = obj;
                    return;
                }
                operation.mFragment.getSharedElementEnterTransition$ar$ds();
            }
            this.mSharedElementTransition = null;
        }

        public final FragmentTransitionImpl getHandlingImpl(Object obj) {
            if (obj == null) {
                return null;
            }
            int i = FragmentTransition.FragmentTransition$ar$NoOp;
            if (obj instanceof Transition) {
                return FragmentTransition.PLATFORM_IMPL;
            }
            if (FragmentTransition.SUPPORT_IMPL != null && FragmentTransition.SUPPORT_IMPL.canHandle(obj)) {
                return FragmentTransition.SUPPORT_IMPL;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Transition ");
            stringBuilder.append(obj);
            stringBuilder.append(" for fragment ");
            stringBuilder.append(this.mOperation.mFragment);
            stringBuilder.append(" is not a valid framework Transition or AndroidX Transition");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
    }

    public DefaultSpecialEffectsController(ViewGroup viewGroup) {
        super(viewGroup);
    }

    static final void applyContainerChanges$ar$ds(Operation operation) {
        State.applyState$ar$edu(operation.mFinalState$ar$edu, operation.mFragment.mView);
    }

    static final void retainMatchingViews$ar$ds(ArrayMap arrayMap, Collection collection) {
        Iterator it = arrayMap.entrySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(ViewCompat.getTransitionName((View) ((Entry) it.next()).getValue()))) {
                it.remove();
            }
        }
    }

    final void captureTransitioningViews(ArrayList arrayList, View view) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            if (!viewGroup.isTransitionGroup()) {
                int childCount = viewGroup.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View childAt = viewGroup.getChildAt(i);
                    if (childAt.getVisibility() == 0) {
                        captureTransitioningViews(arrayList, childAt);
                    }
                }
            } else if (!arrayList.contains(view)) {
                arrayList.add(viewGroup);
            }
        } else if (!arrayList.contains(view)) {
            arrayList.add(view);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void executeOperations(java.util.List r34, boolean r35) {
        /*
        r33 = this;
        r0 = r33;
        r1 = r35;
        r2 = r34.iterator();
        r3 = 0;
        r4 = r3;
        r5 = r4;
    L_0x000b:
        r6 = r2.hasNext();
        r7 = 2;
        if (r6 == 0) goto L_0x0037;
    L_0x0012:
        r6 = r2.next();
        r6 = (android.support.p000v4.app.SpecialEffectsController.Operation) r6;
        r8 = r6.mFragment;
        r8 = r8.mView;
        r8 = android.support.p000v4.app.SpecialEffectsController.Operation.State.from$ar$edu$b2310ebe_0(r8);
        r9 = r6.mFinalState$ar$edu;
        r10 = r9 + -1;
        if (r9 == 0) goto L_0x0035;
    L_0x0026:
        switch(r10) {
            case 0: goto L_0x002f;
            case 1: goto L_0x002a;
            case 2: goto L_0x002f;
            case 3: goto L_0x002f;
            default: goto L_0x0029;
        };
    L_0x0029:
        goto L_0x000b;
    L_0x002a:
        if (r8 != r7) goto L_0x002d;
    L_0x002c:
        goto L_0x0029;
    L_0x002d:
        r5 = r6;
        goto L_0x000b;
    L_0x002f:
        if (r8 != r7) goto L_0x0029;
    L_0x0031:
        if (r4 != 0) goto L_0x0029;
    L_0x0033:
        r4 = r6;
        goto L_0x000b;
        throw r3;
        r2 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r7);
        r6 = " to ";
        r8 = "FragmentManager";
        if (r2 == 0) goto L_0x005c;
    L_0x0042:
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r9 = "Executing operations from ";
        r2.append(r9);
        r2.append(r4);
        r2.append(r6);
        r2.append(r5);
        r2 = r2.toString();
        android.util.Log.v(r8, r2);
    L_0x005c:
        r2 = new java.util.ArrayList;
        r2.<init>();
        r9 = new java.util.ArrayList;
        r9.<init>();
        r10 = new java.util.ArrayList;
        r11 = r34;
        r10.<init>(r11);
        r11 = r34.iterator();
    L_0x0071:
        r12 = r11.hasNext();
        if (r12 == 0) goto L_0x00b2;
    L_0x0077:
        r12 = r11.next();
        r12 = (android.support.p000v4.app.SpecialEffectsController.Operation) r12;
        r15 = new androidx.core.os.CancellationSignal;
        r15.<init>();
        r12.markStartedSpecialEffect(r15);
        r3 = new android.support.v4.app.DefaultSpecialEffectsController$AnimationInfo;
        r3.<init>(r12, r15, r1);
        r2.add(r3);
        r3 = new androidx.core.os.CancellationSignal;
        r3.<init>();
        r12.markStartedSpecialEffect(r3);
        r15 = new android.support.v4.app.DefaultSpecialEffectsController$TransitionInfo;
        if (r1 == 0) goto L_0x009d;
    L_0x0099:
        if (r12 != r4) goto L_0x00a1;
    L_0x009b:
        r13 = 1;
        goto L_0x00a2;
    L_0x009d:
        if (r12 != r5) goto L_0x00a1;
    L_0x009f:
        r13 = 1;
        goto L_0x00a2;
    L_0x00a1:
        r13 = 0;
    L_0x00a2:
        r15.<init>(r12, r3, r1, r13);
        r9.add(r15);
        r3 = new android.support.v4.app.DefaultSpecialEffectsController$1;
        r3.<init>(r10, r12);
        r12.addCompletionListener(r3);
        r3 = 0;
        goto L_0x0071;
    L_0x00b2:
        r3 = new java.util.HashMap;
        r3.<init>();
        r11 = r9.iterator();
        r12 = 0;
    L_0x00bc:
        r15 = r11.hasNext();
        if (r15 == 0) goto L_0x014e;
    L_0x00c2:
        r15 = r11.next();
        r15 = (android.support.p000v4.app.DefaultSpecialEffectsController.TransitionInfo) r15;
        r17 = r15.isVisibilityUnchanged();
        if (r17 != 0) goto L_0x0147;
    L_0x00ce:
        r13 = r15.mTransition;
        r13 = r15.getHandlingImpl(r13);
        r7 = r15.mSharedElementTransition;
        r7 = r15.getHandlingImpl(r7);
        r14 = " returned Transition ";
        r17 = r11;
        r11 = "Mixing framework transitions and AndroidX transitions is not allowed. Fragment ";
        if (r13 == 0) goto L_0x0112;
    L_0x00e2:
        if (r7 == 0) goto L_0x0112;
    L_0x00e4:
        if (r13 != r7) goto L_0x00e7;
    L_0x00e6:
        goto L_0x0112;
    L_0x00e7:
        r1 = new java.lang.IllegalArgumentException;
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r2.append(r11);
        r3 = r15.mOperation;
        r3 = r3.mFragment;
        r2.append(r3);
        r2.append(r14);
        r3 = r15.mTransition;
        r2.append(r3);
        r3 = " which uses a different Transition  type than its shared element transition ";
        r2.append(r3);
        r3 = r15.mSharedElementTransition;
        r2.append(r3);
        r2 = r2.toString();
        r1.<init>(r2);
        throw r1;
    L_0x0112:
        if (r13 != 0) goto L_0x0115;
    L_0x0114:
        r13 = r7;
    L_0x0115:
        if (r12 != 0) goto L_0x011c;
    L_0x0117:
        r12 = r13;
        r11 = r17;
        r7 = 2;
        goto L_0x00bc;
    L_0x011c:
        if (r13 == 0) goto L_0x0149;
    L_0x011e:
        if (r12 != r13) goto L_0x0121;
    L_0x0120:
        goto L_0x0149;
    L_0x0121:
        r1 = new java.lang.IllegalArgumentException;
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r2.append(r11);
        r3 = r15.mOperation;
        r3 = r3.mFragment;
        r2.append(r3);
        r2.append(r14);
        r3 = r15.mTransition;
        r2.append(r3);
        r3 = " which uses a different Transition  type than other Fragments.";
        r2.append(r3);
        r2 = r2.toString();
        r1.<init>(r2);
        throw r1;
    L_0x0147:
        r17 = r11;
    L_0x0149:
        r11 = r17;
        r7 = 2;
        goto L_0x00bc;
    L_0x014e:
        if (r12 != 0) goto L_0x017e;
    L_0x0150:
        r1 = r9.iterator();
    L_0x0154:
        r9 = r1.hasNext();
        if (r9 == 0) goto L_0x016e;
    L_0x015a:
        r9 = r1.next();
        r9 = (android.support.p000v4.app.DefaultSpecialEffectsController.TransitionInfo) r9;
        r11 = r9.mOperation;
        r12 = 0;
        r13 = java.lang.Boolean.valueOf(r12);
        r3.put(r11, r13);
        r9.completeSpecialEffect();
        goto L_0x0154;
    L_0x016e:
        r26 = r2;
        r9 = r3;
        r24 = r4;
        r31 = r5;
        r25 = r6;
        r30 = r8;
        r28 = r10;
        r3 = 0;
        goto L_0x0663;
    L_0x017e:
        r11 = new android.view.View;
        r13 = r0.mContainer;
        r13 = r13.getContext();
        r11.<init>(r13);
        r13 = new android.graphics.Rect;
        r13.<init>();
        r14 = new java.util.ArrayList;
        r14.<init>();
        r15 = new java.util.ArrayList;
        r15.<init>();
        r7 = new androidx.collection.ArrayMap;
        r7.<init>();
        r23 = r9.iterator();
        r26 = r2;
        r25 = r6;
        r2 = 0;
        r6 = 0;
        r24 = 0;
    L_0x01a9:
        r17 = r23.hasNext();
        if (r17 == 0) goto L_0x0393;
    L_0x01af:
        r17 = r23.next();
        r27 = r6;
        r6 = r17;
        r6 = (android.support.p000v4.app.DefaultSpecialEffectsController.TransitionInfo) r6;
        r6 = r6.mSharedElementTransition;
        if (r6 == 0) goto L_0x0381;
    L_0x01bd:
        if (r4 == 0) goto L_0x0381;
    L_0x01bf:
        if (r5 == 0) goto L_0x0381;
    L_0x01c1:
        r2 = r12.cloneTransition(r6);
        r2 = r12.wrapTransitionInSet(r2);
        r6 = r5.mFragment;
        r6 = r6.getSharedElementSourceNames();
        r28 = r10;
        r10 = r4.mFragment;
        r10 = r10.getSharedElementSourceNames();
        r29 = r9;
        r9 = r4.mFragment;
        r9 = r9.getSharedElementTargetNames();
        r30 = r3;
        r3 = 0;
    L_0x01e2:
        r31 = r11;
        r11 = r9.size();
        if (r3 >= r11) goto L_0x0207;
    L_0x01ea:
        r11 = r9.get(r3);
        r11 = r6.indexOf(r11);
        r17 = r9;
        r9 = -1;
        if (r11 == r9) goto L_0x0200;
    L_0x01f7:
        r9 = r10.get(r3);
        r9 = (java.lang.String) r9;
        r6.set(r11, r9);
    L_0x0200:
        r3 = r3 + 1;
        r9 = r17;
        r11 = r31;
        goto L_0x01e2;
    L_0x0207:
        r3 = r5.mFragment;
        r3 = r3.getSharedElementTargetNames();
        if (r1 != 0) goto L_0x021a;
    L_0x020f:
        r9 = r4.mFragment;
        r9.getExitTransitionCallback$ar$ds();
        r9 = r5.mFragment;
        r9.getEnterTransitionCallback$ar$ds();
        goto L_0x0224;
    L_0x021a:
        r9 = r4.mFragment;
        r9.getEnterTransitionCallback$ar$ds();
        r9 = r5.mFragment;
        r9.getExitTransitionCallback$ar$ds();
    L_0x0224:
        r9 = r6.size();
        r10 = 0;
    L_0x0229:
        if (r10 >= r9) goto L_0x0243;
    L_0x022b:
        r11 = r6.get(r10);
        r11 = (java.lang.String) r11;
        r17 = r3.get(r10);
        r18 = r9;
        r9 = r17;
        r9 = (java.lang.String) r9;
        r7.put(r11, r9);
        r10 = r10 + 1;
        r9 = r18;
        goto L_0x0229;
        r9 = 2;
        r10 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r10 == 0) goto L_0x02ab;
    L_0x024b:
        r9 = ">>> entering view names <<<";
        android.util.Log.v(r8, r9);
        r9 = r3.size();
        r10 = 0;
    L_0x0255:
        r11 = "Name: ";
        if (r10 >= r9) goto L_0x027e;
    L_0x0259:
        r17 = r3.get(r10);
        r18 = r9;
        r9 = r17;
        r9 = (java.lang.String) r9;
        r32 = r13;
        r13 = new java.lang.StringBuilder;
        r13.<init>();
        r13.append(r11);
        r13.append(r9);
        r9 = r13.toString();
        android.util.Log.v(r8, r9);
        r10 = r10 + 1;
        r9 = r18;
        r13 = r32;
        goto L_0x0255;
    L_0x027e:
        r32 = r13;
        r9 = ">>> exiting view names <<<";
        android.util.Log.v(r8, r9);
        r9 = r6.size();
        r10 = 0;
    L_0x028a:
        if (r10 >= r9) goto L_0x02ad;
    L_0x028c:
        r13 = r6.get(r10);
        r13 = (java.lang.String) r13;
        r17 = r9;
        r9 = new java.lang.StringBuilder;
        r9.<init>();
        r9.append(r11);
        r9.append(r13);
        r9 = r9.toString();
        android.util.Log.v(r8, r9);
        r10 = r10 + 1;
        r9 = r17;
        goto L_0x028a;
    L_0x02ab:
        r32 = r13;
    L_0x02ad:
        r9 = new androidx.collection.ArrayMap;
        r9.<init>();
        r10 = r4.mFragment;
        r10 = r10.mView;
        r0.findNamedViews(r9, r10);
        r9.retainAll(r6);
        r10 = r9.keySet();
        r7.retainAll(r10);
        r10 = new androidx.collection.ArrayMap;
        r10.<init>();
        r11 = r5.mFragment;
        r11 = r11.mView;
        r0.findNamedViews(r10, r11);
        r10.retainAll(r3);
        r11 = r7.values();
        r10.retainAll(r11);
        android.support.p000v4.app.FragmentTransition.retainValues(r7, r10);
        r11 = r7.keySet();
        android.support.p000v4.app.DefaultSpecialEffectsController.retainMatchingViews$ar$ds(r9, r11);
        r11 = r7.values();
        android.support.p000v4.app.DefaultSpecialEffectsController.retainMatchingViews$ar$ds(r10, r11);
        r11 = r7.isEmpty();
        if (r11 == 0) goto L_0x0301;
    L_0x02f0:
        r14.clear();
        r15.clear();
        r6 = r27;
        r9 = r30;
        r3 = r31;
        r11 = r32;
        r2 = 0;
        goto L_0x038a;
    L_0x0301:
        r11 = r5.mFragment;
        r13 = r4.mFragment;
        android.support.p000v4.app.FragmentTransition.callSharedElementStartEnd$ar$ds(r11, r13, r1);
        r11 = r0.mContainer;
        r13 = new android.support.v4.app.DefaultSpecialEffectsController$6;
        r13.<init>(r5, r4, r1);
        android.support.p000v4.view.OneShotPreDrawListener.add$ar$ds$e2022eb2_0(r11, r13);
        r11 = r9.values();
        r14.addAll(r11);
        r11 = r6.isEmpty();
        if (r11 != 0) goto L_0x0330;
    L_0x031f:
        r11 = 0;
        r6 = r6.get(r11);
        r6 = (java.lang.String) r6;
        r6 = r9.get(r6);
        r6 = (android.view.View) r6;
        r12.setEpicenter(r2, r6);
        goto L_0x0332;
    L_0x0330:
        r6 = r27;
    L_0x0332:
        r9 = r10.values();
        r15.addAll(r9);
        r9 = r3.isEmpty();
        if (r9 != 0) goto L_0x035d;
    L_0x033f:
        r9 = 0;
        r3 = r3.get(r9);
        r3 = (java.lang.String) r3;
        r3 = r10.get(r3);
        r3 = (android.view.View) r3;
        if (r3 == 0) goto L_0x035d;
    L_0x034e:
        r9 = r0.mContainer;
        r10 = new android.support.v4.app.DefaultSpecialEffectsController$7;
        r11 = r32;
        r10.<init>(r3, r11);
        android.support.p000v4.view.OneShotPreDrawListener.add$ar$ds$e2022eb2_0(r9, r10);
        r24 = 1;
        goto L_0x035f;
    L_0x035d:
        r11 = r32;
    L_0x035f:
        r3 = r31;
        r12.setSharedElementTargets(r2, r3, r14);
        r19 = 0;
        r20 = 0;
        r17 = r12;
        r18 = r2;
        r21 = r2;
        r22 = r15;
        r17.scheduleRemoveTargets$ar$ds(r18, r19, r20, r21, r22);
        r9 = 1;
        r10 = java.lang.Boolean.valueOf(r9);
        r9 = r30;
        r9.put(r4, r10);
        r9.put(r5, r10);
        goto L_0x038a;
    L_0x0381:
        r29 = r9;
        r28 = r10;
        r9 = r3;
        r3 = r11;
        r11 = r13;
        r6 = r27;
    L_0x038a:
        r13 = r11;
        r10 = r28;
        r11 = r3;
        r3 = r9;
        r9 = r29;
        goto L_0x01a9;
    L_0x0393:
        r27 = r6;
        r29 = r9;
        r28 = r10;
        r9 = r3;
        r3 = r11;
        r11 = r13;
        r1 = new java.util.ArrayList;
        r1.<init>();
        r6 = r29.iterator();
        r10 = 0;
    L_0x03a6:
        r13 = r6.hasNext();
        if (r13 == 0) goto L_0x0499;
    L_0x03ac:
        r13 = r6.next();
        r13 = (android.support.p000v4.app.DefaultSpecialEffectsController.TransitionInfo) r13;
        r17 = r13.isVisibilityUnchanged();
        if (r17 == 0) goto L_0x03cd;
    L_0x03b8:
        r35 = r6;
        r6 = r13.mOperation;
        r23 = r7;
        r17 = 0;
        r7 = java.lang.Boolean.valueOf(r17);
        r9.put(r6, r7);
        r13.completeSpecialEffect();
        r30 = r8;
        goto L_0x03fb;
    L_0x03cd:
        r35 = r6;
        r23 = r7;
        r6 = r13.mTransition;
        r6 = r12.cloneTransition(r6);
        r7 = r13.mOperation;
        if (r2 == 0) goto L_0x03e5;
    L_0x03db:
        if (r7 == r4) goto L_0x03e2;
    L_0x03dd:
        if (r7 != r5) goto L_0x03e5;
    L_0x03df:
        r17 = 1;
        goto L_0x03e7;
    L_0x03e2:
        r17 = 1;
        goto L_0x03e7;
    L_0x03e5:
        r17 = 0;
    L_0x03e7:
        if (r6 != 0) goto L_0x0402;
    L_0x03e9:
        if (r17 != 0) goto L_0x03f9;
    L_0x03eb:
        r30 = r8;
        r6 = 0;
        r8 = java.lang.Boolean.valueOf(r6);
        r9.put(r7, r8);
        r13.completeSpecialEffect();
        goto L_0x03fb;
    L_0x03f9:
        r30 = r8;
    L_0x03fb:
        r6 = r35;
        r7 = r23;
        r8 = r30;
        goto L_0x03a6;
    L_0x0402:
        r30 = r8;
        r8 = new java.util.ArrayList;
        r8.<init>();
        r31 = r5;
        r5 = r7.mFragment;
        r5 = r5.mView;
        r0.captureTransitioningViews(r8, r5);
        if (r17 == 0) goto L_0x041d;
    L_0x0414:
        if (r7 != r4) goto L_0x041a;
    L_0x0416:
        r8.removeAll(r14);
        goto L_0x041d;
    L_0x041a:
        r8.removeAll(r15);
    L_0x041d:
        r5 = r8.isEmpty();
        if (r5 == 0) goto L_0x0429;
    L_0x0423:
        r12.addTarget(r6, r3);
        r17 = r3;
        goto L_0x0464;
    L_0x0429:
        r12.addTargets(r6, r8);
        r21 = 0;
        r22 = 0;
        r17 = r12;
        r18 = r6;
        r19 = r6;
        r20 = r8;
        r17.scheduleRemoveTargets$ar$ds(r18, r19, r20, r21, r22);
        r5 = r7.mFinalState$ar$edu;
        r17 = r3;
        r3 = 3;
        if (r5 != r3) goto L_0x0464;
    L_0x0442:
        r3 = r28;
        r3.remove(r7);
        r5 = new java.util.ArrayList;
        r5.<init>(r8);
        r3 = r7.mFragment;
        r3 = r3.mView;
        r5.remove(r3);
        r3 = r7.mFragment;
        r3 = r3.mView;
        r12.scheduleHideFragmentView(r6, r3, r5);
        r3 = r0.mContainer;
        r5 = new android.support.v4.app.DefaultSpecialEffectsController$8;
        r5.<init>(r8);
        android.support.p000v4.view.OneShotPreDrawListener.add$ar$ds$e2022eb2_0(r3, r5);
    L_0x0464:
        r3 = r7.mFinalState$ar$edu;
        r5 = 2;
        if (r3 != r5) goto L_0x0477;
    L_0x0469:
        r1.addAll(r8);
        if (r24 == 0) goto L_0x0474;
    L_0x046e:
        r12.setEpicenter(r6, r11);
        r3 = r27;
        goto L_0x047c;
    L_0x0474:
        r3 = r27;
        goto L_0x047c;
    L_0x0477:
        r3 = r27;
        r12.setEpicenter(r6, r3);
        r5 = 1;
        r8 = java.lang.Boolean.valueOf(r5);
        r9.put(r7, r8);
        r5 = r13.mOverlapAllowed;
        r10 = r12.mergeTransitionsTogether$ar$ds(r10, r6);
        r6 = r35;
        r27 = r3;
        r3 = r17;
        r7 = r23;
        r8 = r30;
        r5 = r31;
        goto L_0x03a6;
    L_0x0499:
        r31 = r5;
        r23 = r7;
        r30 = r8;
        r3 = r12.mergeTransitionsInSequence$ar$ds(r10, r2);
        r5 = r29.iterator();
    L_0x04a7:
        r6 = r5.hasNext();
        if (r6 == 0) goto L_0x0529;
    L_0x04ad:
        r6 = r5.next();
        r6 = (android.support.p000v4.app.DefaultSpecialEffectsController.TransitionInfo) r6;
        r7 = r6.isVisibilityUnchanged();
        if (r7 != 0) goto L_0x0523;
    L_0x04b9:
        r7 = r6.mTransition;
        r8 = r6.mOperation;
        if (r2 == 0) goto L_0x04cb;
    L_0x04bf:
        if (r8 == r4) goto L_0x04c7;
    L_0x04c1:
        r10 = r31;
        if (r8 != r10) goto L_0x04cd;
    L_0x04c5:
        r11 = 1;
        goto L_0x04ce;
    L_0x04c7:
        r10 = r31;
        r11 = 1;
        goto L_0x04ce;
    L_0x04cb:
        r10 = r31;
    L_0x04cd:
        r11 = 0;
    L_0x04ce:
        if (r7 != 0) goto L_0x04d6;
    L_0x04d0:
        if (r11 == 0) goto L_0x04d3;
    L_0x04d2:
        goto L_0x04d6;
    L_0x04d3:
        r31 = r10;
        goto L_0x04a7;
    L_0x04d6:
        r7 = r0.mContainer;
        r7 = android.support.p000v4.view.ViewCompat.isLaidOut(r7);
        if (r7 != 0) goto L_0x0510;
    L_0x04de:
        r7 = 2;
        r11 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r7);
        if (r11 == 0) goto L_0x0506;
    L_0x04e5:
        r7 = new java.lang.StringBuilder;
        r7.<init>();
        r11 = "SpecialEffectsController: Container ";
        r7.append(r11);
        r11 = r0.mContainer;
        r7.append(r11);
        r11 = " has not been laid out. Completing operation ";
        r7.append(r11);
        r7.append(r8);
        r7 = r7.toString();
        r11 = r30;
        android.util.Log.v(r11, r7);
        goto L_0x0508;
    L_0x0506:
        r11 = r30;
    L_0x0508:
        r6.completeSpecialEffect();
        r31 = r10;
        r30 = r11;
        goto L_0x04a7;
    L_0x0510:
        r11 = r30;
        r7 = r6.mOperation;
        r7 = r7.mFragment;
        r7 = r6.mSignal;
        r7 = new android.support.v4.app.DefaultSpecialEffectsController$9;
        r7.<init>(r6, r8);
        r12.setListenerForTransitionEnd$ar$ds(r3, r7);
        r31 = r10;
        goto L_0x04a7;
    L_0x0523:
        r11 = r30;
        r10 = r31;
        goto L_0x04a7;
    L_0x0529:
        r11 = r30;
        r10 = r31;
        r5 = r0.mContainer;
        r5 = android.support.p000v4.view.ViewCompat.isLaidOut(r5);
        if (r5 == 0) goto L_0x065c;
    L_0x0535:
        r5 = 4;
        android.support.p000v4.app.FragmentTransition.setViewVisibility(r1, r5);
        r5 = new java.util.ArrayList;
        r5.<init>();
        r6 = r15.size();
        r7 = 0;
    L_0x0543:
        if (r7 >= r6) goto L_0x0559;
    L_0x0545:
        r8 = r15.get(r7);
        r8 = (android.view.View) r8;
        r13 = android.support.p000v4.view.ViewCompat.getTransitionName(r8);
        r5.add(r13);
        r13 = 0;
        android.support.p000v4.view.ViewCompat.setTransitionName(r8, r13);
        r7 = r7 + 1;
        goto L_0x0543;
        r6 = 2;
        r7 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r6);
        if (r7 == 0) goto L_0x05dc;
    L_0x0561:
        r6 = ">>>>> Beginning transition <<<<<";
        android.util.Log.v(r11, r6);
        r6 = ">>>>> SharedElementFirstOutViews <<<<<";
        android.util.Log.v(r11, r6);
        r6 = r14.size();
        r7 = 0;
    L_0x0570:
        r8 = " Name: ";
        r13 = "View: ";
        if (r7 >= r6) goto L_0x05a5;
    L_0x0576:
        r17 = r14.get(r7);
        r35 = r6;
        r6 = r17;
        r6 = (android.view.View) r6;
        r31 = r10;
        r10 = new java.lang.StringBuilder;
        r10.<init>();
        r10.append(r13);
        r10.append(r6);
        r10.append(r8);
        r6 = android.support.p000v4.view.ViewCompat.getTransitionName(r6);
        r10.append(r6);
        r6 = r10.toString();
        android.util.Log.v(r11, r6);
        r7 = r7 + 1;
        r6 = r35;
        r10 = r31;
        goto L_0x0570;
    L_0x05a5:
        r31 = r10;
        r6 = ">>>>> SharedElementLastInViews <<<<<";
        android.util.Log.v(r11, r6);
        r6 = r15.size();
        r7 = 0;
    L_0x05b1:
        if (r7 >= r6) goto L_0x05de;
    L_0x05b3:
        r10 = r15.get(r7);
        r10 = (android.view.View) r10;
        r35 = r6;
        r6 = new java.lang.StringBuilder;
        r6.<init>();
        r6.append(r13);
        r6.append(r10);
        r6.append(r8);
        r10 = android.support.p000v4.view.ViewCompat.getTransitionName(r10);
        r6.append(r10);
        r6 = r6.toString();
        android.util.Log.v(r11, r6);
        r7 = r7 + 1;
        r6 = r35;
        goto L_0x05b1;
    L_0x05dc:
        r31 = r10;
    L_0x05de:
        r6 = r0.mContainer;
        r12.beginDelayedTransition(r6, r3);
        r3 = r0.mContainer;
        r6 = r15.size();
        r7 = new java.util.ArrayList;
        r7.<init>();
        r8 = 0;
    L_0x05ef:
        if (r8 >= r6) goto L_0x063c;
    L_0x05f1:
        r10 = r14.get(r8);
        r10 = (android.view.View) r10;
        r13 = android.support.p000v4.view.ViewCompat.getTransitionName(r10);
        r7.add(r13);
        if (r13 != 0) goto L_0x0605;
    L_0x0600:
        r24 = r4;
        r30 = r11;
        goto L_0x0635;
    L_0x0605:
        r24 = r4;
        r4 = 0;
        android.support.p000v4.view.ViewCompat.setTransitionName(r10, r4);
        r10 = r23;
        r16 = r10.get(r13);
        r4 = r16;
        r4 = (java.lang.String) r4;
        r10 = 0;
    L_0x0616:
        if (r10 >= r6) goto L_0x0633;
    L_0x0618:
        r30 = r11;
        r11 = r5.get(r10);
        r11 = r4.equals(r11);
        if (r11 == 0) goto L_0x062e;
    L_0x0624:
        r4 = r15.get(r10);
        r4 = (android.view.View) r4;
        android.support.p000v4.view.ViewCompat.setTransitionName(r4, r13);
        goto L_0x0635;
    L_0x062e:
        r10 = r10 + 1;
        r11 = r30;
        goto L_0x0616;
    L_0x0633:
        r30 = r11;
    L_0x0635:
        r8 = r8 + 1;
        r4 = r24;
        r11 = r30;
        goto L_0x05ef;
    L_0x063c:
        r24 = r4;
        r30 = r11;
        r4 = new android.support.v4.app.FragmentTransitionImpl$1;
        r17 = r4;
        r18 = r6;
        r19 = r15;
        r20 = r5;
        r21 = r14;
        r22 = r7;
        r17.<init>(r18, r19, r20, r21, r22);
        android.support.p000v4.view.OneShotPreDrawListener.add$ar$ds$e2022eb2_0(r3, r4);
        r3 = 0;
        android.support.p000v4.app.FragmentTransition.setViewVisibility(r1, r3);
        r12.swapSharedElementTargets(r2, r14, r15);
        goto L_0x0663;
    L_0x065c:
        r24 = r4;
        r31 = r10;
        r30 = r11;
        r3 = 0;
        r1 = 1;
        r2 = java.lang.Boolean.valueOf(r1);
        r1 = r9.containsValue(r2);
        r2 = r0.mContainer;
        r4 = r2.getContext();
        r5 = new java.util.ArrayList;
        r5.<init>();
        r6 = r26.iterator();
        r12 = 0;
    L_0x067d:
        r7 = r6.hasNext();
        r8 = " has started.";
        if (r7 == 0) goto L_0x075d;
    L_0x0685:
        r7 = r6.next();
        r7 = (android.support.p000v4.app.DefaultSpecialEffectsController.AnimationInfo) r7;
        r10 = r7.isVisibilityUnchanged();
        if (r10 == 0) goto L_0x0697;
    L_0x0691:
        r7.completeSpecialEffect();
        r13 = r30;
        goto L_0x06e5;
    L_0x0697:
        r10 = r7.getAnimation(r4);
        if (r10 != 0) goto L_0x06a3;
    L_0x069d:
        r7.completeSpecialEffect();
        r13 = r30;
        goto L_0x06e5;
    L_0x06a3:
        r15 = r10.animator;
        if (r15 != 0) goto L_0x06ad;
    L_0x06a7:
        r5.add(r7);
        r13 = r30;
        goto L_0x06e5;
    L_0x06ad:
        r14 = r7.mOperation;
        r10 = r14.mFragment;
        r11 = java.lang.Boolean.TRUE;
        r13 = r9.get(r14);
        r11 = r11.equals(r13);
        if (r11 == 0) goto L_0x06e8;
    L_0x06bd:
        r8 = 2;
        r11 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r8);
        if (r11 == 0) goto L_0x06e0;
    L_0x06c4:
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r11 = "Ignoring Animator set on ";
        r8.append(r11);
        r8.append(r10);
        r10 = " as this Fragment was involved in a Transition.";
        r8.append(r10);
        r8 = r8.toString();
        r13 = r30;
        android.util.Log.v(r13, r8);
        goto L_0x06e2;
    L_0x06e0:
        r13 = r30;
    L_0x06e2:
        r7.completeSpecialEffect();
    L_0x06e5:
        r30 = r13;
        goto L_0x067d;
    L_0x06e8:
        r13 = r30;
        r11 = r14.mFinalState$ar$edu;
        r12 = 3;
        if (r11 != r12) goto L_0x06f2;
    L_0x06ef:
        r16 = 1;
        goto L_0x06f4;
    L_0x06f2:
        r16 = 0;
    L_0x06f4:
        if (r16 == 0) goto L_0x06fc;
    L_0x06f6:
        r11 = r28;
        r11.remove(r14);
        goto L_0x06fe;
    L_0x06fc:
        r11 = r28;
    L_0x06fe:
        r10 = r10.mView;
        r2.startViewTransition(r10);
        r3 = new android.support.v4.app.DefaultSpecialEffectsController$2;
        r35 = r10;
        r10 = r3;
        r28 = r11;
        r11 = r2;
        r17 = 3;
        r12 = r35;
        r0 = r13;
        r13 = r16;
        r16 = r14;
        r18 = r6;
        r6 = r15;
        r15 = r7;
        r10.<init>(r11, r12, r13, r14, r15);
        r6.addListener(r3);
        r3 = r35;
        r6.setTarget(r3);
        r6.start();
        r3 = 2;
        r10 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r3);
        if (r10 == 0) goto L_0x0747;
    L_0x072d:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r10 = "Animator from operation ";
        r3.append(r10);
        r10 = r16;
        r3.append(r10);
        r3.append(r8);
        r3 = r3.toString();
        android.util.Log.v(r0, r3);
        goto L_0x0749;
    L_0x0747:
        r10 = r16;
    L_0x0749:
        r3 = r7.mSignal;
        r7 = new android.support.v4.app.DefaultSpecialEffectsController$3;
        r7.<init>(r6, r10);
        r3.setOnCancelListener(r7);
        r30 = r0;
        r6 = r18;
        r3 = 0;
        r12 = 1;
        r0 = r33;
        goto L_0x067d;
    L_0x075d:
        r0 = r30;
        r3 = r5.size();
        r6 = 0;
    L_0x0764:
        if (r6 >= r3) goto L_0x0816;
    L_0x0766:
        r7 = r5.get(r6);
        r7 = (android.support.p000v4.app.DefaultSpecialEffectsController.AnimationInfo) r7;
        r9 = r7.mOperation;
        r10 = r9.mFragment;
        r11 = "Ignoring Animation set on ";
        if (r1 == 0) goto L_0x0798;
    L_0x0774:
        r9 = 2;
        r13 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r13 == 0) goto L_0x0792;
    L_0x077b:
        r9 = new java.lang.StringBuilder;
        r9.<init>();
        r9.append(r11);
        r9.append(r10);
        r10 = " as Animations cannot run alongside Transitions.";
        r9.append(r10);
        r9 = r9.toString();
        android.util.Log.v(r0, r9);
    L_0x0792:
        r7.completeSpecialEffect();
        r14 = 1;
        goto L_0x0812;
    L_0x0798:
        if (r12 == 0) goto L_0x07bd;
    L_0x079a:
        r9 = 2;
        r13 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r9);
        if (r13 == 0) goto L_0x07b8;
    L_0x07a1:
        r9 = new java.lang.StringBuilder;
        r9.<init>();
        r9.append(r11);
        r9.append(r10);
        r10 = " as Animations cannot run alongside Animators.";
        r9.append(r10);
        r9 = r9.toString();
        android.util.Log.v(r0, r9);
    L_0x07b8:
        r7.completeSpecialEffect();
        r14 = 1;
        goto L_0x0812;
    L_0x07bd:
        r10 = r10.mView;
        r11 = r7.getAnimation(r4);
        android.support.p000v4.util.Preconditions.checkNotNull$ar$ds(r11);
        r11 = r11.animation;
        android.support.p000v4.util.Preconditions.checkNotNull$ar$ds(r11);
        r13 = r9.mFinalState$ar$edu;
        r14 = 1;
        if (r13 == r14) goto L_0x07d7;
    L_0x07d0:
        r10.startAnimation(r11);
        r7.completeSpecialEffect();
        goto L_0x0808;
    L_0x07d7:
        r2.startViewTransition(r10);
        r13 = new android.support.v4.app.FragmentAnim$EndViewTransitionAnimation;
        r13.<init>(r11, r2, r10);
        r11 = new android.support.v4.app.DefaultSpecialEffectsController$4;
        r11.<init>(r9, r2, r10, r7);
        r13.setAnimationListener(r11);
        r10.startAnimation(r13);
        r11 = 2;
        r13 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r11);
        if (r13 == 0) goto L_0x0808;
    L_0x07f1:
        r11 = new java.lang.StringBuilder;
        r11.<init>();
        r13 = "Animation from operation ";
        r11.append(r13);
        r11.append(r9);
        r11.append(r8);
        r11 = r11.toString();
        android.util.Log.v(r0, r11);
    L_0x0808:
        r11 = r7.mSignal;
        r13 = new android.support.v4.app.DefaultSpecialEffectsController$5;
        r13.<init>(r10, r2, r7, r9);
        r11.setOnCancelListener(r13);
    L_0x0812:
        r6 = r6 + 1;
        goto L_0x0764;
    L_0x0816:
        r1 = r28.size();
        r14 = 0;
    L_0x081b:
        if (r14 >= r1) goto L_0x082b;
    L_0x081d:
        r2 = r28;
        r3 = r2.get(r14);
        r3 = (android.support.p000v4.app.SpecialEffectsController.Operation) r3;
        android.support.p000v4.app.DefaultSpecialEffectsController.applyContainerChanges$ar$ds(r3);
        r14 = r14 + 1;
        goto L_0x081b;
    L_0x082b:
        r2 = r28;
        r2.clear();
        r1 = 2;
        r1 = android.support.p000v4.app.FragmentManager.isLoggingEnabled(r1);
        if (r1 == 0) goto L_0x0857;
    L_0x0837:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Completed executing operations from ";
        r1.append(r2);
        r3 = r24;
        r1.append(r3);
        r2 = r25;
        r1.append(r2);
        r3 = r31;
        r1.append(r3);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x0857:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.DefaultSpecialEffectsController.executeOperations(java.util.List, boolean):void");
    }

    final void findNamedViews(Map map, View view) {
        String transitionName = ViewCompat.getTransitionName(view);
        if (transitionName != null) {
            map.put(transitionName, view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = viewGroup.getChildAt(i);
                if (childAt.getVisibility() == 0) {
                    findNamedViews(map, childAt);
                }
            }
        }
    }
}
