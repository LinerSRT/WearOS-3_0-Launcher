package android.support.p000v4.app;

import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationCompat$WearableExtender */
public final class NotificationCompat$WearableExtender {
    public ArrayList mActions = new ArrayList();
    public int mContentActionIndex = -1;
    public int mContentIconGravity = 8388613;
    public int mFlags = 1;
    public int mGravity = 80;
    public ArrayList mPages = new ArrayList();

    public final /* bridge */ /* synthetic */ Object clone() {
        NotificationCompat$WearableExtender notificationCompat$WearableExtender = new NotificationCompat$WearableExtender();
        notificationCompat$WearableExtender.mActions = new ArrayList(this.mActions);
        notificationCompat$WearableExtender.mFlags = this.mFlags;
        notificationCompat$WearableExtender.mPages = new ArrayList(this.mPages);
        notificationCompat$WearableExtender.mContentIconGravity = this.mContentIconGravity;
        notificationCompat$WearableExtender.mContentActionIndex = this.mContentActionIndex;
        notificationCompat$WearableExtender.mGravity = this.mGravity;
        return notificationCompat$WearableExtender;
    }
}
