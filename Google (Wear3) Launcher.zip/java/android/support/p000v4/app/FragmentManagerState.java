package android.support.p000v4.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p000v4.app.FragmentManager.LaunchedFragmentInfo;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentManagerState */
final class FragmentManagerState implements Parcelable {
    public static final Creator CREATOR = new PG();
    ArrayList mActive;
    ArrayList mAdded;
    BackStackRecordState[] mBackStack;
    int mBackStackIndex;
    ArrayList mBackStackStateKeys = new ArrayList();
    ArrayList mBackStackStates = new ArrayList();
    ArrayList mLaunchedFragments;
    String mPrimaryNavActiveWho = null;
    ArrayList mResultKeys = new ArrayList();
    ArrayList mResults = new ArrayList();
    ArrayList mSavedState;

    /* renamed from: android.support.v4.app.FragmentManagerState$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new FragmentManagerState[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new FragmentManagerState(parcel);
        }
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(this.mSavedState);
        parcel.writeStringList(this.mActive);
        parcel.writeStringList(this.mAdded);
        parcel.writeTypedArray(this.mBackStack, i);
        parcel.writeInt(this.mBackStackIndex);
        parcel.writeString(this.mPrimaryNavActiveWho);
        parcel.writeStringList(this.mBackStackStateKeys);
        parcel.writeTypedList(this.mBackStackStates);
        parcel.writeStringList(this.mResultKeys);
        parcel.writeTypedList(this.mResults);
        parcel.writeTypedList(this.mLaunchedFragments);
    }

    public FragmentManagerState(Parcel parcel) {
        this.mSavedState = parcel.createTypedArrayList(FragmentState.CREATOR);
        this.mActive = parcel.createStringArrayList();
        this.mAdded = parcel.createStringArrayList();
        this.mBackStack = (BackStackRecordState[]) parcel.createTypedArray(BackStackRecordState.CREATOR);
        this.mBackStackIndex = parcel.readInt();
        this.mPrimaryNavActiveWho = parcel.readString();
        this.mBackStackStateKeys = parcel.createStringArrayList();
        this.mBackStackStates = parcel.createTypedArrayList(BackStackState.CREATOR);
        this.mResultKeys = parcel.createStringArrayList();
        this.mResults = parcel.createTypedArrayList(Bundle.CREATOR);
        this.mLaunchedFragments = parcel.createTypedArrayList(LaunchedFragmentInfo.CREATOR);
    }
}
