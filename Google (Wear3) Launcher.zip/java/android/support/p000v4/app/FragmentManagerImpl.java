package android.support.p000v4.app;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentManagerImpl */
final class FragmentManagerImpl extends FragmentManager {
}
