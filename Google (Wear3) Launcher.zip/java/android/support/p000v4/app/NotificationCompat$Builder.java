package android.support.p000v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationCompat$Builder */
public final class NotificationCompat$Builder {
    public ArrayList mActions;
    boolean mAllowSystemGeneratedContextualActions;
    public String mCategory;
    public String mChannelId;
    public int mColor;
    public PendingIntent mContentIntent;
    CharSequence mContentText;
    CharSequence mContentTitle;
    public Context mContext;
    public Bundle mExtras;
    ArrayList mInvisibleActions;
    boolean mLocalOnly;
    public Notification mNotification;
    @Deprecated
    public ArrayList mPeople;
    public ArrayList mPersonList;
    public int mPriority;
    public boolean mShowWhen;
    NotificationCompat$Style mStyle;
    public CharSequence mSubText;
    public boolean mUseChronometer;

    @Deprecated
    public NotificationCompat$Builder(Context context) {
        this(context, null);
    }

    public static CharSequence limitCharSequenceLength(CharSequence charSequence) {
        if (charSequence == null) {
            return null;
        }
        if (charSequence.length() > 5120) {
            charSequence = charSequence.subSequence(0, 5120);
        }
        return charSequence;
    }

    public final void addAction$ar$ds(NotificationCompat$Action notificationCompat$Action) {
        if (notificationCompat$Action != null) {
            this.mActions.add(notificationCompat$Action);
        }
    }

    public final Notification build() {
        Object notificationCompatBuilder = new NotificationCompatBuilder(this);
        NotificationCompat$Style notificationCompat$Style = notificationCompatBuilder.mBuilderCompat.mStyle;
        if (notificationCompat$Style != null) {
            notificationCompat$Style.apply(notificationCompatBuilder);
        }
        Notification build = notificationCompatBuilder.mBuilder.build();
        if (notificationCompat$Style != null) {
            Bundle bundle = build.extras;
            if (bundle != null) {
                bundle.putString("android.support.v4.app.extra.COMPAT_TEMPLATE", notificationCompat$Style.getClassName());
            }
        }
        return build;
    }

    public final Bundle getExtras() {
        if (this.mExtras == null) {
            this.mExtras = new Bundle();
        }
        return this.mExtras;
    }

    public final void setAutoCancel$ar$ds(boolean z) {
        setFlag(16, z);
    }

    public final void setContentText$ar$ds(CharSequence charSequence) {
        this.mContentText = NotificationCompat$Builder.limitCharSequenceLength(charSequence);
    }

    public final void setContentTitle$ar$ds(CharSequence charSequence) {
        this.mContentTitle = NotificationCompat$Builder.limitCharSequenceLength(charSequence);
    }

    public final void setDeleteIntent$ar$ds(PendingIntent pendingIntent) {
        this.mNotification.deleteIntent = pendingIntent;
    }

    public final void setFlag(int i, boolean z) {
        if (z) {
            Notification notification = this.mNotification;
            notification.flags = i | notification.flags;
            return;
        }
        notification = this.mNotification;
        notification.flags = (i ^ -1) & notification.flags;
    }

    public final void setLocalOnly$ar$ds() {
        this.mLocalOnly = true;
    }

    public final void setSmallIcon$ar$ds(int i) {
        this.mNotification.icon = i;
    }

    public final void setTicker$ar$ds(CharSequence charSequence) {
        this.mNotification.tickerText = NotificationCompat$Builder.limitCharSequenceLength(charSequence);
    }

    public final void setWhen$ar$ds(long j) {
        this.mNotification.when = j;
    }

    public NotificationCompat$Builder(Context context, String str) {
        this.mActions = new ArrayList();
        this.mPersonList = new ArrayList();
        this.mInvisibleActions = new ArrayList();
        this.mShowWhen = true;
        this.mLocalOnly = false;
        this.mColor = 0;
        Notification notification = new Notification();
        this.mNotification = notification;
        this.mContext = context;
        this.mChannelId = str;
        notification.when = System.currentTimeMillis();
        this.mNotification.audioStreamType = -1;
        this.mPriority = 0;
        this.mPeople = new ArrayList();
        this.mAllowSystemGeneratedContextualActions = true;
    }

    public final void setStyle$ar$ds(NotificationCompat$Style notificationCompat$Style) {
        if (this.mStyle != notificationCompat$Style) {
            this.mStyle = notificationCompat$Style;
            if (notificationCompat$Style != null && notificationCompat$Style.mBuilder != this) {
                notificationCompat$Style.mBuilder = this;
                NotificationCompat$Builder notificationCompat$Builder = notificationCompat$Style.mBuilder;
                if (notificationCompat$Builder != null) {
                    notificationCompat$Builder.setStyle$ar$ds(notificationCompat$Style);
                }
            }
        }
    }
}
