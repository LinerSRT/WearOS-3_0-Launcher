package android.support.p000v4.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.View;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentHostCallback */
public class FragmentHostCallback extends FragmentContainer {
    public final Activity mActivity;
    public final Context mContext;
    final FragmentManager mFragmentManager = new FragmentManagerImpl();
    public final Handler mHandler;

    public FragmentHostCallback(Activity activity, Context context, Handler handler) {
        this.mActivity = activity;
        this.mContext = context;
        this.mHandler = handler;
    }

    public View onFindViewById(int i) {
        throw null;
    }

    public boolean onHasView() {
        throw null;
    }
}
