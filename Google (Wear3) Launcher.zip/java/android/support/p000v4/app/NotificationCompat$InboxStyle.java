package android.support.p000v4.app;

import android.app.Notification.InboxStyle;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationCompat$InboxStyle */
public final class NotificationCompat$InboxStyle extends NotificationCompat$Style {
    public final ArrayList mTexts = new ArrayList();

    public final void apply(NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
        InboxStyle bigContentTitle = new InboxStyle(((NotificationCompatBuilder) notificationBuilderWithBuilderAccessor).mBuilder).setBigContentTitle(null);
        List list = this.mTexts;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            bigContentTitle.addLine((CharSequence) list.get(i));
        }
    }

    protected final String getClassName() {
        return "android.support.v4.app.NotificationCompat$InboxStyle";
    }
}
