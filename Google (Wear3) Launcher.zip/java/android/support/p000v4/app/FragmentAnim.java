package android.support.p000v4.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.support.p000v4.app.Fragment.AnimationInfo;
import android.support.p000v4.view.OneShotPreDrawListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentAnim */
final class FragmentAnim {

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.FragmentAnim$AnimationOrAnimator */
    final class AnimationOrAnimator {
        public final Animation animation;
        public final Animator animator;

        public AnimationOrAnimator(Animator animator) {
            this.animation = null;
            this.animator = animator;
        }

        public AnimationOrAnimator(Animation animation) {
            this.animation = animation;
            this.animator = null;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.FragmentAnim$EndViewTransitionAnimation */
    final class EndViewTransitionAnimation extends AnimationSet implements Runnable {
        private boolean mAnimating = true;
        private final View mChild;
        private boolean mEnded;
        private final ViewGroup mParent;
        private boolean mTransitionEnded;

        public EndViewTransitionAnimation(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.mParent = viewGroup;
            this.mChild = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        public final boolean getTransformation(long j, Transformation transformation) {
            this.mAnimating = true;
            if (this.mEnded) {
                return !this.mTransitionEnded;
            } else {
                if (!super.getTransformation(j, transformation)) {
                    this.mEnded = true;
                    OneShotPreDrawListener.add$ar$ds$e2022eb2_0(this.mParent, this);
                }
                return true;
            }
        }

        public final void run() {
            if (this.mEnded || !this.mAnimating) {
                this.mParent.endViewTransition(this.mChild);
                this.mTransitionEnded = true;
                return;
            }
            this.mAnimating = false;
            this.mParent.post(this);
        }

        public final boolean getTransformation(long j, Transformation transformation, float f) {
            this.mAnimating = true;
            if (this.mEnded) {
                return !this.mTransitionEnded;
            } else {
                if (!super.getTransformation(j, transformation, f)) {
                    this.mEnded = true;
                    OneShotPreDrawListener.add$ar$ds$e2022eb2_0(this.mParent, this);
                }
                return true;
            }
        }
    }

    private static int toActivityTransitResId(Context context, int i) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(16973825, new int[]{i});
        i = obtainStyledAttributes.getResourceId(0, -1);
        obtainStyledAttributes.recycle();
        return i;
    }

    static AnimationOrAnimator loadAnimation(Context context, Fragment fragment, boolean z, boolean z2) {
        int i;
        int popEnterAnim;
        AnimationInfo animationInfo = fragment.mAnimationInfo;
        int i2 = 0;
        if (animationInfo == null) {
            i = 0;
        } else {
            i = animationInfo.mNextTransition;
        }
        if (z2) {
            if (z) {
                popEnterAnim = fragment.getPopEnterAnim();
            } else {
                popEnterAnim = fragment.getPopExitAnim();
            }
        } else if (z) {
            popEnterAnim = fragment.getEnterAnim();
        } else {
            popEnterAnim = fragment.getExitAnim();
        }
        fragment.setAnimations(0, 0, 0, 0);
        ViewGroup viewGroup = fragment.mContainer;
        if (!(viewGroup == null || viewGroup.getTag(R.id.visible_removing_fragment_view_tag) == null)) {
            fragment.mContainer.setTag(R.id.visible_removing_fragment_view_tag, null);
        }
        ViewGroup viewGroup2 = fragment.mContainer;
        if (viewGroup2 != null) {
            if (viewGroup2.getLayoutTransition() != null) {
                return null;
            }
        }
        if (popEnterAnim != 0) {
            i2 = popEnterAnim;
        } else if (i != 0) {
            switch (i) {
                case 4097:
                    if (true == z) {
                        i2 = R.animator.fragment_open_enter;
                        break;
                    }
                    i2 = R.animator.fragment_open_exit;
                    break;
                case 4099:
                    if (true == z) {
                        i2 = R.animator.fragment_fade_enter;
                        break;
                    }
                    i2 = R.animator.fragment_fade_exit;
                    break;
                case 4100:
                    if (!z) {
                        i2 = FragmentAnim.toActivityTransitResId(context, 16842937);
                        break;
                    }
                    i2 = FragmentAnim.toActivityTransitResId(context, 16842936);
                    break;
                case 8194:
                    if (true == z) {
                        i2 = R.animator.fragment_close_enter;
                        break;
                    }
                    i2 = R.animator.fragment_close_exit;
                    break;
                case 8197:
                    if (!z) {
                        i2 = FragmentAnim.toActivityTransitResId(context, 16842939);
                        break;
                    }
                    i2 = FragmentAnim.toActivityTransitResId(context, 16842938);
                    break;
                default:
                    i2 = -1;
                    break;
            }
        }
        if (i2 != 0) {
            boolean equals = "anim".equals(context.getResources().getResourceTypeName(i2));
            if (equals) {
                try {
                    Animation loadAnimation = AnimationUtils.loadAnimation(context, i2);
                    if (loadAnimation != null) {
                        return new AnimationOrAnimator(loadAnimation);
                    }
                } catch (NotFoundException e) {
                    throw e;
                } catch (RuntimeException e2) {
                }
            }
            try {
                Animator loadAnimator = AnimatorInflater.loadAnimator(context, i2);
                if (loadAnimator != null) {
                    return new AnimationOrAnimator(loadAnimator);
                }
            } catch (RuntimeException e3) {
                if (equals) {
                    throw e3;
                }
                Animation loadAnimation2 = AnimationUtils.loadAnimation(context, i2);
                if (loadAnimation2 != null) {
                    return new AnimationOrAnimator(loadAnimation2);
                }
            }
        }
        return null;
    }
}
