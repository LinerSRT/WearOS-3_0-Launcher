package android.support.p000v4.app;

import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.p000v4.graphics.drawable.IconCompat;
import android.support.p000v4.util.Preconditions;
import androidx.core.app.Person;
import androidx.core.app.Person.Builder;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationCompat$MessagingStyle$Message */
public final class NotificationCompat$MessagingStyle$Message {
    public String mDataMimeType;
    public Uri mDataUri;
    private final Bundle mExtras = new Bundle();
    public final Person mPerson;
    public final CharSequence mText;
    public final long mTimestamp;

    public NotificationCompat$MessagingStyle$Message(CharSequence charSequence, long j, Person person) {
        this.mText = charSequence;
        this.mTimestamp = j;
        this.mPerson = person;
    }

    static Bundle[] getBundleArrayForMessages(List list) {
        Bundle[] bundleArr = new Bundle[list.size()];
        int size = list.size();
        for (int i = 0; i < size; i++) {
            NotificationCompat$MessagingStyle$Message notificationCompat$MessagingStyle$Message = (NotificationCompat$MessagingStyle$Message) list.get(i);
            Bundle bundle = new Bundle();
            CharSequence charSequence = notificationCompat$MessagingStyle$Message.mText;
            if (charSequence != null) {
                bundle.putCharSequence("text", charSequence);
            }
            bundle.putLong("time", notificationCompat$MessagingStyle$Message.mTimestamp);
            Person person = notificationCompat$MessagingStyle$Message.mPerson;
            if (person != null) {
                bundle.putCharSequence("sender", person.mName);
                bundle.putParcelable("sender_person", notificationCompat$MessagingStyle$Message.mPerson.toAndroidPerson());
            }
            String str = notificationCompat$MessagingStyle$Message.mDataMimeType;
            if (str != null) {
                bundle.putString("type", str);
            }
            Parcelable parcelable = notificationCompat$MessagingStyle$Message.mDataUri;
            if (parcelable != null) {
                bundle.putParcelable("uri", parcelable);
            }
            bundle.putBundle("extras", notificationCompat$MessagingStyle$Message.mExtras);
            bundleArr[i] = bundle;
        }
        return bundleArr;
    }

    static List getMessagesFromBundleArray(Parcelable[] parcelableArr) {
        Parcelable[] parcelableArr2 = parcelableArr;
        String str = "extras";
        String str2 = "type";
        String str3 = "sender";
        String str4 = "sender_person";
        String str5 = "person";
        String str6 = "time";
        String str7 = "text";
        List arrayList = new ArrayList(parcelableArr2.length);
        int i = 0;
        while (i < parcelableArr2.length) {
            Parcelable parcelable = parcelableArr2[i];
            if (parcelable instanceof Bundle) {
                Object obj;
                Bundle bundle = (Bundle) parcelable;
                try {
                    if (bundle.containsKey(str7)) {
                        if (bundle.containsKey(str6)) {
                            Person build;
                            String str8 = "uri";
                            if (bundle.containsKey(str5)) {
                                Bundle bundle2 = bundle.getBundle(str5);
                                Bundle bundle3 = bundle2.getBundle("icon");
                                Builder builder = new Builder();
                                builder.mName = bundle2.getCharSequence("name");
                                builder.mIcon = bundle3 != null ? IconCompat.createFromBundle(bundle3) : null;
                                builder.mUri = bundle2.getString(str8);
                                builder.mKey = bundle2.getString("key");
                                builder.mIsBot = bundle2.getBoolean("isBot");
                                builder.mIsImportant = bundle2.getBoolean("isImportant");
                                build = builder.build();
                            } else if (bundle.containsKey(str4)) {
                                IconCompat createWithResource$ar$ds;
                                android.app.Person person = (android.app.Person) bundle.getParcelable(str4);
                                Builder builder2 = new Builder();
                                builder2.mName = person.getName();
                                if (person.getIcon() != null) {
                                    Icon icon = person.getIcon();
                                    Preconditions.checkNotNull$ar$ds(icon);
                                    String str9 = "Uri must not be null.";
                                    Uri uri;
                                    String uri2;
                                    switch (icon.getType()) {
                                        case 2:
                                            createWithResource$ar$ds = IconCompat.createWithResource$ar$ds(icon.getResPackage(), icon.getResId());
                                            break;
                                        case 4:
                                            uri = icon.getUri();
                                            if (uri != null) {
                                                uri2 = uri.toString();
                                                if (uri2 != null) {
                                                    createWithResource$ar$ds = new IconCompat(4);
                                                    createWithResource$ar$ds.mObj1 = uri2;
                                                    break;
                                                }
                                                throw new IllegalArgumentException(str9);
                                            }
                                            throw new IllegalArgumentException(str9);
                                        case 6:
                                            uri = icon.getUri();
                                            if (uri != null) {
                                                uri2 = uri.toString();
                                                if (uri2 != null) {
                                                    createWithResource$ar$ds = new IconCompat(6);
                                                    createWithResource$ar$ds.mObj1 = uri2;
                                                    break;
                                                }
                                                throw new IllegalArgumentException(str9);
                                            }
                                            throw new IllegalArgumentException(str9);
                                        default:
                                            createWithResource$ar$ds = new IconCompat(-1);
                                            createWithResource$ar$ds.mObj1 = icon;
                                            break;
                                    }
                                }
                                createWithResource$ar$ds = null;
                                builder2.mIcon = createWithResource$ar$ds;
                                builder2.mUri = person.getUri();
                                builder2.mKey = person.getKey();
                                builder2.mIsBot = person.isBot();
                                builder2.mIsImportant = person.isImportant();
                                build = builder2.build();
                            } else if (bundle.containsKey(str3)) {
                                Builder builder3 = new Builder();
                                builder3.mName = bundle.getCharSequence(str3);
                                build = builder3.build();
                            } else {
                                build = null;
                            }
                            NotificationCompat$MessagingStyle$Message notificationCompat$MessagingStyle$Message = new NotificationCompat$MessagingStyle$Message(bundle.getCharSequence(str7), bundle.getLong(str6), build);
                            if (bundle.containsKey(str2) && bundle.containsKey(str8)) {
                                Uri uri3 = (Uri) bundle.getParcelable(str8);
                                notificationCompat$MessagingStyle$Message.mDataMimeType = bundle.getString(str2);
                                notificationCompat$MessagingStyle$Message.mDataUri = uri3;
                            }
                            if (bundle.containsKey(str)) {
                                notificationCompat$MessagingStyle$Message.mExtras.putAll(bundle.getBundle(str));
                            }
                            obj = notificationCompat$MessagingStyle$Message;
                        } else {
                            obj = null;
                        }
                        if (obj != null) {
                            arrayList.add(obj);
                        }
                    }
                } catch (ClassCastException e) {
                }
                obj = null;
                if (obj != null) {
                    arrayList.add(obj);
                }
            }
            i++;
            parcelableArr2 = parcelableArr;
        }
        return arrayList;
    }

    @Deprecated
    public final CharSequence getSender() {
        Person person = this.mPerson;
        return person == null ? null : person.mName;
    }
}
