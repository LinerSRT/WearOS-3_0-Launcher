package android.support.p000v4.app;

import android.app.PendingIntent;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.support.p000v4.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.app.NotificationCompat$Action */
public final class NotificationCompat$Action {
    public final PendingIntent actionIntent;
    @Deprecated
    public int icon;
    public final boolean mAllowGeneratedReplies;
    public final Bundle mExtras;
    private IconCompat mIcon;
    public final boolean mIsContextual;
    public final RemoteInput[] mRemoteInputs;
    public final int mSemanticAction;
    public boolean mShowsUserInterface = true;
    public final CharSequence title;

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.NotificationCompat$Action$Builder */
    public final class Builder {
        public boolean mAllowGeneratedReplies;
        public final Bundle mExtras;
        private final IconCompat mIcon;
        private final PendingIntent mIntent;
        public boolean mIsContextual;
        public ArrayList mRemoteInputs;
        public int mSemanticAction;
        public boolean mShowsUserInterface;
        private final CharSequence mTitle;

        public Builder(IconCompat iconCompat, CharSequence charSequence, PendingIntent pendingIntent) {
            this(iconCompat, charSequence, pendingIntent, new Bundle());
        }

        public final NotificationCompat$Action build() {
            if (this.mIsContextual) {
                if (this.mIntent == null) {
                    throw new NullPointerException("Contextual Actions must contain a valid PendingIntent");
                }
            }
            List arrayList = new ArrayList();
            List arrayList2 = new ArrayList();
            List list = this.mRemoteInputs;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    RemoteInput remoteInput = (RemoteInput) list.get(i);
                    if (!remoteInput.mAllowFreeFormTextInput) {
                        CharSequence[] charSequenceArr = remoteInput.mChoices;
                        if ((charSequenceArr == null || charSequenceArr.length == 0) && !remoteInput.mAllowedDataTypes.isEmpty()) {
                            arrayList.add(remoteInput);
                        }
                    }
                    arrayList2.add(remoteInput);
                }
            }
            if (!arrayList.isEmpty()) {
                RemoteInput[] remoteInputArr = (RemoteInput[]) arrayList.toArray(new RemoteInput[arrayList.size()]);
            }
            return new NotificationCompat$Action(this.mIcon, this.mTitle, this.mIntent, this.mExtras, arrayList2.isEmpty() ? null : (RemoteInput[]) arrayList2.toArray(new RemoteInput[arrayList2.size()]), this.mAllowGeneratedReplies, this.mSemanticAction, this.mShowsUserInterface, this.mIsContextual);
        }

        public Builder(IconCompat iconCompat, CharSequence charSequence, PendingIntent pendingIntent, Bundle bundle) {
            this.mAllowGeneratedReplies = true;
            this.mShowsUserInterface = true;
            this.mIcon = iconCompat;
            this.mTitle = NotificationCompat$Builder.limitCharSequenceLength(charSequence);
            this.mIntent = pendingIntent;
            this.mExtras = bundle;
            this.mRemoteInputs = null;
            this.mAllowGeneratedReplies = true;
            this.mSemanticAction = 0;
            this.mShowsUserInterface = true;
            this.mIsContextual = false;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.NotificationCompat$Action$WearableExtender */
    public final class WearableExtender {
        public CharSequence mCancelLabel;
        public CharSequence mConfirmLabel;
        private int mFlags = 1;
        public CharSequence mInProgressLabel;

        public final /* bridge */ /* synthetic */ Object clone() {
            WearableExtender wearableExtender = new WearableExtender();
            wearableExtender.mFlags = this.mFlags;
            wearableExtender.mInProgressLabel = this.mInProgressLabel;
            wearableExtender.mConfirmLabel = this.mConfirmLabel;
            wearableExtender.mCancelLabel = this.mCancelLabel;
            return wearableExtender;
        }

        public WearableExtender(NotificationCompat$Action notificationCompat$Action) {
            Bundle bundle = notificationCompat$Action.mExtras.getBundle("android.wearable.EXTENSIONS");
            if (bundle != null) {
                this.mFlags = bundle.getInt("flags", 1);
                this.mInProgressLabel = bundle.getCharSequence("inProgressLabel");
                this.mConfirmLabel = bundle.getCharSequence("confirmLabel");
                this.mCancelLabel = bundle.getCharSequence("cancelLabel");
            }
        }
    }

    public final IconCompat getIconCompat() {
        if (this.mIcon == null) {
            int i = this.icon;
            if (i != 0) {
                this.mIcon = IconCompat.createWithResource$ar$ds("", i);
            }
        }
        return this.mIcon;
    }

    public NotificationCompat$Action(IconCompat iconCompat, CharSequence charSequence, PendingIntent pendingIntent, Bundle bundle, RemoteInput[] remoteInputArr, boolean z, int i, boolean z2, boolean z3) {
        this.mIcon = iconCompat;
        if (iconCompat != null) {
            int i2 = iconCompat.mType;
            if (i2 == -1) {
                i2 = ((Icon) iconCompat.mObj1).getType();
            }
            if (i2 == 2) {
                this.icon = iconCompat.getResId();
            }
        }
        this.title = NotificationCompat$Builder.limitCharSequenceLength(charSequence);
        this.actionIntent = pendingIntent;
        this.mExtras = bundle;
        this.mRemoteInputs = remoteInputArr;
        this.mAllowGeneratedReplies = z;
        this.mSemanticAction = i;
        this.mShowsUserInterface = z2;
        this.mIsContextual = z3;
    }
}
