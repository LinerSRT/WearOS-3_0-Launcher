package android.support.p000v4.app;

import android.content.Context;
import android.os.Bundle;
import android.support.p000v4.app.FragmentManager.FragmentLifecycleCallbacks;
import android.view.View;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentLifecycleCallbacksDispatcher */
final class FragmentLifecycleCallbacksDispatcher {
    private final FragmentManager mFragmentManager;
    private final CopyOnWriteArrayList mLifecycleCallbacks = new CopyOnWriteArrayList();

    /* compiled from: PG */
    /* renamed from: android.support.v4.app.FragmentLifecycleCallbacksDispatcher$FragmentLifecycleCallbacksHolder */
    final class FragmentLifecycleCallbacksHolder {
        final FragmentLifecycleCallbacks mCallback;
        final boolean mRecursive;
    }

    public FragmentLifecycleCallbacksDispatcher(FragmentManager fragmentManager) {
        this.mFragmentManager = fragmentManager;
    }

    final void dispatchOnFragmentActivityCreated(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentActivityCreated(fragment, bundle, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentAttached(Fragment fragment, boolean z) {
        FragmentManager fragmentManager = this.mFragmentManager;
        Context context = fragmentManager.mHost.mContext;
        Fragment fragment2 = fragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentAttached(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentCreated(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentCreated(fragment, bundle, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentDestroyed(Fragment fragment, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentDestroyed(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentDetached(Fragment fragment, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentDetached(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentPaused(Fragment fragment, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentPaused(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentPreAttached(Fragment fragment, boolean z) {
        FragmentManager fragmentManager = this.mFragmentManager;
        Context context = fragmentManager.mHost.mContext;
        Fragment fragment2 = fragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentPreAttached(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentPreCreated(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentPreCreated(fragment, bundle, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentResumed(Fragment fragment, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentResumed(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentSaveInstanceState(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentSaveInstanceState(fragment, bundle, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentStarted(Fragment fragment, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentStarted(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentStopped(Fragment fragment, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentStopped(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentViewCreated(Fragment fragment, View view, Bundle bundle, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentViewCreated(fragment, view, bundle, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }

    final void dispatchOnFragmentViewDestroyed(Fragment fragment, boolean z) {
        Fragment fragment2 = this.mFragmentManager.mParent;
        if (fragment2 != null) {
            fragment2.getParentFragmentManager().mLifecycleCallbacksDispatcher.dispatchOnFragmentViewDestroyed(fragment, true);
        }
        Iterator it = this.mLifecycleCallbacks.iterator();
        while (it.hasNext()) {
            FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder = (FragmentLifecycleCallbacksHolder) it.next();
            if (z) {
                boolean z2 = fragmentLifecycleCallbacksHolder.mRecursive;
            } else {
                FragmentLifecycleCallbacks fragmentLifecycleCallbacks = fragmentLifecycleCallbacksHolder.mCallback;
                throw null;
            }
        }
    }
}
