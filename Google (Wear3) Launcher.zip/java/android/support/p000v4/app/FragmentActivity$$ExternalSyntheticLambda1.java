package android.support.p000v4.app;

import android.os.Bundle;
import androidx.lifecycle.Lifecycle.Event;
import androidx.savedstate.SavedStateRegistry.SavedStateProvider;

/* compiled from: PG */
/* renamed from: android.support.v4.app.FragmentActivity$$ExternalSyntheticLambda1 */
public final /* synthetic */ class FragmentActivity$$ExternalSyntheticLambda1 implements SavedStateProvider {
    public final /* synthetic */ FragmentActivity f$0;

    public /* synthetic */ FragmentActivity$$ExternalSyntheticLambda1(FragmentActivity fragmentActivity) {
        this.f$0 = fragmentActivity;
    }

    public final Bundle saveState() {
        FragmentActivity fragmentActivity = this.f$0;
        fragmentActivity.markFragmentsCreated();
        fragmentActivity.mFragmentLifecycleRegistry.handleLifecycleEvent(Event.ON_STOP);
        return new Bundle();
    }
}
