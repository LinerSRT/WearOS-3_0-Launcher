package android.support.p000v4.widget;

import android.content.ClipData;
import android.content.ClipData.Item;
import android.content.Context;
import android.support.p000v4.view.ContentInfoCompat;
import android.support.p002v7.widget.AppCompatEditText;
import android.text.Selection;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

/* compiled from: PG */
/* renamed from: android.support.v4.widget.TextViewOnReceiveContentListener */
public final class TextViewOnReceiveContentListener {
    public static final ContentInfoCompat onReceiveContent$ar$ds(View view, ContentInfoCompat contentInfoCompat) {
        String str = "ReceiveContent";
        if (Log.isLoggable(str, 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onReceive: ");
            stringBuilder.append(contentInfoCompat);
            Log.d(str, stringBuilder.toString());
        }
        if (contentInfoCompat.mCompat.getSource() == 2) {
            return contentInfoCompat;
        }
        ClipData clip = contentInfoCompat.mCompat.getClip();
        int flags = contentInfoCompat.mCompat.getFlags();
        Object text = ((AppCompatEditText) view).getText();
        Context context = ((TextView) view).getContext();
        Object obj = null;
        for (int i = 0; i < clip.getItemCount(); i++) {
            CharSequence coerceToText;
            Item itemAt = clip.getItemAt(i);
            if ((flags & 1) != 0) {
                coerceToText = itemAt.coerceToText(context);
                if (coerceToText instanceof Spanned) {
                    coerceToText = coerceToText.toString();
                }
            } else {
                coerceToText = itemAt.coerceToStyledText(context);
            }
            if (coerceToText != null) {
                if (obj == null) {
                    int selectionStart = Selection.getSelectionStart(text);
                    int selectionEnd = Selection.getSelectionEnd(text);
                    int max = Math.max(0, Math.min(selectionStart, selectionEnd));
                    selectionStart = Math.max(0, Math.max(selectionStart, selectionEnd));
                    Selection.setSelection(text, selectionStart);
                    text.replace(max, selectionStart, coerceToText);
                    obj = 1;
                } else {
                    text.insert(Selection.getSelectionEnd(text), "\n");
                    text.insert(Selection.getSelectionEnd(text), coerceToText);
                    obj = 1;
                }
            }
        }
        return null;
    }
}
