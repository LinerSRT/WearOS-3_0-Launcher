package android.support.p000v4.widget;

import android.support.p000v4.util.Preconditions;
import android.widget.TextView;

/* compiled from: PG */
/* renamed from: android.support.v4.widget.TextViewCompat */
public final class TextViewCompat {
    public static void setLineHeight(TextView textView, int i) {
        Preconditions.checkArgumentNonnegative$ar$ds(i);
        int fontMetricsInt = textView.getPaint().getFontMetricsInt(null);
        if (i != fontMetricsInt) {
            textView.setLineSpacing((float) (i - fontMetricsInt), 1.0f);
        }
    }
}
