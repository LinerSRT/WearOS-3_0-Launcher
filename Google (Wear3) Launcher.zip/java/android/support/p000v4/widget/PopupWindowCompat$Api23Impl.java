package android.support.p000v4.widget;

import android.widget.PopupWindow;

/* compiled from: PG */
/* renamed from: android.support.v4.widget.PopupWindowCompat$Api23Impl */
public final class PopupWindowCompat$Api23Impl {
    public static void setOverlapAnchor(PopupWindow popupWindow, boolean z) {
        popupWindow.setOverlapAnchor(z);
    }

    public static void setWindowLayoutType(PopupWindow popupWindow, int i) {
        popupWindow.setWindowLayoutType(i);
    }
}
