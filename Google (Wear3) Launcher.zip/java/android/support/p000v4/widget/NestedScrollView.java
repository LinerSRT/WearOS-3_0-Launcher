package android.support.p000v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p000v4.view.AccessibilityDelegateCompat;
import android.support.p000v4.view.NestedScrollingChildHelper;
import android.support.p000v4.view.NestedScrollingParent3;
import android.support.p000v4.view.NestedScrollingParentHelper;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityActionCompat;
import android.support.p002v7.widget.LinearLayoutManager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.OverScroller;
import android.widget.ScrollView;
import com.google.android.clockwork.wcs.sdk.PG;
import com.google.android.wearable.sysui.R;
import java.util.List;

/* compiled from: PG */
/* renamed from: android.support.v4.widget.NestedScrollView */
public class NestedScrollView extends FrameLayout implements NestedScrollingParent3 {
    private static final AccessibilityDelegate ACCESSIBILITY_DELEGATE = new AccessibilityDelegate();
    private static final int[] SCROLLVIEW_STYLEABLE = new int[]{16843130};
    private int mActivePointerId;
    private final NestedScrollingChildHelper mChildHelper;
    private View mChildToScrollTo;
    public EdgeEffect mEdgeGlowBottom;
    public EdgeEffect mEdgeGlowTop;
    private boolean mFillViewport;
    private boolean mIsBeingDragged;
    private boolean mIsLaidOut;
    private boolean mIsLayoutDirty;
    private int mLastMotionY;
    private long mLastScroll;
    private int mLastScrollerY;
    private int mMaximumVelocity;
    private int mMinimumVelocity;
    private int mNestedYOffset;
    public OnScrollChangeListener mOnScrollChangeListener;
    private final NestedScrollingParentHelper mParentHelper;
    private SavedState mSavedState;
    private final int[] mScrollConsumed;
    private final int[] mScrollOffset;
    private OverScroller mScroller;
    private boolean mSmoothScrollingEnabled;
    private final Rect mTempRect;
    private int mTouchSlop;
    private VelocityTracker mVelocityTracker;
    private float mVerticalScrollFactor;

    /* compiled from: PG */
    /* renamed from: android.support.v4.widget.NestedScrollView$AccessibilityDelegate */
    final class AccessibilityDelegate extends AccessibilityDelegateCompat {
        public final void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            boolean z;
            super.onInitializeAccessibilityEvent(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            if (nestedScrollView.getScrollRange() > 0) {
                z = true;
            } else {
                z = false;
            }
            accessibilityEvent.setScrollable(z);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            accessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setMaxScrollY(nestedScrollView.getScrollRange());
        }

        public final void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfoCompat);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityNodeInfoCompat.setClassName(ScrollView.class.getName());
            if (nestedScrollView.isEnabled()) {
                int scrollRange = nestedScrollView.getScrollRange();
                if (scrollRange > 0) {
                    accessibilityNodeInfoCompat.setScrollable(true);
                    if (nestedScrollView.getScrollY() > 0) {
                        accessibilityNodeInfoCompat.addAction(AccessibilityActionCompat.ACTION_SCROLL_BACKWARD);
                        accessibilityNodeInfoCompat.addAction(AccessibilityActionCompat.ACTION_SCROLL_UP);
                    }
                    if (nestedScrollView.getScrollY() < scrollRange) {
                        accessibilityNodeInfoCompat.addAction(AccessibilityActionCompat.ACTION_SCROLL_FORWARD);
                        accessibilityNodeInfoCompat.addAction(AccessibilityActionCompat.ACTION_SCROLL_DOWN);
                    }
                }
            }
        }

        public final boolean performAccessibilityAction(View view, int i, Bundle bundle) {
            if (super.performAccessibilityAction(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            int paddingBottom;
            switch (i) {
                case 4096:
                case 16908346:
                    i = nestedScrollView.getHeight();
                    paddingBottom = nestedScrollView.getPaddingBottom();
                    i = Math.min(nestedScrollView.getScrollY() + ((i - paddingBottom) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
                    if (i == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.smoothScrollTo$ar$ds(i);
                    return true;
                case 8192:
                case 16908344:
                    i = nestedScrollView.getHeight();
                    paddingBottom = nestedScrollView.getPaddingBottom();
                    i = Math.max(nestedScrollView.getScrollY() - ((i - paddingBottom) - nestedScrollView.getPaddingTop()), 0);
                    if (i == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.smoothScrollTo$ar$ds(i);
                    return true;
                default:
                    return false;
            }
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.widget.NestedScrollView$OnScrollChangeListener */
    public interface OnScrollChangeListener {
        void onScrollChange$ar$ds(NestedScrollView nestedScrollView);
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.widget.NestedScrollView$SavedState */
    final class SavedState extends BaseSavedState {
        public static final Creator CREATOR = new PG();
        public int scrollPosition;

        /* renamed from: android.support.v4.widget.NestedScrollView$SavedState$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new SavedState[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }
        }

        public SavedState(Parcel parcel) {
            super(parcel);
            this.scrollPosition = parcel.readInt();
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("HorizontalScrollView.SavedState{");
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append(" scrollPosition=");
            stringBuilder.append(this.scrollPosition);
            stringBuilder.append("}");
            return stringBuilder.toString();
        }

        public final void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.scrollPosition);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public NestedScrollView(Context context) {
        this(context, null);
    }

    private final void abortAnimatedScroll() {
        this.mScroller.abortAnimation();
        stopNestedScroll(1);
    }

    private static int clamp(int i, int i2, int i3) {
        if (i2 < i3) {
            if (i >= 0) {
                return i2 + i > i3 ? i3 - i2 : i;
            }
        }
        return 0;
    }

    private final void doScrollY(int i) {
        if (i != 0) {
            if (this.mSmoothScrollingEnabled) {
                smoothScrollBy$ar$ds(i);
                return;
            }
            scrollBy(0, i);
        }
    }

    private final void endDrag() {
        this.mIsBeingDragged = false;
        recycleVelocityTracker();
        stopNestedScroll(0);
        this.mEdgeGlowTop.onRelease();
        this.mEdgeGlowBottom.onRelease();
    }

    private final void initVelocityTrackerIfNotExists() {
        if (this.mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        }
    }

    private final boolean isOffScreen(View view) {
        return !isWithinDeltaOfScreen(view, 0, getHeight());
    }

    private static boolean isViewDescendantOf(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && NestedScrollView.isViewDescendantOf((View) parent, view2);
    }

    private final boolean isWithinDeltaOfScreen(View view, int i, int i2) {
        view.getDrawingRect(this.mTempRect);
        offsetDescendantRectToMyCoords(view, this.mTempRect);
        return this.mTempRect.bottom + i >= getScrollY() && this.mTempRect.top - i <= getScrollY() + i2;
    }

    private final void onNestedScrollInternal(int i, int i2, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.mChildHelper.dispatchNestedScrollInternal(0, scrollY2, 0, i - scrollY2, null, i2, iArr);
    }

    private final void onSecondaryPointerUp(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.mActivePointerId) {
            if (actionIndex == 0) {
                actionIndex = 1;
            } else {
                actionIndex = 0;
            }
            this.mLastMotionY = (int) motionEvent.getY(actionIndex);
            this.mActivePointerId = motionEvent.getPointerId(actionIndex);
            VelocityTracker velocityTracker = this.mVelocityTracker;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    private final void recycleVelocityTracker() {
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.mVelocityTracker = null;
        }
    }

    private final void runAnimatedScroll(boolean z) {
        if (z) {
            startNestedScroll(2, 1);
        } else {
            stopNestedScroll(1);
        }
        this.mLastScrollerY = getScrollY();
        ViewCompat.postInvalidateOnAnimation(this);
    }

    private final boolean scrollAndFocus(int i, int i2, int i3) {
        boolean z;
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        int height = getHeight();
        int scrollY = getScrollY();
        height += scrollY;
        List focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        Object obj = null;
        for (int i7 = 0; i7 < size; i7++) {
            View view2 = (View) focusables.get(i7);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i5 < bottom && top < i6) {
                Object obj2;
                if (i5 >= top || bottom >= i6) {
                    obj2 = null;
                } else {
                    obj2 = 1;
                }
                if (view == null) {
                    view = view2;
                    obj = obj2;
                } else {
                    Object obj3 = i4 == 33 ? top >= view.getTop() ? null : 1 : bottom > view.getBottom() ? 1 : null;
                    if (obj != null) {
                        if (!(obj2 == null || obj3 == null)) {
                        }
                    } else if (obj2 != null) {
                        view = view2;
                        obj = 1;
                    } else if (obj3 == null) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = r0;
        }
        if (i5 < scrollY || i6 > height) {
            if (i4 == 33) {
                i5 -= scrollY;
            } else {
                i5 = i6 - height;
            }
            doScrollY(i5);
            z = true;
        } else {
            z = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i4);
        }
        return z;
    }

    private final void scrollToChild(View view) {
        view.getDrawingRect(this.mTempRect);
        offsetDescendantRectToMyCoords(view, this.mTempRect);
        int computeScrollDeltaToGetChildRectOnScreen = computeScrollDeltaToGetChildRectOnScreen(this.mTempRect);
        if (computeScrollDeltaToGetChildRectOnScreen != 0) {
            scrollBy(0, computeScrollDeltaToGetChildRectOnScreen);
        }
    }

    private final void smoothScrollBy$ar$ds$c0e3f38_0(int i, int i2, boolean z) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.mLastScroll > 250) {
                View childAt = getChildAt(0);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int height = childAt.getHeight();
                int i3 = layoutParams.topMargin;
                int i4 = layoutParams.bottomMargin;
                int height2 = getHeight();
                int paddingTop = getPaddingTop();
                int paddingBottom = getPaddingBottom();
                int scrollY = getScrollY();
                this.mScroller.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(i2 + scrollY, Math.max(0, ((height + i3) + i4) - ((height2 - paddingTop) - paddingBottom)))) - scrollY, 250);
                runAnimatedScroll(z);
            } else {
                if (!this.mScroller.isFinished()) {
                    abortAnimatedScroll();
                }
                scrollBy(i, i2);
            }
            this.mLastScroll = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    private final boolean stopGlowAnimations(MotionEvent motionEvent) {
        boolean z;
        if (EdgeEffectCompat.getDistance(this.mEdgeGlowTop) != 0.0f) {
            EdgeEffectCompat.onPullDistance(this.mEdgeGlowTop, 0.0f, motionEvent.getY() / ((float) getHeight()));
            z = true;
        } else {
            z = false;
        }
        if (EdgeEffectCompat.getDistance(this.mEdgeGlowBottom) == 0.0f) {
            return z;
        }
        EdgeEffectCompat.onPullDistance(this.mEdgeGlowBottom, 0.0f, 1.0f - (motionEvent.getY() / ((float) getHeight())));
        return true;
    }

    public final void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final boolean arrowScroll(int i) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        int height = (int) (((float) getHeight()) * 0.5f);
        if (findNextFocus == null || !isWithinDeltaOfScreen(findNextFocus, height, getHeight())) {
            if (i == 33 && getScrollY() < height) {
                height = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                findNextFocus = getChildAt(0);
                height = Math.min((findNextFocus.getBottom() + ((LayoutParams) findNextFocus.getLayoutParams()).bottomMargin) - ((getScrollY() + getHeight()) - getPaddingBottom()), height);
            }
            if (height == 0) {
                return false;
            }
            if (i != 130) {
                height = -height;
            }
            doScrollY(height);
        } else {
            findNextFocus.getDrawingRect(this.mTempRect);
            offsetDescendantRectToMyCoords(findNextFocus, this.mTempRect);
            doScrollY(computeScrollDeltaToGetChildRectOnScreen(this.mTempRect));
            findNextFocus.requestFocus(i);
        }
        if (findFocus != null && findFocus.isFocused() && isOffScreen(findFocus)) {
            i = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(i);
        }
        return true;
    }

    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public final void computeScroll() {
        if (!this.mScroller.isFinished()) {
            int scrollY;
            this.mScroller.computeScrollOffset();
            int currY = this.mScroller.getCurrY();
            int i = currY - this.mLastScrollerY;
            this.mLastScrollerY = currY;
            int[] iArr = this.mScrollConsumed;
            iArr[1] = 0;
            dispatchNestedPreScroll(0, i, iArr, null, 1);
            i -= this.mScrollConsumed[1];
            int scrollRange = getScrollRange();
            if (i != 0) {
                scrollY = getScrollY();
                overScrollByCompat$ar$ds(i, getScrollX(), scrollY, scrollRange);
                int scrollY2 = getScrollY() - scrollY;
                i -= scrollY2;
                int[] iArr2 = this.mScrollConsumed;
                iArr2[1] = 0;
                dispatchNestedScroll$ar$ds(scrollY2, i, this.mScrollOffset, 1, iArr2);
                i -= this.mScrollConsumed[1];
            }
            if (i != 0) {
                scrollY = getOverScrollMode();
                if (scrollY == 0 || (scrollY == 1 && scrollRange > 0)) {
                    if (i < 0) {
                        if (this.mEdgeGlowTop.isFinished()) {
                            this.mEdgeGlowTop.onAbsorb((int) this.mScroller.getCurrVelocity());
                        }
                    } else if (this.mEdgeGlowBottom.isFinished()) {
                        this.mEdgeGlowBottom.onAbsorb((int) this.mScroller.getCurrVelocity());
                    }
                }
                abortAnimatedScroll();
            }
            if (this.mScroller.isFinished()) {
                stopNestedScroll(1);
            } else {
                ViewCompat.postInvalidateOnAnimation(this);
            }
        }
    }

    protected final int computeScrollDeltaToGetChildRectOnScreen(Rect rect) {
        int i = 0;
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i2 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
        if (rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) {
            verticalFadingEdgeLength = i2 - verticalFadingEdgeLength;
        } else {
            verticalFadingEdgeLength = i2;
        }
        int i3;
        if (rect.bottom > verticalFadingEdgeLength && rect.top > scrollY) {
            if (rect.height() > height) {
                i3 = rect.top - scrollY;
            } else {
                i3 = rect.bottom - verticalFadingEdgeLength;
            }
            i = Math.min(i3, (childAt.getBottom() + layoutParams.bottomMargin) - i2);
        } else if (rect.top < scrollY && rect.bottom < verticalFadingEdgeLength) {
            if (rect.height() > height) {
                i3 = -(verticalFadingEdgeLength - rect.bottom);
            } else {
                i3 = -(scrollY - rect.top);
            }
            i = Math.max(i3, -getScrollY());
        }
        return i;
    }

    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public final int computeVerticalScrollRange() {
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (getChildCount() == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        if (scrollY < 0) {
            bottom -= scrollY;
        } else if (scrollY > max) {
            return bottom + (scrollY - max);
        }
        return bottom;
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!super.dispatchKeyEvent(keyEvent)) {
            if (!executeKeyEvent(keyEvent)) {
                return false;
            }
        }
        return true;
    }

    public final boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.mChildHelper.dispatchNestedFling(f, f2, z);
    }

    public final boolean dispatchNestedPreFling(float f, float f2) {
        return this.mChildHelper.dispatchNestedPreFling(f, f2);
    }

    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return dispatchNestedPreScroll(i, i2, iArr, iArr2, 0);
    }

    public final boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.mChildHelper.dispatchNestedScroll(i, i2, i3, i4, iArr);
    }

    public final void dispatchNestedScroll$ar$ds(int i, int i2, int[] iArr, int i3, int[] iArr2) {
        this.mChildHelper.dispatchNestedScrollInternal(0, i, 0, i2, iArr, i3, iArr2);
    }

    public final void draw(Canvas canvas) {
        int width;
        int height;
        super.draw(canvas);
        int scrollY = getScrollY();
        int i = 0;
        if (!this.mEdgeGlowTop.isFinished()) {
            int paddingLeft;
            int save = canvas.save();
            width = getWidth();
            height = getHeight();
            int min = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingLeft() + getPaddingRight();
                paddingLeft = getPaddingLeft();
            } else {
                paddingLeft = 0;
            }
            if (getClipToPadding()) {
                height -= getPaddingTop() + getPaddingBottom();
                min += getPaddingTop();
            }
            canvas.translate((float) paddingLeft, (float) min);
            this.mEdgeGlowTop.setSize(width, height);
            if (this.mEdgeGlowTop.draw(canvas)) {
                ViewCompat.postInvalidateOnAnimation(this);
            }
            canvas.restoreToCount(save);
        }
        if (!this.mEdgeGlowBottom.isFinished()) {
            save = canvas.save();
            width = getWidth();
            height = getHeight();
            scrollY = Math.max(getScrollRange(), scrollY) + height;
            if (getClipToPadding()) {
                width -= getPaddingLeft() + getPaddingRight();
                i = getPaddingLeft();
            }
            if (getClipToPadding()) {
                height -= getPaddingTop() + getPaddingBottom();
                scrollY -= getPaddingBottom();
            }
            canvas.translate((float) (i - width), (float) scrollY);
            canvas.rotate(180.0f, (float) width, 0.0f);
            this.mEdgeGlowBottom.setSize(width, height);
            if (this.mEdgeGlowBottom.draw(canvas)) {
                ViewCompat.postInvalidateOnAnimation(this);
            }
            canvas.restoreToCount(save);
        }
    }

    public final boolean executeKeyEvent(KeyEvent keyEvent) {
        this.mTempRect.setEmpty();
        boolean z = false;
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() == 0) {
                    int i = 33;
                    switch (keyEvent.getKeyCode()) {
                        case 19:
                            if (!keyEvent.isAltPressed()) {
                                z = arrowScroll(33);
                                break;
                            }
                            z = fullScroll(33);
                            break;
                        case PG.styleable.CircledImageView_image_circle_percentage /*20*/:
                            if (!keyEvent.isAltPressed()) {
                                z = arrowScroll(130);
                                break;
                            }
                            z = fullScroll(130);
                            break;
                        case 62:
                            if (true != keyEvent.isShiftPressed()) {
                                i = 130;
                            }
                            int height = getHeight();
                            if (i == 130) {
                                this.mTempRect.top = getScrollY() + height;
                                int childCount = getChildCount();
                                if (childCount > 0) {
                                    childAt = getChildAt(childCount - 1);
                                    childCount = (childAt.getBottom() + ((LayoutParams) childAt.getLayoutParams()).bottomMargin) + getPaddingBottom();
                                    if (this.mTempRect.top + height > childCount) {
                                        this.mTempRect.top = childCount - height;
                                    }
                                }
                            } else {
                                this.mTempRect.top = getScrollY() - height;
                                if (this.mTempRect.top < 0) {
                                    this.mTempRect.top = 0;
                                }
                            }
                            Rect rect = this.mTempRect;
                            rect.bottom = rect.top + height;
                            scrollAndFocus(i, this.mTempRect.top, this.mTempRect.bottom);
                            return false;
                        default:
                            break;
                    }
                }
                return z;
            }
        }
        if (isFocused() && keyEvent.getKeyCode() != 4) {
            View findFocus = findFocus();
            if (findFocus == this) {
                findFocus = null;
            }
            findFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
            return (findFocus == null || findFocus == this || !findFocus.requestFocus(130)) ? false : true;
        }
    }

    public final void fling(int i) {
        if (getChildCount() > 0) {
            this.mScroller.fling(getScrollX(), getScrollY(), 0, i, 0, 0, LinearLayoutManager.INVALID_OFFSET, Integer.MAX_VALUE, 0, 0);
            runAnimatedScroll(true);
        }
    }

    public final boolean fullScroll(int i) {
        int height = getHeight();
        this.mTempRect.top = 0;
        this.mTempRect.bottom = height;
        if (i == 130) {
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                this.mTempRect.bottom = (childAt.getBottom() + layoutParams.bottomMargin) + getPaddingBottom();
                Rect rect = this.mTempRect;
                rect.top = rect.bottom - height;
            }
        }
        return scrollAndFocus(i, this.mTempRect.top, this.mTempRect.bottom);
    }

    protected final float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        return bottom < verticalFadingEdgeLength ? ((float) bottom) / ((float) verticalFadingEdgeLength) : 1.0f;
    }

    public final int getNestedScrollAxes() {
        return this.mParentHelper.getNestedScrollAxes();
    }

    final int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    protected final float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        return scrollY < verticalFadingEdgeLength ? ((float) scrollY) / ((float) verticalFadingEdgeLength) : 1.0f;
    }

    public final boolean hasNestedScrollingParent() {
        return hasNestedScrollingParent(0);
    }

    public final boolean isNestedScrollingEnabled() {
        return this.mChildHelper.mIsNestedScrollingEnabled;
    }

    protected final void measureChild(View view, int i, int i2) {
        view.measure(NestedScrollView.getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight(), view.getLayoutParams().width), MeasureSpec.makeMeasureSpec(0, 0));
    }

    protected final void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        view.measure(NestedScrollView.getChildMeasureSpec(i, (((getPaddingLeft() + getPaddingRight()) + marginLayoutParams.leftMargin) + marginLayoutParams.rightMargin) + i2, marginLayoutParams.width), MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mIsLaidOut = false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onGenericMotionEvent(android.view.MotionEvent r7) {
        /*
        r6 = this;
        r0 = r7.getSource();
        r0 = r0 & 2;
        r1 = 0;
        if (r0 == 0) goto L_0x0073;
    L_0x0009:
        r0 = r7.getAction();
        switch(r0) {
            case 8: goto L_0x0011;
            default: goto L_0x0010;
        };
    L_0x0010:
        goto L_0x0073;
    L_0x0011:
        r0 = r6.mIsBeingDragged;
        if (r0 != 0) goto L_0x0010;
    L_0x0015:
        r0 = 9;
        r7 = r7.getAxisValue(r0);
        r0 = 0;
        r2 = (r7 > r0 ? 1 : (r7 == r0 ? 0 : -1));
        if (r2 == 0) goto L_0x0073;
    L_0x0020:
        r2 = r6.mVerticalScrollFactor;
        r3 = 1;
        r0 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1));
        if (r0 != 0) goto L_0x0054;
    L_0x0027:
        r0 = new android.util.TypedValue;
        r0.<init>();
        r2 = r6.getContext();
        r4 = r2.getTheme();
        r5 = 16842829; // 0x101004d float:2.3693774E-38 double:8.321463E-317;
        r4 = r4.resolveAttribute(r5, r0, r3);
        if (r4 == 0) goto L_0x004c;
    L_0x003d:
        r2 = r2.getResources();
        r2 = r2.getDisplayMetrics();
        r2 = r0.getDimension(r2);
        r6.mVerticalScrollFactor = r2;
        goto L_0x0054;
    L_0x004c:
        r7 = new java.lang.IllegalStateException;
        r0 = "Expected theme to define listPreferredItemHeight.";
        r7.<init>(r0);
        throw r7;
    L_0x0054:
        r0 = r6.getScrollRange();
        r4 = r6.getScrollY();
        r7 = r7 * r2;
        r7 = (int) r7;
        r7 = r4 - r7;
        if (r7 >= 0) goto L_0x0065;
    L_0x0063:
        r0 = 0;
        goto L_0x0069;
    L_0x0065:
        if (r7 <= r0) goto L_0x0068;
    L_0x0067:
        goto L_0x0069;
    L_0x0068:
        r0 = r7;
    L_0x0069:
        if (r0 == r4) goto L_0x0073;
    L_0x006b:
        r7 = r6.getScrollX();
        super.scrollTo(r7, r0);
        return r3;
    L_0x0073:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.widget.NestedScrollView.onGenericMotionEvent(android.view.MotionEvent):boolean");
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z = true;
        if (action == 2) {
            if (this.mIsBeingDragged) {
                return true;
            }
            action = 2;
        }
        int scrollY;
        switch (action & 255) {
            case 0:
                action = (int) motionEvent.getY();
                int x = (int) motionEvent.getX();
                if (getChildCount() > 0) {
                    scrollY = getScrollY();
                    View childAt = getChildAt(0);
                    if (action >= childAt.getTop() - scrollY && action < childAt.getBottom() - scrollY && x >= childAt.getLeft() && x < childAt.getRight()) {
                        this.mLastMotionY = action;
                        this.mActivePointerId = motionEvent.getPointerId(0);
                        VelocityTracker velocityTracker = this.mVelocityTracker;
                        if (velocityTracker == null) {
                            this.mVelocityTracker = VelocityTracker.obtain();
                        } else {
                            velocityTracker.clear();
                        }
                        this.mVelocityTracker.addMovement(motionEvent);
                        this.mScroller.computeScrollOffset();
                        if (!stopGlowAnimations(motionEvent)) {
                            if (this.mScroller.isFinished()) {
                                z = false;
                            }
                        }
                        this.mIsBeingDragged = z;
                        startNestedScroll(2, 0);
                        break;
                    }
                }
                if (!stopGlowAnimations(motionEvent)) {
                    if (this.mScroller.isFinished()) {
                        z = false;
                    }
                }
                this.mIsBeingDragged = z;
                recycleVelocityTracker();
                break;
            case 1:
            case 3:
                this.mIsBeingDragged = false;
                this.mActivePointerId = -1;
                recycleVelocityTracker();
                if (this.mScroller.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    ViewCompat.postInvalidateOnAnimation(this);
                }
                stopNestedScroll(0);
                break;
            case 2:
                action = this.mActivePointerId;
                if (action != -1) {
                    scrollY = motionEvent.findPointerIndex(action);
                    if (scrollY != -1) {
                        action = (int) motionEvent.getY(scrollY);
                        if (Math.abs(action - this.mLastMotionY) > this.mTouchSlop && (2 & getNestedScrollAxes()) == 0) {
                            this.mIsBeingDragged = true;
                            this.mLastMotionY = action;
                            initVelocityTrackerIfNotExists();
                            this.mVelocityTracker.addMovement(motionEvent);
                            this.mNestedYOffset = 0;
                            ViewParent parent = getParent();
                            if (parent != null) {
                                parent.requestDisallowInterceptTouchEvent(true);
                                break;
                            }
                        }
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Invalid pointerId=");
                    stringBuilder.append(action);
                    stringBuilder.append(" in onInterceptTouchEvent");
                    Log.e("NestedScrollView", stringBuilder.toString());
                    break;
                }
                break;
            case 6:
                onSecondaryPointerUp(motionEvent);
                break;
            default:
                break;
        }
        return this.mIsBeingDragged;
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int i5 = 0;
        this.mIsLayoutDirty = false;
        View view = this.mChildToScrollTo;
        if (view != null && NestedScrollView.isViewDescendantOf(view, this)) {
            scrollToChild(this.mChildToScrollTo);
        }
        this.mChildToScrollTo = null;
        if (!this.mIsLaidOut) {
            if (this.mSavedState != null) {
                scrollTo(getScrollX(), this.mSavedState.scrollPosition);
                this.mSavedState = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                i5 = (childAt.getMeasuredHeight() + layoutParams.topMargin) + layoutParams.bottomMargin;
            }
            i = getPaddingTop();
            i3 = getPaddingBottom();
            int scrollY = getScrollY();
            i5 = NestedScrollView.clamp(scrollY, ((i4 - i2) - i) - i3, i5);
            if (i5 != scrollY) {
                scrollTo(getScrollX(), i5);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.mIsLaidOut = true;
    }

    protected final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.mFillViewport && MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            int measuredHeight = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (childAt.getMeasuredHeight() < measuredHeight) {
                childAt.measure(NestedScrollView.getChildMeasureSpec(i, ((getPaddingLeft() + getPaddingRight()) + layoutParams.leftMargin) + layoutParams.rightMargin, layoutParams.width), MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824));
            }
        }
    }

    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        dispatchNestedFling(0.0f, f2, true);
        fling((int) f2);
        return true;
    }

    public final boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public final void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        onNestedPreScroll$ar$ds(i, i2, iArr, 0);
    }

    public final void onNestedPreScroll$ar$ds(int i, int i2, int[] iArr, int i3) {
        dispatchNestedPreScroll(i, i2, iArr, null, i3);
    }

    public final void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        onNestedScrollInternal(i4, 0, null);
    }

    public final void onNestedScrollAccepted(View view, View view2, int i) {
        onNestedScrollAccepted(view, view2, i, 0);
    }

    protected final void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    protected final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View findNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (findNextFocus == null || isOffScreen(findNextFocus)) {
            return false;
        }
        return findNextFocus.requestFocus(i, rect);
    }

    protected final void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            super.onRestoreInstanceState(savedState.getSuperState());
            this.mSavedState = savedState;
            requestLayout();
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    protected final Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        savedState.scrollPosition = getScrollY();
        return savedState;
    }

    protected final void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        OnScrollChangeListener onScrollChangeListener = this.mOnScrollChangeListener;
        if (onScrollChangeListener != null) {
            onScrollChangeListener.onScrollChange$ar$ds(this);
        }
    }

    protected final void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null) {
            if (this != findFocus) {
                if (isWithinDeltaOfScreen(findFocus, 0, i4)) {
                    findFocus.getDrawingRect(this.mTempRect);
                    offsetDescendantRectToMyCoords(findFocus, this.mTempRect);
                    doScrollY(computeScrollDeltaToGetChildRectOnScreen(this.mTempRect));
                }
            }
        }
    }

    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return onStartNestedScroll(view, view2, i, 0);
    }

    public final boolean onStartNestedScroll(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    public final void onStopNestedScroll(View view) {
        onStopNestedScroll(view, 0);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        VelocityTracker velocityTracker;
        NestedScrollView nestedScrollView = this;
        MotionEvent motionEvent2 = motionEvent;
        initVelocityTrackerIfNotExists();
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            nestedScrollView.mNestedYOffset = 0;
            actionMasked = 0;
        }
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        float f = 0.0f;
        obtain.offsetLocation(0.0f, (float) nestedScrollView.mNestedYOffset);
        float f2;
        switch (actionMasked) {
            case 0:
                if (getChildCount() != 0) {
                    if (nestedScrollView.mIsBeingDragged) {
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                    if (!nestedScrollView.mScroller.isFinished()) {
                        abortAnimatedScroll();
                    }
                    nestedScrollView.mLastMotionY = (int) motionEvent.getY();
                    nestedScrollView.mActivePointerId = motionEvent2.getPointerId(0);
                    startNestedScroll(2, 0);
                    break;
                }
                return false;
            case 1:
                velocityTracker = nestedScrollView.mVelocityTracker;
                velocityTracker.computeCurrentVelocity(1000, (float) nestedScrollView.mMaximumVelocity);
                actionMasked = (int) velocityTracker.getYVelocity(nestedScrollView.mActivePointerId);
                if (Math.abs(actionMasked) >= nestedScrollView.mMinimumVelocity) {
                    if (EdgeEffectCompat.getDistance(nestedScrollView.mEdgeGlowTop) != 0.0f) {
                        nestedScrollView.mEdgeGlowTop.onAbsorb(actionMasked);
                    } else if (EdgeEffectCompat.getDistance(nestedScrollView.mEdgeGlowBottom) != 0.0f) {
                        nestedScrollView.mEdgeGlowBottom.onAbsorb(-actionMasked);
                    } else {
                        actionMasked = -actionMasked;
                        f2 = (float) actionMasked;
                        if (!dispatchNestedPreFling(0.0f, f2)) {
                            dispatchNestedFling(0.0f, f2, true);
                            fling(actionMasked);
                        }
                    }
                } else if (nestedScrollView.mScroller.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    ViewCompat.postInvalidateOnAnimation(this);
                }
                nestedScrollView.mActivePointerId = -1;
                endDrag();
                break;
            case 2:
                int findPointerIndex = motionEvent2.findPointerIndex(nestedScrollView.mActivePointerId);
                if (findPointerIndex != -1) {
                    int round;
                    ViewParent parent2;
                    int i;
                    int scrollRange;
                    Object obj;
                    Object obj2;
                    int[] iArr;
                    int y = (int) motionEvent2.getY(findPointerIndex);
                    actionMasked = nestedScrollView.mLastMotionY - y;
                    float x = motionEvent2.getX(findPointerIndex) / ((float) getWidth());
                    f2 = ((float) actionMasked) / ((float) getHeight());
                    if (EdgeEffectCompat.getDistance(nestedScrollView.mEdgeGlowTop) != 0.0f) {
                        x = -EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowTop, -f2, x);
                        if (EdgeEffectCompat.getDistance(nestedScrollView.mEdgeGlowTop) == 0.0f) {
                            nestedScrollView.mEdgeGlowTop.onRelease();
                        }
                    } else if (EdgeEffectCompat.getDistance(nestedScrollView.mEdgeGlowBottom) != 0.0f) {
                        x = EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowBottom, f2, 1.0f - x);
                        if (EdgeEffectCompat.getDistance(nestedScrollView.mEdgeGlowBottom) == 0.0f) {
                            nestedScrollView.mEdgeGlowBottom.onRelease();
                        }
                    } else {
                        round = Math.round(f * ((float) getHeight()));
                        if (round != 0) {
                            invalidate();
                        }
                        actionMasked -= round;
                        if (!nestedScrollView.mIsBeingDragged && Math.abs(actionMasked) > nestedScrollView.mTouchSlop) {
                            parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            nestedScrollView.mIsBeingDragged = true;
                            if (actionMasked > 0) {
                                i = actionMasked + nestedScrollView.mTouchSlop;
                                if (nestedScrollView.mIsBeingDragged) {
                                    if (dispatchNestedPreScroll(0, i, nestedScrollView.mScrollConsumed, nestedScrollView.mScrollOffset, 0)) {
                                        i -= nestedScrollView.mScrollConsumed[1];
                                        nestedScrollView.mNestedYOffset += nestedScrollView.mScrollOffset[1];
                                    }
                                    nestedScrollView.mLastMotionY = y - nestedScrollView.mScrollOffset[1];
                                    y = getScrollY();
                                    scrollRange = getScrollRange();
                                    actionMasked = getOverScrollMode();
                                    obj = actionMasked == 0 ? (actionMasked == 1 || scrollRange <= 0) ? null : 1 : 1;
                                    obj2 = (overScrollByCompat$ar$ds(i, 0, getScrollY(), scrollRange) || hasNestedScrollingParent(0)) ? null : 1;
                                    round = getScrollY() - y;
                                    iArr = nestedScrollView.mScrollConsumed;
                                    iArr[1] = 0;
                                    dispatchNestedScroll$ar$ds(round, i - round, nestedScrollView.mScrollOffset, 0, iArr);
                                    actionMasked = nestedScrollView.mLastMotionY;
                                    round = nestedScrollView.mScrollOffset[1];
                                    nestedScrollView.mLastMotionY = actionMasked - round;
                                    nestedScrollView.mNestedYOffset += round;
                                    if (obj != null) {
                                        i -= nestedScrollView.mScrollConsumed[1];
                                        y += i;
                                        if (y >= 0) {
                                            EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowTop, ((float) (-i)) / ((float) getHeight()), motionEvent2.getX(findPointerIndex) / ((float) getWidth()));
                                            if (!nestedScrollView.mEdgeGlowBottom.isFinished()) {
                                                nestedScrollView.mEdgeGlowBottom.onRelease();
                                            }
                                        } else if (y > scrollRange) {
                                            EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowBottom, ((float) i) / ((float) getHeight()), 1.0f - (motionEvent2.getX(findPointerIndex) / ((float) getWidth())));
                                            if (!nestedScrollView.mEdgeGlowTop.isFinished()) {
                                                nestedScrollView.mEdgeGlowTop.onRelease();
                                            }
                                        }
                                        if (!(nestedScrollView.mEdgeGlowTop.isFinished() && nestedScrollView.mEdgeGlowBottom.isFinished())) {
                                            ViewCompat.postInvalidateOnAnimation(this);
                                            break;
                                        }
                                    }
                                    if (obj2 != null) {
                                        nestedScrollView.mVelocityTracker.clear();
                                        break;
                                    }
                                }
                            }
                            actionMasked -= nestedScrollView.mTouchSlop;
                        }
                        i = actionMasked;
                        if (nestedScrollView.mIsBeingDragged) {
                            if (dispatchNestedPreScroll(0, i, nestedScrollView.mScrollConsumed, nestedScrollView.mScrollOffset, 0)) {
                                i -= nestedScrollView.mScrollConsumed[1];
                                nestedScrollView.mNestedYOffset += nestedScrollView.mScrollOffset[1];
                            }
                            nestedScrollView.mLastMotionY = y - nestedScrollView.mScrollOffset[1];
                            y = getScrollY();
                            scrollRange = getScrollRange();
                            actionMasked = getOverScrollMode();
                            if (actionMasked == 0) {
                            }
                            if (overScrollByCompat$ar$ds(i, 0, getScrollY(), scrollRange)) {
                                break;
                            }
                            round = getScrollY() - y;
                            iArr = nestedScrollView.mScrollConsumed;
                            iArr[1] = 0;
                            dispatchNestedScroll$ar$ds(round, i - round, nestedScrollView.mScrollOffset, 0, iArr);
                            actionMasked = nestedScrollView.mLastMotionY;
                            round = nestedScrollView.mScrollOffset[1];
                            nestedScrollView.mLastMotionY = actionMasked - round;
                            nestedScrollView.mNestedYOffset += round;
                            if (obj != null) {
                                i -= nestedScrollView.mScrollConsumed[1];
                                y += i;
                                if (y >= 0) {
                                    EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowTop, ((float) (-i)) / ((float) getHeight()), motionEvent2.getX(findPointerIndex) / ((float) getWidth()));
                                    if (nestedScrollView.mEdgeGlowBottom.isFinished()) {
                                        nestedScrollView.mEdgeGlowBottom.onRelease();
                                    }
                                } else if (y > scrollRange) {
                                    EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowBottom, ((float) i) / ((float) getHeight()), 1.0f - (motionEvent2.getX(findPointerIndex) / ((float) getWidth())));
                                    if (nestedScrollView.mEdgeGlowTop.isFinished()) {
                                        nestedScrollView.mEdgeGlowTop.onRelease();
                                    }
                                }
                                ViewCompat.postInvalidateOnAnimation(this);
                            }
                            if (obj2 != null) {
                                nestedScrollView.mVelocityTracker.clear();
                            }
                        }
                    }
                    f = x;
                    round = Math.round(f * ((float) getHeight()));
                    if (round != 0) {
                        invalidate();
                    }
                    actionMasked -= round;
                    parent2 = getParent();
                    if (parent2 != null) {
                        parent2.requestDisallowInterceptTouchEvent(true);
                    }
                    nestedScrollView.mIsBeingDragged = true;
                    if (actionMasked > 0) {
                        i = actionMasked + nestedScrollView.mTouchSlop;
                        if (nestedScrollView.mIsBeingDragged) {
                            if (dispatchNestedPreScroll(0, i, nestedScrollView.mScrollConsumed, nestedScrollView.mScrollOffset, 0)) {
                                i -= nestedScrollView.mScrollConsumed[1];
                                nestedScrollView.mNestedYOffset += nestedScrollView.mScrollOffset[1];
                            }
                            nestedScrollView.mLastMotionY = y - nestedScrollView.mScrollOffset[1];
                            y = getScrollY();
                            scrollRange = getScrollRange();
                            actionMasked = getOverScrollMode();
                            if (actionMasked == 0) {
                                if (actionMasked == 1) {
                                }
                            }
                            if (overScrollByCompat$ar$ds(i, 0, getScrollY(), scrollRange)) {
                            }
                            round = getScrollY() - y;
                            iArr = nestedScrollView.mScrollConsumed;
                            iArr[1] = 0;
                            dispatchNestedScroll$ar$ds(round, i - round, nestedScrollView.mScrollOffset, 0, iArr);
                            actionMasked = nestedScrollView.mLastMotionY;
                            round = nestedScrollView.mScrollOffset[1];
                            nestedScrollView.mLastMotionY = actionMasked - round;
                            nestedScrollView.mNestedYOffset += round;
                            if (obj != null) {
                                i -= nestedScrollView.mScrollConsumed[1];
                                y += i;
                                if (y >= 0) {
                                    EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowTop, ((float) (-i)) / ((float) getHeight()), motionEvent2.getX(findPointerIndex) / ((float) getWidth()));
                                    if (nestedScrollView.mEdgeGlowBottom.isFinished()) {
                                        nestedScrollView.mEdgeGlowBottom.onRelease();
                                    }
                                } else if (y > scrollRange) {
                                    EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowBottom, ((float) i) / ((float) getHeight()), 1.0f - (motionEvent2.getX(findPointerIndex) / ((float) getWidth())));
                                    if (nestedScrollView.mEdgeGlowTop.isFinished()) {
                                        nestedScrollView.mEdgeGlowTop.onRelease();
                                    }
                                }
                                ViewCompat.postInvalidateOnAnimation(this);
                            }
                            if (obj2 != null) {
                                nestedScrollView.mVelocityTracker.clear();
                            }
                        }
                    } else {
                        actionMasked -= nestedScrollView.mTouchSlop;
                        i = actionMasked;
                        if (nestedScrollView.mIsBeingDragged) {
                            if (dispatchNestedPreScroll(0, i, nestedScrollView.mScrollConsumed, nestedScrollView.mScrollOffset, 0)) {
                                i -= nestedScrollView.mScrollConsumed[1];
                                nestedScrollView.mNestedYOffset += nestedScrollView.mScrollOffset[1];
                            }
                            nestedScrollView.mLastMotionY = y - nestedScrollView.mScrollOffset[1];
                            y = getScrollY();
                            scrollRange = getScrollRange();
                            actionMasked = getOverScrollMode();
                            if (actionMasked == 0) {
                            }
                            if (overScrollByCompat$ar$ds(i, 0, getScrollY(), scrollRange)) {
                            }
                            round = getScrollY() - y;
                            iArr = nestedScrollView.mScrollConsumed;
                            iArr[1] = 0;
                            dispatchNestedScroll$ar$ds(round, i - round, nestedScrollView.mScrollOffset, 0, iArr);
                            actionMasked = nestedScrollView.mLastMotionY;
                            round = nestedScrollView.mScrollOffset[1];
                            nestedScrollView.mLastMotionY = actionMasked - round;
                            nestedScrollView.mNestedYOffset += round;
                            if (obj != null) {
                                i -= nestedScrollView.mScrollConsumed[1];
                                y += i;
                                if (y >= 0) {
                                    EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowTop, ((float) (-i)) / ((float) getHeight()), motionEvent2.getX(findPointerIndex) / ((float) getWidth()));
                                    if (nestedScrollView.mEdgeGlowBottom.isFinished()) {
                                        nestedScrollView.mEdgeGlowBottom.onRelease();
                                    }
                                } else if (y > scrollRange) {
                                    EdgeEffectCompat.onPullDistance(nestedScrollView.mEdgeGlowBottom, ((float) i) / ((float) getHeight()), 1.0f - (motionEvent2.getX(findPointerIndex) / ((float) getWidth())));
                                    if (nestedScrollView.mEdgeGlowTop.isFinished()) {
                                        nestedScrollView.mEdgeGlowTop.onRelease();
                                    }
                                }
                                ViewCompat.postInvalidateOnAnimation(this);
                            }
                            if (obj2 != null) {
                                nestedScrollView.mVelocityTracker.clear();
                            }
                        }
                    }
                    break;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid pointerId=");
                stringBuilder.append(nestedScrollView.mActivePointerId);
                stringBuilder.append(" in onTouchEvent");
                Log.e("NestedScrollView", stringBuilder.toString());
                break;
                break;
            case 3:
                if (nestedScrollView.mIsBeingDragged && getChildCount() > 0 && nestedScrollView.mScroller.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    ViewCompat.postInvalidateOnAnimation(this);
                }
                nestedScrollView.mActivePointerId = -1;
                endDrag();
                break;
            case 5:
                actionMasked = motionEvent.getActionIndex();
                nestedScrollView.mLastMotionY = (int) motionEvent2.getY(actionMasked);
                nestedScrollView.mActivePointerId = motionEvent2.getPointerId(actionMasked);
                break;
            case 6:
                onSecondaryPointerUp(motionEvent);
                nestedScrollView.mLastMotionY = (int) motionEvent2.getY(motionEvent2.findPointerIndex(nestedScrollView.mActivePointerId));
                break;
            default:
                break;
        }
        velocityTracker = nestedScrollView.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.addMovement(obtain);
        }
        obtain.recycle();
        return true;
    }

    final boolean overScrollByCompat$ar$ds(int i, int i2, int i3, int i4) {
        Object obj;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        i3 += i;
        Object obj2 = i2 > 0 ? 1 : i2 < 0 ? 1 : null;
        if (i3 > i4) {
            obj = 1;
        } else if (i3 < 0) {
            obj = 1;
            i4 = 0;
        } else {
            i4 = i3;
            obj = null;
        }
        if (!(obj == null || hasNestedScrollingParent(1))) {
            this.mScroller.springBack(0, i4, 0, 0, 0, getScrollRange());
        }
        super.scrollTo(0, i4);
        if (obj2 == null) {
            if (obj == null) {
                return false;
            }
        }
        return true;
    }

    public final void requestChildFocus(View view, View view2) {
        if (this.mIsLayoutDirty) {
            this.mChildToScrollTo = view2;
        } else {
            scrollToChild(view2);
        }
        super.requestChildFocus(view, view2);
    }

    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        boolean z2;
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int computeScrollDeltaToGetChildRectOnScreen = computeScrollDeltaToGetChildRectOnScreen(rect);
        if (computeScrollDeltaToGetChildRectOnScreen != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2) {
            if (z) {
                scrollBy(0, computeScrollDeltaToGetChildRectOnScreen);
            } else {
                smoothScrollBy$ar$ds(computeScrollDeltaToGetChildRectOnScreen);
            }
        }
        return z2;
    }

    public final void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            recycleVelocityTracker();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public final void requestLayout() {
        this.mIsLayoutDirty = true;
        super.requestLayout();
    }

    public final void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            i = NestedScrollView.clamp(i, (getWidth() - getPaddingLeft()) - getPaddingRight(), (childAt.getWidth() + layoutParams.leftMargin) + layoutParams.rightMargin);
            i2 = NestedScrollView.clamp(i2, (getHeight() - getPaddingTop()) - getPaddingBottom(), (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin);
            if (i != getScrollX() || i2 != getScrollY()) {
                super.scrollTo(i, i2);
            }
        }
    }

    public final void setNestedScrollingEnabled(boolean z) {
        this.mChildHelper.setNestedScrollingEnabled(z);
    }

    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    public final void smoothScrollBy$ar$ds(int i) {
        smoothScrollBy$ar$ds$c0e3f38_0(0, i, false);
    }

    public final boolean startNestedScroll(int i) {
        return startNestedScroll(i, 0);
    }

    public final void stopNestedScroll() {
        stopNestedScroll(0);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.nestedScrollViewStyle);
    }

    public final boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return this.mChildHelper.dispatchNestedPreScroll(i, i2, iArr, iArr2, i3);
    }

    public final boolean hasNestedScrollingParent(int i) {
        return this.mChildHelper.hasNestedScrollingParent(i);
    }

    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5) {
        onNestedScrollInternal(i4, i5, null);
    }

    public final void onNestedScrollAccepted(View view, View view2, int i, int i2) {
        this.mParentHelper.onNestedScrollAccepted$ar$ds(i, i2);
        startNestedScroll(2, i2);
    }

    public final void onStopNestedScroll(View view, int i) {
        this.mParentHelper.onStopNestedScroll$ar$ds(i);
        stopNestedScroll(i);
    }

    final void smoothScrollTo$ar$ds(int i) {
        smoothScrollBy$ar$ds$c0e3f38_0(-getScrollX(), i - getScrollY(), true);
    }

    public final boolean startNestedScroll(int i, int i2) {
        return this.mChildHelper.startNestedScroll(i, i2);
    }

    public final void stopNestedScroll(int i) {
        this.mChildHelper.stopNestedScroll(i);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mTempRect = new Rect();
        this.mIsLayoutDirty = true;
        this.mIsLaidOut = false;
        this.mChildToScrollTo = null;
        this.mIsBeingDragged = false;
        this.mSmoothScrollingEnabled = true;
        this.mActivePointerId = -1;
        this.mScrollOffset = new int[2];
        this.mScrollConsumed = new int[2];
        this.mEdgeGlowTop = EdgeEffectCompat.create(context, attributeSet);
        this.mEdgeGlowBottom = EdgeEffectCompat.create(context, attributeSet);
        this.mScroller = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.mMinimumVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
        this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, SCROLLVIEW_STYLEABLE, i, 0);
        boolean z = obtainStyledAttributes.getBoolean(0, false);
        if (z != this.mFillViewport) {
            this.mFillViewport = z;
            requestLayout();
        }
        obtainStyledAttributes.recycle();
        this.mParentHelper = new NestedScrollingParentHelper();
        this.mChildHelper = new NestedScrollingChildHelper(this);
        setNestedScrollingEnabled(true);
        ViewCompat.setAccessibilityDelegate(this, ACCESSIBILITY_DELEGATE);
    }

    public final void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        onNestedScrollInternal(i4, i5, iArr);
    }

    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
