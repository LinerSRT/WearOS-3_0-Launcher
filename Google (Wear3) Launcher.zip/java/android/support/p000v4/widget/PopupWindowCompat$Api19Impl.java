package android.support.p000v4.widget;

import android.view.View;
import android.widget.PopupWindow;

/* compiled from: PG */
/* renamed from: android.support.v4.widget.PopupWindowCompat$Api19Impl */
public final class PopupWindowCompat$Api19Impl {
    public static void showAsDropDown(PopupWindow popupWindow, View view, int i, int i2, int i3) {
        popupWindow.showAsDropDown(view, i, i2, i3);
    }
}
