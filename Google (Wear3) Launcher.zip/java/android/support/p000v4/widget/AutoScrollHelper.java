package android.support.p000v4.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.support.p000v4.view.ViewCompat;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

/* compiled from: PG */
/* renamed from: android.support.v4.widget.AutoScrollHelper */
public abstract class AutoScrollHelper implements OnTouchListener {
    private static final int DEFAULT_ACTIVATION_DELAY = ViewConfiguration.getTapTimeout();
    private final int mActivationDelay;
    private boolean mAlreadyDelayed;
    boolean mAnimating;
    private final Interpolator mEdgeInterpolator = new AccelerateInterpolator();
    private boolean mEnabled;
    private final float[] mMaximumEdges;
    private final float[] mMaximumVelocity;
    private final float[] mMinimumVelocity;
    boolean mNeedsCancel;
    boolean mNeedsReset;
    private final float[] mRelativeEdges;
    private final float[] mRelativeVelocity;
    private Runnable mRunnable;
    final ClampedScroller mScroller;
    final View mTarget;

    /* compiled from: PG */
    /* renamed from: android.support.v4.widget.AutoScrollHelper$ClampedScroller */
    final class ClampedScroller {
        public long mDeltaTime = 0;
        public int mEffectiveRampDown;
        public int mRampDownDuration;
        public int mRampUpDuration;
        public long mStartTime = Long.MIN_VALUE;
        public long mStopTime = -1;
        public float mStopValue;
        public float mTargetVelocityX;
        public float mTargetVelocityY;

        public final float getValueAt(long j) {
            long j2 = this.mStartTime;
            if (j < j2) {
                return 0.0f;
            }
            long j3 = this.mStopTime;
            if (j3 >= 0) {
                if (j >= j3) {
                    float f = this.mStopValue;
                    return (1.0f - f) + (f * AutoScrollHelper.constrain(((float) (j - j3)) / ((float) this.mEffectiveRampDown), 0.0f, 1.0f));
                }
            }
            return AutoScrollHelper.constrain(((float) (j - j2)) / ((float) this.mRampUpDuration), 0.0f, 1.0f) * 0.5f;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.widget.AutoScrollHelper$ScrollAnimationRunnable */
    final class ScrollAnimationRunnable implements Runnable {
        public final void run() {
            AutoScrollHelper autoScrollHelper = AutoScrollHelper.this;
            if (autoScrollHelper.mAnimating) {
                ClampedScroller clampedScroller;
                if (autoScrollHelper.mNeedsReset) {
                    autoScrollHelper.mNeedsReset = false;
                    clampedScroller = autoScrollHelper.mScroller;
                    long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                    clampedScroller.mStartTime = currentAnimationTimeMillis;
                    clampedScroller.mStopTime = -1;
                    clampedScroller.mDeltaTime = currentAnimationTimeMillis;
                    clampedScroller.mStopValue = 0.5f;
                }
                clampedScroller = AutoScrollHelper.this.mScroller;
                if ((clampedScroller.mStopTime <= 0 || AnimationUtils.currentAnimationTimeMillis() <= clampedScroller.mStopTime + ((long) clampedScroller.mEffectiveRampDown)) && AutoScrollHelper.this.shouldAnimate()) {
                    AutoScrollHelper autoScrollHelper2 = AutoScrollHelper.this;
                    if (autoScrollHelper2.mNeedsCancel) {
                        autoScrollHelper2.mNeedsCancel = false;
                        long uptimeMillis = SystemClock.uptimeMillis();
                        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                        autoScrollHelper2.mTarget.onTouchEvent(obtain);
                        obtain.recycle();
                    }
                    if (clampedScroller.mDeltaTime != 0) {
                        long currentAnimationTimeMillis2 = AnimationUtils.currentAnimationTimeMillis();
                        float valueAt = clampedScroller.getValueAt(currentAnimationTimeMillis2);
                        long j = clampedScroller.mDeltaTime;
                        clampedScroller.mDeltaTime = currentAnimationTimeMillis2;
                        AutoScrollHelper.this.scrollTargetBy$ar$ds((int) ((((float) (currentAnimationTimeMillis2 - j)) * (((-4.0f * valueAt) * valueAt) + (valueAt * 4.0f))) * clampedScroller.mTargetVelocityY));
                        ViewCompat.postOnAnimation(AutoScrollHelper.this.mTarget, this);
                        return;
                    }
                    throw new RuntimeException("Cannot compute scroll delta before calling start()");
                }
                AutoScrollHelper.this.mAnimating = false;
            }
        }
    }

    public AutoScrollHelper(View view) {
        ClampedScroller clampedScroller = new ClampedScroller();
        this.mScroller = clampedScroller;
        float[] fArr = new float[]{0.0f, 0.0f};
        this.mRelativeEdges = fArr;
        float[] fArr2 = new float[]{Float.MAX_VALUE, Float.MAX_VALUE};
        this.mMaximumEdges = fArr2;
        float[] fArr3 = new float[]{0.0f, 0.0f};
        this.mRelativeVelocity = fArr3;
        float[] fArr4 = new float[]{0.0f, 0.0f};
        this.mMinimumVelocity = fArr4;
        float[] fArr5 = new float[]{Float.MAX_VALUE, Float.MAX_VALUE};
        this.mMaximumVelocity = fArr5;
        this.mTarget = view;
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        float f = displayMetrics.density;
        float f2 = displayMetrics.density;
        f = ((float) ((int) ((f * 1575.0f) + 0.5f))) / 1000.0f;
        fArr5[0] = f;
        fArr5[1] = f;
        f2 = ((float) ((int) ((f2 * 315.0f) + 0.5f))) / 1000.0f;
        fArr4[0] = f2;
        fArr4[1] = f2;
        fArr2[0] = Float.MAX_VALUE;
        fArr2[1] = Float.MAX_VALUE;
        fArr[0] = 0.2f;
        fArr[1] = 0.2f;
        fArr3[0] = 0.001f;
        fArr3[1] = 0.001f;
        this.mActivationDelay = DEFAULT_ACTIVATION_DELAY;
        clampedScroller.mRampUpDuration = 500;
        clampedScroller.mRampDownDuration = 500;
    }

    static float constrain(float f, float f2, float f3) {
        return f > f3 ? f3 : f < f2 ? f2 : f;
    }

    private final float constrainEdgeValue(float f, float f2) {
        if (f2 != 0.0f && f < f2) {
            if (f >= 0.0f) {
                return 1.0f - (f / f2);
            }
            if (this.mAnimating) {
                return 1.0f;
            }
        }
        return 0.0f;
    }

    public abstract boolean canTargetScrollVertically(int i);

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.mEnabled) {
            return false;
        }
        switch (motionEvent.getActionMasked()) {
            case 0:
                this.mNeedsCancel = true;
                this.mAlreadyDelayed = false;
                break;
            case 1:
            case 3:
                requestStop();
                break;
            case 2:
                break;
            default:
                break;
        }
        float computeTargetVelocity = computeTargetVelocity(0, motionEvent.getX(), (float) view.getWidth(), (float) this.mTarget.getWidth());
        float computeTargetVelocity2 = computeTargetVelocity(1, motionEvent.getY(), (float) view.getHeight(), (float) this.mTarget.getHeight());
        ClampedScroller clampedScroller = this.mScroller;
        clampedScroller.mTargetVelocityX = computeTargetVelocity;
        clampedScroller.mTargetVelocityY = computeTargetVelocity2;
        if (!this.mAnimating && shouldAnimate()) {
            if (this.mRunnable == null) {
                this.mRunnable = new ScrollAnimationRunnable();
            }
            this.mAnimating = true;
            this.mNeedsReset = true;
            if (!this.mAlreadyDelayed) {
                int i = this.mActivationDelay;
                if (i > 0) {
                    ViewCompat.postOnAnimationDelayed(this.mTarget, this.mRunnable, (long) i);
                    this.mAlreadyDelayed = true;
                }
            }
            this.mRunnable.run();
            this.mAlreadyDelayed = true;
        }
        return false;
    }

    public abstract void scrollTargetBy$ar$ds(int i);

    public final void setEnabled$ar$ds(boolean z) {
        if (this.mEnabled && !z) {
            requestStop();
        }
        this.mEnabled = z;
    }

    private final float computeTargetVelocity(int i, float f, float f2, float f3) {
        float constrain = AutoScrollHelper.constrain(this.mRelativeEdges[i] * f2, 0.0f, this.mMaximumEdges[i]);
        f = constrainEdgeValue(f2 - f, constrain) - constrainEdgeValue(f, constrain);
        if (f < 0.0f) {
            f = -this.mEdgeInterpolator.getInterpolation(-f);
        } else if (f > 0.0f) {
            f = this.mEdgeInterpolator.getInterpolation(f);
        } else {
            f = 0.0f;
            if (f == 0.0f) {
                return 0.0f;
            }
            f2 = this.mRelativeVelocity[i];
            constrain = this.mMinimumVelocity[i];
            float f4 = this.mMaximumVelocity[i];
            f2 *= f3;
            return f <= 0.0f ? AutoScrollHelper.constrain(f * f2, constrain, f4) : -AutoScrollHelper.constrain((-f) * f2, constrain, f4);
        }
        f = AutoScrollHelper.constrain(f, -1.0f, 1.0f);
        if (f == 0.0f) {
            return 0.0f;
        }
        f2 = this.mRelativeVelocity[i];
        constrain = this.mMinimumVelocity[i];
        float f42 = this.mMaximumVelocity[i];
        f2 *= f3;
        if (f <= 0.0f) {
        }
    }

    private final void requestStop() {
        int i = 0;
        if (this.mNeedsReset) {
            this.mAnimating = false;
            return;
        }
        ClampedScroller clampedScroller = this.mScroller;
        long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
        int i2 = (int) (currentAnimationTimeMillis - clampedScroller.mStartTime);
        int i3 = clampedScroller.mRampDownDuration;
        if (i2 > i3) {
            i = i3;
        } else if (i2 >= 0) {
            i = i2;
        }
        clampedScroller.mEffectiveRampDown = i;
        clampedScroller.mStopValue = clampedScroller.getValueAt(currentAnimationTimeMillis);
        clampedScroller.mStopTime = currentAnimationTimeMillis;
    }

    final boolean shouldAnimate() {
        ClampedScroller clampedScroller = this.mScroller;
        float f = clampedScroller.mTargetVelocityY;
        int abs = (int) (f / Math.abs(f));
        float f2 = clampedScroller.mTargetVelocityX;
        int abs2 = (int) (f2 / Math.abs(f2));
        if (abs != 0) {
            if (canTargetScrollVertically(abs)) {
                return true;
            }
        }
        return abs2 == 0 ? false : false;
    }
}
