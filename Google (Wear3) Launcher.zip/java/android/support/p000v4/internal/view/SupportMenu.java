package android.support.p000v4.internal.view;

import android.view.Menu;

/* compiled from: PG */
/* renamed from: android.support.v4.internal.view.SupportMenu */
public interface SupportMenu extends Menu {
}
