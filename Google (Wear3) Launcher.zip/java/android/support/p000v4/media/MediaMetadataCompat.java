package android.support.p000v4.media;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p000v4.media.session.MediaSessionCompat;
import androidx.collection.ArrayMap;
import androidx.collection.SimpleArrayMap;

/* compiled from: PG */
/* renamed from: android.support.v4.media.MediaMetadataCompat */
public final class MediaMetadataCompat implements Parcelable {
    public static final Creator CREATOR = new PG();
    static final ArrayMap METADATA_KEYS_TYPE;
    final Bundle mBundle;

    /* renamed from: android.support.v4.media.MediaMetadataCompat$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new MediaMetadataCompat[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new MediaMetadataCompat(parcel);
        }
    }

    static {
        SimpleArrayMap arrayMap = new ArrayMap();
        METADATA_KEYS_TYPE = arrayMap;
        Integer valueOf = Integer.valueOf(1);
        arrayMap.put("android.media.metadata.TITLE", valueOf);
        arrayMap.put("android.media.metadata.ARTIST", valueOf);
        Integer valueOf2 = Integer.valueOf(0);
        arrayMap.put("android.media.metadata.DURATION", valueOf2);
        arrayMap.put("android.media.metadata.ALBUM", valueOf);
        arrayMap.put("android.media.metadata.AUTHOR", valueOf);
        arrayMap.put("android.media.metadata.WRITER", valueOf);
        arrayMap.put("android.media.metadata.COMPOSER", valueOf);
        arrayMap.put("android.media.metadata.COMPILATION", valueOf);
        arrayMap.put("android.media.metadata.DATE", valueOf);
        arrayMap.put("android.media.metadata.YEAR", valueOf2);
        arrayMap.put("android.media.metadata.GENRE", valueOf);
        arrayMap.put("android.media.metadata.TRACK_NUMBER", valueOf2);
        arrayMap.put("android.media.metadata.NUM_TRACKS", valueOf2);
        arrayMap.put("android.media.metadata.DISC_NUMBER", valueOf2);
        arrayMap.put("android.media.metadata.ALBUM_ARTIST", valueOf);
        Integer valueOf3 = Integer.valueOf(2);
        arrayMap.put("android.media.metadata.ART", valueOf3);
        arrayMap.put("android.media.metadata.ART_URI", valueOf);
        arrayMap.put("android.media.metadata.ALBUM_ART", valueOf3);
        arrayMap.put("android.media.metadata.ALBUM_ART_URI", valueOf);
        Integer valueOf4 = Integer.valueOf(3);
        arrayMap.put("android.media.metadata.USER_RATING", valueOf4);
        arrayMap.put("android.media.metadata.RATING", valueOf4);
        arrayMap.put("android.media.metadata.DISPLAY_TITLE", valueOf);
        arrayMap.put("android.media.metadata.DISPLAY_SUBTITLE", valueOf);
        arrayMap.put("android.media.metadata.DISPLAY_DESCRIPTION", valueOf);
        arrayMap.put("android.media.metadata.DISPLAY_ICON", valueOf3);
        arrayMap.put("android.media.metadata.DISPLAY_ICON_URI", valueOf);
        arrayMap.put("android.media.metadata.MEDIA_ID", valueOf);
        arrayMap.put("android.media.metadata.BT_FOLDER_TYPE", valueOf2);
        arrayMap.put("android.media.metadata.MEDIA_URI", valueOf);
        arrayMap.put("android.media.metadata.ADVERTISEMENT", valueOf2);
        arrayMap.put("android.media.metadata.DOWNLOAD_STATUS", valueOf2);
    }

    public MediaMetadataCompat(Parcel parcel) {
        this.mBundle = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeBundle(this.mBundle);
    }
}
