package android.support.p000v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.media.MediaDescription.Builder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p000v4.media.session.MediaSessionCompat;

/* compiled from: PG */
/* renamed from: android.support.v4.media.MediaDescriptionCompat */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Creator CREATOR = new PG();
    private final CharSequence mDescription;
    public MediaDescription mDescriptionFwk;
    private final Bundle mExtras;
    private final Bitmap mIcon;
    private final Uri mIconUri;
    private final String mMediaId;
    private final Uri mMediaUri;
    private final CharSequence mSubtitle;
    private final CharSequence mTitle;

    /* renamed from: android.support.v4.media.MediaDescriptionCompat$1 */
    final class PG implements Creator {
        public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
            return new MediaDescriptionCompat[i];
        }

        public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
            Object createFromParcel = MediaDescription.CREATOR.createFromParcel(parcel);
            Bundle bundle = null;
            if (createFromParcel == null) {
                return null;
            }
            Uri uri;
            MediaDescriptionCompat mediaDescriptionCompat;
            Builder builder = new Builder();
            MediaDescription mediaDescription = (MediaDescription) createFromParcel;
            builder.mMediaId = Api21Impl.getMediaId(mediaDescription);
            builder.mTitle = Api21Impl.getTitle(mediaDescription);
            builder.mSubtitle = Api21Impl.getSubtitle(mediaDescription);
            builder.mDescription = Api21Impl.getDescription(mediaDescription);
            builder.mIcon = Api21Impl.getIconBitmap(mediaDescription);
            builder.mIconUri = Api21Impl.getIconUri(mediaDescription);
            Bundle extras = Api21Impl.getExtras(mediaDescription);
            if (extras != null) {
                extras = MediaSessionCompat.unparcelWithClassLoader(extras);
            }
            String str = "android.support.v4.media.description.MEDIA_URI";
            if (extras != null) {
                uri = (Uri) extras.getParcelable(str);
            } else {
                uri = null;
            }
            if (uri != null) {
                String str2 = "android.support.v4.media.description.NULL_BUNDLE_FLAG";
                if (extras.containsKey(str2) && extras.size() == 2) {
                    builder.mExtras = bundle;
                    if (uri == null) {
                        builder.mMediaUri = uri;
                    } else {
                        builder.mMediaUri = Api23Impl.getMediaUri(mediaDescription);
                    }
                    mediaDescriptionCompat = new MediaDescriptionCompat(builder.mMediaId, builder.mTitle, builder.mSubtitle, builder.mDescription, builder.mIcon, builder.mIconUri, builder.mExtras, builder.mMediaUri);
                    mediaDescriptionCompat.mDescriptionFwk = mediaDescription;
                    return mediaDescriptionCompat;
                }
                extras.remove(str);
                extras.remove(str2);
            }
            bundle = extras;
            builder.mExtras = bundle;
            if (uri == null) {
                builder.mMediaUri = Api23Impl.getMediaUri(mediaDescription);
            } else {
                builder.mMediaUri = uri;
            }
            mediaDescriptionCompat = new MediaDescriptionCompat(builder.mMediaId, builder.mTitle, builder.mSubtitle, builder.mDescription, builder.mIcon, builder.mIconUri, builder.mExtras, builder.mMediaUri);
            mediaDescriptionCompat.mDescriptionFwk = mediaDescription;
            return mediaDescriptionCompat;
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.media.MediaDescriptionCompat$Api21Impl */
    final class Api21Impl {
        static MediaDescription build(Builder builder) {
            return builder.build();
        }

        static Builder createBuilder() {
            return new Builder();
        }

        static CharSequence getDescription(MediaDescription mediaDescription) {
            return mediaDescription.getDescription();
        }

        static Bundle getExtras(MediaDescription mediaDescription) {
            return mediaDescription.getExtras();
        }

        static Bitmap getIconBitmap(MediaDescription mediaDescription) {
            return mediaDescription.getIconBitmap();
        }

        static Uri getIconUri(MediaDescription mediaDescription) {
            return mediaDescription.getIconUri();
        }

        static String getMediaId(MediaDescription mediaDescription) {
            return mediaDescription.getMediaId();
        }

        static CharSequence getSubtitle(MediaDescription mediaDescription) {
            return mediaDescription.getSubtitle();
        }

        static CharSequence getTitle(MediaDescription mediaDescription) {
            return mediaDescription.getTitle();
        }

        static void setDescription(Builder builder, CharSequence charSequence) {
            builder.setDescription(charSequence);
        }

        static void setExtras(Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }

        static void setIconBitmap(Builder builder, Bitmap bitmap) {
            builder.setIconBitmap(bitmap);
        }

        static void setIconUri(Builder builder, Uri uri) {
            builder.setIconUri(uri);
        }

        static void setMediaId(Builder builder, String str) {
            builder.setMediaId(str);
        }

        static void setSubtitle(Builder builder, CharSequence charSequence) {
            builder.setSubtitle(charSequence);
        }

        static void setTitle(Builder builder, CharSequence charSequence) {
            builder.setTitle(charSequence);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.media.MediaDescriptionCompat$Api23Impl */
    final class Api23Impl {
        static Uri getMediaUri(MediaDescription mediaDescription) {
            return mediaDescription.getMediaUri();
        }

        static void setMediaUri(Builder builder, Uri uri) {
            builder.setMediaUri(uri);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.media.MediaDescriptionCompat$Builder */
    public final class Builder {
        public CharSequence mDescription;
        public Bundle mExtras;
        public Bitmap mIcon;
        public Uri mIconUri;
        public String mMediaId;
        public Uri mMediaUri;
        public CharSequence mSubtitle;
        public CharSequence mTitle;
    }

    public MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.mMediaId = str;
        this.mTitle = charSequence;
        this.mSubtitle = charSequence2;
        this.mDescription = charSequence3;
        this.mIcon = bitmap;
        this.mIconUri = uri;
        this.mExtras = bundle;
        this.mMediaUri = uri2;
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.mTitle);
        String str = ", ";
        stringBuilder.append(str);
        stringBuilder.append(this.mSubtitle);
        stringBuilder.append(str);
        stringBuilder.append(this.mDescription);
        return stringBuilder.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        MediaDescription mediaDescription = this.mDescriptionFwk;
        if (mediaDescription == null) {
            Builder createBuilder = Api21Impl.createBuilder();
            Api21Impl.setMediaId(createBuilder, this.mMediaId);
            Api21Impl.setTitle(createBuilder, this.mTitle);
            Api21Impl.setSubtitle(createBuilder, this.mSubtitle);
            Api21Impl.setDescription(createBuilder, this.mDescription);
            Api21Impl.setIconBitmap(createBuilder, this.mIcon);
            Api21Impl.setIconUri(createBuilder, this.mIconUri);
            Api21Impl.setExtras(createBuilder, this.mExtras);
            Api23Impl.setMediaUri(createBuilder, this.mMediaUri);
            mediaDescription = Api21Impl.build(createBuilder);
            this.mDescriptionFwk = mediaDescription;
        }
        mediaDescription.writeToParcel(parcel, i);
    }
}
