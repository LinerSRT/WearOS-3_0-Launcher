package android.support.p000v4.media.session;

import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.ResultReceiver;
import android.support.p000v4.media.MediaDescriptionCompat;
import android.util.Log;

/* compiled from: PG */
/* renamed from: android.support.v4.media.session.MediaSessionCompat */
public final class MediaSessionCompat {

    /* compiled from: PG */
    /* renamed from: android.support.v4.media.session.MediaSessionCompat$QueueItem */
    public final class QueueItem implements Parcelable {
        public static final Creator CREATOR = new PG();
        private final MediaDescriptionCompat mDescription;
        private final long mId;

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$QueueItem$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new QueueItem[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new QueueItem(parcel);
            }
        }

        public QueueItem(Parcel parcel) {
            this.mDescription = (MediaDescriptionCompat) MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
            this.mId = parcel.readLong();
        }

        public final int describeContents() {
            return 0;
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("MediaSession.QueueItem {Description=");
            stringBuilder.append(this.mDescription);
            stringBuilder.append(", Id=");
            stringBuilder.append(this.mId);
            stringBuilder.append(" }");
            return stringBuilder.toString();
        }

        public final void writeToParcel(Parcel parcel, int i) {
            this.mDescription.writeToParcel(parcel, i);
            parcel.writeLong(this.mId);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper */
    final class ResultReceiverWrapper implements Parcelable {
        public static final Creator CREATOR = new PG();
        ResultReceiver mResultReceiver;

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new ResultReceiverWrapper[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new ResultReceiverWrapper(parcel);
            }
        }

        public ResultReceiverWrapper(Parcel parcel) {
            this.mResultReceiver = (ResultReceiver) ResultReceiver.CREATOR.createFromParcel(parcel);
        }

        public final int describeContents() {
            return 0;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            this.mResultReceiver.writeToParcel(parcel, i);
        }
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.media.session.MediaSessionCompat$Token */
    public final class Token implements Parcelable {
        public static final Creator CREATOR = new PG();
        private final Object mInner;

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$Token$1 */
        final class PG implements Creator {
            public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
                return new Token[i];
            }

            public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
                return new Token(parcel.readParcelable(null));
            }
        }

        public Token(Object obj) {
            this.mInner = obj;
        }

        public final int describeContents() {
            return 0;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Token)) {
                return false;
            }
            Token token = (Token) obj;
            Object obj2 = this.mInner;
            if (obj2 == null) {
                return token.mInner == null;
            } else {
                obj = token.mInner;
                if (obj == null) {
                    return false;
                }
                return obj2.equals(obj);
            }
        }

        public final int hashCode() {
            Object obj = this.mInner;
            return obj == null ? 0 : obj.hashCode();
        }

        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.mInner, i);
        }
    }

    public static Bundle unparcelWithClassLoader(Bundle bundle) {
        bundle.setClassLoader(MediaSessionCompat.class.getClassLoader());
        try {
            bundle.isEmpty();
            return bundle;
        } catch (BadParcelableException e) {
            Log.e("MediaSessionCompat", "Could not unparcel the data.");
            return null;
        }
    }
}
