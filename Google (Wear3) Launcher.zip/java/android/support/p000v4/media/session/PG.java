package android.support.p000v4.media.session;

import android.os.Bundle;
import android.os.ResultReceiver;

/* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver */
class PG extends ResultReceiver {
    protected final void onReceiveResult(int i, Bundle bundle) {
        throw null;
    }
}
