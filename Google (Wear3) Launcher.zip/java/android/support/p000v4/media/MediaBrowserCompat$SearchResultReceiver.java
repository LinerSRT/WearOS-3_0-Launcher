package android.support.p000v4.media;

import android.support.p000v4.p001os.ResultReceiver;

/* compiled from: PG */
/* renamed from: android.support.v4.media.MediaBrowserCompat$SearchResultReceiver */
class MediaBrowserCompat$SearchResultReceiver extends ResultReceiver {
    protected final void onReceiveResult$ar$ds() {
        throw null;
    }
}
