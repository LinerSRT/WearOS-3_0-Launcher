package android.support.p000v4.util;

/* compiled from: PG */
/* renamed from: android.support.v4.util.Consumer */
public interface Consumer {
    void accept(Object obj);
}
