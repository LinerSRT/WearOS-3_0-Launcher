package android.support.p000v4.util;

import android.text.TextUtils;

/* compiled from: PG */
/* renamed from: android.support.v4.util.Preconditions */
public final class Preconditions {
    public static void checkArgument(boolean z, Object obj) {
        if (!z) {
            throw new IllegalArgumentException((String) obj);
        }
    }

    public static void checkArgumentNonnegative$ar$ds(int i) {
        if (i < 0) {
            throw new IllegalArgumentException();
        }
    }

    public static void checkNotNull$ar$ds(Object obj) {
        if (obj == null) {
            throw null;
        }
    }

    public static void checkStringNotEmpty$ar$ds(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            throw new IllegalArgumentException("id cannot be empty");
        }
    }
}
