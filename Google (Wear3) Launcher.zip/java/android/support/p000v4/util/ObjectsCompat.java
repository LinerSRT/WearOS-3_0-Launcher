package android.support.p000v4.util;

/* compiled from: PG */
/* renamed from: android.support.v4.util.ObjectsCompat */
public final class ObjectsCompat {
    public static void requireNonNull$ar$ds(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException(str);
        }
    }
}
