package android.support.p000v4.util;

/* compiled from: PG */
/* renamed from: android.support.v4.util.Pools$SimplePool */
public final class Pools$SimplePool {
    private final Object[] mPool;
    private int mPoolSize;

    public Pools$SimplePool(int i) {
        this.mPool = new Object[i];
    }

    public final Object acquire() {
        int i = this.mPoolSize;
        if (i <= 0) {
            return null;
        }
        i--;
        Object[] objArr = this.mPool;
        Object obj = objArr[i];
        objArr[i] = null;
        this.mPoolSize = i;
        return obj;
    }

    public final boolean release(Object obj) {
        int i = 0;
        while (true) {
            int i2 = this.mPoolSize;
            if (i >= i2) {
                break;
            } else if (this.mPool[i] != obj) {
                i++;
            } else {
                throw new IllegalStateException("Already in the pool!");
            }
        }
        Object[] objArr = this.mPool;
        if (i2 >= objArr.length) {
            return false;
        }
        objArr[i2] = obj;
        this.mPoolSize = i2 + 1;
        return true;
    }
}
