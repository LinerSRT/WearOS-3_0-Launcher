package android.support.p000v4.util;

/* compiled from: PG */
/* renamed from: android.support.v4.util.Pair */
public final class Pair {
    public final Object first;
    public final Object second;

    public final boolean equals(Object obj) {
        throw null;
    }

    public final int hashCode() {
        throw null;
    }

    public final String toString() {
        throw null;
    }
}
