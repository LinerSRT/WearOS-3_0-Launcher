package android.support.p000v4.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.support.p000v4.content.res.ResourcesCompat.FontCallback;
import androidx.collection.LruCache;
import androidx.core.provider.FontsContractCompat$FontRequestCallback;

/* compiled from: PG */
/* renamed from: android.support.v4.graphics.TypefaceCompat */
public final class TypefaceCompat {
    public static final LruCache sTypefaceCache = new LruCache(16);

    /* compiled from: PG */
    /* renamed from: android.support.v4.graphics.TypefaceCompat$ResourcesCallbackAdapter */
    public final class ResourcesCallbackAdapter extends FontsContractCompat$FontRequestCallback {
        public final FontCallback mFontCallback;

        public ResourcesCallbackAdapter(FontCallback fontCallback) {
            this.mFontCallback = fontCallback;
        }
    }

    public static Typeface create(Context context, Typeface typeface, int i) {
        if (context != null) {
            return Typeface.create(typeface, i);
        }
        throw new IllegalArgumentException("Context cannot be null");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.graphics.Typeface createFromResourcesFamilyXml$ar$ds(android.content.Context r7, android.support.p000v4.content.res.FontResourcesParserCompat.FamilyResourceEntry r8, android.content.res.Resources r9, int r10, int r11, android.support.p000v4.content.res.ResourcesCompat.FontCallback r12) {
        /*
        r0 = r8 instanceof android.support.p000v4.content.res.FontResourcesParserCompat.ProviderResourceEntry;
        r1 = 0;
        r2 = 0;
        if (r0 == 0) goto L_0x00f8;
    L_0x0006:
        r8 = (android.support.p000v4.content.res.FontResourcesParserCompat.ProviderResourceEntry) r8;
        r0 = r8.mSystemFontFamilyName;
        if (r0 == 0) goto L_0x0027;
    L_0x000c:
        r3 = r0.isEmpty();
        if (r3 == 0) goto L_0x0014;
    L_0x0012:
        r0 = r2;
        goto L_0x0028;
        r0 = android.graphics.Typeface.create(r0, r1);
        r3 = android.graphics.Typeface.DEFAULT;
        r1 = android.graphics.Typeface.create(r3, r1);
        if (r0 == 0) goto L_0x0027;
    L_0x0021:
        r1 = r0.equals(r1);
        if (r1 == 0) goto L_0x0028;
    L_0x0027:
        r0 = r2;
    L_0x0028:
        if (r0 != 0) goto L_0x00f4;
    L_0x002a:
        r0 = r8.mStrategy;
        r1 = r8.mTimeoutMs;
        r3 = android.support.p000v4.content.res.ResourcesCompat.FontCallback.getHandler$ar$ds();
        r4 = new android.support.v4.graphics.TypefaceCompat$ResourcesCallbackAdapter;
        r4.<init>(r12);
        r8 = r8.mRequest;
        r12 = new androidx.core.provider.CallbackWithHandler;
        r12.<init>(r4, r3);
        if (r0 != 0) goto L_0x0087;
    L_0x0040:
        r0 = androidx.core.provider.FontRequestWorker.createCacheId(r8, r11);
        r3 = androidx.core.provider.FontRequestWorker.sTypefaceCache;
        r3 = r3.get(r0);
        r3 = (android.graphics.Typeface) r3;
        if (r3 == 0) goto L_0x0059;
    L_0x004e:
        r7 = new androidx.core.provider.FontRequestWorker$TypefaceResult;
        r7.<init>(r3);
        r12.onTypefaceResult(r7);
        r2 = r3;
        goto L_0x016c;
    L_0x0059:
        r3 = -1;
        if (r1 != r3) goto L_0x0067;
    L_0x005c:
        r7 = androidx.core.provider.FontRequestWorker.getFontSync(r0, r7, r8, r11);
        r12.onTypefaceResult(r7);
        r2 = r7.mTypeface;
        goto L_0x016c;
    L_0x0067:
        r3 = new androidx.core.provider.FontRequestWorker$1;
        r3.<init>(r0, r7, r8, r11);
        r7 = androidx.core.provider.FontRequestWorker.DEFAULT_EXECUTOR_SERVICE;	 Catch:{ InterruptedException -> 0x007b }
        r7 = androidx.core.provider.RequestExecutor.submit(r7, r3, r1);	 Catch:{ InterruptedException -> 0x007b }
        r7 = (androidx.core.provider.FontRequestWorker.TypefaceResult) r7;	 Catch:{ InterruptedException -> 0x007b }
        r12.onTypefaceResult(r7);	 Catch:{ InterruptedException -> 0x007b }
        r2 = r7.mTypeface;	 Catch:{ InterruptedException -> 0x007b }
        goto L_0x016c;
    L_0x007b:
        r7 = move-exception;
        r7 = new androidx.core.provider.FontRequestWorker$TypefaceResult;
        r8 = -3;
        r7.<init>(r8);
        r12.onTypefaceResult(r7);
        goto L_0x016c;
    L_0x0087:
        r0 = androidx.core.provider.FontRequestWorker.createCacheId(r8, r11);
        r1 = androidx.core.provider.FontRequestWorker.sTypefaceCache;
        r1 = r1.get(r0);
        r1 = (android.graphics.Typeface) r1;
        if (r1 == 0) goto L_0x00a0;
    L_0x0095:
        r7 = new androidx.core.provider.FontRequestWorker$TypefaceResult;
        r7.<init>(r1);
        r12.onTypefaceResult(r7);
        r2 = r1;
        goto L_0x016c;
    L_0x00a0:
        r1 = new androidx.core.provider.FontRequestWorker$2;
        r1.<init>(r12);
        r3 = androidx.core.provider.FontRequestWorker.LOCK;
        monitor-enter(r3);
        r12 = androidx.core.provider.FontRequestWorker.PENDING_REPLIES;	 Catch:{ all -> 0x00f1 }
        r12 = r12.get(r0);	 Catch:{ all -> 0x00f1 }
        r12 = (java.util.ArrayList) r12;	 Catch:{ all -> 0x00f1 }
        if (r12 == 0) goto L_0x00b8;
    L_0x00b2:
        r12.add(r1);	 Catch:{ all -> 0x00f1 }
        monitor-exit(r3);	 Catch:{ all -> 0x00f1 }
        goto L_0x016c;
    L_0x00b8:
        r12 = new java.util.ArrayList;	 Catch:{ all -> 0x00f1 }
        r12.<init>();	 Catch:{ all -> 0x00f1 }
        r12.add(r1);	 Catch:{ all -> 0x00f1 }
        r1 = androidx.core.provider.FontRequestWorker.PENDING_REPLIES;	 Catch:{ all -> 0x00f1 }
        r1.put(r0, r12);	 Catch:{ all -> 0x00f1 }
        monitor-exit(r3);	 Catch:{ all -> 0x00f1 }
        r12 = new androidx.core.provider.FontRequestWorker$3;
        r12.<init>(r0, r7, r8, r11);
        r7 = androidx.core.provider.FontRequestWorker.DEFAULT_EXECUTOR_SERVICE;
        r8 = new androidx.core.provider.FontRequestWorker$4;
        r8.<init>(r0);
        r0 = android.os.Looper.myLooper();
        if (r0 != 0) goto L_0x00e2;
    L_0x00d8:
        r0 = new android.os.Handler;
        r1 = android.os.Looper.getMainLooper();
        r0.<init>(r1);
        goto L_0x00e7;
    L_0x00e2:
        r0 = new android.os.Handler;
        r0.<init>();
    L_0x00e7:
        r1 = new androidx.core.provider.RequestExecutor$ReplyRunnable;
        r1.<init>(r0, r12, r8);
        r7.execute(r1);
        goto L_0x016c;
    L_0x00f1:
        r7 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x00f1 }
        throw r7;
    L_0x00f4:
        r12.callbackSuccessAsync$ar$ds(r0);
        return r0;
    L_0x00f8:
        r8 = (android.support.p000v4.content.res.FontResourcesParserCompat.FontFamilyFilesResourceEntry) r8;
        r7 = r8.mEntries;	 Catch:{ Exception -> 0x0162 }
        r8 = r7.length;	 Catch:{ Exception -> 0x0162 }
        r3 = r2;
        r0 = 0;
    L_0x00ff:
        if (r0 >= r8) goto L_0x0137;
    L_0x0101:
        r4 = r7[r0];	 Catch:{ Exception -> 0x0162 }
        r5 = new android.graphics.fonts.Font$Builder;	 Catch:{ IOException -> 0x0133 }
        r6 = r4.mResourceId;	 Catch:{ IOException -> 0x0133 }
        r5.<init>(r9, r6);	 Catch:{ IOException -> 0x0133 }
        r6 = r4.mWeight;	 Catch:{ IOException -> 0x0133 }
        r5 = r5.setWeight(r6);	 Catch:{ IOException -> 0x0133 }
        r6 = r4.mItalic;	 Catch:{ IOException -> 0x0133 }
        r5 = r5.setSlant(r6);	 Catch:{ IOException -> 0x0133 }
        r6 = r4.mTtcIndex;	 Catch:{ IOException -> 0x0133 }
        r5 = r5.setTtcIndex(r6);	 Catch:{ IOException -> 0x0133 }
        r4 = r4.mVariationSettings;	 Catch:{ IOException -> 0x0133 }
        r4 = r5.setFontVariationSettings(r4);	 Catch:{ IOException -> 0x0133 }
        r4 = r4.build();	 Catch:{ IOException -> 0x0133 }
        if (r3 != 0) goto L_0x012f;
    L_0x0128:
        r5 = new android.graphics.fonts.FontFamily$Builder;	 Catch:{ IOException -> 0x0133 }
        r5.<init>(r4);	 Catch:{ IOException -> 0x0133 }
        r3 = r5;
        goto L_0x0132;
    L_0x012f:
        r3.addFont(r4);	 Catch:{ IOException -> 0x0133 }
    L_0x0132:
        goto L_0x0134;
    L_0x0133:
        r4 = move-exception;
    L_0x0134:
        r0 = r0 + 1;
        goto L_0x00ff;
    L_0x0137:
        if (r3 != 0) goto L_0x013a;
    L_0x0139:
        goto L_0x0163;
    L_0x013a:
        r7 = new android.graphics.fonts.FontStyle;	 Catch:{ Exception -> 0x0162 }
        r8 = r11 & 1;
        r0 = 1;
        if (r0 == r8) goto L_0x0144;
    L_0x0141:
        r8 = 400; // 0x190 float:5.6E-43 double:1.976E-321;
        goto L_0x0146;
    L_0x0144:
        r8 = 700; // 0x2bc float:9.81E-43 double:3.46E-321;
    L_0x0146:
        r4 = r11 & 2;
        if (r4 == 0) goto L_0x014c;
    L_0x014a:
        r1 = 1;
        goto L_0x014d;
    L_0x014d:
        r7.<init>(r8, r1);	 Catch:{ Exception -> 0x0162 }
        r8 = new android.graphics.Typeface$CustomFallbackBuilder;	 Catch:{ Exception -> 0x0162 }
        r0 = r3.build();	 Catch:{ Exception -> 0x0162 }
        r8.<init>(r0);	 Catch:{ Exception -> 0x0162 }
        r7 = r8.setStyle(r7);	 Catch:{ Exception -> 0x0162 }
        r2 = r7.build();	 Catch:{ Exception -> 0x0162 }
        goto L_0x0163;
    L_0x0162:
        r7 = move-exception;
    L_0x0163:
        if (r2 == 0) goto L_0x0169;
    L_0x0165:
        r12.callbackSuccessAsync$ar$ds(r2);
        goto L_0x016c;
    L_0x0169:
        android.support.p000v4.content.res.ResourcesCompat.FontCallback.callbackFailAsync$ar$ds$f10018_0();
    L_0x016c:
        if (r2 == 0) goto L_0x0177;
    L_0x016e:
        r7 = sTypefaceCache;
        r8 = android.support.p000v4.graphics.TypefaceCompat.createResourceUid(r9, r10, r11);
        r7.put(r8, r2);
    L_0x0177:
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.graphics.TypefaceCompat.createFromResourcesFamilyXml$ar$ds(android.content.Context, android.support.v4.content.res.FontResourcesParserCompat$FamilyResourceEntry, android.content.res.Resources, int, int, android.support.v4.content.res.ResourcesCompat$FontCallback):android.graphics.Typeface");
    }

    public static String createResourceUid(Resources resources, int i, int i2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(resources.getResourcePackageName(i));
        String str = "-";
        stringBuilder.append(str);
        stringBuilder.append(i);
        stringBuilder.append(str);
        stringBuilder.append(i2);
        return stringBuilder.toString();
    }

    static {
        TypefaceCompatBaseImpl typefaceCompatBaseImpl = new TypefaceCompatBaseImpl();
    }
}
