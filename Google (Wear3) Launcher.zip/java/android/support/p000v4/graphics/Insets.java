package android.support.p000v4.graphics;

import android.graphics.Rect;

/* compiled from: PG */
/* renamed from: android.support.v4.graphics.Insets */
public final class Insets {
    public static final Insets NONE = new Insets(0, 0, 0, 0);
    public final int bottom;
    public final int left;
    public final int right;
    public final int top;

    private Insets(int i, int i2, int i3, int i4) {
        this.left = i;
        this.top = i2;
        this.right = i3;
        this.bottom = i4;
    }

    /* renamed from: of */
    public static Insets m0of(int i, int i2, int i3, int i4) {
        if (i == 0) {
            if (i2 != 0) {
                i = 0;
            } else if (i3 != 0) {
                i = 0;
                i2 = 0;
            } else if (i4 == 0) {
                return NONE;
            } else {
                i = 0;
                i2 = 0;
                i3 = 0;
            }
        }
        return new Insets(i, i2, i3, i4);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (getClass() == obj.getClass()) {
                Insets insets = (Insets) obj;
                return this.bottom == insets.bottom && this.left == insets.left && this.right == insets.right && this.top == insets.top;
            }
        }
        return false;
    }

    public final int hashCode() {
        return (((((this.left * 31) + this.top) * 31) + this.right) * 31) + this.bottom;
    }

    public final android.graphics.Insets toPlatformInsets() {
        return android.graphics.Insets.of(this.left, this.top, this.right, this.bottom);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Insets{left=");
        stringBuilder.append(this.left);
        stringBuilder.append(", top=");
        stringBuilder.append(this.top);
        stringBuilder.append(", right=");
        stringBuilder.append(this.right);
        stringBuilder.append(", bottom=");
        stringBuilder.append(this.bottom);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }

    /* renamed from: of */
    public static Insets m1of(Rect rect) {
        return Insets.m0of(rect.left, rect.top, rect.right, rect.bottom);
    }
}
