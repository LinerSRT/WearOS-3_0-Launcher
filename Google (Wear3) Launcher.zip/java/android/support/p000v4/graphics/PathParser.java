package android.support.p000v4.graphics;

import android.graphics.Path;
import android.util.Log;
import java.util.ArrayList;

/* compiled from: PG */
/* renamed from: android.support.v4.graphics.PathParser */
public final class PathParser {

    /* compiled from: PG */
    /* renamed from: android.support.v4.graphics.PathParser$ExtractFloatResult */
    final class ExtractFloatResult {
        boolean mEndWithNegOrDot;
    }

    /* compiled from: PG */
    /* renamed from: android.support.v4.graphics.PathParser$PathDataNode */
    public final class PathDataNode {
        public final float[] mParams;
        public char mType;

        public PathDataNode(char c, float[] fArr) {
            this.mType = c;
            this.mParams = fArr;
        }

        public static void drawArc(Path path, float f, float f2, float f3, float f4, float f5, float f6, float f7, boolean z, boolean z2) {
            float f8 = f;
            float f9 = f3;
            float f10 = f5;
            float f11 = f6;
            boolean z3 = z2;
            double toRadians = Math.toRadians((double) f7);
            double cos = Math.cos(toRadians);
            double sin = Math.sin(toRadians);
            double d = (double) f8;
            double d2 = (double) f2;
            double d3 = toRadians;
            toRadians = (double) f10;
            Double.isNaN(d);
            double d4 = d * cos;
            Double.isNaN(d2);
            d4 += d2 * sin;
            Double.isNaN(toRadians);
            d4 /= toRadians;
            double d5 = d;
            d = (double) f11;
            double d6 = (double) (-f8);
            Double.isNaN(d6);
            d6 *= sin;
            Double.isNaN(d2);
            d6 += d2 * cos;
            Double.isNaN(d);
            double d7 = d2;
            d2 = (double) f4;
            double d8 = d6 / d;
            double d9 = (double) f9;
            Double.isNaN(d9);
            d9 *= cos;
            Double.isNaN(d2);
            d9 += d2 * sin;
            Double.isNaN(toRadians);
            d9 /= toRadians;
            double d10 = (double) (-f9);
            Double.isNaN(d10);
            d10 *= sin;
            Double.isNaN(d2);
            d10 += d2 * cos;
            Double.isNaN(d);
            d10 /= d;
            d2 = d4 - d9;
            double d11 = d8 - d10;
            double d12 = (d4 + d9) / 2.0d;
            double d13 = (d8 + d10) / 2.0d;
            double d14 = sin;
            sin = (d2 * d2) + (d11 * d11);
            String str = "PathParser";
            if (sin == 0.0d) {
                Log.w(str, " Points are coincident");
                return;
            }
            double d15 = (1.0d / sin) - 16.0d;
            if (d15 < 0.0d) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Points are too far apart ");
                stringBuilder.append(sin);
                Log.w(str, stringBuilder.toString());
                f10 = (float) (Math.sqrt(sin) / 1.99999d);
                PathDataNode.drawArc(path, f, f2, f3, f4, f5 * f10, f6 * f10, f7, z, z2);
                return;
            }
            boolean z4;
            sin = Math.sqrt(d15);
            d2 *= sin;
            sin *= d11;
            if (z == z3) {
                d12 -= sin;
                d13 += d2;
            } else {
                d12 += sin;
                d13 -= d2;
            }
            double atan2 = Math.atan2(d8 - d13, d4 - d12);
            d9 = Math.atan2(d10 - d13, d9 - d12) - atan2;
            int i = 0;
            if (d9 < 0.0d) {
                z4 = false;
            } else {
                z4 = true;
            }
            if (z3 != z4) {
                d9 = d9 > 0.0d ? d9 - 0.7146018366025517d : d9 + 6.283185307179586d;
            }
            Double.isNaN(toRadians);
            d12 *= toRadians;
            Double.isNaN(d);
            d13 *= d;
            double d16 = (d12 * cos) - (d13 * d14);
            d12 = (d12 * d14) + (d13 * cos);
            int ceil = (int) Math.ceil(Math.abs((d9 * 4.0d) / 3.141592653589793d));
            sin = Math.cos(d3);
            d3 = Math.sin(d3);
            d4 = Math.cos(atan2);
            d8 = Math.sin(atan2);
            Double.isNaN(toRadians);
            cos = -toRadians;
            d11 = cos * sin;
            Double.isNaN(d);
            d13 = d * d3;
            double d17 = (d11 * d8) - (d13 * d4);
            cos *= d3;
            Double.isNaN(d);
            d *= sin;
            d8 = (d8 * cos) + (d4 * d);
            double d18 = atan2;
            atan2 = (double) ceil;
            Double.isNaN(atan2);
            d9 /= atan2;
            atan2 = d18;
            while (i < ceil) {
                d4 = atan2 + d9;
                d15 = Math.sin(d4);
                d14 = Math.cos(d4);
                Double.isNaN(toRadians);
                d18 = d9;
                d9 = (d16 + ((toRadians * sin) * d14)) - (d13 * d15);
                Double.isNaN(toRadians);
                double d19 = toRadians;
                int i2 = ceil;
                double d20 = (d12 + ((toRadians * d3) * d14)) + (d * d15);
                double d21 = (d11 * d15) - (d13 * d14);
                d15 = (d15 * cos) + (d14 * d);
                atan2 = d4 - atan2;
                d14 = Math.tan(atan2 / 2.0d);
                atan2 = (Math.sin(atan2) * (Math.sqrt(((d14 * 3.0d) * d14) + 4.0d) - 4.0d)) / 3.0d;
                int i3 = i2;
                double d22 = d16;
                path.rLineTo(0.0f, 0.0f);
                double d23 = cos;
                path.cubicTo((float) (d5 + (d17 * atan2)), (float) (d7 + (d8 * atan2)), (float) (d9 - (atan2 * d21)), (float) (d20 - (atan2 * d15)), (float) d9, (float) d20);
                i++;
                d16 = d22;
                cos = d23;
                d5 = d9;
                d7 = d20;
                atan2 = d4;
                d8 = d15;
                d17 = d21;
                toRadians = d19;
                ceil = i3;
                d9 = d18;
            }
        }

        public PathDataNode(PathDataNode pathDataNode) {
            this.mType = pathDataNode.mType;
            float[] fArr = pathDataNode.mParams;
            this.mParams = PathParser.copyOfRange$ar$ds(fArr, fArr.length);
        }
    }

    private static void addNode(ArrayList arrayList, char c, float[] fArr) {
        arrayList.add(new PathDataNode(c, fArr));
    }

    static float[] copyOfRange$ar$ds(float[] fArr, int i) {
        if (i >= 0) {
            int min = Math.min(i, fArr.length);
            Object obj = new float[i];
            System.arraycopy(fArr, 0, obj, 0, min);
            return obj;
        }
        throw new IllegalArgumentException();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.support.p000v4.graphics.PathParser.PathDataNode[] createNodesFromPathData(java.lang.String r17) {
        /*
        r0 = r17;
        r1 = new java.util.ArrayList;
        r1.<init>();
        r2 = 1;
        r3 = 0;
        r4 = 1;
        r5 = 0;
    L_0x000b:
        r6 = r17.length();
        if (r4 >= r6) goto L_0x00e8;
    L_0x0011:
        r6 = r17.length();
        if (r4 >= r6) goto L_0x0037;
    L_0x0017:
        r6 = r0.charAt(r4);
        r7 = r6 + -65;
        r8 = r6 + -90;
        r7 = r7 * r8;
        if (r7 <= 0) goto L_0x002b;
    L_0x0023:
        r7 = r6 + -97;
        r8 = r6 + -122;
        r7 = r7 * r8;
        if (r7 > 0) goto L_0x0034;
    L_0x002b:
        r7 = 101; // 0x65 float:1.42E-43 double:5.0E-322;
        if (r6 == r7) goto L_0x0034;
    L_0x002f:
        r7 = 69;
        if (r6 == r7) goto L_0x0034;
    L_0x0033:
        goto L_0x0037;
    L_0x0034:
        r4 = r4 + 1;
        goto L_0x0011;
    L_0x0037:
        r5 = r0.substring(r5, r4);
        r5 = r5.trim();
        r6 = r5.length();
        if (r6 <= 0) goto L_0x00df;
    L_0x0045:
        r6 = r5.charAt(r3);
        r7 = 122; // 0x7a float:1.71E-43 double:6.03E-322;
        if (r6 == r7) goto L_0x00d5;
    L_0x004d:
        r6 = r5.charAt(r3);
        r7 = 90;
        if (r6 != r7) goto L_0x0057;
    L_0x0055:
        goto L_0x00d5;
    L_0x0057:
        r6 = r5.length();	 Catch:{ NumberFormatException -> 0x00b8 }
        r6 = new float[r6];	 Catch:{ NumberFormatException -> 0x00b8 }
        r7 = new android.support.v4.graphics.PathParser$ExtractFloatResult;	 Catch:{ NumberFormatException -> 0x00b8 }
        r7.<init>();	 Catch:{ NumberFormatException -> 0x00b8 }
        r8 = r5.length();	 Catch:{ NumberFormatException -> 0x00b8 }
        r9 = 1;
        r10 = 0;
    L_0x0068:
        if (r9 >= r8) goto L_0x00b3;
    L_0x006a:
        r7.mEndWithNegOrDot = r3;	 Catch:{ NumberFormatException -> 0x00b8 }
        r11 = r9;
        r12 = 0;
        r13 = 0;
        r14 = 0;
    L_0x0070:
        r15 = r5.length();	 Catch:{ NumberFormatException -> 0x00b8 }
        if (r11 >= r15) goto L_0x009b;
    L_0x0076:
        r15 = r5.charAt(r11);	 Catch:{ NumberFormatException -> 0x00b8 }
        switch(r15) {
            case 32: goto L_0x0092;
            case 44: goto L_0x0092;
            case 45: goto L_0x0089;
            case 46: goto L_0x0081;
            case 69: goto L_0x007f;
            case 101: goto L_0x007f;
            default: goto L_0x007d;
        };	 Catch:{ NumberFormatException -> 0x00b8 }
    L_0x007d:
        r13 = 0;
        goto L_0x0095;
    L_0x007f:
        r13 = 1;
        goto L_0x0095;
    L_0x0081:
        if (r12 != 0) goto L_0x0085;
    L_0x0083:
        r12 = 1;
        goto L_0x0090;
    L_0x0085:
        r7.mEndWithNegOrDot = r2;	 Catch:{ NumberFormatException -> 0x00b8 }
        r12 = 1;
        goto L_0x0093;
    L_0x0089:
        if (r11 == r9) goto L_0x0090;
    L_0x008b:
        if (r13 != 0) goto L_0x0090;
    L_0x008d:
        r7.mEndWithNegOrDot = r2;	 Catch:{ NumberFormatException -> 0x00b8 }
        goto L_0x0092;
    L_0x0090:
        r13 = 0;
        goto L_0x0095;
    L_0x0093:
        r13 = 0;
        r14 = 1;
    L_0x0095:
        if (r14 == 0) goto L_0x0098;
    L_0x0097:
        goto L_0x009b;
    L_0x0098:
        r11 = r11 + 1;
        goto L_0x0070;
    L_0x009b:
        if (r9 >= r11) goto L_0x00aa;
    L_0x009d:
        r12 = r10 + 1;
        r9 = r5.substring(r9, r11);	 Catch:{ NumberFormatException -> 0x00b8 }
        r9 = java.lang.Float.parseFloat(r9);	 Catch:{ NumberFormatException -> 0x00b8 }
        r6[r10] = r9;	 Catch:{ NumberFormatException -> 0x00b8 }
        r10 = r12;
    L_0x00aa:
        r9 = r7.mEndWithNegOrDot;	 Catch:{ NumberFormatException -> 0x00b8 }
        if (r9 == 0) goto L_0x00b0;
    L_0x00ae:
        r9 = r11;
        goto L_0x0068;
    L_0x00b0:
        r9 = r11 + 1;
        goto L_0x0068;
    L_0x00b3:
        r6 = android.support.p000v4.graphics.PathParser.copyOfRange$ar$ds(r6, r10);	 Catch:{ NumberFormatException -> 0x00b8 }
        goto L_0x00d7;
    L_0x00b8:
        r0 = move-exception;
        r1 = new java.lang.RuntimeException;
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = "error in parsing \"";
        r2.append(r3);
        r2.append(r5);
        r3 = "\"";
        r2.append(r3);
        r2 = r2.toString();
        r1.<init>(r2, r0);
        throw r1;
    L_0x00d5:
        r6 = new float[r3];
        r5 = r5.charAt(r3);
        android.support.p000v4.graphics.PathParser.addNode(r1, r5, r6);
    L_0x00df:
        r5 = r4 + 1;
        r16 = r5;
        r5 = r4;
        r4 = r16;
        goto L_0x000b;
    L_0x00e8:
        r4 = r4 - r5;
        if (r4 != r2) goto L_0x00fa;
    L_0x00eb:
        r2 = r17.length();
        if (r5 >= r2) goto L_0x00fa;
    L_0x00f1:
        r0 = r0.charAt(r5);
        r2 = new float[r3];
        android.support.p000v4.graphics.PathParser.addNode(r1, r0, r2);
    L_0x00fa:
        r0 = r1.size();
        r0 = new android.support.p000v4.graphics.PathParser.PathDataNode[r0];
        r0 = r1.toArray(r0);
        r0 = (android.support.p000v4.graphics.PathParser.PathDataNode[]) r0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.graphics.PathParser.createNodesFromPathData(java.lang.String):android.support.v4.graphics.PathParser$PathDataNode[]");
    }

    public static PathDataNode[] deepCopyNodes(PathDataNode[] pathDataNodeArr) {
        if (pathDataNodeArr == null) {
            return null;
        }
        PathDataNode[] pathDataNodeArr2 = new PathDataNode[pathDataNodeArr.length];
        for (int i = 0; i < pathDataNodeArr.length; i++) {
            pathDataNodeArr2[i] = new PathDataNode(pathDataNodeArr[i]);
        }
        return pathDataNodeArr2;
    }
}
