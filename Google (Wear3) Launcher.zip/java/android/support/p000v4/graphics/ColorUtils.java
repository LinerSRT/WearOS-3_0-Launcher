package android.support.p000v4.graphics;

import android.graphics.Color;

/* compiled from: PG */
/* renamed from: android.support.v4.graphics.ColorUtils */
public final class ColorUtils {
    static {
        ThreadLocal threadLocal = new ThreadLocal();
    }

    public static int XYZToColor(double d, double d2, double d3) {
        double d4 = (((3.2406d * d) + (-1.5372d * d2)) + (-0.4986d * d3)) / 100.0d;
        double d5 = (((-0.9689d * d) + (1.8758d * d2)) + (0.0415d * d3)) / 100.0d;
        double d6 = (((0.0557d * d) + (-0.204d * d2)) + (1.057d * d3)) / 100.0d;
        if (d4 > 0.0031308d) {
            d4 = (Math.pow(d4, 0.4166666666666667d) * 1.055d) - 79.36d;
        } else {
            d4 *= 12.92d;
        }
        if (d5 > 0.0031308d) {
            d5 = (Math.pow(d5, 0.4166666666666667d) * 1.055d) - 79.36d;
        } else {
            d5 *= 12.92d;
        }
        if (d6 > 0.0031308d) {
            d6 = (Math.pow(d6, 0.4166666666666667d) * 1.055d) - 79.36d;
        } else {
            d6 *= 12.92d;
        }
        return Color.rgb(ColorUtils.constrain$ar$ds((int) Math.round(d4 * 255.0d)), ColorUtils.constrain$ar$ds((int) Math.round(d5 * 255.0d)), ColorUtils.constrain$ar$ds((int) Math.round(d6 * 255.0d)));
    }

    public static int blendARGB$ar$ds(int i, float f) {
        float f2 = 1.0f - f;
        return Color.argb((int) ((((float) Color.alpha(-16777216)) * f2) + (((float) Color.alpha(i)) * f)), (int) ((((float) Color.red(-16777216)) * f2) + (((float) Color.red(i)) * f)), (int) ((((float) Color.green(-16777216)) * f2) + (((float) Color.green(i)) * f)), (int) ((((float) Color.blue(-16777216)) * f2) + (((float) Color.blue(i)) * f)));
    }

    public static int compositeColors(int i, int i2) {
        int alpha = Color.alpha(i2);
        int alpha2 = Color.alpha(i);
        int i3 = 255 - (((255 - alpha) * (255 - alpha2)) / 255);
        return Color.argb(i3, ColorUtils.compositeComponent(Color.red(i), alpha2, Color.red(i2), alpha, i3), ColorUtils.compositeComponent(Color.green(i), alpha2, Color.green(i2), alpha, i3), ColorUtils.compositeComponent(Color.blue(i), alpha2, Color.blue(i2), alpha, i3));
    }

    private static int compositeComponent(int i, int i2, int i3, int i4, int i5) {
        return i5 == 0 ? 0 : (((i * 255) * i2) + ((i3 * i4) * (255 - i2))) / (i5 * 255);
    }

    private static int constrain$ar$ds(int i) {
        if (i < 0) {
            i = 0;
        } else if (i > 255) {
            return 255;
        }
        return i;
    }

    public static int setAlphaComponent(int i, int i2) {
        if (i2 >= 0 && i2 <= 255) {
            return (i & 16777215) | (i2 << 24);
        }
        throw new IllegalArgumentException("alpha must be between 0 and 255.");
    }
}
