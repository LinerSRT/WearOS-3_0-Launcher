package android.support.p000v4.graphics;

import p020j$.util.concurrent.ConcurrentHashMap;

/* compiled from: PG */
/* renamed from: android.support.v4.graphics.TypefaceCompatBaseImpl */
public final class TypefaceCompatBaseImpl {
    public TypefaceCompatBaseImpl() {
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
    }
}
