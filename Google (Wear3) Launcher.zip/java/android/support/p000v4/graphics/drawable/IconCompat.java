package android.support.p000v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;

/* compiled from: PG */
/* renamed from: android.support.v4.graphics.drawable.IconCompat */
public class IconCompat extends CustomVersionedParcelable {
    public static final Mode DEFAULT_TINT_MODE = Mode.SRC_IN;
    public byte[] mData = null;
    public int mInt1 = 0;
    public int mInt2 = 0;
    public Object mObj1;
    public Parcelable mParcelable = null;
    public String mString1;
    public ColorStateList mTintList = null;
    public Mode mTintMode = DEFAULT_TINT_MODE;
    public String mTintModeStr = null;
    public int mType = -1;

    public IconCompat(int i) {
        this.mType = i;
    }

    public static IconCompat createFromBundle(Bundle bundle) {
        int i = bundle.getInt("type");
        IconCompat iconCompat = new IconCompat(i);
        iconCompat.mInt1 = bundle.getInt("int1");
        iconCompat.mInt2 = bundle.getInt("int2");
        iconCompat.mString1 = bundle.getString("string1");
        String str = "tint_list";
        if (bundle.containsKey(str)) {
            iconCompat.mTintList = (ColorStateList) bundle.getParcelable(str);
        }
        str = "tint_mode";
        if (bundle.containsKey(str)) {
            iconCompat.mTintMode = Mode.valueOf(bundle.getString(str));
        }
        str = "obj";
        switch (i) {
            case -1:
            case 1:
            case 5:
                iconCompat.mObj1 = bundle.getParcelable(str);
                break;
            case 2:
            case 4:
            case 6:
                iconCompat.mObj1 = bundle.getString(str);
                break;
            case 3:
                iconCompat.mObj1 = bundle.getByteArray(str);
                break;
            default:
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unknown type ");
                stringBuilder.append(i);
                Log.w("IconCompat", stringBuilder.toString());
                return null;
        }
        return iconCompat;
    }

    public static IconCompat createWithResource$ar$ds(String str, int i) {
        if (str == null) {
            throw new IllegalArgumentException("Package must not be null.");
        } else if (i != 0) {
            IconCompat iconCompat = new IconCompat(2);
            iconCompat.mInt1 = i;
            iconCompat.mObj1 = str;
            iconCompat.mString1 = str;
            return iconCompat;
        } else {
            throw new IllegalArgumentException("Drawable resource ID must not be 0");
        }
    }

    public final int getResId() {
        int i = this.mType;
        if (i == -1) {
            return ((Icon) this.mObj1).getResId();
        }
        if (i == 2) {
            return this.mInt1;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("called getResId() on ");
        stringBuilder.append(this);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final String toString() {
        if (this.mType == -1) {
            return String.valueOf(this.mObj1);
        }
        String str;
        StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
        switch (this.mType) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        stringBuilder.append(str);
        switch (this.mType) {
            case 1:
            case 5:
                stringBuilder.append(" size=");
                stringBuilder.append(((Bitmap) this.mObj1).getWidth());
                stringBuilder.append("x");
                stringBuilder.append(((Bitmap) this.mObj1).getHeight());
                break;
            case 2:
                stringBuilder.append(" pkg=");
                stringBuilder.append(this.mString1);
                stringBuilder.append(" id=");
                stringBuilder.append(String.format("0x%08x", new Object[]{Integer.valueOf(getResId())}));
                break;
            case 3:
                stringBuilder.append(" len=");
                stringBuilder.append(this.mInt1);
                if (this.mInt2 != 0) {
                    stringBuilder.append(" off=");
                    stringBuilder.append(this.mInt2);
                    break;
                }
                break;
            case 4:
            case 6:
                stringBuilder.append(" uri=");
                stringBuilder.append(this.mObj1);
                break;
            default:
                break;
        }
        if (this.mTintList != null) {
            stringBuilder.append(" tint=");
            stringBuilder.append(this.mTintList);
        }
        if (this.mTintMode != DEFAULT_TINT_MODE) {
            stringBuilder.append(" mode=");
            stringBuilder.append(this.mTintMode);
        }
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    @Deprecated
    public final Icon toIcon() {
        Icon icon;
        int i = this.mType;
        StringBuilder stringBuilder;
        switch (i) {
            case -1:
                icon = (Icon) this.mObj1;
                break;
            case 1:
                icon = Icon.createWithBitmap((Bitmap) this.mObj1);
                break;
            case 2:
                String resPackage;
                if (i == -1) {
                    resPackage = ((Icon) this.mObj1).getResPackage();
                } else if (i == 2) {
                    resPackage = TextUtils.isEmpty(this.mString1) ? ((String) this.mObj1).split(":", -1)[0] : this.mString1;
                } else {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("called getResPackage() on ");
                    stringBuilder.append(this);
                    throw new IllegalStateException(stringBuilder.toString());
                }
                icon = Icon.createWithResource(resPackage, this.mInt1);
                break;
            case 3:
                icon = Icon.createWithData((byte[]) this.mObj1, this.mInt1, this.mInt2);
                break;
            case 4:
                icon = Icon.createWithContentUri((String) this.mObj1);
                break;
            case 5:
                icon = Icon.createWithAdaptiveBitmap((Bitmap) this.mObj1);
                break;
            case 6:
                Uri uri;
                if (i == -1) {
                    uri = ((Icon) this.mObj1).getUri();
                } else {
                    if (i != 4) {
                        if (i != 6) {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("called getUri() on ");
                            stringBuilder.append(this);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                    }
                    uri = Uri.parse((String) this.mObj1);
                }
                icon = Icon.createWithAdaptiveBitmapContentUri(uri);
                break;
            default:
                throw new IllegalArgumentException("Unknown type");
        }
        ColorStateList colorStateList = this.mTintList;
        if (colorStateList != null) {
            icon.setTintList(colorStateList);
        }
        Mode mode = this.mTintMode;
        if (mode == DEFAULT_TINT_MODE) {
            return icon;
        }
        icon.setTintMode(mode);
        return icon;
    }
}
