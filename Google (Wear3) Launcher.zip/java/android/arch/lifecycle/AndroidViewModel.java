package android.arch.lifecycle;

import android.app.Application;

/* compiled from: PG */
public final class AndroidViewModel extends ViewModel {
    public AndroidViewModel(Application application) {
    }
}
