package android.arch.lifecycle;

import android.app.Application;
import android.arch.lifecycle.ViewModelProvider.AndroidViewModelFactory;
import android.arch.lifecycle.ViewModelProvider.Factory;
import android.arch.lifecycle.ViewModelProvider.KeyedFactory;
import android.arch.lifecycle.ViewModelProvider.NewInstanceFactory;
import android.os.Bundle;
import androidx.lifecycle.Lifecycle;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.SavedStateRegistryOwner;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

/* compiled from: PG */
public final class SavedStateViewModelFactory extends KeyedFactory {
    private static final Class[] ANDROID_VIEWMODEL_SIGNATURE = new Class[]{Application.class, SavedStateHandle.class};
    private static final Class[] VIEWMODEL_SIGNATURE = new Class[]{SavedStateHandle.class};
    private final Application mApplication;
    private final Bundle mDefaultArgs;
    private final Factory mFactory;
    private final Lifecycle mLifecycle;
    private final SavedStateRegistry mSavedStateRegistry;

    public SavedStateViewModelFactory(Application application, SavedStateRegistryOwner savedStateRegistryOwner, Bundle bundle) {
        Factory factory;
        this.mSavedStateRegistry = savedStateRegistryOwner.getSavedStateRegistry();
        this.mLifecycle = savedStateRegistryOwner.getLifecycle();
        this.mDefaultArgs = bundle;
        this.mApplication = application;
        if (application != null) {
            if (AndroidViewModelFactory.sInstance == null) {
                AndroidViewModelFactory.sInstance = new AndroidViewModelFactory(application);
            }
            factory = AndroidViewModelFactory.sInstance;
            factory.getClass();
        } else {
            if (NewInstanceFactory.sInstance == null) {
                NewInstanceFactory.sInstance = new NewInstanceFactory();
            }
            factory = NewInstanceFactory.sInstance;
            factory.getClass();
        }
        this.mFactory = factory;
    }

    private static Constructor findMatchingConstructor(Class cls, Class[] clsArr) {
        for (Constructor constructor : cls.getConstructors()) {
            if (Arrays.equals(clsArr, constructor.getParameterTypes())) {
                return constructor;
            }
        }
        return null;
    }

    public final ViewModel create(Class cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return create(canonicalName, cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    public final void onRequery(ViewModel viewModel) {
        SavedStateHandleController.attachHandleIfNeeded(viewModel, this.mSavedStateRegistry, this.mLifecycle);
    }

    public final ViewModel create(String str, Class cls) {
        Constructor findMatchingConstructor;
        boolean isAssignableFrom = AndroidViewModel.class.isAssignableFrom(cls);
        if (!isAssignableFrom || this.mApplication == null) {
            findMatchingConstructor = findMatchingConstructor(cls, VIEWMODEL_SIGNATURE);
        } else {
            findMatchingConstructor = findMatchingConstructor(cls, ANDROID_VIEWMODEL_SIGNATURE);
        }
        if (findMatchingConstructor == null) {
            return this.mFactory.create(cls);
        }
        ViewModel viewModel;
        SavedStateHandleController create = SavedStateHandleController.create(this.mSavedStateRegistry, this.mLifecycle, str, this.mDefaultArgs);
        if (isAssignableFrom) {
            try {
                if (this.mApplication != null) {
                    viewModel = (ViewModel) findMatchingConstructor.newInstance(new Object[]{this.mApplication, create.mHandle});
                    viewModel.setTagIfAbsent$ar$ds(create);
                    return viewModel;
                }
            } catch (Throwable e) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Failed to access ");
                stringBuilder.append(cls);
                throw new RuntimeException(stringBuilder.toString(), e);
            } catch (Throwable e2) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("A ");
                stringBuilder.append(cls);
                stringBuilder.append(" cannot be instantiated.");
                throw new RuntimeException(stringBuilder.toString(), e2);
            } catch (InvocationTargetException e3) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("An exception happened in constructor of ");
                stringBuilder.append(cls);
                throw new RuntimeException(stringBuilder.toString(), e3.getCause());
            }
        }
        viewModel = (ViewModel) findMatchingConstructor.newInstance(new Object[]{create.mHandle});
        viewModel.setTagIfAbsent$ar$ds(create);
        return viewModel;
    }
}
