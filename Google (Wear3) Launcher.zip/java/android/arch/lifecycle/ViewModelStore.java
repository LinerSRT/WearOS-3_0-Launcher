package android.arch.lifecycle;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/* compiled from: PG */
public final class ViewModelStore {
    public final HashMap mMap = new HashMap();

    public final void clear() {
        for (ViewModel viewModel : this.mMap.values()) {
            viewModel.mCleared = true;
            synchronized (viewModel.mBagOfTags) {
                for (Object closeWithRuntimeException : viewModel.mBagOfTags.values()) {
                    ViewModel.closeWithRuntimeException(closeWithRuntimeException);
                }
            }
            viewModel.onCleared();
        }
        this.mMap.clear();
    }

    final ViewModel get(String str) {
        return (ViewModel) this.mMap.get(str);
    }

    final Set keys() {
        return new HashSet(this.mMap.keySet());
    }
}
