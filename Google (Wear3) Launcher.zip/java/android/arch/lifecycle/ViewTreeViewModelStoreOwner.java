package android.arch.lifecycle;

import android.view.View;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
public final class ViewTreeViewModelStoreOwner {
    public static void set(View view, ViewModelStoreOwner viewModelStoreOwner) {
        view.setTag(R.id.view_tree_view_model_store_owner, viewModelStoreOwner);
    }
}
