package android.arch.lifecycle;

import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MediatorLiveData.Source;
import androidx.lifecycle.Observer;

/* compiled from: PG */
public final class Transformations {

    /* renamed from: android.arch.lifecycle.Transformations$2 */
    final class PG implements Observer {
        LiveData mSource;
        final /* synthetic */ MediatorLiveData val$result;
        final /* synthetic */ Function val$switchMapFunction;

        /* renamed from: android.arch.lifecycle.Transformations$2$1 */
        final class PG implements Observer {
            public final void onChanged(Object obj) {
                PG.this.val$result.setValue(obj);
            }
        }

        public PG(Function function, MediatorLiveData mediatorLiveData) {
            this.val$switchMapFunction = function;
            this.val$result = mediatorLiveData;
        }

        public final void onChanged(Object obj) {
            LiveData liveData = (LiveData) this.val$switchMapFunction.apply(obj);
            LiveData liveData2 = this.mSource;
            if (liveData2 != liveData) {
                if (liveData2 != null) {
                    Source source = (Source) this.val$result.mSources.remove(liveData2);
                    if (source != null) {
                        source.unplug();
                    }
                }
                this.mSource = liveData;
                if (liveData != null) {
                    this.val$result.addSource(liveData, new PG());
                }
            }
        }
    }

    /* renamed from: android.arch.lifecycle.Transformations$3 */
    public final class C00483 implements Observer {
        boolean mFirstTime = true;
        final /* synthetic */ MediatorLiveData val$outputLiveData;

        public C00483(MediatorLiveData mediatorLiveData) {
            this.val$outputLiveData = mediatorLiveData;
        }

        public final void onChanged(Object obj) {
            Object obj2 = this.val$outputLiveData.mData;
            if (obj2 == LiveData.NOT_SET) {
                obj2 = null;
            }
            if (!this.mFirstTime && (obj2 != null || obj == null)) {
                if (obj2 == null || obj2.equals(obj)) {
                    return;
                }
            }
            this.mFirstTime = false;
            this.val$outputLiveData.setValue(obj);
        }
    }

    public static LiveData switchMap(LiveData liveData, Function function) {
        LiveData mediatorLiveData = new MediatorLiveData();
        mediatorLiveData.addSource(liveData, new PG(function, mediatorLiveData));
        return mediatorLiveData;
    }
}
