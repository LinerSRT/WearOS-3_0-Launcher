package android.arch.lifecycle;

import android.view.View;
import androidx.lifecycle.LifecycleOwner;
import com.google.android.wearable.sysui.R;

/* compiled from: PG */
public final class ViewTreeLifecycleOwner {
    public static void set(View view, LifecycleOwner lifecycleOwner) {
        view.setTag(R.id.view_tree_lifecycle_owner, lifecycleOwner);
    }
}
