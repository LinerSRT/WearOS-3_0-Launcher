package android.arch.lifecycle;

/* compiled from: PG */
public interface ViewModelStoreOwner {
    ViewModelStore getViewModelStore();
}
