package android.arch.lifecycle;

/* compiled from: PG */
public interface GeneratedAdapter {
    void callMethods$ar$ds();
}
