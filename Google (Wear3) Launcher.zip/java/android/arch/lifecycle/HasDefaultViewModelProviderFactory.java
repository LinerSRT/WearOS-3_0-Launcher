package android.arch.lifecycle;

import android.arch.lifecycle.ViewModelProvider.Factory;

/* compiled from: PG */
public interface HasDefaultViewModelProviderFactory {
    Factory getDefaultViewModelProviderFactory();
}
