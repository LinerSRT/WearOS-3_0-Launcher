package android.arch.lifecycle;

import java.io.Closeable;
import java.util.HashMap;
import java.util.Map;

/* compiled from: PG */
public class ViewModel {
    public final Map mBagOfTags = new HashMap();
    public volatile boolean mCleared = false;

    public static void closeWithRuntimeException(Object obj) {
        if (obj instanceof Closeable) {
            try {
                ((Closeable) obj).close();
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        }
    }

    protected void onCleared() {
    }

    final void setTagIfAbsent$ar$ds(Object obj) {
        String str = "android.arch.lifecycle.savedstate.vm.tag";
        synchronized (this.mBagOfTags) {
            Object obj2 = this.mBagOfTags.get(str);
            if (obj2 == null) {
                this.mBagOfTags.put(str, obj);
            }
        }
        if (obj2 != null) {
            obj = obj2;
        }
        if (this.mCleared) {
            closeWithRuntimeException(obj);
        }
    }
}
