package android.arch.lifecycle;

import android.os.Binder;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import androidx.lifecycle.MutableLiveData;
import androidx.savedstate.SavedStateRegistry.SavedStateProvider;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/* compiled from: PG */
public final class SavedStateHandle {
    public static final Class[] ACCEPTABLE_CLASSES = new Class[]{Boolean.TYPE, boolean[].class, Double.TYPE, double[].class, Integer.TYPE, int[].class, Long.TYPE, long[].class, String.class, String[].class, Binder.class, Bundle.class, Byte.TYPE, byte[].class, Character.TYPE, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, Float.TYPE, float[].class, Parcelable.class, Parcelable[].class, Serializable.class, Short.TYPE, short[].class, SparseArray.class, Size.class, SizeF.class};
    public final Map mLiveDatas;
    final Map mRegular;
    public final SavedStateProvider mSavedStateProvider;
    final Map mSavedStateProviders;

    /* renamed from: android.arch.lifecycle.SavedStateHandle$1 */
    final class PG implements SavedStateProvider {
        public final Bundle saveState() {
            for (Entry entry : new HashMap(SavedStateHandle.this.mSavedStateProviders).entrySet()) {
                Bundle saveState = ((SavedStateProvider) entry.getValue()).saveState();
                SavedStateHandle savedStateHandle = SavedStateHandle.this;
                String str = (String) entry.getKey();
                Class[] clsArr = SavedStateHandle.ACCEPTABLE_CLASSES;
                int i = 0;
                while (i < 29) {
                    if (clsArr[i].isInstance(saveState)) {
                        MutableLiveData mutableLiveData = (MutableLiveData) savedStateHandle.mLiveDatas.get(str);
                        if (mutableLiveData != null) {
                            mutableLiveData.setValue(saveState);
                        } else {
                            savedStateHandle.mRegular.put(str, saveState);
                        }
                    } else {
                        i++;
                    }
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Can't put value with type ");
                stringBuilder.append(saveState.getClass());
                stringBuilder.append(" into saved state");
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            Set<String> keySet = SavedStateHandle.this.mRegular.keySet();
            ArrayList arrayList = new ArrayList(keySet.size());
            ArrayList arrayList2 = new ArrayList(arrayList.size());
            for (String str2 : keySet) {
                arrayList.add(str2);
                arrayList2.add(SavedStateHandle.this.mRegular.get(str2));
            }
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("keys", arrayList);
            bundle.putParcelableArrayList("values", arrayList2);
            return bundle;
        }
    }

    public SavedStateHandle() {
        this.mSavedStateProviders = new HashMap();
        this.mLiveDatas = new HashMap();
        this.mSavedStateProvider = new PG();
        this.mRegular = new HashMap();
    }

    public SavedStateHandle(Map map) {
        this.mSavedStateProviders = new HashMap();
        this.mLiveDatas = new HashMap();
        this.mSavedStateProvider = new PG();
        this.mRegular = new HashMap(map);
    }
}
