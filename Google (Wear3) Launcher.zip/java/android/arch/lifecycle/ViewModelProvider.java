package android.arch.lifecycle;

import android.app.Application;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: PG */
public final class ViewModelProvider {
    private final Factory factory;
    private final ViewModelStore store;

    /* compiled from: PG */
    public final class AndroidViewModelFactory extends NewInstanceFactory {
        public static AndroidViewModelFactory sInstance;
        private final Application application;

        public AndroidViewModelFactory(Application application) {
            this.application = application;
        }

        public final ViewModel create(Class cls) {
            String str = "Cannot create an instance of ";
            if (!AndroidViewModel.class.isAssignableFrom(cls)) {
                return super.create(cls);
            }
            try {
                ViewModel viewModel = (ViewModel) cls.getConstructor(new Class[]{Application.class}).newInstance(new Object[]{this.application});
                viewModel.getClass();
                return viewModel;
            } catch (Throwable e) {
                throw new RuntimeException(Intrinsics.stringPlus(str, cls), e);
            } catch (Throwable e2) {
                throw new RuntimeException(Intrinsics.stringPlus(str, cls), e2);
            } catch (Throwable e22) {
                throw new RuntimeException(Intrinsics.stringPlus(str, cls), e22);
            } catch (Throwable e222) {
                throw new RuntimeException(Intrinsics.stringPlus(str, cls), e222);
            }
        }
    }

    /* compiled from: PG */
    public interface Factory {
        ViewModel create(Class cls);
    }

    /* compiled from: PG */
    public abstract class KeyedFactory extends OnRequeryFactory implements Factory {
        public ViewModel create(Class cls) {
            throw null;
        }

        public abstract ViewModel create(String str, Class cls);
    }

    /* compiled from: PG */
    public class NewInstanceFactory implements Factory {
        public static NewInstanceFactory sInstance;

        public ViewModel create(Class cls) {
            String str = "Cannot create an instance of ";
            try {
                Object newInstance = cls.newInstance();
                newInstance.getClass();
                return (ViewModel) newInstance;
            } catch (Throwable e) {
                throw new RuntimeException(Intrinsics.stringPlus(str, cls), e);
            } catch (Throwable e2) {
                throw new RuntimeException(Intrinsics.stringPlus(str, cls), e2);
            }
        }
    }

    /* compiled from: PG */
    public class OnRequeryFactory {
        public void onRequery(ViewModel viewModel) {
        }
    }

    public ViewModelProvider(ViewModelStore viewModelStore, Factory factory) {
        viewModelStore.getClass();
        factory.getClass();
        this.store = viewModelStore;
        this.factory = factory;
    }

    public final ViewModel get(Class cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            canonicalName = Intrinsics.stringPlus("android.arch.lifecycle.ViewModelProvider.DefaultKey:", canonicalName);
            canonicalName.getClass();
            ViewModel viewModel = this.store.get(canonicalName);
            if (cls.isInstance(viewModel)) {
                Factory factory = this.factory;
                OnRequeryFactory onRequeryFactory = factory instanceof OnRequeryFactory ? (OnRequeryFactory) factory : null;
                if (onRequeryFactory != null) {
                    viewModel.getClass();
                    onRequeryFactory.onRequery(viewModel);
                }
                if (viewModel == null) {
                    throw new NullPointerException("null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
                }
            } else {
                Factory factory2 = this.factory;
                if (factory2 instanceof KeyedFactory) {
                    viewModel = ((KeyedFactory) factory2).create(canonicalName, cls);
                } else {
                    viewModel = factory2.create(cls);
                }
                ViewModel viewModel2 = (ViewModel) this.store.mMap.put(canonicalName, viewModel);
                if (viewModel2 != null) {
                    viewModel2.onCleared();
                }
                viewModel.getClass();
            }
            return viewModel;
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    public ViewModelProvider(ViewModelStoreOwner viewModelStoreOwner) {
        ViewModelStore viewModelStore = viewModelStoreOwner.getViewModelStore();
        viewModelStore.getClass();
        Factory defaultViewModelProviderFactory = viewModelStoreOwner.getDefaultViewModelProviderFactory();
        defaultViewModelProviderFactory.getClass();
        this(viewModelStore, defaultViewModelProviderFactory);
    }

    public ViewModelProvider(ViewModelStoreOwner viewModelStoreOwner, Factory factory) {
        factory.getClass();
        ViewModelStore viewModelStore = viewModelStoreOwner.getViewModelStore();
        viewModelStore.getClass();
        this(viewModelStore, factory);
    }
}
